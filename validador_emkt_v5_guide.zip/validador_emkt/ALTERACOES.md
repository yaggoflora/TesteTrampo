# Alterações (v5): regras do GUIDE de Validação do EMKT

Só o **Validador** foi mexido (o SFMC Workbench ficou como estava).

1. **Módulo novo `validador/guide.py`** com as regras do GUIDE: assunto/pré-header, texto, personalização
   (`%%CAMPO%%`, campos genéricos), links (HTTPS, href vazio/#, URL inválida, URL visível), Optout
   (existe, RedirectTo, Alias=Unsubscribe, no Footer, visível), Disclaimer (presença, antifraude, canais,
   comunicação automática), Footer (marca e logo ≥ 30%), CTA (máx. 3, sem sombra/gradiente, 48px, padding 28/14, fonte 20px),
   tipografia (Verdana, corpo 18–24px, legenda ≥ 14px, entrelinha ≥ 24px), grid (700px, margem 42px),
   responsividade, Dark Mode, GIF, QR Code, ícones, segmentação e investimentos.
2. **Prioridades do GUIDE**: P0 entra em "Impede a publicação" e reprova; P1 deixa o pacote em "atenção"
   (`guide.P1_VIRA_ATENCAO = False` desfaz); P2 e P3 só aparecem na seção nova "Regras do GUIDE" (tela e relatório).
3. **Ajuste de rigor**: `guide.NIVEIS` muda a prioridade de qualquer regra (P0–P3 ou `"off"`); `guide.ATIVO = False`
   desliga tudo; limites (600 caracteres, 48px, 700px…) ficam no topo do arquivo.
4. **Texto de imagem sem leitura**: quando o OCR não leu todas as imagens, regras de "texto ausente" (disclaimer,
   antifraude, investimentos…) viram "não conferida" em vez de reprovar.
5. **Segmentação**: o segmento é identificado e segmentos misturados são apontados. Para conferir telefone e domínio
   por segmento, preencha `guide.SEGMENTOS_ESPERADO` com os dados oficiais (vem vazio).
6. **Não automatizável** (aparece em "Conferir à mão"): estrutura Header/Body/Footer e grid de 8 colunas, tipografia do
   Header, clareza do assunto, URL funcional (precisa de rede), contraste do Dark Mode, base legal da LGPD.
7. 45 testes novos (`--testar`): 98 passam. Os casos antigos rodam com o GUIDE desligado, para seguirem testando só o que testavam.

---

# Alterações (v4): repetição, texto de imagem, aviso de conferência e executável

1. **Palavra repetida não reprova.** "Livelo Livelo" no HTML e um "Livelo" no docx vira aviso
   (até 3 palavras, todas já presentes no docx). Fora disso: se o trecho tiver "não", "sem",
   "nunca", "nenhum(a)", continua reprovando. Código: `comparador._motivo_de_aviso`.
2. **Texto de imagem só reprova se NADA dele estiver no docx.** Se pelo menos uma palavra lida
   na imagem consta no docx, o que faltou é aviso. Palavras de 1 a 2 letras (ruído de ícone) não contam.
3. **Continuam reprovando** (de propósito): número, taxa, prazo ou valor diferente (qualquer
   palavra com dígito) e trechos obrigatórios (disclaimer, opt-out, atendimento) ausentes do docx.
4. **Redes sociais** ("Acompanhe o Bradesco nas Redes Sociais") só no docx: é só aviso, e agora
   a peça fica válida (antes ficava em "atenção").
5. **Observação de conferência manual** na tela de cada pacote e no relatório.
6. **Arquivos para executar**: `iniciar_validador.bat` (duplo clique, Windows), `iniciar_validador.sh`
   (bash) e `gerar_exe.bat` (gera `dist\ValidadorEMKT\ValidadorEMKT.exe` no seu computador).
7. 5 testes novos (`--testar`): 53 passam.

---

# Alterações nesta versão (ajuste de rigor + e-mail de devolução)

1. **Só reprova se a peça for realmente diferente.** Acento, vírgula, dois pontos ou
   espaço diferentes entre HTML e CONTEUDO.docx (ex.: `Cartões Digitais:` x `Cartões Digitais`)
   viram **aviso de diferença**: aparecem na tela, não reprovam, não pedem "atenção" e o
   pacote continua **válido para anexar**. Reprova: palavra faltando, trocada ou sobrando,
   imagem errada, letra errada no texto do código, e acento/pontuação **grotescos**.
   Limites em `validador/regras.py` (`LIMITE_ACENTOS_NA_PECA`, `LIMITE_ACENTOS_NO_TRECHO`,
   `LIMITE_PONTUACAO_NA_PECA`). Código: `validador/comparador.py`.
2. **Caixa de console com o e-mail de devolução** em cada pacote (`static/validador.js`,
   `validador/serializacao.py`): válido → e-mail "arquivadas em nosso controle";
   reprovado → e-mail "necessitam de ajustes" com o nome da ação. Saudação pelo horário
   (antes das 12h bom dia, até 18h boa tarde, depois boa noite). Nome e e-mail corporativo
   ficam salvos no navegador; a validade (VAL_ATE_MM.AA) vem do nome da pasta e pode ser editada.
3. 6 testes novos (`--testar`): 48 passam.

---

# Alterações nesta versão

1. **Ponte Validador → Workbench**: botão "Abrir o HTML deste pacote no Workbench" no resultado.
   Rota nova `/api/preview/<id>/html`; no Workbench, `WB.abrirPeca()` (com Desfazer).
   Arquivos: static/validador.js, static/wb/app.js, static/validador.css.
2. **Acentos no OCR**: aviso na tela e no relatório quando o Tesseract está sem `por`.
   Instalador: `python validador_emkt_unificado.py --instalar-idioma-por`
   (usa a pasta do Tesseract; sem permissão, cria `tessdata/` ao lado do script).
   `TESSDATA_URL` aponta para um espelho interno. Com RapidOCR não é preciso. (validador/ocr.py, validador/pacote.py)
3. **Limpeza de relatórios**: ao abrir, apaga os com mais de 30 dias (`DIAS_RELATORIOS=15` muda; `0` desliga).
4. **Cache do OCR**: a versão da leitura é o hash só de `ocr`, `layout` e `normalizacao`. (validador/ocr.py)
5. **Testes do Validador**: 42 casos em `/validador/tests/` e `python validador_emkt_unificado.py --testar`.
   Pacotes reais opcionais em `pacotes_de_teste/PACOTE_APROVADO` e `PACOTE_ERROS`.
