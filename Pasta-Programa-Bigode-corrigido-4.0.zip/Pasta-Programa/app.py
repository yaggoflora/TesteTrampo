"""
Aplicação web simples para localizar, dentro de uma pasta de rede, subpastas
"Val..." cuja validade esteja vencida há 3 meses ou mais.

Este aplicativo é SOMENTE LEITURA: em nenhum momento arquivos ou pastas são
criados, alterados, movidos ou excluídos.

Como executar:
    pip install -r requirements.txt
    python app.py

Depois acesse: http://127.0.0.1:5000
"""

import os

from flask import Flask, render_template, request, jsonify
from scanner import escanear_pastas, CANAIS, CANAL_OUTROS, ROTULO_OUTROS

# A pasta de templates aceita tanto "templates" (padrão do Flask) quanto
# "template" (nome usado em algumas cópias do projeto), para o app subir sem
# depender de qual das duas está no disco.
PASTA_DO_PROJETO = os.path.dirname(os.path.abspath(__file__))
PASTA_TEMPLATES = (
    'templates'
    if os.path.isdir(os.path.join(PASTA_DO_PROJETO, 'templates'))
    else 'template'
)

app = Flask(__name__, template_folder=PASTA_TEMPLATES)


@app.route('/')
def pagina_inicial():
    # A lista de canais é montada aqui e enviada ao HTML, para que os botões
    # de filtro sempre reflitam o que o scanner realmente reconhece.
    canais = [
        {'codigo': codigo, 'rotulo': info['rotulo'], 'descricao': info['descricao']}
        for codigo, info in CANAIS.items()
    ]
    canais.append({
        'codigo': CANAL_OUTROS,
        'rotulo': ROTULO_OUTROS,
        'descricao': 'Pastas fora dos canais acima',
    })
    return render_template('index.html', canais=canais)


@app.route('/api/scan')
def api_scan():
    caminho = request.args.get('path', '').strip()

    if not caminho:
        return jsonify({'sucesso': False, 'erro': 'Informe um caminho de pasta.'}), 400

    # 'canais' chega como lista separada por vírgula (ex: "PUSH,IB").
    # Vazio ou ausente = todos os canais.
    canais_bruto = request.args.get('canais', '').strip()
    canais = [parte for parte in canais_bruto.split(',') if parte.strip()] or None

    dados, erro = escanear_pastas(caminho, canais=canais)

    if erro:
        return jsonify({'sucesso': False, 'erro': erro}), 400

    return jsonify({'sucesso': True, **dados})


if __name__ == '__main__':
    # host='127.0.0.1' = acessível apenas nesta máquina (recomendado).
    # Se precisar acessar de outro computador da rede, use host='0.0.0.0',
    # mas com cautela: isso expõe uma ferramenta de leitura de pastas na rede.
    app.run(debug=True, host='127.0.0.1', port=5000)
