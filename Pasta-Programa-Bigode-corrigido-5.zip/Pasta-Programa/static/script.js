/* ==========================================================================
   Validade de Pastas — interface

   O backend faz a varredura e devolve a lista pronta. Tudo aqui é
   apresentação: filtrar, ordenar e exportar o que já veio.

     1. Estado           5. Filtros e ordenação
     2. Elementos        6. Lista
     3. Canais           7. Exportações
     4. Busca            8. Avisos, atalhos e utilidades
   ========================================================================== */

'use strict';

// ==========================================================================
// 1. Estado
// ==========================================================================

let ultimosResultados = [];
let ultimosAvisos = [];
let resumoCanais = {};

// Recorte visível depois de todos os filtros. É o que exportação e log usam.
let resultadosVisiveis = [];

// Canal selecionado no filtro pós-busca ('todos' ou um código de canal).
let canalAtivo = 'todos';
let severidadeAtiva = 'todas';

// Caminhos que o usuário marcou como conferidos. Vive só enquanto a página
// está aberta e não influencia a busca.
const caminhosVerificados = new Set();

// Preferências lembradas entre sessões (só conveniência, nada sensível).
const CHAVE_CAMINHO = 'bradesco_validade_ultimo_caminho';
const CHAVE_CANAIS = 'bradesco_validade_canais';
const CHAVE_TEMA = 'bradesco_validade_tema';

// ==========================================================================
// 2. Elementos
// ==========================================================================

const $ = (id) => document.getElementById(id);

const form = $('form-busca');
const inputCaminho = $('caminho');
const btnBuscar = $('btn-buscar');
const btnBuscarSpinner = btnBuscar.querySelector('.btn-spinner');
const btnBuscarLabel = btnBuscar.querySelector('.btn-label');

const statusArea = $('status-area');
const emptyState = $('empty-state');
const errorState = $('error-state');

const resultadosSection = $('resultados-section');
const resultsCount = $('results-count');
const listaResultados = $('lista-resultados');
const emptyFiltered = $('empty-filtered');
const toolbarScope = $('toolbar-scope');

const distBar = $('dist-bar');
const distLegenda = $('dist-legenda');
const btnLimparCanal = $('btn-limpar-canal');

const filtroTexto = $('filtro-texto');
const segSeveridade = $('filtro-severidade');
const filtroOrdenacao = $('filtro-ordenacao');
const btnTema = $('btn-tema');
const btnLimparFiltros = $('btn-limpar-filtros');

const canaisChecks = Array.from(document.querySelectorAll('.canal-check'));
const btnCanaisTodos = $('btn-canais-todos');
const btnCanaisNenhum = $('btn-canais-nenhum');
const canaisNota = $('canais-nota');

const CODIGO_OUTROS = 'OUTROS';
const checkOutros = canaisChecks.find((c) => c.value === CODIGO_OUTROS);
const outrosBuscaWrap = $('outros-busca-wrap');
const outrosBuscaInput = $('outros-busca');
const CHAVE_BUSCA_OUTROS = 'bradesco_validade_busca_outros';

const btnCopiarTodos = $('btn-copiar-todos');
const btnCopiarTodosLabel = $('btn-copiar-todos-label');
const btnExportarExcel = $('btn-exportar-excel');
const btnSalvarLog = $('btn-salvar-log');

const avisosSection = $('avisos-section');
const avisosToggle = $('avisos-toggle');
const avisosCorpo = $('avisos-corpo');
const avisosLista = $('avisos-lista');
const avisosContador = $('avisos-contador');
const avisosMais = $('avisos-mais');

const toast = $('toast');

// ==========================================================================
// 3. Canais
// ==========================================================================

function canaisSelecionados() {
  return canaisChecks.filter((c) => c.checked).map((c) => c.value);
}

function rotuloDoChip(check) {
  return check.closest('.chip').querySelector('.chip-face').textContent.trim();
}

function rotulosSelecionados() {
  return canaisChecks.filter((c) => c.checked).map(rotuloDoChip);
}

// Mantém a nota abaixo dos chips dizendo exatamente o que será lido — o
// usuário não deve precisar contar chips para saber o alcance da busca.
function atualizarNotaDeCanais() {
  const marcados = canaisSelecionados();

  if (marcados.length === 0) {
    canaisNota.textContent = 'Marque ao menos um canal para buscar.';
    canaisNota.classList.add('parcial');
  } else if (marcados.length === canaisChecks.length) {
    canaisNota.textContent = 'Todos os canais serão lidos.';
    canaisNota.classList.remove('parcial');
  } else {
    const nomes = rotulosSelecionados();
    canaisNota.textContent =
      `Só ${listarPorExtenso(nomes)} ${nomes.length === 1 ? 'será lido' : 'serão lidos'}. ` +
      'Os demais canais nem são abertos, o que deixa a busca mais rápida.';
    canaisNota.classList.add('parcial');
  }

  guardar(CHAVE_CANAIS, JSON.stringify(marcados));
}

// "PUSH", "PUSH e SMS", "PUSH, SMS e IB" — em vez de uma lista separada
// por vírgula que soa como texto de máquina.
function listarPorExtenso(itens) {
  if (itens.length <= 1) return itens.join('');
  return `${itens.slice(0, -1).join(', ')} e ${itens[itens.length - 1]}`;
}

// Mostra o campo de busca por nome só quando "Outras pastas" está marcada
// — não faz sentido oferecê-lo para os outros canais, que já têm estrutura
// conhecida.
function atualizarVisibilidadeBuscaOutros() {
  if (!checkOutros || !outrosBuscaWrap) return;
  outrosBuscaWrap.hidden = !checkOutros.checked;
}

checkOutros?.addEventListener('change', atualizarVisibilidadeBuscaOutros);

outrosBuscaInput?.addEventListener('input', () => {
  guardar(CHAVE_BUSCA_OUTROS, outrosBuscaInput.value);
});

canaisChecks.forEach((c) => c.addEventListener('change', atualizarNotaDeCanais));

btnCanaisTodos.addEventListener('click', () => {
  canaisChecks.forEach((c) => { c.checked = true; });
  atualizarNotaDeCanais();
});

btnCanaisNenhum.addEventListener('click', () => {
  canaisChecks.forEach((c) => { c.checked = false; });
  atualizarNotaDeCanais();
});

// ==========================================================================
// 4. Busca
// ==========================================================================

let cronometroId = null;

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();

  const caminho = inputCaminho.value.trim();
  if (!caminho) return;

  const canais = canaisSelecionados();
  if (canais.length === 0) {
    mostrarToast('Marque ao menos um canal');
    canaisNota.classList.add('parcial');
    return;
  }

  guardar(CHAVE_CAMINHO, caminho);
  limparEstados();
  definirCarregando(true);
  iniciarStatusDeBusca(caminho, canais);

  try {
    // 'canais' só vai na URL quando há recorte de verdade; com todos
    // marcados o servidor varre tudo, como antes.
    const parametros = new URLSearchParams({ path: caminho });
    if (canais.length < canaisChecks.length) parametros.set('canais', canais.join(','));

    // Filtro de texto de "Outras pastas" — só faz sentido mandar quando o
    // canal está marcado e há algo digitado; em branco busca tudo, como antes.
    const buscaOutros = (checkOutros?.checked && outrosBuscaInput)
      ? outrosBuscaInput.value.trim()
      : '';
    if (buscaOutros) parametros.set('busca_outros', buscaOutros);

    const resposta = await fetch('/api/scan?' + parametros.toString());
    const dados = await resposta.json();

    encerrarStatusDeBusca();

    if (!dados.sucesso) {
      mostrarErro(dados.erro);
      return;
    }

    ultimosResultados = dados.resultados || [];
    ultimosAvisos = dados.avisos || [];
    resumoCanais = dados.resumo_canais || {};

    renderizarAvisos();

    if (ultimosResultados.length === 0) {
      mostrarVazio();
      return;
    }

    resultadosSection.hidden = false;
    canalAtivo = 'todos';
    severidadeAtiva = 'todas';
    filtroTexto.value = '';
    marcarSegmentoAtivo('todas');
    renderizarDistribuicao();
    aplicarFiltros();
  } catch (erro) {
    encerrarStatusDeBusca();
    mostrarErro(
      'O servidor não respondeu. Confirme se o programa ainda está em execução ' +
      'na janela do Python e tente de novo.'
    );
  } finally {
    definirCarregando(false);
  }
});

function definirCarregando(carregando) {
  btnBuscar.disabled = carregando;
  btnBuscarSpinner.hidden = !carregando;
  btnBuscarLabel.textContent = carregando ? 'Buscando' : 'Buscar pastas';
}

// Varredura em pasta de rede pode levar minutos. O cronômetro mostra que
// o programa continua trabalhando, em vez de deixar a tela parada.
function iniciarStatusDeBusca(caminho, canais) {
  const recorte = canais.length < canaisChecks.length
    ? `em ${escapeHtml(listarPorExtenso(rotulosSelecionados()))}`
    : 'em todos os canais';

  statusArea.innerHTML = `
    <div class="status-carregando">
      <span class="pontos" aria-hidden="true"><i></i><i></i><i></i></span>
      <span class="status-texto">
        Lendo as pastas ${recorte}<br>
        <span class="status-alvo">${escapeHtml(caminho)}</span>
      </span>
      <span class="cronometro" id="cronometro">0s</span>
    </div>`;

  const inicio = Date.now();
  cronometroId = setInterval(() => {
    const seg = Math.floor((Date.now() - inicio) / 1000);
    const alvo = $('cronometro');
    if (alvo) alvo.textContent = seg < 60 ? `${seg}s` : `${Math.floor(seg / 60)}min ${seg % 60}s`;
  }, 1000);
}

function encerrarStatusDeBusca() {
  clearInterval(cronometroId);
  cronometroId = null;
  statusArea.innerHTML = '';
}

function limparEstados() {
  emptyState.hidden = true;
  errorState.hidden = true;
  resultadosSection.hidden = true;
  avisosSection.hidden = true;
  listaResultados.innerHTML = '';
  emptyFiltered.hidden = true;
  resultadosVisiveis = [];
}

function mostrarErro(mensagem) {
  errorState.hidden = false;
  errorState.innerHTML = `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="7.4" stroke="currentColor" stroke-width="1.5"/>
      <path d="M10 6.3v4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <circle cx="10" cy="13.4" r=".95" fill="currentColor"/>
    </svg>
    <div>
      <strong>A busca não foi concluída</strong>
      <p>${escapeHtml(mensagem)}</p>
    </div>`;
}

function mostrarVazio() {
  const parcial = canaisSelecionados().length < canaisChecks.length;
  emptyState.hidden = false;
  emptyState.innerHTML = `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3 5.8c0-.7.56-1.3 1.25-1.3h3.4l1.6 1.7h7.5c.69 0 1.25.58 1.25 1.3v7.7c0 .72-.56 1.3-1.25 1.3H4.25C3.56 16.5 3 15.92 3 15.2V5.8Z"
            stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
      <path d="M7.6 11.2 9.3 12.9l3.4-3.6" stroke="currentColor" stroke-width="1.5"
            stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div>
      <strong>Nada vencido por aqui</strong>
      <p>
        Nenhuma pasta "Val..." está vencida há 3 meses ou mais nesse caminho${
          parcial ? ` em ${escapeHtml(listarPorExtenso(rotulosSelecionados()))}` : ''
        }.${parcial ? ' Marque mais canais para ampliar a busca.' : ''}
      </p>
    </div>`;
}

// ==========================================================================
// 5. Filtros e ordenação
// ==========================================================================

// Faixas de gravidade:
//   3 a 4 meses  -> "Vencida"
//   5 a 11 meses -> "Vencido Atenção"
//   12+ meses    -> "Vencido Crítico"
const ROTULO_SEVERIDADE = { atencao: 'Vencida', vencida: 'Vencido Atenção', critica: 'Vencido Crítico' };

function classificarSeveridade(meses) {
  if (meses >= 12) return 'critica';
  if (meses >= 5) return 'vencida';
  return 'atencao';
}

// --- Distribuição por canal (também é o filtro de canal) ------------------

function renderizarDistribuicao() {
  const codigos = Object.keys(resumoCanais).sort((a, b) => resumoCanais[b] - resumoCanais[a]);
  const total = codigos.reduce((soma, c) => soma + resumoCanais[c], 0);

  const rotulos = {};
  ultimosResultados.forEach((item) => { rotulos[item.canal] = item.canal_rotulo; });

  distBar.innerHTML = codigos.map((codigo, i) => {
    const n = resumoCanais[codigo];
    const pct = Math.round((n / total) * 100);
    return `
      <button type="button" class="dist-seg" data-canal="${escapeHtml(codigo)}"
              style="flex-grow: ${n}; animation-delay: ${i * 55}ms"
              title="${escapeHtml(rotulos[codigo] || codigo)}: ${n} (${pct}%)"
              aria-label="Filtrar por ${escapeHtml(rotulos[codigo] || codigo)}, ${n} pastas"></button>`;
  }).join('');

  distLegenda.innerHTML = codigos.map((codigo) => `
    <button type="button" class="legenda-item" data-canal="${escapeHtml(codigo)}"
            aria-pressed="false">
      ${escapeHtml(rotulos[codigo] || codigo)}
      <span class="legenda-num">${resumoCanais[codigo]}</span>
    </button>`).join('');

  [distBar, distLegenda].forEach((container) => {
    container.querySelectorAll('[data-canal]').forEach((el) => {
      el.addEventListener('click', () => {
        // Clicar no canal já ativo desfaz o filtro — evita ficar preso.
        definirCanal(el.dataset.canal === canalAtivo ? 'todos' : el.dataset.canal);
      });
    });
  });
}

function definirCanal(codigo) {
  canalAtivo = codigo;

  distBar.classList.toggle('tem-selecao', codigo !== 'todos');
  distBar.querySelectorAll('.dist-seg').forEach((seg) => {
    seg.classList.toggle('ativo', seg.dataset.canal === codigo);
  });
  distLegenda.querySelectorAll('.legenda-item').forEach((item) => {
    const ativo = item.dataset.canal === codigo;
    item.classList.toggle('ativo', ativo);
    item.setAttribute('aria-pressed', String(ativo));
  });

  btnLimparCanal.hidden = codigo === 'todos';
  aplicarFiltros();
}

btnLimparCanal.addEventListener('click', () => definirCanal('todos'));

// --- Gravidade ------------------------------------------------------------

segSeveridade.addEventListener('click', (evento) => {
  const botao = evento.target.closest('.seg-btn');
  if (!botao || botao.disabled) return;
  severidadeAtiva = botao.dataset.valor;
  marcarSegmentoAtivo(severidadeAtiva);
  aplicarFiltros();
});

function marcarSegmentoAtivo(valor) {
  segSeveridade.querySelectorAll('.seg-btn').forEach((b) => {
    b.classList.toggle('ativo', b.dataset.valor === valor);
  });
}

// --- Texto e ordenação ----------------------------------------------------

filtroTexto.addEventListener('input', aplicarFiltros);
filtroOrdenacao.addEventListener('change', aplicarFiltros);

btnLimparFiltros.addEventListener('click', () => {
  filtroTexto.value = '';
  severidadeAtiva = 'todas';
  marcarSegmentoAtivo('todas');
  definirCanal('todos');
});

// --- Aplicação ------------------------------------------------------------

function aplicarFiltros() {
  const texto = filtroTexto.value.trim().toLowerCase();
  const ordenacao = filtroOrdenacao.value;

  const combinaTextoECanal = (item) => {
    const bateTexto = !texto
      || item.nome.toLowerCase().includes(texto)
      || item.caminho.toLowerCase().includes(texto)
      || (item.campanha || '').toLowerCase().includes(texto);
    const bateCanal = canalAtivo === 'todos' || item.canal === canalAtivo;
    return bateTexto && bateCanal;
  };

  // As contagens do controle de gravidade refletem o recorte atual de
  // canal e texto — assim o número no botão é o que você vai receber.
  const baseParaContagem = ultimosResultados.filter(combinaTextoECanal);
  atualizarContadoresDeSeveridade(baseParaContagem);

  let filtrados = baseParaContagem.filter((item) =>
    severidadeAtiva === 'todas' || classificarSeveridade(item.meses_vencida) === severidadeAtiva
  );

  filtrados = filtrados.slice().sort((a, b) => {
    if (ordenacao === 'recentes') return a.meses_vencida - b.meses_vencida;
    return b.meses_vencida - a.meses_vencida; // 'antigas' (padrão)
  });

  resultadosVisiveis = filtrados;
  renderizarLista(filtrados);
  atualizarContagem(filtrados.length, ultimosResultados.length);
}

function atualizarContadoresDeSeveridade(base) {
  const contagem = { atencao: 0, vencida: 0, critica: 0 };
  base.forEach((item) => { contagem[classificarSeveridade(item.meses_vencida)] += 1; });

  Object.keys(contagem).forEach((sev) => {
    const alvo = segSeveridade.querySelector(`[data-num="${sev}"]`);
    if (alvo) alvo.textContent = contagem[sev];
    const botao = segSeveridade.querySelector(`[data-valor="${sev}"]`);
    // Sem resultados naquela faixa o botão fica inerte, em vez de levar a
    // uma lista vazia.
    if (botao) botao.disabled = contagem[sev] === 0 && severidadeAtiva !== sev;
  });
}

function atualizarContagem(visiveis, total) {
  const plural = (n) => (n === 1 ? 'pasta vencida' : 'pastas vencidas');

  resultsCount.innerHTML = visiveis === total
    ? `<span class="num">${total}</span> ${plural(total)}`
    : `<span class="num num-parcial">${visiveis}</span> de ${total} ${plural(total)}`;

  const nomeCanal = canalAtivo === 'todos'
    ? null
    : (resultadosVisiveis[0]?.canal_rotulo || canalAtivo);

  toolbarScope.textContent = nomeCanal
    ? `Exportações e cópia usam o recorte atual · ${nomeCanal}`
    : 'Exportações e cópia usam o recorte atual';

  btnCopiarTodosLabel.textContent = visiveis === total
    ? `Copiar caminhos (${total})`
    : `Copiar caminhos (${visiveis})`;

  [btnCopiarTodos, btnExportarExcel, btnSalvarLog].forEach((b) => { b.disabled = visiveis === 0; });
}

// ==========================================================================
// 6. Lista
// ==========================================================================

function renderizarLista(itens) {
  if (itens.length === 0) {
    listaResultados.innerHTML = '';
    emptyFiltered.hidden = false;
    return;
  }
  emptyFiltered.hidden = true;

  listaResultados.innerHTML = itens.map((item, indice) => {
    const sev = classificarSeveridade(item.meses_vencida);
    const verificada = caminhosVerificados.has(item.caminho);
    const meses = `${item.meses_vencida} ${item.meses_vencida === 1 ? 'mês' : 'meses'}`;

    return `
      <li class="item${verificada ? ' verificada' : ''}"
          data-canal="${escapeHtml(item.canal)}" data-sev="${sev}">
        <label class="item-check" title="Marcar como conferida">
          <input type="checkbox" class="check-verificada" data-indice="${indice}"
                 ${verificada ? 'checked' : ''}
                 aria-label="Marcar ${escapeHtml(item.nome)} como conferida">
        </label>

        <div class="item-corpo">
          <div class="item-topo">
            <span class="item-nome">${escapeHtml(item.nome)}</span>
            <span class="selos">
              <span class="selo-canal">${escapeHtml(item.canal_rotulo)}</span>
              <span class="selo-sev">${ROTULO_SEVERIDADE[sev]} · ${meses}</span>
            </span>
          </div>

          <div class="item-meta">
            <span>Validade <b>${escapeHtml(item.validade)}</b></span>
            ${item.campanha
              ? `<span class="item-campanha">Campanha <b>${escapeHtml(item.campanha)}</b></span>`
              : ''}
          </div>

          <div class="item-caminho-linha">
            <code class="caminho">${escapeHtml(item.caminho)}</code>
            <button type="button" class="btn-copiar" data-indice="${indice}">
              <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <rect x="7.2" y="7.2" width="9.6" height="9.6" rx="1.6" stroke="currentColor" stroke-width="1.3"/>
                <path d="M13 7.2V5.6c0-.88-.72-1.6-1.6-1.6H4.8c-.88 0-1.6.72-1.6 1.6v6.6c0 .88.72 1.6 1.6 1.6h2.4"
                      stroke="currentColor" stroke-width="1.3"/>
              </svg>
              <span>Copiar</span>
            </button>
          </div>
        </div>
      </li>`;
  }).join('');

  listaResultados.querySelectorAll('.btn-copiar').forEach((botao) => {
    botao.addEventListener('click', () => {
      copiarTexto(itens[Number(botao.dataset.indice)].caminho, botao, 'Copiado', 'Copiar');
    });
  });

  // O estado de conferido fica em `caminhosVerificados` e é reaplicado a
  // cada redesenho, então filtrar ou reordenar não perde as marcações.
  listaResultados.querySelectorAll('.check-verificada').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const item = itens[Number(checkbox.dataset.indice)];
      const linha = checkbox.closest('.item');
      if (checkbox.checked) {
        caminhosVerificados.add(item.caminho);
        linha.classList.add('verificada');
      } else {
        caminhosVerificados.delete(item.caminho);
        linha.classList.remove('verificada');
      }
    });
  });
}

// ==========================================================================
// 7. Exportações
// ==========================================================================

function sufixoDeArquivo() {
  return canalAtivo === 'todos' ? '' : `_${canalAtivo.toLowerCase()}`;
}

btnCopiarTodos.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;
  const caminhos = resultadosVisiveis.map((item) => item.caminho);

  copiarTexto(caminhos.join('\n'), btnCopiarTodos, null, null, () => {
    const original = btnCopiarTodosLabel.textContent;
    btnCopiarTodosLabel.textContent = 'Copiado';
    setTimeout(() => { btnCopiarTodosLabel.textContent = original; }, 1600);
  });

  mostrarToast(`${caminhos.length} caminho${caminhos.length === 1 ? '' : 's'} copiado${caminhos.length === 1 ? '' : 's'}`);
});

// A planilha é montada no navegador, a partir do que já veio da busca.
btnExportarExcel.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;

  const linhas = resultadosVisiveis.map((item) => ({
    'Canal': item.canal_rotulo,
    'Campanha': item.campanha,
    'Nome da pasta': item.nome,
    'Validade': item.validade,
    'Meses vencida': item.meses_vencida,
    'Gravidade': ROTULO_SEVERIDADE[classificarSeveridade(item.meses_vencida)],
    'Caminho completo': item.caminho,
    'Conferida': caminhosVerificados.has(item.caminho) ? 'Sim' : 'Não',
  }));

  const planilha = XLSX.utils.json_to_sheet(linhas);
  planilha['!cols'] = [
    { wch: 10 }, { wch: 36 }, { wch: 26 }, { wch: 10 },
    { wch: 13 }, { wch: 11 }, { wch: 62 }, { wch: 10 },
  ];
  planilha['!autofilter'] = { ref: `A1:H${linhas.length + 1}` };

  const livro = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(livro, planilha, 'Pastas vencidas');
  XLSX.writeFile(livro, `pastas-vencidas${sufixoDeArquivo()}_${hoje()}.xlsx`);

  mostrarToast(`${linhas.length} linha${linhas.length === 1 ? '' : 's'} exportada${linhas.length === 1 ? '' : 's'}`);
});

btnSalvarLog.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;

  const agora = new Date();
  const recorte = canalAtivo === 'todos'
    ? 'todos os canais'
    : (resultadosVisiveis[0]?.canal_rotulo || canalAtivo);

  const linhas = [
    'Validade de pastas — Bradesco CRM · Publicação e Orquestração',
    `Gerado em ${agora.toLocaleString('pt-BR')}`,
    `Caminho: ${inputCaminho.value.trim()}`,
    `Recorte: ${recorte}`,
    `Pastas listadas: ${resultadosVisiveis.length}`,
    '='.repeat(66),
    '',
    ...resultadosVisiveis.map((item) => (
      `${item.nome}\n` +
      `  Canal: ${item.canal_rotulo}${item.campanha ? `  |  Campanha: ${item.campanha}` : ''}\n` +
      `  Validade: ${item.validade}  |  Vencida há: ${item.meses_vencida} ${item.meses_vencida === 1 ? 'mês' : 'meses'}\n` +
      `  Conferida: ${caminhosVerificados.has(item.caminho) ? 'sim' : 'não'}\n` +
      `  Caminho: ${item.caminho}\n`
    )),
  ];

  baixarTexto(linhas.join('\n'), `pastas-vencidas${sufixoDeArquivo()}_${hoje()}.log.txt`);
  mostrarToast('Log salvo');
});

function baixarTexto(conteudo, nomeArquivo) {
  const url = URL.createObjectURL(new Blob([conteudo], { type: 'text/plain;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = nomeArquivo;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const hoje = () => new Date().toISOString().slice(0, 10);

// ==========================================================================
// 8. Avisos, atalhos e utilidades
// ==========================================================================

// Quantos caminhos listar antes de resumir o restante — uma pasta de rede
// com muita permissão negada geraria uma lista interminável.
const LIMITE_AVISOS = 40;

function renderizarAvisos() {
  if (!ultimosAvisos.length) {
    avisosSection.hidden = true;
    return;
  }

  avisosSection.hidden = false;
  avisosContador.textContent = ultimosAvisos.length;

  const visiveis = ultimosAvisos.slice(0, LIMITE_AVISOS);
  avisosLista.innerHTML = visiveis.map((a) => `<li>${escapeHtml(a)}</li>`).join('');

  const restante = ultimosAvisos.length - visiveis.length;
  avisosMais.hidden = restante === 0;
  if (restante > 0) {
    avisosMais.textContent = `+ ${restante} outro${restante === 1 ? '' : 's'} caminho${restante === 1 ? '' : 's'} sem permissão de leitura.`;
  }
}

// Recolhido por padrão: é informação de apoio, não o resultado da busca.
avisosToggle.addEventListener('click', () => {
  const aberto = avisosToggle.getAttribute('aria-expanded') === 'true';
  avisosToggle.setAttribute('aria-expanded', String(!aberto));
  avisosCorpo.hidden = aberto;
});

// --- Atalhos de teclado ---------------------------------------------------

document.addEventListener('keydown', (evento) => {
  const digitando = ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName);

  if (evento.key === '/' && !digitando && !resultadosSection.hidden) {
    evento.preventDefault();
    filtroTexto.focus();
    return;
  }

  if (evento.key === 'Escape' && document.activeElement === filtroTexto) {
    filtroTexto.value = '';
    aplicarFiltros();
  }
});

// --- Cópia com feedback e alternativa para contexto não seguro -----------

function copiarTexto(texto, botao, textoTemporario, textoOriginal, aoConcluir) {
  const feedback = () => {
    if (botao) {
      botao.classList.add('ok');
      setTimeout(() => botao.classList.remove('ok'), 1600);
    }
    if (botao && textoTemporario) {
      const span = botao.querySelector('span:last-child') || botao;
      span.textContent = textoTemporario;
      setTimeout(() => { span.textContent = textoOriginal; }, 1600);
    }
    if (aoConcluir) aoConcluir();
  };

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(texto).then(feedback).catch(() => {
      copiarComFallback(texto);
      feedback();
    });
  } else {
    copiarComFallback(texto);
    feedback();
  }
}

function copiarComFallback(texto) {
  const area = document.createElement('textarea');
  area.value = texto;
  area.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
  document.body.appendChild(area);
  area.select();
  try {
    document.execCommand('copy');
  } catch (erro) {
    mostrarToast('Não foi possível copiar');
  }
  document.body.removeChild(area);
}

let toastTimeout = null;
function mostrarToast(mensagem) {
  toast.textContent = mensagem;
  toast.classList.add('visivel');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('visivel'), 2000);
}

function escapeHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : texto;
  return div.innerHTML;
}

// localStorage pode estar bloqueado por política do navegador corporativo;
// nesse caso o programa segue funcionando, só não lembra as preferências.
function guardar(chave, valor) {
  try { localStorage.setItem(chave, valor); } catch (erro) { /* sem persistência */ }
}

function recuperar(chave) {
  try { return localStorage.getItem(chave); } catch (erro) { return null; }
}

// --- Tema claro/escuro ------------------------------------------------

function aplicarTema(tema) {
  document.documentElement.setAttribute('data-tema', tema);
  if (btnTema) btnTema.setAttribute('aria-pressed', tema === 'escuro' ? 'true' : 'false');
}

btnTema?.addEventListener('click', () => {
  const novoTema = document.documentElement.getAttribute('data-tema') === 'escuro' ? 'claro' : 'escuro';
  aplicarTema(novoTema);
  guardar(CHAVE_TEMA, novoTema);
});

// --- Início ---------------------------------------------------------------

(function iniciar() {
  // O tema em si já foi aplicado por um script inline no <head> (evita
  // "flash" de tela clara); aqui só sincronizamos o estado visual do botão.
  aplicarTema(document.documentElement.getAttribute('data-tema') || 'claro');

  const caminhoSalvo = recuperar(CHAVE_CAMINHO);
  if (caminhoSalvo) inputCaminho.value = caminhoSalvo;

  const canaisSalvos = recuperar(CHAVE_CANAIS);
  if (canaisSalvos) {
    try {
      const lista = JSON.parse(canaisSalvos);
      if (Array.isArray(lista) && lista.length) {
        canaisChecks.forEach((c) => { c.checked = lista.includes(c.value); });
      }
    } catch (erro) { /* preferência inválida: mantém todos marcados */ }
  }

  const buscaOutrosSalva = recuperar(CHAVE_BUSCA_OUTROS);
  if (buscaOutrosSalva && outrosBuscaInput) outrosBuscaInput.value = buscaOutrosSalva;

  atualizarNotaDeCanais();
  atualizarVisibilidadeBuscaOutros();
  inputCaminho.focus();
})();
