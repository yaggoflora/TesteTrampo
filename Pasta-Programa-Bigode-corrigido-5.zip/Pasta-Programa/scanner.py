"""
Módulo responsável por escanear pastas e identificar aquelas com validade
vencida há 3 meses ou mais.

IMPORTANTE: este módulo é SOMENTE LEITURA. Em nenhum momento cria, altera,
move ou exclui arquivos/pastas — apenas lê nomes e navega na árvore de
diretórios.

Versão com leitura em paralelo: como o gargalo em uma pasta de rede é a
LATÊNCIA de cada chamada (não o processamento), várias pastas são lidas ao
mesmo tempo em vez de uma de cada vez. Isso costuma reduzir bastante o tempo
total em compartilhamentos grandes.

Versão com FILTRO POR CANAL: a estrutura da pasta de rede é
    disponiveis\\<briefing + nome da campanha>\\<CANAL>\\...\\Val_MM.AA
onde <CANAL> é PUSH, EMKT, SMS, IB, NET, ATM, MODAL, CARD ou DOCs. É possível escolher quais canais
interessam; os canais não escolhidos não são nem lidos (menos chamadas de
rede = busca mais rápida).
"""

import os
import re
import calendar
import threading
import unicodedata
from datetime import date
from concurrent.futures import ThreadPoolExecutor

# Regex que localiza datas no formato DD.MM.AA ou DD.MM.AAAA dentro do nome
# da pasta (formato real usado nas pastas: "Val_ATE_01.01.25", "Val_ATE_06.02.26").
# (?<!\d) e (?!\d) garantem que não pegamos pedaços de números maiores.
# Exemplos que casam: 01.01.25 | 06.02.26 | 15.11.2026
PADRAO_DATA_DIA_MES_ANO = re.compile(r'(?<!\d)(\d{2})\.(\d{2})\.(\d{4}|\d{2})(?!\d)')

# Formato antigo/alternativo, sem o dia: MM.AA ou MM.AAAA.
# Só é usado como reserva quando NENHUMA data DD.MM.AA é encontrada no nome,
# para não confundir "01.01.25" (dia.mês.ano) com "01.01" (mês.ano) — que era
# exatamente o bug que fazia pastas de 2024/2025/2026 aparecerem como 2001,
# 2002, 2004 etc.
PADRAO_DATA_MES_ANO = re.compile(r'(?<!\d)(\d{2})\.(\d{4}|\d{2})(?!\d)')

# Quantidade de meses de tolerância antes de considerar a pasta "vencida".
MESES_LIMITE_VENCIMENTO = 3

# Quantas pastas são lidas ao mesmo tempo. Como o gargalo é a rede (e não a
# CPU), esse número pode ser bem maior que a quantidade de núcleos da
# máquina. Ajuste para cima/baixo conforme o comportamento do servidor de
# arquivos (números muito altos podem sobrecarregar um servidor de rede
# lento ou levar a mais erros de "muitas conexões simultâneas").
MAX_LEITURAS_PARALELAS = 16

# ============================================================================
# Canais (pastas de meio dentro de cada campanha)
# ============================================================================
# Código usado para tudo que foi encontrado FORA de uma pasta de canal
# conhecida (ex.: uma "Val..." solta direto na pasta da campanha).
CANAL_OUTROS = 'OUTROS'
ROTULO_OUTROS = 'Outras pastas'

# 'apelidos' são os nomes de pasta aceitos para cada canal, já normalizados
# (sem acento, minúsculo, sem separadores). Assim "E-MAIL MARKETING",
# "Email_Marketing" e "emkt" caem todos em EMKT.
CANAIS = {
    'PUSH': {
        'rotulo': 'PUSH',
        'descricao': 'Mobile Push',
        'apelidos': ('push', 'mobile push', 'mobilepush', 'app push'),
    },
    'EMKT': {
        'rotulo': 'EMKT',
        'descricao': 'E-mail marketing',
        'apelidos': ('emkt', 'email', 'e mail', 'email marketing',
                     'e mail marketing', 'mkt email'),
    },
    'SMS': {
        'rotulo': 'SMS',
        'descricao': 'Mensagem de texto',
        'apelidos': ('sms', 'torpedo'),
    },
    'IB': {
        'rotulo': 'IB',
        'descricao': 'Internet Banking',
        'apelidos': ('ib', 'internet banking', 'internetbanking'),
    },
    'NET': {
        'rotulo': 'NET',
        'descricao': 'Bradesco Net Empresa',
        'apelidos': ('net', 'net empresa', 'netempresa', 'bradesco net'),
    },
    'ATM': {
        'rotulo': 'ATM',
        'descricao': 'Atendimento caixa eletrônico',
        'apelidos': ('atm', 'caixa eletronico', 'autoatendimento'),
    },
    'MODAL': {
        'rotulo': 'MODAL',
        'descricao': 'Modais do app',
        'apelidos': ('modal', 'modais'),
    },
    'CARD': {
        'rotulo': 'CARD',
        'descricao': 'Cards do app',
        'apelidos': ('card', 'cards'),
    },
    'DOCS': {
        'rotulo': 'DOCs',
        'descricao': 'Documentos do briefing',
        'apelidos': ('docs', 'doc', 'documento', 'documentos'),
    },
}


def _normalizar(texto: str) -> str:
    """Minúsculo, sem acento e sem separadores — para comparar nomes de pasta."""
    base = unicodedata.normalize('NFKD', texto)
    base = ''.join(c for c in base if not unicodedata.combining(c))
    base = re.sub(r'[^a-z0-9]+', ' ', base.lower())
    return base.strip()


_MAPA_APELIDOS = {
    apelido: codigo
    for codigo, info in CANAIS.items()
    for apelido in info['apelidos']
}


def identificar_canal(nome_pasta: str):
    """Retorna o código do canal ('PUSH', 'IB'...) ou None se não for canal."""
    return _MAPA_APELIDOS.get(_normalizar(nome_pasta))


def rotulo_do_canal(codigo: str) -> str:
    """Nome amigável do canal, para exibição."""
    if codigo == CANAL_OUTROS:
        return ROTULO_OUTROS
    return CANAIS.get(codigo, {}).get('rotulo', codigo)


def codigos_de_canal() -> list:
    """Todos os códigos aceitos no filtro, incluindo OUTROS."""
    return list(CANAIS.keys()) + [CANAL_OUTROS]


def normalizar_selecao(canais):
    """
    Converte a seleção recebida (lista/set/None) em um conjunto de códigos
    válidos. Retorna None quando nada foi informado ou quando todos os
    canais foram selecionados — nesse caso não há filtro nenhum a aplicar.
    """
    if not canais:
        return None

    validos = set(codigos_de_canal())
    selecao = {str(c).strip().upper() for c in canais if str(c).strip()}
    selecao &= validos

    if not selecao or selecao == validos:
        return None
    return selecao


def pasta_e_candidata(nome_pasta: str) -> bool:
    """True se o nome da pasta começa com 'val' (ignorando maiúsculas/minúsculas)."""
    return nome_pasta.strip().lower().startswith('val')


def extrair_validade(nome_pasta: str):
    """
    Encontra a data de validade no nome da pasta.

    Prioridade 1: última ocorrência de DD.MM.AA ou DD.MM.AAAA (formato real
    das pastas, ex: "Val_ATE_01.01.25" -> 01/01/2025). O dia informado é
    usado tal como está no nome.

    Prioridade 2 (reserva): se nenhuma data DD.MM.AA for encontrada, cai para
    o formato antigo MM.AA / MM.AAAA (ex: "Val_08.26"), usando o último dia
    daquele mês como validade.

    Retorna None se nenhuma data válida for encontrada.
    """
    ocorrencias_completas = PADRAO_DATA_DIA_MES_ANO.findall(nome_pasta)
    if ocorrencias_completas:
        dia_str, mes_str, ano_str = ocorrencias_completas[-1]  # última ocorrência

        dia = int(dia_str)
        mes = int(mes_str)
        ano = int(ano_str)

        # Ano com 2 dígitos -> assume-se 20XX (ex: 26 -> 2026)
        if ano < 100:
            ano += 2000

        if mes < 1 or mes > 12:
            return None

        try:
            return date(ano, mes, dia)
        except ValueError:
            # dia inválido para o mês/ano (ex: 31.02.26) -> descarta
            return None

    # Nenhuma data DD.MM.AA encontrada: tenta o formato antigo MM.AA
    ocorrencias_mes_ano = PADRAO_DATA_MES_ANO.findall(nome_pasta)
    if not ocorrencias_mes_ano:
        return None

    mes_str, ano_str = ocorrencias_mes_ano[-1]  # última ocorrência encontrada

    mes = int(mes_str)
    ano = int(ano_str)

    if ano < 100:
        ano += 2000

    if mes < 1 or mes > 12:
        return None

    ultimo_dia_do_mes = calendar.monthrange(ano, mes)[1]
    return date(ano, mes, ultimo_dia_do_mes)


def meses_entre(data_referencia: date, data_validade: date) -> int:
    """
    Quantidade de meses completos já passados desde o fim do mês de validade.
    Considera corretamente a virada de ano (ex: validade 11/2025 e hoje
    fevereiro/2026 = 3 meses).
    """
    return (
        (data_referencia.year - data_validade.year) * 12
        + (data_referencia.month - data_validade.month)
    )


def escanear_pastas(caminho_base: str, data_referencia: date = None, canais=None,
                     busca_outros: str = None):
    """
    Percorre recursivamente 'caminho_base' e retorna a tupla (dados, erro).

    - 'canais': lista de códigos ('PUSH', 'IB', 'ATM', 'EMKT', 'DOCS',
      'OUTROS'). None ou lista completa = sem filtro. Os canais fora da
      seleção NÃO são lidos, o que reduz o número de chamadas à rede.
    - 'busca_outros': texto opcional para restringir o que entra em
      "Outras pastas". Só vale para o canal OUTROS — os demais canais não
      são afetados. Comparação ignora acento/maiúsculas/separadores, e casa
      por trecho (não precisa ser o nome inteiro), tanto contra o nome da
      campanha quanto contra o nome da própria pasta "Val...", para cobrir
      erro de digitação no nome da campanha. Vazio/None = sem filtro,
      devolve tudo que for OUTROS (comportamento de antes).
    - 'dados' é um dicionário: {'resultados': [...], 'avisos': [...],
      'resumo_canais': {...}}
    - 'erro' é uma string de erro, ou None se tudo correu bem.

    Nenhum arquivo ou pasta é alterado, movido ou excluído — apenas leitura.
    """
    if data_referencia is None:
        data_referencia = date.today()

    selecao = normalizar_selecao(canais)
    filtro_outros_norm = _normalizar(busca_outros) if busca_outros else ''

    try:
        if not os.path.exists(caminho_base):
            return None, f'Caminho não encontrado ou inacessível: {caminho_base}'

        if not os.path.isdir(caminho_base):
            return None, f'O caminho informado não é uma pasta: {caminho_base}'
    except OSError as erro:
        return None, f'Não foi possível acessar o caminho informado: {erro}'

    resultados = []
    avisos = []
    lock = threading.Lock()  # protege 'resultados' e 'avisos' entre as threads

    def canal_selecionado(codigo) -> bool:
        """True se esse canal deve entrar no resultado (None = ainda fora de canal)."""
        if selecao is None:
            return True
        return (codigo or CANAL_OUTROS) in selecao

    def listar_subpastas(caminho):
        """Lê apenas os NOMES das subpastas diretas de 'caminho' (somente leitura)."""
        try:
            with os.scandir(caminho) as it:
                return [
                    entrada.name for entrada in it
                    if entrada.is_dir(follow_symlinks=False)
                ]
        except OSError:
            with lock:
                avisos.append(f'Sem permissão/acesso para ler: {caminho}')
            return []

    def processar_pasta(contexto):
        """
        Lê as subpastas diretas de 'contexto'. Cada contexto carrega, além do
        caminho, o canal em que já estamos e a campanha correspondente —
        assim cada resultado sabe de qual canal veio.

        Para cada subpasta encontrada:
          - se for candidata ("Val...") e estiver vencida, registra no
            resultado (desde que o canal esteja na seleção);
          - se for a pasta de um canal (PUSH/EMKT/SMS/IB/NET/ATM/MODAL/
            CARD/DOCs) e esse canal
            NÃO estiver selecionado, ela é ignorada por completo — não se
            entra nela, o que evita leituras desnecessárias na rede;
          - caso contrário, devolve o caminho para ser lido na próxima rodada.
        Não desce dentro de pastas "Val..." (evita varredura desnecessária).
        """
        caminho, canal, campanha = contexto
        proximas = []

        for nome in listar_subpastas(caminho):
            caminho_filho = os.path.join(caminho, nome)

            if pasta_e_candidata(nome):
                if not canal_selecionado(canal):
                    continue  # canal fora do filtro escolhido
                data_validade = extrair_validade(nome)
                if data_validade is not None:
                    meses_vencida = meses_entre(data_referencia, data_validade)
                    if meses_vencida >= MESES_LIMITE_VENCIMENTO:
                        codigo = canal or CANAL_OUTROS
                        # Filtro de texto: só vale para OUTROS. Casa contra o
                        # nome da campanha OU o nome da pasta "Val...", assim
                        # cobre tanto erro de digitação na campanha quanto o
                        # caso de a campanha ainda não ter sido identificada.
                        if codigo == CANAL_OUTROS and filtro_outros_norm:
                            alvo = f'{_normalizar(campanha or "")} {_normalizar(nome)}'
                            if filtro_outros_norm not in alvo:
                                continue
                        with lock:
                            resultados.append({
                                'nome': nome,
                                'caminho': caminho_filho,
                                'validade': data_validade.strftime('%d/%m/%Y'),
                                'meses_vencida': meses_vencida,
                                'canal': codigo,
                                'canal_rotulo': rotulo_do_canal(codigo),
                                'campanha': campanha or '',
                            })
                # já classificada como "Val...": não entra dentro dela.
                continue

            # Só procuramos pasta de canal enquanto ainda não estamos dentro
            # de um canal — assim uma subpasta chamada "Push" lá no fundo de
            # /IB/ não reclassifica o resultado.
            codigo_canal = identificar_canal(nome) if canal is None else None

            # A campanha é sempre a primeira pasta abaixo da raiz consultada
            # (briefing + nome), não importa se um canal foi encontrado ali
            # dentro ou não — assim uma "Val..." solta direto na pasta da
            # campanha (sem passar por nenhum canal) também sai com o nome
            # da campanha preenchido, e não em branco.
            proxima_campanha = campanha if campanha is not None else nome

            if codigo_canal is not None:
                if selecao is not None and codigo_canal not in selecao:
                    continue  # canal descartado: nem é aberto
                proximas.append((caminho_filho, codigo_canal, proxima_campanha))
            else:
                proximas.append((caminho_filho, canal, proxima_campanha))

        return proximas

    # Varredura "por nível" (largura), com cada nível lido em paralelo:
    # primeiro lê a pasta raiz, depois lê TODAS as subpastas encontradas ao
    # mesmo tempo (até MAX_LEITURAS_PARALELAS por vez), depois o próximo
    # nível, e assim por diante — em vez de esperar uma pasta terminar para
    # só então começar a próxima.
    try:
        with ThreadPoolExecutor(max_workers=MAX_LEITURAS_PARALELAS) as executor:
            nivel_atual = [(caminho_base, None, None)]
            while nivel_atual:
                resultados_do_nivel = executor.map(processar_pasta, nivel_atual)
                proximo_nivel = []
                for subpastas_para_ler in resultados_do_nivel:
                    proximo_nivel.extend(subpastas_para_ler)
                nivel_atual = proximo_nivel
    except OSError as erro:
        return None, f'Erro durante a leitura das pastas: {erro}'

    # Mostra primeiro as mais vencidas
    resultados.sort(key=lambda item: item['meses_vencida'], reverse=True)

    # Quantas pastas vencidas em cada canal — usado para montar os contadores
    # do filtro na tela.
    resumo_canais = {}
    for item in resultados:
        resumo_canais[item['canal']] = resumo_canais.get(item['canal'], 0) + 1

    return {
        'resultados': resultados,
        'avisos': avisos,
        'resumo_canais': resumo_canais,
    }, None
