#!/usr/bin/env bash
# Validador EMKT + SFMC Workbench (Linux, macOS ou Git Bash no Windows).
# Uso: ./iniciar_validador.sh   (na primeira vez instala as bibliotecas; precisa de internet)
set -e
cd "$(dirname "$0")"

PY=$(command -v python3 || command -v python || true)
if [ -z "$PY" ]; then
  echo "Python nao encontrado. Instale em https://www.python.org/downloads/"
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Preparando o ambiente pela primeira vez, aguarde..."
  "$PY" -m venv .venv
  VENV_PY=".venv/bin/python"; [ -x "$VENV_PY" ] || VENV_PY=".venv/Scripts/python.exe"
  "$VENV_PY" -m pip install --upgrade pip
  "$VENV_PY" -m pip install flask beautifulsoup4 python-docx pillow rapidocr onnxruntime numpy pytesseract
fi

VENV_PY=".venv/bin/python"; [ -x "$VENV_PY" ] || VENV_PY=".venv/Scripts/python.exe"
echo "Abrindo o Validador EMKT. Ctrl+C encerra."
exec "$VENV_PY" validador_emkt_unificado.py
