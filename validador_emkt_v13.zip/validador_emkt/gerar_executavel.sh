#!/usr/bin/env bash
# Gera o executável do Validador EMKT + SFMC Workbench na pasta dist/.
#
# Quem RECEBE o executável não precisa de Python nem de internet.
# Quem GERA precisa de Python 3.9+ e internet (uma vez, para baixar as bibliotecas).
#
# IMPORTANTE: o PyInstaller não faz "cross-compile". O executável sai para o
# sistema onde este script roda:
#   - rodou no Windows (Git Bash)  -> dist/ValidadorEMKT/ValidadorEMKT.exe
#   - rodou no Linux ou no macOS   -> binário daquele sistema (NÃO abre no Windows)
# Como o time usa Windows, gere no Windows: ou este script no Git Bash, ou o
# gerar_exe.bat (duplo clique).
#
# Uso:  ./gerar_executavel.sh
set -euo pipefail
cd "$(dirname "$0")"

NOME="ValidadorEMKT"
SCRIPT="validador_emkt_unificado.py"

# ---------- 1. Python ----------
PY=$(command -v python3 || command -v python || command -v py || true)
if [ -z "$PY" ]; then
  echo "Python nao encontrado. Instale em https://www.python.org/downloads/ (marque 'Add python.exe to PATH')."
  exit 1
fi

# ---------- 2. Ambiente isolado (.venv) ----------
if [ ! -d ".venv" ]; then
  echo ">> Criando ambiente isolado (.venv)..."
  "$PY" -m venv .venv
fi
VENV_PY=".venv/bin/python"; [ -x "$VENV_PY" ] || VENV_PY=".venv/Scripts/python.exe"

echo ">> Instalando bibliotecas (precisa de internet)..."
"$VENV_PY" -m pip install --quiet --upgrade pip
"$VENV_PY" -m pip install --quiet -r requirements.txt pyinstaller

# ---------- 3. Empacotar ----------
# As bibliotecas de terceiros sao importadas de dentro do script, e os modulos
# do pacote "validador" ficam embutidos como TEXTO: o PyInstaller nao enxerga
# nenhum desses imports sozinho. Por isso o --collect-all e os --hidden-import.
echo ">> Gerando o executavel (leva alguns minutos)..."
"$VENV_PY" -m PyInstaller --noconfirm --clean --onedir --name "$NOME" \
  --collect-all rapidocr --collect-all onnxruntime --collect-all docx \
  --collect-all bs4 --collect-all flask --collect-all pytesseract \
  --hidden-import PIL.Image --hidden-import PIL.ImageOps --hidden-import PIL.ImageFilter \
  --hidden-import PIL.ImageEnhance --hidden-import PIL.ImageSequence --hidden-import numpy \
  --hidden-import difflib --hidden-import unicodedata --hidden-import html \
  --hidden-import hashlib --hidden-import json --hidden-import subprocess \
  --hidden-import urllib.request --hidden-import concurrent.futures \
  --hidden-import importlib.metadata --hidden-import datetime --hidden-import collections \
  --hidden-import dataclasses --hidden-import logging --hidden-import uuid --hidden-import zlib \
  "$SCRIPT"

# ---------- 4. Arquivos de apoio na pasta final ----------
cp LEIA-ME-USUARIO.txt "dist/$NOME/LEIA-ME.txt"

# ---------- 5. Teste: roda a bateria de testes do proprio executavel ----------
BIN="dist/$NOME/$NOME"; [ -f "$BIN" ] || BIN="dist/$NOME/$NOME.exe"
echo ">> Testando o executavel gerado (--testar)..."
if ABRIR_NAVEGADOR=0 "$BIN" --testar > "dist/teste-do-executavel.txt" 2>&1; then
  echo "   Testes OK."
else
  echo "   ATENCAO: os testes do executavel falharam. Veja dist/teste-do-executavel.txt"
  exit 1
fi

# ---------- 6. ZIP para compartilhar ----------
"$VENV_PY" - <<PY
import shutil
shutil.make_archive("dist/$NOME", "zip", "dist", "$NOME")
PY

echo
echo "Pronto!"
echo "  Pasta : dist/$NOME/   (copie a pasta INTEIRA)"
echo "  ZIP   : dist/$NOME.zip (mande este arquivo para o time)"
