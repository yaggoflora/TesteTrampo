## v9
- Números de cartão/serial (6+ dígitos), algarismo solto de ícone e logos de marca (Bradesco, Prime, Friday, Livelo, Visa, Mastercard, Cinemark, Veloe...) não são mais lidos nem comparados. Lista editável: `MARCAS_IGNORADAS` em `validador/ocr.py`.
- Imagem com `width` até 400 no HTML (cartões, selos) não é lida: vai para "revisão manual", sem diferença falsa.

# Alterações (v8): OK/Errado, marcações salvas e quadros do GIF

1. **Caixinhas OK / Errado** em cada ponto a conferir (diferenças de texto e revisão manual). Só uma vale por vez; sem marca =
   pendente. "Errado" abre um campo "o que precisa ajustar" e entra sozinho na lista do e-mail de ajustes.
2. **Trava do e-mail "arquivada"**: com ponto pendente ou marcado como Errado, o botão e a cópia desse e-mail ficam
   bloqueados, com o motivo escrito. Marcar Errado troca para o e-mail de ajustes. "Confirmar e liberar" só aparece com tudo
   OK e sem bloqueio de publicação (P0).
3. **Marcações salvas no navegador**, por peça. Cada marca guarda quem e quando. Ela vale enquanto o apontamento e os
   arquivos de imagem forem os mesmos (assinatura do conteúdo); se a peça mudou, a marca some. Vencem em 30 dias. Botão
   "Limpar marcações". Ficam só naquele computador/navegador.
4. **GIF**: mostra número de quadros, duração, tamanho, peso e se repete, com aviso quando passa dos limites do GUIDE
   (700 px, 10 s), mais os quadros primeiro (o que o Outlook desktop mostra), meio e último.
5. 2 testes novos: 106 passam.

---

# Alterações (v7): revisão manual, GIF, P1–P4 opcionais, layout

1. **GIF animado não é lido.** A peça com GIF mostra "Esta peça tem GIF — revisão manual": o texto do GIF não entra
   na comparação e o analista confere à mão (`ocr.LER_GIF_ANIMADO = True` volta a ler quadro a quadro).
2. **Revisão manual necessária** (seção nova): GIF, imagem que não conseguiu ler, leitura duvidosa, letra miúda
   ignorada, ícones pequenos. Cada ponto tem a caixinha "Conferi manualmente — a peça está correta", com o aviso
   na própria seção de que o analista precisa marcá-la.
3. **P1, P2, P3 do GUIDE viram recomendações recolhidas** (inclui Verdana). Não mudam o veredito; só P0 aparece em
   "Impede a publicação". (`guide.P1_VIRA_ATENCAO = True` volta ao comportamento antigo.)
4. **Disclaimer sem &#xFEFF; deixou de "impedir a publicação"**: vira "Confira o endereço no código" (status atenção).
   Passou a reconhecer também `<wbr>`, &zwnj;, &#8203; e outros caracteres invisíveis.
5. **"Acima de 1 MB" é opcional**: não reprova nem conta; aparece só em "Mostrar avisos opcionais".
6. **"Arquivo na pasta sem chamada no HTML" corrigido**: se o nome da imagem aparece em qualquer lugar do código
   (comentário do Outlook, CSS, VML, maiúscula/minúscula, %20), conta como usada.
7. **Texto muito parecido** (palavra repetida, imagem em parte no docx) aparece como "confira · não reprova", com a dica
   de olhar antes de marcar como correto. Diferenças mínimas (singular/plural, acento, pontuação) seguem ocultas.
8. **Singular x plural** também vale no modo sem leitura de imagem.
9. **Layout**: preview (Comparar lado a lado) no topo; caixa escura do e-mail pronto no rodapé do resultado.
10. Testes: 104 passam.

---

# Alterações (v6): letra miúda, diferenças mínimas e antifraude

1. **Letra miúda não é lida.** Texto pequeno dentro de imagem (escrita em cartão como "MasterCard" e os números,
   ícones, estampa de camisa) é descartado do OCR e não gera diferença. O critério é a altura da caixa de texto na
   escala de 700 px: abaixo de 14 px é ignorado. Ajuste em `validador/ocr.py`: `ALTURA_MINIMA_LETRA_PX`;
   `IGNORAR_LETRAS_MIUDAS = False` volta a ler tudo. Imagem só com letra miúda não vira alerta de "leitura duvidosa".
2. **Singular x plural é a mesma palavra.** "Cartões de Crédito" no HTML e "Cartão de Crédito:" no docx não são mais
   diferença (`comparador.radical`). Palavras com número, curtas e as que mudam o sentido ("não", "sem", "mais"…) não são tocadas.
3. **Diferenças mínimas ficam ocultas e são opcionais.** Tudo que não reprova nem pede atenção (acento, pontuação,
   singular/plural, espaçamento, palavra repetida, redes sociais) some da lista. Na seção Texto há a caixa
   "Mostrar diferenças mínimas (N)", lembrada no navegador. Elas também não entram mais na contagem da seção nem no placar
   de conferência. No relatório, ficam recolhidas em "Diferenças mínimas".
4. **Aviso antifraude passa de P1 para P2** (não é crítico nem obrigatório no GUIDE). Para mudar: `guide.NIVEIS["disclaimer_antifraude"]`
   (P3 ou "off").
5. 3 testes novos (`--testar`): 101 passam.

---

# Alterações (v5): regras do GUIDE de Validação do EMKT

Só o **Validador** foi mexido (o SFMC Workbench ficou como estava).

1. **Módulo novo `validador/guide.py`** com as regras do GUIDE: assunto/pré-header, texto, personalização
   (`%%CAMPO%%`, campos genéricos), links (HTTPS, href vazio/#, URL inválida, URL visível), Optout
   (existe, RedirectTo, Alias=Unsubscribe, no Footer, visível), Disclaimer (presença, antifraude, canais,
   comunicação automática), Footer (marca e logo ≥ 30%), CTA (máx. 3, sem sombra/gradiente, 48px, padding 28/14, fonte 20px),
   tipografia (Verdana, corpo 18–24px, legenda ≥ 14px, entrelinha ≥ 24px), grid (700px, margem 42px),
   responsividade, Dark Mode, GIF, QR Code, ícones, segmentação e investimentos.
2. **Prioridades do GUIDE**: P0 entra em "Impede a publicação" e reprova; P1 deixa o pacote em "atenção"
   (`guide.P1_VIRA_ATENCAO = False` desfaz); P2 e P3 só aparecem na seção nova "Regras do GUIDE" (tela e relatório).
3. **Ajuste de rigor**: `guide.NIVEIS` muda a prioridade de qualquer regra (P0–P3 ou `"off"`); `guide.ATIVO = False`
   desliga tudo; limites (600 caracteres, 48px, 700px…) ficam no topo do arquivo.
4. **Texto de imagem sem leitura**: quando o OCR não leu todas as imagens, regras de "texto ausente" (disclaimer,
   antifraude, investimentos…) viram "não conferida" em vez de reprovar.
5. **Segmentação**: o segmento é identificado e segmentos misturados são apontados. Para conferir telefone e domínio
   por segmento, preencha `guide.SEGMENTOS_ESPERADO` com os dados oficiais (vem vazio).
6. **Não automatizável** (aparece em "Conferir à mão"): estrutura Header/Body/Footer e grid de 8 colunas, tipografia do
   Header, clareza do assunto, URL funcional (precisa de rede), contraste do Dark Mode, base legal da LGPD.
7. 45 testes novos (`--testar`): 98 passam. Os casos antigos rodam com o GUIDE desligado, para seguirem testando só o que testavam.

---

# Alterações (v4): repetição, texto de imagem, aviso de conferência e executável

1. **Palavra repetida não reprova.** "Livelo Livelo" no HTML e um "Livelo" no docx vira aviso
   (até 3 palavras, todas já presentes no docx). Fora disso: se o trecho tiver "não", "sem",
   "nunca", "nenhum(a)", continua reprovando. Código: `comparador._motivo_de_aviso`.
2. **Texto de imagem só reprova se NADA dele estiver no docx.** Se pelo menos uma palavra lida
   na imagem consta no docx, o que faltou é aviso. Palavras de 1 a 2 letras (ruído de ícone) não contam.
3. **Continuam reprovando** (de propósito): número, taxa, prazo ou valor diferente (qualquer
   palavra com dígito) e trechos obrigatórios (disclaimer, opt-out, atendimento) ausentes do docx.
4. **Redes sociais** ("Acompanhe o Bradesco nas Redes Sociais") só no docx: é só aviso, e agora
   a peça fica válida (antes ficava em "atenção").
5. **Observação de conferência manual** na tela de cada pacote e no relatório.
6. **Arquivos para executar**: `iniciar_validador.bat` (duplo clique, Windows), `iniciar_validador.sh`
   (bash) e `gerar_exe.bat` (gera `dist\ValidadorEMKT\ValidadorEMKT.exe` no seu computador).
7. 5 testes novos (`--testar`): 53 passam.

---

# Alterações nesta versão (ajuste de rigor + e-mail de devolução)

1. **Só reprova se a peça for realmente diferente.** Acento, vírgula, dois pontos ou
   espaço diferentes entre HTML e CONTEUDO.docx (ex.: `Cartões Digitais:` x `Cartões Digitais`)
   viram **aviso de diferença**: aparecem na tela, não reprovam, não pedem "atenção" e o
   pacote continua **válido para anexar**. Reprova: palavra faltando, trocada ou sobrando,
   imagem errada, letra errada no texto do código, e acento/pontuação **grotescos**.
   Limites em `validador/regras.py` (`LIMITE_ACENTOS_NA_PECA`, `LIMITE_ACENTOS_NO_TRECHO`,
   `LIMITE_PONTUACAO_NA_PECA`). Código: `validador/comparador.py`.
2. **Caixa de console com o e-mail de devolução** em cada pacote (`static/validador.js`,
   `validador/serializacao.py`): válido → e-mail "arquivadas em nosso controle";
   reprovado → e-mail "necessitam de ajustes" com o nome da ação. Saudação pelo horário
   (antes das 12h bom dia, até 18h boa tarde, depois boa noite). Nome e e-mail corporativo
   ficam salvos no navegador; a validade (VAL_ATE_MM.AA) vem do nome da pasta e pode ser editada.
3. 6 testes novos (`--testar`): 48 passam.

---

# Alterações nesta versão

1. **Ponte Validador → Workbench**: botão "Abrir o HTML deste pacote no Workbench" no resultado.
   Rota nova `/api/preview/<id>/html`; no Workbench, `WB.abrirPeca()` (com Desfazer).
   Arquivos: static/validador.js, static/wb/app.js, static/validador.css.
2. **Acentos no OCR**: aviso na tela e no relatório quando o Tesseract está sem `por`.
   Instalador: `python validador_emkt_unificado.py --instalar-idioma-por`
   (usa a pasta do Tesseract; sem permissão, cria `tessdata/` ao lado do script).
   `TESSDATA_URL` aponta para um espelho interno. Com RapidOCR não é preciso. (validador/ocr.py, validador/pacote.py)
3. **Limpeza de relatórios**: ao abrir, apaga os com mais de 30 dias (`DIAS_RELATORIOS=15` muda; `0` desliga).
4. **Cache do OCR**: a versão da leitura é o hash só de `ocr`, `layout` e `normalizacao`. (validador/ocr.py)
5. **Testes do Validador**: 42 casos em `/validador/tests/` e `python validador_emkt_unificado.py --testar`.
   Pacotes reais opcionais em `pacotes_de_teste/PACOTE_APROVADO` e `PACOTE_ERROS`.
