@echo off
rem Gera o executavel .exe do Validador EMKT + SFMC Workbench.
rem Rode UMA vez num computador COM Python e internet. Demora alguns minutos.
rem Resultado:
rem   dist\ValidadorEMKT\ValidadorEMKT.exe   (pasta inteira)
rem   dist\ValidadorEMKT.zip                 (este arquivo e o que se compartilha)
rem Quem recebe NAO precisa de Python nem de internet.
setlocal
cd /d "%~dp0"

set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python nao encontrado. Instale em https://www.python.org/downloads/ e marque "Add python.exe to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv || goto erro
)
".venv\Scripts\python.exe" -m pip install --upgrade pip || goto erro
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller || goto erro

rem As bibliotecas e os modulos do pacote "validador" sao importados de dentro do
rem script (os modulos ficam embutidos como texto), entao o PyInstaller nao os
rem enxerga sozinho: por isso o --collect-all e os --hidden-import.
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --name ValidadorEMKT ^
  --collect-all rapidocr --collect-all onnxruntime --collect-all docx ^
  --collect-all bs4 --collect-all flask --collect-all pytesseract ^
  --hidden-import PIL.Image --hidden-import PIL.ImageOps --hidden-import PIL.ImageFilter ^
  --hidden-import PIL.ImageEnhance --hidden-import PIL.ImageSequence --hidden-import numpy ^
  --hidden-import difflib --hidden-import unicodedata --hidden-import html ^
  --hidden-import hashlib --hidden-import json --hidden-import subprocess ^
  --hidden-import urllib.request --hidden-import concurrent.futures ^
  --hidden-import importlib.metadata --hidden-import datetime --hidden-import collections ^
  --hidden-import dataclasses --hidden-import logging --hidden-import uuid --hidden-import zlib ^
  validador_emkt_unificado.py || goto erro

copy /y LEIA-ME-USUARIO.txt "dist\ValidadorEMKT\LEIA-ME.txt" >nul

echo.
echo Testando o executavel gerado (--testar)...
set ABRIR_NAVEGADOR=0
"dist\ValidadorEMKT\ValidadorEMKT.exe" --testar > "dist\teste-do-executavel.txt" 2>&1
if errorlevel 1 (
  echo ATENCAO: os testes do executavel falharam. Veja dist\teste-do-executavel.txt
  pause
  exit /b 1
)
echo Testes OK.

echo Compactando para compartilhar...
powershell -NoProfile -Command "Compress-Archive -Path 'dist\ValidadorEMKT' -DestinationPath 'dist\ValidadorEMKT.zip' -Force" || goto erro

echo.
echo Pronto!
echo   Pasta: dist\ValidadorEMKT\ValidadorEMKT.exe
echo   ZIP  : dist\ValidadorEMKT.zip  (mande este arquivo para o time)
pause
exit /b 0

:erro
echo.
echo Algo deu errado. Confira a conexao com a internet e rode de novo.
pause
exit /b 1
