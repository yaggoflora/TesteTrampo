@echo off
rem Validador EMKT + SFMC Workbench: duplo clique para abrir.
rem Na primeira vez cria o ambiente e instala as bibliotecas (precisa de internet).
setlocal
cd /d "%~dp0"

set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python nao encontrado. Instale em https://www.python.org/downloads/ e marque "Add python.exe to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Preparando o ambiente pela primeira vez, aguarde...
  %PY% -m venv .venv || goto erro
  ".venv\Scripts\python.exe" -m pip install --upgrade pip || goto erro
  ".venv\Scripts\python.exe" -m pip install flask beautifulsoup4 python-docx pillow rapidocr onnxruntime numpy pytesseract || goto erro
)

echo Abrindo o Validador EMKT. Deixe esta janela aberta enquanto usa; feche-a para encerrar.
".venv\Scripts\python.exe" validador_emkt_unificado.py
pause
exit /b 0

:erro
echo.
echo Algo deu errado na instalacao. Confira a conexao com a internet e rode de novo.
pause
exit /b 1
