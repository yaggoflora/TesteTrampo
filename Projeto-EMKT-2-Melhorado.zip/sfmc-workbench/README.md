# Gerador AMPScript EMKT - SFMC Workbench

Ferramenta de homologação técnica de HTML de e-mail para Salesforce Marketing Cloud.

## Como usar
Abra `index.html` no navegador. Não precisa instalar nada nem de servidor.
O editor (CodeMirror) fica em `vendor/`, então funciona sem internet. Só as fontes IBM Plex vêm do Google Fonts; sem internet, usa a fonte do sistema.

## Arquivos
- `index.html`: estrutura da página
- `style.css`: visual, com temas claro e escuro
- `regras-time.js`: regras compartilhadas do time (edite aqui para mudar a base de todos)
- `js/parser.js`: leitura do HTML com posição de cada tag, ciente de AMPScript, e ponte para o DOMParser
- `js/rules.js`: catálogo de regras, padrão embutido, validação e armazenamento
- `js/audit.js`: Quality Gate e geração do código final
- `js/preview.js`: dados de teste, modo escuro e imagens bloqueadas no preview
- `js/report.js`: relatório de homologação (TXT e PDF)
- `js/editor.js`: editor com destaque de HTML/AMPScript, busca e navegação por alertas
- `js/app.js`: interface, desfazer/refazer e rascunho
- `tests/`: testes automáticos (abra `tests/index.html`)
- `vendor/codemirror/`: CodeMirror 5.65.20 (licença MIT)

## Atalhos no editor
- `Ctrl+F` buscar, `Alt+G` ir para a linha, `F8` / `Shift+F8` próximo / anterior alerta
- `Ctrl+Z` / `Ctrl+Y` desfazer e refazer (valem para o projeto todo)

## Regras
Prioridade: ajustes salvos no navegador (aba Regras) > `regras-time.js` > padrão em `js/rules.js`.
Para mudar a base do time: ajuste na aba Regras, clique em "Baixar como regras-time.js" e substitua o arquivo na pasta compartilhada.
Níveis: `bloq` (bloqueador), `alerta` ou `off` (desligada).

## Testes
Abra `tests/index.html`. Os casos ficam em `tests/casos.js` e rodam com as regras padrão embutidas.
Ao mudar a lógica de uma regra, rode os testes; ao criar uma regra nova, adicione um caso aprovado e um reprovado.

## Limitações conhecidas
- No preview, blocos IF do AMPScript mostram todos os ramos.
- Links VML dentro de comentários condicionais do Outlook não são auditados.
- Domínios escritos com entidade HTML (ex.: `exemplo&#46;com`) são detectados, mas a proteção anti-link não os altera.
- O rascunho fica salvo só no navegador em que foi feito.
