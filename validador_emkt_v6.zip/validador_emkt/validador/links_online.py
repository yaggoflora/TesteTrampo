"""
Teste de links online (opcional): confere se cada URL da peça responde.

O GUIDE pede "URL funcional", e isso só se descobre pela rede. Por causa da rede do
banco, este módulo NÃO roda sozinho: só quando o analista clica em "Testar links
online" (a tela mostra antes quantos links e quais domínios serão acessados).

O que ele faz e o que não faz:
  - só lê: HEAD e, se o servidor não gostar, GET (sem baixar a página);
  - não envia dado nenhum do pacote, só pede a URL que já está no HTML;
  - segue redirecionamento à mão, salto a salto, e confere cada salto;
  - NÃO acessa endereço interno (localhost, 10.x, 192.168.x, 172.16-31.x, link-local,
    etc.): um HTML de agência não pode fazer o computador do analista bater na intranet.
    Ligue BLOQUEAR_REDE_INTERNA = False só em teste;
  - usa o proxy do sistema (variáveis HTTP_PROXY/HTTPS_PROXY ou configuração do Windows);
  - não desliga a verificação de certificado.

Desligar de vez neste computador: variável de ambiente VALIDADOR_LINKS_ONLINE=0.

O resultado NÃO muda o veredito do pacote: "não respondeu" pode ser a rede do banco, e
site que bloqueia robô responde 403 para quem é gente. Vai para a tela e para o relatório
como conferência, para o analista decidir.
"""

import ipaddress
import os
import re
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from bs4 import BeautifulSoup

from .guide import _Linhas

# --------------------------------------------------------------------- limites
TEMPO_LIMITE_S = 8              # espera por resposta em cada salto
ORCAMENTO_POR_URL_S = 20        # tempo máximo de uma URL, somando os redirecionamentos
ORCAMENTO_TOTAL_S = 120         # depois disso, o que faltou fica "não deu tempo"
MAX_LINKS = 60
SIMULTANEOS = 6
MAX_REDIRECIONAMENTOS = 8
BLOQUEAR_REDE_INTERNA = True
USER_AGENT = "Mozilla/5.0 (compatible; ValidadorEMKT/1.0; conferencia-de-links-de-email)"

# Resposta do servidor que quase sempre é bloqueio de robô, não link quebrado.
_CODIGOS_DE_ROBO = {401, 403, 405, 406, 429, 451, 999}
_ESTADOS = ("ok", "inconclusivo", "falha", "sem_resposta", "bloqueado", "ignorado")


def habilitado() -> bool:
    """Falso quando o time de segurança desligou o recurso (VALIDADOR_LINKS_ONLINE=0)."""
    return os.environ.get("VALIDADOR_LINKS_ONLINE", "").strip().lower() not in (
        "0", "nao", "não", "off", "false", "desligado")


# ------------------------------------------------------------------ coleta
def coletar(codigo_html: str) -> list:
    """
    Links <a href> da peça, sem repetir a URL. Cada item:
    {url, textos, locais, estado (só quando não dá para testar), motivo}.
    """
    codigo = (codigo_html or "").lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    soup = BeautifulSoup(codigo, "html.parser")
    lin = _Linhas(codigo)
    por_url = {}
    for a in soup.find_all("a"):
        href = (a.get("href") or "").strip()
        baixo = href.lower()
        if not baixo.startswith(("http://", "https://", "%%")) or baixo.startswith("%%view_email_url"):
            continue   # vazio, #, javascript, mailto, tel...: o GUIDE já cuida; e-mail e telefone não têm URL para testar
        item = por_url.setdefault(href, {"url": href, "textos": [], "locais": []})
        texto = a.get_text(" ", strip=True) or (a.find("img").get("alt") if a.find("img") else "") or ""
        if texto and texto not in item["textos"]:
            item["textos"].append(texto[:60])
        local = lin.por_tag(a)
        if local:
            item["locais"].append(local)
    saida = []
    for item in por_url.values():
        if "%%" in item["url"]:
            item["estado"] = "ignorado"
            item["motivo"] = ("a URL tem variável ou AMPScript do SFMC (%%…%%): só existe de verdade "
                              "no envio de teste")
        saida.append(item)
    return saida


def plano(codigo_html: str) -> dict:
    """O que seria testado, para a tela pedir confirmação antes de sair para a rede."""
    itens = coletar(codigo_html)
    testaveis = [i for i in itens if "estado" not in i]
    dominios = sorted({(urllib.parse.urlsplit(i["url"]).hostname or "").lower() for i in testaveis} - {""})
    return {
        "total": len(testaveis),
        "dominios": dominios,
        "ignorados": len(itens) - len(testaveis),
        "limitado": len(testaveis) > MAX_LINKS,
        "limite": MAX_LINKS,
    }


# ----------------------------------------------------------- bloqueio de rede interna
def _motivo_de_bloqueio(url: str):
    """Texto do motivo, se a URL não deve ser acessada deste computador; senão None."""
    partes = urllib.parse.urlsplit(url)
    if partes.scheme not in ("http", "https"):
        return "só links http e https são testados"
    host = (partes.hostname or "").strip("[]")
    if not host:
        return "URL sem endereço"
    if not BLOQUEAR_REDE_INTERNA:
        return None
    if host.lower() == "localhost" or host.lower().endswith((".localhost", ".local", ".internal")):
        return "endereço interno (não é testado por segurança)"
    try:
        enderecos = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            enderecos = [ipaddress.ip_address(info[4][0])
                         for info in socket.getaddrinfo(host, partes.port or 443, type=socket.SOCK_STREAM)]
        except (socket.gaierror, UnicodeError, OSError, ValueError):
            return None   # não resolveu aqui: a requisição conta o que houve (pode ser o proxy que resolve)
    for ip in enderecos:
        ip = getattr(ip, "ipv4_mapped", None) or ip
        if not ip.is_global:
            return "o endereço aponta para a rede interna (não é testado por segurança)"
    return None


# ------------------------------------------------------------------ requisição
class _SemRedirecionar(urllib.request.HTTPRedirectHandler):
    """Quem segue o redirecionamento somos nós, para conferir cada salto."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _abridor():
    return urllib.request.build_opener(
        _SemRedirecionar, urllib.request.HTTPSHandler(context=ssl.create_default_context()))


def _pedir(abridor, url: str, metodo: str, tempo: float):
    """(status, cabeçalhos). Erros de rede sobem como exceção."""
    pedido = urllib.request.Request(url, method=metodo, headers={
        "User-Agent": USER_AGENT, "Accept": "text/html,*/*;q=0.8", "Accept-Language": "pt-BR,pt;q=0.9"})
    try:
        with abridor.open(pedido, timeout=tempo) as resposta:
            if metodo == "GET":
                resposta.read(1)       # só para o servidor considerar a visita; a página não é baixada
            return resposta.status, resposta.headers
    except urllib.error.HTTPError as erro:
        try:
            return erro.code, erro.headers
        finally:
            erro.close()


def _descrever_erro(erro: Exception) -> tuple:
    """(estado, mensagem) para falha de rede."""
    causa = getattr(erro, "reason", erro)
    texto = str(causa).lower()
    if isinstance(causa, ssl.SSLCertVerificationError) or "certificate" in texto:
        return "falha", ("certificado do site não é confiável a partir deste computador. Se acontecer com "
                         "todos os links, é a rede do banco inspecionando o tráfego, não a peça")
    if isinstance(causa, socket.gaierror) or "name or service not known" in texto or "getaddrinfo" in texto \
            or "nodename nor servname" in texto or "temporary failure in name resolution" in texto:
        return "falha", "o endereço não existe (o domínio não foi encontrado)"
    if isinstance(causa, (socket.timeout, TimeoutError)) or "timed out" in texto:
        return "sem_resposta", f"sem resposta em {TEMPO_LIMITE_S} s (pode ser a rede do banco bloqueando)"
    if isinstance(causa, ConnectionRefusedError) or "refused" in texto:
        return "falha", "o servidor recusou a conexão"
    if isinstance(causa, ssl.SSLError):
        return "falha", "falha na conexão segura (HTTPS)"
    return "sem_resposta", "não consegui conectar: " + str(causa)[:90]


def _testar_um(url: str, prazo_total: float) -> dict:
    inicio = time.monotonic()
    resultado = {"url": url, "estado": "falha", "status": None, "mensagem": "", "url_final": "",
                 "redirecionamentos": 0, "ms": 0}

    def fechar(estado, mensagem, status=None):
        resultado.update(estado=estado, mensagem=mensagem, status=status,
                         ms=int((time.monotonic() - inicio) * 1000))
        return resultado

    if time.monotonic() > prazo_total:
        return fechar("sem_resposta", f"não deu tempo: o teste tem limite de {ORCAMENTO_TOTAL_S} s no total")

    abridor, atual, visitados = _abridor(), url, [url]
    try:
        while True:
            motivo = _motivo_de_bloqueio(atual)
            if motivo:
                return fechar("bloqueado", motivo if atual == url else f"redirecionou para um endereço bloqueado: {motivo}")
            restante = ORCAMENTO_POR_URL_S - (time.monotonic() - inicio)
            if restante <= 0:
                return fechar("sem_resposta", "demorou demais seguindo os redirecionamentos")
            tempo = max(1.0, min(TEMPO_LIMITE_S, restante))

            try:
                status, cabecalhos = _pedir(abridor, atual, "HEAD", tempo)
                if status >= 400:      # muito servidor recusa HEAD e atende GET
                    status, cabecalhos = _pedir(abridor, atual, "GET", tempo)
            except (urllib.error.URLError, OSError, ValueError) as erro:
                estado, mensagem = _descrever_erro(erro)
                return fechar(estado, mensagem if len(visitados) == 1 else "no meio dos redirecionamentos: " + mensagem)

            if 300 <= status < 400:
                destino = (cabecalhos.get("Location") or "").strip()
                if not destino:
                    return fechar("falha", f"redirecionou (HTTP {status}) sem dizer para onde", status)
                atual = urllib.parse.urljoin(atual, destino)
                if atual in visitados:
                    return fechar("falha", "redirecionamento em círculo", status)
                if len(visitados) > MAX_REDIRECIONAMENTOS:
                    return fechar("falha", f"mais de {MAX_REDIRECIONAMENTOS} redirecionamentos", status)
                visitados.append(atual)
                continue
            break
    except Exception as erro:  # noqa: BLE001 — um link com problema nunca derruba o teste dos outros
        return fechar("sem_resposta", f"erro ao testar: {type(erro).__name__}")

    resultado["redirecionamentos"] = len(visitados) - 1
    resultado["url_final"] = atual if atual != url else ""
    if 200 <= status < 300:
        nota = f"respondeu (HTTP {status})"
        if resultado["redirecionamentos"]:
            nota += f" depois de {resultado['redirecionamentos']} redirecionamento(s)"
        if url.lower().startswith("https://") and atual.lower().startswith("http://"):
            return fechar("falha", "terminou em HTTP, sem HTTPS: " + nota, status)
        return fechar("ok", nota, status)
    if status in _CODIGOS_DE_ROBO:
        return fechar("inconclusivo", f"o site respondeu HTTP {status}, que costuma ser bloqueio de teste "
                                       "automático: abra no navegador para confirmar", status)
    if status in (404, 410):
        return fechar("falha", f"a página não existe (HTTP {status})", status)
    if status >= 500:
        return fechar("falha", f"erro no servidor do site (HTTP {status})", status)
    return fechar("falha", f"o site respondeu HTTP {status}", status)


# ------------------------------------------------------------------ execução
def testar(codigo_html: str) -> dict:
    """Testa os links da peça e devolve o resultado para a tela e o relatório."""
    itens = coletar(codigo_html)
    testaveis = [i for i in itens if "estado" not in i]
    cortados = testaveis[MAX_LINKS:]
    testaveis = testaveis[:MAX_LINKS]
    prazo_total = time.monotonic() + ORCAMENTO_TOTAL_S

    with ThreadPoolExecutor(max_workers=SIMULTANEOS) as pool:
        respostas = list(pool.map(lambda i: _testar_um(i["url"], prazo_total), testaveis))

    linhas = []
    for item, resposta in zip(testaveis, respostas):
        resposta.update(textos=item["textos"], locais=item["locais"])
        linhas.append(resposta)
    for item in itens:
        if "estado" in item:
            linhas.append({"url": item["url"], "estado": "ignorado", "status": None, "mensagem": item["motivo"],
                           "url_final": "", "redirecionamentos": 0, "ms": 0,
                           "textos": item["textos"], "locais": item["locais"]})
    ordem = {e: i for i, e in enumerate(("falha", "sem_resposta", "inconclusivo", "bloqueado", "ok", "ignorado"))}
    linhas.sort(key=lambda l: (ordem[l["estado"]], l["url"]))

    contagem = {e: sum(1 for l in linhas if l["estado"] == e) for e in _ESTADOS}
    avisos = []
    if cortados:
        avisos.append(f"{len(cortados)} link(s) ficaram de fora: o teste vai até {MAX_LINKS} links por peça.")
    rede = contagem["sem_resposta"] + sum(1 for l in linhas if l["estado"] == "falha" and "certificado" in l["mensagem"])
    if len(testaveis) >= 3 and rede == len(testaveis):
        avisos.append("Nenhum link respondeu e o motivo parece ser a rede deste computador (proxy, firewall ou "
                      "inspeção de certificado), não a peça. Teste em outra rede antes de reportar.")
    return {
        "feito_em": time.strftime("%d/%m/%Y %H:%M"),
        "total": len(testaveis), "contagem": contagem, "avisos": avisos, "links": linhas,
    }
