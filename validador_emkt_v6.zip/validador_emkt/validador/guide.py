"""
Regras do GUIDE de Validação do EMKT (HTML, SFMC, compliance e LGPD).

Mesmo espírito do regras.py: são regras do banco, mudam por decisão de processo.
Para mudar o rigor de uma regra, mexa só em NIVEIS (P0, P1, P2, P3 ou "off").

Cada apontamento que tem lugar no HTML traz `locais`: linha e coluna do trecho, no
mesmo critério do editor do SFMC Workbench (o botão "Abrir no Workbench" usa isso).
As regras de código e de SFMC (view_email_url, script, AMPScript, tamanho, DOCTYPE,
link dentro de link) vêm do Quality Gate do Workbench, com o mesmo critério.

Prioridades do GUIDE:
  P0  reprovação imediata   -> entra em "bloqueios" do pacote e reprova
  P1  crítico               -> o pacote fica em "atenção" (não pode anexar)
                               (desligue com P1_VIRA_ATENCAO = False)
  P2  médio                 -> aparece na seção do GUIDE, não muda o veredito
  P3  melhoria              -> idem

O que este módulo NÃO consegue conferir sozinho (precisa de olho humano ou rede)
está em NAO_AUTOMATIZAVEIS e aparece na tela e no relatório.
"""

import bisect
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field

from bs4 import BeautifulSoup, Comment, NavigableString, Tag

from . import excecoes, regras

ATIVO = True
P1_VIRA_ATENCAO = True

# A partir de que ponto do corpo do HTML (0 a 1) começa o footer.
RODAPE_A_PARTIR_DE = 0.55

# --------------------------------------------------------------------- limites
MAX_TEXTO = 600
MAX_CTAS = 3
CTA_FONTE_PX = 20
CTA_ALTURA_PX = 48
CTA_PADDING_LATERAL_PX = 28
CTA_PADDING_VERTICAL_PX = 14
CORPO_MIN_PX, CORPO_MAX_PX = 18, 24
LEGENDA_MIN_PX = 14
ENTRELINHA_MIN_PX = 24
LARGURA_PECA_PX = 700
MARGEM_LATERAL_PX = 42
GIF_MAX_LARGURA_PX = 700
GIF_MAX_SEGUNDOS = 10
QR_MIN_PX = 130
QR_BORDA_PX = 12
ICONE_MIN_PX = 40
LOGO_MIN_PROPORCAO_FOOTER = 0.30
PALAVRAS_TEXTO_EM_IMAGEM = 15
LIMITE_HTML_KB = 102           # corte do Gmail; é o mesmo valor de limiteKB no regras-time.js do Workbench
MAX_LOCAIS = 30                # quantos pontos do HTML cada apontamento guarda

# ------------------------------------------------------------------- catálogo
# id: (grupo, título, prioridade padrão do GUIDE)
CATALOGO = {
    "assunto_rotulo": ("Assunto", "Assunto sem o rótulo “Assunto:” no texto", "P2"),
    "preheader_rotulo": ("Pré-header", "Pré-header sem o rótulo “Pré-header:” no texto", "P2"),
    "preheader_complementa": ("Pré-header", "Pré-header complementa o assunto (não repete)", "P3"),
    "texto_limite": ("Texto", f"Até {MAX_TEXTO} caracteres de texto no HTML", "P3"),
    "texto_em_imagem": ("Texto", "Sem blocos de texto dentro de imagens", "P2"),
    "sem_texto_html": ("Texto", "Conteúdo em HTML (não só imagem)", "P1"),
    "var_generica": ("Personalização", "Sem campos genéricos (Data 1, Nome 1, Data Fim…)", "P1"),
    "var_sintaxe": ("Personalização", "Variáveis %%CAMPO%% bem formadas", "P1"),
    "link_http": ("Links", "Todos os links em HTTPS", "P0"),
    "link_sem_href": ("Links", "CTA e links com URL (sem href vazio, # ou javascript)", "P0"),
    "link_invalido": ("Links", "URL dos links válida", "P0"),
    "url_visivel": ("Links", "Sem URL visível no conteúdo", "P1"),
    "optout_ausente": ("Optout", "Optout existe", "P0"),
    "optout_redirect": ("Optout", "Optout usa RedirectTo", "P0"),
    "optout_alias": ("Optout", "Optout com Alias = Unsubscribe", "P0"),
    "optout_footer": ("Optout", "Optout está no Footer", "P0"),
    "optout_oculto": ("Optout", "Optout visível", "P0"),
    "disclaimer_ausente": ("Disclaimer", "Disclaimer obrigatório presente", "P0"),
    "disclaimer_antifraude": ("Disclaimer", "Aviso antifraude", "P1"),
    "disclaimer_canais": ("Disclaimer", "Canais oficiais", "P1"),
    "disclaimer_automatica": ("Disclaimer", "Aviso de comunicação automática", "P1"),
    "footer_marca": ("Footer", "Assinatura da marca no Footer", "P1"),
    "footer_logo": ("Footer", "Logo horizontal, mínimo 30% do Footer", "P2"),
    "cta_max": ("CTA", f"No máximo {MAX_CTAS} CTAs", "P1"),
    "cta_efeito": ("CTA", "CTA sem sombra, box-shadow ou gradiente", "P1"),
    "cta_medidas": ("CTA", "CTA: altura 48px, padding 28/14px, fonte 20px", "P2"),
    "fonte_verdana": ("Tipografia", "Fonte Verdana", "P1"),
    "fonte_corpo": ("Tipografia", "Corpo de 18px a 24px", "P2"),
    "fonte_legenda": ("Tipografia", "Legenda mínima de 14px", "P2"),
    "entrelinha": ("Tipografia", "Entrelinha mínima de 24px", "P2"),
    "grid_largura": ("Grid", "Largura total de 700px", "P2"),
    "grid_margem": ("Grid", "Margens laterais de 42px", "P3"),
    "viewport": ("Responsividade", "Meta viewport", "P2"),
    "media_query": ("Responsividade", "Media query para telas pequenas", "P2"),
    "darkmode": ("Dark Mode", "Suporte a Dark Mode declarado", "P2"),
    "gif_tamanho": ("GIF", "GIF até 700px e até 10 segundos", "P2"),
    "gif_ocupa_tudo": ("GIF", "GIF não ocupa toda a peça", "P1"),
    "qr_tamanho": ("QR Code", "QR Code com mínimo de 130x130px", "P2"),
    "qr_fundo": ("QR Code", "QR Code com fundo branco e borda de 12px", "P2"),
    "icone_tamanho": ("Ícones", "Ícones com área mínima de 40x40px", "P2"),
    "segmento_misturado": ("Segmentação", "Um único segmento na peça", "P1"),
    "segmento_coerencia": ("Segmentação", "Telefones e domínio do segmento", "P1"),
    "invest_disclaimer": ("Investimentos", "Disclaimer de investimentos", "P0"),
    "invest_suitability": ("Investimentos", "Suitability", "P1"),
    "invest_risco": ("Investimentos", "Aviso de risco", "P1"),
    "invest_responsabilidade": ("Investimentos", "Responsabilidade do investidor", "P1"),
    "invest_fgc": ("Investimentos", "FGC quando aplicável", "P1"),
    # --- regras do Quality Gate do Workbench (mesmo critério e mesmo rigor: bloqueador = P0, alerta = P2)
    "view_email_url": ("SFMC", "Link “ver no navegador” (%%view_email_url%%)", "P0"),
    "script_tag": ("Código", "Sem tag <script> (exceto AMPScript)", "P0"),
    "amp_fechamento": ("SFMC", "Blocos AMPScript fechados (%%[ ]%% e %%= =%%)", "P0"),
    "html_tamanho": ("Código", f"HTML até {LIMITE_HTML_KB} KB (corte do Gmail)", "P2"),
    "link_aninhado": ("Links", "Sem link dentro de outro link", "P2"),
    "doctype": ("Código", "DOCTYPE presente", "P2"),
}

# Ajuste aqui. Valores: "P0", "P1", "P2", "P3" ou "off".
NIVEIS = {rid: dados[2] for rid, dados in CATALOGO.items()}

NAO_AUTOMATIZAVEIS = [
    "Estrutura Header/Body/Footer, grid de 8 colunas e gutter de 24px (precisa de olho)",
    "Tipografia do Header: título 28px, subtítulo 26px, campo dinâmico 22px",
    "Clareza, objetividade e poder de abertura do assunto e do pré-header",
    "Se o pré-header faz sentido com o assunto (só conferimos repetição)",
    "URL funcional, página existente e redirecionamento correto (exigem rede: use “Testar links online”, opcional)",
    "Dark Mode: contraste, logo visível e hierarquia (só conferimos se há suporte declarado)",
    "LGPD: base legal, transparência e comunicação permitida (decisão da campanha)",
]

# ------------------------------------------------------------- segmentação
SEGMENTOS = {
    "Prime": r"bradesco\s+prime|\bprime\b",
    "Exclusive": r"bradesco\s+exclusive|\bexclusive\b",
    "Empresas e Negócios": r"bradesco\s+empresas|empresas\s+e\s+neg[óo]cios|\bmei\b",
    "Corporate": r"bradesco\s+corporate|\bcorporate\b",
    "Global Private Bank": r"global\s+private\s+bank",
    "Não Correntista": r"n[ãa]o\s+correntista",
    "Varejo": r"bradesco\s+varejo|\bvarejo\b",
    "Investimentos": r"bradesco\s+investimentos",
}
_RE_SEGMENTOS = {k: re.compile(v, re.IGNORECASE) for k, v in SEGMENTOS.items()}

# Preencher com os dados OFICIAIS do GUIDE para ligar a checagem de coerência:
#   "Prime": {"telefones": ["0800 000 0000"], "dominios": ["bradescoprime.com.br"]}
# Vazio = a coerência de telefone/domínio por segmento não é conferida.
SEGMENTOS_ESPERADO: dict = {}

_RE_TELEFONE = re.compile(r"\b0?800[\s.\-]?\d{3}[\s.\-]?\d{4}\b|\b\d{4}[\s.\-]?\d{4}\b")
_RE_DOMINIO = re.compile(r"\b(?:[a-z0-9\-]+\.)+(?:com\.br|com|br|net|org)\b", re.IGNORECASE)

# --------------------------------------------------------------- padrões
_RE_OPTOUT = re.compile(
    r"unsub|opt.?out|descadastr|cancel(e|ar)\s+(o\s+)?(recebimento|inscri)"
    r"|n[ãa]o\s+(desejo|quero|deseja)\s+(mais\s+)?receber|deixar\s+de\s+receber|sair\s+da\s+lista",
    re.IGNORECASE)
_RE_ANTIFRAUDE = re.compile(
    r"fraude|golpe|phishing|n[ãa]o\s+(solicit|pedi|envi)|nunca\s+(solicit|pe[çc]a)|desconfi", re.IGNORECASE)
_RE_CANAIS = re.compile(
    r"canais?\s+oficia|\bsac\b|ouvidoria|0?800[\s.\-]?\d{3}|4004|fale\s+conosco|bradesco\.com\.br|banco\.bradesco",
    re.IGNORECASE)
_RE_AUTOMATICA = re.compile(
    r"gerada\s+automaticamente|mensagem\s+autom[áa]tica|n[ãa]o\s+(responda|pode\s+ser\s+respondid)", re.IGNORECASE)

_RE_INVEST = re.compile(
    r"\bfundos\b|\bfundo\s+(de|garantidor)|investiment|wealth|\bprivate\b|\bfgc\b|renda\s+fixa"
    r"|\bcdb\b|\blci\b|\blca\b|tesouro\s+direto", re.IGNORECASE)
_RE_INVEST_DISCLAIMER = re.compile(
    r"rentabilidade\s+(passada|obtida|anterior)|n[ãa]o\s+h[áa]\s+garantia|garantia\s+de\s+(rentabilidade|resultado)"
    r"|leia\s+(o|a|as|os)\s+(regulamento|l[âa]mina|prospecto)|l[âa]mina\s+de\s+informa|material\s+publicit",
    re.IGNORECASE)
_RE_SUITABILITY = re.compile(
    r"suitability|perfil\s+(do\s+|de\s+)?investidor|adequa[çc][ãa]o\s+(ao|do)\s+perfil", re.IGNORECASE)
_RE_RISCO = re.compile(r"\brisco", re.IGNORECASE)
_RE_RESPONSABILIDADE = re.compile(
    r"responsabilidade\s+(do|de)\s+(investidor|cliente)|decis[ãa]o\s+(de\s+)?investimento"
    r"|avalie\s+(os\s+)?riscos?|investidor\s+(deve|[ée]\s+respons)", re.IGNORECASE)
_RE_FGC_APLICAVEL = re.compile(r"\bcdb\b|\blci\b|\blca\b|\brdb\b|renda\s+fixa|poupan[çc]a|dep[óo]sito", re.IGNORECASE)
_RE_FGC = re.compile(r"\bfgc\b|fundo\s+garantidor", re.IGNORECASE)

_RE_VAR_SIMPLES = re.compile(r"(?<![\]=])%%(?![\[=])([^%\[\]=\n<>]{0,60}?)(?<![\]=])%%")
_RE_GENERICO = re.compile(r"^(data|nome|campo|valor|texto|variavel|var)\d+$|^(datafim|datainicio|datainicial|datafinal)$")
_RE_GENERICO_VISIVEL = re.compile(r"\b(data\s*1|nome\s*1|data\s+fim|data\s+in[íi]cio)\b", re.IGNORECASE)
_RE_PLACEHOLDER = re.compile(r"\[[A-ZÀ-Ú][A-ZÀ-Ú _]{2,}\]|\{\{[^}]+\}\}")

_HOSTS_HTTP_OK = ("w3.org", "schemas.microsoft.com", "purl.org", "ns.adobe.com")
_PREFIXOS_LINK_OK = ("https://", "http://", "%%", "mailto:", "tel:", "sms:", "whatsapp:")
_TAGS_SEM_TEXTO = {"script", "style", "head", "title", "meta", "link", "noscript"}


# ------------------------------------------------------------------ resultado
@dataclass
class Achado:
    prioridade: str
    regra: str
    grupo: str
    titulo: str
    detalhe: str
    locais: list = field(default_factory=list)   # [{linha, coluna, tamanho, trecho}] no HTML


@dataclass
class ResultadoGuide:
    achados: list = field(default_factory=list)
    atendidas: list = field(default_factory=list)       # títulos
    nao_conferidas: list = field(default_factory=list)  # (título, motivo)
    segmento: str = ""

    def por_prioridade(self, p: str) -> list:
        return [a for a in self.achados if a.prioridade == p]

    @property
    def bloqueios(self) -> list:
        return self.por_prioridade("P0")

    @property
    def criticos(self) -> list:
        return self.por_prioridade("P1")


class _Linhas:
    """
    Posição no texto -> linha e coluna, com a conta do editor do Workbench
    (linha 1 é a primeira; a coluna conta UTF-16, como o CodeMirror).
    """

    def __init__(self, texto: str):
        self.texto = texto
        self.inicios = [0] + [m.end() for m in re.finditer(r"\n", texto)]

    def _linha(self, indice: int) -> int:
        return bisect.bisect_right(self.inicios, max(indice, 0))

    def _coluna16(self, linha: int, indice: int) -> int:
        prefixo = self.texto[self.inicios[linha - 1]:indice]
        return len(prefixo.encode("utf-16-le")) // 2

    def por_indice(self, indice: int, tamanho: int = 0, trecho: str = "") -> dict:
        indice = min(max(indice, 0), len(self.texto))
        linha = self._linha(indice)
        pedaco = self.texto[indice:indice + tamanho]
        return {
            "linha": linha, "coluna": self._coluna16(linha, indice),
            "tamanho": len(pedaco.encode("utf-16-le")) // 2,
            "trecho": _trecho(trecho or pedaco, 80),
        }

    def por_tag(self, tag, trecho: str = "") -> dict | None:
        """Início da tag no HTML (o BeautifulSoup guarda linha e coluna de onde ela abre)."""
        numero, coluna = getattr(tag, "sourceline", None), getattr(tag, "sourcepos", None)
        if not numero or numero > len(self.inicios):
            return None
        indice = self.inicios[numero - 1] + (coluna or 0)
        if self.texto[indice:indice + 1] != "<":
            return {"linha": numero, "coluna": 0, "tamanho": 0, "trecho": _trecho(trecho, 80)}
        fim, aspas = indice + 1, ""
        while fim < min(len(self.texto), indice + 600):   # abertura da tag: o ">" fora das aspas
            c = self.texto[fim]
            if aspas:
                aspas = "" if c == aspas else aspas
            elif c in "\"'":
                aspas = c
            elif c == ">":
                fim += 1
                break
            fim += 1
        return self.por_indice(indice, fim - indice, trecho)

    def achar(self, trecho: str) -> dict | None:
        """Primeira vez que o trecho aparece no código (espaços e maiúsculas não importam)."""
        palavras = (trecho or "").split()
        if not palavras:
            return None
        achou = re.search(r"\s+".join(re.escape(p) for p in palavras), self.texto, re.IGNORECASE)
        return self.por_indice(achou.start(), achou.end() - achou.start()) if achou else None


def _limpar_locais(locais) -> list:
    vistos, saida = set(), []
    for local in locais or []:
        if not local:
            continue
        chave = (local["linha"], local["coluna"])
        if chave not in vistos:
            vistos.add(chave)
            saida.append(local)
    return sorted(saida, key=lambda l: (l["linha"], l["coluna"]))[:MAX_LOCAIS]


def formatar_locais(locais, quantos: int = 6) -> str:
    """"linha 12 · linha 40, col. 310 · +2" — para relatório e textos."""
    if not locais:
        return ""
    partes = []
    for l in locais[:quantos]:
        partes.append(f"linha {l['linha']}" + (f", col. {l['coluna'] + 1}" if l.get("coluna", 0) > 80 else ""))
    extra = f" · +{len(locais) - quantos}" if len(locais) > quantos else ""
    return " · ".join(partes) + extra


class _Ctx:
    def __init__(self, codigo: str = ""):
        self.achados, self.checadas, self.puladas = [], [], []
        self.lin = _Linhas(codigo)
        self.imgs_por_nome = {}

    def nivel(self, rid):
        return NIVEIS.get(rid, CATALOGO[rid][2])

    def checar(self, rid) -> bool:
        if self.nivel(rid) == "off":
            return False
        if rid not in self.checadas:
            self.checadas.append(rid)
        return True

    def falha(self, rid, detalhe, locais=None):
        nivel = self.nivel(rid)
        if nivel == "off":
            return
        grupo, titulo, _ = CATALOGO[rid]
        self.achados.append(Achado(nivel, rid, grupo, titulo, detalhe, _limpar_locais(locais)))

    def pular(self, rid, motivo):
        if self.nivel(rid) != "off" and rid not in [p[0] for p in self.puladas]:
            self.puladas.append((rid, motivo))
            if rid in self.checadas:
                self.checadas.remove(rid)

    def resultado(self) -> ResultadoGuide:
        com_achado = {a.regra for a in self.achados}
        puladas = [p[0] for p in self.puladas]
        return ResultadoGuide(
            achados=sorted(self.achados, key=lambda a: a.prioridade),
            atendidas=[CATALOGO[r][1] for r in self.checadas if r not in com_achado and r not in puladas],
            nao_conferidas=[(CATALOGO[r][1], m) for r, m in self.puladas],
        )


# ----------------------------------------------------------------- utilidades
def _norm(texto: str) -> str:
    sem = unicodedata.normalize("NFD", texto or "")
    return "".join(c for c in sem if unicodedata.category(c) != "Mn").lower()


def _estilo(tag) -> dict:
    saida = {}
    for parte in (tag.get("style") or "").split(";"):
        if ":" in parte:
            k, v = parte.split(":", 1)
            saida[k.strip().lower()] = v.strip().lower()
    return saida


def _px(valor):
    if valor is None:
        return None
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*(px|pt)?\s*$", str(valor).lower())
    if not m:
        return None
    n = float(m.group(1))
    return n * 4 / 3 if m.group(2) == "pt" else n


def _regras_css(soup) -> list:
    css = "\n".join(s.get_text() for s in soup.find_all("style"))
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    anterior = None
    while anterior != css:   # tira @media e afins (blocos aninhados)
        anterior = css
        css = re.sub(r"@[^{};]+\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}", "", css)
    saida = []
    for seletor, corpo in re.findall(r"([^{}]+)\{([^{}]*)\}", css):
        props = {}
        for parte in corpo.split(";"):
            if ":" in parte:
                k, v = parte.split(":", 1)
                props[k.strip().lower()] = v.strip().lower()
        for s in seletor.split(","):
            s = s.strip().lower()
            if s and not re.search(r"[\s>+~:\[]", s):
                saida.append((s, props))
    return saida


def _casa(seletor: str, tag) -> bool:
    if seletor == "*":
        return True
    m = re.match(r"^([a-z0-9]*)((?:\.[\w\-]+)*)(#[\w\-]+)?$", seletor)
    if not m:
        return False
    nome, classes, ident = m.groups()
    if nome and nome != tag.name:
        return False
    if classes:
        tem = tag.get("class") or []
        if any(c not in [x.lower() for x in tem] for c in classes.strip(".").split(".")):
            return False
    if ident and (tag.get("id") or "").lower() != ident[1:]:
        return False
    return True


def _efetivo(tag, prop: str, css: list):
    """Valor da propriedade herdado na cadeia de ancestrais (inline vence a folha)."""
    no = tag
    while isinstance(no, Tag):
        valor = _estilo(no).get(prop)
        if valor is None:
            for seletor, props in css:
                if prop in props and _casa(seletor, no):
                    valor = props[prop]
        if valor is None and prop == "font-family" and no.name == "font" and no.get("face"):
            valor = no.get("face").lower()
        if valor and valor != "inherit":
            return valor
        no = no.parent
    return None


def _primeira_fonte(valor) -> str:
    return (valor or "").split(",")[0].strip(" '\"").lower()


def _linha_altura_px(valor, tamanho):
    if valor is None or valor == "normal":
        return None
    px = _px(valor)
    if px is not None:
        return px
    try:
        if valor.endswith("%"):
            return float(valor[:-1]) / 100 * tamanho if tamanho else None
        return float(valor) * tamanho if tamanho else None
    except ValueError:
        return None


def _largura_declarada(tag):
    est = _estilo(tag)
    for bruto in (est.get("width"), est.get("max-width"), tag.get("width")):
        px = _px(bruto)
        if px is not None:
            return px
    return None


def _trecho(texto: str, n: int = 50) -> str:
    texto = " ".join((texto or "").split())
    return texto if len(texto) <= n else texto[:n - 1] + "…"


def _lista(itens, n=4) -> str:
    itens = list(dict.fromkeys(itens))
    extra = f" (+{len(itens) - n})" if len(itens) > n else ""
    return "; ".join(itens[:n]) + extra


def ler_codigo(caminho: str) -> str:
    """
    O HTML do pacote como texto, do mesmo jeito para o GUIDE e para o botão
    "Abrir no Workbench": assim a linha que o GUIDE aponta é a linha que o editor mostra.
    UTF-8 (com ou sem BOM) ou, se não for, Windows-1252.
    """
    with open(caminho, "rb") as f:
        bruto = f.read()
    try:
        return bruto.decode("utf-8-sig")
    except UnicodeDecodeError:
        return bruto.decode("cp1252", errors="replace")


# ---------------------------------------------------------------- verificação
def analisar(codigo_html: str, leitura_html, paragrafos_docx=(), assunto: str = "",
             pre_header: str = "", pasta_imagens: str = "", nome_pasta: str = "") -> ResultadoGuide:
    from .html_parser import _esta_oculto, _localizar_arquivo

    codigo_html = (codigo_html or "").lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    ctx = _Ctx(codigo_html)
    soup = BeautifulSoup(codigo_html, "html.parser")
    for img in soup.find_all("img"):
        nome_img = (img.get("src") or "").split("?")[0].split("/")[-1].lower()
        if nome_img:
            ctx.imgs_por_nome.setdefault(nome_img, img)
    css = _regras_css(soup)
    corpo = soup.body or soup
    ordem = {id(n): i for i, n in enumerate(corpo.descendants)}
    total = max(len(ordem), 1)
    posicao = lambda tag: ordem.get(id(tag), 0) / total
    no_footer = lambda tag: posicao(tag) >= RODAPE_A_PARTIR_DE

    fita = list(getattr(leitura_html, "fita", []) or [])
    docx = "\n".join(paragrafos_docx or [])
    texto_html = "\n".join(b.conteudo for b in fita if b.conteudo and not b.oculto)
    corpus = texto_html + "\n" + docx
    incompleta = any(b.tipo == "imagem" and not b.ocr_lido and not b.oculto for b in fita)
    motivo_ocr = "há imagens cujo texto não foi lido; o texto delas pode ter o que falta"

    textos = []   # (tag pai, texto)
    for no in corpo.descendants:
        if isinstance(no, NavigableString) and not isinstance(no, Comment):
            pai = no.parent
            if pai is None or pai.name in _TAGS_SEM_TEXTO or not no.strip():
                continue
            if _esta_oculto(pai):
                continue
            textos.append((pai, " ".join(str(no).split())))

    def exigir(rid, padrao, onde, detalhe, motivo_pular=motivo_ocr):
        if not ctx.checar(rid):
            return
        if padrao.search(onde):
            return
        if incompleta:
            ctx.pular(rid, motivo_pular)
        else:
            ctx.falha(rid, detalhe)

    _assunto(ctx, assunto, pre_header)
    _codigo(ctx, soup, codigo_html)
    _texto(ctx, fita, textos, texto_html, incompleta)
    _personalizacao(ctx, codigo_html, fita, docx)
    _links(ctx, soup, codigo_html, fita, _esta_oculto)
    _optout(ctx, soup, css, posicao, no_footer, _esta_oculto)

    # --- disclaimer ---
    if ctx.checar("disclaimer_ausente"):
        achou = any(b.classificacao.startswith("obrigatorio:disclaimer") for b in fita) or \
            any(excecoes.classificar(p).startswith("obrigatorio:disclaimer") for p in (paragrafos_docx or []))
        if not achou:
            if incompleta:
                ctx.pular("disclaimer_ausente", motivo_ocr)
            else:
                ctx.falha("disclaimer_ausente", "nenhum trecho de disclaimer encontrado no HTML nem no CONTEUDO.docx")
    exigir("disclaimer_antifraude", _RE_ANTIFRAUDE, corpus, "não encontrei o aviso antifraude")
    exigir("disclaimer_canais", _RE_CANAIS, corpus, "não encontrei os canais oficiais de atendimento")
    exigir("disclaimer_automatica", _RE_AUTOMATICA, corpus, "não encontrei o aviso de comunicação automática")

    _footer(ctx, soup, fita, incompleta, no_footer, pasta_imagens, _localizar_arquivo, motivo_ocr)
    ctas = _ctas(ctx, soup, css)
    _tipografia(ctx, textos, css)
    _grid(ctx, soup, css)
    _responsivo(ctx, soup, codigo_html)
    _imagens_especiais(ctx, soup, leitura_html, pasta_imagens, _localizar_arquivo, fita, texto_html)
    segmento = _segmentacao(ctx, nome_pasta, assunto, corpus)
    _investimentos(ctx, corpus, incompleta, motivo_ocr)

    resultado = ctx.resultado()
    resultado.segmento = segmento
    return resultado


# --- código e SFMC (vêm do Quality Gate do Workbench) -------------------------
def _amp_sem_fechar(codigo: str) -> list:
    """(posição, abertura) de cada %%[ ou %%= que não fecha. Mesma leitura do parser do Workbench."""
    erros, i = [], 0
    while True:
        achou = re.compile(r"%%[\[=]").search(codigo, i)
        if not achou:
            return erros
        i = achou.start()
        bloco = codigo[i + 2] == "["
        fim = codigo.find("]%%" if bloco else "=%%", i + 3)
        if fim < 0:
            erros.append((i, "%%[" if bloco else "%%="))
            i += 3
        else:
            if ("%%[" if bloco else "%%=") in codigo[i + 3:fim]:    # abriu de novo antes de fechar
                erros.append((i, "%%[" if bloco else "%%="))
            i = fim + 3


def _codigo(ctx, soup, codigo):
    if ctx.checar("view_email_url") and not re.search(r"%%view_email_url%%", codigo, re.I):
        ctx.falha("view_email_url", "não encontrei %%view_email_url%%: inclua o link para ver o e-mail no navegador")

    if ctx.checar("script_tag"):
        scripts = [s for s in soup.find_all("script") if "ampscript" not in (s.get("language") or "").lower()]
        if scripts:
            ctx.falha("script_tag", f"{len(scripts)} tag(s) <script>: JavaScript não roda em e-mail e pode barrar a publicação",
                      [ctx.lin.por_tag(s) for s in scripts])

    if ctx.checar("amp_fechamento"):
        abertos = _amp_sem_fechar(codigo)
        if abertos:
            ctx.falha("amp_fechamento",
                      f"{len(abertos)} trecho(s) de AMPScript sem fechamento: feche %%[ com ]%% e %%= com =%%",
                      [ctx.lin.por_indice(i, 3, f"{abertura} sem fechar") for i, abertura in abertos])

    if ctx.checar("html_tamanho"):
        pesado = codigo.encode("utf-8")
        kb = len(pesado) / 1024
        if kb > LIMITE_HTML_KB:
            corte = len(pesado[:int(LIMITE_HTML_KB * 1024)].decode("utf-8", errors="ignore"))
            ctx.falha("html_tamanho", f"HTML com {kb:.0f} KB: acima de {LIMITE_HTML_KB} KB o Gmail corta o e-mail "
                      "e o que vem depois (rodapé, optout) some",
                      [ctx.lin.por_indice(corte, 0, "o Gmail corta daqui para baixo")])

    if ctx.checar("doctype") and not re.search(r"<!doctype", codigo, re.I):
        ctx.falha("doctype", "sem DOCTYPE: recomendado para a renderização ficar igual nos clientes de e-mail",
                  [ctx.lin.por_indice(0, 0, "início do arquivo")])


# --- assunto e pré-header ----------------------------------------------------
def _assunto(ctx, assunto, pre_header):
    if ctx.checar("assunto_rotulo") and assunto and re.match(r"\s*(assunto|subject)\s*[:\-]", assunto, re.I):
        ctx.falha("assunto_rotulo", f"o assunto começa com o rótulo: “{_trecho(assunto)}”")
    if ctx.checar("preheader_rotulo") and pre_header and re.match(
            r"\s*(pr[eé][\s\-]?header|preheader)\s*[:\-]", pre_header, re.I):
        ctx.falha("preheader_rotulo", f"o pré-header começa com o rótulo: “{_trecho(pre_header)}”")
    if ctx.checar("preheader_complementa") and assunto and pre_header:
        a, p = _norm(assunto).strip(" .!?"), _norm(pre_header).strip(" .!?")
        if a and p and (a == p or (len(p) > 8 and p in a) or (len(a) > 8 and a in p)):
            ctx.falha("preheader_complementa", "o pré-header repete o assunto em vez de complementá-lo")


# --- texto -------------------------------------------------------------------
def _texto(ctx, fita, textos, texto_html, incompleta):
    if ctx.checar("texto_limite"):
        vivo = [b.conteudo for b in fita if b.tipo == "texto" and not b.oculto and not b.classificacao]
        n = sum(len(t) for t in vivo)
        if n > MAX_TEXTO:
            ctx.falha("texto_limite", f"{n} caracteres de texto no HTML ({n - MAX_TEXTO} acima dos {MAX_TEXTO} recomendados)")
    if ctx.checar("texto_em_imagem"):
        grandes, locais = [], []
        for b in fita:
            if b.tipo == "imagem" and b.ocr_lido and not b.oculto:
                palavras = [p for p in re.findall(r"\w+", b.conteudo or "") if len(p) >= regras.TAMANHO_MINIMO_PALAVRA_IMAGEM]
                if len(palavras) >= PALAVRAS_TEXTO_EM_IMAGEM:
                    grandes.append(f"{b.referencia} ({len(palavras)} palavras)")
                    tag = ctx.imgs_por_nome.get((b.referencia or "").lower())
                    locais.append(ctx.lin.por_tag(tag) if tag is not None else None)
        if grandes:
            ctx.falha("texto_em_imagem", "bloco de texto dentro de imagem: " + _lista(grandes), locais)
    if ctx.checar("sem_texto_html"):
        tem_imagem = any(b.tipo == "imagem" and not b.oculto for b in fita)
        vivo = [b.conteudo for b in fita if b.tipo == "texto" and not b.oculto and not b.classificacao]
        if tem_imagem and sum(len(t) for t in vivo) < 40:
            ctx.falha("sem_texto_html", "a peça é praticamente só imagem: quase nenhum texto escrito no HTML")


# --- personalização ----------------------------------------------------------
def _personalizacao(ctx, codigo, fita, docx):
    if ctx.checar("var_generica"):
        achados, locais = [], []
        for m in _RE_VAR_SIMPLES.finditer(codigo or ""):
            if _RE_GENERICO.match(re.sub(r"[\s_\-]", "", _norm(m.group(1)))):
                achados.append(f"%%{m.group(1).strip()}%%")
                locais.append(ctx.lin.por_indice(m.start(), m.end() - m.start()))
        visivel = "\n".join(b.conteudo for b in fita if b.tipo == "texto" and not b.oculto) + "\n" + docx
        for m in _RE_GENERICO_VISIVEL.finditer(visivel):
            achados.append(f"“{m.group(0)}” no texto")
            locais.append(ctx.lin.achar(m.group(0)))
        if achados:
            ctx.falha("var_generica", "campo genérico: " + _lista(achados), locais)
    if ctx.checar("var_sintaxe"):
        problemas, locais = [], []
        sem_amp = re.sub(r"%%[\[=].*?[\]=]%%", "", codigo or "", flags=re.S)   # AMPScript fica de fora
        if sem_amp.count("%%") % 2:
            problemas.append("há um %% sem par")
            # mesma conta, mas sem mexer nas posições: o que não casa em par é o suspeito
            mascarado = re.sub(r"%%[\[=].*?[\]=]%%", lambda m: re.sub(r"[^\n]", " ", m.group(0)),
                               codigo or "", flags=re.S)
            resto = re.sub(r"%%[^%\n]*?%%", lambda m: " " * len(m.group(0)), mascarado)
            locais += [ctx.lin.por_indice(m.start(), 2, "%% sem par") for m in re.finditer(r"%%", resto)]
        for m in _RE_VAR_SIMPLES.finditer(codigo or ""):
            nome = m.group(1)
            if not nome.strip():
                problemas.append("variável vazia (%%%%)")
                locais.append(ctx.lin.por_indice(m.start(), m.end() - m.start()))
            elif nome != nome.strip():
                problemas.append(f"espaço dentro de %%{nome}%%")
                locais.append(ctx.lin.por_indice(m.start(), m.end() - m.start()))
        texto = "\n".join(b.conteudo for b in fita if b.tipo == "texto" and not b.oculto)
        for m in _RE_PLACEHOLDER.finditer(texto):
            problemas.append(f"placeholder sem substituir: {m.group(0)}")
            locais.append(ctx.lin.achar(m.group(0)))
        if problemas:
            ctx.falha("var_sintaxe", _lista(problemas), locais)


# --- links -------------------------------------------------------------------
def _links(ctx, soup, codigo, fita, esta_oculto):
    if ctx.checar("link_http"):
        achados, locais = [], []
        for m in re.finditer(r"http://[^\s\"'<>)\]]+", codigo or "", flags=re.I):
            url = m.group()
            host = re.sub(r"^http://", "", url, flags=re.I).split("/")[0].lower()
            if not any(host.endswith(ok) for ok in _HOSTS_HTTP_OK):
                achados.append(url[:70])
                locais.append(ctx.lin.por_indice(m.start(), len(url)))
        if achados:
            ctx.falha("link_http", "HTTP em vez de HTTPS: " + _lista(achados), locais)

    sem, invalidos, loc_sem, loc_inv = [], [], [], []
    for a in soup.find_all("a"):
        texto = a.get_text(" ", strip=True)
        if not texto and a.find("img"):
            texto = a.find("img").get("alt") or ""
        texto = _trecho(texto)
        rotulo = f"“{texto}”" if texto else "(sem texto)"
        if not a.has_attr("href"):
            if a.get("name") or (a.get("id") and not texto):
                continue
            if texto or a.find("img"):
                sem.append(f"{rotulo}: sem href")
                loc_sem.append(ctx.lin.por_tag(a))
            continue
        href = (a.get("href") or "").strip()
        baixo = href.lower()
        if href in ("", "#") or baixo.startswith("javascript:"):
            sem.append(f"{rotulo}: href “{href or 'vazio'}”")
            loc_sem.append(ctx.lin.por_tag(a))
        elif not baixo.startswith(_PREFIXOS_LINK_OK):
            invalidos.append(f"{rotulo}: {_trecho(href, 40)}")
            loc_inv.append(ctx.lin.por_tag(a))
        elif re.search(r"\s", re.sub(r"%%.*?%%", "", href, flags=re.S)):
            invalidos.append(f"{rotulo}: URL com espaço")
            loc_inv.append(ctx.lin.por_tag(a))
    for b in soup.find_all("button"):
        sem.append(f"“{_trecho(b.get_text(' ', strip=True))}”: <button> não funciona em e-mail")
        loc_sem.append(ctx.lin.por_tag(b))
    if ctx.checar("link_sem_href") and sem:
        ctx.falha("link_sem_href", _lista(sem), loc_sem)
    if ctx.checar("link_invalido") and invalidos:
        ctx.falha("link_invalido", _lista(invalidos), loc_inv)

    if ctx.checar("link_aninhado"):
        dentro = [a for a in soup.find_all("a") if a.find_parent("a") is not None]
        if dentro:
            nomes = [f"“{_trecho(a.get_text(' ', strip=True), 25) or 'sem texto'}”" for a in dentro]
            ctx.falha("link_aninhado", f"{len(dentro)} link(s) dentro de outro link: " + _lista(nomes)
                      + ". Feche cada <a> antes de abrir o próximo.", [ctx.lin.por_tag(a) for a in dentro])

    if ctx.checar("url_visivel"):
        achados, locais = [], []
        for b in fita:
            if b.tipo == "texto" and not b.oculto and (not b.classificacao or b.classificacao == "tolerado"):
                m = regras.RE_ENDERECO.search(b.conteudo)
                if m:
                    visivel = m.group().rstrip(".,;:)")
                    achados.append(_trecho(visivel, 60))
                    locais.append(ctx.lin.achar(visivel))
        if achados:
            ctx.falha("url_visivel", "URL escrita no conteúdo: " + _lista(achados), locais)


# --- optout ------------------------------------------------------------------
def _optout(ctx, soup, css, posicao, no_footer, esta_oculto):
    candidatos = []
    for a in soup.find_all("a"):
        href = a.get("href") or ""
        alias = (a.get("alias") or a.get("data-alias") or "").strip()
        texto = a.get_text(" ", strip=True) or " ".join((i.get("alt") or "") for i in a.find_all("img"))
        if alias.lower() == "unsubscribe" or _RE_OPTOUT.search(f"{href} {texto} {alias}"):
            tamanho = _px(_efetivo(a, "font-size", css))
            visivel = not esta_oculto(a) and (texto.strip() or a.find("img")) and not (tamanho is not None and tamanho < 8)
            candidatos.append({
                "a": a, "alias": alias, "texto": texto, "visivel": bool(visivel),
                "redirect": bool(re.search(r"redirectto\s*\(", href, re.I)),
                "footer": no_footer(a),
            })
    if not ctx.checar("optout_ausente"):
        return
    if not candidatos:
        ctx.falha("optout_ausente", "nenhum link de descadastro encontrado no HTML")
        for rid in ("optout_redirect", "optout_alias", "optout_footer", "optout_oculto"):
            ctx.pular(rid, "sem optout para conferir")
        return
    melhor = max(candidatos, key=lambda c: (c["footer"] + c["alias"].lower().startswith("unsub")
                                            + c["redirect"] + c["visivel"]))
    nome = f"“{_trecho(melhor['texto'], 40)}”"
    onde = [ctx.lin.por_tag(melhor["a"])]
    if ctx.checar("optout_redirect") and not melhor["redirect"]:
        ctx.falha("optout_redirect", f"o link {nome} não usa RedirectTo", onde)
    if ctx.checar("optout_alias") and melhor["alias"].lower() != "unsubscribe":
        ctx.falha("optout_alias", f"o link {nome} tem alias “{melhor['alias'] or 'vazio'}” (esperado: Unsubscribe)", onde)
    if ctx.checar("optout_footer") and not melhor["footer"]:
        ctx.falha("optout_footer", f"o link {nome} não está no Footer", onde)
    if ctx.checar("optout_oculto") and not melhor["visivel"]:
        ctx.falha("optout_oculto", f"o link {nome} está oculto, vazio ou com fonte ilegível", onde)


# --- footer ------------------------------------------------------------------
def _footer(ctx, soup, fita, incompleta, no_footer, pasta, localizar, motivo_ocr):
    logos = []
    for img in soup.find_all("img"):
        ref = f"{img.get('src') or ''} {img.get('alt') or ''}"
        if no_footer(img) and re.search(r"logo|bradesco", ref, re.I) and not re.search(r"qr", ref, re.I):
            logos.append(img)
    if ctx.checar("footer_marca"):
        inicio = int(len(fita) * RODAPE_A_PARTIR_DE)
        zona = " ".join(b.conteudo or "" for b in fita[inicio:] if not b.oculto)
        achou = bool(logos) or "bradesco" in _norm(zona)
        if not achou:
            if incompleta:
                ctx.pular("footer_marca", motivo_ocr)
            else:
                ctx.falha("footer_marca", "não encontrei a assinatura da marca (logo ou nome) no Footer")
    if ctx.checar("footer_logo"):
        if not logos:
            ctx.pular("footer_logo", "logo do Footer não identificado (nome do arquivo ou alt sem “logo”/“bradesco”)")
            return
        problemas, locais = [], []
        minimo = LARGURA_PECA_PX * LOGO_MIN_PROPORCAO_FOOTER
        for img in logos:
            nome = img.get("src") or "logo"
            largura = _largura_declarada(img)
            altura = _px(_estilo(img).get("height") or img.get("height"))
            if largura is None or altura is None:
                caminho = localizar(pasta, (nome.split("?")[0].split("/")[-1])) if pasta else None
                if caminho:
                    try:
                        from PIL import Image
                        with Image.open(caminho) as im:
                            largura = largura or im.size[0]
                            altura = altura or im.size[1]
                    except Exception:
                        pass
            if largura is not None and largura < minimo:
                problemas.append(f"{nome.split('/')[-1]}: {largura:.0f}px de largura (mínimo {minimo:.0f}px)")
                locais.append(ctx.lin.por_tag(img))
            if largura is not None and altura is not None and altura > largura:
                problemas.append(f"{nome.split('/')[-1]}: logo vertical ({largura:.0f}x{altura:.0f})")
                locais.append(ctx.lin.por_tag(img))
        if problemas:
            ctx.falha("footer_logo", _lista(problemas), locais)


# --- CTA ---------------------------------------------------------------------
def _ctas(ctx, soup, css) -> list:
    ctas = []
    for a in soup.find_all("a"):
        if _RE_OPTOUT.search(f"{a.get('href') or ''} {a.get_text(' ', strip=True)} {a.get('alias') or ''}"):
            continue
        texto = a.get_text(" ", strip=True)
        if not texto or (a.find("img") and not texto):
            continue
        est = _estilo(a)
        pai = a.parent if isinstance(a.parent, Tag) and a.parent.name == "td" else None
        est_pai = _estilo(pai) if pai else {}
        fundo_td = bool(pai and (pai.get("bgcolor") or est_pai.get("background-color") or est_pai.get("background")))
        so_ancora = bool(pai and " ".join(pai.get_text(" ", strip=True).split()) == " ".join(texto.split()))
        botao = (("background" in est or "background-color" in est) and
                 ("padding" in est or "inline-block" in est.get("display", ""))) or (fundo_td and so_ancora)
        if botao:
            ctas.append((a, pai, texto, {**est_pai, **est}))
    if ctx.checar("cta_max"):
        primeira_tag = {}
        for a, _, t, _ in ctas:
            primeira_tag.setdefault((t, a.get("href")), a)
        unicos = list(primeira_tag)
        if len(unicos) > MAX_CTAS:
            ctx.falha("cta_max", f"{len(unicos)} CTAs encontrados (máximo {MAX_CTAS}): " + _lista([f"“{_trecho(t, 25)}”" for t, _ in unicos]),
                      [ctx.lin.por_tag(primeira_tag[k]) for k in unicos[MAX_CTAS:]])
    if ctx.checar("cta_efeito"):
        achados, locais = [], []
        for a, pai, texto, est in ctas:
            bruto = ";".join(f"{k}:{v}" for k, v in est.items())
            if re.search(r"box-shadow|text-shadow|drop-shadow|gradient", bruto):
                achados.append(f"“{_trecho(texto, 25)}”")
                locais.append(ctx.lin.por_tag(a))
        if achados:
            ctx.falha("cta_efeito", "sombra ou gradiente no CTA: " + _lista(achados), locais)
    if ctx.checar("cta_medidas"):
        achados, locais = [], []
        for a, pai, texto, est in ctas:
            nome = f"“{_trecho(texto, 25)}”"
            antes = len(achados)
            tam = _px(_efetivo(a, "font-size", css))
            if tam is not None and tam != CTA_FONTE_PX:
                achados.append(f"{nome}: fonte {tam:g}px (esperado {CTA_FONTE_PX}px)")
            vert, lat = _padding(est)
            if vert is not None and vert != CTA_PADDING_VERTICAL_PX:
                achados.append(f"{nome}: padding vertical {vert:g}px (esperado {CTA_PADDING_VERTICAL_PX}px)")
            if lat is not None and lat != CTA_PADDING_LATERAL_PX:
                achados.append(f"{nome}: padding lateral {lat:g}px (esperado {CTA_PADDING_LATERAL_PX}px)")
            alt = _px(est.get("height") or (pai.get("height") if pai else None) or a.get("height"))
            if alt is not None and alt != CTA_ALTURA_PX:
                achados.append(f"{nome}: altura {alt:g}px (esperado {CTA_ALTURA_PX}px)")
            if len(achados) > antes:
                locais.append(ctx.lin.por_tag(a))
        if achados:
            ctx.falha("cta_medidas", _lista(achados, 5), locais)
    return ctas


def _padding(est: dict):
    vert = lat = None
    p = est.get("padding")
    if p:
        v = [_px(x) for x in p.split()]
        if v and None not in v:
            if len(v) == 1:
                vert = lat = v[0]
            elif len(v) == 2:
                vert, lat = v
            elif len(v) == 3:
                vert, lat = (v[0] if v[0] == v[2] else None), v[1]
            else:
                vert = v[0] if v[0] == v[2] else None
                lat = v[1] if v[1] == v[3] else None
    for chave, alvo in (("padding-top", "v"), ("padding-bottom", "v"), ("padding-left", "l"), ("padding-right", "l")):
        if chave in est and _px(est[chave]) is not None:
            if alvo == "v":
                vert = _px(est[chave])
            else:
                lat = _px(est[chave])
    return vert, lat


# --- tipografia --------------------------------------------------------------
def _tipografia(ctx, textos, css):
    if not textos:
        return
    fora, sem_fonte, primeiro_sem_fonte = {}, 0, None
    tamanhos, pequenos, apertadas = Counter(), [], []
    onde_tamanho, loc_pequenos, loc_apertadas = {}, [], []
    for pai, texto in textos:
        fam = _primeira_fonte(_efetivo(pai, "font-family", css))
        if not fam:
            sem_fonte += 1
            primeiro_sem_fonte = primeiro_sem_fonte or pai
        elif fam != "verdana":
            fora.setdefault(fam, (texto, pai))
        tam = _px(_efetivo(pai, "font-size", css))
        if tam is not None:
            if tam < LEGENDA_MIN_PX:
                pequenos.append(f"{tam:g}px em “{_trecho(texto, 25)}”")
                loc_pequenos.append(ctx.lin.por_tag(pai))
            elif tam > LEGENDA_MIN_PX:      # até 14px é legenda/rodapé, não corpo
                tamanhos[tam] += len(texto)
                onde_tamanho.setdefault(tam, pai)
            alt = _linha_altura_px(_efetivo(pai, "line-height", css), tam)
            if alt is not None and alt < ENTRELINHA_MIN_PX:
                apertadas.append(f"{alt:g}px em “{_trecho(texto, 25)}”")
                loc_apertadas.append(ctx.lin.por_tag(pai))
    if ctx.checar("fonte_verdana"):
        partes = [f"{f} (“{_trecho(t, 20)}”)" for f, (t, _) in fora.items()]
        locais = [ctx.lin.por_tag(p) for _, p in fora.values()]
        if sem_fonte:
            partes.append(f"{sem_fonte} trecho(s) sem fonte declarada")
            locais.append(ctx.lin.por_tag(primeiro_sem_fonte))
        if partes:
            ctx.falha("fonte_verdana", "fora do Verdana: " + _lista(partes), locais)
    if ctx.checar("fonte_corpo") and tamanhos:
        moda = tamanhos.most_common(1)[0][0]
        if not CORPO_MIN_PX <= moda <= CORPO_MAX_PX:
            ctx.falha("fonte_corpo", f"o corpo do texto usa {moda:g}px (esperado de {CORPO_MIN_PX}px a {CORPO_MAX_PX}px)",
                      [ctx.lin.por_tag(onde_tamanho[moda])])
    if ctx.checar("fonte_legenda") and pequenos:
        ctx.falha("fonte_legenda", f"abaixo de {LEGENDA_MIN_PX}px: " + _lista(pequenos), loc_pequenos)
    if ctx.checar("entrelinha") and apertadas:
        ctx.falha("entrelinha", f"entrelinha abaixo de {ENTRELINHA_MIN_PX}px: " + _lista(apertadas), loc_apertadas)


# --- grid, responsividade, dark mode -----------------------------------------
def _grid(ctx, soup, css):
    larguras, tabela_da_largura = [], {}
    for t in soup.find_all("table"):
        w = _largura_declarada(t)
        if w is not None and w >= 400:
            larguras.append(w)
            tabela_da_largura.setdefault(w, t)
    if ctx.checar("grid_largura"):
        if not larguras:
            primeira = soup.find("table")
            ctx.falha("grid_largura", f"nenhuma tabela com largura fixa em px (esperado {LARGURA_PECA_PX}px)",
                      [ctx.lin.por_tag(primeira)] if primeira is not None else [])
        elif max(larguras) != LARGURA_PECA_PX:
            ctx.falha("grid_largura", f"largura total de {max(larguras):g}px (esperado {LARGURA_PECA_PX}px)",
                      [ctx.lin.por_tag(tabela_da_largura[max(larguras)])])
    if ctx.checar("grid_margem"):
        miolo = LARGURA_PECA_PX - 2 * MARGEM_LATERAL_PX
        achou = any(w == miolo for w in larguras) or any(
            re.search(rf"padding[^;]*\b{MARGEM_LATERAL_PX}px", ";".join(f"{k}:{v}" for k, v in _estilo(t).items()))
            for t in soup.find_all(["td", "table", "div"]))
        if not achou:
            ctx.falha("grid_margem", f"não encontrei margem lateral de {MARGEM_LATERAL_PX}px (padding de {MARGEM_LATERAL_PX}px ou miolo de {miolo}px)")


def _onde_inserir(ctx, soup) -> list:
    """Para o que está faltando: o <head>, que é onde entra (ou o começo do arquivo)."""
    head = soup.find("head")
    local = ctx.lin.por_tag(head, "insira dentro do <head>") if head is not None else None
    return [local or ctx.lin.por_indice(0, 0, "início do arquivo")]


def _responsivo(ctx, soup, codigo):
    if ctx.checar("viewport") and not soup.find("meta", attrs={"name": re.compile("^viewport$", re.I)}):
        ctx.falha("viewport", "falta <meta name=\"viewport\">", _onde_inserir(ctx, soup))
    if ctx.checar("media_query") and not re.search(r"@media[^{]*\(\s*(max|min)-(device-)?width", codigo or "", re.I):
        ctx.falha("media_query", "nenhuma media query para telas pequenas", _onde_inserir(ctx, soup))
    if ctx.checar("darkmode"):
        meta = soup.find("meta", attrs={"name": re.compile("color-scheme", re.I)})
        if not meta and not re.search(r"prefers-color-scheme", codigo or "", re.I):
            ctx.falha("darkmode", "sem <meta name=\"color-scheme\"> e sem @media (prefers-color-scheme: dark)",
                      _onde_inserir(ctx, soup))


# --- GIF, QR Code e ícones ---------------------------------------------------
def _imagens_especiais(ctx, soup, leitura, pasta, localizar, fita, texto_html):
    try:
        from PIL import Image
    except Exception:
        for rid in ("gif_tamanho", "gif_ocupa_tudo", "qr_tamanho", "qr_fundo", "icone_tamanho"):
            ctx.pular(rid, "Pillow não está instalado")
        return

    def abrir(nome):
        caminho = localizar(pasta, nome) if pasta else None
        if not caminho:
            return None
        try:
            return Image.open(caminho)
        except Exception:
            return None

    gifs, outras, alturas_gif, alturas_total = [], 0, 0, 0
    qrs, icones, gif_tags = [], [], []
    for img in soup.find_all("img"):
        src = (img.get("src") or "").split("?")[0]
        nome = src.split("/")[-1]
        if not nome:
            continue
        ref = f"{nome} {img.get('alt') or ''}"
        declarada = _largura_declarada(img)
        if nome.lower().endswith(".gif"):
            gifs.append(nome)
            gif_tags.append(img)
        if re.search(r"qr", ref, re.I):
            qrs.append((nome, declarada, img))
        elif re.search(r"[íi]cone|\bicon", ref, re.I) and not re.search(r"favicon", ref, re.I):
            icones.append((nome, declarada, _px(_estilo(img).get("height") or img.get("height")), img))

    if gifs and (ctx.checar("gif_tamanho") or ctx.checar("gif_ocupa_tudo")):
        achados, locais_gif, altura_gifs, altura_total = [], [], 0, 0
        for img in soup.find_all("img"):
            nome = (img.get("src") or "").split("?")[0].split("/")[-1]
            im = abrir(nome) if nome else None
            if im is None:
                continue
            with im:
                h = im.size[1]
                altura_total += h
                if nome.lower().endswith(".gif"):
                    altura_gifs += h
                    if im.size[0] > GIF_MAX_LARGURA_PX:
                        achados.append(f"{nome}: {im.size[0]}px de largura (máximo {GIF_MAX_LARGURA_PX}px)")
                        locais_gif.append(ctx.lin.por_tag(img))
                    try:
                        segundos = sum(
                            (im.seek(i) or im.info.get("duration", 0)) for i in range(getattr(im, "n_frames", 1))) / 1000
                        if segundos > GIF_MAX_SEGUNDOS:
                            achados.append(f"{nome}: {segundos:.1f}s (máximo {GIF_MAX_SEGUNDOS}s)")
                            locais_gif.append(ctx.lin.por_tag(img))
                    except Exception:
                        pass
        if achados:
            ctx.falha("gif_tamanho", _lista(achados), locais_gif)
        if altura_total and altura_gifs / altura_total >= 0.7:
            ctx.falha("gif_ocupa_tudo", "o GIF ocupa praticamente toda a peça", [ctx.lin.por_tag(t) for t in gif_tags])

    for nome, declarada, tag_qr in qrs:
        im = abrir(nome)
        if im is None:
            ctx.pular("qr_tamanho", f"arquivo do QR Code ({nome}) não encontrado na pasta")
            ctx.pular("qr_fundo", f"arquivo do QR Code ({nome}) não encontrado na pasta")
            continue
        with im:
            w, h = im.size
            lado = min(declarada or w, w, h)
            if ctx.checar("qr_tamanho") and lado < QR_MIN_PX:
                ctx.falha("qr_tamanho", f"{nome}: {lado:g}px (mínimo {QR_MIN_PX}x{QR_MIN_PX}px)", [ctx.lin.por_tag(tag_qr)])
            if ctx.checar("qr_fundo"):
                rgba = im.convert("RGBA")
                borda = max(1, min(QR_BORDA_PX, w // 10, h // 10))
                pixels = []
                for caixa in ((0, 0, w, borda), (0, h - borda, w, h), (0, 0, borda, h), (w - borda, 0, w, h)):
                    pixels += list(rgba.crop(caixa).getdata())
                brancos = sum(1 for r, g, b, a in pixels if a == 255 and r >= 240 and g >= 240 and b >= 240)
                if brancos / len(pixels) < 0.98:
                    ctx.falha("qr_fundo", f"{nome}: a borda de proteção de {QR_BORDA_PX}px não é toda branca (fundo colorido ou transparente)",
                              [ctx.lin.por_tag(tag_qr)])

    if icones and ctx.checar("icone_tamanho"):
        achados, locais_ic = [], []
        for nome, larg, alt, tag_ic in icones:
            im = abrir(nome)
            tw, th = larg, alt
            if im is not None:
                with im:
                    tw, th = tw or im.size[0], th or im.size[1]
            if (tw is not None and tw < ICONE_MIN_PX) or (th is not None and th < ICONE_MIN_PX):
                achados.append(f"{nome}: {tw or '?'}x{th or '?'}px (mínimo {ICONE_MIN_PX}x{ICONE_MIN_PX}px)")
                locais_ic.append(ctx.lin.por_tag(tag_ic))
        if achados:
            ctx.falha("icone_tamanho", _lista(achados), locais_ic)


# --- segmentação -------------------------------------------------------------
def _segmentacao(ctx, nome_pasta, assunto, corpus) -> str:
    base = f"{nome_pasta}\n{assunto}\n{corpus}"
    achados = [s for s, rx in _RE_SEGMENTOS.items() if rx.search(base)]
    exclusivos = [s for s in achados if s != "Investimentos"]
    if ctx.checar("segmento_misturado") and len(exclusivos) > 1:
        ctx.falha("segmento_misturado", "a peça cita mais de um segmento: " + ", ".join(exclusivos)
                  + ". Confirme logo, footer, canais e disclaimer.")
    segmento = " + ".join(achados)
    unico = exclusivos[0] if len(exclusivos) == 1 else ""
    esperado = SEGMENTOS_ESPERADO.get(unico) if unico else None
    if not esperado:
        if ctx.nivel("segmento_coerencia") != "off":
            ctx.pular("segmento_coerencia",
                      "tabela SEGMENTOS_ESPERADO (telefones e domínios oficiais) ainda não preenchida em validador/guide.py"
                      if SEGMENTOS_ESPERADO == {} else "segmento não identificado com clareza")
        return segmento
    if ctx.checar("segmento_coerencia"):
        achados_c, locais_c = [], []
        permitidos = {re.sub(r"\D", "", t) for t in esperado.get("telefones", [])}
        if permitidos:
            for m in _RE_TELEFONE.finditer(corpus):
                digitos = re.sub(r"\D", "", m.group())
                if digitos not in permitidos:
                    achados_c.append(f"telefone {m.group().strip()}")
                    locais_c.append(ctx.lin.achar(m.group().strip()))
        dominios = [d.lower() for d in esperado.get("dominios", [])]
        if dominios:
            for m in _RE_DOMINIO.finditer(corpus):
                host = m.group().lower()
                if not any(host == d or host.endswith("." + d) for d in dominios):
                    achados_c.append(f"domínio {host}")
                    locais_c.append(ctx.lin.achar(host))
        if achados_c:
            ctx.falha("segmento_coerencia", f"fora do padrão de {unico}: " + _lista(achados_c), locais_c)
    return segmento


# --- investimentos -----------------------------------------------------------
def _investimentos(ctx, corpus, incompleta, motivo):
    if not _RE_INVEST.search(corpus):
        return
    regras_inv = [
        ("invest_disclaimer", _RE_INVEST_DISCLAIMER, "campanha de investimento sem o disclaimer de investimentos (rentabilidade passada, regulamento/lâmina…)"),
        ("invest_suitability", _RE_SUITABILITY, "não encontrei menção a suitability / perfil de investidor"),
        ("invest_risco", _RE_RISCO, "não encontrei o aviso de risco"),
        ("invest_responsabilidade", _RE_RESPONSABILIDADE, "não encontrei a responsabilidade do investidor"),
    ]
    if _RE_FGC_APLICAVEL.search(corpus):
        regras_inv.append(("invest_fgc", _RE_FGC, "produto que pede menção ao FGC, e ela não aparece"))
    for rid, padrao, detalhe in regras_inv:
        if not ctx.checar(rid) or padrao.search(corpus):
            continue
        if incompleta:
            ctx.pular(rid, motivo)
        else:
            ctx.falha(rid, detalhe)
