@echo off
REM ============================================================================
REM Verificador de Validade de Pastas — iniciar.bat
REM
REM Duplo-clique neste arquivo para abrir o programa. Na primeira vez, ele
REM prepara tudo sozinho (cria o ambiente Python e instala o Flask); nas
REM próximas, só abre. Não precisa saber o que é "venv" ou "pip" para usar.
REM ============================================================================

setlocal enabledelayedexpansion
title Verificador de Validade de Pastas

REM Garante que estamos na pasta onde este .bat está, não importa de onde
REM foi clicado (área de trabalho, atalho, etc.).
set "PASTA_DO_PROGRAMA=%~dp0"
cd /d "%PASTA_DO_PROGRAMA%"

REM --- 1. Confere se existe Python instalado nesta máquina ------------------
where python >nul 2>nul
if errorlevel 1 (
    echo(
    echo   Nao foi encontrado o Python nesta maquina.
    echo(
    echo   Instale o Python em https://www.python.org/downloads/
    echo   e marque a opcao "Add Python to PATH" durante a instalacao.
    echo   Depois, clique de novo neste arquivo.
    echo(
    pause
    exit /b 1
)

REM --- 2. Primeira vez: cria o ambiente e instala as dependencias -----------
if not exist "venv\Scripts\python.exe" (
    echo(
    echo   Preparando o programa pela primeira vez, aguarde um instante...
    echo(

    python -m venv venv
    if errorlevel 1 (
        echo(
        echo   Nao foi possivel preparar o programa ^(erro ao criar o ambiente^).
        echo   Copie a mensagem acima e envie para quem criou o programa.
        echo(
        pause
        exit /b 1
    )

    call venv\Scripts\activate.bat
    python -m pip install --upgrade pip --quiet
    pip install -r requirements.txt
    if errorlevel 1 (
        echo(
        echo   Nao foi possivel instalar as dependencias.
        echo   Verifique se esta maquina tem acesso a internet e tente de novo.
        echo(
        pause
        exit /b 1
    )

    echo(
    echo   Tudo pronto! Abrindo o programa...
    echo(
) else (
    call venv\Scripts\activate.bat
)

REM --- 3. Abre o navegador sozinho, um instante depois do servidor subir ----
REM O "timeout" roda em uma janela separada, sem travar o "python app.py"
REM logo abaixo, que precisa continuar rodando enquanto o programa é usado.
start "" cmd /c "timeout /t 2 /nobreak >nul & start "" http://127.0.0.1:5000"

echo(
echo   ==========================================================
echo    O programa esta rodando. O navegador vai abrir sozinho.
echo(
echo    NAO FECHE esta janela enquanto estiver usando o programa
echo    — fechar esta janela desliga o programa.
echo(
echo    Para encerrar: feche esta janela, ou clique aqui dentro
echo    e pressione Ctrl+C.
echo   ==========================================================
echo(

python app.py

echo(
echo   O programa foi encerrado.
pause
