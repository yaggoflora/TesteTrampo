@echo off
REM ============================================================================
REM Verificador de Validade de Pastas — gerar_executavel.bat
REM
REM Este script NAO e para o time usar no dia a dia. E para RODAR UMA VEZ,
REM na sua maquina (a que ja tem Python), para gerar um arquivo .exe pronto.
REM
REM Depois de pronto, esse .exe pode ser copiado para a maquina de qualquer
REM colega — mesmo quem NAO tem Python, VSCode ou qualquer coisa de
REM programacao instalada. E so copiar o arquivo e dar dois cliques.
REM ============================================================================

setlocal enabledelayedexpansion
title Gerando o executavel do Verificador de Validade

set "PASTA_DO_PROGRAMA=%~dp0"
cd /d "%PASTA_DO_PROGRAMA%"

where python >nul 2>nul
if errorlevel 1 (
    echo(
    echo   Este script precisa do Python instalado NESTA maquina para gerar
    echo   o executavel ^(so aqui, uma vez^). Instale em
    echo   https://www.python.org/downloads/ marcando "Add Python to PATH".
    echo(
    pause
    exit /b 1
)

echo(
echo   Preparando o ambiente...
echo(

if not exist "venv\Scripts\python.exe" (
    python -m venv venv
)
call venv\Scripts\activate.bat

python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
pip install pyinstaller --quiet
if errorlevel 1 (
    echo(
    echo   Nao foi possivel instalar o PyInstaller. Verifique a conexao com
    echo   a internet e tente de novo.
    echo(
    pause
    exit /b 1
)

echo(
echo   Gerando o executavel — isso pode levar alguns minutos na primeira vez.
echo(

REM --onefile:  tudo (Python + Flask + o programa) vira UM arquivo .exe so,
REM             o mais facil de copiar e distribuir para o time.
REM --add-data: inclui a tela (template) e o visual (static) dentro do .exe —
REM             sem isso, o programa abriria em branco, sem CSS nem JS.
REM             No Windows o separador entre origem e destino e ";".
REM --noupx:    NAO compacta o .exe com UPX. Compactar deixaria o arquivo
REM             menor, mas e exatamente o padrao que antivirus corporativos
REM             (comuns em bancos) mais associam a malware, gerando falso
REM             positivo. Sem UPX, o .exe fica maior mas passa mais tranquilo.
pyinstaller --onefile --noupx --name VerificadorDeValidade ^
    --add-data "template;template" ^
    --add-data "static;static" ^
    app.py

if not exist "dist\VerificadorDeValidade.exe" (
    echo(
    echo   Algo deu errado e o executavel nao foi gerado. Role a tela para
    echo   cima para ver a mensagem de erro do PyInstaller.
    echo(
    pause
    exit /b 1
)

echo(
echo   ==========================================================
echo    Pronto! O executavel esta em:
echo(
echo      dist\VerificadorDeValidade.exe
echo(
echo    Copie SOMENTE esse arquivo para a maquina de quem vai usar.
echo    La, a pessoa so precisa dar dois cliques — nao precisa
echo    instalar Python, nem nada de programacao.
echo(
echo    O navegador abre sozinho. Para fechar o programa, e so
echo    fechar a janela preta que aparece junto.
echo   ==========================================================
echo(
pause
