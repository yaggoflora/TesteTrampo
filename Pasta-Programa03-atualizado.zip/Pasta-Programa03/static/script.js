/* ==========================================================================
   Validade de Pastas — interface

   O backend faz a varredura e devolve a lista pronta. Tudo aqui é
   apresentação: filtrar, ordenar e exportar o que já veio.

     1. Estado           5. Filtros e ordenação
     2. Elementos        6. Lista
     3. Canais           7. Exportações
     4. Busca            8. Envio para Descontinuadas
                         9. Avisos, atalhos e utilidades
   ========================================================================== */

'use strict';

// ==========================================================================
// 1. Estado
// ==========================================================================

let ultimosResultados = [];
let ultimosAvisos = [];
let resumoCanais = {};

// Caminho realmente pesquisado na última busca. Vai junto no envio: o
// servidor recusa qualquer campanha que não esteja dentro dele.
let caminhoPesquisado = '';

// Recorte visível depois de todos os filtros. É o que exportação e log usam.
let resultadosVisiveis = [];

// Canal selecionado no filtro pós-busca ('todos' ou um código de canal).
let canalAtivo = 'todos';
let severidadeAtiva = 'todas';

// Caminhos que o usuário marcou como conferidos. Vive só enquanto a página
// está aberta e não influencia a busca.
const caminhosVerificados = new Set();

// Preferências lembradas entre sessões (só conveniência, nada sensível).
const CHAVE_CAMINHO = 'bradesco_validade_ultimo_caminho';
const CHAVE_CANAIS = 'bradesco_validade_canais';
const CHAVE_DESTINO = 'bradesco_validade_destino';

// ==========================================================================
// 2. Elementos
// ==========================================================================

const $ = (id) => document.getElementById(id);

const form = $('form-busca');
const inputCaminho = $('caminho');
const btnBuscar = $('btn-buscar');
const btnBuscarSpinner = btnBuscar.querySelector('.btn-spinner');
const btnBuscarLabel = btnBuscar.querySelector('.btn-label');

const statusArea = $('status-area');
const emptyState = $('empty-state');
const errorState = $('error-state');

const resultadosSection = $('resultados-section');
const resultsCount = $('results-count');
const listaResultados = $('lista-resultados');
const emptyFiltered = $('empty-filtered');
const toolbarScope = $('toolbar-scope');

const distBar = $('dist-bar');
const distLegenda = $('dist-legenda');
const btnLimparCanal = $('btn-limpar-canal');

const filtroTexto = $('filtro-texto');
const segSeveridade = $('filtro-severidade');
const filtroOrdenacao = $('filtro-ordenacao');
const btnLimparFiltros = $('btn-limpar-filtros');

const canaisChecks = Array.from(document.querySelectorAll('.canal-check'));
const btnCanaisTodos = $('btn-canais-todos');
const btnCanaisNenhum = $('btn-canais-nenhum');
const canaisNota = $('canais-nota');

const btnCopiarTodos = $('btn-copiar-todos');
const btnCopiarTodosLabel = $('btn-copiar-todos-label');
const btnExportarExcel = $('btn-exportar-excel');
const btnSalvarLog = $('btn-salvar-log');

const avisosSection = $('avisos-section');
const avisosToggle = $('avisos-toggle');
const avisosCorpo = $('avisos-corpo');
const avisosLista = $('avisos-lista');
const avisosContador = $('avisos-contador');
const avisosMais = $('avisos-mais');

const inputDestino = $('destino');
const destinoNota = $('destino-nota');
const btnEnviarTodas = $('btn-enviar-todas');
const btnEnviarTodasLabel = $('btn-enviar-todas-label');
const envioResultado = $('envio-resultado');

const modalEnvio = $('modal-envio');
const modalEnvioTitulo = $('modal-envio-titulo');
const modalEnvioCorpo = $('modal-envio-corpo');
const btnConfirmarEnvio = $('btn-confirmar-envio');
const btnConfirmarSpinner = btnConfirmarEnvio.querySelector('.btn-spinner');
const btnConfirmarLabel = btnConfirmarEnvio.querySelector('.btn-label');

const modalSelecao = $('modal-selecao');
const selecaoCampanha = $('selecao-campanha');
const selecaoTexto = $('selecao-texto');
const btnSelecionarTodasFiltradas = $('btn-selecionar-todas-filtradas');
const selecaoTodasContagem = $('selecao-todas-contagem');
const btnLimparSelecao = $('btn-limpar-selecao');
const selecaoContador = $('selecao-contador');
const selecaoLista = $('selecao-lista');
const selecaoVazio = $('selecao-vazio');
const btnConfirmarSelecao = $('btn-confirmar-selecao');

const toast = $('toast');

// ==========================================================================
// 3. Canais
// ==========================================================================

function canaisSelecionados() {
  return canaisChecks.filter((c) => c.checked).map((c) => c.value);
}

function rotuloDoChip(check) {
  return check.closest('.chip').querySelector('.chip-face').textContent.trim();
}

function rotulosSelecionados() {
  return canaisChecks.filter((c) => c.checked).map(rotuloDoChip);
}

// Mantém a nota abaixo dos chips dizendo exatamente o que será lido — o
// usuário não deve precisar contar chips para saber o alcance da busca.
function atualizarNotaDeCanais() {
  const marcados = canaisSelecionados();

  if (marcados.length === 0) {
    canaisNota.textContent = 'Marque ao menos um canal para buscar.';
    canaisNota.classList.add('parcial');
  } else if (marcados.length === canaisChecks.length) {
    canaisNota.textContent = 'Todos os canais serão lidos.';
    canaisNota.classList.remove('parcial');
  } else {
    const nomes = rotulosSelecionados();
    canaisNota.textContent =
      `Só ${listarPorExtenso(nomes)} ${nomes.length === 1 ? 'será lido' : 'serão lidos'}. ` +
      'Os demais canais nem são abertos, o que deixa a busca mais rápida.';
    canaisNota.classList.add('parcial');
  }

  guardar(CHAVE_CANAIS, JSON.stringify(marcados));
}

// "PUSH", "PUSH e SMS", "PUSH, SMS e IB" — em vez de uma lista separada
// por vírgula que soa como texto de máquina.
function listarPorExtenso(itens) {
  if (itens.length <= 1) return itens.join('');
  return `${itens.slice(0, -1).join(', ')} e ${itens[itens.length - 1]}`;
}

canaisChecks.forEach((c) => c.addEventListener('change', atualizarNotaDeCanais));

btnCanaisTodos.addEventListener('click', () => {
  canaisChecks.forEach((c) => { c.checked = true; });
  atualizarNotaDeCanais();
});

btnCanaisNenhum.addEventListener('click', () => {
  canaisChecks.forEach((c) => { c.checked = false; });
  atualizarNotaDeCanais();
});

// ==========================================================================
// 4. Busca
// ==========================================================================

let cronometroId = null;
let progressoPollingId = null;

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();

  const caminho = inputCaminho.value.trim();
  if (!caminho) return;

  const canais = canaisSelecionados();
  if (canais.length === 0) {
    mostrarToast('Marque ao menos um canal');
    canaisNota.classList.add('parcial');
    return;
  }

  guardar(CHAVE_CAMINHO, caminho);
  limparEstados();
  definirCarregando(true);

  // Id só desta busca, usado para casar o /api/scan com o polling de
  // progresso em /api/scan_progresso. crypto.randomUUID() funciona aqui
  // porque http://127.0.0.1 conta como contexto seguro no navegador.
  const progressId = crypto.randomUUID();
  iniciarStatusDeBusca(caminho, canais);
  iniciarPollingDeProgresso(progressId);

  try {
    // 'canais' só vai na URL quando há recorte de verdade; com todos
    // marcados o servidor varre tudo, como antes.
    const parametros = new URLSearchParams({ path: caminho, progress_id: progressId });
    if (canais.length < canaisChecks.length) parametros.set('canais', canais.join(','));

    const resposta = await fetch('/api/scan?' + parametros.toString());
    const dados = await resposta.json();

    encerrarStatusDeBusca();

    if (!dados.sucesso) {
      mostrarErro(dados.erro);
      return;
    }

    ultimosResultados = dados.resultados || [];
    ultimosAvisos = dados.avisos || [];
    resumoCanais = dados.resumo_canais || {};
    caminhoPesquisado = caminho;

    renderizarAvisos();

    if (ultimosResultados.length === 0) {
      mostrarVazio();
      return;
    }

    resultadosSection.hidden = false;
    canalAtivo = 'todos';
    severidadeAtiva = 'todas';
    filtroTexto.value = '';
    marcarSegmentoAtivo('todas');
    renderizarDistribuicao();
    aplicarFiltros();
  } catch (erro) {
    encerrarStatusDeBusca();
    mostrarErro(
      'O servidor não respondeu. Confirme se o programa ainda está em execução ' +
      'na janela do Python e tente de novo.'
    );
  } finally {
    definirCarregando(false);
  }
});

function definirCarregando(carregando) {
  btnBuscar.disabled = carregando;
  btnBuscarSpinner.hidden = !carregando;
  btnBuscarLabel.textContent = carregando ? 'Buscando' : 'Buscar pastas';
}

// Varredura em pasta de rede pode levar minutos. O cronômetro mostra que
// o programa continua trabalhando, em vez de deixar a tela parada.
function iniciarStatusDeBusca(caminho, canais) {
  const recorte = canais.length < canaisChecks.length
    ? `em ${escapeHtml(listarPorExtenso(rotulosSelecionados()))}`
    : 'em todos os canais';

  statusArea.innerHTML = `
    <div class="status-carregando">
      <span class="pontos" aria-hidden="true"><i></i><i></i><i></i></span>
      <span class="status-texto">
        Lendo as pastas ${recorte}<br>
        <span class="status-alvo">${escapeHtml(caminho)}</span>
        <span class="status-progresso" id="statusProgresso"></span>
      </span>
      <span class="cronometro" id="cronometro">0s</span>
    </div>`;

  const inicio = Date.now();
  cronometroId = setInterval(() => {
    const seg = Math.floor((Date.now() - inicio) / 1000);
    const alvo = $('cronometro');
    if (alvo) alvo.textContent = seg < 60 ? `${seg}s` : `${Math.floor(seg / 60)}min ${seg % 60}s`;
  }, 1000);
}

// Consulta /api/scan_progresso a cada meio segundo enquanto a busca roda, e
// atualiza o contador "N pastas lidas". Como a árvore de pastas só é
// descoberta aos poucos, não existe um "total" fixo desde o início — por
// isso o texto é "lidas" (fato) e não "X de Y" (que exigiria promessa de um
// total que a gente ainda não conhece).
function iniciarPollingDeProgresso(progressId) {
  progressoPollingId = setInterval(async () => {
    try {
      const resposta = await fetch('/api/scan_progresso?id=' + progressId);
      const dados = await resposta.json();
      const alvo = $('statusProgresso');
      if (!alvo) return;

      if (dados.em_andamento && typeof dados.lidas === 'number') {
        const pendentes = dados.pendentes || 0;
        alvo.textContent = pendentes > 0
          ? `${dados.lidas} pastas lidas · ~${pendentes} na fila`
          : `${dados.lidas} pastas lidas`;
      }
    } catch (erro) {
      // Uma falha no polling é só cosmética (o contador para de atualizar);
      // não deve interromper nem avisar sobre a busca em si.
    }
  }, 500);
}

function encerrarStatusDeBusca() {
  clearInterval(cronometroId);
  cronometroId = null;
  clearInterval(progressoPollingId);
  progressoPollingId = null;
  statusArea.innerHTML = '';
}

function limparEstados() {
  emptyState.hidden = true;
  errorState.hidden = true;
  envioResultado.hidden = true;
  ultimoEnvio = null;
  resultadosSection.hidden = true;
  avisosSection.hidden = true;
  listaResultados.innerHTML = '';
  emptyFiltered.hidden = true;
  resultadosVisiveis = [];
  // Uma busca nova invalida qualquer seleção pendente do painel: nunca deixar
  // uma marcação de uma pasta de rede anterior sobreviver para outra busca.
  if (!modalSelecao.hidden) fecharPainelSelecao();
  pecasSelecionadas = new Set();
}

function mostrarErro(mensagem) {
  errorState.hidden = false;
  errorState.innerHTML = `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="7.4" stroke="currentColor" stroke-width="1.5"/>
      <path d="M10 6.3v4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <circle cx="10" cy="13.4" r=".95" fill="currentColor"/>
    </svg>
    <div>
      <strong>A busca não foi concluída</strong>
      <p>${escapeHtml(mensagem)}</p>
    </div>`;
}

function mostrarVazio() {
  const parcial = canaisSelecionados().length < canaisChecks.length;
  emptyState.hidden = false;
  emptyState.innerHTML = `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3 5.8c0-.7.56-1.3 1.25-1.3h3.4l1.6 1.7h7.5c.69 0 1.25.58 1.25 1.3v7.7c0 .72-.56 1.3-1.25 1.3H4.25C3.56 16.5 3 15.92 3 15.2V5.8Z"
            stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
      <path d="M7.6 11.2 9.3 12.9l3.4-3.6" stroke="currentColor" stroke-width="1.5"
            stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div>
      <strong>Nada vencido por aqui</strong>
      <p>
        Nenhuma pasta "Val..." está vencida há 3 meses ou mais nesse caminho${
          parcial ? ` em ${escapeHtml(listarPorExtenso(rotulosSelecionados()))}` : ''
        }.${parcial ? ' Marque mais canais para ampliar a busca.' : ''}
      </p>
    </div>`;
}

// ==========================================================================
// 5. Filtros e ordenação
// ==========================================================================

const ROTULO_SEVERIDADE = { atencao: 'Atenção', vencida: 'Vencida', critica: 'Crítica' };

function classificarSeveridade(meses) {
  if (meses >= 12) return 'critica';
  if (meses >= 6) return 'vencida';
  return 'atencao';
}

// --- Distribuição por canal (também é o filtro de canal) ------------------

function renderizarDistribuicao() {
  const codigos = Object.keys(resumoCanais).sort((a, b) => resumoCanais[b] - resumoCanais[a]);
  const total = codigos.reduce((soma, c) => soma + resumoCanais[c], 0);

  const rotulos = {};
  ultimosResultados.forEach((item) => { rotulos[item.canal] = item.canal_rotulo; });

  distBar.innerHTML = codigos.map((codigo, i) => {
    const n = resumoCanais[codigo];
    const pct = Math.round((n / total) * 100);
    return `
      <button type="button" class="dist-seg" data-canal="${escapeHtml(codigo)}"
              style="flex-grow: ${n}; animation-delay: ${i * 55}ms"
              title="${escapeHtml(rotulos[codigo] || codigo)}: ${n} (${pct}%)"
              aria-label="Filtrar por ${escapeHtml(rotulos[codigo] || codigo)}, ${n} pastas"></button>`;
  }).join('');

  distLegenda.innerHTML = codigos.map((codigo) => `
    <button type="button" class="legenda-item" data-canal="${escapeHtml(codigo)}"
            aria-pressed="false">
      ${escapeHtml(rotulos[codigo] || codigo)}
      <span class="legenda-num">${resumoCanais[codigo]}</span>
    </button>`).join('');

  [distBar, distLegenda].forEach((container) => {
    container.querySelectorAll('[data-canal]').forEach((el) => {
      el.addEventListener('click', () => {
        // Clicar no canal já ativo desfaz o filtro — evita ficar preso.
        definirCanal(el.dataset.canal === canalAtivo ? 'todos' : el.dataset.canal);
      });
    });
  });
}

function definirCanal(codigo) {
  canalAtivo = codigo;

  distBar.classList.toggle('tem-selecao', codigo !== 'todos');
  distBar.querySelectorAll('.dist-seg').forEach((seg) => {
    seg.classList.toggle('ativo', seg.dataset.canal === codigo);
  });
  distLegenda.querySelectorAll('.legenda-item').forEach((item) => {
    const ativo = item.dataset.canal === codigo;
    item.classList.toggle('ativo', ativo);
    item.setAttribute('aria-pressed', String(ativo));
  });

  btnLimparCanal.hidden = codigo === 'todos';
  aplicarFiltros();
}

btnLimparCanal.addEventListener('click', () => definirCanal('todos'));

// --- Gravidade ------------------------------------------------------------

segSeveridade.addEventListener('click', (evento) => {
  const botao = evento.target.closest('.seg-btn');
  if (!botao || botao.disabled) return;
  severidadeAtiva = botao.dataset.valor;
  marcarSegmentoAtivo(severidadeAtiva);
  aplicarFiltros();
});

function marcarSegmentoAtivo(valor) {
  segSeveridade.querySelectorAll('.seg-btn').forEach((b) => {
    b.classList.toggle('ativo', b.dataset.valor === valor);
  });
}

// --- Texto e ordenação ----------------------------------------------------

filtroTexto.addEventListener('input', aplicarFiltros);
filtroOrdenacao.addEventListener('change', aplicarFiltros);

btnLimparFiltros.addEventListener('click', () => {
  filtroTexto.value = '';
  severidadeAtiva = 'todas';
  marcarSegmentoAtivo('todas');
  definirCanal('todos');
});

// --- Aplicação ------------------------------------------------------------

function aplicarFiltros() {
  const texto = filtroTexto.value.trim().toLowerCase();
  const ordenacao = filtroOrdenacao.value;

  const combinaTextoECanal = (item) => {
    const bateTexto = !texto
      || item.nome.toLowerCase().includes(texto)
      || item.caminho.toLowerCase().includes(texto)
      || (item.campanha || '').toLowerCase().includes(texto);
    const bateCanal = canalAtivo === 'todos' || item.canal === canalAtivo;
    return bateTexto && bateCanal;
  };

  // As contagens do controle de gravidade refletem o recorte atual de
  // canal e texto — assim o número no botão é o que você vai receber.
  const baseParaContagem = ultimosResultados.filter(combinaTextoECanal);
  atualizarContadoresDeSeveridade(baseParaContagem);

  let filtrados = baseParaContagem.filter((item) =>
    severidadeAtiva === 'todas' || classificarSeveridade(item.meses_vencida) === severidadeAtiva
  );

  filtrados = filtrados.slice().sort((a, b) => {
    if (ordenacao === 'antigas') return b.meses_vencida - a.meses_vencida;
    if (ordenacao === 'recentes') return a.meses_vencida - b.meses_vencida;
    if (ordenacao === 'canal') {
      return a.canal_rotulo.localeCompare(b.canal_rotulo, 'pt-BR')
        || b.meses_vencida - a.meses_vencida;
    }
    if (ordenacao === 'campanha') {
      return (a.campanha || '').localeCompare(b.campanha || '', 'pt-BR')
        || b.meses_vencida - a.meses_vencida;
    }
    return a.nome.localeCompare(b.nome, 'pt-BR');
  });

  resultadosVisiveis = filtrados;
  renderizarLista(filtrados);
  atualizarContagem(filtrados.length, ultimosResultados.length);
}

function atualizarContadoresDeSeveridade(base) {
  const contagem = { atencao: 0, vencida: 0, critica: 0 };
  base.forEach((item) => { contagem[classificarSeveridade(item.meses_vencida)] += 1; });

  Object.keys(contagem).forEach((sev) => {
    const alvo = segSeveridade.querySelector(`[data-num="${sev}"]`);
    if (alvo) alvo.textContent = contagem[sev];
    const botao = segSeveridade.querySelector(`[data-valor="${sev}"]`);
    // Sem resultados naquela faixa o botão fica inerte, em vez de levar a
    // uma lista vazia.
    if (botao) botao.disabled = contagem[sev] === 0 && severidadeAtiva !== sev;
  });
}

function atualizarContagem(visiveis, total) {
  const plural = (n) => (n === 1 ? 'pasta vencida' : 'pastas vencidas');

  resultsCount.innerHTML = visiveis === total
    ? `<span class="num">${total}</span> ${plural(total)}`
    : `<span class="num num-parcial">${visiveis}</span> de ${total} ${plural(total)}`;

  const nomeCanal = canalAtivo === 'todos'
    ? null
    : (resultadosVisiveis[0]?.canal_rotulo || canalAtivo);

  // O envio também respeita o recorte, então o texto precisa dizer isso: é
  // a diferença entre exportar a lista errada e MOVER a campanha errada.
  toolbarScope.textContent = nomeCanal
    ? `Exportação, cópia e envio usam o recorte atual · ${nomeCanal}`
    : 'Exportação, cópia e envio usam o recorte atual';

  btnCopiarTodosLabel.textContent = visiveis === total
    ? `Copiar caminhos (${total})`
    : `Copiar caminhos (${visiveis})`;

  [btnCopiarTodos, btnExportarExcel, btnSalvarLog].forEach((b) => { b.disabled = visiveis === 0; });
  atualizarEstadoDoEnvio();
}

// ==========================================================================
// 6. Lista
// ==========================================================================

function renderizarLista(itens) {
  if (itens.length === 0) {
    listaResultados.innerHTML = '';
    emptyFiltered.hidden = false;
    return;
  }
  emptyFiltered.hidden = true;

  listaResultados.innerHTML = itens.map((item, indice) => {
    const sev = classificarSeveridade(item.meses_vencida);
    const verificada = caminhosVerificados.has(item.caminho);
    const meses = `${item.meses_vencida} ${item.meses_vencida === 1 ? 'mês' : 'meses'}`;
    const podeEnviar = envioLiberado() && Boolean(item.campanha);

    return `
      <li class="item${verificada ? ' verificada' : ''}"
          data-canal="${escapeHtml(item.canal)}" data-sev="${sev}">
        <label class="item-check" title="Marcar como conferida">
          <input type="checkbox" class="check-verificada" data-indice="${indice}"
                 ${verificada ? 'checked' : ''}
                 aria-label="Marcar ${escapeHtml(item.nome)} como conferida">
        </label>

        <div class="item-corpo">
          <div class="item-topo">
            <span class="item-nome">${escapeHtml(item.nome)}</span>
            <span class="selos">
              <span class="selo-canal">${escapeHtml(item.canal_rotulo)}</span>
              <span class="selo-sev">${ROTULO_SEVERIDADE[sev]} · ${meses}</span>
            </span>
          </div>

          <div class="item-meta">
            <span>Validade <b>${escapeHtml(item.validade)}</b></span>
            ${item.campanha
              ? `<span class="item-campanha">Campanha <b>${escapeHtml(item.campanha)}</b></span>`
              : ''}
          </div>

          <div class="item-caminho-linha">
            <code class="caminho">${escapeHtml(item.caminho)}</code>
            <button type="button" class="btn-copiar" data-indice="${indice}">
              <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <rect x="7.2" y="7.2" width="9.6" height="9.6" rx="1.6" stroke="currentColor" stroke-width="1.3"/>
                <path d="M13 7.2V5.6c0-.88-.72-1.6-1.6-1.6H4.8c-.88 0-1.6.72-1.6 1.6v6.6c0 .88.72 1.6 1.6 1.6h2.4"
                      stroke="currentColor" stroke-width="1.3"/>
              </svg>
              <span>Copiar</span>
            </button>
            <button type="button" class="btn-enviar" data-indice="${indice}"
                    ${podeEnviar ? '' : 'disabled'} title="${escapeHtml(motivoDoEnvio(item))}">
              <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M3 6.2c0-.72.58-1.3 1.3-1.3h3.1l1.5 1.6h6.8c.72 0 1.3.58 1.3 1.3v6.9c0 .72-.58 1.3-1.3 1.3H4.3c-.72 0-1.3-.58-1.3-1.3V6.2Z"
                      stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
                <path d="M10 9v4.2M8 11.4 10 13.4l2-2" stroke="currentColor" stroke-width="1.3"
                      stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span>Descontinuar</span>
            </button>
          </div>
        </div>
      </li>`;
  }).join('');

  listaResultados.querySelectorAll('.btn-copiar').forEach((botao) => {
    botao.addEventListener('click', () => {
      copiarTexto(itens[Number(botao.dataset.indice)].caminho, botao, 'Copiado', 'Copiar');
    });
  });

  listaResultados.querySelectorAll('.btn-enviar').forEach((botao) => {
    botao.addEventListener('click', () => {
      confirmarEnvio([itens[Number(botao.dataset.indice)]]);
    });
  });

  // O estado de conferido fica em `caminhosVerificados` e é reaplicado a
  // cada redesenho, então filtrar ou reordenar não perde as marcações.
  listaResultados.querySelectorAll('.check-verificada').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const item = itens[Number(checkbox.dataset.indice)];
      const linha = checkbox.closest('.item');
      if (checkbox.checked) {
        caminhosVerificados.add(item.caminho);
        linha.classList.add('verificada');
      } else {
        caminhosVerificados.delete(item.caminho);
        linha.classList.remove('verificada');
      }
    });
  });
}

// ==========================================================================
// 7. Exportações
// ==========================================================================

function sufixoDeArquivo() {
  return canalAtivo === 'todos' ? '' : `_${canalAtivo.toLowerCase()}`;
}

btnCopiarTodos.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;
  const caminhos = resultadosVisiveis.map((item) => item.caminho);

  copiarTexto(caminhos.join('\n'), btnCopiarTodos, null, null, () => {
    const original = btnCopiarTodosLabel.textContent;
    btnCopiarTodosLabel.textContent = 'Copiado';
    setTimeout(() => { btnCopiarTodosLabel.textContent = original; }, 1600);
  });

  mostrarToast(`${caminhos.length} caminho${caminhos.length === 1 ? '' : 's'} copiado${caminhos.length === 1 ? '' : 's'}`);
});

// A planilha é montada no navegador, a partir do que já veio da busca.
btnExportarExcel.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;

  const linhas = resultadosVisiveis.map((item) => ({
    'Canal': item.canal_rotulo,
    'Campanha': item.campanha,
    'Nome da pasta': item.nome,
    'Validade': item.validade,
    'Meses vencida': item.meses_vencida,
    'Gravidade': ROTULO_SEVERIDADE[classificarSeveridade(item.meses_vencida)],
    'Caminho completo': item.caminho,
    'Conferida': caminhosVerificados.has(item.caminho) ? 'Sim' : 'Não',
  }));

  const planilha = XLSX.utils.json_to_sheet(linhas);
  planilha['!cols'] = [
    { wch: 10 }, { wch: 36 }, { wch: 26 }, { wch: 10 },
    { wch: 13 }, { wch: 11 }, { wch: 62 }, { wch: 10 },
  ];
  planilha['!autofilter'] = { ref: `A1:H${linhas.length + 1}` };

  const livro = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(livro, planilha, 'Pastas vencidas');
  XLSX.writeFile(livro, `pastas-vencidas${sufixoDeArquivo()}_${hoje()}.xlsx`);

  mostrarToast(`${linhas.length} linha${linhas.length === 1 ? '' : 's'} exportada${linhas.length === 1 ? '' : 's'}`);
});

btnSalvarLog.addEventListener('click', () => {
  if (!resultadosVisiveis.length) return;

  const agora = new Date();
  const recorte = canalAtivo === 'todos'
    ? 'todos os canais'
    : (resultadosVisiveis[0]?.canal_rotulo || canalAtivo);

  const linhas = [
    'Validade de pastas — Bradesco CRM · Publicação e Orquestração',
    `Gerado em ${agora.toLocaleString('pt-BR')}`,
    `Caminho: ${inputCaminho.value.trim()}`,
    `Recorte: ${recorte}`,
    `Pastas listadas: ${resultadosVisiveis.length}`,
    '='.repeat(66),
    '',
    ...resultadosVisiveis.map((item) => (
      `${item.nome}\n` +
      `  Canal: ${item.canal_rotulo}${item.campanha ? `  |  Campanha: ${item.campanha}` : ''}\n` +
      `  Validade: ${item.validade}  |  Vencida há: ${item.meses_vencida} ${item.meses_vencida === 1 ? 'mês' : 'meses'}\n` +
      `  Conferida: ${caminhosVerificados.has(item.caminho) ? 'sim' : 'não'}\n` +
      `  Caminho: ${item.caminho}\n`
    )),
  ];

  baixarTexto(linhas.join('\n'), `pastas-vencidas${sufixoDeArquivo()}_${hoje()}.log.txt`);
  mostrarToast('Log salvo');
});

function baixarTexto(conteudo, nomeArquivo) {
  const url = URL.createObjectURL(new Blob([conteudo], { type: 'text/plain;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = nomeArquivo;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const hoje = () => new Date().toISOString().slice(0, 10);

// ==========================================================================
// 8. Descontinuar (enviar para Descontinuadas)
// ==========================================================================
//
// Esta é a única parte da tela que ALTERA a rede. O que se move é a PEÇA
// vencida — a pasta "Val..." — e só ela. A pasta da campanha e a do canal
// ficam onde estão, mesmo que esvaziem: elas guardam a 0.DOCs e as peças que
// ainda estão no prazo.
//
// No destino, os três níveis são recriados com os nomes idênticos aos da
// origem, e a peça ganha a data do dia na frente:
//
//   Disponiveis\20260904 - Campanha X\PUSH\Val_05.24
//       -> Descontinuadas\20260904 - Campanha X\PUSH\20260905_Val_05.24
//
// Três garantias, por ordem de importância:
//   1. Sempre confirma, mostrando peça por peça o nome que ela terá.
//   2. Nada é sobrescrito: peça já existente no destino é bloqueada.
//   3. Quem valida de verdade é o servidor — isto aqui é conveniência.

function envioLiberado() {
  return Boolean(inputDestino.value.trim()) && Boolean(caminhoPesquisado);
}

/** AAAAMMDD de hoje — o mesmo prefixo que o servidor vai aplicar. */
function prefixoDeHoje() {
  const agora = new Date();
  const mes = String(agora.getMonth() + 1).padStart(2, '0');
  const dia = String(agora.getDate()).padStart(2, '0');
  return `${agora.getFullYear()}${mes}${dia}`;
}

/** Como a peça vai se chamar depois de descontinuada. */
function nomeDescontinuado(item) {
  return `${prefixoDeHoje()}_${item.nome}`;
}

/** Texto do `title` do botão de envio de um item — diz por que está travado. */
function motivoDoEnvio(item) {
  if (!item.campanha) {
    return 'Esta pasta não está dentro de uma campanha, então não há '
      + 'estrutura para recriar em Descontinuadas. Mova manualmente.';
  }
  if (!inputDestino.value.trim()) {
    return 'Informe a pasta Descontinuadas, lá em cima, para liberar o envio.';
  }
  return `Descontinuar: vira ${nomeDescontinuado(item)} em Descontinuadas`;
}

/** Só entram no envio as peças que têm campanha para recriar no destino. */
function pecasEnviaveis(itens) {
  return (itens || []).filter((item) => Boolean(item.campanha));
}

/** Liga/desliga o botão de lote e mantém a nota do campo de destino honesta. */
function atualizarEstadoDoEnvio() {
  const temDestino = Boolean(inputDestino.value.trim());
  // Usa o UNIVERSO TOTAL da busca (não só o que está filtrado na tela): o
  // painel de seleção tem seu próprio filtro por campanha, então o botão que
  // o abre precisa contar tudo que existe para escolher, não só o recorte
  // atual de canal/gravidade da lista principal.
  const pecas = pecasEnviaveis(ultimosResultados);

  btnEnviarTodas.disabled = !temDestino || pecas.length === 0;
  btnEnviarTodas.title = temDestino
    ? 'Abrir o painel para escolher quais peças descontinuar'
    : 'Informe a pasta Descontinuadas para liberar o envio';

  btnEnviarTodasLabel.textContent = pecas.length
    ? `Selecionar para descontinuar (${pecas.length})`
    : 'Selecionar para descontinuar';

  if (!temDestino) {
    destinoNota.textContent =
      'Enquanto estiver em branco, o envio fica desligado — só a busca funciona.';
    destinoNota.classList.remove('destino-ok');
  } else {
    destinoNota.textContent =
      `Envio liberado. As peças vão para CAMPANHA\\CANAL\\${prefixoDeHoje()}_Val_...`;
    destinoNota.classList.add('destino-ok');
  }
}

inputDestino.addEventListener('input', () => {
  guardar(CHAVE_DESTINO, inputDestino.value.trim());
  atualizarEstadoDoEnvio();
  // Os botões por item também dependem do destino estar preenchido.
  if (!resultadosSection.hidden) renderizarLista(resultadosVisiveis);
});

btnEnviarTodas.addEventListener('click', () => {
  abrirPainelSelecao();
});

// --- Painel de seleção (etapa antes do envio em lote) ---------------------
//
// Objetivo: dar controle total sobre o que é descontinuado em lote. Nada é
// enviado só por estar visível ou por bater com um filtro rápido da lista
// principal — a pessoa precisa MARCAR, peça por peça, o que quer mandar
// (ou usar "Selecionar todas", que só marca o que está dentro do recorte de
// campanha/busca escolhido AQUI, dentro do painel).
//
// A seleção usa o universo TOTAL da busca (`ultimosResultados`), não o
// recorte da tela (`resultadosVisiveis`): assim um filtro de canal deixado
// ligado na lista principal não esconde peças do painel de seleção.
//
// A seleção nunca sobrevive a um fechamento sem confirmar, nem a uma nova
// busca — reabrir o painel sempre começa com nada marcado. É proposital:
// evita que uma marcação antiga, de outra pasta ou de outra sessão de uso,
// seja enviada sem que a pessoa tenha olhado para ela de novo.

let pecasSelecionadas = new Set();

function itensSelecionaveis() {
  return pecasEnviaveis(ultimosResultados);
}

/** Nomes de campanha distintos entre as peças enviáveis, em ordem alfabética. */
function campanhasDisponiveis() {
  const contagem = new Map();
  itensSelecionaveis().forEach((item) => {
    contagem.set(item.campanha, (contagem.get(item.campanha) || 0) + 1);
  });
  return Array.from(contagem.entries()).sort((a, b) => a[0].localeCompare(b[0], 'pt-BR'));
}

function popularFiltroDeCampanha() {
  const campanhas = campanhasDisponiveis();
  const total = itensSelecionaveis().length;
  const valorAnterior = selecaoCampanha.value;

  selecaoCampanha.innerHTML = [
    `<option value="todas">Todas as campanhas (${total})</option>`,
    ...campanhas.map(([nome, n]) =>
      `<option value="${escapeHtml(nome)}">${escapeHtml(nome)} (${n})</option>`),
  ].join('');

  // Mantém a campanha escolhida se ela ainda existir depois de um envio
  // parcial; volta para "todas" se ela sumiu (foi toda descontinuada).
  const aindaExiste = campanhas.some(([nome]) => nome === valorAnterior);
  selecaoCampanha.value = aindaExiste ? valorAnterior : 'todas';
}

function itensFiltradosNoPainel() {
  const campanha = selecaoCampanha.value;
  const texto = selecaoTexto.value.trim().toLowerCase();

  return itensSelecionaveis().filter((item) => {
    const bateCampanha = campanha === 'todas' || item.campanha === campanha;
    const bateTexto = !texto
      || item.nome.toLowerCase().includes(texto)
      || (item.campanha || '').toLowerCase().includes(texto)
      || (item.nome_canal || item.canal_rotulo || '').toLowerCase().includes(texto);
    return bateCampanha && bateTexto;
  });
}

function abrirPainelSelecao() {
  if (!itensSelecionaveis().length) return;

  pecasSelecionadas = new Set();
  selecaoTexto.value = '';
  popularFiltroDeCampanha();
  selecaoCampanha.value = 'todas';
  renderizarListaSelecao();

  modalSelecao.hidden = false;
  document.body.classList.add('com-modal');
  selecaoTexto.focus();
}

function fecharPainelSelecao() {
  modalSelecao.hidden = true;
  document.body.classList.remove('com-modal');
}

modalSelecao.querySelectorAll('[data-fechar-selecao]').forEach((elemento) => {
  elemento.addEventListener('click', fecharPainelSelecao);
});

selecaoCampanha.addEventListener('change', renderizarListaSelecao);
selecaoTexto.addEventListener('input', renderizarListaSelecao);

function renderizarListaSelecao() {
  const itens = itensFiltradosNoPainel();

  selecaoTodasContagem.textContent = `(${itens.length})`;
  btnSelecionarTodasFiltradas.disabled = itens.length === 0;

  if (itens.length === 0) {
    selecaoLista.innerHTML = '';
    selecaoVazio.hidden = false;
  } else {
    selecaoVazio.hidden = true;
    selecaoLista.innerHTML = itens.map((item) => {
      const sev = classificarSeveridade(item.meses_vencida);
      const marcada = pecasSelecionadas.has(item.caminho);
      const meses = `${item.meses_vencida} ${item.meses_vencida === 1 ? 'mês' : 'meses'}`;

      return `
        <li class="item${marcada ? ' selecionada' : ''}"
            data-canal="${escapeHtml(item.canal)}" data-sev="${sev}"
            data-caminho="${escapeHtml(item.caminho)}">
          <label class="item-check" title="${marcada ? 'Remover da seleção' : 'Marcar para descontinuar'}">
            <input type="checkbox" class="check-selecionada" ${marcada ? 'checked' : ''}
                   aria-label="Selecionar ${escapeHtml(item.nome)} para descontinuar">
          </label>

          <div class="item-corpo">
            <div class="item-topo">
              <span class="item-nome">${escapeHtml(item.nome)}</span>
              <span class="selos">
                <span class="selo-canal">${escapeHtml(item.canal_rotulo)}</span>
                <span class="selo-sev">${ROTULO_SEVERIDADE[sev]} · ${meses}</span>
              </span>
            </div>
            <div class="item-meta">
              <span class="item-campanha">Campanha <b>${escapeHtml(item.campanha)}</b></span>
              <span>Validade <b>${escapeHtml(item.validade)}</b></span>
            </div>
          </div>
        </li>`;
    }).join('');
  }

  atualizarContadorSelecao();
}

/** Clique em qualquer parte da linha alterna a seleção — não só no checkbox. */
selecaoLista.addEventListener('click', (evento) => {
  const linha = evento.target.closest('.item[data-caminho]');
  if (!linha) return;

  const ehCheckbox = evento.target.matches('.check-selecionada');
  const caminho = linha.dataset.caminho;

  if (ehCheckbox) {
    alternarSelecao(caminho, evento.target.checked);
  } else {
    alternarSelecao(caminho, !pecasSelecionadas.has(caminho));
  }
});

function alternarSelecao(caminho, marcar) {
  if (marcar) {
    pecasSelecionadas.add(caminho);
  } else {
    pecasSelecionadas.delete(caminho);
  }
  // Redesenha a lista inteira em vez de tocar só a linha: caminho de rede
  // pode ter caractere que complique um seletor CSS, e a lista costuma ser
  // pequena o bastante (peças vencidas de uma busca) para o custo não importar.
  renderizarListaSelecao();
}

/** Seleciona TUDO que está dentro do recorte atual do painel (campanha + busca) — nunca fora dele. */
btnSelecionarTodasFiltradas.addEventListener('click', () => {
  itensFiltradosNoPainel().forEach((item) => pecasSelecionadas.add(item.caminho));
  renderizarListaSelecao();
});

btnLimparSelecao.addEventListener('click', () => {
  pecasSelecionadas.clear();
  renderizarListaSelecao();
});

function atualizarContadorSelecao() {
  const n = pecasSelecionadas.size;
  selecaoContador.textContent = n === 0
    ? 'Nenhuma pasta selecionada'
    : `${n} pasta${n === 1 ? '' : 's'} selecionada${n === 1 ? '' : 's'}`;
  selecaoContador.classList.toggle('tem-selecao', n > 0);

  btnConfirmarSelecao.disabled = n === 0;
  $('btn-confirmar-selecao-label').textContent = n === 0
    ? 'Descontinuar selecionadas'
    : `Descontinuar selecionadas (${n})`;
}

btnConfirmarSelecao.addEventListener('click', () => {
  if (!pecasSelecionadas.size) return;

  const escolhidas = ultimosResultados.filter((item) => pecasSelecionadas.has(item.caminho));
  fecharPainelSelecao();
  // Reaproveita a confirmação existente: itemizada, com o nome final de cada
  // peça, antes de qualquer coisa ser realmente movida.
  confirmarEnvio(escolhidas);
});

// --- Confirmação ----------------------------------------------------------

// A janela de confirmação é a mesma para descontinuar e para desfazer: muda
// o título, o corpo e o que acontece no "confirmar". Manter uma só evita que
// as duas operações mais perigosas da tela divirjam em comportamento.
let acaoConfirmada = null;

function abrirConfirmacao({ titulo, html, rotulo, acao }) {
  modalEnvioTitulo.textContent = titulo;
  modalEnvioCorpo.innerHTML = html;
  btnConfirmarLabel.textContent = rotulo;
  acaoConfirmada = acao;
  abrirModal();
}

let pecasAguardandoConfirmacao = [];

function confirmarEnvio(itens) {
  const pecas = pecasEnviaveis(itens);

  if (!pecas.length) {
    mostrarToast('Nada para descontinuar');
    return;
  }

  const destino = inputDestino.value.trim();
  if (!destino) {
    mostrarToast('Informe a pasta Descontinuadas');
    inputDestino.focus();
    return;
  }

  // Quantas campanhas serão tocadas — útil para dimensionar o lote sem ter
  // que contar as linhas.
  const campanhas = new Set(pecas.map((p) => p.campanha)).size;

  const html = `
    <p class="modal-linha">
      <span class="modal-rotulo">De</span>
      <code class="caminho">${escapeHtml(caminhoPesquisado)}</code>
    </p>
    <p class="modal-linha">
      <span class="modal-rotulo">Para</span>
      <code class="caminho">${escapeHtml(destino)}</code>
    </p>

    <p class="modal-resumo">
      <b>${pecas.length}</b> peça${pecas.length === 1 ? '' : 's'}
      de <b>${campanhas}</b> campanha${campanhas === 1 ? '' : 's'}.
      A pasta da campanha e a do canal <b>continuam em Disponíveis</b> —
      só ${pecas.length === 1 ? 'a peça sai' : 'as peças saem'} do lugar.
    </p>

    <ul class="modal-lista">
      ${pecas.map((p) => `
        <li>
          <span class="modal-campanha">${escapeHtml(p.campanha)}${p.nome_canal ? ` <span class="modal-seta">›</span> ${escapeHtml(p.nome_canal)}` : ''}</span>
          <span class="modal-detalhe">
            <span class="modal-de">${escapeHtml(p.nome)}</span>
            <span class="modal-seta">→</span>
            <b class="modal-para">${escapeHtml(nomeDescontinuado(p))}</b>
          </span>
        </li>`).join('')}
    </ul>

    <p class="modal-aviso-final">
      Depois de confirmar, dá para desfazer <b>enquanto esta página estiver
      aberta</b> — e só se nada tiver mudado na rede nesse meio-tempo.
    </p>`;

  abrirConfirmacao({
    titulo: 'Descontinuar peças vencidas',
    html,
    rotulo: `Confirmar (${pecas.length})`,
    acao: () => executarEnvio(pecas),
  });
}

function abrirModal() {
  modalEnvio.hidden = false;
  document.body.classList.add('com-modal');
  btnConfirmarEnvio.focus();
}

function fecharModal() {
  modalEnvio.hidden = true;
  document.body.classList.remove('com-modal');
  acaoConfirmada = null;
}

modalEnvio.querySelectorAll('[data-fechar-modal]').forEach((elemento) => {
  elemento.addEventListener('click', fecharModal);
});

// --- Execução -------------------------------------------------------------

btnConfirmarEnvio.addEventListener('click', async () => {
  if (!acaoConfirmada) return;
  const acao = acaoConfirmada;

  definirEnviando(true);
  try {
    await acao();
  } finally {
    definirEnviando(false);
  }
});

async function executarEnvio(pecas) {
  try {
    const resposta = await fetch('/api/mover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origem: caminhoPesquisado,
        destino: inputDestino.value.trim(),
        pecas: pecas.map((p) => ({
          caminho: p.caminho,
          campanha: p.campanha,
          canal: p.nome_canal || '',
        })),
      }),
    });

    const dados = await resposta.json();

    if (!dados.sucesso) {
      fecharModal();
      mostrarErro(dados.erro || 'O envio não foi concluído.');
      return;
    }

    fecharModal();
    aplicarResultadoDoEnvio(dados, pecas);
  } catch (erro) {
    fecharModal();
    mostrarErro(
      'O servidor não respondeu durante o envio. Confira na pasta de rede o que '
      + 'chegou em Descontinuadas antes de tentar de novo — mover é uma operação '
      + 'que pode ter começado.'
    );
  }
}

// --- Desfazer -------------------------------------------------------------
//
// Alcance deliberadamente estreito: desfaz A ÚLTIMA operação, e só enquanto a
// página estiver aberta. Recarregou ou fez outra busca, acabou. É o que dá
// para prometer com honestidade: depois de alguns minutos a rede seguiu a
// vida, e a peça pode ter sido recriada no lugar de origem por outra pessoa.
//
// Por isso a devolução usa a MESMA trava do envio: se já existir algo com
// aquele nome no destino, ela é bloqueada em vez de sobrescrever.

function confirmarDesfazer() {
  const movidas = ultimoEnvio?.dados?.movidas || [];
  if (!movidas.length) return;

  const html = `
    <p class="modal-resumo">
      Devolver <b>${movidas.length}</b> peça${movidas.length === 1 ? '' : 's'}
      para o lugar de origem, com o nome que ${movidas.length === 1 ? 'tinha' : 'tinham'}
      antes (sem a data na frente).
    </p>

    <ul class="modal-lista">
      ${movidas.map((m) => `
        <li>
          <span class="modal-campanha">${escapeHtml(m.campanha)}${m.canal ? ` <span class="modal-seta">›</span> ${escapeHtml(m.canal)}` : ''}</span>
          <span class="modal-detalhe">
            <span class="modal-de">${escapeHtml(m.nome_novo)}</span>
            <span class="modal-seta">→</span>
            <b class="modal-para">${escapeHtml(m.nome_original)}</b>
          </span>
        </li>`).join('')}
    </ul>

    <p class="modal-aviso-final">
      Se alguém já recriou alguma dessas peças em Disponíveis, a devolução
      dela é bloqueada — nada é sobrescrito.
    </p>`;

  abrirConfirmacao({
    titulo: 'Desfazer a última descontinuação',
    html,
    rotulo: `Devolver (${movidas.length})`,
    acao: executarDesfazer,
  });
}

async function executarDesfazer() {
  const envio = ultimoEnvio;
  const movidas = envio?.dados?.movidas || [];
  if (!movidas.length) return;

  try {
    const resposta = await fetch('/api/desfazer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origem: caminhoPesquisado,
        destino: envio.dados.destino,
        devolucoes: movidas.map((m) => ({ atual: m.destino, original: m.origem })),
      }),
    });

    const dados = await resposta.json();

    if (!dados.sucesso) {
      fecharModal();
      mostrarErro(dados.erro || 'A devolução não foi concluída.');
      return;
    }

    fecharModal();
    aplicarResultadoDaDevolucao(dados, envio);
  } catch (erro) {
    fecharModal();
    mostrarErro(
      'O servidor não respondeu durante a devolução. Confira na pasta de rede o '
      + 'que voltou para Disponíveis antes de tentar de novo.'
    );
  }
}

/**
 * Recoloca na lista as peças que voltaram e mostra o comprovante da
 * devolução. As que voltaram estão de novo no caminho original, então
 * exibi-las é a verdade — some o item só de quem ficou em Descontinuadas.
 */
function aplicarResultadoDaDevolucao(dados, envio) {
  const devolvidas = dados.devolvidas || [];
  const falhas = dados.falhas || [];

  // O log da devolução sai primeiro, e protegido, pela mesma razão do envio:
  // a esta altura as pastas já voltaram.
  try {
    baixarLogDaDevolucao(dados, envio);
  } catch (erro) {
    console.error('Falha ao gerar o log da devolução:', erro);
    mostrarToast('As peças voltaram, mas o log da devolução falhou');
  }

  if (devolvidas.length) {
    const voltaram = new Set(devolvidas.map((d) => String(d.para).toLowerCase()));
    const reentrantes = (envio.pecas || []).filter(
      (p) => voltaram.has(String(p.caminho).toLowerCase())
    );

    ultimosResultados = ultimosResultados.concat(reentrantes);
    ultimosResultados.sort((a, b) => b.meses_vencida - a.meses_vencida);

    resumoCanais = {};
    ultimosResultados.forEach((item) => {
      resumoCanais[item.canal] = (resumoCanais[item.canal] || 0) + 1;
    });

    resultadosSection.hidden = ultimosResultados.length === 0;
    canalAtivo = 'todos';
    btnLimparCanal.hidden = true;
    renderizarDistribuicao();
    aplicarFiltros();
  }

  // Desfazer é de uma vez só: o que voltou não pode ser "desfeito" de novo.
  ultimoEnvio = null;

  envioResultado.hidden = false;
  envioResultado.innerHTML = `
    <div class="envio-cabecalho">
      <span class="envio-selo ${devolvidas.length ? 'ok' : 'nada'}">
        ${devolvidas.length} devolvida${devolvidas.length === 1 ? '' : 's'}
      </span>
      ${falhas.length ? `<span class="envio-selo falha">${falhas.length} bloqueada${falhas.length === 1 ? '' : 's'}</span>` : ''}
      <span class="envio-destino">de volta para <code>${escapeHtml(caminhoPesquisado)}</code></span>
    </div>
    <p class="envio-autoria">
      Descontinuação desfeita · o log da devolução foi baixado.
    </p>

    ${devolvidas.length ? `
      <ul class="envio-lista">
        ${devolvidas.map((d) => `<li class="envio-ok"><b>${escapeHtml(d.nome_original)}</b><span>voltou para o lugar de origem</span></li>`).join('')}
      </ul>` : ''}

    ${falhas.length ? `
      <ul class="envio-lista">
        ${falhas.map((f) => `
          <li class="envio-falha">
            <b>${escapeHtml(f.nome_original)}</b>
            <span>${escapeHtml(f.mensagem)}</span>
          </li>`).join('')}
      </ul>` : ''}`;

  envioResultado.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  if (devolvidas.length && !falhas.length) {
    mostrarToast(`${devolvidas.length} peça${devolvidas.length === 1 ? '' : 's'} devolvida${devolvidas.length === 1 ? '' : 's'}`);
  } else if (devolvidas.length) {
    mostrarToast(`${devolvidas.length} devolvida(s), ${falhas.length} bloqueada(s)`);
  } else {
    mostrarToast('Nada foi devolvido');
  }
}

function definirEnviando(enviando) {
  btnConfirmarEnvio.disabled = enviando;
  btnConfirmarSpinner.hidden = !enviando;
  btnConfirmarLabel.textContent = enviando ? 'Movendo...' : btnConfirmarLabel.textContent;
  modalEnvio.querySelectorAll('[data-fechar-modal]').forEach((el) => {
    // Fechar no meio de um `shutil.move` não cancela nada e só confunde.
    el.style.pointerEvents = enviando ? 'none' : '';
  });
}

/**
 * Tira da lista o que realmente saiu da rede e mostra o comprovante.
 * As peças movidas somem dos resultados porque a pasta não existe mais ali —
 * deixá-las na tela seria mentira.
 */
function aplicarResultadoDoEnvio(dados, pecas) {
  const movidas = dados.movidas || [];
  const falhas = dados.falhas || [];

  // O log sai ANTES de mexer na lista: se algo falhar daqui para a frente, o
  // registro do que aconteceu na rede já está na mão da pessoa.
  //
  // E sai dentro de try/catch porque, a esta altura, as pastas JÁ FORAM
  // MOVIDAS. Deixar uma falha na geração do log estourar aqui faria a tela
  // dizer que o envio não deu certo — a pior mentira possível, porque a
  // pessoa tentaria de novo achando que nada aconteceu.
  ultimoEnvio = { dados, pecas, quando: new Date() };
  try {
    baixarLogDoEnvio();
  } catch (erro) {
    console.error('Falha ao gerar o log do envio:', erro);
    formatoDoLog = null;
    mostrarToast('As peças foram movidas, mas o log falhou — use "Baixar log de novo"');
  }

  const caminhosMovidos = new Set(
    movidas.map((m) => String(m.origem).toLowerCase())
  );

  if (movidas.length) {
    ultimosResultados = ultimosResultados.filter(
      (item) => !caminhosMovidos.has(String(item.caminho).toLowerCase())
    );

    resumoCanais = {};
    ultimosResultados.forEach((item) => {
      resumoCanais[item.canal] = (resumoCanais[item.canal] || 0) + 1;
    });
  }

  renderizarResultadoDoEnvio(dados);

  if (ultimosResultados.length === 0) {
    resultadosSection.hidden = true;
    resultadosVisiveis = [];
  } else {
    canalAtivo = 'todos';
    btnLimparCanal.hidden = true;
    renderizarDistribuicao();
    aplicarFiltros();
  }

  if (movidas.length && !falhas.length) {
    mostrarToast(`${movidas.length} peça${movidas.length === 1 ? '' : 's'} descontinuada${movidas.length === 1 ? '' : 's'}`);
  } else if (movidas.length) {
    mostrarToast(`${movidas.length} movida(s), ${falhas.length} bloqueada(s)`);
  } else {
    mostrarToast('Nada foi movido');
  }
}

function renderizarResultadoDoEnvio(dados) {
  const usuario = dados.usuario || 'desconhecido';
  const movidas = dados.movidas || [];
  const falhas = dados.falhas || [];

  envioResultado.hidden = false;
  envioResultado.innerHTML = `
    <div class="envio-cabecalho">
      <span class="envio-selo ${movidas.length ? 'ok' : 'nada'}">
        ${movidas.length} descontinuada${movidas.length === 1 ? '' : 's'}
      </span>
      ${falhas.length ? `<span class="envio-selo falha">${falhas.length} bloqueada${falhas.length === 1 ? '' : 's'}</span>` : ''}
      <span class="envio-destino">para <code>${escapeHtml(dados.destino || '')}</code></span>
      ${movidas.length ? `
        <button type="button" class="btn-perigo envio-desfazer" id="btn-desfazer">
          <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path d="M7.4 4.6 3.8 8.2l3.6 3.6" stroke="currentColor" stroke-width="1.4"
                  stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3.8 8.2h7.4a4.6 4.6 0 0 1 0 9.2H8" stroke="currentColor" stroke-width="1.4"
                  stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Desfazer</span>
        </button>` : ''}
      <button type="button" class="btn-ghost envio-relog" id="btn-baixar-log">
        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path d="M10 3.4v8.4M6.6 8.8 10 12.2l3.4-3.4" stroke="currentColor" stroke-width="1.4"
                stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M3.6 14.2v1.4c0 .55.45 1 1 1h10.8c.55 0 1-.45 1-1v-1.4"
                stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
        </svg>
        <span>Baixar log de novo</span>
      </button>
    </div>
    <p class="envio-autoria">
      Registrado como <b>${escapeHtml(usuario)}</b> em
      ${escapeHtml((ultimoEnvio?.quando || new Date()).toLocaleString('pt-BR'))} ·
      ${formatoDoLog
        ? `o log em <b>${formatoDoLog}</b> foi baixado automaticamente.`
        : 'o log <b>não pôde ser gerado</b> — use o botão ao lado para tentar de novo.'}
    </p>

    ${movidas.length ? `
      <ul class="envio-lista">
        ${movidas.map((m) => `
          <li class="envio-ok">
            <b>${escapeHtml(m.campanha)}${m.canal ? ` › ${escapeHtml(m.canal)}` : ''}</b>
            <span>${escapeHtml(m.nome_original)} → ${escapeHtml(m.nome_novo)}</span>
          </li>`).join('')}
      </ul>` : ''}

    ${falhas.length ? `
      <ul class="envio-lista">
        ${falhas.map((f) => `
          <li class="envio-falha">
            <b>${escapeHtml(f.nome_original)}</b>
            <span>${escapeHtml(f.mensagem)}</span>
          </li>`).join('')}
      </ul>` : ''}`;

  const botaoLog = $('btn-baixar-log');
  if (botaoLog) botaoLog.addEventListener('click', baixarLogDoEnvio);

  const botaoDesfazer = $('btn-desfazer');
  if (botaoDesfazer) botaoDesfazer.addEventListener('click', confirmarDesfazer);

  envioResultado.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// --- Log de auditoria -----------------------------------------------------
//
// Toda confirmação gera um .xlsx, baixado na hora. Entram no arquivo tanto as
// peças MOVIDAS quanto as BLOQUEADAS: uma tentativa barrada é exatamente o
// tipo de coisa que alguém vai querer conferir depois ("descontinuei ou não
// aquela peça?").

let ultimoEnvio = null;

// Em que formato o último log saiu ('Excel', 'CSV' ou null se falhou). O
// comprovante mostra isso: dizer "log em Excel" quando saiu um CSV é o tipo
// de imprecisão que faz a pessoa procurar o arquivo errado na pasta.
let formatoDoLog = 'Excel';

function baixarLogDoEnvio() {
  if (!ultimoEnvio) return;

  const { dados, pecas, quando } = ultimoEnvio;
  const usuario = dados.usuario || 'desconhecido';
  const carimbo = quando.toLocaleString('pt-BR');

  // Validade e meses vencida ficam no resultado da BUSCA, não na resposta do
  // envio — por isso os dois são cruzados aqui pelo caminho da peça.
  const porCaminho = new Map(
    (pecas || []).map((p) => [String(p.caminho).toLowerCase(), p])
  );
  const detalhe = (caminho) => porCaminho.get(String(caminho).toLowerCase()) || {};

  const linhas = [];

  (dados.movidas || []).forEach((m) => {
    const info = detalhe(m.origem);
    linhas.push({
      'Data/hora': carimbo,
      'Usuário': usuario,
      'Situação': 'Descontinuada',
      'Briefing / Campanha': m.campanha,
      'Canal': m.canal || info.canal_rotulo || '',
      'Peça (nome original)': m.nome_original,
      'Nome em Descontinuadas': m.nome_novo,
      'Validade': info.validade || '',
      'Meses vencida': info.meses_vencida ?? '',
      'Origem': m.origem,
      'Destino': m.destino,
      'Motivo do bloqueio': '',
    });
  });

  (dados.falhas || []).forEach((f) => {
    const info = detalhe(f.caminho);
    linhas.push({
      'Data/hora': carimbo,
      'Usuário': usuario,
      'Situação': 'Bloqueada',
      'Briefing / Campanha': f.campanha || info.campanha || '',
      'Canal': f.canal || info.canal_rotulo || '',
      'Peça (nome original)': f.nome_original,
      'Nome em Descontinuadas': '',
      'Validade': info.validade || '',
      'Meses vencida': info.meses_vencida ?? '',
      'Origem': f.caminho,
      'Destino': '',
      'Motivo do bloqueio': f.mensagem || '',
    });
  });

  escreverLog(linhas, nomeDoLog(usuario, quando), 'Descontinuadas');
}

/** Nome do arquivo com usuário e horário: dois logs do mesmo dia não se
 *  sobrescrevem na pasta de Downloads. */
function nomeDoLog(usuario, quando, sufixo) {
  const hora = quando.toTimeString().slice(0, 5).replace(':', 'h');
  const usuarioNoNome = usuario.replace(/[^a-zA-Z0-9._-]+/g, '-').toLowerCase();
  return `descontinuadas${sufixo || ''}_${usuarioNoNome}_${hoje()}_${hora}`;
}

/** Grava o log em Excel — ou em CSV, se a biblioteca não estiver disponível. */
function escreverLog(linhas, nomeBase, nomeDaAba) {
  if (!linhas.length) return;

  // A biblioteca do Excel vem de um CDN, que rede corporativa às vezes
  // bloqueia. Sem ela o log vira CSV — que o Excel abre igual — em vez de
  // simplesmente não existir. Um registro de auditoria é justamente o que
  // não pode depender de a internet estar liberada.
  if (typeof XLSX === 'undefined') {
    baixarLogEmCsv(linhas, nomeBase);
    formatoDoLog = 'CSV';
    return;
  }

  const planilha = XLSX.utils.json_to_sheet(linhas);
  planilha['!cols'] = [
    { wch: 19 }, { wch: 18 }, { wch: 14 }, { wch: 38 }, { wch: 10 }, { wch: 24 },
    { wch: 28 }, { wch: 10 }, { wch: 13 }, { wch: 62 }, { wch: 62 }, { wch: 46 },
  ];
  planilha['!autofilter'] = { ref: `A1:L${linhas.length + 1}` };

  const livro = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(livro, planilha, nomeDaAba);
  XLSX.writeFile(livro, `${nomeBase}.xlsx`);
  formatoDoLog = 'Excel';
}

/**
 * Log da devolução. Sai como um arquivo próprio, e não como "cancelamento"
 * do anterior: o log de descontinuação já foi baixado e pode já ter sido
 * arquivado por alguém. Apagar o rastro do que aconteceu — ainda que tenha
 * sido desfeito — seria justamente o que um registro de auditoria não pode.
 */
function baixarLogDaDevolucao(dados, envio) {
  const usuario = dados.usuario || 'desconhecido';
  const quando = new Date();
  const carimbo = quando.toLocaleString('pt-BR');

  const porCaminho = new Map(
    (envio.pecas || []).map((p) => [String(p.caminho).toLowerCase(), p])
  );
  const detalhe = (caminho) => porCaminho.get(String(caminho).toLowerCase()) || {};

  const linhas = [];

  (dados.devolvidas || []).forEach((d) => {
    const info = detalhe(d.para);
    linhas.push({
      'Data/hora': carimbo,
      'Usuário': usuario,
      'Situação': 'Devolvida',
      'Briefing / Campanha': info.campanha || '',
      'Canal': info.nome_canal || info.canal_rotulo || '',
      'Peça (nome original)': d.nome_original,
      'Nome em Descontinuadas': '',
      'Validade': info.validade || '',
      'Meses vencida': info.meses_vencida ?? '',
      'Origem': d.de,
      'Destino': d.para,
      'Motivo do bloqueio': '',
    });
  });

  (dados.falhas || []).forEach((f) => {
    const info = detalhe(f.original);
    linhas.push({
      'Data/hora': carimbo,
      'Usuário': usuario,
      'Situação': 'Devolução bloqueada',
      'Briefing / Campanha': info.campanha || '',
      'Canal': info.nome_canal || info.canal_rotulo || '',
      'Peça (nome original)': f.nome_original,
      'Nome em Descontinuadas': '',
      'Validade': info.validade || '',
      'Meses vencida': info.meses_vencida ?? '',
      'Origem': f.atual,
      'Destino': f.original,
      'Motivo do bloqueio': f.mensagem || '',
    });
  });

  escreverLog(linhas, nomeDoLog(usuario, quando, '-desfeito'), 'Devolvidas');
}

/** Log em CSV, para quando a biblioteca do Excel não estiver disponível. */
function baixarLogEmCsv(linhas, nomeBase) {
  const colunas = Object.keys(linhas[0]);

  // Ponto e vírgula e BOM: é o que faz o Excel em português abrir o arquivo
  // já separado em colunas e com os acentos certos, sem assistente de importação.
  const escapar = (valor) => `"${String(valor ?? '').replace(/"/g, '""')}"`;
  const csv = '﻿' + [
    colunas.map(escapar).join(';'),
    ...linhas.map((linha) => colunas.map((c) => escapar(linha[c])).join(';')),
  ].join('\r\n');

  baixarTexto(csv, `${nomeBase}.csv`);
  mostrarToast('Log salvo em CSV (a biblioteca do Excel não carregou)');
}

// ==========================================================================
// 9. Avisos, atalhos e utilidades
// ==========================================================================

// Quantos caminhos listar antes de resumir o restante — uma pasta de rede
// com muita permissão negada geraria uma lista interminável.
const LIMITE_AVISOS = 40;

function renderizarAvisos() {
  if (!ultimosAvisos.length) {
    avisosSection.hidden = true;
    return;
  }

  avisosSection.hidden = false;
  avisosContador.textContent = ultimosAvisos.length;

  const visiveis = ultimosAvisos.slice(0, LIMITE_AVISOS);
  avisosLista.innerHTML = visiveis.map((a) => `<li>${escapeHtml(a)}</li>`).join('');

  const restante = ultimosAvisos.length - visiveis.length;
  avisosMais.hidden = restante === 0;
  if (restante > 0) {
    avisosMais.textContent = `+ ${restante} outro${restante === 1 ? '' : 's'} caminho${restante === 1 ? '' : 's'} sem permissão de leitura.`;
  }
}

// Recolhido por padrão: é informação de apoio, não o resultado da busca.
avisosToggle.addEventListener('click', () => {
  const aberto = avisosToggle.getAttribute('aria-expanded') === 'true';
  avisosToggle.setAttribute('aria-expanded', String(!aberto));
  avisosCorpo.hidden = aberto;
});

// --- Atalhos de teclado ---------------------------------------------------

document.addEventListener('keydown', (evento) => {
  const digitando = ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName);

  if (evento.key === 'Escape' && !modalEnvio.hidden && !btnConfirmarEnvio.disabled) {
    fecharModal();
    return;
  }

  if (evento.key === 'Escape' && !modalSelecao.hidden) {
    fecharPainelSelecao();
    return;
  }

  if (evento.key === '/' && !digitando && !resultadosSection.hidden) {
    evento.preventDefault();
    filtroTexto.focus();
    return;
  }

  if (evento.key === 'Escape' && document.activeElement === filtroTexto) {
    filtroTexto.value = '';
    aplicarFiltros();
  }
});

// --- Cópia com feedback e alternativa para contexto não seguro -----------

function copiarTexto(texto, botao, textoTemporario, textoOriginal, aoConcluir) {
  const feedback = () => {
    if (botao) {
      botao.classList.add('ok');
      setTimeout(() => botao.classList.remove('ok'), 1600);
    }
    if (botao && textoTemporario) {
      const span = botao.querySelector('span:last-child') || botao;
      span.textContent = textoTemporario;
      setTimeout(() => { span.textContent = textoOriginal; }, 1600);
    }
    if (aoConcluir) aoConcluir();
  };

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(texto).then(feedback).catch(() => {
      copiarComFallback(texto);
      feedback();
    });
  } else {
    copiarComFallback(texto);
    feedback();
  }
}

function copiarComFallback(texto) {
  const area = document.createElement('textarea');
  area.value = texto;
  area.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
  document.body.appendChild(area);
  area.select();
  try {
    document.execCommand('copy');
  } catch (erro) {
    mostrarToast('Não foi possível copiar');
  }
  document.body.removeChild(area);
}

let toastTimeout = null;
function mostrarToast(mensagem) {
  toast.textContent = mensagem;
  toast.classList.add('visivel');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('visivel'), 2000);
}

function escapeHtml(texto) {
  const div = document.createElement('div');
  div.textContent = texto == null ? '' : texto;
  return div.innerHTML;
}

// localStorage pode estar bloqueado por política do navegador corporativo;
// nesse caso o programa segue funcionando, só não lembra as preferências.
function guardar(chave, valor) {
  try { localStorage.setItem(chave, valor); } catch (erro) { /* sem persistência */ }
}

function recuperar(chave) {
  try { return localStorage.getItem(chave); } catch (erro) { return null; }
}

// --- Início ---------------------------------------------------------------

(function iniciar() {
  const caminhoSalvo = recuperar(CHAVE_CAMINHO);
  if (caminhoSalvo) inputCaminho.value = caminhoSalvo;

  const canaisSalvos = recuperar(CHAVE_CANAIS);
  if (canaisSalvos) {
    try {
      const lista = JSON.parse(canaisSalvos);
      if (Array.isArray(lista) && lista.length) {
        canaisChecks.forEach((c) => { c.checked = lista.includes(c.value); });
      }
    } catch (erro) { /* preferência inválida: mantém todos marcados */ }
  }

  const destinoSalvo = recuperar(CHAVE_DESTINO);
  if (destinoSalvo) inputDestino.value = destinoSalvo;

  atualizarNotaDeCanais();
  atualizarEstadoDoEnvio();
  inputCaminho.focus();
})();
