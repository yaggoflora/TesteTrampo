"""
Descontinuação de peças vencidas: "Disponíveis" -> "Descontinuadas".

Este módulo é o ÚNICO ponto do sistema que ESCREVE no disco. Todo o resto
(scanner.py) é somente leitura. A separação é proposital: se um dia for
preciso auditar "o que este programa é capaz de alterar", a resposta inteira
está neste arquivo.

O QUE É MOVIDO
--------------
Apenas a PEÇA vencida — a pasta "Val...". A pasta da campanha e a do canal
NÃO saem de Disponíveis; elas continuam lá, mesmo que fiquem vazias, porque
guardam a 0.DOCs e as peças que ainda estão no prazo.

No destino, a estrutura de três níveis é recriada:

    Disponiveis\\20260904 - Campanha X\\PUSH\\Val_05.24
        ->  Descontinuadas\\20260904 - Campanha X\\PUSH\\20260905_Val_05.24

    (1) pasta da campanha, com o nome IDÊNTICO ao de Disponíveis
    (2) pasta do canal, também com o nome idêntico
    (3) a peça, renomeada com a data da descontinuação na frente

As pastas (1) e (2) são criadas se não existirem e reaproveitadas se já
existirem — é o "ctrl+c do nome idêntico" feito automaticamente.

O PREFIXO DE DATA
-----------------
A peça entra em Descontinuadas com AAAAMMDD_ na frente, referente ao DIA DA
DESCONTINUAÇÃO (não à validade). Isso também tem um efeito prático útil: uma
peça já descontinuada não começa mais com "Val", então nunca é encontrada de
novo pela varredura — não há risco de descontinuar a mesma coisa duas vezes.

REGRAS
------
  1. Se a peça já existir no destino com o mesmo nome, NADA é movido e a
     operação devolve o motivo 'ja_existe'. Não sobrescrevemos nem mesclamos.
  2. Nada é excluído. `shutil.move` transfere; entre compartilhamentos de rede
     distintos isso vira cópia + remoção da origem, feita pelo próprio shutil.
  3. Uma falha não interrompe o lote: a peça problemática entra em 'falhas'
     com o motivo e as demais seguem.
"""

import os
import shutil
from datetime import date

from scanner import e_pasta_de_registro


class ErroDeMovimentacao(Exception):
    """Falha esperada e explicável (não é bug): destino inválido, peça já
    existente, permissão negada. Carrega um `motivo` curto, para a interface
    decidir o tratamento, além da mensagem pronta em português."""

    def __init__(self, motivo, mensagem):
        super().__init__(mensagem)
        self.motivo = motivo
        self.mensagem = mensagem


# ------------------------------------------------------------------------------
# Apoio
# ------------------------------------------------------------------------------

def _normalizar(caminho):
    """Forma canônica para comparar dois caminhos com segurança.

    `normcase` é o que faz a comparação funcionar no Windows, onde
    'C:\\Pasta' e 'c:\\pasta' são o MESMO lugar. `abspath` resolve '..' e
    caminhos relativos.
    """
    return os.path.normcase(os.path.abspath(caminho))


def caminho_esta_dentro(filho, pai):
    """Diz se `filho` está dentro de `pai` (ou é o próprio `pai`).

    Usado pelo app.py para conferir que toda peça recebida em uma requisição
    pertence mesmo à pasta que foi pesquisada.
    """
    filho = _normalizar(filho)
    pai = _normalizar(pai)
    if filho == pai:
        return True
    return filho.startswith(pai + os.sep)


def prefixo_de_data(quando=None):
    """AAAAMMDD do dia da descontinuação (ex.: '20260905')."""
    return (quando or date.today()).strftime('%Y%m%d')


def nome_descontinuado(nome_da_peca, quando=None):
    """'Val_05.24' -> '20260905_Val_05.24'."""
    return f'{prefixo_de_data(quando)}_{nome_da_peca}'


def _validar_segmento(valor, rotulo):
    """Garante que um nome de pasta é UM segmento, não um caminho.

    Campanha e canal chegam da tela. Se viesse algo como '..\\..\\outra',
    o os.path.join montaria um destino fora de Descontinuadas — por isso
    conferimos aqui, e não confiamos no que foi enviado.
    """
    nome = (valor or '').strip().strip('\\/')
    if not nome:
        return ''
    if os.sep in nome or (os.altsep and os.altsep in nome) or nome in ('.', '..'):
        raise ErroDeMovimentacao(
            'nome_invalido',
            f'Nome de {rotulo} inválido: {valor}')
    return nome


# ------------------------------------------------------------------------------
# Validação do destino (chamada uma vez, antes do lote)
# ------------------------------------------------------------------------------

def validar_pasta_destino(pasta_destino):
    """Confere se a pasta "Descontinuadas" informada serve como destino.

    Devolve o caminho normalizado. Levanta ErroDeMovimentacao com uma
    mensagem pronta quando não serve — a interface só repassa o texto.
    """
    caminho = (pasta_destino or '').strip()

    if not caminho:
        raise ErroDeMovimentacao(
            'destino_vazio',
            'Informe o caminho da pasta Descontinuadas.')

    if not os.path.exists(caminho):
        raise ErroDeMovimentacao(
            'destino_inexistente',
            f'A pasta de destino não foi encontrada: {caminho}')

    if not os.path.isdir(caminho):
        raise ErroDeMovimentacao(
            'destino_nao_e_pasta',
            f'O destino informado não é uma pasta: {caminho}')

    # Permissão de escrita conferida ANTES do lote: sem isto o erro só
    # apareceria no meio do caminho, depois de já ter movido algumas peças.
    if not os.access(caminho, os.W_OK):
        raise ErroDeMovimentacao(
            'destino_sem_permissao',
            f'Sem permissão de escrita na pasta de destino: {caminho}')

    return os.path.abspath(caminho)


# ------------------------------------------------------------------------------
# Movimentação
# ------------------------------------------------------------------------------

def mover_peca(peca, pasta_destino, quando=None):
    """Move UMA peça vencida para Descontinuadas.

    `peca` é um dicionário com:
        caminho   - caminho completo da pasta "Val..." (obrigatório)
        campanha  - nome da pasta da campanha (obrigatório)
        canal     - nome da pasta do canal (opcional: peça solta na campanha)

    Devolve um dicionário com o resultado. Levanta ErroDeMovimentacao quando
    a operação não pode ser feita.
    """
    origem = (peca.get('caminho') or '').strip()

    if not origem:
        raise ErroDeMovimentacao(
            'origem_vazia', 'Caminho da peça não informado.')

    if not os.path.exists(origem):
        raise ErroDeMovimentacao(
            'origem_inexistente',
            f'A pasta não foi encontrada: {origem}')

    if not os.path.isdir(origem):
        raise ErroDeMovimentacao(
            'origem_nao_e_pasta',
            f'O caminho informado não é uma pasta: {origem}')

    origem = os.path.abspath(origem)
    nome_original = os.path.basename(origem.rstrip('\\/'))

    # Segunda trava contra a mesma regra do scanner.py: a varredura já nunca
    # LISTA a pasta de registro (DOCs), então ela normalmente nem chega até
    # aqui. Mas esta rota escreve no disco — por isso ela confere de novo em
    # vez de confiar cegamente no que a tela mandou. Reaproveita a mesma
    # função de scanner.py: é uma regra só, checada em dois pontos.
    if e_pasta_de_registro(nome_original):
        raise ErroDeMovimentacao(
            'pasta_protegida',
            f'"{nome_original}" é a pasta de registro (DOCs) e nunca é '
            'descontinuada. Nada foi movido.')

    campanha = _validar_segmento(peca.get('campanha'), 'campanha')
    canal = _validar_segmento(peca.get('canal'), 'canal')

    if not campanha:
        raise ErroDeMovimentacao(
            'sem_campanha',
            f'"{nome_original}" não está dentro de uma pasta de campanha, '
            'então não há estrutura para recriar. Mova manualmente.')

    destino_base = os.path.abspath(pasta_destino)

    # Estrutura de três níveis. O canal pode não existir (peça solta direto na
    # campanha): nesse caso a peça fica um nível acima, em vez de inventarmos
    # uma pasta de canal que não existe na origem.
    pasta_da_campanha = os.path.join(destino_base, campanha)
    pasta_do_canal = os.path.join(pasta_da_campanha, canal) if canal else pasta_da_campanha

    novo_nome = nome_descontinuado(nome_original, quando)
    destino_final = os.path.join(pasta_do_canal, novo_nome)

    if caminho_esta_dentro(destino_base, origem):
        raise ErroDeMovimentacao(
            'destino_dentro_da_origem',
            'A pasta Descontinuadas está dentro da própria peça. '
            'Escolha um destino fora dela.')

    # Conferido ANTES de criar qualquer pasta: assim uma peça bloqueada não
    # deixa para trás uma campanha vazia no destino.
    if os.path.exists(destino_final):
        raise ErroDeMovimentacao(
            'ja_existe',
            f'Já existe "{novo_nome}" em {campanha}'
            + (f'\\{canal}' if canal else '')
            + '. Nada foi movido.')

    try:
        # "Ctrl+C do nome idêntico": cria a campanha e o canal no destino se
        # ainda não existirem, e reaproveita se já existirem.
        os.makedirs(pasta_do_canal, exist_ok=True)
        shutil.move(origem, destino_final)
    except PermissionError:
        raise ErroDeMovimentacao(
            'sem_permissao',
            f'Sem permissão para mover "{nome_original}". '
            'Verifique se alguém está com a pasta aberta.')
    except OSError as erro:
        raise ErroDeMovimentacao(
            'falha_do_sistema',
            f'Falha ao mover "{nome_original}": {erro}')

    return {
        'nome_original': nome_original,
        'nome_novo': novo_nome,
        'campanha': campanha,
        'canal': canal,
        'origem': origem,
        'destino': destino_final,
    }


def mover_pecas(pecas, pasta_destino, quando=None):
    """Move várias peças, uma a uma, sem parar na primeira falha."""
    destino_base = validar_pasta_destino(pasta_destino)

    movidas = []
    falhas = []
    ja_processadas = set()

    for peca in pecas or []:
        caminho = (peca.get('caminho') or '').strip()
        if not caminho:
            continue

        chave = _normalizar(caminho)
        if chave in ja_processadas:
            continue
        ja_processadas.add(chave)

        try:
            movidas.append(mover_peca(peca, destino_base, quando))
        except ErroDeMovimentacao as erro:
            falhas.append({
                'caminho': caminho,
                'nome_original': os.path.basename(caminho.rstrip('\\/')),
                'campanha': peca.get('campanha') or '',
                'canal': peca.get('canal') or '',
                'motivo': erro.motivo,
                'mensagem': erro.mensagem,
            })

    return {'movidas': movidas, 'falhas': falhas, 'destino': destino_base}


# ------------------------------------------------------------------------------
# Desfazer: devolver a peça para de onde ela saiu
# ------------------------------------------------------------------------------

def devolver_peca(caminho_atual, caminho_original):
    """Move uma peça de Descontinuadas de volta ao caminho original.

    `caminho_original` é o caminho completo que a peça tinha em Disponíveis —
    o mesmo que `mover_peca` devolveu como 'origem'. Devolver para lá restaura
    de uma vez o lugar E o nome (sem o prefixo de data), sem precisar
    desmontar string nenhuma.
    """
    atual = (caminho_atual or '').strip()
    original = (caminho_original or '').strip()

    if not atual or not original:
        raise ErroDeMovimentacao(
            'devolucao_incompleta', 'Caminhos da devolução não informados.')

    if not os.path.exists(atual):
        raise ErroDeMovimentacao(
            'sumiu_do_destino',
            f'A peça não está mais em Descontinuadas: {atual}. '
            'Alguém pode tê-la movido depois.')

    if not os.path.isdir(atual):
        raise ErroDeMovimentacao(
            'origem_nao_e_pasta',
            f'O caminho informado não é uma pasta: {atual}')

    atual = os.path.abspath(atual)
    original = os.path.abspath(original)
    nome_original = os.path.basename(original.rstrip('\\/'))

    # A trava de sempre: nunca sobrescrever. Entre a descontinuação e o
    # arrependimento alguém pode ter recriado a peça no lugar de origem.
    if os.path.exists(original):
        raise ErroDeMovimentacao(
            'ja_existe_na_origem',
            f'Já existe "{nome_original}" no lugar de origem. '
            'Nada foi devolvido — confira antes, para não misturar versões.')

    try:
        # A pasta do canal pode ter sido apagada depois que esvaziou; recriar
        # é o que faz a devolução funcionar em vez de falhar por um detalhe.
        os.makedirs(os.path.dirname(original), exist_ok=True)
        shutil.move(atual, original)
    except PermissionError:
        raise ErroDeMovimentacao(
            'sem_permissao',
            f'Sem permissão para devolver "{nome_original}". '
            'Verifique se alguém está com a pasta aberta.')
    except OSError as erro:
        raise ErroDeMovimentacao(
            'falha_do_sistema',
            f'Falha ao devolver "{nome_original}": {erro}')

    return {
        'nome_original': nome_original,
        'de': atual,
        'para': original,
    }


def devolver_pecas(devolucoes):
    """Devolve várias peças, uma a uma, sem parar na primeira falha.

    `devolucoes` é uma lista de {atual, original}.
    """
    devolvidas = []
    falhas = []
    ja_processadas = set()

    for item in devolucoes or []:
        atual = (item.get('atual') or '').strip()
        original = (item.get('original') or '').strip()
        if not atual:
            continue

        chave = _normalizar(atual)
        if chave in ja_processadas:
            continue
        ja_processadas.add(chave)

        try:
            devolvidas.append(devolver_peca(atual, original))
        except ErroDeMovimentacao as erro:
            falhas.append({
                'atual': atual,
                'original': original,
                'nome_original': os.path.basename(original.rstrip('\\/')),
                'motivo': erro.motivo,
                'mensagem': erro.mensagem,
            })

    return {'devolvidas': devolvidas, 'falhas': falhas}
