@echo off
title CRM Bradesco - Orquestracao e Controle de Pecas
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 app.py
) else (
    python app.py
)

if errorlevel 1 (
    echo.
    echo Nao foi possivel iniciar. Verifique se o Python 3.12 esta instalado
    echo e disponivel no PATH ^(teste com: python --version^).
    pause
)
