"""Regras de negócio: parser de briefing/campanha, matriz de status e e-mails.

Portado sem alterações de comportamento do backend FastAPI original.
"""

import re
import uuid

from . import config

SEGMENTOS = ["Classic", "Exclusive", "Unif_PF", "Unif_NC", "Unif_PJ",
             "Unif_Prime", "Private", "Principal"]

AGENCIAS = ["ACCENTURE", "AG2", "Agência F&C", "Aldeiah", "BBDA",
            "Produtos + interno", "LBTM", "Leo Burnett", "P3K", "MMDemby",
            "Não informativo", "One.BRA", "Conexão Xpress", "ALMAP", "WIPRO", "CCP"]

TIPOS_CANAL = ["ATM", "EMKT", "IB", "NET_EMPRESA", "PUSH", "SMS", "MOBILE",
               "CLOUD PAGE", "WHATSAPP"]

CANAL_MAP = {
    "ATM": ["ATM - GC Informativo", "ATM - GC Ofertas", "ATM - SAIBA MAIS",
            "TELA DE ENCERRAMENTO", "ATM - TELA RANDOMICA"],
    "EMKT": ["CLOUD PAGE", "EMAIL MARKETING GENERICO",
             "EMAIL MARKETING PERSONALIZADO", "EMAIL MARKETING DISCLAIMER"],
    "IB": ["IB - BANNER TRANSPROMO", "IB - ENTRETELA", "MENSAGENS E AVISOS",
           "IB - TELA DE ENCERRAMENTO"],
    "MOBILE": ["MOBILE - CARDS", "MOBILE - MODAL"],
    "NET_EMPRESA": ["NE - BANNER TELA DE VENDAS", "NE - TELA DE ENCERRAMENTO",
                    "NE - TRANSPROMO"],
    "PUSH": ["PUSH PF", "PUSH PJ"],
    "SMS": ["SMS"],
    "CLOUD PAGE": ["CLOUD PAGE"],
    "WHATSAPP": ["WHATSAPP"],
}

POSSUI_LINK_OPCOES = ["Interno", "Externo", "Não possui"]
QTD_RESPOSTAS_OPCOES = [1, 2, 3, 4, 5]
STATUS_PECA_OPCOES = ["OK", "Ajustes", "Alt Validade", "Desconsiderada",
                      "Desconsiderada Alerta"]

STATUS_FILA_OPCOES = [
    {"value": "RECEBIDA", "desc": "Peça recebida e verificada. Grava no Controle como OK."},
    {"value": "Em Recebimento", "desc": "Peça em conferência com ajustes. Grava no Controle como Ajustes."},
    {"value": "FILA", "desc": "Nenhum analista assumiu. Bloqueia o processamento."},
    {"value": "Sem Retorno", "desc": "Sem resposta do Marketing. Gera e-mail de correção."},
    {"value": "Devolvida - Pendente", "desc": "Devolvida e pendente. Gera e-mail de correção."},
    {"value": "Devolvida - OK", "desc": "Devolvida OK. Gera e-mail de correção."},
    {"value": "Alt. Validade", "desc": "Alteração de validade. Grava no Controle e gera aviso."},
]

STATUS_MATRIX = {
    "RECEBIDA": {"escreve_controle": True, "status_peca": "OK", "template": "recebidas"},
    "Em Recebimento": {"escreve_controle": True, "status_peca": "Ajustes", "template": "ajuste_peca"},
    "FILA": {"escreve_controle": False, "bloqueado": True,
             "erro": "Nenhum analista assumiu a peça ainda. Não é possível prosseguir."},
    "Sem Retorno": {"escreve_controle": False, "template": "ajuste_peca"},
    "Devolvida - Pendente": {"escreve_controle": False, "template": "ajuste_peca"},
    "Devolvida - OK": {"escreve_controle": False, "template": "ajuste_peca"},
    "Alt. Validade": {"escreve_controle": True, "status_peca": "Alt Validade", "template": "alteracao_validade"},
}

CABECALHOS_EXCEL = ["Responsável", "Briefing", "Nome de Campanha", "Segmento", "Link da Pasta",
                    "Data de Entrega", "Data de Conferência", "Fim de Vigência", "Marketing", "Agência",
                    "Qtd Respostas", "Tipo de Canal (Mobile)", "Canal Esperado", "Status Peça",
                    "Observação", "Possui Link", "Status Fila", "Criador", "Pasta Renomeada", "Criado em"]

CAMPOS_EXCEL = ["responsavel", "briefing", "nome_campanha", "segmento", "link_pasta",
                "data_entrega", "data_conferencia", "fim_vigencia", "marketing", "agencia",
                "qtd_respostas", "tipo_canal", "canal_esperado", "status_peca",
                "observacao", "possui_link", "fila_status", "criador", "pasta_renomeada", "created_at"]

CAMPOS_PECA = ["criador", "assunto_email", "responsavel", "briefing", "nome_campanha", "segmento",
               "link_pasta", "data_entrega", "data_conferencia", "fim_vigencia", "marketing",
               "agencia", "qtd_respostas", "tipo_canal", "canal_esperado", "status_peca",
               "observacao", "possui_link"]


def nova_peca(dados: dict) -> dict:
    """Monta o documento completo da peça a partir dos campos do formulário."""
    peca = {campo: "" for campo in CAMPOS_PECA}
    peca.update({k: v for k, v in dados.items() if k in CAMPOS_PECA})
    try:
        peca["qtd_respostas"] = int(peca.get("qtd_respostas") or 0)
    except (TypeError, ValueError):
        peca["qtd_respostas"] = 0
    peca.update({
        "id": str(uuid.uuid4()),
        "fila_status": "",
        "template_tipo": "",
        "email_assunto": "",
        "email_corpo": "",
        "pasta_renomeada": "",
        "concluida": False,
        "historico": [],
        "created_at": config.agora_iso(),
        "updated_at": config.agora_iso(),
    })
    return peca


# ---------------- Parser inteligente ----------------

def parse_briefing(assunto: str):
    nums = re.findall(r"\d{4,9}", assunto or "")
    if not nums:
        return None
    n = nums[0]
    return n if len(n) >= 8 else n.zfill(8)


def parse_campanha(nome: str):
    n = (nome or "").upper()
    tipo, esperado = "", ""
    if "WHATSAPP" in n or "WPP" in n:
        tipo, esperado = "WHATSAPP", "WHATSAPP"
    elif "NET_EMPRESA" in n or re.search(r"(^|_)NE(_|$)", n):
        tipo = "NET_EMPRESA"
        if "VENDAS" in n:
            esperado = "NE - BANNER TELA DE VENDAS"
        elif "ENCERRAMENTO" in n:
            esperado = "NE - TELA DE ENCERRAMENTO"
        elif "TRANSPROMO" in n:
            esperado = "NE - TRANSPROMO"
    elif "CLOUD" in n and "PAGE" in n:
        tipo, esperado = "EMKT", "CLOUD PAGE"
    elif "EMKT" in n or "EMAIL" in n or "E_MAIL" in n:
        tipo = "EMKT"
        if "DISCLAIMER" in n:
            esperado = "EMAIL MARKETING DISCLAIMER"
        elif "PERS" in n:
            esperado = "EMAIL MARKETING PERSONALIZADO"
        elif "CLOUD" in n:
            esperado = "CLOUD PAGE"
        else:
            esperado = "EMAIL MARKETING GENERICO"
    elif "ATM" in n:
        tipo = "ATM"
        if "SAIBA" in n:
            esperado = "ATM - SAIBA MAIS"
        elif "RANDOMICA" in n:
            esperado = "ATM - TELA RANDOMICA"
        elif "ENCERRAMENTO" in n:
            esperado = "TELA DE ENCERRAMENTO"
        elif "OFERTA" in n or "_OFE" in n:
            esperado = "ATM - GC Ofertas"
        elif "INF" in n:
            esperado = "ATM - GC Informativo"
    elif "PUSH" in n:
        tipo = "PUSH"
        if re.search(r"_PJ(_|$)", n) or " PJ" in n:
            esperado = "PUSH PJ"
        elif re.search(r"_PF(_|$)", n) or " PF" in n or "_CLA" in n:
            esperado = "PUSH PF"
    elif "SMS" in n:
        tipo, esperado = "SMS", "SMS"
    elif "MOBILE" in n or "MODAL" in n or "CARDS" in n:
        tipo = "MOBILE"
        if "CARD" in n:
            esperado = "MOBILE - CARDS"
        elif "MODAL" in n:
            esperado = "MOBILE - MODAL"
    elif re.search(r"(^|_)IB(_|$)", n) or "INTERNET_BANKING" in n:
        tipo = "IB"
        if "TRANSPROMO" in n:
            esperado = "IB - BANNER TRANSPROMO"
        elif "ENTRETELA" in n:
            esperado = "IB - ENTRETELA"
        elif "AVISO" in n or "MENSAG" in n:
            esperado = "MENSAGENS E AVISOS"
        elif "ENCERRAMENTO" in n:
            esperado = "IB - TELA DE ENCERRAMENTO"
    return tipo, esperado


def parse_segmento(nome: str) -> str:
    n = (nome or "").upper()
    if "PRIVATE" in n or "_PVT" in n:
        return "Private"
    if "PRIME" in n:
        return "Unif_Prime"
    if "EXCLUSIVE" in n or "_EXC" in n:
        return "Exclusive"
    if "_PJ" in n:
        return "Unif_PJ"
    if "_NC" in n:
        return "Unif_NC"
    if "_CLA" in n or "CLASSIC" in n:
        return "Classic"
    if "_PF" in n:
        return "Unif_PF"
    return ""


def analisar(assunto: str, nome_campanha: str) -> dict:
    briefing = parse_briefing(assunto) or parse_briefing(nome_campanha) or ""
    tipo, esperado = parse_campanha(nome_campanha)
    return {
        "briefing": briefing,
        "link_pasta": f"{config.CAMINHO_REDE}\\{briefing}" if briefing else "",
        "tipo_canal": tipo,
        "canal_esperado": esperado,
        "segmento": parse_segmento(nome_campanha),
        "data_conferencia": config.agora().strftime("%d/%m/%Y"),
    }


# ---------------- E-mails padronizados ----------------

def saudacao_atual() -> str:
    h = config.agora().hour
    if h < 12:
        return "bom dia"
    if h < 18:
        return "boa tarde"
    return "boa noite"


def mm_aa(fim_vigencia: str) -> str:
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", fim_vigencia or "")
    if m:
        return f"{m.group(2)}.{m.group(3)[2:]}"
    m2 = re.search(r"(\d{4})-(\d{2})-(\d{2})", fim_vigencia or "")
    if m2:
        return f"{m2.group(2)}.{m2.group(1)[2:]}"
    return "__.__"


def montar_email(peca: dict, template_tipo: str, ajustes_detalhe: str = "",
                 validade_anterior: str = "") -> dict:
    saudacao = saudacao_atual()
    campanha = peca.get("nome_campanha") or "(nome da campanha)"
    canais = peca.get("tipo_canal") or "(canal)"
    analista = peca.get("responsavel") or peca.get("criador") or "(analista)"
    assinatura = f"Atenciosamente,\n{analista} | CRM Bradesco - Orquestração e Publicação"

    if template_tipo == "alteracao_validade":
        vig = mm_aa(peca.get("fim_vigencia", ""))
        ant = validade_anterior or vig
        assunto = f"Ajuste / Alteração de Validade - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As pastas abaixo tiveram a validade alterada, conforme solicitado.\n\n"
                 f"Canais: {canais}\n"
                 f"Campanha: {campanha}\n"
                 f"Alteração: De Val_{ant} para Val_ATE_{vig}\n\n"
                 f"{assinatura}")
    elif template_tipo == "recebidas":
        vig = mm_aa(peca.get("fim_vigencia", ""))
        assunto = f"Peças Recebidas - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As peças abaixo foram recebidas, verificadas e arquivadas em nosso controle.\n\n"
                 f"Canais: {canais}\n"
                 f"Validade: Val_ATE_{vig}\n\n"
                 f"{assinatura}")
    else:
        detalhe = ajustes_detalhe or peca.get("observacao") or "[Descrever aqui o detalhamento do ajuste]"
        assunto = f"Ajuste de Peça - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As peças abaixo necessitam de ajustes:\n\n"
                 f"Canais: {canais}\n"
                 f"Ajustes Necessários: {detalhe}\n\n"
                 f"{assinatura}")
    return {"assunto": assunto, "corpo": corpo, "saudacao": saudacao}


def calcular_stats(pecas: list) -> dict:
    por_status_peca, por_status_fila, por_canal = {}, {}, {}
    for p in pecas:
        if p.get("status_peca"):
            por_status_peca[p["status_peca"]] = por_status_peca.get(p["status_peca"], 0) + 1
        if p.get("fila_status"):
            por_status_fila[p["fila_status"]] = por_status_fila.get(p["fila_status"], 0) + 1
        if p.get("tipo_canal"):
            por_canal[p["tipo_canal"]] = por_canal.get(p["tipo_canal"], 0) + 1
    return {
        "total": len(pecas),
        "concluidas": sum(1 for p in pecas if p.get("concluida")),
        "no_controle": sum(1 for p in pecas if p.get("status_peca")),
        "por_status_peca": por_status_peca,
        "por_status_fila": por_status_fila,
        "por_canal": por_canal,
    }


def opcoes_frontend() -> dict:
    """Tudo que o formulário precisa, servido pela própria API."""
    return {
        "segmentos": SEGMENTOS,
        "agencias": AGENCIAS,
        "tipos_canal": TIPOS_CANAL,
        "canal_map": CANAL_MAP,
        "qtd_respostas": QTD_RESPOSTAS_OPCOES,
        "possui_link": POSSUI_LINK_OPCOES,
        "status_peca": STATUS_PECA_OPCOES,
        "status_fila": STATUS_FILA_OPCOES,
        "ia_disponivel": bool(config.IA_API_KEY),
    }
