"""Núcleo da aplicação: configuração, domínio, armazenamento, planilha e IA."""
