"""Configuração central — lê o arquivo .env sem depender do python-dotenv."""

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent


def carregar_env(caminho: Path = None) -> None:
    """Lê RAIZ/.env (formato CHAVE=valor) e joga em os.environ."""
    caminho = caminho or (RAIZ / ".env")
    if not caminho.exists():
        return
    for linha in caminho.read_text(encoding="utf-8-sig").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, valor = linha.split("=", 1)
        valor = valor.strip().strip('"').strip("'")
        os.environ.setdefault(chave.strip(), valor)


carregar_env()


def env(chave: str, padrao: str = "") -> str:
    return os.environ.get(chave, padrao).strip()


# ---------------- Fuso horário ----------------
# O Windows não traz o banco IANA; sem o pacote tzdata o ZoneInfo falha.
# Por isso caímos para UTC-3 fixo, que é o horário de Brasília atual.
try:
    from zoneinfo import ZoneInfo

    TZ = ZoneInfo("America/Sao_Paulo")
except Exception:  # pragma: no cover
    TZ = timezone(timedelta(hours=-3), "America/Sao_Paulo")


def agora() -> datetime:
    return datetime.now(TZ)


def agora_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------- Parâmetros ----------------
HOST = env("HOST", "127.0.0.1")
PORTA = int(env("PORTA", "8000") or 8000)
ABRIR_NAVEGADOR = env("ABRIR_NAVEGADOR", "1") == "1"

# "sqlite" (padrão — banco local, aguenta 100 mil+ linhas), "arquivo" (JSON
# em pasta local ou sincronizada do SharePoint, só recomendado para poucas
# peças), "mongo" ou "sqlserver" (plugáveis, exigem servidor rodando).
ARMAZENAMENTO = (env("ARMAZENAMENTO", "sqlite") or "sqlite").lower()

# Pasta onde os dados ficam. Aponte para a pasta do SharePoint sincronizada
# pelo OneDrive para usar o SharePoint como base, ex.:
# PASTA_DADOS=C:\Users\seu.usuario\Bradesco\CRM Orquestracao - Documentos\Base
PASTA_DADOS = Path(env("PASTA_DADOS", "") or (RAIZ / "dados"))
ARQUIVO_DADOS = PASTA_DADOS / env("ARQUIVO_DADOS", "base_pecas.json")
ARQUIVO_SQLITE = PASTA_DADOS / env("ARQUIVO_SQLITE", "base_pecas.db")

# Gera/atualiza uma planilha .xlsx ao lado do banco a cada gravação.
# É o que faz a pasta do SharePoint mostrar um Excel sempre atualizado.
ESPELHO_XLSX = env("ESPELHO_XLSX", "1") == "1"
ARQUIVO_XLSX = PASTA_DADOS / env("ARQUIVO_XLSX", "CONTROLE_DE_PECAS.xlsx")

MONGO_URL = env("MONGO_URL", "mongodb://localhost:27017")
MONGO_DB = env("DB_NAME", "crm_bradesco")

# SQL Server (opcional, plugável — exige "pip install pyodbc" e um driver ODBC
# instalado). Só usado se ARMAZENAMENTO=sqlserver.
SQLSERVER_DSN = env("SQLSERVER_DSN", "")  # string de conexão ODBC completa
SQLSERVER_SERVIDOR = env("SQLSERVER_SERVIDOR", "")
SQLSERVER_BANCO = env("SQLSERVER_BANCO", "crm_bradesco")

# Pasta onde você copia as planilhas .xlsx (Fila de Peças, Controle de Peças)
# para importar pela tela "Importar" do sistema.
PASTA_IMPORTAR = Path(env("PASTA_IMPORTAR", "") or (RAIZ / "importar"))

WEBHOOK_CRON_SECRET = env("WEBHOOK_CRON_SECRET", "")

# IA (opcional). Compatível com qualquer endpoint no padrão OpenAI.
IA_API_KEY = env("OPENAI_API_KEY", "") or env("IA_API_KEY", "")
IA_BASE_URL = env("IA_BASE_URL", "https://api.openai.com/v1").rstrip("/")
IA_MODELO = env("OPENAI_CHAT_MODEL", "") or env("IA_MODELO", "gpt-4o-mini")

CAMINHO_REDE = env("CAMINHO_REDE", r"\\corpbradesco\CRM\ORQUESTRACAO\DISPONIVEIS")
