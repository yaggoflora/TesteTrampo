"""Gerador de planilha .xlsx sem dependências externas.

Escreve o formato OpenXML diretamente com zipfile + XML da biblioteca padrão,
para não precisar instalar o openpyxl na máquina corporativa. O arquivo abre
normalmente no Excel, no LibreOffice e no SharePoint/Excel Online.
"""

import io
import zipfile
from xml.sax.saxutils import escape

from .dominio import CABECALHOS_EXCEL, CAMPOS_EXCEL

_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

_WORKBOOK_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1E293B"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def _coluna(indice: int) -> str:
    """1 -> A, 27 -> AA"""
    letras = ""
    while indice > 0:
        indice, resto = divmod(indice - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


def _celula(ref: str, valor, estilo: int = 0) -> str:
    s = f' s="{estilo}"' if estilo else ""
    if valor is None or valor == "":
        return f'<c r="{ref}"{s}/>'
    if isinstance(valor, bool):
        valor = "Sim" if valor else "Não"
    if isinstance(valor, (int, float)):
        return f'<c r="{ref}"{s}><v>{valor}</v></c>'
    texto = escape(str(valor)).replace("\r", "").replace("\n", "&#10;")
    return f'<c r="{ref}"{s} t="inlineStr"><is><t xml:space="preserve">{texto}</t></is></c>'


def gerar_xlsx(linhas: list, titulo: str = "Controle de Peças") -> bytes:
    """Recebe a lista de peças (dicts) e devolve os bytes do .xlsx."""
    partes = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
              '<sheetViews><sheetView workbookViewId="0">',
              '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>',
              '</sheetView></sheetViews>',
              '<cols>']
    for i, cab in enumerate(CABECALHOS_EXCEL, 1):
        largura = max(14, min(45, len(cab) + 8))
        partes.append(f'<col min="{i}" max="{i}" width="{largura}" customWidth="1"/>')
    partes.append("</cols><sheetData>")

    partes.append('<row r="1" ht="22" customHeight="1">')
    for i, cab in enumerate(CABECALHOS_EXCEL, 1):
        partes.append(_celula(f"{_coluna(i)}1", cab, estilo=1))
    partes.append("</row>")

    for n, linha in enumerate(linhas, 2):
        partes.append(f'<row r="{n}">')
        for i, campo in enumerate(CAMPOS_EXCEL, 1):
            partes.append(_celula(f"{_coluna(i)}{n}", linha.get(campo, "")))
        partes.append("</row>")

    ultima = _coluna(len(CABECALHOS_EXCEL))
    partes.append("</sheetData>")
    partes.append(f'<autoFilter ref="A1:{ultima}{max(1, len(linhas) + 1)}"/>')
    partes.append("</worksheet>")
    sheet = "".join(partes)

    workbook = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                f'<sheets><sheet name="{escape(titulo[:31])}" sheetId="1" r:id="rId1"/></sheets>'
                "</workbook>")

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES)
        z.writestr("_rels/.rels", _RELS)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", _WORKBOOK_RELS)
        z.writestr("xl/styles.xml", _STYLES)
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    return buffer.getvalue()
