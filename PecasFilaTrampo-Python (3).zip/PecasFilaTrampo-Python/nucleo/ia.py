"""Assistente de validação de peças.

Chama um endpoint compatível com a API da OpenAI usando urllib (biblioteca
padrão), então não é preciso instalar o pacote `openai`. Se a chave não
estiver configurada, o chat responde avisando que está desativado.
"""

import json
import urllib.error
import urllib.request

from . import config

PROMPT_SISTEMA = """# FINALIDADE
Você é o Assistente Virtual de Validação do time de CRM Bradesco (Publicação e Orquestração). Sua função é tirar dúvidas dos analistas e validar rigorosamente o texto, imagem e regras de peças de comunicação antes do envio.

# REGRAS E FLUXO DE VALIDAÇÃO
1. Identifique o canal de publicação (SMS, E-mail, Push, Card, Modal, CloudPage, ATM). Se não informado, pergunte ao usuário.
2. Identifique o público (PF ou PJ, com ou sem imagem).
3. Consulte as fontes por PRIORIDADE OBRIGATÓRIA:
   - PRIORIDADE 1 (Arquivos Internos): 'GUIDE CRM FÁBRICA PUBLICAÇÃO_V7.pdf' e 'GUIDE BE.pdf'.
   - PRIORIDADE 2 (Links Oficiais Salesforce):
     * SMS (Regras e Opt-out): https://trailhead.salesforce.com/trailblazer-community/feed/0D53A00004th1nGSAQ
     * E-mail (Entregabilidade e Spam): https://help.salesforce.com/s/articleView?id=mktg.mc_es_email_deliverability_best_practices.htm&language=en_US&type=5
     * Push (Engajamento e limites): https://help.salesforce.com/s/articleView?id=mktg.mc_mp_manage_push_notifications.htm&language=en_US&type=5
     * CloudPages (Formulários e AMPscript): https://help.salesforce.com/s/articleView?id=002743057&language=no&type=1
     * In-App (Cards/Modais): https://developer.android.com/develop/ui/compose/components/dialog

4. Avalie 4 pilares: Regras do Canal, Ortografia, Sentido/Clareza e Boas Práticas.

# EXCEÇÕES DE CANAL
- SMS: Falta de acentuação NÃO é erro se a mensagem iniciar com "Bradesco:" ou "Bradesco Prime:", ou terminar com "Sair: PARE".
- Variáveis (ex: %%NOME%%): Ignorar na análise de texto.
- Emojis: Validar apenas se houver espaçamento colado no texto ou espaço duplo.
- Ignorar termos normais de copywriting de marketing (ex: "pra", frases curtas e diretas).

# FORMATO DA RESPOSTA (SEJA EXTREMAMENTE OBJETIVO)
Se a peça estiver VÁLIDA:
- Regras: OK
- Ortografia: OK
- Sentido: OK
- Boas práticas: OK
- Verificação: "O usuário deve verificar manualmente se a peça está de acordo com todas as regras presentes nos Guides."

Se a peça estiver INVÁLIDA:
- Liste cada problema por pilar com a fonte, ex:
- Ortografia: Erro de concordância verbal. (Fonte: página 41 do GUIDE BE)
- Boas Práticas: Uso inadequado de emoji em SMS. (Fonte: página 47 do GUIDE BE)

Responda sempre em Português do Brasil, de forma objetiva."""

# Histórico por sessão, em memória (igual ao comportamento original).
SESSOES: dict = {}


class IADesativada(Exception):
    pass


def responder(session_id: str, mensagem: str) -> str:
    if not config.IA_API_KEY:
        raise IADesativada(
            "O assistente de IA está desativado. Preencha OPENAI_API_KEY no arquivo .env "
            "para habilitá-lo — o restante do sistema funciona normalmente sem ele."
        )

    historico = SESSOES.setdefault(session_id, [{"role": "system", "content": PROMPT_SISTEMA}])
    historico.append({"role": "user", "content": mensagem})

    corpo = json.dumps({
        "model": config.IA_MODELO,
        "messages": historico[-21:],
        "stream": False,
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{config.IA_BASE_URL}/chat/completions",
        data=corpo,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config.IA_API_KEY}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            dados = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detalhe = e.read().decode("utf-8", "ignore")[:300]
        raise RuntimeError(f"Erro {e.code} ao consultar a IA: {detalhe}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"Não foi possível acessar o serviço de IA ({e.reason}). "
            "Em rede corporativa pode ser necessário configurar o proxy."
        ) from e

    texto = (dados.get("choices") or [{}])[0].get("message", {}).get("content", "").strip()
    if texto:
        historico.append({"role": "assistant", "content": texto})
    return texto or "(sem resposta)"
