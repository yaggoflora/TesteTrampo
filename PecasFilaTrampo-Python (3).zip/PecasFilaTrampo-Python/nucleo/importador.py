"""Importação de planilhas .xlsx grandes (Fila de Peças, Controle de Peças)
para o banco do sistema.

Só depende de uma biblioteca externa — openpyxl — e só quando você realmente
for importar uma planilha (o resto do sistema continua 100% biblioteca
padrão). Para instalar: pip install openpyxl

Fluxo:
1. Copie os arquivos .xlsx para a pasta configurada em PASTA_IMPORTAR
   (por padrão, a pasta "importar" dentro do projeto).
2. Na tela "Importar" do sistema, escolha o arquivo -> o sistema detecta as
   colunas da primeira linha e sugere um mapeamento automático.
3. Confira/ajuste o mapeamento coluna da planilha -> campo do sistema.
4. Confirme a importação. Nenhuma coluna é descartada: o que não é mapeado
   para um campo conhecido é guardado do mesmo jeito (em "extra_json"), então
   nada da planilha original se perde.
"""

import uuid

from . import config, dominio

# Campos que uma linha importada pode preencher. "(ignorar)" descarta a
# coluna; qualquer outro nome de coluna da planilha que não apareça no
# mapeamento vai, mesmo assim, para o extra_json (nada se perde).
CAMPOS_IMPORTAVEIS = dominio.CAMPOS_PECA + [
    "fila_status", "status_peca", "concluida", "created_at", "pasta_renomeada",
]

# Sinônimos comuns em planilhas de Fila/Controle de Peças, usados só para
# sugerir automaticamente o mapeamento — o usuário sempre confere antes de
# importar.
_SINONIMOS = {
    "responsavel": ["responsável", "responsavel", "analista"],
    "briefing": ["briefing", "nº briefing", "numero briefing", "cod briefing"],
    "nome_campanha": ["nome de campanha", "nome da campanha", "campanha"],
    "segmento": ["segmento"],
    "link_pasta": ["link da pasta", "link pasta", "pasta"],
    "data_entrega": ["data de entrega", "data entrega"],
    "data_conferencia": ["data de conferência", "data de conferencia", "data conferencia"],
    "fim_vigencia": ["fim de vigência", "fim de vigencia", "vigencia", "validade"],
    "marketing": ["marketing"],
    "agencia": ["agência", "agencia"],
    "qtd_respostas": ["qtd respostas", "quantidade de respostas", "qtd. respostas"],
    "tipo_canal": ["tipo de canal", "tipo de canal (mobile)", "canal"],
    "canal_esperado": ["canal esperado"],
    "status_peca": ["status peça", "status peca", "status"],
    "observacao": ["observação", "observacao", "obs"],
    "possui_link": ["possui link"],
    "fila_status": ["status fila", "status da fila"],
    "criador": ["criador", "criado por"],
    "pasta_renomeada": ["pasta renomeada"],
    "created_at": ["criado em", "data de criação", "data criacao"],
    "assunto_email": ["assunto", "assunto do e-mail", "assunto email"],
}


def _normalizar(texto: str) -> str:
    return (texto or "").strip().lower()


def _abrir_workbook(caminho):
    try:
        import openpyxl
    except ImportError as e:
        raise RuntimeError(
            "Importar planilhas exige o pacote openpyxl (só para esta função — "
            "o resto do sistema não precisa). Rode no terminal: "
            "pip install openpyxl"
        ) from e
    return openpyxl.load_workbook(caminho, read_only=True, data_only=True)


def listar_planilhas_disponiveis() -> list:
    config.PASTA_IMPORTAR.mkdir(parents=True, exist_ok=True)
    return sorted(p.name for p in config.PASTA_IMPORTAR.glob("*.xlsx"))


def detectar_colunas(nome_arquivo: str, aba: str = "") -> dict:
    caminho = config.PASTA_IMPORTAR / nome_arquivo
    if not caminho.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado em {config.PASTA_IMPORTAR}: {nome_arquivo}")

    wb = _abrir_workbook(caminho)
    abas = wb.sheetnames
    ws = wb[aba] if aba and aba in abas else wb.active
    primeira_linha = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), ())
    colunas = [str(c).strip() if c not in (None, "") else f"(coluna {i + 1})"
               for i, c in enumerate(primeira_linha)]
    total_linhas = max((ws.max_row or 1) - 1, 0)
    wb.close()

    sugestao = {}
    for coluna in colunas:
        alvo = ""
        norm = _normalizar(coluna)
        for campo, sinonimos in _SINONIMOS.items():
            if norm == campo or norm in sinonimos:
                alvo = campo
                break
        sugestao[coluna] = alvo

    return {
        "abas": abas,
        "aba_selecionada": ws.title,
        "colunas": colunas,
        "sugestao_mapeamento": sugestao,
        "total_linhas_estimado": total_linhas,
        "campos_disponiveis": CAMPOS_IMPORTAVEIS,
    }


def executar_importacao(store, nome_arquivo: str, mapeamento: dict, origem: str,
                          aba: str = "", tamanho_lote: int = 2000) -> dict:
    """Lê a planilha em streaming (sem carregar tudo na memória) e grava em
    lotes. `mapeamento` é {coluna_da_planilha: campo_do_sistema | ""}."""
    if not hasattr(store, "inserir_pecas_lote") or store.tipo not in ("sqlite",):
        raise RuntimeError(
            "Importação em massa só é recomendada com ARMAZENAMENTO=sqlite "
            "(o back-end atual reescreveria o arquivo inteiro a cada lote, "
            "o que é lento e arriscado para dezenas de milhares de linhas)."
        )

    caminho = config.PASTA_IMPORTAR / nome_arquivo
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {nome_arquivo}")

    wb = _abrir_workbook(caminho)
    ws = wb[aba] if aba and aba in wb.sheetnames else wb.active
    linhas_iter = ws.iter_rows(min_row=1, values_only=True)
    cabecalho = next(linhas_iter, ())
    colunas = [str(c).strip() if c not in (None, "") else f"(coluna {i + 1})"
               for i, c in enumerate(cabecalho)]

    total_importadas = 0
    total_ignoradas = 0
    lote = []
    agora = config.agora_iso()

    for linha in linhas_iter:
        valores = dict(zip(colunas, linha))
        # se a linha inteira estiver vazia, pula
        if not any(v not in (None, "") for v in valores.values()):
            continue

        peca = {campo: "" for campo in dominio.CAMPOS_PECA}
        extras = {}
        for coluna, valor in valores.items():
            campo = mapeamento.get(coluna, "")
            texto = "" if valor is None else str(valor).strip()
            if not campo:
                if texto:
                    extras[coluna] = texto
                continue
            if campo == "concluida":
                peca[campo] = texto.lower() in ("1", "true", "sim", "verdadeiro", "x")
            elif campo == "qtd_respostas":
                try:
                    peca[campo] = int(float(texto)) if texto else 0
                except ValueError:
                    peca[campo] = 0
            else:
                peca[campo] = texto

        if extras:
            peca.update(extras)

        peca["id"] = str(uuid.uuid4())
        peca.setdefault("fila_status", "")
        peca.setdefault("template_tipo", "")
        peca.setdefault("email_assunto", "")
        peca.setdefault("email_corpo", "")
        peca.setdefault("pasta_renomeada", "")
        peca.setdefault("concluida", False)
        peca["origem_importacao"] = origem
        peca["created_at"] = peca.get("created_at") or agora
        peca["updated_at"] = agora
        peca["historico"] = [{
            "acao": f"Importada da planilha '{nome_arquivo}' ({origem})",
            "data": agora,
        }]

        lote.append(peca)
        if len(lote) >= tamanho_lote:
            total_importadas += store.inserir_pecas_lote(lote)
            lote = []

    if lote:
        total_importadas += store.inserir_pecas_lote(lote)

    wb.close()
    return {"importadas": total_importadas, "ignoradas": total_ignoradas, "arquivo": nome_arquivo}
