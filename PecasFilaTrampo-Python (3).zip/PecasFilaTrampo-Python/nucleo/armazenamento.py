"""Camada de dados com back-ends intercambiáveis.

- "sqlite": banco local em arquivo único, biblioteca padrão do Python (zero
  instalação). Recomendado — aguenta 100 mil+ linhas numa boa. É o padrão.
- "arquivo": um JSON em disco (pode ser a pasta do SharePoint sincronizada
  pelo OneDrive). Simples, mas reescreve o arquivo inteiro a cada gravação —
  só recomendado para poucas centenas de peças.
- "mongo": MongoDB local via pymongo, caso você prefira banco (exige servidor
  MongoDB rodando + `pip install pymongo`).
- "sqlserver": SQL Server via pyodbc, plugável para quando você já tiver
  testado a conexão nesse PC (exige driver ODBC + `pip install pyodbc`).

O resto do sistema só enxerga esta interface (listar/obter/inserir/atualizar/
excluir peças, backups e chat), então trocar de back-end é mudar uma linha
do .env — nada mais do sistema precisa mudar.
"""

import gzip
import json
import os
import shutil
import sqlite3
import tempfile
import threading
import uuid

from . import config
from .planilha import gerar_xlsx

_BASE_VAZIA = {"pecas": [], "backups": [], "chat": []}


class ArmazenamentoArquivo:
    """Guarda tudo em um único JSON, com escrita atômica."""

    tipo = "arquivo"

    def __init__(self, caminho=None, espelho_xlsx=None):
        self.caminho = caminho or config.ARQUIVO_DADOS
        self.espelho = config.ESPELHO_XLSX if espelho_xlsx is None else espelho_xlsx
        self._lock = threading.RLock()
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        if not self.caminho.exists():
            self._gravar(dict(_BASE_VAZIA))

    # ---- baixo nível ----
    def _ler(self) -> dict:
        try:
            with open(self.caminho, "r", encoding="utf-8") as f:
                base = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {k: list(v) for k, v in _BASE_VAZIA.items()}
        for chave in _BASE_VAZIA:
            base.setdefault(chave, [])
        return base

    def _gravar(self, base: dict) -> None:
        destino = self.caminho
        destino.parent.mkdir(parents=True, exist_ok=True)
        # grava em arquivo temporário e substitui: evita base corrompida se o
        # OneDrive sincronizar no meio da escrita ou o programa for fechado.
        fd, temp = tempfile.mkstemp(dir=str(destino.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(base, f, ensure_ascii=False, indent=2)
            os.replace(temp, destino)
        except Exception:
            if os.path.exists(temp):
                os.unlink(temp)
            raise
        if self.espelho:
            self._espelhar_xlsx(base.get("pecas", []))

    def _espelhar_xlsx(self, pecas: list) -> None:
        try:
            conteudo = gerar_xlsx([p for p in pecas if p.get("status_peca")])
            destino = config.ARQUIVO_XLSX
            destino.parent.mkdir(parents=True, exist_ok=True)
            fd, temp = tempfile.mkstemp(dir=str(destino.parent), suffix=".tmp")
            with os.fdopen(fd, "wb") as f:
                f.write(conteudo)
            os.replace(temp, destino)
        except Exception as e:  # o espelho nunca pode derrubar a gravação
            print(f"[aviso] não foi possível atualizar o espelho .xlsx: {e}")

    def _alterar(self, funcao):
        with self._lock:
            base = self._ler()
            resultado = funcao(base)
            self._gravar(base)
            return resultado

    # ---- peças ----
    def listar_pecas(self) -> list:
        with self._lock:
            pecas = self._ler()["pecas"]
        return sorted(pecas, key=lambda p: p.get("created_at", ""), reverse=True)

    def obter_peca(self, peca_id: str):
        with self._lock:
            for p in self._ler()["pecas"]:
                if p.get("id") == peca_id:
                    return p
        return None

    def inserir_peca(self, peca: dict) -> dict:
        def acao(base):
            base["pecas"].append(peca)
            return peca
        return self._alterar(acao)

    def inserir_pecas_lote(self, pecas: list) -> int:
        """Importação em massa. Existe por compatibilidade, mas o back-end
        'arquivo' reescreve o JSON inteiro a cada chamada — para 40-60 mil
        linhas isso é lento e não é recomendado. Use ARMAZENAMENTO=sqlite
        para importar planilhas grandes."""
        def acao(base):
            base["pecas"].extend(pecas)
            return len(pecas)
        return self._alterar(acao)

    def atualizar_peca(self, peca_id: str, campos: dict, historico: dict = None):
        def acao(base):
            for p in base["pecas"]:
                if p.get("id") == peca_id:
                    p.update(campos)
                    if historico:
                        p.setdefault("historico", []).append(historico)
                    return p
            return None
        return self._alterar(acao)

    def excluir_peca(self, peca_id: str) -> bool:
        def acao(base):
            antes = len(base["pecas"])
            base["pecas"] = [p for p in base["pecas"] if p.get("id") != peca_id]
            return len(base["pecas"]) < antes
        return self._alterar(acao)

    # ---- backups ----
    def listar_backups(self) -> list:
        with self._lock:
            backups = self._ler()["backups"]
        resumo = [{k: v for k, v in b.items() if k != "data"} for b in backups]
        return sorted(resumo, key=lambda b: b.get("created_at", ""), reverse=True)

    def inserir_backup(self, backup: dict) -> dict:
        def acao(base):
            base["backups"].append(backup)
            return {k: v for k, v in backup.items() if k != "data"}
        return self._alterar(acao)

    def obter_backup(self, backup_id: str):
        with self._lock:
            for b in self._ler()["backups"]:
                if b.get("id") == backup_id:
                    return b
        return None

    # ---- chat ----
    def inserir_chat(self, mensagem: dict) -> None:
        def acao(base):
            base["chat"].append(mensagem)
            base["chat"] = base["chat"][-500:]
        self._alterar(acao)

    def listar_chat(self, session_id: str) -> list:
        with self._lock:
            msgs = [m for m in self._ler()["chat"] if m.get("session_id") == session_id]
        return sorted(msgs, key=lambda m: m.get("created_at", ""))

    def descricao(self) -> str:
        extra = f" (+ espelho {config.ARQUIVO_XLSX.name})" if self.espelho else ""
        return f"arquivo JSON em {self.caminho}{extra}"


class ArmazenamentoMongo:
    """Mesma interface, usando MongoDB via pymongo (síncrono)."""

    tipo = "mongo"

    def __init__(self, url=None, banco=None):
        try:
            from pymongo import MongoClient
        except ImportError as e:
            raise RuntimeError(
                "ARMAZENAMENTO=mongo exige o pymongo. Rode: pip install pymongo"
            ) from e
        self.cliente = MongoClient(url or config.MONGO_URL, serverSelectionTimeoutMS=5000)
        self.db = self.cliente[banco or config.MONGO_DB]
        self.db.pecas.create_index("id", unique=True)
        self.db.backups.create_index("id", unique=True)

    def listar_pecas(self) -> list:
        return list(self.db.pecas.find({}, {"_id": 0}).sort("created_at", -1).limit(5000))

    def obter_peca(self, peca_id: str):
        return self.db.pecas.find_one({"id": peca_id}, {"_id": 0})

    def inserir_peca(self, peca: dict) -> dict:
        self.db.pecas.insert_one(dict(peca))
        return peca

    def inserir_pecas_lote(self, pecas: list) -> int:
        if not pecas:
            return 0
        self.db.pecas.insert_many([dict(p) for p in pecas])
        return len(pecas)

    def atualizar_peca(self, peca_id: str, campos: dict, historico: dict = None):
        update = {"$set": campos}
        if historico:
            update["$push"] = {"historico": historico}
        res = self.db.pecas.update_one({"id": peca_id}, update)
        if res.matched_count == 0:
            return None
        return self.obter_peca(peca_id)

    def excluir_peca(self, peca_id: str) -> bool:
        return self.db.pecas.delete_one({"id": peca_id}).deleted_count > 0

    def listar_backups(self) -> list:
        return list(self.db.backups.find({}, {"_id": 0, "data": 0}).sort("created_at", -1).limit(200))

    def inserir_backup(self, backup: dict) -> dict:
        self.db.backups.insert_one(dict(backup))
        return {k: v for k, v in backup.items() if k != "data"}

    def obter_backup(self, backup_id: str):
        return self.db.backups.find_one({"id": backup_id}, {"_id": 0})

    def inserir_chat(self, mensagem: dict) -> None:
        self.db.chat_messages.insert_one(dict(mensagem))

    def listar_chat(self, session_id: str) -> list:
        return list(self.db.chat_messages.find({"session_id": session_id}, {"_id": 0})
                    .sort("created_at", 1).limit(200))

    def descricao(self) -> str:
        return f"MongoDB {config.MONGO_URL} / banco {config.MONGO_DB}"


class ArmazenamentoSQLite:
    """Banco local em arquivo único (sqlite3, biblioteca padrão — zero
    instalação). Recomendado para bases grandes (dezenas de milhares de
    linhas, como planilhas importadas): cada operação só lê/grava o que
    precisa, ao contrário do back-end 'arquivo' que reescreve tudo."""

    tipo = "sqlite"

    # Colunas "de primeira classe" — todo o resto (campos que a planilha
    # importada tinha e o sistema não conhece) vai para "extra_json", sem
    # perder nenhum dado da origem.
    _COLUNAS_PECA = [
        "id", "criador", "assunto_email", "responsavel", "briefing", "nome_campanha",
        "segmento", "link_pasta", "data_entrega", "data_conferencia", "fim_vigencia",
        "marketing", "agencia", "qtd_respostas", "tipo_canal", "canal_esperado",
        "status_peca", "observacao", "possui_link", "fila_status", "template_tipo",
        "email_assunto", "email_corpo", "pasta_renomeada", "concluida",
        "created_at", "updated_at", "origem_importacao",
    ]

    def __init__(self, caminho=None):
        self.caminho = caminho or config.ARQUIVO_SQLITE
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conexao = sqlite3.connect(str(self.caminho), check_same_thread=False)
        self._conexao.row_factory = sqlite3.Row
        self._conexao.execute("PRAGMA journal_mode=WAL")
        self._conexao.execute("PRAGMA synchronous=NORMAL")
        self._criar_tabelas()

    def _criar_tabelas(self):
        colunas_sql = ", ".join(f"{c} TEXT" if c not in ("qtd_respostas", "concluida")
                                 else f"{c} INTEGER" for c in self._COLUNAS_PECA)
        with self._lock, self._conexao:
            self._conexao.execute(f"""
                CREATE TABLE IF NOT EXISTS pecas (
                    {colunas_sql},
                    historico TEXT,
                    extra_json TEXT,
                    PRIMARY KEY (id)
                )
            """)
            for indice, coluna in (("idx_pecas_status_fila", "fila_status"),
                                    ("idx_pecas_status_peca", "status_peca"),
                                    ("idx_pecas_created", "created_at"),
                                    ("idx_pecas_briefing", "briefing")):
                self._conexao.execute(f"CREATE INDEX IF NOT EXISTS {indice} ON pecas({coluna})")
            self._conexao.execute("""
                CREATE TABLE IF NOT EXISTS backups (
                    id TEXT PRIMARY KEY, nome TEXT, tipo TEXT,
                    total_pecas INTEGER, created_at TEXT, dados BLOB
                )
            """)
            self._conexao.execute("""
                CREATE TABLE IF NOT EXISTS chat (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT,
                    role TEXT, content TEXT, created_at TEXT
                )
            """)

    # ---- conversão dict <-> linha ----
    def _para_linha(self, peca: dict) -> tuple:
        extras = {k: v for k, v in peca.items()
                  if k not in self._COLUNAS_PECA and k != "historico"}
        valores = []
        for c in self._COLUNAS_PECA:
            v = peca.get(c, "")
            if c == "concluida":
                v = 1 if v else 0
            elif c == "qtd_respostas":
                try:
                    v = int(v or 0)
                except (TypeError, ValueError):
                    v = 0
            valores.append(v)
        valores.append(json.dumps(peca.get("historico") or [], ensure_ascii=False))
        valores.append(json.dumps(extras, ensure_ascii=False) if extras else None)
        return tuple(valores)

    def _de_linha(self, linha: sqlite3.Row) -> dict:
        peca = {c: linha[c] for c in self._COLUNAS_PECA}
        peca["concluida"] = bool(peca["concluida"])
        try:
            peca["historico"] = json.loads(linha["historico"] or "[]")
        except json.JSONDecodeError:
            peca["historico"] = []
        if linha["extra_json"]:
            try:
                peca.update(json.loads(linha["extra_json"]))
            except json.JSONDecodeError:
                pass
        return peca

    # ---- peças ----
    def listar_pecas(self) -> list:
        with self._lock:
            linhas = self._conexao.execute(
                "SELECT * FROM pecas ORDER BY created_at DESC").fetchall()
        return [self._de_linha(l) for l in linhas]

    def obter_peca(self, peca_id: str):
        with self._lock:
            linha = self._conexao.execute(
                "SELECT * FROM pecas WHERE id = ?", (peca_id,)).fetchone()
        return self._de_linha(linha) if linha else None

    def inserir_peca(self, peca: dict) -> dict:
        colunas = self._COLUNAS_PECA + ["historico", "extra_json"]
        marcadores = ", ".join("?" for _ in colunas)
        with self._lock, self._conexao:
            self._conexao.execute(
                f"INSERT INTO pecas ({', '.join(colunas)}) VALUES ({marcadores})",
                self._para_linha(peca))
        return peca

    def inserir_pecas_lote(self, pecas: list) -> int:
        """Usado pela importação de planilhas grandes: uma única transação
        para milhares de linhas (muito mais rápido que inserir uma a uma)."""
        if not pecas:
            return 0
        colunas = self._COLUNAS_PECA + ["historico", "extra_json"]
        marcadores = ", ".join("?" for _ in colunas)
        linhas = [self._para_linha(p) for p in pecas]
        with self._lock, self._conexao:
            self._conexao.executemany(
                f"INSERT OR REPLACE INTO pecas ({', '.join(colunas)}) VALUES ({marcadores})",
                linhas)
        return len(pecas)

    def atualizar_peca(self, peca_id: str, campos: dict, historico: dict = None):
        with self._lock:
            atual = self.obter_peca(peca_id)
            if not atual:
                return None
            atual.update(campos)
            if historico:
                atual.setdefault("historico", []).append(historico)
            colunas = self._COLUNAS_PECA + ["historico", "extra_json"]
            atribuicoes = ", ".join(f"{c} = ?" for c in colunas)
            with self._conexao:
                self._conexao.execute(
                    f"UPDATE pecas SET {atribuicoes} WHERE id = ?",
                    self._para_linha(atual) + (peca_id,))
        return atual

    def excluir_peca(self, peca_id: str) -> bool:
        with self._lock, self._conexao:
            cursor = self._conexao.execute("DELETE FROM pecas WHERE id = ?", (peca_id,))
        return cursor.rowcount > 0

    # ---- backups ----
    def listar_backups(self) -> list:
        with self._lock:
            linhas = self._conexao.execute(
                "SELECT id, nome, tipo, total_pecas, created_at FROM backups "
                "ORDER BY created_at DESC").fetchall()
        return [dict(l) for l in linhas]

    def inserir_backup(self, backup: dict) -> dict:
        dados_comprimidos = gzip.compress(
            json.dumps(backup.get("data", []), ensure_ascii=False).encode("utf-8"))
        with self._lock, self._conexao:
            self._conexao.execute(
                "INSERT INTO backups (id, nome, tipo, total_pecas, created_at, dados) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (backup["id"], backup["nome"], backup["tipo"], backup["total_pecas"],
                 backup["created_at"], dados_comprimidos))
        return {k: v for k, v in backup.items() if k != "data"}

    def obter_backup(self, backup_id: str):
        with self._lock:
            linha = self._conexao.execute(
                "SELECT * FROM backups WHERE id = ?", (backup_id,)).fetchone()
        if not linha:
            return None
        doc = {k: linha[k] for k in linha.keys() if k != "dados"}
        doc["data"] = json.loads(gzip.decompress(linha["dados"]).decode("utf-8"))
        return doc

    # ---- chat ----
    def inserir_chat(self, mensagem: dict) -> None:
        with self._lock, self._conexao:
            self._conexao.execute(
                "INSERT INTO chat (session_id, role, content, created_at) VALUES (?, ?, ?, ?)",
                (mensagem["session_id"], mensagem["role"], mensagem["content"], mensagem["created_at"]))

    def listar_chat(self, session_id: str) -> list:
        with self._lock:
            linhas = self._conexao.execute(
                "SELECT session_id, role, content, created_at FROM chat "
                "WHERE session_id = ? ORDER BY created_at ASC", (session_id,)).fetchall()
        return [dict(l) for l in linhas]

    def descricao(self) -> str:
        return f"SQLite em {self.caminho}"


class ArmazenamentoSQLServer:
    """Plugável para quando a conexão com o SQL Server corporativo já
    estiver testada nesse PC. Mesma interface das outras classes."""

    tipo = "sqlserver"

    def __init__(self):
        try:
            import pyodbc  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "ARMAZENAMENTO=sqlserver exige o pyodbc e um driver ODBC do "
                "SQL Server instalado. Rode: pip install pyodbc — e configure "
                "SQLSERVER_DSN (ou SQLSERVER_SERVIDOR/SQLSERVER_BANCO) no .env."
            ) from e
        raise RuntimeError(
            "Back-end SQL Server ainda não foi implementado neste projeto — "
            "só a checagem de pré-requisitos está pronta. Use ARMAZENAMENTO="
            "sqlite (recomendado) até validarmos juntos a conexão e o schema "
            "no SQL Server."
        )


def criar_armazenamento():
    if config.ARMAZENAMENTO == "mongo":
        return ArmazenamentoMongo()
    if config.ARMAZENAMENTO == "sqlserver":
        return ArmazenamentoSQLServer()
    if config.ARMAZENAMENTO == "arquivo":
        return ArmazenamentoArquivo()
    return ArmazenamentoSQLite()


def criar_backup(store, tipo: str) -> dict:
    """Snapshot congelado da base, igual ao backup quinzenal original."""
    pecas = store.listar_pecas()
    nome = f"BACKUP_CONTROLE_CRM_{config.agora().strftime('%Y_%m_%d')}.xlsx"
    doc = {
        "id": str(uuid.uuid4()),
        "nome": nome,
        "tipo": tipo,
        "total_pecas": len(pecas),
        "created_at": config.agora_iso(),
        "data": pecas,
    }
    return store.inserir_backup(doc)


def exportar_copia_local(destino, store) -> None:
    """Cópia avulsa do JSON (usada pelo backup em pasta, se desejar)."""
    shutil.copy2(store.caminho, destino)
