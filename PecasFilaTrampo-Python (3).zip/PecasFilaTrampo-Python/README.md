# CRM Bradesco — Orquestração e Controle de Peças (versão Python)

Mesma aplicação de antes, com todas as funcionalidades, mas rodando **só com
Python 3.12**. Não precisa de Node.js, nem de `pip install`, nem de banco de
dados obrigatório.

## Como rodar

1. Instale o **Python 3.12** (veja abaixo) — é a única coisa que precisa
   estar instalada na máquina para rodar o sistema no dia a dia.
2. Descompacte a pasta em qualquer lugar (ex.: `C:\Ferramentas\CRM-Pecas`).
3. Dê duplo clique em **`INICIAR.bat`** — ou, no VS Code, abra a pasta e rode
   `python app.py` no terminal.
4. O navegador abre sozinho em `http://127.0.0.1:8000`.

Para encerrar, feche a janela preta ou pressione `Ctrl+C`.

Se for **importar planilhas** (aba "Importar"), rode uma vez, antes:
`pip install openpyxl` — é a única dependência externa do projeto, e só
necessária para essa função.

## O que mudou em relação à versão anterior

| Antes | Agora |
|---|---|
| FastAPI + uvicorn + motor + openpyxl + openai (`pip install`) | Biblioteca padrão do Python — zero instalação (exceto para importar planilhas) |
| React + Tailwind + shadcn (`yarn install`, Node 18) | HTML, CSS e JavaScript puros servidos pelo próprio Python |
| MongoDB obrigatório | **SQLite** (padrão) — ou JSON, MongoDB, à sua escolha |
| Backup por webhook/cron externo | Agendador interno (dias 1 e 16, a cada ~15 dias), mais o botão manual |
| Chat com streaming via pacote `openai` | Chat via `urllib`, resposta completa de uma vez |
| Importar planilhas existentes | Tela **"Importar"**, com mapeamento de colunas |

Nada foi retirado: assistente de 5 etapas, parser de briefing e nomenclatura,
matriz de status Fila ↔ Controle, geração de e-mails com saudação automática,
tabelas, painel, exportação `.xlsx`, backups e o assistente de validação.

## Banco de dados: SQLite (padrão)

O sistema usa **SQLite** por padrão — um banco de verdade (com índices, não um
arquivo texto reescrito inteiro a cada gravação), mas que é biblioteca padrão
do Python: zero instalação, zero servidor rodando, um único arquivo
(`dados/base_pecas.db`) que aguenta bem mais que as 100 mil linhas das suas
duas planilhas. É a razão de não termos partido direto para MongoDB ou SQL
Server: nenhum dos dois traz vantagem real aqui, e os dois exigiriam um
servidor rodando (o SQL Server, no seu caso, nem testado ainda foi).

O SQL Server fica **plugável** para o futuro: quando quiser, testamos juntos a
conexão nesse PC e ativamos com `ARMAZENAMENTO=sqlserver` no `.env`, sem
reescrever o resto do sistema — a estrutura para isso já está pronta em
`nucleo/armazenamento.py`, só falta implementar depois que a conexão estiver
validada. MongoDB continua disponível do mesmo jeito (`ARMAZENAMENTO=mongo`),
caso você já tenha um servidor rodando.

## Importando as planilhas (Fila de Peças, Controle de Peças)

1. Copie os arquivos `.xlsx` para a pasta `importar/` dentro do projeto (ou
   aponte `PASTA_IMPORTAR` no `.env` para outro lugar).
2. Rode o sistema (`python app.py`) e abra a aba **"Importar"**.
3. Escolha o arquivo, diga se é "Fila de Peças" ou "Controle de Peças" e
   clique em **Detectar colunas** — o sistema lê a primeira linha da planilha
   e já sugere para qual campo do sistema cada coluna deveria ir.
4. Confira/ajuste o mapeamento coluna a coluna e confirme a importação.

Nenhum dado é perdido: colunas que você não mapear para um campo específico
ainda ficam guardadas junto de cada peça (aparecem no histórico dela). A
importação lê a planilha em streaming (não carrega tudo na memória de uma vez)
e grava em lotes — 60 mil linhas levam poucos segundos.

**Só funciona com `ARMAZENAMENTO=sqlite`** (o padrão). Com "arquivo" (JSON), o
sistema bloqueia a importação em massa de propósito, porque esse back-end
reescreveria o JSON inteiro a cada lote — lento e arriscado para 40-60 mil
linhas.

**Dependência extra só para importar:** `pip install openpyxl`. É a única
biblioteca externa necessária para ler os `.xlsx` reais (com datas, células
vazias, formatos variados) — o resto do sistema continua sem depender dela.

## Usando o SharePoint como "banco de dados" (alternativa ao SQLite)

Se preferir manter tudo em JSON dentro de uma pasta do SharePoint sincronizada
(mais simples de olhar manualmente, mas não recomendado para bases grandes):

1. Na biblioteca do SharePoint do time, clique em **Sincronizar** (ou "Adicionar
   atalho ao OneDrive"). Ela vira uma pasta normal no Windows.
2. Copie `.env.exemplo` para `.env` e aponte a pasta:

```
ARMAZENAMENTO=arquivo
PASTA_DADOS=C:\Users\seu.usuario\Bradesco\CRM Orquestracao - Documentos\Base
```

A cada gravação o sistema escreve dois arquivos nessa pasta:

- `base_pecas.json` — a base em si, que o programa lê e escreve;
- `CONTROLE_DE_PECAS.xlsx` — planilha sempre atualizada, que o time abre direto
  no SharePoint/Excel Online.

A escrita é atômica (grava num temporário e troca), então o OneDrive nunca
sincroniza um arquivo pela metade.

**Limitação honesta:** essa abordagem usa a sincronização do OneDrive, não a API
do SharePoint. Ela funciona muito bem para uma pessoa por vez, ou para um time
pequeno em que raramente duas pessoas salvam no mesmo instante. Se duas
gravarem no mesmo segundo, o OneDrive pode criar um arquivo "em conflito" e a
última alteração pode se perder. Com `ARMAZENAMENTO=sqlite` (padrão) isso não
acontece, mesmo com o time inteiro usando ao mesmo tempo.

Mesmo usando SQLite, você pode manter `ESPELHO_XLSX=1` e `PASTA_DADOS` apontando
para o SharePoint: o banco (`base_pecas.db`) fica lá, e um `.xlsx` sempre
atualizado é gerado do lado, para quem quiser só olhar no Excel Online.

## Usando MongoDB

Se preferir banco de verdade rodando como servidor (útil se, um dia, mais de
um servidor de aplicação precisar ler/escrever ao mesmo tempo):

```
ARMAZENAMENTO=mongo
MONGO_URL=mongodb://localhost:27017
DB_NAME=crm_bradesco
```

Nesse modo é preciso `pip install pymongo`. A exportação para Excel e os
backups seguem funcionando igual.

## Assistente de IA

Opcional. Preencha `OPENAI_API_KEY` no `.env` para ligar o chat de validação.
Sem a chave, o botão continua lá e avisa que está desativado — o resto do
sistema funciona normalmente. Como a chamada é HTTP direta, qualquer endpoint
compatível com a API da OpenAI serve (basta mudar `IA_BASE_URL`), inclusive um
gateway interno do banco.

## Estrutura

```
app.py                  servidor HTTP + rotas da API
nucleo/config.py        leitura do .env, fuso horário, caminhos
nucleo/dominio.py       parsers, matriz de status, templates de e-mail
nucleo/armazenamento.py back-ends: sqlite (padrão), arquivo (JSON/SharePoint),
                         mongo e sqlserver (plugável)
nucleo/importador.py    leitura de .xlsx e importação em massa (usa openpyxl)
nucleo/planilha.py      gerador de .xlsx de saída, sem openpyxl
nucleo/ia.py            assistente de validação
web/                    interface (index.html, estilo.css, app.js)
dados/                  base local (base_pecas.db), quando PASTA_DADOS não é informado
importar/               coloque aqui as planilhas .xlsx que quer importar
```

## Detalhes que valem saber

- **Fuso horário:** o Windows não traz o banco IANA e o `zoneinfo` falharia sem
  o pacote `tzdata`. O `config.py` detecta isso e cai para UTC-3 fixo.
- **Sem CDN:** todo o CSS e JS é local, porque proxy corporativo costuma
  bloquear CDN.
- **Porta ocupada:** se a 8000 estiver em uso, mude `PORTA` no `.env`.
- **Compartilhar na rede:** trocando `HOST` para `0.0.0.0`, outras máquinas
  acessam pelo seu IP. Não há autenticação, então use só dentro da rede interna.
