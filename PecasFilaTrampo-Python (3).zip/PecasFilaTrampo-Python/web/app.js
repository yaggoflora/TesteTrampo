/* CRM Bradesco — front-end em JavaScript puro.
   Mesmas telas e mesmo fluxo da versão React, sem build e sem Node.js. */

const API = "/api";

const RASCUNHO_VAZIO = {
  criador: "", assunto_email: "", responsavel: "", briefing: "", nome_campanha: "",
  segmento: "", link_pasta: "", data_entrega: "", data_conferencia: "", fim_vigencia: "",
  marketing: "", agencia: "", qtd_respostas: 0, tipo_canal: "", canal_esperado: "",
  status_peca: "", observacao: "", possui_link: "",
};

const PASSOS = [
  { n: 1, titulo: "Entrada & Briefing" },
  { n: 2, titulo: "Controle de Peças" },
  { n: 3, titulo: "Fila de Peças" },
  { n: 4, titulo: "E-mail" },
  { n: 5, titulo: "Conclusão" },
];

const CORES_FILA = {
  "RECEBIDA": "verde", "Em Recebimento": "ambar", "FILA": "vermelha",
  "Sem Retorno": "vermelha", "Devolvida - Pendente": "ambar",
  "Devolvida - OK": "azul", "Alt. Validade": "azul",
};
const CORES_PECA = {
  "OK": "verde", "Ajustes": "ambar", "Alt Validade": "azul",
  "Desconsiderada": "cinza", "Desconsiderada Alerta": "vermelha",
};
const ROTULO_TEMPLATE = {
  recebidas: "Peças Recebidas (Confirmação)",
  ajuste_peca: "Ajuste de Peça",
  alteracao_validade: "Ajuste / Alteração de Validade",
};

const estado = {
  aba: "painel",
  rascunho: { ...RASCUNHO_VAZIO },
  pecaId: null,
  passo: 1,
  templateTipo: "",
  filaStatus: "",
  bloqueio: "",
  extraidos: null,
  pastaRenomeada: "",
  concluida: false,
  opcoes: null,
  carregando: false,
};

/* ------------------------------------------------- utilidades */

const el = document.getElementById.bind(document);
const escapar = (t) => String(t ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function toast(mensagem, tipo = "info") {
  const div = document.createElement("div");
  div.className = `toast ${tipo}`;
  div.textContent = mensagem;
  el("toasts").appendChild(div);
  setTimeout(() => div.remove(), 4500);
}

async function pedir(caminho, opcoes = {}) {
  const resp = await fetch(API + caminho, {
    headers: { "Content-Type": "application/json" },
    ...opcoes,
    body: opcoes.corpo ? JSON.stringify(opcoes.corpo) : undefined,
  });
  const texto = await resp.text();
  const dados = texto ? JSON.parse(texto) : null;
  if (!resp.ok) {
    const erro = new Error((dados && dados.detail) || "Erro na requisição");
    erro.status = resp.status;
    throw erro;
  }
  return dados;
}

const get = (c) => pedir(c);
const post = (c, corpo) => pedir(c, { method: "POST", corpo: corpo || {} });
const put = (c, corpo) => pedir(c, { method: "PUT", corpo });
const remover = (c) => pedir(c, { method: "DELETE" });

const dataHoje = () => new Date().toLocaleDateString("pt-BR");
const guardar = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
const recuperar = (k) => { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } };

function etiqueta(valor, mapa) {
  if (!valor) return '<span style="color:#94A3B8">—</span>';
  return `<span class="etiqueta ${mapa[valor] || "cinza"}">${escapar(valor)}</span>`;
}

async function copiar(texto, rotulo) {
  try {
    await navigator.clipboard.writeText(texto);
    toast(`${rotulo} copiado para a área de transferência!`, "sucesso");
  } catch (e) {
    toast("Não foi possível copiar automaticamente. Selecione e copie manualmente.", "erro");
  }
}

/* ------------------------------------------------- navegação */

function irPara(aba) {
  estado.aba = aba;
  document.querySelectorAll("#abas button").forEach((b) =>
    b.classList.toggle("ativa", b.dataset.aba === aba));
  renderizar();
}

function novaPeca() {
  estado.rascunho = {
    ...RASCUNHO_VAZIO,
    criador: estado.rascunho.criador || recuperar("crm_criador"),
    briefing: recuperar("crm_ultimo_briefing"),
    data_entrega: recuperar("crm_ultima_entrega"),
    data_conferencia: dataHoje(),
  };
  Object.assign(estado, {
    pecaId: null, passo: 1, templateTipo: "", filaStatus: "", bloqueio: "",
    extraidos: null, pastaRenomeada: "", concluida: false, aba: "nova",
  });
  document.querySelectorAll("#abas button").forEach((b) => b.classList.remove("ativa"));
  renderizar();
}

function retomarPeca(peca) {
  estado.rascunho = { ...RASCUNHO_VAZIO, ...peca };
  Object.assign(estado, {
    pecaId: peca.id,
    templateTipo: peca.template_tipo || "",
    filaStatus: peca.fila_status || "",
    passo: peca.fila_status ? (peca.email_corpo ? 4 : 3) : 2,
    bloqueio: "", extraidos: null,
    pastaRenomeada: peca.pasta_renomeada || "",
    concluida: !!peca.concluida,
    aba: "nova",
  });
  document.querySelectorAll("#abas button").forEach((b) => b.classList.remove("ativa"));
  renderizar();
}

function renderizar() {
  const alvo = el("conteudo");
  if (estado.aba === "painel") return renderPainel(alvo);
  if (estado.aba === "nova") return renderAssistente(alvo);
  if (estado.aba === "fila") return renderFila(alvo);
  if (estado.aba === "controle") return renderControle(alvo);
  if (estado.aba === "importar") return renderImportar(alvo);
}

/* ------------------------------------------------- painel */

async function renderPainel(alvo) {
  alvo.innerHTML = `
    <div class="hero">
      <h2>Orquestração e Controle de Peças CRM</h2>
      <p>Automatize a entrada de dados, elimine duplicidade entre Fila e Controle, gere e-mails
         padronizados e valide peças com o assistente de IA.</p>
      <button class="btn btn-primario" id="hero-nova">Iniciar Nova Orquestração →</button>
    </div>
    <div class="kpis" id="kpis"></div>
    <div class="cartao" style="margin-top:32px">
      <h2 style="font-size:20px">Peças por Tipo de Canal</h2>
      <div id="canais" style="margin-top:20px"><p class="sub">Carregando...</p></div>
    </div>`;
  el("hero-nova").onclick = novaPeca;

  let stats;
  try { stats = await get("/stats"); } catch (e) { toast("Erro ao carregar o painel.", "erro"); return; }

  const valores = [
    { titulo: "Total de Peças", valor: stats.total, cor: "#DBEAFE" },
    { titulo: "OK / Aprovadas", valor: stats.por_status_peca.OK || 0, cor: "#D1FAE5" },
    { titulo: "Em Ajustes", valor: stats.por_status_peca.Ajustes || 0, cor: "#FEF3C7" },
    {
      titulo: "Sem Retorno / Alerta",
      valor: (stats.por_status_fila["Sem Retorno"] || 0) + (stats.por_status_fila.FILA || 0),
      cor: "#FEE2E2",
    },
  ];
  el("kpis").innerHTML = valores.map((k) => `
    <div class="kpi">
      <div class="marcador" style="background:${k.cor}"></div>
      <p class="valor">${k.valor}</p>
      <p class="titulo">${k.titulo}</p>
    </div>`).join("");

  const canais = Object.entries(stats.por_canal).sort((a, b) => b[1] - a[1]);
  const maximo = Math.max(1, ...canais.map(([, v]) => v));
  el("canais").innerHTML = canais.length === 0
    ? '<p style="color:#64748B">Nenhuma peça registrada ainda. Os dados aparecerão aqui conforme a fila for preenchida.</p>'
    : canais.map(([canal, qtd]) => `
        <div class="linha-canal">
          <div class="legenda"><span>${escapar(canal)}</span><span>${qtd}</span></div>
          <div class="barra-canal"><div style="width:${(qtd / maximo) * 100}%"></div></div>
        </div>`).join("");
}

/* ------------------------------------------------- assistente (wizard) */

function htmlStepper() {
  const itens = PASSOS.map((s, i) => {
    const classe = estado.passo > s.n ? "feito" : estado.passo === s.n ? "atual" : "";
    const trilho = i < PASSOS.length - 1
      ? `<div class="trilho ${estado.passo > s.n ? "feito" : ""}"></div>` : "";
    return `<li>
      <div class="passo">
        <div class="bolinha ${classe}">${estado.passo > s.n ? "✓" : s.n}</div>
        <span class="${estado.passo === s.n ? "atual" : ""}">${s.titulo}</span>
      </div>${trilho}</li>`;
  }).join("");
  const progresso = ((estado.passo - 1) / (PASSOS.length - 1)) * 100;
  return `<div class="stepper">
    <div class="stepper-rolagem"><ol>${itens}</ol></div>
    <div class="barra-progresso"><div style="width:${progresso}%"></div></div>
  </div>`;
}

function ligarCampos(container) {
  container.querySelectorAll("[data-campo]").forEach((campo) => {
    campo.addEventListener("input", () => {
      const nome = campo.dataset.campo;
      estado.rascunho[nome] = campo.type === "number" || nome === "qtd_respostas"
        ? parseInt(campo.value || "0", 10) : campo.value;
      if (nome === "tipo_canal") {
        estado.rascunho.canal_esperado = "";
        renderizar();
      }
    });
  });
}

function renderAssistente(alvo) {
  alvo.innerHTML = htmlStepper() + '<div id="passo-atual"></div>';
  const caixa = el("passo-atual");
  if (estado.passo === 1) passoEntrada(caixa);
  if (estado.passo === 2) passoControle(caixa);
  if (estado.passo === 3) passoFila(caixa);
  if (estado.passo === 4) passoEmail(caixa);
  if (estado.passo === 5) passoConclusao(caixa);
  ligarCampos(caixa);
}

function passoEntrada(caixa) {
  const d = estado.rascunho;
  const extraidos = estado.extraidos ? `
    <div class="aviso rosa" style="margin-top:24px">
      <h3>Dados extraídos automaticamente</h3>
      <div class="grade" style="margin-top:12px">
        <div class="caixa-dado"><span>Briefing</span><strong class="mono">${escapar(estado.extraidos.briefing) || "—"}</strong></div>
        <div class="caixa-dado"><span>Tipo de Canal</span><strong>${escapar(estado.extraidos.tipo_canal) || "—"}</strong></div>
        <div class="caixa-dado"><span>Canal Esperado</span><strong>${escapar(estado.extraidos.canal_esperado) || "—"}</strong></div>
        <div class="caixa-dado"><span>Segmento</span><strong>${escapar(estado.extraidos.segmento) || "—"}</strong></div>
        <div class="caixa-dado col-cheia"><span>Link da Pasta</span><strong class="mono">${escapar(estado.extraidos.link_pasta) || "—"}</strong></div>
      </div>
      <p class="dica">Campos não identificados com 100% de certeza ficam em branco para preenchimento manual.</p>
    </div>` : "";

  caixa.innerHTML = `<div class="cartao">
    <h2>Entrada &amp; Briefing</h2>
    <p class="sub">Cole o assunto do e-mail do Marketing. O sistema extrai o briefing e localiza a pasta na rede automaticamente.</p>
    <div class="aviso azul">
      <h3>Antes de começar: verifique a peça no Outlook e no Workflow</h3>
      <p>Dados de consulta obrigatória do analista:</p>
      <ul>
        <li>Briefing</li><li>Nome da Campanha</li><li>Segmento</li>
        <li>Data de Fim de Vigência (Outlook)</li><li>Agência Desenvolvedora</li>
        <li>Marketing (responsável pelo envio)</li>
      </ul>
    </div>
    <div class="grade-2">
      <div>
        <label class="rotulo">Nome do Criador *</label>
        <input type="text" data-campo="criador" value="${escapar(d.criador)}" placeholder="Ex: Yaggo Silva">
      </div>
      <div>
        <label class="rotulo">Assunto do E-mail</label>
        <input type="text" data-campo="assunto_email" value="${escapar(d.assunto_email)}"
               placeholder='Ex: "SUBSTITUIÇÃO DE PEÇAS 14023 - Crédito - Balcão Emergencial"'>
      </div>
      <div class="col-cheia">
        <label class="rotulo">Nome de Campanha (opcional nesta etapa)</label>
        <input type="text" class="mono" data-campo="nome_campanha" value="${escapar(d.nome_campanha)}"
               placeholder="Ex: 00015107_00139713_MARGEM_LIVRE_INSS_CLA_ATM_INF">
      </div>
    </div>
    ${extraidos}
    <div class="linha-botoes">
      <button class="btn btn-escuro" id="btn-analisar">Analisar e Extrair Dados</button>
      <button class="btn btn-primario" id="btn-avancar">Avançar →</button>
    </div>
  </div>`;

  el("btn-analisar").onclick = async (ev) => {
    const d2 = estado.rascunho;
    if (!d2.assunto_email && !d2.nome_campanha) {
      toast("Informe o assunto do e-mail ou o nome da campanha para análise.", "erro");
      return;
    }
    ev.target.disabled = true; ev.target.textContent = "Analisando...";
    try {
      const dados = await post("/parse", { assunto: d2.assunto_email, nome_campanha: d2.nome_campanha });
      estado.extraidos = dados;
      Object.assign(estado.rascunho, {
        briefing: dados.briefing || d2.briefing,
        link_pasta: dados.link_pasta || d2.link_pasta,
        tipo_canal: dados.tipo_canal || d2.tipo_canal,
        canal_esperado: dados.canal_esperado || d2.canal_esperado,
        segmento: dados.segmento || d2.segmento,
        data_conferencia: dados.data_conferencia,
      });
      toast(dados.briefing ? `Briefing identificado: ${dados.briefing}`
        : "Não foi possível identificar o briefing. Preencha manualmente.",
        dados.briefing ? "sucesso" : "info");
      renderizar();
    } catch (e) {
      toast("Erro ao analisar: " + e.message, "erro");
      ev.target.disabled = false; ev.target.textContent = "Analisar e Extrair Dados";
    }
  };

  el("btn-avancar").onclick = () => {
    if (!estado.rascunho.criador.trim()) {
      toast("Informe o Nome do Criador antes de avançar.", "erro");
      return;
    }
    estado.passo = 2;
    renderizar();
  };
}

function campoSelect(rotulo, campo, opcoes, dica, desabilitado) {
  const valor = estado.rascunho[campo];
  const itens = opcoes.map((o) => {
    const v = typeof o === "object" ? o.value : o;
    return `<option value="${escapar(v)}" ${String(v) === String(valor) ? "selected" : ""}>${escapar(v)}</option>`;
  }).join("");
  return `<div>
    <label class="rotulo">${rotulo}</label>
    <select data-campo="${campo}" ${desabilitado ? "disabled" : ""}>
      <option value="">${desabilitado ? "Aguardando tipo de canal" : "Selecione..."}</option>
      ${itens}
    </select>
    ${dica ? `<p class="dica">${dica}</p>` : ""}
  </div>`;
}

function campoTexto(rotulo, campo, placeholder, dica, mono) {
  return `<div class="${campo === "nome_campanha" || campo === "link_pasta" ? "col-cheia" : ""}">
    <label class="rotulo">${rotulo}</label>
    <input type="text" ${mono ? 'class="mono"' : ""} data-campo="${campo}"
           value="${escapar(estado.rascunho[campo])}" placeholder="${escapar(placeholder || "")}">
    ${dica ? `<p class="dica">${dica}</p>` : ""}
  </div>`;
}

function passoControle(caixa) {
  const o = estado.opcoes;
  const canais = o.canal_map[estado.rascunho.tipo_canal] || [];
  caixa.innerHTML = `<div class="cartao">
    <h2>Controle de Peças — Formulário (colunas A–P)</h2>
    <p class="sub">Este é o preenchimento principal, equivalente à planilha "Controle de Peças". Os campos semelhantes da "Fila de Peças" são preenchidos automaticamente a partir daqui.</p>
    <div class="grade">
      ${campoTexto("Responsável (A)", "responsavel", "Ex: Yaggo")}
      ${campoTexto("Briefing (B)", "briefing", "000123477", "Padrão de 8 a 9 dígitos", true)}
      ${campoSelect("Segmento (D)", "segmento", o.segmentos)}
      ${campoTexto("Nome de Campanha (C)", "nome_campanha", "000123477_SQ_LINHACARA_PUB__CC_CLASSIC_PUSH", "", true)}
      ${campoTexto("Link da Pasta (E)", "link_pasta", "\\\\...\\DISPONIVEIS\\000123477", "", true)}
      ${campoTexto("Data de Entrega (F)", "data_entrega", "DD/MM/AAAA", "Data em que o e-mail de solicitação do Marketing foi enviado")}
      ${campoTexto("Data de Conferência (G)", "data_conferencia", "DD/MM/AAAA", "Data em que você recebeu e começou a trabalhar na peça")}
      ${campoTexto("Fim de Vigência (H)", "fim_vigencia", "31/12/2026", "Data final de vigência, informada no e-mail ou no Workflow")}
      ${campoTexto("Marketing (I)", "marketing", "Nome e último sobrenome")}
      ${campoSelect("Agência (J)", "agencia", o.agencias)}
      ${campoSelect("Qtd Respostas (K)", "qtd_respostas", o.qtd_respostas, "Quantas interações por e-mail (1ª versão, correções...)")}
      ${campoSelect("Tipo de Canal (L)", "tipo_canal", o.tipos_canal)}
      ${campoSelect("Canal Esperado (M)", "canal_esperado", canais,
        estado.rascunho.tipo_canal ? `Opções filtradas para ${escapar(estado.rascunho.tipo_canal)}` : "Selecione o Tipo de Canal primeiro",
        !estado.rascunho.tipo_canal)}
      ${campoSelect("Status Peça (N)", "status_peca", o.status_peca, "Preenchido automaticamente pela Fila; ajuste manual se necessário")}
      ${campoSelect("Possui Link (P)", "possui_link", o.possui_link, "Se a peça contém link interno ou externo")}
    </div>
    <div class="linha-botoes">
      <button class="btn btn-neutro" id="btn-voltar">← Voltar</button>
      <button class="btn btn-primario" id="btn-salvar">Salvar na Fila e Avançar →</button>
    </div>
  </div>`;

  el("btn-voltar").onclick = () => { estado.passo = 1; renderizar(); };
  el("btn-salvar").onclick = async (ev) => {
    const d = estado.rascunho;
    if (!d.criador.trim()) { toast("O campo 'Nome do Criador' é obrigatório.", "erro"); return; }
    ev.target.disabled = true; ev.target.textContent = "Salvando...";
    try {
      guardar("crm_criador", d.criador);
      if (d.briefing) guardar("crm_ultimo_briefing", d.briefing);
      if (d.data_entrega) guardar("crm_ultima_entrega", d.data_entrega);
      if (estado.pecaId) {
        await put(`/pecas/${estado.pecaId}`, d);
        toast("Peça atualizada na Fila de Peças.", "sucesso");
      } else {
        const nova = await post("/pecas", d);
        estado.pecaId = nova.id;
        toast("Peça registrada na Fila de Peças.", "sucesso");
      }
      estado.passo = 3;
      renderizar();
    } catch (e) {
      toast(e.message || "Erro ao salvar a peça.", "erro");
      ev.target.disabled = false; ev.target.textContent = "Salvar na Fila e Avançar →";
    }
  };
}

function passoFila(caixa) {
  const opcoes = estado.opcoes.status_fila.map((op) => `
    <button class="opcao-status ${estado.filaStatus === op.value ? "selecionada" : ""}" data-status="${escapar(op.value)}">
      <strong>${escapar(op.value)}</strong><span>${escapar(op.desc)}</span>
    </button>`).join("");

  caixa.innerHTML = `<div class="cartao">
    <h2>Fila de Peças — Status da Peça</h2>
    <p class="sub">Selecione o status da peça na Fila de Peças. Conforme a regra, o sistema atualiza (ou não) a coluna N — Status Peça — do Controle de Peças e prepara o e-mail correspondente.</p>
    ${estado.bloqueio ? `<div class="aviso vermelho"><h3>Processamento bloqueado</h3><p>${escapar(estado.bloqueio)}</p></div>` : ""}
    <div class="opcoes-status">${opcoes}</div>
    <div style="margin-top:24px">
      <label class="rotulo">Observação (coluna O)</label>
      <textarea data-campo="observacao" placeholder="Anotações do analista, detalhamento de ajustes...">${escapar(estado.rascunho.observacao)}</textarea>
    </div>
    <div class="linha-botoes">
      <button class="btn btn-neutro" id="btn-voltar">← Voltar</button>
      <button class="btn btn-primario" id="btn-processar">Processar Status e Avançar →</button>
    </div>
  </div>`;

  caixa.querySelectorAll(".opcao-status").forEach((b) => {
    b.onclick = () => { estado.filaStatus = b.dataset.status; estado.bloqueio = ""; renderizar(); };
  });
  el("btn-voltar").onclick = () => { estado.passo = 2; renderizar(); };
  el("btn-processar").onclick = async (ev) => {
    if (!estado.filaStatus) { toast("Selecione o status da peça na Fila.", "erro"); return; }
    ev.target.disabled = true; ev.target.textContent = "Processando...";
    try {
      const dados = await post(`/pecas/${estado.pecaId}/processar`, {
        fila_status: estado.filaStatus, observacao: estado.rascunho.observacao,
      });
      estado.templateTipo = dados.template_tipo;
      if (dados.escreve_controle) {
        estado.rascunho.status_peca = dados.status_peca;
        toast(`Controle de Peças atualizado: status "${dados.status_peca}".`, "sucesso");
      } else {
        toast("Status registrado. Controle de Peças não é preenchido para este status.", "info");
      }
      estado.passo = 4;
      renderizar();
    } catch (e) {
      if (e.status === 409) { estado.bloqueio = e.message; renderizar(); }
      else {
        toast(e.message || "Erro ao processar status.", "erro");
        ev.target.disabled = false; ev.target.textContent = "Processar Status e Avançar →";
      }
    }
  };
}

async function passoEmail(caixa) {
  caixa.innerHTML = '<div class="cartao"><p style="text-align:center;color:#64748B;padding:32px 0">Gerando e-mail padronizado...</p></div>';

  const gerar = async (detalhe, anterior) => {
    return post(`/pecas/${estado.pecaId}/email`, {
      template_tipo: estado.templateTipo || "ajuste_peca",
      ajustes_detalhe: detalhe ?? (el("ajuste-detalhe") ? el("ajuste-detalhe").value : estado.rascunho.observacao),
      validade_anterior: anterior ?? (el("validade-anterior") ? el("validade-anterior").value : ""),
    });
  };

  let email;
  try { email = await gerar(); } catch (e) { toast("Erro ao gerar o e-mail.", "erro"); return; }

  const blocoAjuste = estado.templateTipo === "ajuste_peca" ? `
    <div class="aviso ambar">
      <label class="rotulo">Ajustes Necessários (descreva o que precisa mudar)</label>
      <textarea id="ajuste-detalhe" placeholder="Ex: Corrigir link do botão e ajustar disclaimer do SMS">${escapar(estado.rascunho.observacao)}</textarea>
      <button class="btn btn-escuro" id="btn-atualizar-ajuste" style="margin-top:12px">Atualizar e-mail com o ajuste</button>
    </div>` : "";

  const blocoValidade = estado.templateTipo === "alteracao_validade" ? `
    <div class="aviso azul">
      <label class="rotulo">Validade anterior (MM.AA)</label>
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
        <input type="text" class="mono" id="validade-anterior" placeholder="Ex: 09.26" style="max-width:200px">
        <button class="btn btn-escuro" id="btn-atualizar-validade">Atualizar e-mail</button>
      </div>
    </div>` : "";

  caixa.innerHTML = `<div class="cartao">
    <div class="cabecalho-cartao">
      <div>
        <h2>E-mail Padronizado</h2>
        <p style="color:#475569">Modelo: <strong>${ROTULO_TEMPLATE[estado.templateTipo] || "Ajuste de Peça"}</strong>
           • Saudação automática: <strong>"Prezado(a), ${escapar(email.saudacao)}!"</strong></p>
      </div>
      <button class="btn btn-neutro btn-pequeno" id="btn-regenerar">Regenerar</button>
    </div>
    ${blocoAjuste}${blocoValidade}
    <div class="moldura-email">
      <div class="assunto">
        <p class="etiqueta-campo">ASSUNTO (EDITÁVEL)</p>
        <input type="text" id="email-assunto" value="${escapar(email.assunto)}">
      </div>
      <div class="corpo">
        <p class="etiqueta-campo">CORPO DO E-MAIL (EDITÁVEL)</p>
        <textarea id="email-corpo">${escapar(email.corpo)}</textarea>
      </div>
    </div>
    <p class="dica">O e-mail é gerado pronto, mas pode ser ajustado livremente antes de copiar.</p>
    <div class="linha-botoes">
      <button class="btn btn-primario" id="btn-copiar-tudo">Copiar E-mail Completo</button>
      <button class="btn btn-neutro" id="btn-copiar-assunto">Copiar apenas o Assunto</button>
    </div>
    <p class="dica" style="margin-top:16px">Cole o conteúdo no Outlook e envie ao Marketing. Depois avance para a conclusão.</p>
  </div>
  <div class="linha-botoes">
    <button class="btn btn-neutro" id="btn-voltar">← Voltar</button>
    <button class="btn btn-primario" id="btn-avancar">E-mail enviado no Outlook — Avançar →</button>
  </div>`;

  const aplicar = async (detalhe, anterior) => {
    try {
      const novo = await gerar(detalhe, anterior);
      el("email-assunto").value = novo.assunto;
      el("email-corpo").value = novo.corpo;
      toast("E-mail atualizado.", "sucesso");
    } catch (e) { toast("Erro ao gerar o e-mail.", "erro"); }
  };

  el("btn-regenerar").onclick = () => aplicar();
  if (el("btn-atualizar-ajuste")) el("btn-atualizar-ajuste").onclick = () => aplicar(el("ajuste-detalhe").value);
  if (el("btn-atualizar-validade")) el("btn-atualizar-validade").onclick = () => aplicar(undefined, el("validade-anterior").value);
  el("btn-copiar-tudo").onclick = () => copiar(`Assunto: ${el("email-assunto").value}\n\n${el("email-corpo").value}`, "E-mail completo");
  el("btn-copiar-assunto").onclick = () => copiar(el("email-assunto").value, "Assunto");
  el("btn-voltar").onclick = () => { estado.passo = 3; renderizar(); };
  el("btn-avancar").onclick = () => { estado.passo = 5; renderizar(); };
}

function passoConclusao(caixa) {
  const pronto = estado.concluida || estado.pastaRenomeada;
  caixa.innerHTML = `<div class="cartao">
    <h2>Conclusão &amp; Arquivamento</h2>
    <p class="sub">Finalize o processamento. O sistema irá orientar o arquivamento em DOCS e a renomeação da pasta na rede.</p>
    ${pronto ? `
      <div class="aviso verde">
        <h3>Peça processada e concluída!</h3>
        <p>Renomeie/salve a pasta do Briefing no diretório DISPONIVEIS com o nome abaixo:</p>
        <div class="caixa-dado mono" style="margin-top:12px"><strong>${escapar(estado.pastaRenomeada)}</strong></div>
        <button class="btn btn-escuro" id="btn-copiar-pasta" style="margin-top:16px">Copiar nome da pasta</button>
      </div>`
      : '<button class="btn btn-primario" id="btn-concluir">✓ Concluído</button>'}
    <div class="linha-botoes" style="border-top:1px solid #E2E8F0;padding-top:24px">
      <button class="btn btn-neutro" id="btn-nova">Iniciar Nova Peça</button>
    </div>
  </div>`;

  el("btn-nova").onclick = novaPeca;
  if (el("btn-copiar-pasta")) {
    el("btn-copiar-pasta").onclick = () => copiar(estado.pastaRenomeada, "Nome da pasta");
  }
  if (el("btn-concluir")) el("btn-concluir").onclick = abrirModalDocs;
}

function abrirModalDocs() {
  el("modal").innerHTML = `<div class="fundo-modal">
    <div class="modal">
      <div class="icone-alerta">!</div>
      <h3>Atenção Analista!</h3>
      <p>Lembre-se de salvar o e-mail recebido do Marketing e o e-mail de resposta enviado na pasta <strong>"DOCS"</strong>.</p>
      <div class="linha-botoes" style="justify-content:flex-end">
        <button class="btn btn-neutro" id="modal-voltar">Voltar</button>
        <button class="btn btn-primario" id="modal-confirmar">Entendi, já salvei em DOCS — Concluir</button>
      </div>
    </div>
  </div>`;
  el("modal-voltar").onclick = () => { el("modal").innerHTML = ""; };
  el("modal-confirmar").onclick = async (ev) => {
    ev.target.disabled = true; ev.target.textContent = "Concluindo...";
    try {
      const dados = await post(`/pecas/${estado.pecaId}/concluir`);
      estado.pastaRenomeada = dados.pasta_renomeada;
      estado.concluida = true;
      el("modal").innerHTML = "";
      toast("Processamento concluído com sucesso!", "sucesso");
      renderizar();
    } catch (e) {
      toast(e.message || "Erro ao concluir.", "erro");
      el("modal").innerHTML = "";
    }
  };
}

/* ------------------------------------------------- fila */

async function renderFila(alvo) {
  alvo.innerHTML = '<div class="cartao"><p class="vazio">Carregando...</p></div>';
  let pecas;
  try { pecas = await get("/pecas"); } catch (e) { toast("Erro ao carregar a Fila de Peças.", "erro"); return; }

  const desenhar = (busca = "") => {
    const filtradas = pecas.filter((p) => !busca ||
      [p.nome_campanha, p.briefing, p.responsavel, p.assunto_email].join(" ").toLowerCase().includes(busca.toLowerCase()));

    const corpo = filtradas.length === 0
      ? '<p class="vazio">Nenhuma peça na fila. Clique em "Nova Peça" para começar.</p>'
      : `<div class="rolagem-tabela"><table>
          <thead><tr>
            <th>Briefing</th><th>Campanha</th><th>Canal</th><th>Status Fila</th>
            <th>Status Peça</th><th>Responsável</th><th style="text-align:right">Ações</th>
          </tr></thead>
          <tbody>${filtradas.map((p) => `
            <tr>
              <td class="mono"><strong>${escapar(p.briefing) || "—"}</strong></td>
              <td class="truncar" title="${escapar(p.nome_campanha)}">${escapar(p.nome_campanha || p.assunto_email) || "—"}</td>
              <td>${escapar(p.tipo_canal) || "—"}</td>
              <td>${etiqueta(p.fila_status, CORES_FILA)}</td>
              <td>${etiqueta(p.status_peca, CORES_PECA)}</td>
              <td>${escapar(p.responsavel || p.criador) || "—"}</td>
              <td style="text-align:right;white-space:nowrap">
                <button class="btn btn-escuro btn-pequeno" data-retomar="${p.id}">Retomar</button>
                <button class="btn btn-perigo btn-pequeno" data-excluir="${p.id}">Excluir</button>
              </td>
            </tr>`).join("")}</tbody></table></div>`;

    alvo.innerHTML = `<div class="cartao">
      <div class="cabecalho-cartao">
        <div>
          <h2>Fila de Peças</h2>
          <p style="color:#475569">${pecas.length} peça(s) registrada(s)</p>
        </div>
        <div style="display:flex;gap:12px">
          <input type="text" id="busca" placeholder="Buscar por briefing, campanha..." style="width:260px" value="${escapar(busca)}">
          <button class="btn btn-neutro" id="btn-atualizar">Atualizar</button>
        </div>
      </div>
      ${corpo}
    </div>`;

    el("btn-atualizar").onclick = () => renderFila(alvo);
    const campoBusca = el("busca");
    campoBusca.oninput = () => {
      const valor = campoBusca.value;
      desenhar(valor);
      const novo = el("busca");
      novo.focus();
      novo.setSelectionRange(valor.length, valor.length);
    };
    alvo.querySelectorAll("[data-retomar]").forEach((b) => {
      b.onclick = () => retomarPeca(pecas.find((p) => p.id === b.dataset.retomar));
    });
    alvo.querySelectorAll("[data-excluir]").forEach((b) => {
      b.onclick = async () => {
        if (!confirm("Remover esta peça da fila?")) return;
        try {
          await remover(`/pecas/${b.dataset.excluir}`);
          toast("Peça removida da fila.", "sucesso");
          renderFila(alvo);
        } catch (e) { toast("Erro ao remover peça.", "erro"); }
      };
    });
  };

  desenhar();
}

/* ------------------------------------------------- controle */

async function renderControle(alvo) {
  alvo.innerHTML = '<div class="cartao"><p class="vazio">Carregando...</p></div>';
  let pecas, backups;
  try {
    [pecas, backups] = await Promise.all([get("/pecas"), get("/backups")]);
  } catch (e) { toast("Erro ao carregar o Controle de Peças.", "erro"); return; }
  pecas = pecas.filter((p) => p.status_peca);

  const tabela = pecas.length === 0
    ? '<p class="vazio">Nenhuma peça gravada no controle ainda.</p>'
    : `<div class="rolagem-tabela"><table>
        <thead><tr>
          <th>Briefing</th><th>Campanha</th><th>Segmento</th><th>Canal Esperado</th>
          <th>Fim Vigência</th><th>Status Peça</th><th>Status Fila</th><th>Criador</th>
        </tr></thead>
        <tbody>${pecas.map((p) => `
          <tr>
            <td class="mono"><strong>${escapar(p.briefing) || "—"}</strong></td>
            <td class="truncar" title="${escapar(p.nome_campanha)}">${escapar(p.nome_campanha) || "—"}</td>
            <td>${escapar(p.segmento) || "—"}</td>
            <td>${escapar(p.canal_esperado) || "—"}</td>
            <td>${escapar(p.fim_vigencia) || "—"}</td>
            <td>${etiqueta(p.status_peca, CORES_PECA)}</td>
            <td>${etiqueta(p.fila_status, CORES_FILA)}</td>
            <td>${escapar(p.criador) || "—"}</td>
          </tr>`).join("")}</tbody></table></div>`;

  const listaBackups = backups.length === 0
    ? '<p style="color:#64748B">Nenhum backup criado ainda.</p>'
    : `<ul style="list-style:none;padding:0;margin:0">${backups.map((b) => `
        <li style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;padding:16px 0;border-top:1px solid #F1F5F9">
          <div>
            <p class="mono"><strong>${escapar(b.nome)}</strong></p>
            <p class="dica">${b.total_pecas} peças • ${b.tipo === "agendado" ? "Automático (quinzenal)" : "Manual"}</p>
          </div>
          <a class="btn btn-neutro btn-pequeno" href="${API}/backups/${b.id}/download">Baixar</a>
        </li>`).join("")}</ul>`;

  alvo.innerHTML = `<div class="cartao">
    <div class="cabecalho-cartao">
      <div>
        <h2>Controle de Peças</h2>
        <p style="color:#475569">${pecas.length} peça(s) gravada(s) no controle (OK, Ajustes, Alt. Validade)</p>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:12px">
        <a class="btn btn-verde" href="${API}/export/excel">Exportar Excel (.xlsx)</a>
        <button class="btn btn-escuro" id="btn-backup">Criar Backup Agora</button>
        <button class="btn btn-neutro" id="btn-recarregar">Atualizar</button>
      </div>
    </div>
    ${tabela}
  </div>
  <div class="cartao">
    <h2 style="font-size:20px">Backups da Base</h2>
    <p class="sub">Snapshots congelados gerados automaticamente a cada 15 dias (dias 1 e 16) ou manualmente.</p>
    ${listaBackups}
  </div>`;

  el("btn-recarregar").onclick = () => renderControle(alvo);
  el("btn-backup").onclick = async () => {
    try {
      const b = await post("/backups");
      toast(`Backup criado: ${b.nome}`, "sucesso");
      renderControle(alvo);
    } catch (e) { toast("Erro ao criar backup.", "erro"); }
  };
}

/* ------------------------------------------------- importar */

async function renderImportar(alvo) {
  alvo.innerHTML = '<div class="cartao"><p class="vazio">Carregando...</p></div>';
  let info;
  try { info = await get("/importar/planilhas"); } catch (e) { toast("Erro ao consultar a pasta de importação.", "erro"); return; }

  const estadoImp = { arquivo: "", aba: "", origem: "fila", deteccao: null, mapeamento: {} };

  const desenhar = () => {
    const semArquivos = info.arquivos.length === 0
      ? `<p class="dica">Nenhum arquivo .xlsx encontrado em <span class="mono">${escapar(info.pasta)}</span>. Copie a planilha para essa pasta e clique em "Atualizar lista".</p>`
      : "";

    const selectArquivo = `<select id="sel-arquivo">
        <option value="">Selecione um arquivo...</option>
        ${info.arquivos.map((a) => `<option value="${escapar(a)}" ${a === estadoImp.arquivo ? "selected" : ""}>${escapar(a)}</option>`).join("")}
      </select>`;

    let blocoDeteccao = "";
    if (estadoImp.deteccao) {
      const d = estadoImp.deteccao;
      blocoDeteccao = `
        <div class="aviso azul" style="margin-top:24px">
          <h3>${d.total_linhas_estimado.toLocaleString("pt-BR")} linha(s) detectada(s)</h3>
          <p>Confira o mapeamento de cada coluna da planilha antes de importar. Colunas deixadas em "(ignorar campo específico)" ainda assim não se perdem — ficam guardadas junto da peça.</p>
        </div>
        <div class="rolagem-tabela"><table>
          <thead><tr><th>Coluna na planilha</th><th>Vira, no sistema</th></tr></thead>
          <tbody>${d.colunas.map((c) => `
            <tr>
              <td><strong>${escapar(c)}</strong></td>
              <td><select data-col="${escapar(c)}" class="sel-mapeamento">
                <option value="">(guardar sem mapear campo específico)</option>
                ${d.campos_disponiveis.map((campo) => `<option value="${campo}" ${estadoImp.mapeamento[c] === campo ? "selected" : ""}>${campo}</option>`).join("")}
              </select></td>
            </tr>`).join("")}</tbody></table></div>
        <div class="linha-botoes">
          <button class="btn btn-primario" id="btn-confirmar-importar">Importar ${d.total_linhas_estimado.toLocaleString("pt-BR")} linha(s)</button>
        </div>`;
    }

    alvo.innerHTML = `<div class="cartao">
      <h2>Importar planilha</h2>
      <p class="sub">Traga uma planilha grande (Fila de Peças, Controle de Peças) para dentro do sistema, sem digitar tudo de novo.</p>
      <div class="aviso ${info.armazenamento_atual === "sqlite" ? "verde" : "ambar"}">
        <h3>Armazenamento atual: ${escapar(info.armazenamento_atual)}</h3>
        <p>${info.armazenamento_atual === "sqlite"
          ? "Pronto para importar planilhas grandes."
          : "A importação em massa só é permitida com ARMAZENAMENTO=sqlite no .env (o back-end atual reescreveria o arquivo inteiro a cada lote)."}</p>
      </div>
      ${semArquivos}
      <div class="grade-2" style="margin-top:20px">
        <div>
          <label class="etiqueta-campo">1. Arquivo (pasta importar/)</label>
          ${selectArquivo}
        </div>
        <div>
          <label class="etiqueta-campo">2. Esta planilha é</label>
          <select id="sel-origem">
            <option value="fila" ${estadoImp.origem === "fila" ? "selected" : ""}>Fila de Peças</option>
            <option value="controle" ${estadoImp.origem === "controle" ? "selected" : ""}>Controle de Peças</option>
          </select>
        </div>
      </div>
      <div class="linha-botoes">
        <button class="btn btn-neutro" id="btn-atualizar-lista">Atualizar lista</button>
        <button class="btn btn-escuro" id="btn-detectar" ${estadoImp.arquivo ? "" : "disabled"}>Detectar colunas</button>
      </div>
      ${blocoDeteccao}
    </div>`;

    el("btn-atualizar-lista").onclick = () => renderImportar(alvo);
    el("sel-arquivo").onchange = (ev) => { estadoImp.arquivo = ev.target.value; estadoImp.deteccao = null; desenhar(); };
    el("sel-origem").onchange = (ev) => { estadoImp.origem = ev.target.value; };

    el("btn-detectar").onclick = async () => {
      try {
        const d = await post("/importar/detectar", { arquivo: estadoImp.arquivo });
        estadoImp.deteccao = d;
        estadoImp.mapeamento = { ...d.sugestao_mapeamento };
        desenhar();
      } catch (e) { toast(e.message || "Erro ao detectar colunas.", "erro"); }
    };

    alvo.querySelectorAll(".sel-mapeamento").forEach((s) => {
      s.onchange = () => { estadoImp.mapeamento[s.dataset.col] = s.value; };
    });

    const botaoConfirmar = document.getElementById("btn-confirmar-importar");
    if (botaoConfirmar) {
      botaoConfirmar.onclick = async () => {
        if (!confirm(`Importar a planilha "${estadoImp.arquivo}" como ${estadoImp.origem === "fila" ? "Fila de Peças" : "Controle de Peças"}? Isso pode levar alguns segundos.`)) return;
        botaoConfirmar.disabled = true;
        botaoConfirmar.textContent = "Importando...";
        try {
          const r = await post("/importar/executar", {
            arquivo: estadoImp.arquivo, mapeamento: estadoImp.mapeamento, origem: estadoImp.origem,
          });
          toast(`${r.importadas} peça(s) importada(s) de "${r.arquivo}".`, "sucesso");
          estadoImp.deteccao = null;
          desenhar();
        } catch (e) {
          toast(e.message || "Erro ao importar.", "erro");
          botaoConfirmar.disabled = false;
          botaoConfirmar.textContent = `Importar ${estadoImp.deteccao.total_linhas_estimado.toLocaleString("pt-BR")} linha(s)`;
        }
      };
    }
  };

  desenhar();
}

/* ------------------------------------------------- chat */

const SUGESTOES = [
  "Validar SMS sem acentuação",
  "Regras para Push PF",
  "Pode usar emoji em e-mail?",
  "Limite de caracteres no SMS",
];

function idSessao() {
  let id = recuperar("crm_chat_sessao");
  if (!id) {
    id = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
    guardar("crm_chat_sessao", id);
  }
  return id;
}

function adicionarBalao(papel, texto) {
  const div = document.createElement("div");
  div.className = `balao ${papel}`;
  div.textContent = texto;
  el("mensagens-chat").appendChild(div);
  el("mensagens-chat").scrollTop = el("mensagens-chat").scrollHeight;
  return div;
}

async function enviarChat(texto) {
  const mensagem = (texto || el("entrada-chat").value).trim();
  if (!mensagem) return;
  el("entrada-chat").value = "";
  adicionarBalao("usuario", mensagem);
  const resposta = adicionarBalao("assistente", "Analisando...");
  try {
    const dados = await post("/chat", { session_id: idSessao(), message: mensagem });
    resposta.textContent = dados.resposta;
  } catch (e) {
    resposta.textContent = e.message || "Não foi possível falar com o assistente.";
  }
  el("mensagens-chat").scrollTop = el("mensagens-chat").scrollHeight;
}

function iniciarChat() {
  el("sugestoes-chat").innerHTML = SUGESTOES.map((s) => `<button>${s}</button>`).join("");
  el("sugestoes-chat").querySelectorAll("button").forEach((b) => {
    b.onclick = () => enviarChat(b.textContent);
  });
  el("botao-chat").onclick = () => {
    el("painel-chat").classList.toggle("oculto");
    if (!el("painel-chat").classList.contains("oculto") && !el("mensagens-chat").children.length) {
      adicionarBalao("assistente", estado.opcoes && estado.opcoes.ia_disponivel
        ? "Olá! Envie o texto da peça e o canal (SMS, e-mail, push...) que eu valido regras, ortografia, sentido e boas práticas."
        : "O assistente de IA está desativado. Preencha OPENAI_API_KEY no arquivo .env para habilitá-lo — o restante do sistema funciona normalmente.");
    }
  };
  el("fechar-chat").onclick = () => el("painel-chat").classList.add("oculto");
  el("enviar-chat").onclick = () => enviarChat();
  el("entrada-chat").addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") enviarChat();
  });
}

/* ------------------------------------------------- inicialização */

async function iniciar() {
  document.querySelectorAll("#abas button").forEach((b) => {
    b.onclick = () => irPara(b.dataset.aba);
  });
  el("btn-nova-peca").onclick = novaPeca;
  iniciarChat();
  try {
    estado.opcoes = await get("/opcoes");
  } catch (e) {
    toast("Não foi possível falar com o servidor. Ele ainda está rodando?", "erro");
    return;
  }
  renderizar();
}

iniciar();
