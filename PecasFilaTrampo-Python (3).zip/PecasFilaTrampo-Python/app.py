"""CRM Bradesco — Orquestração e Controle de Peças (versão 100% Python).

Sobe um servidor local com a API e a interface web. Não precisa de Node.js,
FastAPI, uvicorn nem de qualquer pacote externo: usa só a biblioteca padrão
do Python 3.12.

Para rodar:  python app.py
"""

import json
import mimetypes
import re
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

from nucleo import config, dominio, ia, importador
from nucleo.armazenamento import criar_armazenamento, criar_backup
from nucleo.planilha import gerar_xlsx

PASTA_WEB = config.RAIZ / "web"
STORE = criar_armazenamento()

XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


class ErroHTTP(Exception):
    def __init__(self, status: int, detalhe: str):
        super().__init__(detalhe)
        self.status = status
        self.detalhe = detalhe


# ---------------------------------------------------------------- handlers

def rota_opcoes(_h, _corpo, **_):
    return dominio.opcoes_frontend()


def rota_parse(_h, corpo, **_):
    return dominio.analisar(corpo.get("assunto", ""), corpo.get("nome_campanha", ""))


def rota_listar_pecas(_h, _corpo, **_):
    return STORE.listar_pecas()


def rota_criar_peca(_h, corpo, **_):
    if not (corpo.get("criador") or "").strip():
        raise ErroHTTP(400, "O campo 'Nome do Criador' é obrigatório.")
    peca = dominio.nova_peca(corpo)
    peca["historico"].append({
        "acao": "Peça registrada no Controle de Peças",
        "data": config.agora().isoformat(),
    })
    STORE.inserir_peca(peca)
    return peca


def rota_obter_peca(_h, _corpo, peca_id=None, **_):
    peca = STORE.obter_peca(peca_id)
    if not peca:
        raise ErroHTTP(404, "Peça não encontrada")
    return peca


def rota_atualizar_peca(_h, corpo, peca_id=None, **_):
    campos = {k: v for k, v in corpo.items() if k in dominio.CAMPOS_PECA}
    try:
        campos["qtd_respostas"] = int(campos.get("qtd_respostas") or 0)
    except (TypeError, ValueError):
        campos["qtd_respostas"] = 0
    campos["updated_at"] = config.agora_iso()
    peca = STORE.atualizar_peca(peca_id, campos)
    if not peca:
        raise ErroHTTP(404, "Peça não encontrada")
    return peca


def rota_excluir_peca(_h, _corpo, peca_id=None, **_):
    if not STORE.excluir_peca(peca_id):
        raise ErroHTTP(404, "Peça não encontrada")
    return {"ok": True}


def rota_processar(_h, corpo, peca_id=None, **_):
    peca = STORE.obter_peca(peca_id)
    if not peca:
        raise ErroHTTP(404, "Peça não encontrada")
    fila_status = corpo.get("fila_status", "")
    regra = dominio.STATUS_MATRIX.get(fila_status)
    if not regra:
        raise ErroHTTP(400, "Status de fila inválido")
    if regra.get("bloqueado"):
        raise ErroHTTP(409, regra["erro"])

    campos = {
        "fila_status": fila_status,
        "template_tipo": regra["template"],
        "updated_at": config.agora_iso(),
    }
    if corpo.get("observacao") is not None:
        campos["observacao"] = corpo["observacao"]
    if regra["escreve_controle"]:
        campos["status_peca"] = regra["status_peca"]

    detalhe = (f" → Controle atualizado: {regra['status_peca']}"
               if regra["escreve_controle"] else " (sem gravação no Controle)")
    STORE.atualizar_peca(peca_id, campos, historico={
        "acao": f"Status '{fila_status}' processado" + detalhe,
        "data": config.agora().isoformat(),
    })
    return {
        "ok": True,
        "escreve_controle": regra["escreve_controle"],
        "status_peca": regra.get("status_peca", ""),
        "template_tipo": regra["template"],
    }


def rota_email(_h, corpo, peca_id=None, **_):
    peca = STORE.obter_peca(peca_id)
    if not peca:
        raise ErroHTTP(404, "Peça não encontrada")
    email = dominio.montar_email(
        peca,
        corpo.get("template_tipo") or "ajuste_peca",
        corpo.get("ajustes_detalhe", ""),
        corpo.get("validade_anterior", ""),
    )
    STORE.atualizar_peca(peca_id, {
        "email_assunto": email["assunto"],
        "email_corpo": email["corpo"],
        "updated_at": config.agora_iso(),
    }, historico={
        "acao": f"E-mail gerado ({corpo.get('template_tipo')})",
        "data": config.agora().isoformat(),
    })
    return email


def rota_concluir(_h, _corpo, peca_id=None, **_):
    peca = STORE.obter_peca(peca_id)
    if not peca:
        raise ErroHTTP(404, "Peça não encontrada")
    hoje = config.agora().strftime("%Y%m%d")
    base = (peca.get("assunto_email") or peca.get("nome_campanha")
            or f"Briefing {peca.get('briefing', '')}")
    pasta_renomeada = f"{hoje}_ {base}"
    STORE.atualizar_peca(peca_id, {
        "concluida": True,
        "pasta_renomeada": pasta_renomeada,
        "updated_at": config.agora_iso(),
    }, historico={
        "acao": f"Processamento concluído. Pasta renomeada: {pasta_renomeada}",
        "data": config.agora().isoformat(),
    })
    return {"ok": True, "pasta_renomeada": pasta_renomeada}


def rota_stats(_h, _corpo, **_):
    return dominio.calcular_stats(STORE.listar_pecas())


def rota_listar_backups(_h, _corpo, **_):
    return STORE.listar_backups()


def rota_criar_backup(_h, _corpo, **_):
    return criar_backup(STORE, "manual")


def rota_chat(_h, corpo, **_):
    session_id = corpo.get("session_id") or "padrao"
    mensagem = (corpo.get("message") or "").strip()
    if not mensagem:
        raise ErroHTTP(400, "Mensagem vazia")
    STORE.inserir_chat({"session_id": session_id, "role": "user",
                        "content": mensagem, "created_at": config.agora_iso()})
    try:
        resposta = ia.responder(session_id, mensagem)
    except ia.IADesativada as e:
        raise ErroHTTP(503, str(e))
    except RuntimeError as e:
        raise ErroHTTP(502, str(e))
    STORE.inserir_chat({"session_id": session_id, "role": "assistant",
                        "content": resposta, "created_at": config.agora_iso()})
    return {"resposta": resposta}


def rota_chat_historico(_h, _corpo, session_id=None, **_):
    return STORE.listar_chat(session_id)


def rota_importar_planilhas(_h, _corpo, **_):
    return {
        "pasta": str(config.PASTA_IMPORTAR),
        "arquivos": importador.listar_planilhas_disponiveis(),
        "armazenamento_atual": STORE.tipo,
    }


def rota_importar_detectar(_h, corpo, **_):
    arquivo = (corpo.get("arquivo") or "").strip()
    if not arquivo:
        raise ErroHTTP(400, "Informe o nome do arquivo.")
    try:
        return importador.detectar_colunas(arquivo, corpo.get("aba", ""))
    except FileNotFoundError as e:
        raise ErroHTTP(404, str(e))
    except RuntimeError as e:
        raise ErroHTTP(422, str(e))


def rota_importar_executar(_h, corpo, **_):
    arquivo = (corpo.get("arquivo") or "").strip()
    mapeamento = corpo.get("mapeamento") or {}
    origem = (corpo.get("origem") or "").strip()
    if not arquivo or not mapeamento or origem not in ("fila", "controle"):
        raise ErroHTTP(400, "Informe arquivo, mapeamento e origem ('fila' ou 'controle').")
    try:
        return importador.executar_importacao(STORE, arquivo, mapeamento, origem, corpo.get("aba", ""))
    except FileNotFoundError as e:
        raise ErroHTTP(404, str(e))
    except RuntimeError as e:
        raise ErroHTTP(422, str(e))


ROTAS = [
    ("GET", r"^/api/?$", lambda *a, **k: {"message": "CRM Bradesco - Orquestração e Publicação API"}),
    ("GET", r"^/api/opcoes$", rota_opcoes),
    ("POST", r"^/api/parse$", rota_parse),
    ("GET", r"^/api/pecas$", rota_listar_pecas),
    ("POST", r"^/api/pecas$", rota_criar_peca),
    ("GET", r"^/api/pecas/(?P<peca_id>[^/]+)$", rota_obter_peca),
    ("PUT", r"^/api/pecas/(?P<peca_id>[^/]+)$", rota_atualizar_peca),
    ("DELETE", r"^/api/pecas/(?P<peca_id>[^/]+)$", rota_excluir_peca),
    ("POST", r"^/api/pecas/(?P<peca_id>[^/]+)/processar$", rota_processar),
    ("POST", r"^/api/pecas/(?P<peca_id>[^/]+)/email$", rota_email),
    ("POST", r"^/api/pecas/(?P<peca_id>[^/]+)/concluir$", rota_concluir),
    ("GET", r"^/api/stats$", rota_stats),
    ("GET", r"^/api/backups$", rota_listar_backups),
    ("POST", r"^/api/backups$", rota_criar_backup),
    ("POST", r"^/api/chat$", rota_chat),
    ("GET", r"^/api/chat/history/(?P<session_id>[^/]+)$", rota_chat_historico),
    ("GET", r"^/api/importar/planilhas$", rota_importar_planilhas),
    ("POST", r"^/api/importar/detectar$", rota_importar_detectar),
    ("POST", r"^/api/importar/executar$", rota_importar_executar),
]


# ---------------------------------------------------------------- servidor

class Handler(BaseHTTPRequestHandler):
    server_version = "CRMPecas/2.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, formato, *args):  # log enxuto
        if "/api/" in (args[0] if args else ""):
            print(f"  {self.address_string()} {formato % args}")

    # -- utilidades de resposta --
    def _responder(self, status: int, conteudo: bytes, mime: str, extras: dict = None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(conteudo)))
        self.send_header("Cache-Control", "no-store")
        for chave, valor in (extras or {}).items():
            self.send_header(chave, valor)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(conteudo)

    def _json(self, dados, status: int = 200):
        corpo = json.dumps(dados, ensure_ascii=False, default=str).encode("utf-8")
        self._responder(status, corpo, "application/json; charset=utf-8")

    def _erro(self, status: int, detalhe: str):
        self._json({"detail": detalhe}, status)

    def _ler_corpo(self) -> dict:
        tamanho = int(self.headers.get("Content-Length") or 0)
        if not tamanho:
            return {}
        bruto = self.rfile.read(tamanho)
        try:
            return json.loads(bruto.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ErroHTTP(400, "Corpo da requisição inválido (esperado JSON).")

    # -- roteamento --
    def _despachar(self, metodo: str):
        caminho = unquote(urlparse(self.path).path)
        try:
            if caminho.startswith("/api/"):
                if caminho == "/api/export/excel" and metodo == "GET":
                    return self._exportar_excel()
                m = re.match(r"^/api/backups/(?P<bid>[^/]+)/download$", caminho)
                if m and metodo == "GET":
                    return self._baixar_backup(m.group("bid"))
                for verbo, padrao, funcao in ROTAS:
                    achou = re.match(padrao, caminho)
                    if achou and verbo == metodo:
                        corpo = self._ler_corpo() if metodo in ("POST", "PUT") else {}
                        status = 201 if (metodo == "POST" and caminho in ("/api/pecas", "/api/backups")) else 200
                        return self._json(funcao(self, corpo, **achou.groupdict()), status)
                return self._erro(404, "Rota não encontrada")
            return self._arquivo_estatico(caminho)
        except ErroHTTP as e:
            self._erro(e.status, e.detalhe)
        except Exception as e:  # noqa: BLE001 — erro inesperado vira 500 legível
            import traceback
            traceback.print_exc()
            self._erro(500, f"Erro interno: {e}")

    def _arquivo_estatico(self, caminho: str):
        relativo = "index.html" if caminho in ("/", "") else caminho.lstrip("/")
        destino = (PASTA_WEB / relativo).resolve()
        if not str(destino).startswith(str(PASTA_WEB.resolve())) or not destino.is_file():
            return self._erro(404, "Arquivo não encontrado")
        mime = mimetypes.guess_type(destino.name)[0] or "application/octet-stream"
        if mime.startswith("text/") or mime in ("application/javascript", "application/json"):
            mime += "; charset=utf-8"
        self._responder(200, destino.read_bytes(), mime)

    def _exportar_excel(self):
        pecas = STORE.listar_pecas()
        nome = f"CONTROLE_CRM_{config.agora().strftime('%Y_%m_%d')}.xlsx"
        self._responder(200, gerar_xlsx(pecas), XLSX_MIME,
                        {"Content-Disposition": f'attachment; filename="{nome}"'})

    def _baixar_backup(self, backup_id: str):
        doc = STORE.obter_backup(backup_id)
        if not doc:
            return self._erro(404, "Backup não encontrado")
        self._responder(200, gerar_xlsx(doc.get("data", [])), XLSX_MIME,
                        {"Content-Disposition": f'attachment; filename="{doc["nome"]}"'})

    def do_GET(self):
        self._despachar("GET")

    def do_POST(self):
        self._despachar("POST")

    def do_PUT(self):
        self._despachar("PUT")

    def do_DELETE(self):
        self._despachar("DELETE")


def agendador_backup():
    """Backup automático nos dias 1 e 16 (substitui o cron/webhook original)."""
    ultimo = None
    while True:
        hoje = config.agora()
        marca = hoje.strftime("%Y-%m-%d")
        if hoje.day in (1, 16) and marca != ultimo:
            try:
                criar_backup(STORE, "agendado")
                print(f"[backup] snapshot quinzenal criado em {marca}")
            except Exception as e:  # noqa: BLE001
                print(f"[backup] falhou: {e}")
            ultimo = marca
        time.sleep(1800)


def main():
    print("=" * 66)
    print("  CRM Bradesco — Orquestração e Controle de Peças")
    print("=" * 66)
    print(f"  Armazenamento : {STORE.descricao()}")
    print(f"  Assistente IA : {'ativo (' + config.IA_MODELO + ')' if config.IA_API_KEY else 'desativado (sem OPENAI_API_KEY)'}")
    print(f"  Endereço      : http://{config.HOST}:{config.PORTA}")
    print("  Para encerrar, feche esta janela ou pressione Ctrl+C.")
    print("=" * 66)

    threading.Thread(target=agendador_backup, daemon=True).start()
    servidor = ThreadingHTTPServer((config.HOST, config.PORTA), Handler)
    if config.ABRIR_NAVEGADOR:
        threading.Timer(1.0, lambda: webbrowser.open(f"http://{config.HOST}:{config.PORTA}")).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrando...")
        servidor.shutdown()


if __name__ == "__main__":
    main()
