#!/usr/bin/env python3
"""
Monta pacotes EMKT de teste com as imagens reais de campanha.

Cada pacote existe para exercitar um comportamento específico do validador, e
o CONTEUDO.docx é escrito como um redator escreveria — não extraído do OCR.
Gerar o docx a partir da própria leitura faria os dois lados concordarem
sempre, e o pacote não testaria nada.
"""

import os
import shutil

from docx import Document
from docx.oxml.ns import qn

ORIGEM = "/mnt/user-data/uploads"
DESTINO = "/home/claude/emkts-de-teste"

CABECA = ('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">'
          '<title>{titulo}</title></head><body style="margin:0">'
          '<div style="display:none;max-height:0;overflow:hidden">{preheader}</div>'
          '<center><table width="700" cellpadding="0" cellspacing="0" border="0">')
PE = '</table></center></body></html>'


def texto(conteudo, align="center", tamanho=15):
    return ('<tr><td align="%s" style="font-family:Arial,sans-serif;'
            'font-size:%dpx;line-height:1.5;color:#1b1b1b;padding:18px 40px">'
            '%s</td></tr>' % (align, tamanho, conteudo))


def imagem(nome):
    return ('<tr><td align="center"><img src="imagens/%s" width="700" '
            'style="display:block;width:100%%" alt=""></td></tr>' % nome)


def escrever(pasta, html, paragrafos, assunto, pre_header, imagens):
    os.makedirs(f"{pasta}/imagens", exist_ok=True)
    for origem, destino in imagens:
        shutil.copy(f"{ORIGEM}/{origem}", f"{pasta}/imagens/{destino}")
    open(f"{pasta}/index.html", "w", encoding="utf-8").write(html)

    documento = Document()
    for linha in paragrafos:
        documento.add_paragraph(linha)
    documento.save(f"{pasta}/CONTEUDO.docx")

    # formato que costuma chegar: rótulo em negrito, Shift+Enter entre os dois
    a = Document()
    par = a.add_paragraph()
    r = par.add_run("Assunto: "); r.bold = True
    par.add_run(assunto)
    quebra = par.add_run()
    quebra._r.append(quebra._r.makeelement(qn("w:br"), {}))
    r2 = par.add_run("Pré-header: "); r2.bold = True
    par.add_run(pre_header)
    a.save(f"{pasta}/ASSUNTO_E_PRE_HEADER.docx")


# ---------------------------------------------------------------- pacote 1
# Tudo certo. Serve para ver o verde e conferir que a peça inteira foi lida.

QUEBRA_1 = "00006444_D30_RELAC_TARIFACAO_CESTA_PJ_EMKTP"
IMAGENS_1 = [
    ("00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_01.gif",
     f"{QUEBRA_1}_01.gif"),
    ("00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_02.jpg",
     f"{QUEBRA_1}_02.jpg"),
    ("00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_03.jpg",
     f"{QUEBRA_1}_03.jpg"),
]

DISCLAIMER = (
    'Essa mensagem foi gerada automaticamente e não pode ser respondida. '
    'Mantenha seus dados atualizados e inclua o Bradesco nos seus remetentes '
    'confiáveis. Em caso de dúvidas, acesse '
    'banco&#xFEFF;.&#xFEFF;bradesco&#xFEFF;/&#xFEFF;pessoajuridica e envie uma '
    'mensagem pelo Fale Conosco ou contate a Central de Relacionamento Cliente '
    'Pessoa Jurídica: 3003 1000, capitais e regiões metropolitanas, ou 0800 202 '
    '1000 para demais regiões. Atendimento de segunda a sexta-feira, das 8h às '
    '18h, horário de Brasília.'
)

DISCLAIMER_TEXTO = (
    'Essa mensagem foi gerada automaticamente e não pode ser respondida. '
    'Mantenha seus dados atualizados e inclua o Bradesco nos seus remetentes '
    'confiáveis. Em caso de dúvidas, acesse banco.bradesco/pessoajuridica e '
    'envie uma mensagem pelo Fale Conosco ou contate a Central de '
    'Relacionamento Cliente Pessoa Jurídica: 3003 1000, capitais e regiões '
    'metropolitanas, ou 0800 202 1000 para demais regiões. Atendimento de '
    'segunda a sexta-feira, das 8h às 18h, horário de Brasília.'
)

html1 = (
    CABECA.format(titulo=QUEBRA_1, preheader="Fim de isenção da Cesta de Serviços.") +
    texto('<a href="https://click.campanhasbradesco.com.br/redirect?qs=1" '
          'style="color:#666">Se não conseguir abrir esse e-mail, clique aqui</a>',
          tamanho=12) +
    imagem(f"{QUEBRA_1}_01.gif") +
    texto("Olá, %%NOME%%") +
    texto("Não se preocupe! Sua empresa continua com todos os serviços da "
          "Cesta à disposição.") +
    imagem(f"{QUEBRA_1}_02.jpg") +
    texto('<a href="https://click.campanhasbradesco.com.br/redirect?qs=2" '
          'style="background:#cc092f;color:#fff;padding:14px 30px;'
          'text-decoration:none;border-radius:24px;display:inline-block">'
          'QUERO CONHECER A CESTA</a>') +
    texto("E você ainda conta com toda a proteção e a confiança do Bradesco.") +
    imagem(f"{QUEBRA_1}_03.jpg") +
    texto("Acompanhe o Bradesco nas Redes Sociais!", tamanho=13) +
    texto(DISCLAIMER, align="justify", tamanho=11) +
    texto('Não quer e-mails automáticos de ofertas e campanhas personalizadas? '
          '<a href="https://click.campanhasbradesco.com.br/redirect?qs=3">'
          'Cancele aqui.</a>', tamanho=11) +
    PE
)

PARAGRAFOS_1 = [
    "Se não conseguir abrir esse e-mail, clique aqui",
    "BRADESCO, O BANCO DA PJ",
    "COMPROMISSO com você",
    "e TRANSPARÊNCIA com sua empresa",
    "Olá, %%NOME%%",
    "Não se preocupe! Sua empresa continua com todos os serviços da Cesta à disposição.",
    "A partir do próximo mês, a Cesta de Serviços do seu negócio será cobrada integralmente.",
    "IMPORTANTE: Todos os serviços inclusos continuarão disponíveis.",
    "QUERO CONHECER A CESTA",
    "E você ainda conta com toda a proteção e a confiança do Bradesco.",
    "bradesco empresas e negócios",
    "Acompanhe o Bradesco nas Redes Sociais!",
    DISCLAIMER_TEXTO,
    "Não quer e-mails automáticos de ofertas e campanhas personalizadas? Cancele aqui.",
]


# ---------------------------------------------------------------- pacote 2
# Banner com layout em colunas: é o caso que a análise de layout resolve.

QUEBRA_2 = "10607_00135775_CINEMARK_SALA_PRIME_UNI_EMKTP"
IMAGENS_2 = [
    ("10607_00135775_CINEMARKSALAPRIME_UNI_EMKTP_06.jpg", f"{QUEBRA_2}_01.jpg"),
    ("00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_03.jpg",
     f"{QUEBRA_2}_02.jpg"),
]

html2 = (
    CABECA.format(titulo=QUEBRA_2, preheader="Seus benefícios no Cinemark.") +
    texto('<a href="https://click.campanhasbradesco.com.br/redirect?qs=1" '
          'style="color:#666">Se não conseguir abrir esse e-mail, clique aqui</a>',
          tamanho=12) +
    texto("Olá, %%NOME%%") +
    texto("Aproveite pagando com seu cartão Bradesco Prime.") +
    imagem(f"{QUEBRA_2}_01.jpg") +
    texto('<a href="https://click.campanhasbradesco.com.br/redirect?qs=2" '
          'style="background:#cc092f;color:#fff;padding:14px 30px;'
          'text-decoration:none;border-radius:24px;display:inline-block">'
          'QUERO MEU DESCONTO</a>') +
    imagem(f"{QUEBRA_2}_02.jpg") +
    texto('* Sujeito à disponibilidade. Saiba mais em '
          'banco&#xFEFF;.&#xFEFF;bradesco&#xFEFF;/&#xFEFF;cinemark. '
          'Imagens meramente ilustrativas. ' + DISCLAIMER,
          align="justify", tamanho=11) +
    PE
)

PARAGRAFOS_2 = [
    "Se não conseguir abrir esse e-mail, clique aqui",
    "Olá, %%NOME%%",
    "Aproveite pagando com seu cartão Bradesco Prime.",
    "50% de desconto",
    "no ingresso",
    "na poltrona D-BOX",
    "no combo Bradesco P ou M",
    "(pipoca doce ou salgada + bebida)",
    "20% de desconto",
    "em itens selecionados no",
    "Menu Bradesco em 35 salas VIP",
    "10/09:",
    "Da Magia à Sedução 2",
    "03/09:",
    "Minha Melhor Amiga",
    "24/09:",
    "A Ilha Esquecida",
    "QUERO MEU DESCONTO",
    "bradesco empresas e negócios",
    "* Sujeito à disponibilidade. Saiba mais em banco.bradesco/cinemark. "
    "Imagens meramente ilustrativas. " + DISCLAIMER_TEXTO,
]


def montar():
    shutil.rmtree(DESTINO, ignore_errors=True)

    escrever(f"{DESTINO}/01_TUDO_CERTO/{QUEBRA_1}", html1, PARAGRAFOS_1,
             "Sua Cesta de Serviços vai mudar",
             "Fim de isenção da Cesta de Serviços.", IMAGENS_1)

    escrever(f"{DESTINO}/02_LAYOUT_EM_COLUNAS/{QUEBRA_2}", html2, PARAGRAFOS_2,
             "Seus descontos no Cinemark",
             "Aproveite com seu cartão Prime!", IMAGENS_2)

    # ------------------------------------------------------------ pacote 3
    # Sete defeitos plantados, um de cada tipo que o validador conhece.
    base = f"{DESTINO}/01_TUDO_CERTO/{QUEBRA_1}"
    com_erro = f"{DESTINO}/03_COM_ERROS/{QUEBRA_1}"
    shutil.copytree(base, com_erro)

    codigo = open(f"{com_erro}/index.html", encoding="utf-8").read()
    codigo = codigo.replace("/redirect?qs=", "/?qs=")          # 1. sem redirect
    codigo = codigo.replace("\ufeff", "").replace("&#xFEFF;", "")  # 2. link solto
    codigo = codigo.replace("todos os serviços da Cesta",
                            "todos os serviços da Cesta Premium")  # 3. texto trocado
    open(f"{com_erro}/index.html", "w", encoding="utf-8").write(codigo)

    pasta_imagens = f"{com_erro}/imagens"
    os.rename(f"{pasta_imagens}/{QUEBRA_1}_02.jpg",            # 4. sem zero à esquerda
              f"{pasta_imagens}/{QUEBRA_1}_2.jpg")
    shutil.copy(f"{pasta_imagens}/{QUEBRA_1}_03.jpg",          # 5. imagem órfã
                f"{pasta_imagens}/{QUEBRA_1}_07.jpg")

    documento = Document()
    for linha in PARAGRAFOS_1:
        if "IMPORTANTE" in linha:
            continue                                            # 6. trecho faltando
        if "proteção e a confiança" in linha:
            linha = linha + " Válido até 31/07/2026."            # 7. data vencida
        documento.add_paragraph(linha)
    documento.save(f"{com_erro}/CONTEUDO.docx")

    a = Document()
    a.add_paragraph("Assunto: Sua Cesta de Serviços do seu negócio vai mudar "
                    "a partir do próximo mês")                  # 8. assunto longo
    a.add_paragraph("Preheader: Fim de isenção da Cesta de Serviços")  # 9. sem ponto
    a.save(f"{com_erro}/ASSUNTO_E_PRE_HEADER.docx")

    print("pacotes montados em", DESTINO)


if __name__ == "__main__":
    montar()
