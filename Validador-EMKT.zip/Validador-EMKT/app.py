"""
Aplicação web que confere pacotes de campanha antes da publicação.

Verifica três coisas no pacote que o marketing envia:
  1. as imagens seguem a taxonomia da quebra e estão em sequência sem furo;
  2. toda imagem da pasta é chamada no HTML, e todo src do HTML existe na pasta;
  3. o CONTEUDO.docx tem as mesmas palavras da peça, na mesma ordem de leitura,
     incluindo o texto que está dentro dos banners.

SOMENTE LEITURA: o programa abre os arquivos do pacote para conferir e não
altera, move ou apaga nada. Os relatórios são gravados na subpasta
"relatorios" do próprio projeto.

Como executar:
    pip install -r requirements.txt
    python app.py

Depois acesse: http://127.0.0.1:5000
"""

import os
import shutil
import socket
import sys
import tempfile
import uuid

# --- Caminhos absolutos ------------------------------------------------------
# Ancorar tudo no arquivo, e não no diretório de trabalho, é o que faz o app
# subir igual pelo VS Code (que costuma usar a raiz do workspace como cwd),
# pelo duplo clique e pelo Prompt aberto em qualquer lugar.
PASTA_DO_PROJETO = os.path.dirname(os.path.abspath(__file__))
if PASTA_DO_PROJETO not in sys.path:
    sys.path.insert(0, PASTA_DO_PROJETO)

# Aceita "templates" (padrão do Flask) e "template" (nome usado em algumas
# cópias dos projetos do time), para não depender de qual das duas está no disco.
PASTA_TEMPLATES = os.path.join(PASTA_DO_PROJETO, "templates")
if not os.path.isdir(PASTA_TEMPLATES):
    PASTA_TEMPLATES = os.path.join(PASTA_DO_PROJETO, "template")
PASTA_STATIC = os.path.join(PASTA_DO_PROJETO, "static")
PASTA_RELATORIOS = os.path.join(PASTA_DO_PROJETO, "relatorios")


def _erro_de_dependencia(erro: ImportError) -> None:
    """
    Explica o que instalar em vez de despejar um traceback.

    Sem isto, rodar pelo VS Code num interpretador diferente do que recebeu o
    pip install mostra só "ModuleNotFoundError" e não fica claro o que fazer.
    """
    faltando = getattr(erro, "name", None) or str(erro)
    equivalentes = {
        "flask": "flask",
        "bs4": "beautifulsoup4",
        "docx": "python-docx",
        "PIL": "pillow",
    }
    pacote = equivalentes.get(faltando, faltando)
    print("\n" + "=" * 66)
    print("  Falta uma biblioteca para o validador rodar:", faltando)
    print()
    print("  Instale com:")
    print(f"      {sys.executable} -m pip install {pacote}")
    print()
    print("  Ou instale tudo de uma vez:")
    print(f"      {sys.executable} -m pip install -r requirements.txt")
    print()
    print("  Se você instalou e mesmo assim aparece esta mensagem, o VS Code")
    print("  está usando outro Python. Ctrl+Shift+P > 'Python: Select")
    print("  Interpreter' e escolha o mesmo interpretador mostrado acima.")
    print("=" * 66 + "\n")
    sys.exit(1)


try:
    from flask import (Flask, Response, abort, jsonify, render_template, request,
                   send_file, send_from_directory)
    from validador import pacote, relatorio, serializacao
except ImportError as erro:  # pragma: no cover - caminho de diagnóstico
    _erro_de_dependencia(erro)


app = Flask(__name__, template_folder=PASTA_TEMPLATES, static_folder=PASTA_STATIC)
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024  # 300 MB por pacote
app.config["JSON_AS_ASCII"] = False

os.makedirs(PASTA_RELATORIOS, exist_ok=True)

# pastas temporárias criadas pelo upload, apagadas quando o programa fecha
_temporarias: list[str] = []

# id do relatório -> caminhos do pacote, para o preview lado a lado.
# Fica em memória de propósito: some quando o programa fecha, junto com as
# pastas temporárias do upload.
_previews: dict[str, dict] = {}


def _conferir(caminho_pasta: str, quebra=None, usar_ocr=True) -> dict:
    resultado = pacote.validar(caminho_pasta, quebra=quebra, usar_ocr=usar_ocr)
    id_relatorio = uuid.uuid4().hex[:12]
    relatorio.gerar(resultado, os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html"))

    if resultado.caminho_html:
        _previews[id_relatorio] = {
            "imagens": os.path.abspath(resultado.pasta_imagens or ""),
            "raiz": os.path.abspath(os.path.dirname(resultado.caminho_html)),
            "html": os.path.abspath(resultado.caminho_html),
            "paragrafos": (resultado.leitura_conteudo.paragrafos
                           if resultado.leitura_conteudo else []),
            "leitura": _leitura_da_peca(resultado),
            "nome": resultado.nome_pasta,
        }

    dados = serializacao.para_json(resultado, id_relatorio)
    dados["tem_preview"] = id_relatorio in _previews
    return dados


@app.route("/")
def pagina_inicial():
    return render_template("index.html")


@app.route("/api/conferir-upload", methods=["POST"])
def conferir_upload():
    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"erro": "Nenhum arquivo recebido."}), 400

    destino = tempfile.mkdtemp(prefix="pacote_emkt_")
    _temporarias.append(destino)

    for arquivo in arquivos:
        # o navegador manda o caminho relativo no lugar do nome, o que preserva
        # a subpasta de imagens
        relativo = (arquivo.filename or "").replace("\\", "/")
        partes = [p for p in relativo.split("/") if p not in ("", ".", "..")]
        if not partes:
            continue
        caminho = os.path.join(destino, *partes)
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        arquivo.save(caminho)

    # o navegador inclui a pasta raiz; entra nela quando é o único item
    conteudo = os.listdir(destino)
    raiz = destino
    if len(conteudo) == 1 and os.path.isdir(os.path.join(destino, conteudo[0])):
        raiz = os.path.join(destino, conteudo[0])

    usar_ocr = request.form.get("usar_ocr", "true") == "true"
    # o motor escolhido na tela vale para esta conferência
    from validador.ocr import forcar_motor
    forcar_motor(request.form.get("motor", ""))
    nome_arrastado = (arquivos[0].filename or "").replace("\\", "/").split("/")[0]

    # O usuário arrasta o que tem na mão: pode ser um pacote ou a pasta que
    # guarda vários. Quem decide é a estrutura, não uma opção na tela.
    pastas = pacote.localizar_pacotes(raiz)
    if not pastas:
        return jsonify({
            "erro": "Não encontrei nenhum pacote aqui. A pasta precisa conter o "
                    "HTML da peça, os docx e as imagens — ou ser a pasta que "
                    "guarda vários pacotes assim."
        }), 400

    try:
        resultados = [_conferir(p, None, usar_ocr) for p in pastas]
    except Exception as e:  # noqa: BLE001
        return jsonify({"erro": f"Falha ao conferir: {e}"}), 500

    em_lote = len(pastas) > 1
    for item in resultados:
        item["em_lote"] = em_lote
        if not em_lote and nome_arrastado:
            # pacote único: o nome que vale é o da pasta que a pessoa arrastou
            item["nome_pasta"] = item.get("nome_pasta") or nome_arrastado

    return jsonify({
        "modo": "lote" if em_lote else "unico",
        "origem": nome_arrastado or "pacote enviado",
        "total": len(resultados),
        "resultados": resultados,
    })


@app.route("/api/conferir-em-fluxo", methods=["POST"])
def conferir_em_fluxo():
    """
    Mesma conferência, devolvendo cada pacote assim que fica pronto.

    Ler as imagens é quase todo o tempo, e num lote a pessoa ficava olhando uma
    tela parada até o último pacote terminar. Mandando resultado a resultado,
    ela já começa a reportar o primeiro enquanto o resto roda.

    O formato é uma linha de JSON por evento (NDJSON): o navegador consegue ler
    conforme chega, sem esperar o fim da resposta.
    """
    import json

    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"erro": "Nenhum arquivo recebido."}), 400

    destino = tempfile.mkdtemp(prefix="pacote_emkt_")
    _temporarias.append(destino)
    for arquivo in arquivos:
        relativo = (arquivo.filename or "").replace("\\", "/")
        partes = [p for p in relativo.split("/") if p not in ("", ".", "..")]
        if not partes:
            continue
        caminho = os.path.join(destino, *partes)
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        arquivo.save(caminho)

    conteudo = os.listdir(destino)
    raiz = destino
    if len(conteudo) == 1 and os.path.isdir(os.path.join(destino, conteudo[0])):
        raiz = os.path.join(destino, conteudo[0])

    usar_ocr = request.form.get("usar_ocr", "true") == "true"
    from validador.ocr import forcar_motor
    forcar_motor(request.form.get("motor", ""))
    nome_arrastado = (arquivos[0].filename or "").replace("\\", "/").split("/")[0]

    def eventos():
        pastas = pacote.localizar_pacotes(raiz)
        if not pastas:
            yield json.dumps({"tipo": "erro", "erro":
                "Não encontrei nenhum pacote aqui. A pasta precisa conter o HTML "
                "da peça, os docx e as imagens — ou ser a pasta que guarda vários "
                "pacotes assim."}, ensure_ascii=False) + "\n"
            return

        em_lote = len(pastas) > 1
        yield json.dumps({
            "tipo": "inicio", "total": len(pastas),
            "modo": "lote" if em_lote else "unico",
            "origem": nome_arrastado or "pacote enviado",
            "nomes": [os.path.basename(p) for p in pastas],
        }, ensure_ascii=False) + "\n"

        for posicao, caminho in enumerate(pastas, 1):
            nome = os.path.basename(caminho)
            andamento = []

            def anotar(feitas, total, _lista=andamento):
                _lista.append((feitas, total))

            yield json.dumps({"tipo": "andamento", "posicao": posicao,
                              "nome": nome}, ensure_ascii=False) + "\n"
            try:
                resultado = pacote.validar(caminho, usar_ocr=usar_ocr, ao_avancar=anotar)
                id_relatorio = uuid.uuid4().hex[:12]
                relatorio.gerar(
                    resultado, os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html"))
                if resultado.caminho_html:
                    _previews[id_relatorio] = {
                        "raiz": os.path.abspath(os.path.dirname(resultado.caminho_html)),
                        "html": os.path.abspath(resultado.caminho_html),
                        "paragrafos": (resultado.leitura_conteudo.paragrafos
                                       if resultado.leitura_conteudo else []),
                        "leitura": _leitura_da_peca(resultado),
                        "nome": resultado.nome_pasta,
                    }
                dados = serializacao.para_json(resultado, id_relatorio)
                dados["tem_preview"] = id_relatorio in _previews
                dados["em_lote"] = em_lote
                if not em_lote and nome_arrastado:
                    dados["nome_pasta"] = dados.get("nome_pasta") or nome_arrastado
                yield json.dumps({"tipo": "pacote", "posicao": posicao,
                                  "resultado": dados}, ensure_ascii=False) + "\n"
            except Exception as e:  # noqa: BLE001
                yield json.dumps({"tipo": "falha", "nome": nome,
                                  "erro": str(e)}, ensure_ascii=False) + "\n"

        yield json.dumps({"tipo": "fim"}, ensure_ascii=False) + "\n"

    return Response(eventos(), mimetype="application/x-ndjson")


@app.route("/relatorio/<id_relatorio>")
def abrir_relatorio(id_relatorio):
    # o id é gerado por uuid4().hex, então só letras e números são válidos:
    # isso barra qualquer tentativa de subir de pasta pelo endereço
    if not id_relatorio.isalnum():
        return "Identificador inválido.", 400
    caminho = os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html")
    if not os.path.exists(caminho):
        return "Relatório não encontrado. Refaça a conferência.", 404
    return send_file(caminho)


# ----------------------------------------------------------------- preview

def _preview_ou_404(id_relatorio: str) -> dict:
    if not id_relatorio.isalnum() or id_relatorio not in _previews:
        abort(404)
    return _previews[id_relatorio]


@app.route("/preview/<id_relatorio>/peca")
def preview_peca(id_relatorio):
    """
    Serve o HTML do pacote para o iframe do preview.

    O arquivo chama as imagens por caminho relativo ("imagens/banner_01.png").
    Servido de outro endereço, esses caminhos apontariam para o lugar errado e
    a peça apareceria sem nenhuma imagem. A tag <base> injetada no topo faz
    todos eles caírem na rota que serve os arquivos do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        with open(preview["html"], "rb") as arquivo:
            codigo = arquivo.read().decode("utf-8", errors="replace")
    except OSError:
        abort(404)

    base = f'<base href="/preview/{id_relatorio}/arquivo/">'
    minusculo = codigo.lower()
    posicao = minusculo.find("<head")
    if posicao >= 0:
        fim = codigo.find(">", posicao)
        codigo = codigo[:fim + 1] + base + codigo[fim + 1:]
    else:
        codigo = base + codigo

    return Response(codigo, mimetype="text/html; charset=utf-8")


@app.route("/preview/<id_relatorio>/arquivo/<path:relativo>")
def preview_arquivo(id_relatorio, relativo):
    """
    Serve as imagens que a peça referencia.

    send_from_directory resolve o caminho dentro da raiz e recusa qualquer
    tentativa de subir de pasta pelo endereço — sem isso, o navegador poderia
    pedir ../../ e ler arquivo fora do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        return send_from_directory(preview["raiz"], relativo)
    except Exception:
        abort(404)


def _leitura_da_peca(resultado) -> list[dict]:
    """
    O que o sistema entendeu da peça, bloco a bloco.

    É a fita de leitura crua: o texto do código e o texto lido de cada imagem,
    na ordem em que o leitor de tela percorreria. Serve para explicar de onde
    veio cada divergência — quando o apontamento não faz sentido, é aqui que se
    vê se o problema foi a leitura da imagem ou o docx.
    """
    if not resultado.leitura_html:
        return []

    blocos = []
    for bloco in resultado.leitura_html.fita:
        if bloco.oculto:
            continue
        blocos.append({
            "tipo": bloco.tipo,
            "origem": (bloco.referencia if bloco.tipo == "imagem"
                       else "texto do código"),
            "texto": bloco.conteudo,
            "confianca": round(getattr(bloco, "ocr_confianca", 0) or 0),
            "aviso": getattr(bloco, "ocr_aviso", "") or getattr(bloco, "ocr_erro", ""),
            "classificacao": bloco.classificacao,
            "reordenado": bool(getattr(bloco, "reordenado", False)),
        })
    return blocos


@app.route("/preview/<id_relatorio>/imagem/<nome>")
def preview_imagem(id_relatorio, nome):
    """
    Serve uma imagem do pacote pelo nome, para o apontamento mostrar o arquivo.

    Ver o banner ao lado do apontamento é o que permite decidir em um segundo
    se a divergência é da peça ou foi a leitura que errou — e tirar o print
    para anexar no report sem sair da tela.
    """
    preview = _preview_ou_404(id_relatorio)
    pasta = preview.get("imagens") or preview["raiz"]
    if not os.path.isdir(pasta):
        abort(404)
    alvo = os.path.basename(nome).lower()
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower() == alvo:
                return send_file(os.path.join(raiz, arquivo))
    abort(404)


@app.route("/api/preview/<id_relatorio>/leitura")
def preview_leitura(id_relatorio):
    """A fita de leitura, para a aba 'o que o sistema leu'."""
    return jsonify({"blocos": _preview_ou_404(id_relatorio)["leitura"]})


@app.route("/preview/<id_relatorio>/conteudo-gerado.docx")
def baixar_conteudo_gerado(id_relatorio):
    """
    Gera um CONTEUDO.docx com a leitura desta conferência.

    Serve para montar pacote de teste, não para conferir a peça: os dois lados
    sairiam da mesma leitura e o resultado daria 100% sempre. O aviso está na
    tela, ao lado do botão.
    """
    from io import BytesIO

    from docx import Document

    preview = _preview_ou_404(id_relatorio)
    documento = Document()
    for bloco in preview["leitura"]:
        for linha in (bloco["texto"] or "").splitlines():
            if linha.strip():
                documento.add_paragraph(linha.strip())

    memoria = BytesIO()
    documento.save(memoria)
    memoria.seek(0)
    nome = f"CONTEUDO_GERADO_{preview.get('nome') or id_relatorio}.docx"
    return send_file(
        memoria, as_attachment=True, download_name=nome,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


@app.route("/api/preview/<id_relatorio>/conteudo")
def preview_conteudo(id_relatorio):
    """Parágrafos do docx, na ordem, para a coluna de texto."""
    return jsonify({"paragrafos": _preview_ou_404(id_relatorio)["paragrafos"]})


@app.route("/api/status-ocr")
def status_ocr():
    from validador.ocr import (aviso_de_escolha, aviso_de_versao, diagnosticar,
                               idiomas_instalados, motor_ativo, ocr_disponivel)

    disponivel, motivo = ocr_disponivel()
    ativo = motor_ativo()
    idiomas = idiomas_instalados()
    return jsonify({
        "disponivel": disponivel,
        "motivo": motivo,
        "motor": ativo.nome if ativo else "",
        "aviso_escolha": aviso_de_escolha(),
        "aviso_versao": aviso_de_versao(),
        "descricao": ativo.descricao if ativo else "",
        "motores": diagnosticar(),
        "disponiveis": [m for m in diagnosticar() if m["disponivel"]],
        "idiomas": idiomas,
        "portugues": "por" in idiomas,
    })


def _porta_livre(porta: int) -> bool:
    # sem SO_REUSEADDR de propósito: o teste precisa falhar exatamente onde o
    # servidor falharia, senão ele diria "livre" numa porta já em uso
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as teste:
        try:
            teste.bind(("127.0.0.1", porta))
            return True
        except OSError:
            return False


def _escolher_porta(preferida: int = 5000) -> int:
    """
    Deixar o programa aberto numa janela e rodar de novo trava a porta 5000.
    Em vez de morrer com "address already in use", sobe na porta seguinte.
    """
    for porta in range(preferida, preferida + 12):
        if _porta_livre(porta):
            return porta
    return preferida


def limpar_temporarias():
    for pasta in _temporarias:
        shutil.rmtree(pasta, ignore_errors=True)


if __name__ == "__main__":
    import atexit

    atexit.register(limpar_temporarias)

    porta = int(os.environ.get("PORTA") or _escolher_porta())
    endereco = f"http://127.0.0.1:{porta}"

    # O navegador só é aberto no processo principal. Com o reloader ligado o
    # Flask sobe dois processos, e sem esta guarda abriam duas abas.
    if not os.environ.get("WERKZEUG_RUN_MAIN") and os.environ.get("ABRIR_NAVEGADOR", "1") != "0":
        import threading
        import webbrowser

        # webbrowser pode falhar em terminal sem sessão gráfica: se falhar, o
        # endereço continua impresso abaixo e dá para abrir na mão.
        threading.Timer(1.2, lambda: webbrowser.open(endereco)).start()

    print("\n" + "=" * 66)
    print("  Validador de pacotes EMKT · Bradesco CRM")
    print(f"  Abra no navegador: {endereco}")
    if porta != 5000:
        print("  (a porta 5000 estava ocupada, então subi nesta aqui)")
    print("  Para encerrar: Ctrl+C aqui, ou feche esta janela.")
    print("=" * 66 + "\n")

    # host='127.0.0.1' = acessível apenas nesta máquina (recomendado).
    # debug=False de propósito: o debugger do Flask abre um console Python no
    # navegador, e isso não deve existir numa ferramenta que lê pasta de rede.
    app.run(host="127.0.0.1", port=porta, debug=False)
