#!/usr/bin/env python3
"""
Coleta tudo que explica uma diferença de resultado entre duas máquinas.

Quando o mesmo pacote dá resultados diferentes aqui e aí, a causa está em um
destes lugares: versão do Python, versão da biblioteca de leitura, qual motor
está ativo, ou cache guardado de uma versão anterior do código. Este script
olha os quatro e lê uma imagem de teste, para comparar leitura com leitura.

Uso:
    python diagnostico.py
    python diagnostico.py "C:\\caminho\\da\\imagem.gif"
    python diagnostico.py "C:\\caminho\\do\\pacote"
"""

import os
import platform
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

LINHA = "=" * 70


def versao_de(pacote: str) -> str:
    try:
        from importlib.metadata import version
        return version(pacote)
    except Exception:
        return "não instalado"


def secao(titulo: str) -> None:
    print("\n" + LINHA)
    print("  " + titulo)
    print(LINHA)


def main():
    alvo = sys.argv[1] if len(sys.argv) > 1 else ""

    secao("AMBIENTE")
    print(f"  Python            {sys.version.split()[0]}  ({platform.system()} "
          f"{platform.release()})")
    for pacote in ("rapidocr-onnxruntime", "onnxruntime", "winocr",
                   "pytesseract", "Pillow", "python-docx", "Flask",
                   "beautifulsoup4"):
        print(f"  {pacote:22}{versao_de(pacote)}")

    secao("MOTOR DE LEITURA")
    try:
        from validador.ocr import (PASTA_CACHE, VERSAO_DA_LEITURA, diagnosticar,
                                   motor_ativo, ocr_disponivel)
        disponivel, motivo = ocr_disponivel()
        ativo = motor_ativo()
        print(f"  leitura ativa     {disponivel}")
        print(f"  motor em uso      {ativo.nome if ativo else '—'}")
        print(f"  situação          {motivo}")
        from validador.ocr import aviso_de_versao
        alerta = aviso_de_versao()
        if alerta:
            print(f"\n  >>> ATENÇÃO: {alerta}")
        if os.environ.get("OCR_MOTOR"):
            print(f"  OCR_MOTOR         {os.environ['OCR_MOTOR']}  (forçado por variável)")
        print("\n  todos os motores:")
        for motor in diagnosticar():
            marca = "ok   " if motor["disponivel"] else "falta"
            print(f"    {marca} {motor['nome']:12} {motor['descricao'][:44]}")
            if not motor["disponivel"]:
                print(f"          {motor.get('motivo', '')[:60]}")
    except Exception as erro:  # noqa: BLE001
        print(f"  ERRO ao carregar o motor: {erro}")
        return

    secao("CACHE DE LEITURA")
    print(f"  chave do código   {VERSAO_DA_LEITURA}")
    print(f"  pasta             {PASTA_CACHE}")
    if os.path.isdir(PASTA_CACHE):
        guardados = [f for f in os.listdir(PASTA_CACHE) if f.endswith(".json")]
        print(f"  leituras guardadas {len(guardados)}")
        print("\n  Se a chave do código mudou desde a última conferência, estes")
        print("  arquivos não são mais usados — as imagens serão relidas.")
    else:
        print("  pasta não existe ainda (nenhuma leitura guardada)")

    if not alvo:
        secao("COMO SEGUIR")
        print("  Rode de novo apontando para a imagem ou o pacote que está")
        print("  dando diferença:")
        print('     python diagnostico.py "C:\\caminho\\do\\pacote"')
        print()
        return

    if os.path.isdir(alvo):
        secao(f"PACOTE: {os.path.basename(alvo)}")
        from validador import pacote as validador_pacote
        try:
            resultado = validador_pacote.validar(alvo)
        except Exception as erro:  # noqa: BLE001
            print(f"  ERRO ao conferir: {erro}")
            return

        print(f"  status            {resultado.status.upper()}")
        print(f"  aderência         {resultado.resultado_texto.similaridade}%")
        print(f"  imagens na pasta  {len(resultado.resultado_imagens.arquivos)}")
        print(f"  redirects         {resultado.leitura_html.redirects}")

        if resultado.bloqueios:
            print("\n  BLOQUEIOS (impedem a publicação):")
            for item in resultado.bloqueios:
                print(f"    · {item[:100]}")
        if resultado.alertas:
            print("\n  alertas:")
            for item in resultado.alertas:
                print(f"    · {item[:90]}")
        if resultado.resultado_texto.divergencias:
            print("\n  divergências de texto:")
            for d in resultado.resultado_texto.divergencias[:8]:
                print(f"    [{d.gravidade:5}] {d.tipo:18} {d.origem[-28:]}")
                print(f"            leitura:  {d.trecho_html[:60]!r}")
                print(f"            CONTEUDO: {d.trecho_docx[:60]!r}")
        else:
            print("\n  nenhuma divergência de texto")

        print("\n  LEITURA DE CADA IMAGEM:")
        for bloco in resultado.leitura_html.fita:
            if bloco.tipo != "imagem":
                continue
            print(f"\n    {bloco.referencia}")
            if getattr(bloco, "ocr_erro", ""):
                print(f"       ERRO: {bloco.ocr_erro[:70]}")
                continue
            confianca = getattr(bloco, "ocr_confianca", 0)
            aviso = getattr(bloco, "ocr_aviso", "")
            print(f"       confiança {confianca:.0f}%{('  · ' + aviso) if aviso else ''}")
            for linha in (bloco.conteudo or "— sem texto —").splitlines():
                print(f"       | {linha}")
        print()
        return

    secao(f"IMAGEM: {os.path.basename(alvo)}")
    from validador.ocr import ler_imagem
    try:
        from PIL import Image
        with Image.open(alvo) as imagem:
            print(f"  tamanho           {imagem.width}x{imagem.height}  ({imagem.format})")
            print(f"  quadros           {getattr(imagem, 'n_frames', 1)}")
    except Exception as erro:  # noqa: BLE001
        print(f"  não consegui abrir: {erro}")
        return

    leitura = ler_imagem(alvo)
    print(f"  confiança média   {leitura.confianca_media}")
    print(f"  aviso             {leitura.aviso or '—'}")
    print(f"  erro              {leitura.erro or '—'}")
    print("\n  TEXTO LIDO:")
    for linha in (leitura.texto or "— nada —").splitlines():
        print(f"    | {linha}")
    print()


if __name__ == "__main__":
    main()
