#!/usr/bin/env python3
"""
Mede a fidelidade da leitura de imagens contra um gabarito.

Cada caso é uma imagem real de campanha com o texto que uma pessoa lê na tela.
Sem essa régua, "melhorar o OCR" vira opinião: dá para trocar um erro por outro
e achar que avançou.

A métrica é taxa de erro por caractere (CER), a mesma da literatura de OCR.
0% é leitura perfeita.

Uso:
    python medir_fidelidade.py
    python medir_fidelidade.py --detalhe
"""

import argparse
import os
import sys
import time
import unicodedata
from difflib import SequenceMatcher

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from validador.ocr import ler_imagem  # noqa: E402

PASTA = "/mnt/user-data/uploads"

CASOS = [
    (
        "00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_01.gif",
        "BRADESCO, O BANCO DA PJ COMPROMISSO com você e TRANSPARÊNCIA com sua empresa",
    ),
    (
        "00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_02.jpg",
        "A partir do próximo mês, a Cesta de Serviços do seu negócio será cobrada "
        "integralmente. IMPORTANTE: Todos os serviços inclusos continuarão disponíveis.",
    ),
    (
        "00006444_D30_RELAC_INICIOO_DE_TARIFACAO_CESTA_UNIFICADA_EMKT_PERS_03.jpg",
        "bradesco empresas e negócios",
    ),
    (
        "10607_00135775_CINEMARKSALAPRIME_UNI_EMKTP_06.jpg",
        "50% de desconto no ingresso na poltrona D-BOX no combo Bradesco P ou M "
        "(pipoca doce ou salgada + bebida) 20% de desconto em itens selecionados no "
        "Menu Bradesco em 35 salas VIP 10/09: Da Magia à Sedução 2 03/09: "
        "Minha Melhor Amiga 24/09: A Ilha Esquecida",
    ),
]


def _chave(texto: str) -> str:
    """Forma literal: mantém acento, como a pessoa lê na tela."""
    texto = unicodedata.normalize("NFC", texto or "").lower()
    return "".join(c for c in texto if c.isalnum())


def _chave_comparacao(texto: str) -> str:
    """
    Forma que o validador realmente compara: sem acento nem pontuação.

    Medir só a forma literal engana. O reconhecedor devolve "voce" sem acento,
    o que conta como erro na régua bruta — mas a conferência normaliza os dois
    lados antes de comparar, então aquele "erro" nunca vira apontamento. O que
    interessa é este segundo número: o que de fato chega ao analista.
    """
    texto = unicodedata.normalize("NFD", (texto or "").lower())
    return "".join(c for c in texto
                   if unicodedata.category(c) != "Mn" and c.isalnum())


def taxa_de_erro(lido: str, esperado: str, como_validador: bool = False) -> float:
    reduzir = _chave_comparacao if como_validador else _chave
    a, b = reduzir(lido), reduzir(esperado)
    if not b:
        return 0.0
    iguais = sum(bloco.size for bloco in
                 SequenceMatcher(None, b, a, autojunk=False).get_matching_blocks())
    return max(0.0, 1 - iguais / len(b))


def medir(detalhe: bool = False) -> float:
    print("\n" + "=" * 72)
    print("  Fidelidade da leitura de imagens")
    print("=" * 72)

    total, soma, soma_efetiva, tempo_total = 0, 0.0, 0.0, 0.0
    for arquivo, esperado in CASOS:
        caminho = os.path.join(PASTA, arquivo)
        if not os.path.exists(caminho):
            print(f"   --   {arquivo[-34:]}  (ausente)")
            continue

        inicio = time.time()
        lido = ler_imagem(caminho).texto
        duracao = time.time() - inicio

        erro = taxa_de_erro(lido, esperado)
        efetivo = taxa_de_erro(lido, esperado, como_validador=True)
        total += 1
        soma += erro
        soma_efetiva += efetivo
        tempo_total += duracao

        marca = "ok " if efetivo < 0.02 else ("~  " if efetivo < 0.08 else "RUIM")
        print(f"   {marca}  {arquivo[-34:]:36} literal {erro * 100:5.1f}%  "
              f"efetivo {efetivo * 100:5.1f}%  ({duracao:4.1f}s)")
        if detalhe:
            print(f"          esperado: {esperado[:112]}")
            print(f"          lido:     {lido.replace(chr(10), ' / ')[:112]}")

    if not total:
        print("\n  Nenhuma imagem de referência encontrada.\n")
        return 1.0

    media = soma / total
    media_efetiva = soma_efetiva / total
    print("-" * 72)
    print(f"  erro literal: {media * 100:.1f}%  (inclui acento, que o validador ignora)")
    print(f"  ERRO EFETIVO: {media_efetiva * 100:.1f}%  — é o que vira apontamento")
    print(f"  tempo: {tempo_total:.1f}s")
    print("-" * 72 + "\n")
    return media_efetiva


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--detalhe", action="store_true")
    medir(p.parse_args().detalhe)
