# Validador de pacotes EMKT + SFMC Workbench

## Para rodar
Windows: duplo clique em `iniciar_validador.bat` (ou `./iniciar_validador.sh` em bash).
## Para compartilhar com quem NÃO tem Python
Gere o executável **uma vez**, num computador com Python e internet:

- Windows: duplo clique em `gerar_exe.bat` (ou `./gerar_executavel.sh` no Git Bash).
- Resultado: `dist\ValidadorEMKT\ValidadorEMKT.exe` e `dist\ValidadorEMKT.zip`.
- Mande o **.zip** para o time. Quem recebe extrai e dá duplo clique no `ValidadorEMKT.exe`
  (abre a página em http://127.0.0.1:5000). Não precisa de Python nem de internet.
  As instruções para eles estão em `LEIA-ME-USUARIO.txt` (vai dentro do zip como `LEIA-ME.txt`).
- O executável só funciona no sistema onde foi gerado: **gere no Windows** para o time que usa Windows.
- Os scripts rodam `--testar` no executável pronto e só terminam com sucesso se os 53 testes passarem.
- Relatórios, cache e `regras-time.js` ficam ao lado do `.exe` (não dentro de `_internal`).

Manualmente:
    python -m pip install flask beautifulsoup4 python-docx pillow rapidocr
    python validador_emkt_unificado.py          # abre em http://127.0.0.1:5000

O programa roda a partir de **um arquivo só**, `validador_emkt_unificado.py`.
As pastas abaixo trazem **as mesmas partes embutidas nele, como arquivos separados**,
para ler e editar com calma. `sincronizar.py` leva as edições de volta para o script.

## Estrutura
    validador_emkt_unificado.py   o programa (Flask, carregador, testes, rotas)
    sincronizar.py                extrair | montar | conferir
    validador/                    16 módulos Python: ocr, pacote, comparador, regras, imagens...
    static/
      validador.css  validador.js           aba do Validador
      workbench.css  codemirror.css  codemirror.min.js
      wb/*.js                               aba SFMC Workbench (app, parser, rules, audit, preview, report, editor, regras-time)
      wb/tests/*.js                         casos e runner dos testes do Workbench
    html/
      index.html                            página principal (as duas abas)
      workbench-tests.html                  /workbench/tests/
      validador-tests.html                  /validador/tests/
    ALTERACOES.md                 o que mudou nesta versão

## Editar
1. Edite o arquivo que quiser (por exemplo `static/validador.js`).
2. `python sincronizar.py montar` grava a mudança no script único (guarda `.bak`).
3. Rode `python validador_emkt_unificado.py`.

`python sincronizar.py conferir` diz se arquivos e script estão iguais.
Se editar o script único direto, rode `python sincronizar.py extrair` para atualizar os arquivos.
Não use `'''` dentro dos arquivos extraídos (fecharia a string do script); o `montar` avisa.

`regras-time.js`: se existir um `regras-time.js` ao lado do script, ele vale no lugar do embutido.

## Fora das pastas
Configuração inicial, carregador dos módulos, testes do Validador (`--testar`) e rotas do Flask
ficam no próprio script único.
