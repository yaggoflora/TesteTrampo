"""
Ordem de leitura derivada do desenho da peça.

O reconhecedor devolve caixas soltas com posição. Transformar isso em texto
exige decidir a ordem — e é aí que a peça de banco quebra o critério ingênuo.
Ler por faixa horizontal junta o "50%" de um cartão com o item que estiver na
mesma altura, à direita. Ler por coluna separa o número do que ele qualifica.

A técnica clássica para isso é análise de layout por projeção: somar a
ocupação das caixas ao longo de um eixo e procurar os vales — faixas vazias
que separam blocos. Aplicada alternadamente nos dois eixos (o chamado XY-cut),
ela devolve a árvore de blocos da página e, percorrendo essa árvore, a ordem
em que uma pessoa leria.

O primeiro corte é vertical e com folga larga: ele separa as SEÇÕES da peça
(um cartão, outro cartão, a faixa de filmes). Dentro de cada seção vem o corte
horizontal, que encontra as colunas, e só então o corte vertical fino, que
encontra as linhas. Essa ordem importa: cortando fino logo de início, o cartão
"50% de desconto | três itens" era picotado linha a linha e o número acabava
solto no meio da lista.

A diferença para o que já existe em ordenacao.py: lá a ordem vem do
CONTEUDO.docx, aqui vem da própria imagem. Uma não substitui a outra — esta
funciona mesmo quando o docx está errado, que é justamente quando a
conferência importa.
"""

from dataclasses import dataclass, field

# Um vale só separa blocos se for largo o bastante. Medido em relação à altura
# média das linhas: espaço menor que isso é entrelinha, não separação.
#
# O vale horizontal é mais estreito de propósito. O corte em X só acontece
# quando existe um corredor vazio atravessando o bloco inteiro de cima a
# baixo — em texto corrido isso não existe, porque as linhas ocupam toda a
# largura. Então pode ser generoso: o cartão "50% de desconto | três itens"
# tem apenas 22 px de corredor com um detector, e 14 px com outro — a caixa
# de cada motor é um pouco mais larga ou mais justa. Exigir mais que isso
# deixava o número colado no item errado, e o valor precisa caber nos dois.
VALE_MINIMO_VERTICAL = 0.9
VALE_MINIMO_HORIZONTAL = 0.42

# No primeiro corte a folga vertical é bem maior: ali o que se procura são as
# SEÇÕES da peça (um cartão, outro cartão, a faixa de filmes), não as linhas.
# Com a folga normal, o espaço entre itens de uma lista — que é maior que a
# entrelinha — separava cada item num bloco, e o número da oferta ficava solto
# no meio deles antes que alguém notasse que ali havia duas colunas.
VALE_DE_SECAO = 2.0

# Bloco de uma linha só não tem coluna para separar: cortar em X ali apenas
# picotaria a frase.
MINIMO_DE_LINHAS_PARA_CORTAR_EM_X = 2

# Abaixo deste número de caixas não vale analisar: é texto corrido.
MINIMO_PARA_ANALISAR = 4


@dataclass
class Bloco:
    caixas: list = field(default_factory=list)
    topo: float = 0.0
    esquerda: float = 0.0
    base: float = 0.0

    @property
    def texto(self) -> str:
        return "\n".join(c["texto"] for c in self.caixas)


def _altura_media(caixas: list) -> float:
    alturas = [max(1.0, c["base"] - c["topo"]) for c in caixas]
    return sum(alturas) / len(alturas)


def _cortar(caixas: list, eixo: str, folga: float) -> list:
    """
    Separa as caixas nos vales de um eixo.

    Devolve a lista de grupos. Um grupo só é um grupo quando existe uma faixa
    vazia maior que `folga` entre ele e o próximo — assim entrelinha não vira
    separação de bloco.
    """
    if eixo == "y":
        inicio, fim = "topo", "base"
    else:
        inicio, fim = "esquerda", "direita"

    ordenadas = sorted(caixas, key=lambda c: c[inicio])
    grupos, atual, limite = [], [ordenadas[0]], ordenadas[0][fim]

    for caixa in ordenadas[1:]:
        if caixa[inicio] - limite > folga:
            grupos.append(atual)
            atual = [caixa]
            limite = caixa[fim]
        else:
            atual.append(caixa)
            limite = max(limite, caixa[fim])
    grupos.append(atual)
    return grupos


def _montar(caixas: list) -> Bloco:
    return Bloco(
        caixas=sorted(caixas, key=lambda c: (c["topo"], c["esquerda"])),
        topo=min(c["topo"] for c in caixas),
        esquerda=min(c["esquerda"] for c in caixas),
        base=max(c["base"] for c in caixas),
    )


def _linhas_distintas(caixas: list, altura: float) -> int:
    """Quantas faixas horizontais diferentes o bloco ocupa."""
    faixas = {round(c["topo"] / max(1.0, altura * 0.7)) for c in caixas}
    return len(faixas)


def _percorrer(caixas: list, altura: float, cortar_em_y: bool, profundidade: int) -> list:
    """
    XY-cut: corta num eixo, e cada pedaço é cortado no outro, recursivamente.

    A recursão para quando o corte não divide mais nada — aí aquele pedaço é
    um bloco de texto, e suas caixas são lidas de cima para baixo.
    """
    if len(caixas) <= 1 or profundidade > 6:
        return [_montar(caixas)]

    eixo = "y" if cortar_em_y else "x"
    if cortar_em_y:
        folga = altura * (VALE_DE_SECAO if profundidade == 0 else VALE_MINIMO_VERTICAL)
    else:
        folga = altura * VALE_MINIMO_HORIZONTAL

    if not cortar_em_y and _linhas_distintas(caixas, altura) < MINIMO_DE_LINHAS_PARA_CORTAR_EM_X:
        grupos = [caixas]
    else:
        grupos = _cortar(caixas, eixo, folga)

    if len(grupos) == 1:
        # não dividiu neste eixo: tenta o outro
        if profundidade == 0 or cortar_em_y:
            return _percorrer(caixas, altura, not cortar_em_y, profundidade + 1)
        return [_montar(caixas)]

    blocos = []
    for grupo in grupos:
        blocos.extend(_percorrer(grupo, altura, not cortar_em_y, profundidade + 1))
    return blocos


def ordenar_por_layout(caixas: list) -> list:
    """
    Devolve as caixas na ordem de leitura que o desenho da peça sugere.

    Caixas sem posição ou em número pequeno voltam como vieram: analisar
    layout de três linhas soltas só adiciona risco.
    """
    uteis = [c for c in caixas if c.get("texto", "").strip()]
    if len(uteis) < MINIMO_PARA_ANALISAR:
        return caixas

    try:
        altura = _altura_media(uteis)
        blocos = _percorrer(uteis, altura, cortar_em_y=True, profundidade=0)
    except (KeyError, ValueError, ZeroDivisionError):
        return caixas

    # A recursão já devolve na ordem certa: ao cortar em X os grupos saem da
    # esquerda para a direita, ao cortar em Y de cima para baixo. Reordenar o
    # resultado achatado desfaz isso — os pedaços da coluna da direita passam a
    # competir um a um com a coluna da esquerda, e o número da oferta cai no
    # meio da lista.
    ordenadas = []
    for bloco in blocos:
        ordenadas.extend(bloco.caixas)
    return ordenadas


def descrever_blocos(caixas: list) -> list:
    """Os blocos detectados, para inspeção e teste."""
    uteis = [c for c in caixas if c.get("texto", "").strip()]
    if len(uteis) < MINIMO_PARA_ANALISAR:
        return [Bloco(caixas=uteis)]
    altura = _altura_media(uteis)
    return _percorrer(uteis, altura, cortar_em_y=True, profundidade=0)
