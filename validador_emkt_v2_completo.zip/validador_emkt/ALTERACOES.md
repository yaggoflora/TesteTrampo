# Alterações nesta versão

1. **Ponte Validador → Workbench**: botão "Abrir o HTML deste pacote no Workbench" no resultado.
   Rota nova `/api/preview/<id>/html`; no Workbench, `WB.abrirPeca()` (com Desfazer).
   Arquivos: static/validador.js, static/wb/app.js, static/validador.css.
2. **Acentos no OCR**: aviso na tela e no relatório quando o Tesseract está sem `por`.
   Instalador: `python validador_emkt_unificado.py --instalar-idioma-por`
   (usa a pasta do Tesseract; sem permissão, cria `tessdata/` ao lado do script).
   `TESSDATA_URL` aponta para um espelho interno. Com RapidOCR não é preciso. (validador/ocr.py, validador/pacote.py)
3. **Limpeza de relatórios**: ao abrir, apaga os com mais de 30 dias (`DIAS_RELATORIOS=15` muda; `0` desliga).
4. **Cache do OCR**: a versão da leitura é o hash só de `ocr`, `layout` e `normalizacao`. (validador/ocr.py)
5. **Testes do Validador**: 42 casos em `/validador/tests/` e `python validador_emkt_unificado.py --testar`.
   Pacotes reais opcionais em `pacotes_de_teste/PACOTE_APROVADO` e `PACOTE_ERROS`.
