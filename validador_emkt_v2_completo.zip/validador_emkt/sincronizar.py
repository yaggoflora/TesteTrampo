#!/usr/bin/env python3
"""
Sincroniza o script único com os arquivos separados.

O programa roda a partir de UM arquivo, validador_emkt_unificado.py, que traz os
módulos Python, o HTML, o CSS e o JS embutidos. Esta ferramenta deixa editar cada
parte como arquivo de verdade:

    python sincronizar.py extrair    script único  ->  validador/, static/, html/
    python sincronizar.py montar     validador/, static/, html/  ->  script único
    python sincronizar.py conferir   diz se os arquivos e o script estão iguais

"montar" só troca o que mudou e guarda uma cópia do script anterior em
validador_emkt_unificado.py.bak. Não precisa instalar nada além do Python.

O que NÃO é extraído: a configuração inicial, o carregador dos módulos, os testes
automáticos e as rotas do Flask (regiões 1, 2, 4 e 5 do script). Esses ficam no
próprio script único.
"""

import ast
import base64
import os
import sys
import zlib

PASTA = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(PASTA, "validador_emkt_unificado.py")

MODULOS = ["__init__", "normalizacao", "excecoes", "regras", "correcao_ocr", "ordenacao",
           "layout", "comparador", "presenca", "ocr", "imagens", "docx_parser",
           "html_parser", "pacote", "serializacao", "relatorio"]

# (arquivo relativo, variável no script, chave do dicionário ou None, formato)
MAPA = (
    [(f"validador/{m}.py", "_FONTES_VALIDADOR", m, "texto") for m in MODULOS]
    + [
        ("static/validador.css", "_CSS_VALIDADOR", None, "texto"),
        ("static/workbench.css", "_CSS_WORKBENCH", None, "texto"),
        ("static/codemirror.css", "_CSS_CODEMIRROR", None, "texto"),
        ("static/validador.js", "_JS_VALIDADOR", None, "texto"),
        ("static/codemirror.min.js", "_CODEMIRROR_MIN_JS_B64", None, "zlib-base64"),
    ]
    + [(f"static/wb/{n}.js", "_JS_WORKBENCH", n, "texto")
       for n in ("regras-time", "parser", "rules", "audit", "preview", "report", "editor", "app")]
    + [(f"static/wb/tests/{n}.js", "_JS_TESTES", n, "texto") for n in ("casos", "runner")]
    + [
        ("html/index.html", "_HTML_PAGINA", None, "texto"),
        ("html/workbench-tests.html", "_HTML_TESTES", None, "texto"),
        ("html/validador-tests.html", "_HTML_TESTES_VALIDADOR", None, "texto"),
    ]
)


def _ler_script() -> str:
    with open(SCRIPT, encoding="utf-8", newline="") as f:
        return f.read()


def _posicoes(fonte: str):
    """Para cada (variável, chave): (início, fim) da string no texto do script."""
    linhas = fonte.splitlines(keepends=True)
    inicio_da_linha = [0]
    for linha in linhas:
        inicio_da_linha.append(inicio_da_linha[-1] + len(linha))

    def posicao(numero, coluna_em_bytes):
        texto = linhas[numero - 1].encode("utf-8")[:coluna_em_bytes].decode("utf-8")
        return inicio_da_linha[numero - 1] + len(texto)

    achadas = {}
    for no in ast.parse(fonte).body:
        if isinstance(no, ast.Assign) and isinstance(no.targets[0], ast.Name):
            nome, valor = no.targets[0].id, no.value
        elif isinstance(no, ast.AnnAssign) and isinstance(no.target, ast.Name):
            nome, valor = no.target.id, no.value
        else:
            continue
        if isinstance(valor, ast.Dict):
            for chave, item in zip(valor.keys, valor.values):
                if isinstance(item, ast.Constant) and isinstance(item.value, str):
                    achadas[(nome, chave.value)] = (
                        posicao(item.lineno, item.col_offset),
                        posicao(item.end_lineno, item.end_col_offset), item.value)
        elif isinstance(valor, ast.Constant) and isinstance(valor.value, str):
            achadas[(nome, None)] = (
                posicao(valor.lineno, valor.col_offset),
                posicao(valor.end_lineno, valor.end_col_offset), valor.value)
    return achadas


def _texto_do_arquivo(valor: str, formato: str) -> str:
    if formato == "zlib-base64":
        return zlib.decompress(base64.b64decode(valor)).decode("utf-8")
    return valor


def _gravar(caminho: str, texto: str) -> None:
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    with open(caminho, "w", encoding="utf-8", newline="\n") as f:
        f.write(texto)


def _ler(caminho: str) -> str:
    with open(caminho, encoding="utf-8", newline="") as f:
        return f.read().replace("\r\n", "\n")     # editores do Windows trocam o fim de linha


def extrair() -> int:
    achadas = _posicoes(_ler_script())
    for arquivo, variavel, chave, formato in MAPA:
        _, _, valor = achadas[(variavel, chave)]
        _gravar(os.path.join(PASTA, arquivo), _texto_do_arquivo(valor, formato))
    print(f"{len(MAPA)} arquivos gravados em validador/, static/ e html/.")
    return 0


def _estado() -> list:
    """[(arquivo, igual?)] comparando cada arquivo com o que está dentro do script."""
    achadas = _posicoes(_ler_script())
    saida = []
    for arquivo, variavel, chave, formato in MAPA:
        caminho = os.path.join(PASTA, arquivo)
        if not os.path.isfile(caminho):
            saida.append((arquivo, None))
            continue
        _, _, valor = achadas[(variavel, chave)]
        saida.append((arquivo, _ler(caminho) == _texto_do_arquivo(valor, formato)))
    return saida


def conferir() -> int:
    diferentes = [a for a, igual in _estado() if igual is not True]
    if not diferentes:
        print("Arquivos e script único estão iguais.")
        return 0
    print("Diferem do script único:")
    for arquivo in diferentes:
        print("  ", arquivo)
    return 1


def montar() -> int:
    fonte = _ler_script()
    achadas = _posicoes(fonte)
    trocas = []
    for arquivo, variavel, chave, formato in MAPA:
        caminho = os.path.join(PASTA, arquivo)
        if not os.path.isfile(caminho):
            print(f"Faltou {arquivo}: nada a fazer com ele.")
            continue
        novo = _ler(caminho)
        inicio, fim, valor = achadas[(variavel, chave)]
        if novo == _texto_do_arquivo(valor, formato):
            continue
        if formato == "zlib-base64":
            codificado = base64.b64encode(zlib.compress(novo.encode("utf-8"), 9)).decode("ascii")
            trocas.append((inicio, fim, '"' + codificado + '"', arquivo))
            continue
        if "'''" in novo:
            print(f"ERRO em {arquivo}: tem ''' no texto, que fecharia a string do script. "
                  "Troque por \"\"\" (Python) ou outro jeito de escrever.")
            return 1
        if novo.endswith("\\") and not novo.endswith("\\\\"):
            print(f"ERRO em {arquivo}: não pode terminar em barra invertida.")
            return 1
        trocas.append((inicio, fim, "r'''" + novo + "'''", arquivo))

    if not trocas:
        print("Nada mudou: o script único já está igual aos arquivos.")
        return 0

    resultado = fonte
    for inicio, fim, texto, _ in sorted(trocas, reverse=True):
        resultado = resultado[:inicio] + texto + resultado[fim:]
    try:
        ast.parse(resultado)
    except SyntaxError as erro:
        print(f"ERRO: o script montado não compila ({erro}). Nada foi gravado.")
        return 1

    with open(SCRIPT + ".bak", "w", encoding="utf-8", newline="") as f:
        f.write(fonte)
    with open(SCRIPT, "w", encoding="utf-8", newline="") as f:
        f.write(resultado)
    print(f"Script único atualizado com {len(trocas)} arquivo(s): "
          + ", ".join(a for *_, a in sorted(trocas, key=lambda t: t[0])))
    print("A versão anterior ficou em validador_emkt_unificado.py.bak.")
    return 0


if __name__ == "__main__":
    comando = sys.argv[1] if len(sys.argv) > 1 else ""
    acoes = {"extrair": extrair, "montar": montar, "conferir": conferir}
    if comando not in acoes:
        print(__doc__)
        sys.exit(2)
    sys.exit(acoes[comando]())
