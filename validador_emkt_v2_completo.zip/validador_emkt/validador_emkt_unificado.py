#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Validador de pacotes EMKT + SFMC Workbench — Bradesco · CRM · Publicação e Orquestração
(script único)

Duas ferramentas na mesma tela, no mesmo tema (vermelho Bradesco, Manrope, claro/escuro):

  Aba "Validador de pacotes"  confere o pacote que o marketing envia: taxonomia e
                              sequência das imagens, cruzamento HTML x imagens x
                              CONTEUDO.docx, incluindo o texto dentro dos banners.
                              SOMENTE LEITURA: nada do pacote é alterado, movido ou
                              apagado. Os relatórios vão para a subpasta "relatorios",
                              ao lado deste arquivo.

  Aba "SFMC Workbench"        homologação técnica do HTML de e-mail para o Salesforce
                              Marketing Cloud: Quality Gate, links, imagens, variáveis,
                              código final, regras e preview. Roda no navegador; o
                              rascunho fica salvo só no navegador de cada pessoa.
                              Testes automáticos: http://127.0.0.1:5000/workbench/tests/

Como executar:
    python -m pip install flask beautifulsoup4 python-docx pillow rapidocr
    python validador_emkt_unificado.py

Depois acesse: http://127.0.0.1:5000 (se a porta estiver ocupada, sobe na seguinte).

Outros comandos:
    python validador_emkt_unificado.py --testar
        roda os testes automáticos do Validador no terminal (a mesma rodada que a
        página http://127.0.0.1:5000/validador/tests/ mostra). Sai com código 1 se
        algum caso falhar.
    python validador_emkt_unificado.py --instalar-idioma-por
        instala o idioma português do Tesseract. Só faz diferença se o Tesseract
        for o motor de leitura em uso; com o RapidOCR não é preciso.

Variável de ambiente:
    DIAS_RELATORIOS   relatórios com mais de tantos dias são apagados ao abrir o
                      programa (padrão 30; 0 desliga a limpeza).

Pacotes reais para os testes: se existir a pasta "pacotes_de_teste" ao lado deste
script, com as subpastas PACOTE_APROVADO e/ou PACOTE_ERROS, os testes também
conferem esses pacotes com o motor de leitura de verdade.

Organização deste arquivo (cada bloco grande abre e fecha com #region/#endregion,
que o VS Code recolhe):
  1. Configuração e mensagens de dependência
  2. Módulos do Validador, embutidos (pacote "validador") e o carregador deles
  3. Front-end embutido: HTML, CSS e JS das duas abas, CodeMirror comprimido
  4. Testes automáticos do Validador (casos, pacotes de teste, executor)
  5. Aplicação Flask (rotas, preview, status do OCR) e inicialização

Regras do time do Workbench: se existir um arquivo "regras-time.js" ao lado deste
script, ele vale no lugar das regras embutidas (é o mesmo fluxo de "Baixar como
regras-time.js" da aba Regras: salvar o arquivo na pasta do script).

CodeMirror 5 (MIT) vai embutido, comprimido; a licença está em _LICENCA_CODEMIRROR.
"""

# region 1. Configuração
import base64
import importlib.abc
import importlib.util
import os
import re
import shutil
import socket
import sys
import tempfile
import threading
import time
import uuid
import zlib

# --- Caminhos absolutos ------------------------------------------------------
# Ancorar tudo no arquivo, e não no diretório de trabalho, é o que faz o app
# subir igual pelo VS Code (que costuma usar a raiz do workspace como cwd),
# pelo duplo clique e pelo Prompt aberto em qualquer lugar.
_CAMINHO_DO_SCRIPT = os.path.abspath(__file__)
PASTA_DO_SCRIPT = os.path.dirname(_CAMINHO_DO_SCRIPT)
PASTA_RELATORIOS = os.path.join(PASTA_DO_SCRIPT, "relatorios")

# --- Limpeza automática dos relatórios ----------------------------------------
# Cada conferência grava um relatório em "relatorios", e ninguém apaga depois.
# Ao abrir o programa, os relatórios com mais de DIAS_RELATORIOS dias saem.
# O padrão é 30; para mudar sem editar o arquivo, defina a variável de ambiente
# DIAS_RELATORIOS (por exemplo, DIAS_RELATORIOS=15). Com 0 a limpeza fica desligada.
DIAS_PADRAO_DOS_RELATORIOS = 30


def _dias_dos_relatorios() -> int:
    try:
        return max(0, int(os.environ.get("DIAS_RELATORIOS", DIAS_PADRAO_DOS_RELATORIOS)))
    except ValueError:
        return DIAS_PADRAO_DOS_RELATORIOS


DIAS_RELATORIOS = _dias_dos_relatorios()

# O nome do relatório é sempre uuid4().hex[:12] + ".html". Só o que tem
# exatamente esse formato é candidato a apagar: qualquer outro arquivo que
# alguém tenha guardado na pasta fica intocado.
_RE_NOME_DE_RELATORIO = re.compile(r"^[0-9a-f]{12}\.html$")


def limpar_relatorios_antigos(dias=None, pasta=None, agora=None) -> tuple[int, int]:
    """
    Apaga os relatórios com mais de `dias` dias e devolve (apagados, bytes liberados).

    A idade vem da data de modificação do arquivo. Arquivo que não dá para
    apagar (aberto no navegador, no Windows, por exemplo) é pulado e fica para
    a próxima abertura do programa.
    """
    dias = DIAS_RELATORIOS if dias is None else dias
    pasta = pasta or PASTA_RELATORIOS
    if dias <= 0 or not os.path.isdir(pasta):
        return 0, 0

    limite = (time.time() if agora is None else agora) - dias * 86400
    apagados, liberados = 0, 0
    for nome in os.listdir(pasta):
        if not _RE_NOME_DE_RELATORIO.match(nome):
            continue
        caminho = os.path.join(pasta, nome)
        try:
            if not os.path.isfile(caminho) or os.path.getmtime(caminho) >= limite:
                continue
            tamanho = os.path.getsize(caminho)
            os.remove(caminho)
        except OSError:
            continue
        apagados += 1
        liberados += tamanho
    return apagados, liberados



def _erro_de_dependencia(erro: ImportError) -> None:
    """
    Explica o que instalar em vez de despejar um traceback.

    Sem isto, rodar pelo VS Code num interpretador diferente do que recebeu o
    pip install mostra só "ModuleNotFoundError" e não fica claro o que fazer.
    """
    faltando = getattr(erro, "name", None) or str(erro)
    equivalentes = {
        "flask": "flask",
        "bs4": "beautifulsoup4",
        "docx": "python-docx",
        "PIL": "pillow",
    }
    pacote = equivalentes.get(faltando, faltando)
    print("\n" + "=" * 66)
    print("  Falta uma biblioteca para o validador rodar:", faltando)
    print()
    print("  Instale com:")
    print(f"      {sys.executable} -m pip install {pacote}")
    print()
    print("  Ou instale tudo de uma vez:")
    print(f"      {sys.executable} -m pip install -r requirements.txt")
    print()
    print("  Se você instalou e mesmo assim aparece esta mensagem, o VS Code")
    print("  está usando outro Python. Ctrl+Shift+P > 'Python: Select")
    print("  Interpreter' e escolha o mesmo interpretador mostrado acima.")
    print("=" * 66 + "\n")
    sys.exit(1)

# endregion


# region 2. Módulos do Validador, embutidos
# Cada texto abaixo é o código de um módulo do pacote "validador", sem alteração
# de função. O carregador entrega esses textos ao `import`: assim
# "from validador import pacote" e os imports relativos entre os módulos
# continuam funcionando exatamente como na pasta original.
#
# Correções feitas em relação aos arquivos originais:
#   html_parser.py  a marca do Outlook (WordSection1) usava \b numa string raw,
#                   que procura uma barra literal e nunca casava; agora é .
#   ocr.py          PASTA_CACHE e _versao_da_leitura() deixam de depender de
#                   arquivos separados: o cache fica ao lado deste script e a
#                   versão da leitura é o resumo do texto dos módulos que
#                   decidem a leitura (ocr, layout e normalizacao). Editar a
#                   tela, as regras ou o comparador não invalida o cache.
#   ocr.py          o Tesseract sem o idioma português agora avisa na tela e
#                   no relatório, e há um instalador (--instalar-idioma-por).
#   ocr.py          a inicialização do RapidOCR (MotorRapidOCRNovo e
#                   MotorRapidOCR) ganhou trava, porque o ThreadPoolExecutor
#                   podia iniciar o motor duas vezes.

_FONTES_VALIDADOR = {
    # ---- validador/__init__.py ----------------------------------------------------
    "__init__": r'''"""Validador de pacotes de campanha — Orquestração e Ativação."""
__version__ = "1.0.0"
''',
    # ---- validador/normalizacao.py ------------------------------------------------
    "normalizacao": r'''"""
Normalização de texto.

Tudo que vem de HTML, docx e OCR passa por aqui antes de qualquer comparação.
Sem isso, aspas curvas do Word contra aspas retas do HTML viram divergência falsa
e o relatório fica cheio de erro que não é erro.
"""

import re
import unicodedata
from dataclasses import dataclass

# Substituições de caracteres que o Word, o HTML e o OCR escrevem de formas diferentes
SUBSTITUICOES = {
    "\u00a0": " ",   # espaço não-quebrável (&nbsp;)
    "\u2007": " ",
    "\u202f": " ",
    "\u200b": "",    # zero-width space
    "\ufeff": "",    # BOM
    "\u2018": "'",   # aspas simples curvas
    "\u2019": "'",
    "\u201a": "'",
    "\u201c": '"',   # aspas duplas curvas
    "\u201d": '"',
    "\u201e": '"',
    "\u2013": "-",   # en dash
    "\u2014": "-",   # em dash
    "\u2212": "-",   # sinal de menos
    "\u2026": "...",  # reticências
    "\u00ad": "",    # hífen suave
    "\u2022": " ",   # bullet
    "\u00b7": " ",
}

# Chamada de nota de rodapé. Vem de três jeitos diferentes na mesma campanha:
# caractere Unicode na peça (¹), <sup> no HTML e sobrescrito de formatação no
# Word — que o python-docx entrega como dígito comum colado na palavra. Sem
# uniformizar, "CDB¹" e "CDB1" viram divergência de texto onde não há nenhuma.
SOBRESCRITOS = {
    "\u2070": "0", "\u00b9": "1", "\u00b2": "2", "\u00b3": "3", "\u2074": "4",
    "\u2075": "5", "\u2076": "6", "\u2077": "7", "\u2078": "8", "\u2079": "9",
    "\u207a": "+", "\u207b": "-", "\u207d": "(", "\u207e": ")",
    # subscritos aparecem menos, mas pelo mesmo motivo
    "\u2080": "0", "\u2081": "1", "\u2082": "2", "\u2083": "3", "\u2084": "4",
    "\u2085": "5", "\u2086": "6", "\u2087": "7", "\u2088": "8", "\u2089": "9",
    # asterisco e daga também marcam nota
    "\u2217": "*", "\u2020": "*", "\u2021": "*",
}

# NÃO entram em SUBSTITUICOES: limpar() serve também ao texto que aparece no
# relatório e no preview lado a lado, e ali "18x¹" precisa continuar sendo
# "18x¹". A conversão para dígito comum acontece só nas formas de comparação.
_TABELA_SOBRESCRITOS = str.maketrans(SOBRESCRITOS)


def normalizar_sobrescritos(texto: str) -> str:
    """Converte ¹ ² ³ em 1 2 3, para comparar com o que o Word entrega colado."""
    return texto.translate(_TABELA_SOBRESCRITOS) if texto else texto

# Erros clássicos do OCR em fonte de peça de e-mail
CORRECOES_OCR = {
    "|": "l",
    "¦": "l",
}


def limpar(texto: str) -> str:
    """Aplica substituições de caracteres e colapsa espaços. Preserva o caso."""
    if not texto:
        return ""
    texto = unicodedata.normalize("NFC", texto)
    for de, para in SUBSTITUICOES.items():
        texto = texto.replace(de, para)
    texto = re.sub(r"[ \t\r\f\v]+", " ", texto)
    texto = re.sub(r"\n{2,}", "\n", texto)
    return texto.strip()


def sem_acento(texto: str) -> str:
    decomposto = unicodedata.normalize("NFD", texto)
    return "".join(c for c in decomposto if unicodedata.category(c) != "Mn")


def tokenizar(texto: str, ignorar_acentos: bool = True,
              ignorar_pontuacao: bool = True) -> list[str]:
    """
    Quebra o texto em palavras comparáveis.

    A comparação de sequência trabalha em cima desta lista. Manter tokens em vez
    de caracteres deixa o diff legível: o relatório aponta "palavra X virou Y",
    não "caractere 4.871 divergente".
    """
    texto = normalizar_sobrescritos(limpar(texto).lower())
    for de, para in CORRECOES_OCR.items():
        texto = texto.replace(de, para)
    if ignorar_acentos:
        texto = sem_acento(texto)
    if ignorar_pontuacao:
        # mantém R$, %, dígitos e letras — o resto vira separador
        # & entra junto com % e $: em peça de banco ele carrega sentido
        # ("Crédito & Financiamento"), não é pontuação descartável
        texto = re.sub(r"[^\w\s%$&]", " ", texto)
    tokens = [t for t in texto.split() if t]
    return tokens


# O CONTEUDO.docx costuma marcar botão entre colchetes — "[Simular crédito]".
# É convenção de escrita do documento, não pontuação da peça: comparar isso
# geraria um apontamento em todo botão de toda campanha.
RE_MARCACAO_DE_BOTAO = re.compile(r"^[\[\](){}<>]+|[\[\](){}<>]+$")


@dataclass
class Par:
    """
    Uma palavra em três formas, porque cada uma serve a um propósito.

      chave    -> compara: sem acento, sem pontuação, minúscula.
                  É o que decide se a palavra é a mesma.
      sensivel -> compara acento e pontuação: minúscula, mas com acento e com
                  a pontuação que vem colada. Separa "Olá," de "Ola".
      texto    -> aparece no relatório: exatamente como está no arquivo.
    """
    chave: str
    sensivel: str
    texto: str
    inicio: int = 0
    fim: int = 0


# um token é uma sequência de letras, dígitos, % ou $; a pontuação colada nele
# é capturada à parte, para conseguirmos apontar vírgula divergente
RE_TOKEN = re.compile(r"[\w%$&]+")
RE_PONTUACAO_COLADA = re.compile(r"^[.,;:!?)\]}\"'…]+")


def tokenizar_pares(texto: str, ignorar_acentos: bool = True) -> list[Par]:
    """
    Mesma segmentação de tokenizar(), mas devolve as três formas de cada palavra.

    Manter as três juntas é o que permite dizer "a palavra confere, só o acento
    que não" em vez de tratar tudo como divergência de conteúdo.
    """
    base = limpar(texto)
    # a forma de comparação normaliza o sobrescrito; `base` guarda o original,
    # que é o que aparece no relatório
    minuscula = normalizar_sobrescritos(base.lower())
    for de, para in CORRECOES_OCR.items():
        minuscula = minuscula.replace(de, para)

    pares = []
    for achado in RE_TOKEN.finditer(minuscula):
        bruto = achado.group()
        chave = sem_acento(bruto) if ignorar_acentos else bruto
        if not chave:
            continue
        # pontuação imediatamente depois da palavra, ainda sem espaço no meio
        depois = minuscula[achado.end():achado.end() + 4]
        sufixo = ""
        encontrado = RE_PONTUACAO_COLADA.match(depois)
        if encontrado:
            sufixo = encontrado.group()
        pares.append(Par(
            chave=chave,
            sensivel=RE_MARCACAO_DE_BOTAO.sub("", bruto + sufixo),
            texto=base[achado.start():achado.end() + len(sufixo)],
            inicio=achado.start(),
            fim=achado.end() + len(sufixo),
        ))
    return pares


def texto_para_exibicao(texto: str) -> str:
    """Versão limpa mas legível, usada no relatório (preserva caso e acento)."""
    return limpar(texto)
''',
    # ---- validador/excecoes.py ----------------------------------------------------
    "excecoes": r'''"""
Trechos com tratamento especial na comparação.

Dois grupos, com efeitos opostos:

DISPENSÁVEIS — texto de template que não precisa constar no CONTEUDO.docx.
  Hoje: o link de fallback do topo ("se não conseguiu visualizar, clique aqui").
  Estar no HTML e faltar no docx não é erro. Se o analista incluir no docx,
  também não é erro — a comparação continua casando normalmente.

OBRIGATÓRIOS — disclaimer, opt-out e canais de atendimento.
  Faltar no docx é apontamento de gravidade alta e sinalizado como obrigatório
  no relatório, porque é conteúdo que o cliente com deficiência visual tem
  direito de receber.

Ajuste as listas conforme o padrão das peças. Um trecho que case com as duas
listas é tratado como obrigatório — na dúvida, o sistema cobra.
"""

import re

# --- texto de template, dispensável no CONTEUDO.docx ---
DISPENSAVEIS = [
    # o verbo aparece em todas as conjugações que já vimos em pacote real:
    # conseguiu, consegue, conseguir, conseguindo, consiga
    r"n[ãa]o\s+(est[áa]\s+)?conseg(uiu|ue|uir|uindo)",
    r"n[ãa]o\s+(consiga|conseguiu|consegue|conseguir)",
    r"(problemas?|dificuldade)\s+(para|ao|em)\s+(visualizar|ver|abrir)",
    r"caso\s+n[ãa]o\s+(consiga|esteja|visualize)",
    r"visualiz(e|ar|ando)\s+(no|em seu|pelo)\s+navegador",
    r"vers[ãa]o\s+(online|web)\s+(deste|do|desta)",
    r"clique\s+aqui\s+para\s+(visualizar|ver|abrir|acessar)",
    r"abrir\s+ess[ea]\s+e-?\s?mail",
    r"n[ãa]o\s+(está|esta)\s+(vendo|visualizando)",
]

# --- conteúdo que precisa estar no docx ---
OBRIGATORIOS = {
    "opt-out": [
        r"descadastr",
        r"cancelar\s+(o\s+)?(recebimento|inscri)",
        r"n[ãa]o\s+(desejo|quero|deseja)\s+(mais\s+)?receber",
        r"sair\s+da\s+lista",
        r"opt.?out",
        r"deixar\s+de\s+receber",
    ],
    "disclaimer": [
        r"sujeito\s+[àa]\s+(an[áa]lise|aprova[çc][ãa]o)",
        r"consulte\s+(as\s+)?condi[çc][õo]es",
        r"cet\b|custo\s+efetivo\s+total",
        r"taxa\s+de\s+juros",
        r"v[áa]lid[ao]\s+(at[ée]|para)",
        r"imagens?\s+meramente\s+ilustrativ",
        r"regulamento",
        r"cnpj",
        # rodapé padrão das peças do banco — é onde o endereço aparece e onde
        # a proteção contra hyperlink precisa estar
        r"mensagem\s+foi\s+gerada\s+automaticamente",
        r"n[ãa]o\s+pode\s+ser\s+respondida",
        r"remetentes\s+confi[áa]veis",
        r"n[ãa]o\s+insere\s+anexos",
        r"mantenha\s+seus\s+dados\s+atualizados",
        r"dados\s+banc[áa]rios\s+ou\s+pessoais",
        r"hor[áa]rio\s+de\s+bras[íi]lia",
        r"acesso\s+do\s+exterior",
    ],
    "atendimento": [
        r"ouvidoria",
        r"central\s+de\s+(atendimento|relacionamento)",
        r"fale\s+conosco",
        r"sac\b",
        r"deficiente\s+auditiv|fala\s+e\s+audi[çc][ãa]o",
        r"procon",
    ],
}

# --- trechos em que a divergência notifica, mas não reprova ---------------
#
# O bloco de redes sociais é o caso clássico: na peça vem só a palavra
# "ACOMPANHE:" seguida dos ícones, e no docx o redator escreve a frase inteira
# ("Acompanhe o Bradesco nas Redes Sociais!"). Os dois estão certos, cada um no
# seu suporte — cobrar igualdade aí reprovaria praticamente toda campanha.
TOLERADOS = [
    r"acompanhe",
    r"redes\s+sociais",
    r"\b(siga|curta)\b.{0,20}(bradesco|nas\s+redes)",
    r"\b(facebook|instagram|linkedin|youtube|twitter|tiktok|whatsapp)\b",
]

_RE_TOLERADOS = [re.compile(p, re.IGNORECASE) for p in TOLERADOS]
_RE_DISPENSAVEIS = [re.compile(p, re.IGNORECASE) for p in DISPENSAVEIS]
_RE_OBRIGATORIOS = {
    rotulo: [re.compile(p, re.IGNORECASE) for p in padroes]
    for rotulo, padroes in OBRIGATORIOS.items()
}


def classificar(texto: str) -> str:
    """
    Devolve "obrigatorio:<rótulo>", "dispensavel", "tolerado" ou "".
    Obrigatório vence os demais quando mais de um casa.
    """
    if not texto:
        return ""
    for rotulo, padroes in _RE_OBRIGATORIOS.items():
        if any(p.search(texto) for p in padroes):
            return f"obrigatorio:{rotulo}"
    if any(p.search(texto) for p in _RE_DISPENSAVEIS):
        return "dispensavel"
    if any(p.search(texto) for p in _RE_TOLERADOS):
        return "tolerado"
    return ""
''',
    # ---- validador/regras.py ------------------------------------------------------
    "regras": r'''"""
Regras de publicação de EMKT.

Ficam separadas do resto de propósito: são as regras do banco, mudam por
decisão de processo e não por mudança técnica. Quando o padrão do time mudar,
é aqui que se mexe — sem tocar em parser, comparador ou tela.

Três níveis:
  BLOQUEIO  — impede a publicação. Ex.: HTML sem nenhum redirect.
  ALERTA    — não impede, mas o analista precisa saber. Ex.: assunto longo.
  LIMITE    — número usado nas contas acima.
"""

import re

# ------------------------------------------------------------------ limites

# Assunto e pré-header: passar do limite não proíbe a publicação, mas corta na
# caixa de entrada de vários clientes. Vira alerta discreto, não apontamento.
LIMITE_ASSUNTO = 35
LIMITE_PRE_HEADER = 40

# Peso de imagem: acima disso a peça fica pesada para abrir no e-mail.
LIMITE_IMAGEM_KB = 1024  # 1 MB


# ----------------------------------------------------------------- redirect

# Pelo menos um redirect é obrigatório no HTML. Os padrões abaixo cobrem as
# formas mais comuns de escrever a chamada; acrescente aqui se o time usar
# outra. A busca é feita no código inteiro, não só nos links, porque o redirect
# às vezes aparece dentro de AMPScript ou de atributo de rastreio.
PADROES_REDIRECT = [
    r"redirect",
    r"\bredir\b",
    r"redirecionamento",
]

_RE_REDIRECT = [re.compile(p, re.IGNORECASE) for p in PADROES_REDIRECT]


def contar_redirects(codigo_html: str) -> int:
    """Quantas ocorrências de redirect existem no código."""
    if not codigo_html:
        return 0
    total = 0
    for padrao in _RE_REDIRECT:
        total += len(padrao.findall(codigo_html))
    return total


# ------------------------------------------------------- assunto e pré-header

# O pré-header precisa terminar em pontuação final — qualquer uma delas. Ponto,
# exclamação e interrogação são igualmente válidos, e na prática "!" aparece
# mais que o ponto nas chamadas. Reticências contam, e fechamento de aspas ou
# parêntese depois da pontuação também.
PONTUACAO_FINAL = ".!?…"

RE_TERMINA_EM_PONTO = re.compile(
    r"[.!?\u2026](?:[\"'\u201d\u2019\u00bb)\]]*)\s*$"
)


def pre_header_tem_ponto_final(texto: str) -> bool:
    if not texto or not texto.strip():
        return False
    return bool(RE_TERMINA_EM_PONTO.search(texto.strip()))


def excedeu(texto: str, limite: int) -> int:
    """Quantos caracteres passaram do limite. Zero quando está dentro."""
    if not texto:
        return 0
    return max(0, len(texto.strip()) - limite)


# ------------------------------------------- hyperlink automático no disclaimer

# Cliente de e-mail transforma sozinho qualquer coisa com cara de endereço em
# link clicável. No disclaimer isso não pode acontecer, então a peça separa os
# caracteres com um invisível — normalmente &#xFEFF; (zero-width no-break
# space), às vezes &zwnj; ou &#8203; — bem no ponto onde o cliente procuraria o
# padrão de domínio. Sem esse código, o link é gerado e a peça não sobe.
INVISIVEIS_ANTI_LINK = ["\ufeff", "\u200b", "\u200c", "\u200d", "\u2060"]

RE_ENDERECO = re.compile(
    r"(?:https?://|www\.)[^\s<>\"']{4,}"                    # URL explícita
    r"|[a-z0-9][a-z0-9\-]{1,}\.(?:com|br|net|org|gov)\b[^\s<>\"']*"  # domínio
    r"|[a-z0-9][a-z0-9\-]{1,}\.[a-z]{2,}/[^\s<>\"']+"        # banco.bradesco/algo
    r"|[\w.\-]+@[\w\-]+\.[a-z]{2,}",                        # e-mail
    re.IGNORECASE,
)


def enderecos_sem_protecao(texto_bruto: str) -> list[str]:
    """
    Acha endereços dentro de um trecho que virariam link clicável.

    Recebe o texto BRUTO, com os invisíveis preservados: é justamente a
    presença deles que diz se a proteção foi aplicada. Depois da limpeza eles
    somem e não há mais como saber.
    """
    if not texto_bruto:
        return []

    # o invisível fica no meio do endereço; para achar o padrão é preciso
    # olhar o texto sem ele, e depois conferir o trecho original
    sem_invisiveis = texto_bruto
    for marca in INVISIVEIS_ANTI_LINK:
        sem_invisiveis = sem_invisiveis.replace(marca, "")

    desprotegidos = []
    for achado in RE_ENDERECO.finditer(sem_invisiveis):
        endereco = achado.group().rstrip(".,;:)")
        if len(endereco) < 6:
            continue
        # o endereço está protegido se o original traz algum invisível entre
        # os caracteres dele
        trecho_original = _trecho_original(texto_bruto, endereco)
        if not any(marca in trecho_original for marca in INVISIVEIS_ANTI_LINK):
            desprotegidos.append(endereco)
    return desprotegidos


def _trecho_original(texto_bruto: str, endereco: str) -> str:
    """Recorta no texto bruto a região que corresponde ao endereço encontrado."""
    letras = [c for c in endereco]
    posicao, inicio = 0, None
    for indice, caractere in enumerate(texto_bruto):
        if caractere in INVISIVEIS_ANTI_LINK:
            continue
        if posicao < len(letras) and caractere == letras[posicao]:
            if inicio is None:
                inicio = indice
            posicao += 1
            if posicao == len(letras):
                return texto_bruto[inicio:indice + 1]
        else:
            posicao, inicio = 0, None
            if caractere == letras[0]:
                inicio, posicao = indice, 1
    return ""


# ------------------------------------------------------------ datas vencidas

MESES = {
    "janeiro": 1, "fevereiro": 2, "marco": 3, "março": 3, "abril": 4,
    "maio": 5, "junho": 6, "julho": 7, "agosto": 8, "setembro": 9,
    "outubro": 10, "novembro": 11, "dezembro": 12,
}

RE_DATA_NUMERICA = re.compile(r"\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})\b")
RE_DATA_POR_EXTENSO = re.compile(
    r"\b(\d{1,2})\s+de\s+([a-zç]+)\s+de\s+(\d{4})\b", re.IGNORECASE
)


def datas_vencidas(texto: str, hoje=None) -> list[str]:
    """
    Devolve as datas do texto que já passaram.

    Prazo de campanha aparece no disclaimer, no banner e no texto do código, e
    peça reaproveitada de mês anterior costuma trazer a data antiga junto. Vira
    aviso, não bloqueio: às vezes a data passada é proposital (início de
    vigência, data de contrato), e quem decide isso é o analista.
    """
    from datetime import date

    hoje = hoje or date.today()
    vencidas = []

    for dia, mes, ano in RE_DATA_NUMERICA.findall(texto or ""):
        try:
            ano_cheio = int(ano)
            if ano_cheio < 100:
                ano_cheio += 2000
            achada = date(ano_cheio, int(mes), int(dia))
        except ValueError:
            continue
        # datas muito antigas são ano de fundação, CNPJ, número solto
        if achada < hoje and (hoje - achada).days < 900:
            texto_data = f"{int(dia):02d}/{int(mes):02d}/{ano_cheio}"
            if texto_data not in vencidas:
                vencidas.append(texto_data)

    for dia, nome_mes, ano in RE_DATA_POR_EXTENSO.findall(texto or ""):
        numero = MESES.get(nome_mes.lower())
        if not numero:
            continue
        try:
            achada = date(int(ano), numero, int(dia))
        except ValueError:
            continue
        if achada < hoje and (hoje - achada).days < 900:
            texto_data = f"{dia} de {nome_mes} de {ano}"
            if texto_data not in vencidas:
                vencidas.append(texto_data)

    return vencidas
''',
    # ---- validador/correcao_ocr.py ------------------------------------------------
    "correcao_ocr": r'''"""
Correção dos erros típicos de OCR, antes de comparar.

Motor de OCR erra de dois jeitos previsíveis em peça de e-mail:

  1. cola palavras vizinhas      "SemconsultaaoSPCeSerasa"
  2. troca caractere parecido    "ate l dia" (leu 1 como L), "a0 mes"

Se comparar sem tratar isso, quase toda imagem vira apontamento falso e o
sistema perde a serventia — você voltaria a conferir tudo no olho.

A saída aqui é usar o próprio CONTEUDO.docx como dicionário. Ele tem a grafia
correta do que deveria estar na peça: quando um pedaço colado se decompõe
exatamente em palavras do docx, foi erro de leitura, não divergência real.

O que NÃO é corrigido: número que existe de verdade. "48" contra "60" continua
divergência, porque a correção só aceita reescrita que case com o docx, e
nenhuma confusão conhecida transforma 4 em 6 ou 8 em 0.
"""

from .normalizacao import tokenizar

# caracteres que os motores confundem com frequência
CONFUSOES = str.maketrans({
    "0": "o", "1": "l", "5": "s", "8": "b",
    "|": "l", "¦": "l", "!": "l",
})

TAMANHO_MINIMO_PARA_SEGMENTAR = 6
# Uma linha inteira de banner pode vir colada ("dinheironacontaemateldiautil"
# são oito palavras). O teto existe só para evitar decomposições absurdas; a
# exigência de que TODO pedaço exista no docx já é a trava de verdade.
MAXIMO_DE_PEDACOS = 12


def canonizar(token: str) -> str:
    """
    Forma usada só para decidir se dois tokens são o mesmo.

    Nunca é exibida no relatório: o que aparece na tela continua sendo o texto
    original, para você conseguir localizar o trecho na peça.
    """
    return token.translate(CONFUSOES)


def _segmentar(colado: str, vocabulario: set[str]) -> list[str] | None:
    """
    Tenta quebrar um token colado em palavras que existam no docx.

    Programação dinâmica simples: para cada posição, guarda a menor quantidade
    de pedaços que chega até ali. Preferir menos pedaços evita decompor uma
    palavra legítima em partículas ("consulta" virando "con" + "sul" + "ta").
    """
    n = len(colado)
    melhor: list[list[str] | None] = [None] * (n + 1)
    melhor[0] = []

    for fim in range(1, n + 1):
        for inicio in range(fim - 1, -1, -1):
            if melhor[inicio] is None:
                continue
            pedaco = colado[inicio:fim]
            if len(pedaco) < 2 and pedaco not in vocabulario:
                continue
            if pedaco not in vocabulario:
                continue
            candidato = melhor[inicio] + [pedaco]
            if len(candidato) > MAXIMO_DE_PEDACOS:
                continue
            if melhor[fim] is None or len(candidato) < len(melhor[fim]):
                melhor[fim] = candidato

    resultado = melhor[n]
    return resultado if resultado and len(resultado) > 1 else None


def construir_vocabulario(paragrafos: list[str]) -> set[str]:
    """Todas as palavras do docx, em forma canônica."""
    vocabulario = set()
    for paragrafo in paragrafos:
        for palavra in tokenizar(paragrafo):
            vocabulario.add(canonizar(palavra))
    return vocabulario


def corrigir(tokens: list[str], vocabulario: set[str]) -> tuple[list[str], list[str]]:
    """
    Devolve (tokens corrigidos, lista do que foi separado).

    Só mexe no token que não existe no docx e que se decompõe inteiramente em
    palavras do docx. Qualquer outro caso passa intacto — na dúvida, o sistema
    deixa a divergência aparecer em vez de escondê-la com uma correção criativa.
    """
    saida, separados = [], []
    for token in tokens:
        canonico = canonizar(token)
        if canonico in vocabulario:
            saida.append(token)
            continue
        # caractere solto que não existe no docx é sujeira de leitura: uma borda
        # lida como parêntese, um pingo lido como ponto. Manter só produz
        # apontamento falso.
        if len(canonico) == 1:
            separados.append(f"{token} → removido (ruído de leitura)")
            continue
        if len(canonico) < TAMANHO_MINIMO_PARA_SEGMENTAR:
            saida.append(token)
            continue
        pedacos = _segmentar(canonico, vocabulario)
        if pedacos:
            saida.extend(pedacos)
            separados.append(f"{token} → {' '.join(pedacos)}")
        else:
            saida.append(token)
    return saida, separados


def tokens_iguais(a: str, b: str) -> bool:
    return canonizar(a) == canonizar(b)
''',
    # ---- validador/ordenacao.py ---------------------------------------------------
    "ordenacao": r'''"""
Ordem de leitura dentro de uma imagem, usando o CONTEUDO.docx como referência.

O problema: peça de banco usa layout em blocos. "50%" fica num cartão à
esquerda, "de desconto" embaixo dele, e três itens numa lista à direita. Não
existe uma ordem de leitura única aí — ler por linha horizontal junta o "50%"
com o item que estiver na mesma altura; ler por coluna separa o número do
desconto do que ele qualifica. Qualquer critério que a máquina escolha é um
chute, e o chute vira apontamento de "ordem diferente" em quase toda peça.

Quem sabe a ordem certa é quem escreveu a peça, e isso está no docx.

A regra aqui é conservadora de propósito: a reordenação só acontece quando
TODAS as linhas lidas da imagem são encontradas no docx. Se uma linha não
aparece lá — porque tem palavra trocada, porque o docx esqueceu um trecho —
nada é reordenado e a divergência aparece normalmente. Ou seja: isso silencia
ruído de diagramação, não silencia erro de conteúdo.

Vale só DENTRO de cada imagem. A ordem entre os blocos da peça (o banner 01
vem antes do 02, o texto do código vem onde está no HTML) continua sendo
conferida como sempre.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr
from .normalizacao import limpar, tokenizar, tokenizar_pares

# Quanto de uma linha precisa ser encontrado no docx para considerarmos que ela
# está lá. Abaixo disso é coincidência de palavra comum ("de", "no", "em").
COBERTURA_MINIMA = 0.6


@dataclass
class ResultadoOrdenacao:
    linhas: list[str] = field(default_factory=list)
    reordenou: bool = False
    motivo: str = ""


def _posicao_no_docx(tokens_linha: list[str], tokens_docx: list[str]) -> int | None:
    """
    Onde esta linha aparece no docx.

    Devolve o índice do trecho correspondente, ou None se a linha não estiver
    lá. Usa o maior bloco em comum em vez de igualdade: leitura de imagem erra
    caractere, e exigir texto idêntico faria a busca falhar justamente nas
    imagens que mais precisam de ajuda.
    """
    if not tokens_linha or not tokens_docx:
        return None

    matcher = SequenceMatcher(None, tokens_docx, tokens_linha, autojunk=False)
    bloco = matcher.find_longest_match(0, len(tokens_docx), 0, len(tokens_linha))
    if bloco.size == 0:
        return None
    if bloco.size / len(tokens_linha) < COBERTURA_MINIMA:
        return None
    return bloco.a


def _partir_linha(linha: str, paragrafos_docx: list[list[str]],
                  usadas: set | None = None) -> list[tuple] | None:
    """
    Quebra a linha nos pedaços que existem no docx, cada um com sua posição.

    O motor agrupa por faixa horizontal, então dois cartões lado a lado viram
    uma linha só: "03/09: 24/09:" e "Minha Melhor Amiga A Ilha Esquecida" são
    quatro trechos de dois cartões diferentes. Exigir que a linha inteira
    exista no docx faria o alinhamento desistir justamente nas peças de layout
    mais complexo, que são as que mais precisam dele.

    Devolve None quando sobra algum pedaço sem correspondência — aí existe
    divergência de conteúdo e nada deve ser reordenado.
    """
    # os pares mantêm o texto como está na peça ao lado da forma de comparação:
    # a busca usa a canônica, o resultado exibe a original
    pares = tokenizar_pares(linha)
    if not pares:
        return None
    tokens = [correcao_ocr.canonizar(p.chave) for p in pares]
    base = limpar(linha)

    usadas = usadas if usadas is not None else set()
    pedacos, inicio = [], 0
    while inicio < len(tokens):
        melhor_tamanho, melhor_posicao = 0, None
        # procura o maior pedaço, a partir daqui, que exista no docx
        for fim in range(len(tokens), inicio, -1):
            posicao = _posicao_exata(tokens[inicio:fim], paragrafos_docx, usadas)
            if posicao is not None:
                melhor_tamanho, melhor_posicao = fim - inicio, posicao
                break
        if not melhor_tamanho:
            return None
        # marca as posições consumidas por este pedaço
        for deslocamento in range(melhor_tamanho):
            usadas.add(melhor_posicao + deslocamento)
        # recorta direto do texto original em vez de juntar os tokens: assim a
        # barra de "03/09:" e os parênteses de "(pipoca...)" sobrevivem
        primeiro = pares[inicio]
        ultimo = pares[inicio + melhor_tamanho - 1]
        pedacos.append((melhor_posicao, base[primeiro.inicio:ultimo.fim].strip()))
        inicio += melhor_tamanho
    return pedacos


def _posicao_exata(sub: list[str], paragrafos: list[list[str]],
                   usadas: set | None = None) -> int | None:
    """
    Posição da sequência no docx, respeitando a fronteira dos parágrafos.

    Procurar num texto corrido deixava o trecho casar atravessando o fim de um
    parágrafo e o começo do outro: "de desconto no" casava com o fim de "50% de
    desconto" somado ao início de "no ingresso", e o alinhamento saía torto.
    Cada parágrafo é uma unidade — o redator quebrou ali de propósito.

    A posição devolvida é global (parágrafo e deslocamento juntos), só para
    ordenar.
    """
    if not sub:
        return None
    usadas = usadas or set()
    for indice, tokens in enumerate(paragrafos):
        if len(sub) > len(tokens):
            continue
        primeiro = sub[0]
        for i in range(len(tokens) - len(sub) + 1):
            if tokens[i] != primeiro or tokens[i:i + len(sub)] != sub:
                continue
            posicao = indice * 10000 + i
            # Cada pedaço do docx vale uma vez só. "de desconto" aparece em
            # "50% de desconto" e de novo em "20% de desconto": sem marcar o
            # que já foi usado, as duas leituras casam com a primeira
            # ocorrência e os dois acabam empilhados no mesmo cartão, deixando
            # o segundo número sem o seu rótulo.
            if posicao in usadas:
                continue
            return posicao
    return None


def alinhar_por_referencia(texto_da_imagem: str,
                           paragrafos_docx: list[str]) -> ResultadoOrdenacao:
    """
    Reordena o que foi lido da imagem na ordem em que o docx escreveu.
    """
    linhas = [l for l in (texto_da_imagem or "").splitlines() if l.strip()]
    if len(linhas) < 2:
        return ResultadoOrdenacao(linhas=linhas)

    por_paragrafo = []
    for paragrafo in paragrafos_docx:
        tokens = [correcao_ocr.canonizar(t) for t in tokenizar(paragrafo)]
        if tokens:
            por_paragrafo.append(tokens)
    if not por_paragrafo:
        return ResultadoOrdenacao(linhas=linhas)

    trechos = []
    usadas: set = set()
    for indice, linha in enumerate(linhas):
        pedacos = _partir_linha(linha, por_paragrafo, usadas)
        if pedacos is None:
            # trecho fora do docx significa divergência de conteúdo:
            # reordenar aqui esconderia justamente o que precisa aparecer
            return ResultadoOrdenacao(
                linhas=linhas,
                motivo=f"trecho não encontrado no docx: {linha[:60]}",
            )
        for ordem_interna, (posicao, texto) in enumerate(pedacos):
            trechos.append((posicao, indice, ordem_interna, texto))

    ordenados = [t for _, _, _, t in sorted(trechos, key=lambda x: (x[0], x[1], x[2]))]
    if ordenados == linhas:
        return ResultadoOrdenacao(linhas=linhas)

    return ResultadoOrdenacao(
        linhas=ordenados,
        reordenou=True,
        motivo="ordem ajustada pela sequência do CONTEUDO.docx",
    )
''',
    # ---- validador/layout.py ------------------------------------------------------
    "layout": r'''"""
Ordem de leitura derivada do desenho da peça.

O reconhecedor devolve caixas soltas com posição. Transformar isso em texto
exige decidir a ordem — e é aí que a peça de banco quebra o critério ingênuo.
Ler por faixa horizontal junta o "50%" de um cartão com o item que estiver na
mesma altura, à direita. Ler por coluna separa o número do que ele qualifica.

A técnica clássica para isso é análise de layout por projeção: somar a
ocupação das caixas ao longo de um eixo e procurar os vales — faixas vazias
que separam blocos. Aplicada alternadamente nos dois eixos (o chamado XY-cut),
ela devolve a árvore de blocos da página e, percorrendo essa árvore, a ordem
em que uma pessoa leria.

O primeiro corte é vertical e com folga larga: ele separa as SEÇÕES da peça
(um cartão, outro cartão, a faixa de filmes). Dentro de cada seção vem o corte
horizontal, que encontra as colunas, e só então o corte vertical fino, que
encontra as linhas. Essa ordem importa: cortando fino logo de início, o cartão
"50% de desconto | três itens" era picotado linha a linha e o número acabava
solto no meio da lista.

A diferença para o que já existe em ordenacao.py: lá a ordem vem do
CONTEUDO.docx, aqui vem da própria imagem. Uma não substitui a outra — esta
funciona mesmo quando o docx está errado, que é justamente quando a
conferência importa.
"""

from dataclasses import dataclass, field

# Um vale só separa blocos se for largo o bastante. Medido em relação à altura
# média das linhas: espaço menor que isso é entrelinha, não separação.
#
# O vale horizontal é mais estreito de propósito. O corte em X só acontece
# quando existe um corredor vazio atravessando o bloco inteiro de cima a
# baixo — em texto corrido isso não existe, porque as linhas ocupam toda a
# largura. Então pode ser generoso: o cartão "50% de desconto | três itens"
# tem apenas 22 px de corredor com um detector, e 14 px com outro — a caixa
# de cada motor é um pouco mais larga ou mais justa. Exigir mais que isso
# deixava o número colado no item errado, e o valor precisa caber nos dois.
VALE_MINIMO_VERTICAL = 0.9
VALE_MINIMO_HORIZONTAL = 0.42

# No primeiro corte a folga vertical é bem maior: ali o que se procura são as
# SEÇÕES da peça (um cartão, outro cartão, a faixa de filmes), não as linhas.
# Com a folga normal, o espaço entre itens de uma lista — que é maior que a
# entrelinha — separava cada item num bloco, e o número da oferta ficava solto
# no meio deles antes que alguém notasse que ali havia duas colunas.
VALE_DE_SECAO = 2.0

# Bloco de uma linha só não tem coluna para separar: cortar em X ali apenas
# picotaria a frase.
MINIMO_DE_LINHAS_PARA_CORTAR_EM_X = 2

# Abaixo deste número de caixas não vale analisar: é texto corrido.
MINIMO_PARA_ANALISAR = 4


@dataclass
class Bloco:
    caixas: list = field(default_factory=list)
    topo: float = 0.0
    esquerda: float = 0.0
    base: float = 0.0

    @property
    def texto(self) -> str:
        return "\n".join(c["texto"] for c in self.caixas)


def _altura_media(caixas: list) -> float:
    alturas = [max(1.0, c["base"] - c["topo"]) for c in caixas]
    return sum(alturas) / len(alturas)


def _cortar(caixas: list, eixo: str, folga: float) -> list:
    """
    Separa as caixas nos vales de um eixo.

    Devolve a lista de grupos. Um grupo só é um grupo quando existe uma faixa
    vazia maior que `folga` entre ele e o próximo — assim entrelinha não vira
    separação de bloco.
    """
    if eixo == "y":
        inicio, fim = "topo", "base"
    else:
        inicio, fim = "esquerda", "direita"

    ordenadas = sorted(caixas, key=lambda c: c[inicio])
    grupos, atual, limite = [], [ordenadas[0]], ordenadas[0][fim]

    for caixa in ordenadas[1:]:
        if caixa[inicio] - limite > folga:
            grupos.append(atual)
            atual = [caixa]
            limite = caixa[fim]
        else:
            atual.append(caixa)
            limite = max(limite, caixa[fim])
    grupos.append(atual)
    return grupos


def _montar(caixas: list) -> Bloco:
    return Bloco(
        caixas=sorted(caixas, key=lambda c: (c["topo"], c["esquerda"])),
        topo=min(c["topo"] for c in caixas),
        esquerda=min(c["esquerda"] for c in caixas),
        base=max(c["base"] for c in caixas),
    )


def _linhas_distintas(caixas: list, altura: float) -> int:
    """Quantas faixas horizontais diferentes o bloco ocupa."""
    faixas = {round(c["topo"] / max(1.0, altura * 0.7)) for c in caixas}
    return len(faixas)


def _percorrer(caixas: list, altura: float, cortar_em_y: bool, profundidade: int) -> list:
    """
    XY-cut: corta num eixo, e cada pedaço é cortado no outro, recursivamente.

    A recursão para quando o corte não divide mais nada — aí aquele pedaço é
    um bloco de texto, e suas caixas são lidas de cima para baixo.
    """
    if len(caixas) <= 1 or profundidade > 6:
        return [_montar(caixas)]

    eixo = "y" if cortar_em_y else "x"
    if cortar_em_y:
        folga = altura * (VALE_DE_SECAO if profundidade == 0 else VALE_MINIMO_VERTICAL)
    else:
        folga = altura * VALE_MINIMO_HORIZONTAL

    if not cortar_em_y and _linhas_distintas(caixas, altura) < MINIMO_DE_LINHAS_PARA_CORTAR_EM_X:
        grupos = [caixas]
    else:
        grupos = _cortar(caixas, eixo, folga)

    if len(grupos) == 1:
        # não dividiu neste eixo: tenta o outro
        if profundidade == 0 or cortar_em_y:
            return _percorrer(caixas, altura, not cortar_em_y, profundidade + 1)
        return [_montar(caixas)]

    blocos = []
    for grupo in grupos:
        blocos.extend(_percorrer(grupo, altura, not cortar_em_y, profundidade + 1))
    return blocos


def ordenar_por_layout(caixas: list) -> list:
    """
    Devolve as caixas na ordem de leitura que o desenho da peça sugere.

    Caixas sem posição ou em número pequeno voltam como vieram: analisar
    layout de três linhas soltas só adiciona risco.
    """
    uteis = [c for c in caixas if c.get("texto", "").strip()]
    if len(uteis) < MINIMO_PARA_ANALISAR:
        return caixas

    try:
        altura = _altura_media(uteis)
        blocos = _percorrer(uteis, altura, cortar_em_y=True, profundidade=0)
    except (KeyError, ValueError, ZeroDivisionError):
        return caixas

    # A recursão já devolve na ordem certa: ao cortar em X os grupos saem da
    # esquerda para a direita, ao cortar em Y de cima para baixo. Reordenar o
    # resultado achatado desfaz isso — os pedaços da coluna da direita passam a
    # competir um a um com a coluna da esquerda, e o número da oferta cai no
    # meio da lista.
    ordenadas = []
    for bloco in blocos:
        ordenadas.extend(bloco.caixas)
    return ordenadas


def descrever_blocos(caixas: list) -> list:
    """Os blocos detectados, para inspeção e teste."""
    uteis = [c for c in caixas if c.get("texto", "").strip()]
    if len(uteis) < MINIMO_PARA_ANALISAR:
        return [Bloco(caixas=uteis)]
    altura = _altura_media(uteis)
    return _percorrer(uteis, altura, cortar_em_y=True, profundidade=0)
''',
    # ---- validador/comparador.py --------------------------------------------------
    "comparador": r'''"""
Comparação entre a fita de leitura do HTML e o CONTEUDO.docx.

Trabalha com sequência, não com conjunto: além de acusar palavra faltando ou
trocada, detecta trecho fora de ordem — o caso de a imagem 03 aparecer antes da
02 no HTML, ou de o redator ter digitado os blocos na ordem errada no docx.

Cada token carrega a origem (texto vivo ou nome do arquivo de imagem), então o
apontamento diz onde olhar em vez de só dizer que não bateu.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr, excecoes, ordenacao
from .normalizacao import tokenizar, tokenizar_pares


@dataclass
class Token:
    valor: str                # forma de comparação: sem acento nem pontuação
    origem: str               # "texto vivo" ou nome do arquivo
    indice_bloco: int
    classificacao: str = ""   # "dispensavel" | "obrigatorio:<rótulo>" | ""
    sensivel: str = ""        # minúscula, com acento e pontuação colada
    texto: str = ""           # exatamente como está no arquivo


@dataclass
class Divergencia:
    tipo: str            # "faltando" | "sobrando" | "trocado" | "fora_de_ordem"
    origem: str
    trecho_html: str = ""
    trecho_docx: str = ""
    contexto_antes: str = ""
    contexto_depois: str = ""
    posicao: int = 0
    obrigatorio: str = ""     # rótulo do bloco: disclaimer, opt-out, atendimento
    tolerado: bool = False    # bloco onde a diferença é esperada (redes sociais)
    citacao_html: str = ""    # trecho literal, como está na peça
    citacao_docx: str = ""    # trecho literal, como está no docx

    @property
    def gravidade(self) -> str:
        """
        Só "alta" reprova o pacote. As outras duas faixas notificam.

        Acento, vírgula e espaçamento nunca reprovam: existe margem de
        tolerância neles e a decisão é do analista, não da ferramenta. Isso
        vale em qualquer trecho, inclusive nos blocos de disclaimer, opt-out e
        atendimento — a marcação de bloco serve para localizar o trecho, não
        para endurecer o critério.
        """
        if self.tolerado:
            # bloco de redes sociais: a peça traz o ícone, o docx traz a frase.
            # A diferença é informação, não erro.
            return "media"
        if self.tipo in ("acento_pontuacao", "espacamento", "fora_de_ordem"):
            return "media"
        if self.tipo in ("faltando", "trocado", "sobrando"):
            return "alta"
        return "baixa"


@dataclass
class ResultadoComparacao:
    similaridade: float = 0.0
    total_tokens_html: int = 0
    total_tokens_docx: int = 0
    tokens_iguais: int = 0
    divergencias: list[Divergencia] = field(default_factory=list)
    blocos_sem_ocr: list[str] = field(default_factory=list)
    comparacao_parcial: bool = False
    trechos_dispensados: list[str] = field(default_factory=list)
    obrigatorios_ausentes: list[str] = field(default_factory=list)
    correcoes_ocr: list[str] = field(default_factory=list)
    imagens_reordenadas: list[str] = field(default_factory=list)

    @property
    def aprovado(self) -> bool:
        return not self.divergencias and not self.comparacao_parcial

    @property
    def status(self) -> str:
        # gravidade vem antes de completude: uma divergência alta reprova mesmo
        # quando parte das imagens não pôde ser lida
        if any(d.gravidade == "alta" for d in self.divergencias):
            return "reprovado"
        if self.comparacao_parcial:
            return "parcial"
        if not self.divergencias:
            return "aprovado"
        return "atencao"

    def por_gravidade(self, nivel: str) -> list[Divergencia]:
        return [d for d in self.divergencias if d.gravidade == nivel]


def _alinhar_imagens(fita, paragrafos_docx: list[str]) -> list[str]:
    """
    Põe a leitura de cada imagem na ordem em que o docx escreveu.

    Dentro de um banner com layout em blocos não existe ordem de leitura única,
    e qualquer critério automático erra em alguma peça. A ordem que vale é a de
    quem escreveu, e ela está no docx.

    Só acontece quando todas as linhas da imagem foram encontradas lá: assim a
    reordenação silencia ruído de diagramação sem silenciar erro de conteúdo.
    """
    ajustadas = []
    for bloco in fita:
        if bloco.tipo != "imagem" or not bloco.conteudo or not bloco.ocr_lido:
            continue
        resultado = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx)
        if resultado.reordenou:
            bloco.conteudo = "\n".join(resultado.linhas)
            bloco.reordenado = True
            ajustadas.append(bloco.referencia or "imagem")
    return ajustadas


def _remover_dispensaveis(fita, vocabulario: set[str]):
    """
    Tira da comparação o texto de template que não precisa constar no docx.

    O link de fallback do topo — "se não conseguir abrir esse e-mail, clique
    aqui" — é obrigatório no HTML e opcional no docx. Marcá-lo e deixar na fita
    não bastava: o alinhamento juntava esses tokens com os da frase seguinte
    num apontamento só, e a dispensa deixava de valer justamente ali.

    A remoção só acontece quando o trecho REALMENTE não está no docx. Se o
    analista escreveu o fallback lá, ele fica e é comparado como qualquer outro
    texto.
    """
    limpa, removidos = [], []
    for bloco in fita:
        if bloco.classificacao != "dispensavel":
            limpa.append(bloco)
            continue
        palavras = tokenizar(bloco.conteudo)
        if not palavras:
            continue
        presentes = sum(1 for p in palavras if correcao_ocr.canonizar(p) in vocabulario)
        if presentes / len(palavras) >= 0.6:
            limpa.append(bloco)      # está nos dois: compara normalmente
        else:
            removidos.append(bloco.conteudo)
    return limpa, removidos


def _tokens_da_fita(fita, vocabulario: set[str] | None = None
                    ) -> tuple[list[Token], list[str], list[str]]:
    tokens, sem_ocr, corrigidos = [], [], []
    for indice, bloco in enumerate(fita):
        if bloco.oculto:
            continue
        if bloco.tipo == "imagem":
            origem = bloco.referencia or "imagem"
            if not bloco.ocr_lido:
                if bloco.ocr_erro or not bloco.conteudo:
                    # a mesma imagem pode aparecer várias vezes; avisa uma só
                    aviso = f"{origem}: {bloco.ocr_erro or 'sem leitura'}"
                    if aviso not in sem_ocr:
                        sem_ocr.append(aviso)
                    continue
        else:
            origem = "texto vivo"
        pares = tokenizar_pares(bloco.conteudo)
        # texto vindo de OCR passa pela correção; texto do código, não
        if bloco.tipo == "imagem" and vocabulario:
            chaves = [p.chave for p in pares]
            corrigidas, separados = correcao_ocr.corrigir(chaves, vocabulario)
            corrigidos.extend(separados)
            if corrigidas != chaves:
                # a correção quebra ou remove tokens, então o vínculo 1 para 1
                # com o texto original se perde; nesse caso o bloco inteiro vira
                # a citação e cada token guarda só a forma de comparação
                pares = [
                    type(pares[0])(chave=c, sensivel=c, texto=c) if pares else None
                    for c in corrigidas
                ]
                pares = [p for p in pares if p]
        for par in pares:
            tokens.append(Token(
                valor=par.chave, origem=origem, indice_bloco=indice,
                classificacao=bloco.classificacao,
                sensivel=par.sensivel, texto=par.texto,
            ))
    return tokens, sem_ocr, corrigidos


def _tokens_do_docx(paragrafos: list[str]) -> list[Token]:
    tokens = []
    for indice, paragrafo in enumerate(paragrafos):
        # o docx também é classificado: o bloco de redes sociais costuma vir
        # completo só deste lado, e é por aqui que ele é reconhecido
        classificacao = excecoes.classificar(paragrafo)
        for par in tokenizar_pares(paragrafo):
            tokens.append(Token(
                valor=par.chave, origem="docx", indice_bloco=indice,
                sensivel=par.sensivel, texto=par.texto,
                classificacao=classificacao,
            ))
    return tokens


def _citar(tokens: list[Token], inicio: int, fim: int, origens: list[str],
           folga: int = 6, limite: int = 60) -> str:
    """
    Monta a citação literal do trecho, com o texto exatamente como está no
    arquivo — acento, pontuação e maiúscula preservados.

    Cita com uma folga de palavras em volta: um apontamento isolado ("prazo")
    não diz nada a quem vai ler o report. A frase em volta diz.
    """
    if not origens:
        return ""
    inicio_folga = max(0, inicio - folga)
    fim_folga = min(len(tokens), fim + folga)
    fatia = tokens[inicio_folga:fim_folga]
    if not fatia:
        return ""

    partes, bloco_atual = [], None
    for token in fatia[:limite]:
        palavra = token.texto or token.valor
        if bloco_atual is None:
            bloco_atual = token.indice_bloco
        elif token.indice_bloco != bloco_atual:
            partes.append("\n")
            bloco_atual = token.indice_bloco
        partes.append(palavra)

    texto = ""
    for parte in partes:
        if parte == "\n":
            texto = texto.rstrip() + "\n"
        else:
            texto += ("" if texto.endswith("\n") or not texto else " ") + parte
    reticencia_inicio = "… " if inicio_folga > 0 else ""
    reticencia_fim = " …" if fim_folga < len(tokens) else ""
    return (reticencia_inicio + texto.strip() + reticencia_fim).strip()


def _texto(tokens: list[Token], inicio: int, fim: int, limite: int = 25) -> str:
    trecho = [(t.texto or t.valor) for t in tokens[inicio:fim]]
    if len(trecho) > limite:
        trecho = trecho[:limite] + ["..."]
    return " ".join(trecho)


def _origem_dominante(tokens: list[Token], inicio: int, fim: int) -> str:
    fatia = tokens[inicio:fim]
    if not fatia:
        return "—"
    contagem: dict[str, int] = {}
    for token in fatia:
        contagem[token.origem] = contagem.get(token.origem, 0) + 1
    return max(contagem, key=contagem.get)


def _so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2) -> bool:
    """
    Diz se os dois trechos têm exatamente o mesmo conteúdo, só quebrado em
    palavras de forma diferente.

    Comparar sem os espaços é o teste: se as sequências de caracteres coincidem,
    o que mudou foi onde o espaço caiu, não o que está escrito.
    """
    lado_html = "".join(t.valor for t in tokens_html[i1:i2])
    lado_docx = "".join(t.valor for t in tokens_docx[j1:j2])
    return bool(lado_html) and lado_html == lado_docx


def _diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2) -> list[Divergencia]:
    """
    Compara acento e pontuação dentro de um trecho que já casou palavra a palavra.

    Agrupa diferenças vizinhas num apontamento só: uma frase com quatro acentos
    trocados é um problema, não quatro.
    """
    achados, atual = [], None
    for deslocamento in range(i2 - i1):
        alvo_html = tokens_html[i1 + deslocamento]
        alvo_docx = tokens_docx[j1 + deslocamento]
        # Só texto escrito no código entra aqui. OCR erra acento e pontuação
        # por natureza — lê 0 como o, come vírgula, junta ponto de milhar.
        # Cobrar acento de uma leitura de imagem seria inventar divergência.
        if alvo_html.origem != "texto vivo":
            atual = None
            continue
        if alvo_html.sensivel == alvo_docx.sensivel:
            atual = None
            continue
        if atual is not None and deslocamento - atual["ultimo"] <= 3:
            atual["ultimo"] = deslocamento
            atual["pares"].append((alvo_html, alvo_docx))
            continue
        atual = {"inicio": deslocamento, "ultimo": deslocamento,
                 "pares": [(alvo_html, alvo_docx)]}
        achados.append(atual)

    divergencias = []
    for achado in achados:
        inicio = i1 + achado["inicio"]
        fim = i1 + achado["ultimo"] + 1
        desloc_j = j1 + achado["inicio"]
        fim_j = j1 + achado["ultimo"] + 1
        divergencias.append(Divergencia(
            tipo="acento_pontuacao",
            origem=_origem_dominante(tokens_html, inicio, fim),
            trecho_html=" ".join(h.texto for h, _ in achado["pares"]),
            trecho_docx=" ".join(d.texto for _, d in achado["pares"]),
            posicao=inicio,
            citacao_html=_citar(tokens_html, inicio, fim, tokens_html),
            citacao_docx=_citar(tokens_docx, desloc_j, fim_j, tokens_docx),
        ))
    return divergencias


def comparar(fita, paragrafos_docx: list[str],
             janela_contexto: int = 6) -> ResultadoComparacao:
    resultado = ResultadoComparacao()

    vocabulario = correcao_ocr.construir_vocabulario(paragrafos_docx)
    reordenadas = _alinhar_imagens(fita, paragrafos_docx)
    fita, dispensados = _remover_dispensaveis(fita, vocabulario)
    tokens_html, sem_ocr, corrigidos = _tokens_da_fita(fita, vocabulario)
    tokens_docx = _tokens_do_docx(paragrafos_docx)

    resultado.blocos_sem_ocr = sem_ocr
    resultado.correcoes_ocr = corrigidos
    resultado.trechos_dispensados = dispensados
    resultado.imagens_reordenadas = reordenadas
    resultado.comparacao_parcial = bool(sem_ocr)
    resultado.total_tokens_html = len(tokens_html)
    resultado.total_tokens_docx = len(tokens_docx)

    # a comparação usa a forma canônica, que trata confusões de caractere do
    # OCR; o relatório continua exibindo o texto original
    valores_html = [correcao_ocr.canonizar(t.valor) for t in tokens_html]
    valores_docx = [correcao_ocr.canonizar(t.valor) for t in tokens_docx]

    matcher = SequenceMatcher(None, valores_html, valores_docx, autojunk=False)
    resultado.similaridade = round(matcher.ratio() * 100, 1)

    faltando, sobrando = [], []

    for operacao, i1, i2, j1, j2 in matcher.get_opcodes():
        if operacao == "equal":
            resultado.tokens_iguais += i2 - i1
            # A palavra confere, mas pode diferir no acento ou na vírgula.
            # Vira apontamento próprio, de gravidade média: aqui existe margem
            # de tolerância e quem decide é o analista, não a ferramenta.
            resultado.divergencias.extend(
                _diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2)
            )
            continue

        divergencia = Divergencia(
            tipo="",
            origem=_origem_dominante(tokens_html, i1, i2) if i2 > i1 else "docx",
            trecho_html=_texto(tokens_html, i1, i2),
            trecho_docx=_texto(tokens_docx, j1, j2),
            contexto_antes=_texto(tokens_html, max(0, i1 - janela_contexto), i1, 10),
            contexto_depois=_texto(tokens_html, i2, i2 + janela_contexto, 10),
            posicao=i1,
            citacao_html=_citar(tokens_html, i1, i2, tokens_html),
            citacao_docx=_citar(tokens_docx, j1, j2, tokens_docx),
        )

        classificacoes = {t.classificacao for t in tokens_html[i1:i2] if t.classificacao}
        classificacoes_docx = {t.classificacao for t in tokens_docx[j1:j2] if t.classificacao}
        obrigatorio = next(
            (c.split(":", 1)[1] for c in classificacoes if c.startswith("obrigatorio")), ""
        )
        divergencia.obrigatorio = obrigatorio
        # o bloco tolerado pode estar de qualquer um dos lados: no HTML é só o
        # rótulo com os ícones, no docx é a frase inteira
        divergencia.tolerado = ("tolerado" in classificacoes
                                or "tolerado" in classificacoes_docx)

        # Rede de segurança: o grosso do texto de template já saiu da fita em
        # _remover_dispensaveis; aqui pega o que tenha escapado.
        if (operacao == "delete" and not obrigatorio
                and classificacoes == {"dispensavel"}):
            resultado.trechos_dispensados.append(divergencia.trecho_html)
            continue

        if operacao == "delete" and obrigatorio:
            resultado.obrigatorios_ausentes.append(
                f"{obrigatorio}: {divergencia.trecho_html}"
            )

        if operacao == "delete":
            divergencia.tipo = "faltando"      # está no HTML, não está no docx
            faltando.append(divergencia)
        elif operacao == "insert":
            divergencia.tipo = "sobrando"      # está no docx, não está no HTML
            sobrando.append(divergencia)
        elif _so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2):
            # "36x" contra "36 x", "R$50,00" contra "R$ 50,00": as mesmas
            # letras e dígitos, só o espaço em lugar diferente. Notifica, mas
            # não reprova — espaço a mais ou a menos não muda o que o cliente
            # com deficiência visual escuta.
            divergencia.tipo = "espacamento"
            resultado.divergencias.append(divergencia)
        else:
            divergencia.tipo = "trocado"
            resultado.divergencias.append(divergencia)

    # Um mesmo trecho que some de um ponto e reapareça em outro é inversão de
    # ordem, não falta de conteúdo. Reclassificar evita dois apontamentos graves
    # para um problema que é só de posição.
    consumidos_sobrando = set()
    for ausente in faltando:
        chave = " ".join(sorted(ausente.trecho_html.split()))
        casou = False
        for indice, excedente in enumerate(sobrando):
            if indice in consumidos_sobrando:
                continue
            if " ".join(sorted(excedente.trecho_docx.split())) == chave and chave:
                ausente.tipo = "fora_de_ordem"
                ausente.trecho_docx = excedente.trecho_docx
                consumidos_sobrando.add(indice)
                casou = True
                break
        resultado.divergencias.append(ausente)
        if not casou:
            continue

    for indice, excedente in enumerate(sobrando):
        if indice not in consumidos_sobrando:
            resultado.divergencias.append(excedente)

    resultado.divergencias.sort(key=lambda d: d.posicao)
    return resultado


def comparar_assunto(leitura_assunto, leitura_html) -> list[Divergencia]:
    """
    Confere se o pré-header do docx aparece no HTML — normalmente em div oculta.
    Diferente do conteúdo, aqui basta conter, porque a ordem não importa.
    """
    apontamentos = []
    if not leitura_assunto or not leitura_assunto.pre_header:
        return apontamentos

    alvo = set(tokenizar(leitura_assunto.pre_header))
    if not alvo:
        return apontamentos

    universo = set()
    for texto in leitura_html.texto_oculto:
        universo.update(tokenizar(texto))
    for bloco in leitura_html.fita:
        universo.update(tokenizar(bloco.conteudo))

    faltantes = alvo - universo
    if len(faltantes) > len(alvo) * 0.3:
        apontamentos.append(
            Divergencia(
                tipo="faltando",
                origem="pré-header",
                trecho_docx=leitura_assunto.pre_header,
                trecho_html="não localizado no HTML",
            )
        )
    return apontamentos
''',
    # ---- validador/presenca.py ----------------------------------------------------
    "presenca": r'''"""
Comparação por presença, usada quando o texto das imagens não pôde ser lido.

Sem OCR, a fita do HTML fica incompleta: o texto dos banners some, mas continua
no CONTEUDO.docx. Comparar sequência nessa condição alinha trecho errado com
trecho errado e produz apontamento que não existe.

Aqui a pergunta é outra e mais honesta: cada trecho de texto vivo do HTML
aparece no docx? Sobra no docx não é cobrada, porque quase sempre é o texto das
imagens que não conseguimos ler.

Espaçamento, quebra de linha e divisão de parágrafo não contam — a comparação é
palavra a palavra.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr, ordenacao
from .comparador import Divergencia
from .normalizacao import tokenizar

# trechos muito curtos geram ruído; abaixo disso só checamos presença das palavras
MINIMO_PARA_SEQUENCIA = 3


@dataclass
class ResultadoPresenca:
    similaridade: float = 0.0
    divergencias: list[Divergencia] = field(default_factory=list)
    trechos_dispensados: list[str] = field(default_factory=list)
    obrigatorios_ausentes: list[str] = field(default_factory=list)
    blocos_sem_ocr: list[str] = field(default_factory=list)
    blocos_conferidos: int = 0
    correcoes_ocr: list[str] = field(default_factory=list)
    imagens_reordenadas: list[str] = field(default_factory=list)
    comparacao_parcial: bool = True
    total_tokens_html: int = 0
    total_tokens_docx: int = 0
    tokens_iguais: int = 0

    @property
    def status(self) -> str:
        if any(d.gravidade == "alta" for d in self.divergencias):
            return "reprovado"
        return "parcial"

    @property
    def aprovado(self) -> bool:
        return False  # nunca aprova: parte da peça não foi conferida

    def por_gravidade(self, nivel):
        return [d for d in self.divergencias if d.gravidade == nivel]


def _indice_da_subsequencia(sub: list[str], universo: list[str]) -> int:
    """Procura a sequência exata de palavras dentro do docx."""
    if not sub or len(sub) > len(universo):
        return -1
    primeiro = sub[0]
    limite = len(universo) - len(sub) + 1
    for i in range(limite):
        if universo[i] == primeiro and universo[i:i + len(sub)] == sub:
            return i
    return -1


def _paragrafo_mais_proximo(tokens: list[str], paragrafos: list[str]) -> str:
    """
    Acha o parágrafo do docx que mais se parece com o trecho da peça.

    A citação precisa ser o parágrafo inteiro, do jeito que está no arquivo:
    é isso que a pessoa vai colar no report para mostrar a divergência sem
    precisar dizer qual dos dois está certo.
    """
    alvo = set(tokens)
    if not alvo:
        return ""

    notas = []
    for indice, paragrafo in enumerate(paragrafos):
        palavras = set(tokenizar(paragrafo))
        if not palavras:
            continue
        # cobertura: quanto do parágrafo do docx está no trecho da peça.
        # Usar cobertura em vez de similaridade evita descartar um parágrafo
        # curto ("Banco Exemplo") só por ser menor que o bloco da peça.
        cobertura = len(alvo & palavras) / len(palavras)
        if cobertura >= 0.5:
            notas.append((indice, paragrafo))

    if not notas:
        return ""

    # Cita a faixa contínua entre o primeiro e o último parágrafo que casaram.
    # Quando algo entrou no meio — o caso de ordem trocada — é justamente essa
    # linha intrusa que explica o apontamento, e ela só aparece se a citação
    # não pular buracos.
    indices = [i for i, _ in notas]
    inicio, fim = min(indices), max(indices)
    if fim - inicio > 6:
        return "\n".join(paragrafos[i] for i in sorted(indices)[:5])
    return "\n".join(paragrafos[inicio:fim + 1])


def comparar(fita, paragrafos_docx: list[str]) -> ResultadoPresenca:
    resultado = ResultadoPresenca()

    tokens_docx = []
    for paragrafo in paragrafos_docx:
        tokens_docx.extend(tokenizar(paragrafo))
    # a busca compara em forma canônica, que absorve as confusões de caractere
    # do OCR (0/o, 1/l); o relatório continua exibindo o texto original
    tokens_docx = [correcao_ocr.canonizar(t) for t in tokens_docx]
    conjunto_docx = set(tokens_docx)
    vocabulario = conjunto_docx
    resultado.total_tokens_docx = len(tokens_docx)

    # mesma ideia do modo completo: dentro da imagem, a ordem que vale é a do
    # docx, não a que o OCR inferiu do layout
    for bloco in fita:
        if bloco.tipo == "imagem" and bloco.conteudo and bloco.ocr_lido:
            ajuste = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx)
            if ajuste.reordenou:
                bloco.conteudo = "\n".join(ajuste.linhas)
                bloco.reordenado = True
                resultado.imagens_reordenadas.append(bloco.referencia or "imagem")

    vistos_sem_leitura = set()
    tokens_html_total = 0
    tokens_encontrados = 0

    for bloco in fita:
        if bloco.oculto:
            continue

        if bloco.tipo == "imagem" and not bloco.ocr_lido:
            nome = bloco.referencia or "imagem"
            if nome not in vistos_sem_leitura:
                vistos_sem_leitura.add(nome)
                resultado.blocos_sem_ocr.append(nome)
            continue

        tokens = tokenizar(bloco.conteudo)
        # Mesmo com imagens faltando, as que FORAM lidas passam pela correção:
        # sem isto, "nasuaconta" e "a0" viram apontamento falso justamente no
        # modo em que o sistema já está conferindo menos.
        if bloco.tipo == "imagem" and bloco.ocr_lido:
            tokens, separados = correcao_ocr.corrigir(tokens, vocabulario)
            resultado.correcoes_ocr.extend(separados)
        if not tokens:
            continue
        # duas versões: a canônica busca, a original aparece no relatório.
        # Sem isso o diff mostraria "R$ so ooo oo" no lugar de "R$ 50 000 00".
        exibicao = list(tokens)
        tokens = [correcao_ocr.canonizar(t) for t in tokens]

        tokens_html_total += len(tokens)
        origem = bloco.referencia if bloco.tipo == "imagem" else "texto vivo"
        obrigatorio = ""
        if bloco.classificacao.startswith("obrigatorio"):
            obrigatorio = bloco.classificacao.split(":", 1)[1]
        tolerado = bloco.classificacao == "tolerado"

        # texto de template: só é cobrado se o analista tiver escrito no docx
        if bloco.classificacao == "dispensavel":
            resultado.trechos_dispensados.append(bloco.conteudo)
            tokens_encontrados += len(tokens)
            continue

        resultado.blocos_conferidos += 1

        # 1. sequência exata no docx: caso perfeito
        if (len(tokens) >= MINIMO_PARA_SEQUENCIA
                and _indice_da_subsequencia(tokens, tokens_docx) >= 0):
            tokens_encontrados += len(tokens)
            continue

        # 2. todas as palavras existem, mas não juntas nessa ordem
        ausentes = [exibicao[i] for i, t in enumerate(tokens) if t not in conjunto_docx]
        if not ausentes:
            tokens_encontrados += len(tokens)
            if len(tokens) >= MINIMO_PARA_SEQUENCIA:
                resultado.divergencias.append(Divergencia(
                    tipo="fora_de_ordem",
                    origem=origem,
                    trecho_html=" ".join(exibicao[:25]),
                    trecho_docx="as mesmas palavras aparecem no docx, em outra ordem",
                    obrigatorio=obrigatorio,
                    tolerado=tolerado,
                    citacao_html=bloco.conteudo,
                    citacao_docx=_paragrafo_mais_proximo(tokens, paragrafos_docx),
                ))
            continue

        # 3. faltam palavras: apontamento real
        tokens_encontrados += len(tokens) - len(ausentes)
        melhor = _trecho_mais_parecido(tokens, tokens_docx)
        divergencia = Divergencia(
            tipo="faltando",
            origem=origem,
            trecho_html=" ".join(exibicao[:25]),
            trecho_docx=melhor,
            contexto_antes="palavras ausentes: " + ", ".join(ausentes[:12]),
            obrigatorio=obrigatorio,
            tolerado=tolerado,
            citacao_html=bloco.conteudo,
            citacao_docx=_paragrafo_mais_proximo(tokens, paragrafos_docx),
        )
        resultado.divergencias.append(divergencia)
        if obrigatorio:
            resultado.obrigatorios_ausentes.append(
                f"{obrigatorio}: {divergencia.trecho_html}"
            )

    resultado.total_tokens_html = tokens_html_total
    resultado.tokens_iguais = tokens_encontrados
    resultado.similaridade = (
        round(tokens_encontrados / tokens_html_total * 100, 1) if tokens_html_total else 0.0
    )
    return resultado


def _trecho_mais_parecido(tokens: list[str], universo: list[str]) -> str:
    """Acha no docx o trecho mais próximo, para mostrar lado a lado no relatório."""
    if not universo:
        return "—"
    matcher = SequenceMatcher(None, universo, tokens, autojunk=False)
    bloco = matcher.find_longest_match(0, len(universo), 0, len(tokens))
    if bloco.size == 0:
        return "trecho não localizado no docx"
    inicio = max(0, bloco.a - 3)
    fim = min(len(universo), bloco.a + bloco.size + 3)
    return " ".join(universo[inicio:fim])
''',
    # ---- validador/ocr.py ---------------------------------------------------------
    "ocr": r'''"""
Leitura do texto contido nas imagens.

Três motores, testados em cascata. O sistema usa o primeiro que estiver
disponível na máquina, sem você precisar configurar nada:

  1. windows   — OCR nativo do Windows 10/11. Não instala binário nenhum:
                 o motor já faz parte do sistema operacional e o idioma
                 português normalmente já vem junto. Só precisa do pacote
                 Python `winocr`. É o caminho de menor atrito em máquina
                 corporativa, porque não há software novo para homologar.

  2. rapidocr  — modelos ONNX que vêm dentro do próprio pacote pip (~16 MB).
                 Roda offline depois de instalado, não precisa de binário
                 externo nem de privilégio de administrador. É o plano B
                 quando o item 1 não estiver disponível.

  3. tesseract — o mais conhecido, mas exige instalar um programa separado.
                 Aceita também versão portátil: aponte a variável de ambiente
                 TESSERACT_CMD para o executável e não precisa de instalador.

Para forçar um motor específico, defina a variável OCR_MOTOR com "windows",
"rapidocr" ou "tesseract".
"""

import os
import re
import threading
import unicodedata
from dataclasses import dataclass, field

from .normalizacao import limpar


@dataclass
class ResultadoOCR:
    arquivo: str
    texto: str = ""
    lido: bool = False
    erro: str = ""
    aviso: str = ""
    motor: str = ""
    confianca_media: float = 0.0
    linhas: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- utilidades

def _preparar(caminho: str, largura_minima: int = 0):
    """
    Abre a imagem e corrige orientação.

    O aumento de escala NÃO acontece aqui: quem amplia é o fatiamento, já com
    a faixa recortada. Ampliar duas vezes só borra a letra.
    """
    from PIL import Image, ImageOps

    img = Image.open(caminho)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    if largura_minima and img.width < largura_minima:
        fator = largura_minima / img.width
        # LANCZOS de propósito: o padrão do resize borra a borda das letras e o
        # motor passa a inventar caractere — "Simular agora" virava "Simular a
        # agora" num upscale de apenas 1,1x.
        img = img.resize(
            (int(img.width * fator), int(img.height * fator)), Image.LANCZOS
        )
    return img


MAXIMO_FRAMES_LIDOS = 10
# Fração mínima de pixels que precisa mudar para o frame contar como cena nova.
# Média de diferença não serve aqui: em banner de fundo claro, trocar a frase
# inteira mexe em poucos por cento dos pixels e a média mal se move.
MUDANCA_MINIMA_ENTRE_FRAMES = 0.01   # 1% dos pixels
DIFERENCA_POR_PIXEL = 40             # 0-255: o quanto um pixel precisa mudar


def _assinatura(imagem):
    """Miniatura em cinza usada só para comparar frames entre si."""
    from PIL import Image
    return list(imagem.convert("L").resize((64, 64), Image.BILINEAR).getdata())


def _frames_relevantes(caminho: str) -> list:
    """
    Escolhe quais frames de um GIF vale a pena ler.

    Um GIF de peça costuma ter dezenas de frames para poucas cenas de texto:
    ler todos custaria mais de um minuto por imagem sem acrescentar nada. Aqui
    só entram os frames que mudaram de verdade em relação ao último lido, e no
    máximo dez — o suficiente para pegar todas as cenas de uma peça de e-mail.
    """
    from PIL import Image, ImageSequence

    imagem = Image.open(caminho)
    total = getattr(imagem, "n_frames", 1)
    if total <= 1:
        return [imagem.convert("RGB")]

    escolhidos, ultima = [], None
    for quadro in ImageSequence.Iterator(imagem):
        atual = quadro.convert("RGB")
        assinatura = _assinatura(atual)
        if ultima is not None:
            mudados = sum(
                1 for a, b in zip(assinatura, ultima)
                if abs(a - b) > DIFERENCA_POR_PIXEL
            )
            if mudados / len(assinatura) < MUDANCA_MINIMA_ENTRE_FRAMES:
                continue
        escolhidos.append(atual.copy())
        ultima = assinatura
        if len(escolhidos) >= MAXIMO_FRAMES_LIDOS:
            break
    return escolhidos or [imagem.convert("RGB")]


def _juntar_textos(blocos: list[str]) -> str:
    """
    Junta o texto das cenas do GIF sem repetir o que já apareceu.

    Dois tipos de repetição acontecem aqui. A primeira é a frase que se repete
    em frames vizinhos — basta descartar a igual. A segunda é a animação de
    digitação, em que a mesma frase entra aos pedaços: "COMPROMISSO", depois
    "e TRANSPA", depois "e TRANSPARENCIA com sua empresa". Guardar todos os
    pedaços encheria a fita de fragmentos que não existem no docx, então fica
    só a versão mais completa de cada frase.
    """
    from .normalizacao import tokenizar

    candidatos = []
    for bloco in blocos:
        for linha in bloco.splitlines():
            limpa = linha.strip()
            chave = "".join(tokenizar(limpa))   # sem espaços: o OCR varia neles
            if not chave:
                continue
            candidatos.append((chave, limpa))

    # descarta o que está contido em outra linha — o pedaço da animação
    finais = []
    for chave, texto in candidatos:
        contido_em_outro = any(
            chave != outra and chave in outra for outra, _ in candidatos
        )
        if contido_em_outro:
            continue
        if any(chave == vista for vista, _ in finais):
            continue
        finais.append((chave, texto))

    return "\n".join(texto for _, texto in finais)


# O detector do motor encolhe a imagem inteira para caber em cerca de 960 px no
# lado maior. Peça de e-mail é uma tira alta e estreita: uma fatia de 900x2600
# é reduzida a 900x960 e o texto de 20 px vira 7 px — ilegível. Ler em faixas
# preserva a resolução do texto.
ALTURA_MAXIMA_POR_FATIA = 900
SOBREPOSICAO_ENTRE_FATIAS = 120   # px repetidos, para não cortar linha no meio
ALTURA_MINIMA_DO_TEXTO = 26       # abaixo disso o reconhecimento erra caractere
CONFIANCA_PARA_ALERTAR = 80       # abaixo disso a imagem entra em Observações


# Peça de e-mail é cheia de ícone e pictograma — calendário, cadeado, cifrão,
# selo. O detector não sabe distinguir desenho de letra: ele acha uma forma
# parecida com texto e o reconhecedor devolve o palpite mais próximo. O
# calendário desta campanha virava "口" numa escala e "D000 000" na outra.
# Formatos que aparecem de verdade em peça e que NÃO têm letra nenhuma. Eles
# costumam ser o dado mais importante da imagem — o percentual da oferta, a
# data da estreia, o telefone da central — e não podem ser descartados por
# falta de letra.
RE_CONTEUDO_SEM_LETRA = re.compile(r"""
      ^\d{1,3}\s?%$                                   # 50%   20 %
    | ^\d{1,2}[/.\-]\d{1,2}([/.\-]\d{2,4})?[:.]?$     # 10/09:  03/09/2026
    | ^R?\$?\s?\d{1,3}([.\s]\d{3})*([,]\d{2})?$      # R$ 50.000,00
    | ^\d{3,5}[\s-]?\d{3,4}$                          # 4002 0022 · 0800 570
    | ^\d{1,3}\s?[xX]$                                # 36x
    | ^\d{1,2}[hH]$                                    # 22h
    | ^[+\-]?\d{1,4}[.,]\d{1,2}$                      # 1,29
""", re.VERBOSE)

# Dígito ou símbolo repetido é assinatura de contorno de ícone lido como texto:
# "000", "0 0000 000", "...."
RE_REPETICAO_BOBA = re.compile(r"^([\W\d_])[\s]*(\1[\s]*)+$")

CONFIANCA_MINIMA_SEM_LETRA = 88


def _como_numero(valor, padrao: float = 0.0) -> float:
    """
    Converte para número o que o motor devolveu como confiança.

    Versões diferentes do RapidOCR entregam esse campo de jeitos diferentes:
    umas como float, outras como string ("0.98"). Comparar string com número
    quebra a leitura inteira da imagem, e o erro aparece como "sem texto lido"
    — parecendo falha do OCR quando é só um tipo diferente.
    """
    if isinstance(valor, (int, float)):
        return float(valor)
    try:
        return float(str(valor).strip().replace(",", "."))
    except (TypeError, ValueError):
        return padrao


def _tem_letra(texto: str) -> bool:
    return any(c.isalpha() for c in texto)


def _fora_do_alfabeto(texto: str) -> bool:
    """Caractere que não existe em peça escrita em português."""
    for caractere in texto:
        if caractere.isalpha() and not ("a" <= caractere.lower() <= "z"):
            # letra acentuada é latina; CJK, cirílico e afins não são
            if unicodedata.name(caractere, "").startswith("LATIN"):
                continue
            return True
        if unicodedata.category(caractere) == "So":   # símbolo/pictograma
            return True
    return False


def _e_ruido_de_icone(texto: str, confianca) -> bool:
    """
    Diz se a caixa é desenho lido como texto.

    Descartar é mais seguro do que manter: um ícone fantasma entra na
    comparação como palavra inventada e vira apontamento que ninguém consegue
    resolver, porque não existe nada para corrigir na peça.
    """
    limpo = str(texto or "").strip()
    confianca = _como_numero(confianca)
    if not limpo:
        return True
    if _fora_do_alfabeto(limpo):
        return True

    # Repetição do mesmo caractere vem antes de tudo: "000" casaria como valor
    # monetário e escaparia do filtro, mas é contorno de ícone.
    if not _tem_letra(limpo) and RE_REPETICAO_BOBA.match(limpo):
        return True

    # Percentual, data, valor e telefone ficam, custe o que custar: é o dado
    # mais importante da imagem. Descartá-los por confiança apagava justamente
    # o "50%" da oferta e o "10/09:" da estreia.
    if RE_CONTEUDO_SEM_LETRA.match(limpo.replace("  ", " ")):
        return False

    if _tem_letra(limpo):
        return len(limpo) <= 2 and confianca < CONFIANCA_MINIMA_SEM_LETRA

    # sem letra e sem formato reconhecível: só passa com confiança alta
    return confianca < CONFIANCA_MINIMA_SEM_LETRA


# ----------------------------------------------- leitura em várias variantes
#
# O pipeline clássico de OCR (aquisição, pré-processamento, detecção, extração,
# classificação, pós-processamento) trata o pré-processamento como etapa
# própria — e é justamente a que estava faltando aqui. Peça de e-mail varia
# demais: texto branco sobre foto, título fino sobre fundo claro, bloco
# pequeno em cima de gradiente. Nenhum preparo único serve para todos.
#
# Em vez de escolher um, lê-se a mesma fatia em algumas variantes e funde-se o
# resultado, ficando com a melhor leitura de cada região. É o mesmo princípio
# de combinar classificadores: cada variante erra em lugares diferentes.

LIMIAR_ESCURA = 110          # abaixo disso a imagem é escura e vale inverter
SOBREPOSICAO_MESMA_CAIXA = 0.55


def _luminancia_media(imagem) -> float:
    import numpy as np
    from PIL import ImageOps
    return float(np.array(ImageOps.grayscale(imagem)).mean())


def _variantes_de_leitura(imagem, completa: bool):
    """
    Versões da mesma fatia para ler em paralelo.

    Na leitura rápida vai só o original. Quando ele vem fraco — pouca coisa
    lida ou confiança baixa — entram as outras, que custam tempo mas resgatam
    texto que o preparo padrão perde.
    """
    from PIL import ImageFilter, ImageOps

    saida = [("original", imagem)]
    if not completa:
        return saida

    # Texto claro sobre fundo escuro: o detector foi treinado sobretudo em
    # texto escuro sobre claro, e inverter devolve a polaridade esperada.
    if _luminancia_media(imagem) < LIMIAR_ESCURA:
        invertida = ImageOps.invert(ImageOps.grayscale(imagem)).convert("RGB")
        saida.append(("invertida", invertida))

    saida.append(("contraste", ImageOps.autocontrast(imagem, cutoff=1)))
    saida.append(("nitidez", imagem.filter(
        ImageFilter.UnsharpMask(radius=2, percent=140, threshold=3))))
    return saida


def _leitura_fraca(caixas: list, fatia) -> bool:
    """
    Decide se a fatia merece uma segunda passada com pré-processamento.

    O limiar é baixo de propósito. Medindo contra o gabarito, as variantes de
    pré-processamento NÃO reduziram o erro das peças testadas e dobraram o
    tempo: o que restava de divergência era acento, que o reconhecedor não
    emite e a comparação já ignora dos dois lados. Então elas ficam como
    resgate — fatia que não devolveu nada, ou devolveu com confiança baixa
    demais para merecer crédito.
    """
    if not caixas:
        return True
    confianca = sum(c["confianca"] for c in caixas) / len(caixas)
    return confianca < 78


def _mesma_regiao(a: dict, b: dict) -> bool:
    """Diz se duas caixas cobrem o mesmo pedaço da imagem."""
    largura = min(a["direita"], b["direita"]) - max(a["esquerda"], b["esquerda"])
    altura = min(a["base"], b["base"]) - max(a["topo"], b["topo"])
    if largura <= 0 or altura <= 0:
        return False
    intersecao = largura * altura
    area_a = max(1.0, (a["direita"] - a["esquerda"]) * (a["base"] - a["topo"]))
    area_b = max(1.0, (b["direita"] - b["esquerda"]) * (b["base"] - b["topo"]))
    return intersecao / min(area_a, area_b) >= SOBREPOSICAO_MESMA_CAIXA


def _fundir_leituras(leituras: list) -> list:
    """
    Junta as caixas das variantes, ficando com a melhor leitura de cada região.

    Região que só uma variante enxergou entra assim mesmo — é texto que as
    outras perderam. Região vista por várias fica com a de maior confiança;
    empatando, com a que leu mais caracteres, porque o erro típico do motor é
    cortar o fim da frase, não inventar.
    """
    final: list = []
    for caixas in leituras:
        for caixa in caixas:
            for indice, escolhida in enumerate(final):
                if not _mesma_regiao(caixa, escolhida):
                    continue
                atual = (escolhida["confianca"], len(escolhida["texto"]))
                nova = (caixa["confianca"], len(caixa["texto"]))
                if nova > atual:
                    final[indice] = caixa
                break
            else:
                final.append(caixa)
    return final


def _realcar(imagem):
    """
    Realça a faixa para uma segunda tentativa.

    Texto branco sobre área clara da foto — céu, parede, fachada — tem contraste
    baixo e o detector simplesmente não acha a caixa. Esticar o histograma e
    reforçar a borda das letras costuma resolver, e só roda quando a primeira
    leitura não achou nada, então não pesa no caso comum.
    """
    from PIL import ImageEnhance, ImageFilter, ImageOps

    realcada = ImageOps.autocontrast(imagem.convert("RGB"), cutoff=1)
    realcada = ImageEnhance.Contrast(realcada).enhance(1.6)
    return realcada.filter(ImageFilter.UnsharpMask(radius=2, percent=140, threshold=2))


def _fatias_da_imagem(imagem) -> list[tuple]:
    """Divide a imagem em faixas horizontais com sobreposição."""
    largura, altura = imagem.size
    limite = max(ALTURA_MAXIMA_POR_FATIA, largura)
    if altura <= limite:
        return [(imagem, 0)]

    passo = limite - SOBREPOSICAO_ENTRE_FATIAS
    fatias, topo = [], 0
    while topo < altura:
        base = min(altura, topo + limite)
        fatias.append((imagem.crop((0, topo, largura, base)), topo))
        if base >= altura:
            break
        topo += passo
    return fatias


def _caixas_em_fatias(motor, imagem, idioma: str, confianca_minima: int):
    """
    Lê a imagem em faixas e devolve as caixas já com a posição real.

    A sobreposição faz a mesma linha aparecer em duas faixas; a deduplicação
    compara texto e posição para não repetir o trecho na leitura final.
    """
    from PIL import Image

    todas = []
    # Fatiar resolve o encolhimento do detector antigo. O detector novo lê a
    # peça alta inteira e, em fatia, junta colunas vizinhas numa caixa só —
    # aí a análise de layout fica sem corredor para separar.
    if getattr(motor, "prefere_imagem_inteira", False):
        fatias = [(imagem, 0)]
    else:
        fatias = _fatias_da_imagem(imagem)
    for fatia, deslocamento in fatias:
        # o reconhecimento erra caractere quando a letra fica pequena demais;
        # ampliar a faixa antes de ler recupera "50%" que virava "SOVO"
        escala = 1.0
        if fatia.width < 1400:
            escala = min(2.5, 1400 / fatia.width)
            fatia = fatia.resize(
                (int(fatia.width * escala), int(fatia.height * escala)), Image.LANCZOS
            )
        def ler(variantes):
            leituras = []
            for _, variante in variantes:
                try:
                    caixas = motor.caixas(variante, idioma, confianca_minima)
                except Exception:
                    continue
                for caixa in caixas:
                    for campo in ("topo", "base", "esquerda", "direita", "confianca"):
                        caixa[campo] = _como_numero(caixa.get(campo, 0))
                leituras.append([c for c in caixas
                                 if not _e_ruido_de_icone(c["texto"],
                                                          c.get("confianca", 0))])
            return _fundir_leituras(leituras)

        achadas = ler(_variantes_de_leitura(fatia, completa=False))

        # Só vale pagar o preço das variantes quando a leitura simples veio
        # fraca — em peça bem comportada elas não acrescentam nada e triplicam
        # o tempo.
        if _leitura_fraca(achadas, fatia):
            achadas = ler(_variantes_de_leitura(fatia, completa=True))
        if not achadas:
            try:
                tentativa = motor.caixas(_realcar(fatia), idioma, confianca_minima)
            except Exception:
                tentativa = []
            tentativa = [c for c in tentativa
                         if not _e_ruido_de_icone(c["texto"], c.get("confianca", 0))]
            # o realce força o detector a achar forma onde não há texto: só
            # vale a tentativa se ela trouxer palavra de verdade
            if any(len(re.findall(r"[^\W\d_]{3,}", c["texto"])) for c in tentativa):
                achadas = tentativa
        for caixa in achadas:
            caixa["topo"] = caixa["topo"] / escala + deslocamento
            caixa["base"] = caixa["base"] / escala + deslocamento
            caixa["esquerda"] = caixa["esquerda"] / escala
            caixa["direita"] = caixa["direita"] / escala
            todas.append(caixa)

    return _remover_repetidas(todas), len(fatias)


def _remover_repetidas(itens: list[dict]) -> list[dict]:
    """Descarta caixas duplicadas pela sobreposição entre faixas vizinhas."""
    limpos = []
    for item in sorted(itens, key=lambda i: (i["topo"], i["esquerda"])):
        texto = item["texto"].strip()
        if not texto:
            continue
        repetida = False
        for anterior in limpos:
            if anterior["texto"].strip() != texto:
                continue
            if abs(anterior["topo"] - item["topo"]) < 24 and \
                    abs(anterior["esquerda"] - item["esquerda"]) < 24:
                # fica a leitura de maior confiança
                if item.get("confianca", 0) > anterior.get("confianca", 0):
                    anterior.update(item)
                repetida = True
                break
        if not repetida:
            limpos.append(item)
    return limpos


def _ordenar_linhas(itens: list[dict]) -> list[str]:
    """
    Reconstrói a ordem visual de leitura: de cima para baixo, da esquerda para
    a direita.

    Os motores devolvem caixas soltas, e duas palavras da mesma linha vêm
    separadas. Agrupar por faixa de altura fixa não funciona — título grande e
    rodapé miúdo precisam de tolerâncias diferentes. Aqui duas caixas entram na
    mesma linha quando se sobrepõem verticalmente em mais da metade da altura
    da menor delas, que é o critério que uma pessoa usaria olhando a peça.
    """
    validos = [i for i in itens if i["texto"].strip()]
    if not validos:
        return []

    for item in validos:
        item.setdefault("base", item["topo"] + item.get("altura", 10))
        item.setdefault("direita", item["esquerda"])

    # Separa a peça em blocos pelo desenho dela e monta as linhas DENTRO de
    # cada bloco. Agrupar por faixa de altura na peça inteira junta dois
    # cartões lado a lado numa linha só — "03/09: 24/09:" — e cada data perde
    # o filme a que pertence.
    from .layout import descrever_blocos

    saida: list[str] = []
    for bloco in descrever_blocos(validos):
        if bloco.caixas:
            saida.extend(_linhas_de_um_bloco(bloco.caixas))
    return saida


def _linhas_de_um_bloco(validos: list[dict]) -> list[str]:
    """Monta as linhas de texto dentro de um bloco já isolado."""
    validos = sorted(validos, key=lambda r: (r["topo"], r["esquerda"]))

    linhas: list[list[dict]] = []
    for item in validos:
        encaixou = False
        # Chamada de nota é uma caixa minúscula e assentada acima da linha:
        # ela mal encosta no texto ao lado. Com o mesmo critério das palavras
        # normais ela virava uma linha só dela, e o "2" de "36x²" acabava
        # solto, longe da palavra a que pertence.
        curta = len(item["texto"].strip()) <= 2
        for linha in linhas:
            topo_linha = min(c["topo"] for c in linha)
            base_linha = max(c["base"] for c in linha)
            sobreposicao = min(base_linha, item["base"]) - max(topo_linha, item["topo"])
            menor_altura = min(base_linha - topo_linha, item["base"] - item["topo"])
            # A ordenação é por topo, e a chamada de nota fica ACIMA da linha:
            # ela chega primeiro e vira âncora. Por isso o limiar reduzido vale
            # também quando é a linha existente que é só a marca de nota.
            linha_curta = all(len(c["texto"].strip()) <= 2 for c in linha)
            limiar = 0.15 if (curta or linha_curta) else 0.5
            if menor_altura > 0 and sobreposicao > menor_altura * limiar:
                linha.append(item)
                encaixou = True
                break
        if not encaixou:
            linhas.append([item])

    linhas.sort(key=lambda l: min(c["topo"] for c in l))
    saida = []
    for linha in linhas:
        linha.sort(key=lambda c: c["esquerda"])
        saida.append(_montar_linha(linha))
    return saida


RE_CHAMADA_DE_NOTA = re.compile(r"^[0-9]{1,2}$|^\*{1,3}$")


def _montar_linha(caixas: list[dict]) -> str:
    """
    Junta as caixas de uma linha, colando a chamada de nota na palavra anterior.

    O motor devolve o "2" de "CDB²" como uma caixa separada, e juntar tudo com
    espaço produziria "CDB 2". O docx traz "CDB2", porque o Word cola o
    sobrescrito — a diferença viraria apontamento em toda peça com nota de
    rodapé, que em banco é praticamente toda peça.

    O que identifica a chamada: texto de um ou dois dígitos (ou asterisco),
    caixa visivelmente menor que a anterior e assentada mais alto que ela.
    """
    partes = []
    anterior = None
    vistos_na_linha = []
    for caixa in caixas:
        texto = caixa["texto"].strip()
        if not texto:
            continue
        colar = False
        if anterior is not None and RE_CHAMADA_DE_NOTA.match(texto):
            altura = caixa["base"] - caixa["topo"]
            altura_anterior = anterior["base"] - anterior["topo"]
            distancia = caixa["esquerda"] - anterior.get("direita", anterior["esquerda"])
            mais_alta = caixa["topo"] < anterior["topo"]
            menor = altura_anterior > 0 and altura < altura_anterior * 0.8
            perto = distancia < altura_anterior * 0.8
            colar = menor and mais_alta and perto
        # A sobreposição entre faixas faz a mesma frase ser lida duas vezes, e
        # o acento muda entre as leituras ("Seducäo" e "Seducao"), então o
        # descarte por texto idêntico não pega. Comparar sem acento pega.
        assinatura = unicodedata.normalize("NFD", texto.lower())
        assinatura = "".join(c for c in assinatura
                             if unicodedata.category(c) != "Mn" and c.isalnum())
        if assinatura and assinatura in vistos_na_linha:
            continue
        if assinatura:
            vistos_na_linha.append(assinatura)

        partes.append(("" if colar else " ") + texto if partes else texto)
        anterior = caixa
    return "".join(partes)


# ------------------------------------------------------------------- motores

class MotorBase:
    # Fatiar a peça em faixas resolve o encolhimento do detector antigo, mas o
    # detector novo lê a imagem alta inteira e, em fatia, mistura colunas
    # vizinhas numa caixa só. Cada motor diz o que funciona para ele.
    prefere_imagem_inteira = False

    nome = ""
    descricao = ""

    def disponivel(self) -> tuple[bool, str]:
        raise NotImplementedError

    def caixas(self, imagem, idioma: str, confianca_minima: int) -> list[dict]:
        """Devolve as caixas de texto detectadas, com posição e confiança."""
        raise NotImplementedError

    def ler(self, caminho: str, idioma: str, confianca_minima: int) -> ResultadoOCR:
        nome_arquivo = os.path.basename(caminho)
        try:
            imagem = _preparar(caminho)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        try:
            itens, fatias = _caixas_em_fatias(self, imagem, idioma, confianca_minima)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        linhas = _ordenar_linhas(itens)
        confiancas = [i["confianca"] for i in itens if i.get("confianca")]
        media = round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0

        avisos = []
        if fatias > 1:
            avisos.append(f"lida em {fatias} faixas")
        if not linhas:
            avisos.append("nenhum texto encontrado nesta imagem")
        elif media and media < CONFIANCA_PARA_ALERTAR:
            # transparência sobre o que a máquina não teve certeza de ler:
            # é melhor apontar a dúvida do que deixar passar como certo
            avisos.append(f"leitura incerta ({media:.0f}% de confiança), vale conferir no olho")
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome, aviso="; ".join(avisos),
            confianca_media=media,
        )


class MotorWindows(MotorBase):
    """OCR embutido no Windows. Nenhum programa novo para instalar."""

    nome = "windows"
    descricao = "OCR nativo do Windows"

    def disponivel(self):
        if os.name != "nt":
            return False, "só funciona no Windows"
        try:
            import winocr  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install winocr"
        return True, "ok"

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import winocr

        tag = {"por": "pt-BR", "eng": "en-US"}.get(idioma, idioma)
        try:
            resultado = winocr.recognize_pil_sync(imagem, tag)
        except Exception:
            # idioma não instalado no Windows: cai para o padrão do sistema
            resultado = winocr.recognize_pil_sync(imagem)

        linhas_brutas = (resultado.get("lines") if isinstance(resultado, dict)
                         else getattr(resultado, "lines", None))

        itens = []
        for linha in (linhas_brutas or []):
            if isinstance(linha, dict):
                texto = linha.get("text", "")
                palavras = linha.get("words", []) or []
                caixa = palavras[0].get("bounding_rect", {}) if palavras else {}
                topo, esquerda = caixa.get("y", 0), caixa.get("x", 0)
                altura, largura = caixa.get("height", 10), caixa.get("width", 10)
                if palavras:
                    ultima = palavras[-1].get("bounding_rect", {})
                    largura = max(largura, ultima.get("x", 0) + ultima.get("width", 0) - esquerda)
            else:
                texto = getattr(linha, "text", "") or ""
                palavras = getattr(linha, "words", []) or []
                topo = esquerda = 0
                altura = largura = 10
                if palavras:
                    caixa = getattr(palavras[0], "bounding_rect", None)
                    if caixa is not None:
                        topo = getattr(caixa, "y", 0)
                        esquerda = getattr(caixa, "x", 0)
                        altura = getattr(caixa, "height", 10)
                        largura = getattr(caixa, "width", 10)
            if not texto.strip():
                continue
            itens.append({
                "texto": texto, "topo": topo, "base": topo + altura,
                "esquerda": esquerda, "direita": esquerda + largura,
                "confianca": 0.0,   # o Windows não devolve confiança por linha
            })
        return itens


# Abaixo disso o motor usa modelos antigos: sigla curta e texto pequeno passam
# despercebidos, e a confiança vem como texto em vez de número.
VERSAO_MINIMA_RAPIDOCR = (1, 4, 0)


def _versao_instalada(pacote: str):
    try:
        from importlib.metadata import version
        partes = version(pacote).split(".")[:3]
        return tuple(int("".join(c for c in p if c.isdigit()) or 0) for p in partes)
    except Exception:
        return None


# O ThreadPoolExecutor de ler_imagem chama _obter() de várias threads ao mesmo
# tempo. Sem trava, duas delas viam o leitor vazio e iniciavam o RapidOCR duas
# vezes (carrega os modelos ONNX duas vezes e uma instância se perde).
_TRAVA_RAPIDOCR = threading.Lock()


class MotorRapidOCRNovo(MotorBase):
    """
    O RapidOCR atual, publicado sob o nome `rapidocr` (3.x).

    O projeto trocou de nome: `rapidocr-onnxruntime` parou na 1.4.4, que exige
    Python abaixo do 3.13. Quem está num Python mais novo não consegue instalar
    nada além da 1.2.3 — uma versão de 2023, com modelos três gerações atrás,
    que perde sigla curta e texto pequeno sem avisar.

    O pacote novo acompanha o Python atual e traz o PP-OCRv6. É o preferido
    quando existe; o antigo continua atendido para quem já o tem instalado.
    """

    nome = "rapidocr"
    descricao = "RapidOCR (modelos embutidos, sem instalar programa)"
    prefere_imagem_inteira = True

    def __init__(self):
        self._leitor = None

    def disponivel(self) -> tuple[bool, str]:
        try:
            import rapidocr  # noqa: F401
        except ImportError:
            return False, 'falta o pacote Python: pip install rapidocr'
        return True, "pronto"

    def _obter(self):
        if self._leitor is None:
            with _TRAVA_RAPIDOCR:
                # confere de novo já com a trava: outra thread pode ter
                # terminado a inicialização enquanto esta esperava
                if self._leitor is None:
                    import logging

                    from rapidocr import RapidOCR
                    # a biblioteca fala muito no terminal a cada leitura; aqui o
                    # que interessa é o resultado
                    for registro in ("RapidOCR", "rapidocr"):
                        logging.getLogger(registro).setLevel(logging.ERROR)

                    # A detecção, no ajuste padrão, estica a caixa até engolir a
                    # coluna vizinha: "50%" e "na poltrona D-BOX" saíam numa caixa
                    # só, e aí a análise de layout não tinha o que separar. Com a
                    # expansão fixada, cada trecho volta a ter caixa própria.
                    try:
                        self._leitor = RapidOCR(params={"Det.unclip_ratio": 1.6})
                    except Exception:
                        self._leitor = RapidOCR()
        return self._leitor

    def caixas(self, imagem, idioma: str = "por", confianca_minima: int = 40):
        import numpy as np

        resultado = self._obter()(np.array(imagem.convert("RGB")))
        textos = getattr(resultado, "txts", None) or []
        pontos = getattr(resultado, "boxes", None)
        notas = getattr(resultado, "scores", None) or []
        if pontos is None or not len(textos):
            return []

        limite = confianca_minima / 100
        itens = []
        for caixa, texto, nota in zip(pontos, textos, notas):
            confianca = _como_numero(nota)
            if confianca < limite:
                continue
            coordenadas = [(_como_numero(p[0]), _como_numero(p[1])) for p in caixa]
            itens.append({
                "texto": str(texto or ""),
                "topo": min(p[1] for p in coordenadas),
                "base": max(p[1] for p in coordenadas),
                "esquerda": min(p[0] for p in coordenadas),
                "direita": max(p[0] for p in coordenadas),
                "confianca": confianca * 100,
            })
        return itens


class MotorRapidOCR(MotorBase):
    """Modelos ONNX que vêm no próprio pacote pip. Offline, sem binário."""

    nome = "rapidocr-antigo"
    descricao = "RapidOCR 1.x (pacote antigo rapidocr-onnxruntime)"
    _motor = None

    def disponivel(self):
        try:
            import rapidocr_onnxruntime  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install rapidocr-onnxruntime"
        return True, "ok"

    def _obter(self):
        if MotorRapidOCR._motor is None:
            with _TRAVA_RAPIDOCR:
                if MotorRapidOCR._motor is None:
                    from rapidocr_onnxruntime import RapidOCR
                    MotorRapidOCR._motor = RapidOCR()
        return MotorRapidOCR._motor

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import numpy as np

        saida, _ = self._obter()(np.array(imagem.convert("RGB")))
        if not saida:
            return []

        limite = confianca_minima / 100
        itens = []
        for registro in saida:
            caixa, texto, confianca = registro[0], registro[1], registro[2]
            confianca = _como_numero(confianca)
            if confianca < limite:
                continue
            pontos = [(_como_numero(p[0]), _como_numero(p[1])) for p in caixa]
            itens.append({
                "texto": str(texto or ""),
                "topo": min(p[1] for p in pontos),
                "base": max(p[1] for p in pontos),
                "esquerda": min(p[0] for p in pontos),
                "direita": max(p[0] for p in pontos),
                "confianca": confianca * 100,
            })
        return itens


def pasta_de_idiomas_local() -> str:
    """Pasta tessdata ao lado do script, onde --instalar-idioma-por guarda o idioma."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "tessdata")


def _usar_pasta_de_idiomas_local() -> None:
    """
    Aponta o Tesseract para a pasta tessdata ao lado do script, se ela tiver o português.

    Gravar na pasta de instalação do Tesseract pede administrador no Windows; a
    pasta local não pede. TESSDATA_PREFIX definido pela própria pessoa sempre vence.
    """
    if os.environ.get("TESSDATA_PREFIX"):
        return
    pasta = pasta_de_idiomas_local()
    if os.path.isfile(os.path.join(pasta, "por.traineddata")):
        os.environ["TESSDATA_PREFIX"] = pasta


def _pasta_de_idiomas_do_tesseract() -> str:
    """Pasta onde o Tesseract procura os idiomas, lida da saída dele. Vazio se não achar."""
    import shutil
    import subprocess

    try:
        import pytesseract
        comando = pytesseract.pytesseract.tesseract_cmd or "tesseract"
    except ImportError:
        comando = "tesseract"

    try:
        saida = subprocess.run([comando, "--list-langs"], capture_output=True,
                               text=True, timeout=20)
        texto = (saida.stdout or "") + "\n" + (saida.stderr or "")
        achado = re.search(r'languages\s+in\s+"([^"]+)"', texto)
        if achado and os.path.isdir(achado.group(1)):
            return achado.group(1)
    except Exception:
        pass

    # o Tesseract 4 não diz a pasta: tenta a que fica ao lado do executável
    caminho = shutil.which(comando) or comando
    ao_lado = os.path.join(os.path.dirname(os.path.abspath(caminho)), "tessdata")
    return ao_lado if os.path.isdir(ao_lado) else ""


class MotorTesseract(MotorBase):
    """Tesseract. Aceita instalação normal ou versão portátil via TESSERACT_CMD."""

    nome = "tesseract"
    descricao = "Tesseract"

    def disponivel(self):
        try:
            import pytesseract
        except ImportError:
            return False, "falta o pacote Python: pip install pytesseract"
        _usar_pasta_de_idiomas_local()
        if os.environ.get("TESSERACT_CMD"):
            pytesseract.pytesseract.tesseract_cmd = os.environ["TESSERACT_CMD"]
        try:
            pytesseract.get_tesseract_version()
        except Exception:
            return False, "o programa Tesseract não foi encontrado na máquina"
        return True, "ok"

    def idiomas(self):
        try:
            import pytesseract
            return list(pytesseract.get_languages(config=""))
        except Exception:
            return []

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import pytesseract
        from PIL import ImageOps

        disponiveis = self.idiomas()
        if disponiveis and idioma not in disponiveis:
            idioma = "eng" if "eng" in disponiveis else disponiveis[0]

        preparada = ImageOps.autocontrast(ImageOps.grayscale(imagem))
        dados = pytesseract.image_to_data(
            preparada, lang=idioma, output_type=pytesseract.Output.DICT, config="--psm 6"
        )

        agrupadas: dict[tuple, dict] = {}
        for i, palavra in enumerate(dados["text"]):
            palavra = palavra.strip()
            if not palavra:
                continue
            try:
                confianca = float(dados["conf"][i])
            except (ValueError, TypeError):
                confianca = -1
            if confianca < confianca_minima:
                continue
            chave = (dados["block_num"][i], dados["par_num"][i], dados["line_num"][i])
            registro = agrupadas.setdefault(chave, {
                "texto": "", "topo": dados["top"][i], "esquerda": dados["left"][i],
                "base": dados["top"][i] + dados["height"][i],
                "direita": dados["left"][i] + dados["width"][i],
                "confianca": confianca, "soma": 0.0, "quantidade": 0,
            })
            registro["texto"] = (registro["texto"] + " " + palavra).strip()
            registro["esquerda"] = min(registro["esquerda"], dados["left"][i])
            registro["base"] = max(registro["base"], dados["top"][i] + dados["height"][i])
            registro["direita"] = max(registro["direita"],
                                      dados["left"][i] + dados["width"][i])
            registro["soma"] += confianca
            registro["quantidade"] += 1

        for registro in agrupadas.values():
            if registro["quantidade"]:
                registro["confianca"] = registro["soma"] / registro["quantidade"]
        return list(agrupadas.values())


# A ordem é a preferência quando nenhum motor foi escolhido à mão.
#
# RapidOCR vem primeiro por dois motivos. Ele reporta a confiança de cada
# leitura — sem isso o sistema não consegue avisar "leitura duvidosa" nem
# descartar ruído de ícone, que são duas defesas importantes. E, nas peças
# testadas, errou menos: onde o motor do Windows devolveu "Estreias
# deseeerpbro", ele leu "Estreias de setembro".
#
# O do Windows continua disponível e tem uma vantagem real: acentua certo,
# porque tem português nativo. Vale testar os dois nas suas peças e fixar o
# melhor com a variável OCR_MOTOR.
MOTORES = [MotorRapidOCRNovo(), MotorRapidOCR(), MotorWindows(), MotorTesseract()]
_ESCOLHIDO = None
_DIAGNOSTICO = None


def aviso_de_versao() -> str:
    """
    Alerta quando o motor instalado é velho demais para as peças daqui.

    Vale a pena gastar uma linha na tela com isso: com uma versão antiga a
    leitura falha em silêncio — o texto some e o apontamento aparece como se
    fosse erro da peça. Já aconteceu de levar um dia para descobrir.
    """
    motor = motor_ativo()
    if not motor or motor.nome != "rapidocr-antigo":
        return ""
    instalada = _versao_instalada("rapidocr-onnxruntime")
    if not instalada or instalada >= VERSAO_MINIMA_RAPIDOCR:
        return ""
    atual = ".".join(str(n) for n in instalada)
    return (f"A leitura está usando o RapidOCR {atual}, de 2023 — ela perde "
            "sigla curta e texto pequeno dentro das imagens, sem avisar. "
            "O projeto mudou de nome e o pacote atual acompanha o Python novo. "
            "Instale com: python -m pip install rapidocr")


def diagnosticar() -> list[dict]:
    """Estado de cada motor, para a tela mostrar o que falta instalar."""
    global _DIAGNOSTICO
    if _DIAGNOSTICO is None:
        _DIAGNOSTICO = []
        for motor in MOTORES:
            ok, motivo = motor.disponivel()
            _DIAGNOSTICO.append({
                "nome": motor.nome, "descricao": motor.descricao,
                "disponivel": ok, "motivo": motivo,
            })
    return _DIAGNOSTICO


# motor escolhido na tela, válido só para a conferência em curso
_FORCADO_NA_TELA = ""
_AVISO_DE_ESCOLHA = ""


def aviso_de_escolha() -> str:
    """Explica por que o motor em uso não é o que foi pedido."""
    return _AVISO_DE_ESCOLHA


def forcar_motor(nome: str) -> None:
    """Fixa o motor para as próximas leituras. Vazio volta à preferência padrão."""
    global _FORCADO_NA_TELA, _ESCOLHIDO
    nome = (nome or "").strip().lower()
    if nome != _FORCADO_NA_TELA:
        _FORCADO_NA_TELA = nome
        _ESCOLHIDO = None        # refaz a escolha na próxima leitura


def motores_disponiveis() -> list[dict]:
    return [d for d in diagnosticar() if d["disponivel"]]


def motor_ativo():
    """Escolhe o motor: o forçado à mão, ou o primeiro disponível da lista."""
    global _ESCOLHIDO
    if _ESCOLHIDO is not None:
        return _ESCOLHIDO or None

    global _AVISO_DE_ESCOLHA
    _AVISO_DE_ESCOLHA = ""

    forcado = (_FORCADO_NA_TELA
               or (os.environ.get("OCR_MOTOR") or "").strip().lower())

    if forcado:
        pedido = next((m for m in MOTORES if m.nome == forcado), None)
        if pedido is None:
            _AVISO_DE_ESCOLHA = (
                f"O motor \u201c{forcado}\u201d não existe. "
                f"Use um destes: {', '.join(m.nome for m in MOTORES)}."
            )
        else:
            ok, motivo = pedido.disponivel()
            if ok:
                _ESCOLHIDO = pedido
                return pedido
            # Pedir um motor que não está instalado não pode desligar a leitura
            # inteira: o certo é usar o que existe e dizer por que não foi o
            # escolhido. Desligar em silêncio faz parecer defeito do sistema.
            _AVISO_DE_ESCOLHA = (
                f"Você pediu o motor \u201c{forcado}\u201d, mas ele não está "
                f"disponível ({motivo})."
            )

    for motor in MOTORES:
        ok, _ = motor.disponivel()
        if ok:
            _ESCOLHIDO = motor
            return motor
    _ESCOLHIDO = False
    return None


def ocr_disponivel() -> tuple[bool, str]:
    motor = motor_ativo()
    if motor:
        aviso = aviso_de_escolha()
        if aviso:
            return True, f"{aviso} Usando {motor.descricao}."
        return True, f"{motor.descricao} ativo"
    faltas = "; ".join(f"{d['nome']}: {d['motivo']}" for d in diagnosticar())
    return False, f"nenhum motor de leitura disponível ({faltas})"


def idiomas_instalados() -> list[str]:
    motor = motor_ativo()
    if isinstance(motor, MotorTesseract):
        return motor.idiomas()
    if motor:
        return ["por"]  # Windows e RapidOCR cobrem o alfabeto latino
    return []


COMANDO_IDIOMA_POR = "python validador_emkt_unificado.py --instalar-idioma-por"


def aviso_de_idioma() -> str:
    """
    Aviso para quando o motor em uso é o Tesseract e falta o português.

    Sem o idioma, o Tesseract cai para o inglês e perde os acentos, e cada
    palavra acentuada vira divergência falsa contra o docx. Vazio quando não
    há o que avisar (outro motor, ou Tesseract com o idioma).
    """
    motor = motor_ativo()
    if not isinstance(motor, MotorTesseract):
        return ""
    if "por" in motor.idiomas():
        return ""
    return (
        "O Tesseract está sem o idioma português, então os acentos saem errados "
        "na leitura das imagens. Para instalar, feche o programa e rode: "
        f"{COMANDO_IDIOMA_POR}. Outra saída é o RapidOCR (python -m pip install "
        "rapidocr), que não precisa de pacote de idioma."
    )


# Idiomas "fast" do projeto oficial do Tesseract: pequenos (cerca de 1 MB o
# português) e suficientes para texto de peça. TESSDATA_URL aponta para um
# espelho interno quando a rede da empresa bloqueia o github.com.
URL_IDIOMAS_TESSERACT = "https://github.com/tesseract-ocr/tessdata_fast/raw/main"
TAMANHO_MINIMO_DE_IDIOMA = 200_000    # abaixo disso o download veio uma página de erro


def _baixar_idioma(url_base: str, idioma: str, pasta: str, minimo_bytes: int) -> None:
    import shutil
    import urllib.request

    destino = os.path.join(pasta, f"{idioma}.traineddata")
    parcial = destino + ".parte"
    pedido = urllib.request.Request(
        f"{url_base.rstrip('/')}/{idioma}.traineddata",
        headers={"User-Agent": "validador-emkt"},
    )
    try:
        with urllib.request.urlopen(pedido, timeout=90) as resposta, \
                open(parcial, "wb") as saida:
            shutil.copyfileobj(resposta, saida)
        if os.path.getsize(parcial) < minimo_bytes:
            raise OSError(f"o arquivo de {idioma} veio pequeno demais, "
                          "provavelmente não é o idioma")
        os.replace(parcial, destino)
    finally:
        if os.path.exists(parcial):
            os.remove(parcial)


def instalar_idioma_por(imprimir=print, destino=None, url_base=None,
                        minimo_bytes: int = TAMANHO_MINIMO_DE_IDIOMA) -> bool:
    """
    Instala o idioma português (por.traineddata) do Tesseract. True se deu certo.

    Primeiro tenta a pasta de idiomas do próprio Tesseract. Sem permissão de
    escrita (comum no Windows, em Arquivos de Programas), guarda numa pasta
    tessdata ao lado do script e passa a usá-la sozinho nas próximas aberturas.
    A pasta local vira a única que o Tesseract enxerga, por isso leva junto o
    inglês.

    `destino` e `url_base` existem para os testes.
    """
    url_base = url_base or os.environ.get("TESSDATA_URL") or URL_IDIOMAS_TESSERACT

    if destino is None:
        motor = MotorTesseract()
        disponivel, motivo = motor.disponivel()
        if not disponivel:
            imprimir(f"Não dá para instalar o idioma: {motivo}.")
            imprimir("O idioma só importa para o Tesseract. Com o RapidOCR "
                     "(python -m pip install rapidocr) não é preciso.")
            return False
        if "por" in motor.idiomas():
            imprimir("O Tesseract já tem o idioma português. Nada a fazer.")
            return True

        sistema = _pasta_de_idiomas_do_tesseract()
        if sistema and os.access(sistema, os.W_OK):
            destino, idiomas = sistema, ["por"]
        else:
            destino, idiomas = pasta_de_idiomas_local(), ["por", "eng"]
            if sistema:
                imprimir(f"Sem permissão para gravar em {sistema}.")
            imprimir(f"O idioma vai para {destino}, ao lado do programa.")
    else:
        idiomas = ["por", "eng"]

    os.makedirs(destino, exist_ok=True)
    for idioma in idiomas:
        if os.path.isfile(os.path.join(destino, f"{idioma}.traineddata")):
            continue
        imprimir(f"Baixando {idioma}.traineddata...")
        try:
            _baixar_idioma(url_base, idioma, destino, minimo_bytes)
        except Exception as erro:  # noqa: BLE001 - rede, proxy, permissão
            imprimir(f"Falhou: {erro}")
            imprimir("Se a rede bloqueia o github.com, baixe o arquivo "
                     f"{idioma}.traineddata (projeto tessdata_fast) em outra "
                     f"máquina e copie para {destino}, ou aponte a variável "
                     "TESSDATA_URL para um espelho interno.")
            return False

    imprimir(f"Pronto: o idioma português está em {destino}. Abra o programa de novo.")
    return True


# Ícone de rede social, marcador de lista, pixel espaçador. Não cabe texto
# legível num quadrado de 20 px, e cada um desses custa meio segundo de
# leitura à toa — num pacote com dez ícones, são cinco segundos de espera.
LADO_MINIMO_PARA_LER = 60
AREA_MINIMA_PARA_LER = 2500


def _pequena_demais(caminho: str) -> tuple[bool, str]:
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            largura, altura = imagem.size
    except Exception:
        return False, ""
    if largura * altura < AREA_MINIMA_PARA_LER:
        return True, f"{largura}x{altura}: pequena demais para conter texto"
    if largura < LADO_MINIMO_PARA_LER and altura < LADO_MINIMO_PARA_LER:
        return True, f"{largura}x{altura}: tamanho de ícone"
    return False, ""


def _e_gif_animado(caminho: str) -> bool:
    if not caminho.lower().endswith(".gif"):
        return False
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return getattr(imagem, "n_frames", 1) > 1
    except Exception:
        return False


def ler_imagem(caminho: str, idioma: str = "por",
               confianca_minima: int = 40) -> ResultadoOCR:
    motor = motor_ativo()
    nome = os.path.basename(caminho)
    if not motor:
        return ResultadoOCR(arquivo=nome, erro=ocr_disponivel()[1])

    pequena, motivo = _pequena_demais(caminho)
    if pequena:
        return ResultadoOCR(arquivo=nome, lido=True, motor=motor.nome, aviso=motivo)

    if not _e_gif_animado(caminho):
        return motor.ler(caminho, idioma, confianca_minima)

    # GIF animado: cada cena pode trazer texto próprio, e é comum a oferta
    # inteira estar espalhada entre os frames.
    import tempfile

    textos, confiancas, frames_lidos = [], [], 0
    try:
        quadros = _frames_relevantes(caminho)
    except Exception as e:
        return ResultadoOCR(arquivo=nome, erro=f"não consegui abrir o GIF: {e}",
                            motor=motor.nome)

    with tempfile.TemporaryDirectory(prefix="frames_") as pasta:
        for indice, quadro in enumerate(quadros):
            destino = os.path.join(pasta, f"frame_{indice:02d}.png")
            try:
                quadro.save(destino)
            except Exception:
                continue
            parcial = motor.ler(destino, idioma, confianca_minima)
            if parcial.texto:
                textos.append(parcial.texto)
                frames_lidos += 1
            if parcial.confianca_media:
                confiancas.append(parcial.confianca_media)

    texto = _juntar_textos(textos)
    return ResultadoOCR(
        arquivo=nome, texto=texto, lido=True, motor=motor.nome,
        linhas=texto.splitlines(),
        confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        aviso=(f"GIF animado: {frames_lidos} cena(s) lida(s) de "
               f"{len(quadros)} frame(s) distintos"),
    )


# ------------------------------------------------------- cache entre execuções

PASTA_CACHE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".cache-leitura"
)

# Módulos cujo código decide o texto que sai de uma imagem: o próprio ocr
# (motores, fatiamento, filtros), o layout (separa a peça em blocos antes de
# montar as linhas) e a normalização (limpar). Só o texto destes entra na chave
# do cache. A correção de OCR, o comparador, o parser de HTML, as regras e a
# tela rodam DEPOIS da leitura e não mudam o que o cache guarda: mexer neles
# não pode jogar fora leituras que levaram minutos.
MODULOS_DA_LEITURA = ("ocr", "layout", "normalizacao")


def _fontes_da_leitura() -> list:
    """Texto de cada módulo da leitura, na ordem fixa de MODULOS_DA_LEITURA."""
    # no script único, o carregador entrega os textos embutidos
    embutidas = globals().get("_FONTES_DO_SCRIPT") or {}
    pasta = os.path.dirname(os.path.abspath(__file__))
    fontes = []
    for nome in MODULOS_DA_LEITURA:
        texto = embutidas.get(nome)
        if texto is None:
            # pacote em pastas (validador/ocr.py...): lê o arquivo ao lado
            try:
                with open(os.path.join(pasta, nome + ".py"), encoding="utf-8") as f:
                    texto = f.read()
            except OSError:
                texto = ""      # sem acesso ao código: a chave cai no nome do módulo
        fontes.append((nome, texto))
    return fontes


def _versao_da_leitura(fontes: list | None = None) -> str:
    """
    Identidade do código que produz a leitura.

    Isto já foi um número escrito à mão, e o número ficou para trás três vezes
    seguidas enquanto o comportamento da leitura mudava. O efeito é pior do que
    parece: a correção entra no código, a pessoa atualiza, roda o mesmo pacote
    e continua vendo o erro antigo, porque o cache devolve a leitura de antes.
    Depurar isso custa caro, e o sintoma aponta para o lugar errado.

    A chave é o resumo do texto dos módulos de MODULOS_DA_LEITURA. Mudou o
    código que decide a leitura, o cache antigo deixa de valer sozinho. Mudou
    qualquer outra parte do script (a tela, por exemplo), o cache sobrevive.

    `fontes` existe para os testes: lista de (nome, texto) no lugar da real.
    """
    import hashlib

    digestor = hashlib.sha1()
    for nome, texto in (_fontes_da_leitura() if fontes is None else fontes):
        digestor.update(nome.encode("utf-8") + b"\0")
        digestor.update(texto.encode("utf-8") + b"\0")
    return digestor.hexdigest()[:12]


VERSAO_DA_LEITURA = _versao_da_leitura()


def _impressao_do_arquivo(caminho: str, motor: str) -> str | None:
    """
    Identidade da leitura: conteúdo do arquivo + motor + versão.

    Pelo conteúdo, e não pelo caminho: o mesmo banner reaparece em campanhas
    diferentes com nomes diferentes, e conferir de novo o que já foi lido é
    desperdício. Muda uma vírgula na imagem, muda a impressão.
    """
    import hashlib

    try:
        digestor = hashlib.sha1()
        with open(caminho, "rb") as arquivo:
            for pedaco in iter(lambda: arquivo.read(262144), b""):
                digestor.update(pedaco)
    except OSError:
        return None
    digestor.update(f"|{motor}|{VERSAO_DA_LEITURA}".encode())
    return digestor.hexdigest()


def _ler_do_cache(impressao: str) -> ResultadoOCR | None:
    if not impressao:
        return None
    import json

    caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
    try:
        with open(caminho, encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
        return ResultadoOCR(**dados)
    except Exception:
        return None


def _gravar_no_cache(impressao: str, resultado: ResultadoOCR) -> None:
    if not impressao or resultado.erro:
        return          # falha não entra no cache: a próxima tentativa pode dar certo
    import json
    from dataclasses import asdict

    try:
        os.makedirs(PASTA_CACHE, exist_ok=True)
        caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
        with open(caminho, "w", encoding="utf-8") as arquivo:
            json.dump(asdict(resultado), arquivo, ensure_ascii=False)
    except OSError:
        pass            # sem permissão de escrita: segue sem cache


class CacheOCR:
    """
    Guarda a leitura de cada imagem, dentro da execução e entre execuções.

    Ler imagem é praticamente todo o tempo da conferência. Na prática o mesmo
    pacote é conferido várias vezes — ajusta o docx, confere de novo — e as
    imagens não mudaram. Reler tudo a cada vez é o desperdício mais caro aqui.
    """

    def __init__(self, idioma: str = "por", confianca_minima: int = 40,
                 usar_disco: bool = True):
        self.idioma = idioma
        self.confianca_minima = confianca_minima
        self.usar_disco = usar_disco
        self.aviso_idioma = ""
        self.reaproveitadas = 0
        self._cache: dict[str, ResultadoOCR] = {}

    def _nome_do_motor(self) -> str:
        motor = motor_ativo()
        return motor.nome if motor else "nenhum"

    def ler(self, caminho: str) -> ResultadoOCR:
        chave = os.path.normcase(os.path.abspath(caminho))
        if chave in self._cache:
            return self._cache[chave]

        impressao = (_impressao_do_arquivo(caminho, self._nome_do_motor())
                     if self.usar_disco else None)
        guardado = _ler_do_cache(impressao) if impressao else None
        if guardado is not None:
            self.reaproveitadas += 1
            self._cache[chave] = guardado
            return guardado

        resultado = ler_imagem(caminho, self.idioma, self.confianca_minima)
        if resultado.aviso and not self.aviso_idioma:
            self.aviso_idioma = resultado.aviso
        if impressao:
            _gravar_no_cache(impressao, resultado)
        self._cache[chave] = resultado
        return resultado

    def pre_carregar(self, caminhos: list[str], trabalhadores: int = 3,
                     ao_avancar=None) -> None:
        """
        Lê várias imagens ao mesmo tempo.

        O reconhecimento roda fora do Python, então a espera de uma imagem não
        impede a leitura da outra — ler quatro em paralelo aproveita a máquina
        em vez de ficar na fila.
        """
        pendentes = []
        for caminho in caminhos:
            chave = os.path.normcase(os.path.abspath(caminho))
            if chave not in self._cache and os.path.exists(caminho):
                pendentes.append(caminho)
        total = len(pendentes)
        if total < 2:
            for caminho in pendentes:
                self.ler(caminho)
                if ao_avancar:
                    ao_avancar(1, total)
            return

        from concurrent.futures import ThreadPoolExecutor

        concluidas = 0
        with ThreadPoolExecutor(max_workers=min(trabalhadores, total)) as pool:
            for _ in pool.map(self.ler, pendentes):
                concluidas += 1
                if ao_avancar:
                    ao_avancar(concluidas, total)

    @property
    def lidas(self) -> int:
        return sum(1 for r in self._cache.values() if r.lido)
''',
    # ---- validador/imagens.py -----------------------------------------------------
    "imagens": r'''"""
Conferência do pacote de imagens.

Substitui o CTRL+F. Responde três perguntas:
  1. Os nomes seguem a taxonomia da quebra?
  2. A numeração é sequencial, sem furo (01, 02, 08, 03 reprova)?
  3. Toda imagem da pasta está no HTML, e todo src do HTML existe na pasta?

Repetição da mesma imagem dentro do HTML é permitida e não gera apontamento.
"""

import os
import re

from . import regras
from collections import Counter
from dataclasses import dataclass, field

EXTENSOES_VALIDAS = {".jpg", ".jpeg", ".png", ".gif"}

# Nomes que denunciam material de apoio: a arte do e-mail inteiro que a agência
# manda junto para conferência visual.
RE_APOIO = re.compile(
    r"preview|layout|mockup|arte|final|completo|full|montagem|aprova[cç][aã]o|"
    r"refer[eê]ncia|amostra",
    re.IGNORECASE,
)

# Uma peça inteira em imagem única é muito mais alta que larga. Banner de
# seção raramente passa disso.
PROPORCAO_DE_PECA_INTEIRA = 2.5

# quebra + separador opcional + número + extensão
RE_PADRAO = re.compile(
    r"^(?P<quebra>.+?)[_\-\s]?(?P<numero>\d{1,3})$"
)


@dataclass
class ImagemPasta:
    nome: str
    caminho: str
    quebra_detectada: str = ""
    numero: int | None = None
    extensao: str = ""
    tamanho_kb: float = 0.0
    largura: int = 0
    altura: int = 0
    apoio: bool = False


@dataclass
class ResultadoImagens:
    quebra: str = ""
    quebra_inferida: bool = False
    arquivos: list[ImagemPasta] = field(default_factory=list)
    fora_da_taxonomia: list[tuple[str, str]] = field(default_factory=list)
    numeros_faltando: list[int] = field(default_factory=list)
    numeros_duplicados: list[int] = field(default_factory=list)
    nao_comeca_em_um: bool = False
    sem_numeracao_zero_a_esquerda: list[str] = field(default_factory=list)
    extensao_invalida: list[str] = field(default_factory=list)
    acima_do_peso: list[tuple[str, float]] = field(default_factory=list)
    na_pasta_fora_do_html: list[str] = field(default_factory=list)
    no_html_fora_da_pasta: list[str] = field(default_factory=list)
    divergencia_de_caixa: list[tuple[str, str]] = field(default_factory=list)
    material_de_apoio: list[tuple[str, str]] = field(default_factory=list)
    repeticoes_no_html: dict = field(default_factory=dict)
    total_referencias_html: int = 0

    @property
    def aprovado(self) -> bool:
        return not (
            self.acima_do_peso
            or self.fora_da_taxonomia
            or self.numeros_faltando
            or self.numeros_duplicados
            or self.extensao_invalida
            or self.na_pasta_fora_do_html
            or self.no_html_fora_da_pasta
            or self.divergencia_de_caixa
            or self.nao_comeca_em_um
        )


def _inferir_quebra(nomes: list[str]) -> str:
    """
    Deduz a quebra pelo prefixo mais comum quando ela não é informada.
    Usar a moda em vez do prefixo comum a todos evita que um arquivo com nome
    errado — justamente o que queremos flagrar — contamine a referência.
    """
    candidatos = []
    for nome in nomes:
        base = os.path.splitext(nome)[0]
        m = RE_PADRAO.match(base)
        if m:
            candidatos.append(m.group("quebra").strip())
    if not candidatos:
        return ""
    return Counter(candidatos).most_common(1)[0][0]


def listar_pasta(pasta_imagens: str) -> list[ImagemPasta]:
    itens = []
    if not os.path.isdir(pasta_imagens):
        return itens
    for raiz, _, arquivos in os.walk(pasta_imagens):
        for arquivo in sorted(arquivos):
            if arquivo.startswith(("~$", ".")):
                continue
            extensao = os.path.splitext(arquivo)[1].lower()
            if extensao not in EXTENSOES_VALIDAS and extensao not in {".webp", ".bmp", ".svg"}:
                continue
            caminho = os.path.join(raiz, arquivo)
            itens.append(
                ImagemPasta(
                    nome=arquivo,
                    caminho=caminho,
                    extensao=extensao,
                    tamanho_kb=round(os.path.getsize(caminho) / 1024, 1),
                )
            )
    return itens


def _dimensoes(caminho: str) -> tuple[int, int]:
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return imagem.width, imagem.height
    except Exception:
        return 0, 0


def _e_material_de_apoio(imagem: ImagemPasta, referenciadas: set[str],
                         quebra: str) -> str:
    """
    Diz se o arquivo é a arte de conferência do e-mail inteiro, e por quê.

    Vem junto no pacote com frequência e não faz parte da peça publicada: não
    é chamada no código nem entra no Content Builder. Tratar como "imagem não
    utilizada" encheria o report de apontamento que ninguém precisa resolver.

    Só entra aqui o que NÃO é chamado no HTML — arquivo que o código usa é
    parte da peça, custe o nome que custar.
    """
    if imagem.nome.lower() in referenciadas:
        return ""

    if RE_APOIO.search(os.path.splitext(imagem.nome)[0]):
        return "nome indica arte de conferência"

    if not imagem.altura or not imagem.largura:
        imagem.largura, imagem.altura = _dimensoes(imagem.caminho)
    if imagem.largura and imagem.altura / imagem.largura >= PROPORCAO_DE_PECA_INTEIRA:
        return (f"proporção de peça inteira ({imagem.largura}x{imagem.altura})")

    # nome sem a quebra e sem numeração, e ninguém chama: não é peça de montagem
    if quebra and quebra.lower() not in imagem.nome.lower():
        base = os.path.splitext(imagem.nome)[0]
        if not RE_PADRAO.match(base):
            return "fora da taxonomia e não usado no código"
    return ""


def verificar(pasta_imagens: str, imagens_no_html: list[str],
              quebra: str | None = None) -> ResultadoImagens:
    resultado = ResultadoImagens()
    resultado.arquivos = listar_pasta(pasta_imagens)
    nomes_pasta = [i.nome for i in resultado.arquivos]

    if quebra:
        resultado.quebra = quebra.strip()
    else:
        resultado.quebra = _inferir_quebra(nomes_pasta)
        resultado.quebra_inferida = True

    referencia = resultado.quebra.lower()

    # --- material de apoio ---
    # Sai da conferência antes de tudo: não é peça publicada, então não entra
    # em taxonomia, sequência, peso nem cruzamento com o HTML.
    referenciadas = {n.lower() for n in imagens_no_html}
    for imagem in resultado.arquivos:
        motivo = _e_material_de_apoio(imagem, referenciadas, resultado.quebra)
        if motivo:
            imagem.apoio = True
            resultado.material_de_apoio.append((imagem.nome, motivo))
    resultado.arquivos = [i for i in resultado.arquivos if not i.apoio]
    nomes_pasta = [i.nome for i in resultado.arquivos]

    # --- peso dos arquivos ---
    # Vale para toda imagem da pasta, mesmo a que estiver fora da taxonomia:
    # peso é característica do arquivo, não depende de o nome estar certo.
    for imagem in resultado.arquivos:
        if imagem.tamanho_kb > regras.LIMITE_IMAGEM_KB:
            resultado.acima_do_peso.append((imagem.nome, imagem.tamanho_kb))

    # --- taxonomia e numeração ---
    numeros = []
    for imagem in resultado.arquivos:
        base = os.path.splitext(imagem.nome)[0]
        m = RE_PADRAO.match(base)
        if not m:
            resultado.fora_da_taxonomia.append(
                (imagem.nome, "não termina em número sequencial")
            )
            continue
        detectada = m.group("quebra").strip()
        imagem.quebra_detectada = detectada
        imagem.numero = int(m.group("numero"))

        if referencia and detectada.lower() != referencia:
            resultado.fora_da_taxonomia.append(
                (imagem.nome, f"prefixo '{detectada}' difere da quebra '{resultado.quebra}'")
            )
            continue

        if len(m.group("numero")) < 2:
            resultado.sem_numeracao_zero_a_esquerda.append(imagem.nome)

        if imagem.extensao not in EXTENSOES_VALIDAS:
            resultado.extensao_invalida.append(
                f"{imagem.nome} (extensão {imagem.extensao})"
            )

        numeros.append(imagem.numero)

    if numeros:
        contagem = Counter(numeros)
        resultado.numeros_duplicados = sorted(n for n, c in contagem.items() if c > 1)
        maior = max(numeros)
        presentes = set(numeros)
        resultado.numeros_faltando = [n for n in range(1, maior + 1) if n not in presentes]
        resultado.nao_comeca_em_um = 1 not in presentes

    # --- cruzamento pasta x HTML ---
    resultado.total_referencias_html = len(imagens_no_html)
    contagem_html = Counter(n.lower() for n in imagens_no_html)
    resultado.repeticoes_no_html = {
        nome: qtd for nome, qtd in contagem_html.items() if qtd > 1
    }

    mapa_pasta = {n.lower(): n for n in nomes_pasta}
    mapa_html = {}
    for nome in imagens_no_html:
        mapa_html.setdefault(nome.lower(), nome)

    for chave, nome_original in mapa_pasta.items():
        if chave not in mapa_html:
            resultado.na_pasta_fora_do_html.append(nome_original)

    for chave, nome_original in mapa_html.items():
        if chave not in mapa_pasta:
            resultado.no_html_fora_da_pasta.append(nome_original)
        elif mapa_pasta[chave] != nome_original:
            resultado.divergencia_de_caixa.append((mapa_pasta[chave], nome_original))

    return resultado
''',
    # ---- validador/docx_parser.py -------------------------------------------------
    "docx_parser": r'''"""
Leitura dos .docx do pacote.

Dois papéis diferentes:
  CONTEUDO.docx  -> todo o texto legível da peça, na ordem de leitura
  ASSUNTO.docx   -> assunto e pré-header

A identificação é por nome de arquivo, com heurística por conteúdo quando o
analista nomeia fora do padrão.
"""

import os
import re
from difflib import SequenceMatcher
from dataclasses import dataclass, field

from .normalizacao import limpar, sem_acento

RE_ASSUNTO = re.compile(r"assunto|subject|pre.?header|preheader", re.IGNORECASE)
RE_CONTEUDO = re.compile(r"conte.?do|content|texto|alt", re.IGNORECASE)


@dataclass
class LeituraDocx:
    caminho: str
    papel: str = "indefinido"       # "conteudo" | "assunto" | "indefinido"
    paragrafos: list[str] = field(default_factory=list)
    assunto: str = ""
    pre_header: str = ""
    links: list = field(default_factory=list)   # (texto visível, endereço)
    erros: list[str] = field(default_factory=list)

    def texto_completo(self) -> str:
        return "\n".join(self.paragrafos)


DIGITOS_SOBRESCRITOS = {
    "0": "\u2070", "1": "\u00b9", "2": "\u00b2", "3": "\u00b3", "4": "\u2074",
    "5": "\u2075", "6": "\u2076", "7": "\u2077", "8": "\u2078", "9": "\u2079",
}


NS_WORD = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _texto_com_sobrescrito(paragrafo) -> str:
    """
    Monta o texto do parágrafo, com duas coisas que o caminho simples perde.

    A primeira é a chamada de nota: o Word guarda o "1" de "18x¹" como
    formatação, não como caractere. Lido direto vira "18x1" e a peça aparece
    errada no preview, justamente onde se confere se a nota está certa.

    A segunda é mais grave. O texto dentro de um hyperlink não aparece em
    paragraph.runs — e some da comparação. Um trecho da peça que o redator
    colou como link simplesmente não era conferido, sem nenhum aviso. Aqui os
    dois casos são percorridos no XML, que traz tudo.
    """
    partes = []
    for no in paragrafo._p.iter():
        # Shift+Enter e tabulação também precisam sair no texto: é por eles que
        # "Assunto" e "Pré-header" escritos no mesmo bloco continuam separados.
        if no.tag == f"{NS_WORD}br":
            partes.append("\n")
            continue
        if no.tag == f"{NS_WORD}tab":
            partes.append(" ")
            continue
        if not no.tag.endswith("}t"):
            continue
        texto = no.text or ""
        if not texto:
            continue
        run = no.getparent()
        propriedades = run.find(f"{NS_WORD}rPr") if run is not None else None
        sobrescrito = False
        if propriedades is not None:
            alinhamento = propriedades.find(f"{NS_WORD}vertAlign")
            sobrescrito = (alinhamento is not None
                           and alinhamento.get(f"{NS_WORD}val") == "superscript")
        if sobrescrito and texto.strip().isdigit():
            texto = "".join(DIGITOS_SOBRESCRITOS.get(c, c) for c in texto)
        partes.append(texto)

    montado = "".join(partes)
    return montado if montado.strip() else paragrafo.text


def _extrair_paragrafos(caminho: str) -> tuple[list[str], list[str]]:
    """Lê parágrafos e também o texto dentro de tabelas, que o Word esconde do iterador padrão."""
    from docx import Document

    erros = []
    try:
        documento = Document(caminho)
    except Exception as e:
        return [], [f"não foi possível abrir: {e}"]

    linhas = []
    for paragrafo in documento.paragraphs:
        texto_do_paragrafo = _texto_com_sobrescrito(paragrafo)
        # Quebra de linha manual (Shift+Enter) fica DENTRO do parágrafo e volta
        # como \n. Sem dividir aqui, "Assunto: X" e "Pré-header: Y" escritos no
        # mesmo bloco viram uma linha só, e o assunto engole o pré-header
        # inteiro. Isso acontece muito quando o pessoal formata em negrito.
        for pedaco in texto_do_paragrafo.split("\n"):
            texto = limpar(pedaco)
            if texto:
                linhas.append(texto)

    for tabela in documento.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                texto = limpar(celula.text)
                if texto and texto not in linhas[-3:]:
                    linhas.append(texto)

    return linhas, erros


def _extrair_links(caminho: str) -> list[tuple]:
    """
    Acha os hyperlinks do documento.

    O CONTEUDO.docx é transcrição do que a peça mostra, não um documento
    navegável. Link ali significa que alguém colou de outro lugar sem limpar a
    formatação, e o endereço colado costuma ir parar no cadastro junto com o
    texto.
    """
    from docx import Document
    from docx.opc.constants import RELATIONSHIP_TYPE as TIPO

    try:
        documento = Document(caminho)
    except Exception:
        return []

    achados = []
    namespace = ("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}")
    for parte in documento.part.rels.values():
        if parte.reltype != TIPO.HYPERLINK:
            continue
        endereco = str(parte.target_ref or "")
        if endereco:
            achados.append(("", endereco))

    # o texto visível de cada link, para mostrar no apontamento
    corpo = documento.element.body
    textos = []
    for link in corpo.iter(f"{namespace}hyperlink"):
        texto = "".join(no.text or "" for no in link.iter(f"{namespace}t"))
        if texto.strip():
            textos.append(texto.strip())

    completos = []
    for indice, (_, endereco) in enumerate(achados):
        visivel = textos[indice] if indice < len(textos) else ""
        completos.append((visivel, endereco))
    return completos


def ler_docx(caminho: str, papel: str | None = None) -> LeituraDocx:
    """Lê o arquivo. O papel, quando não informado, é decidido em identificar_papeis()."""
    leitura = LeituraDocx(caminho=caminho)
    leitura.paragrafos, leitura.erros = _extrair_paragrafos(caminho)
    leitura.links = _extrair_links(caminho)
    if papel:
        leitura.papel = papel
        if papel == "assunto":
            leitura.assunto, leitura.pre_header = _separar_assunto(leitura.paragrafos)
    return leitura


def _pontuar_como_assunto(leitura: LeituraDocx) -> int:
    """
    O quanto este arquivo se parece com o docx de assunto e pré-header.

    O nome do arquivo não serve de critério: em pacote real ele costuma ser a
    quebra, o CPI ou a ação, e não "ASSUNTO" ou "CONTEUDO". O que distingue os
    dois é o conteúdo — o de assunto é curto e traz os rótulos; o de conteúdo é
    a peça inteira transcrita.
    """
    corpo = " ".join(leitura.paragrafos).lower()
    palavras = len(corpo.split())
    pontos = 0

    if RE_ASSUNTO.search(os.path.basename(leitura.caminho)):
        pontos += 3
    if re.search(r"\bassunto\b", corpo):
        pontos += 4
    if re.search(r"pr[eé].?header|preheader", corpo):
        pontos += 4
    if palavras <= 40:
        pontos += 3
    elif palavras <= 80:
        pontos += 1
    if len(leitura.paragrafos) <= 6:
        pontos += 2
    if palavras > 150:
        pontos -= 5
    return pontos


def identificar_papeis(caminhos: list[str]) -> tuple[LeituraDocx | None, LeituraDocx | None]:
    """
    Decide qual docx é o de conteúdo e qual é o de assunto.

    Devolve (conteudo, assunto). Regra, na ordem:
      - lê todos e pontua cada um pela cara de "assunto"
      - o melhor pontuado vira assunto, desde que passe do limiar
      - entre os restantes, o de maior corpo vira o conteúdo
      - com um arquivo só, ele é conteúdo, a menos que seja claramente assunto
    """
    leituras = [ler_docx(caminho) for caminho in caminhos]
    leituras = [l for l in leituras if l.paragrafos or not l.erros]
    if not leituras:
        return None, None

    pontuados = sorted(
        ((_pontuar_como_assunto(l), -len(" ".join(l.paragrafos)), l) for l in leituras),
        key=lambda t: (-t[0], t[1]),
    )

    assunto = None
    melhor_pontos, _, melhor = pontuados[0]
    # limiar 6: exige pelo menos dois sinais fortes (um rótulo + ser curto),
    # para não promover a assunto um conteúdo que por acaso é pequeno
    if melhor_pontos >= 6:
        assunto = melhor
        assunto.papel = "assunto"
        assunto.assunto, assunto.pre_header = _separar_assunto(assunto.paragrafos)

    candidatos = [l for l in leituras if l is not assunto]
    conteudo = None
    if candidatos:
        conteudo = max(candidatos, key=lambda l: len(" ".join(l.paragrafos)))
        conteudo.papel = "conteudo"
    elif assunto is not None and len(leituras) == 1:
        # arquivo único com cara de assunto: sem material para comparar o texto
        conteudo = None

    return conteudo, assunto


# Rótulos de referência, já sem acento e sem separador. A comparação é por
# similaridade, não por igualdade: em pacote real aparece "Pré-header",
# "Pre header", "Preheader", "Prehead" e uma boa variedade de digitação
# apressada, e nenhuma delas deveria quebrar a leitura.
ROTULOS_DE_REFERENCIA = {
    "assunto": ["assunto", "subject", "titulo"],
    "pre_header": ["preheader", "previewtext", "preview", "prechamada"],
}

SIMILARIDADE_MINIMA = 0.72


def _achatar_rotulo(texto: str) -> str:
    """Deixa só as letras minúsculas sem acento, para comparar grafias."""
    return re.sub(r"[^a-z]", "", sem_acento(texto.lower()))


def _classificar_rotulo(candidato: str) -> str | None:
    achatado = _achatar_rotulo(candidato)
    if len(achatado) < 4:
        return None
    melhor_papel, melhor_nota = None, 0.0
    for papel, referencias in ROTULOS_DE_REFERENCIA.items():
        for referencia in referencias:
            nota = SequenceMatcher(None, achatado, referencia).ratio()
            if nota > melhor_nota:
                melhor_papel, melhor_nota = papel, nota
    return melhor_papel if melhor_nota >= SIMILARIDADE_MINIMA else None


def _identificar_rotulo(linha: str) -> tuple[str | None, str]:
    """
    Devolve (papel, valor) de uma linha do docx de assunto.

    A ordem das tentativas importa. Os dois-pontos vêm primeiro porque o hífen
    também faz parte do próprio rótulo — cortar "Pré-header: X" no hífen daria
    "Pré" como candidato, que é curto demais para reconhecer.
    """
    linha = linha.strip()
    if not linha:
        return None, ""

    # a linha inteira é o rótulo; o valor vem na linha de baixo
    papel = _classificar_rotulo(linha)
    if papel and len(linha.split()) <= 3:
        return papel, ""

    for separador in (r":", r"[-–—]"):
        achado = re.match(rf"^([^\n]{{2,28}}?)\s*{separador}\s*(.+)$", linha)
        if achado:
            papel = _classificar_rotulo(achado.group(1))
            if papel:
                return papel, achado.group(2).strip()

    # sem separador nenhum: "Assunto Seu crédito está liberado"
    palavras = linha.split()
    for quantidade in (2, 1):
        if len(palavras) > quantidade:
            candidato = " ".join(palavras[:quantidade])
            # o candidato não pode ser bem maior que o rótulo que representa,
            # senão "Pré-header: Simule" casaria e comeria a primeira palavra
            if len(_achatar_rotulo(candidato)) <= 14:
                papel = _classificar_rotulo(candidato)
                if papel:
                    return papel, " ".join(palavras[quantidade:]).strip()
    return None, linha


def _separar_assunto(paragrafos: list[str]) -> tuple[str, str]:
    """Separa assunto e pré-header, aceitando tanto 'Assunto: x' quanto linhas soltas."""
    assunto, pre_header = "", ""
    pendente = None

    for linha in paragrafos:
        papel, valor = _identificar_rotulo(linha)
        if papel:
            if valor:
                # rótulo e valor na mesma linha
                if papel == "assunto" and not assunto:
                    assunto = valor
                elif papel == "pre_header" and not pre_header:
                    pre_header = valor
                pendente = None
            else:
                # rótulo sozinho: o valor vem na linha de baixo
                pendente = papel
            continue
        if pendente == "assunto" and not assunto:
            assunto, pendente = linha, None
        elif pendente == "pre_header" and not pre_header:
            pre_header, pendente = linha, None

    # Sem rótulo nenhum, vale a ordem em que costumam ser escritos.
    restantes = [l for l in paragrafos if not _identificar_rotulo(l)[0]]
    if not assunto and restantes:
        assunto = restantes[0]
    if not pre_header and len(restantes) > 1:
        pre_header = restantes[1]
    return assunto, pre_header


def localizar_docx(pasta: str) -> list[str]:
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower().endswith(".docx") and not arquivo.startswith("~$"):
                encontrados.append(os.path.join(raiz, arquivo))
    return sorted(encontrados)
''',
    # ---- validador/html_parser.py -------------------------------------------------
    "html_parser": r'''"""
Leitura do HTML da peça.

A ideia central do sistema está aqui: percorrer o DOM na ordem do código e montar
uma "fita" única de leitura, intercalando o texto vivo com o texto das imagens na
posição exata em que cada imagem aparece. Essa fita é a ordem que o leitor de tela
entrega ao cliente — e é contra ela que o CONTEUDO.docx precisa bater.
"""

import os
import re
from dataclasses import dataclass, field
from urllib.parse import unquote, urlparse

from bs4 import (BeautifulSoup, CData, Comment, Declaration, Doctype,
                 NavigableString, ProcessingInstruction, Tag)

# nós que o parser entrega como texto mas não são conteúdo lido pelo cliente
NAO_E_TEXTO = (Comment, Doctype, Declaration, CData, ProcessingInstruction)

from . import excecoes, regras
from .normalizacao import limpar

TAGS_IGNORADAS = {"script", "style", "head", "meta", "title", "link", "noscript"}

# formatos que valem a pena tentar ler
EXTENSOES_IMAGEM = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}

RE_URL_CSS = re.compile(r"url\(\s*['\"]?(.*?)['\"]?\s*\)", re.IGNORECASE)

# Pixel de rastreio: não é peça, é medição. Entra no HTML da versão publicada
# (abertura, remarketing, parceiro de mídia) e não tem nada a conferir — nem
# nome de taxonomia, nem texto, nem arquivo na pasta.
RE_PIXEL_DE_RASTREIO = re.compile(
    r"open\.aspx|1x1|beacon|pixel|impression|usermatch|/track|utm_|\.aspx\b",
    re.IGNORECASE,
)


def _e_pixel_de_rastreio(url: str, elemento) -> bool:
    if RE_PIXEL_DE_RASTREIO.search(url or ""):
        return True
    # imagem declarada com 1 pixel também é medição
    try:
        largura = int(str(elemento.get("width", "")).strip() or 0)
        altura = int(str(elemento.get("height", "")).strip() or 0)
    except ValueError:
        return False
    return 0 < largura <= 2 and 0 < altura <= 2
# Elementos que separam um parágrafo do outro. Texto dentro de <b>, <span>,
# <a> e afins continua sendo a MESMA frase e precisa ser lido junto.
# Chamada de nota: no HTML vem em <sup>, e o Word entrega o sobrescrito colado
# na palavra. Colar dos dois lados é o que faz "CDB<sup>2</sup>" bater com o
# "CDB2" do docx em vez de virar divergência em toda peça com nota de rodapé.
TAGS_COLADAS = {"sup", "sub"}

TAGS_DE_BLOCO = {
    "p", "div", "td", "th", "tr", "table", "li", "ul", "ol",
    "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "body",
}

# <br> quebra a linha, mas NÃO encerra o parágrafo.
#
# Disclaimer real vem num <td> só, com <br> a cada linha visual. Tratando cada
# <br> como bloco novo, o disclaimer virava 45 pedaços soltos: nenhum deles
# casava com os padrões de disclaimer, e a regra do hyperlink deixava de rodar
# justamente onde ela existe para rodar.
TAGS_DE_QUEBRA = {"br"}

# Espaço duplicado entre palavras na MESMA linha, e espaço solto antes de
# pontuação. Precisa ser na mesma linha: quebra de linha seguida de indentação
# é como o HTML é escrito, não sobra de digitação.
RE_ESPACO_DUPLO = re.compile(r"\S[^\S\n\r]{2,}\S")
RE_ESPACO_ANTES_PONTUACAO = re.compile(r"\S[^\S\n\r]+[,.;:!?](?:\s|$)")

RE_OCULTO = re.compile(
    r"display\s*:\s*none|visibility\s*:\s*hidden|max-height\s*:\s*0|font-size\s*:\s*0",
    re.IGNORECASE,
)


@dataclass
class BlocoFita:
    """Um pedaço da leitura da peça, na ordem em que aparece."""
    tipo: str                 # "texto" | "imagem"
    conteudo: str = ""        # texto vivo, ou texto lido da imagem
    referencia: str = ""      # nome do arquivo, quando for imagem
    alt: str = ""
    origem: str = ""          # "src", "background", "style", "srcset"
    oculto: bool = False
    bruto: str = ""       # texto sem limpeza: preserva os invisíveis anti-link
    tem_link: bool = False
    textos_de_link: list = field(default_factory=list)
    remota: bool = False  # imagem servida por URL, não pelo pacote
    ocr_lido: bool = False
    ocr_confianca: float = 0.0
    ocr_erro: str = ""
    ocr_aviso: str = ""
    reordenado: bool = False
    classificacao: str = ""   # "dispensavel" | "obrigatorio:<rótulo>" | ""


@dataclass
class LeituraHTML:
    caminho: str
    fita: list[BlocoFita] = field(default_factory=list)
    imagens_referenciadas: list[str] = field(default_factory=list)  # com repetição
    imagens_remotas: list[str] = field(default_factory=list)
    pixels_de_rastreio: list[str] = field(default_factory=list)
    texto_oculto: list[str] = field(default_factory=list)
    alts_vazios: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    redirects: int = 0
    pagina_de_email: bool = False
    ruido_de_cliente: list[str] = field(default_factory=list)
    espacos_irregulares: list[str] = field(default_factory=list)

    @property
    def imagens_unicas(self) -> list[str]:
        vistos, saida = set(), []
        for nome in self.imagens_referenciadas:
            chave = nome.lower()
            if chave not in vistos:
                vistos.add(chave)
                saida.append(nome)
        return saida

    def texto_completo(self) -> str:
        return "\n".join(b.conteudo for b in self.fita if b.conteudo and not b.oculto)


# Marcas de página salva de cliente de e-mail. Quem recebe a peça por e-mail e
# usa "salvar como" leva junto a interface inteira do Gmail ou do Outlook — e
# o que interessa, a peça, fica enterrado no meio.
MARCAS_DE_CLIENTE = [
    r'class="[^"]*\ba3s\b',          # corpo da mensagem no Gmail
    r"gmail_quote|gmail_attr",
    r"cb=gapi\.loaded|cleardot\.gif",
    r"In[íi]cio da mensagem encaminhada",
    r'class="[^"]*\bWordSection1\b',   # Outlook
]

RE_MARCAS_DE_CLIENTE = [re.compile(p, re.IGNORECASE) for p in MARCAS_DE_CLIENTE]


# Sobras da interface e do encaminhamento. Vêm junto no "salvar como" e não
# fazem parte da peça: cabeçalho de quem encaminhou, assinatura do celular e
# os botões que o próprio Gmail desenha sobre as imagens.
# Estes não existem em peça nenhuma: são controle do webmail ou cabeçalho de
# encaminhamento. Saem sempre, mesmo quando a página não foi reconhecida como
# salva do Gmail — o corpo extraído continua trazendo esses botões junto.
RUIDO_SEMPRE = [
    r"^fazer o download$",
    r"^enviado do meu\b",
    r"^in[íi]cio da mensagem encaminhada",
    r"^mensagem encaminhada$",
    r"^(de|para|data|cc|cco|enviada em)\s*:",
]

# Estes são ambíguos. "Baixar" pode ser o botão do Gmail ou o CTA da peça
# ("Baixe o app"), então só saem quando o arquivo é reconhecidamente uma
# página salva de webmail.
RUIDO_SO_EM_WEBMAIL = [
    r"^baixar$|^salvar no drive$|^adicionar ao drive$",
    r"^\d+ anexos?$",
    r"^assunto\s*:",
]

RE_RUIDO_SEMPRE = [re.compile(p, re.IGNORECASE) for p in RUIDO_SEMPRE]
RE_RUIDO_SO_EM_WEBMAIL = [re.compile(p, re.IGNORECASE) for p in RUIDO_SO_EM_WEBMAIL]


def e_ruido_de_cliente(texto: str, webmail: bool = False) -> bool:
    limpo = (texto or "").strip()
    if not limpo:
        return False
    padroes = list(RE_RUIDO_SEMPRE)
    if webmail:
        padroes += RE_RUIDO_SO_EM_WEBMAIL
    for linha in limpo.splitlines():
        if any(p.search(linha.strip()) for p in padroes):
            return True
    return False


def parece_pagina_de_email(codigo: str) -> bool:
    """Diz se o arquivo é a tela do webmail em vez do código da peça."""
    encontradas = sum(1 for p in RE_MARCAS_DE_CLIENTE if p.search(codigo or ""))
    return encontradas >= 2


def isolar_corpo_da_mensagem(soup):
    """
    Recorta só o corpo da mensagem dentro da página do webmail.

    Sem isso, o validador leria menu, barra lateral e assinatura do Gmail como
    se fossem parte da peça. Pega o maior bloco de corpo: numa conversa com
    resposta ou encaminhamento existe mais de um, e a peça é o mais longo.
    """
    candidatos = soup.select('div[class*="a3s"], div.WordSection1, div[class*="ii gt"]')
    if not candidatos:
        return None
    return max(candidatos, key=lambda e: len(e.get_text()))


def _e_remota(url: str) -> bool:
    """
    Diz se a imagem é servida por URL em vez de vir no pacote.

    Peça já hospedada — o link de teste que o time abre no navegador — aponta
    para o servidor, não para a pasta. Cobrar esses arquivos na pasta encheria
    o relatório de "chamada sem arquivo" para a peça inteira.
    """
    return bool(url) and url.strip().lower().startswith(("http://", "https://", "//"))


def _nome_arquivo_da_url(url: str) -> str:
    """Extrai só o nome do arquivo de um src, ignorando querystring e caminho."""
    if not url:
        return ""
    url = url.strip()
    if url.startswith("data:"):
        return ""
    caminho = urlparse(url).path or url
    nome = os.path.basename(unquote(caminho))
    return nome.strip()


def _esta_oculto(no: Tag) -> bool:
    atual = no
    while isinstance(atual, Tag):
        estilo = atual.get("style") or ""
        if RE_OCULTO.search(estilo):
            return True
        if atual.get("hidden") is not None:
            return True
        atual = atual.parent
    return False


def _urls_de_imagem(no: Tag) -> list[tuple[str, str]]:
    """Devolve [(url, origem)] de um elemento — cobre src, background e CSS inline."""
    achados = []
    if no.name == "img":
        src = no.get("src") or no.get("data-src") or ""
        if src:
            achados.append((src, "src"))
        srcset = no.get("srcset") or ""
        for parte in srcset.split(","):
            url = parte.strip().split(" ")[0]
            if url:
                achados.append((url, "srcset"))
    # e-mail usa muito background em <td> e <table>
    bg = no.get("background")
    if bg:
        achados.append((bg, "background"))
    estilo = no.get("style") or ""
    for url in RE_URL_CSS.findall(estilo):
        achados.append((url, "style"))
    # fallback do Outlook (VML)
    if no.name and no.name.lower().endswith("image"):
        src = no.get("src")
        if src:
            achados.append((src, "vml"))
    return achados


def ler_html(caminho_html: str, pasta_imagens: str | None = None,
             cache_ocr=None, incluir_ocultos: bool = False) -> LeituraHTML:
    """
    Monta a fita de leitura.

    pasta_imagens: onde procurar o arquivo físico para rodar o OCR.
    cache_ocr:     instância de CacheOCR; se None, as imagens entram sem texto.
    """
    leitura = LeituraHTML(caminho=caminho_html)

    try:
        with open(caminho_html, "rb") as f:
            bruto = f.read()
        texto_html = bruto.decode("utf-8", errors="replace")
    except OSError as e:
        leitura.erros.append(f"não foi possível abrir o HTML: {e}")
        return leitura

    # A contagem roda no código bruto, antes de qualquer limpeza: o redirect
    # aparece tanto em href quanto dentro de AMPScript ou atributo de rastreio.
    leitura.redirects = regras.contar_redirects(texto_html)

    soup = BeautifulSoup(texto_html, "html.parser")

    # arquivo salvo do webmail: trabalha só com o corpo da mensagem
    if parece_pagina_de_email(texto_html):
        leitura.pagina_de_email = True
        corpo = isolar_corpo_da_mensagem(soup)
        if corpo is not None:
            soup = corpo

    for comentario in soup.find_all(string=lambda s: isinstance(s, Comment)):
        comentario.extract()

    base = pasta_imagens or os.path.dirname(os.path.abspath(caminho_html))
    ja_registrado: set[int] = set()

    # Acumulador de texto do parágrafo em curso.
    #
    # Sem isto, "<b>nova taxa</b>, confira" vira três nós separados e a vírgula
    # fica sozinha num deles — como pontuação solta não forma palavra, ela some
    # da leitura e o sistema acusa vírgula divergente contra o docx, que tem a
    # frase inteira. Negrito, link e span são formatação, não fim de frase.
    acumulado: list[tuple[str, bool]] = []   # (texto, cola na palavra anterior)
    acumulado_bruto: list[str] = []
    acumulado_oculto = False
    acumulado_com_link = False
    acumulado_links: list[str] = []

    def _e_chamada_de_nota(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name in TAGS_COLADAS:
                return True
            if atual.name in TAGS_DE_BLOCO:
                return False
            atual = atual.parent
        return False

    def _dentro_de_link(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name == "a" and atual.get("href"):
                return True
            if atual.name in TAGS_DE_BLOCO:
                return False
            atual = atual.parent
        return False

    def _ancestral_de_bloco(no_texto):
        atual = no_texto.parent
        while isinstance(atual, Tag):
            if atual.name in TAGS_DE_BLOCO:
                return id(atual)
            atual = atual.parent
        return None

    def fechar_paragrafo():
        """Fecha o parágrafo acumulado e o coloca na fita."""
        nonlocal acumulado, acumulado_oculto, acumulado_bruto, acumulado_com_link
        nonlocal acumulado_links
        if not acumulado:
            return
        texto = ""
        for pedaco, colado in acumulado:
            if not texto:
                texto = pedaco
            elif pedaco == "\n" or texto.endswith("\n"):
                texto = texto.rstrip(" ") + pedaco if pedaco == "\n" else texto + pedaco
            elif colado or pedaco[0] in ".,;:!?)]}%" or texto[-1] in "([{":
                texto += pedaco          # nota de rodapé e pontuação colam
            else:
                texto += " " + pedaco
        texto = limpar(texto)
        # cabeçalho de encaminhamento e botão do webmail não são peça
        if texto and e_ruido_de_cliente(texto, leitura.pagina_de_email):
            leitura.ruido_de_cliente.append(texto[:90])
            texto = ""
        if texto:
            if acumulado_oculto:
                leitura.texto_oculto.append(texto)
            if not acumulado_oculto or incluir_ocultos:
                leitura.fita.append(BlocoFita(
                    tipo="texto", conteudo=texto, oculto=acumulado_oculto,
                    classificacao=excecoes.classificar(texto),
                    bruto="".join(acumulado_bruto),
                    tem_link=acumulado_com_link,
                    textos_de_link=list(acumulado_links),
                ))
        acumulado = []
        acumulado_bruto = []
        acumulado_oculto = False
        acumulado_com_link = False
        acumulado_links = []
    acumulado_links: list[str] = []

    bloco_corrente = None

    for no in soup.descendants:
        # --- texto vivo ---
        if isinstance(no, NavigableString):
            if isinstance(no, NAO_E_TEXTO):
                continue
            if no.parent and no.parent.name in TAGS_IGNORADAS:
                continue
            bruto = str(no)
            conteudo = limpar(bruto)
            if not conteudo:
                continue
            _registrar_espacos(leitura, bruto)
            oculto = _esta_oculto(no.parent) if no.parent else False
            ancestral = _ancestral_de_bloco(no)
            if (bloco_corrente is not None and ancestral != bloco_corrente) or \
                    (acumulado and oculto != acumulado_oculto):
                fechar_paragrafo()
            bloco_corrente = ancestral
            acumulado_oculto = oculto
            acumulado.append((conteudo, _e_chamada_de_nota(no)))
            # o bruto guarda os invisíveis (&#xFEFF;) que impedem o cliente de
            # e-mail de criar link sozinho — limpar() os remove
            acumulado_bruto.append(str(no))
            if _dentro_de_link(no):
                acumulado_com_link = True
                acumulado_links.append(conteudo)
            continue

        if not isinstance(no, Tag) or no.name in TAGS_IGNORADAS:
            continue

        if no.name in TAGS_DE_QUEBRA:
            if acumulado:
                acumulado.append(("\n", True))
                acumulado_bruto.append("\n")
            continue

        # --- imagens ---
        urls = _urls_de_imagem(no)
        if not urls:
            continue

        # a imagem encerra o parágrafo em curso: o que vier depois dela é lido
        # depois pelo leitor de tela
        fechar_paragrafo()
        bloco_corrente = None
        if id(no) in ja_registrado:
            continue
        ja_registrado.add(id(no))

        vistas_no_elemento = set()
        for url, origem in urls:
            nome = _nome_arquivo_da_url(url)
            if not nome or nome.lower() in vistas_no_elemento:
                continue
            vistas_no_elemento.add(nome.lower())
            if _e_pixel_de_rastreio(url, no):
                leitura.pixels_de_rastreio.append(nome)
                continue
            remota = _e_remota(url)
            if remota:
                if nome not in leitura.imagens_remotas:
                    leitura.imagens_remotas.append(nome)
            else:
                leitura.imagens_referenciadas.append(nome)

            alt = limpar(no.get("alt") or "")
            if no.name == "img" and not alt:
                leitura.alts_vazios.append(nome)

            bloco = BlocoFita(
                tipo="imagem", referencia=nome, alt=alt, origem=origem,
                oculto=_esta_oculto(no), remota=remota,
            )

            extensao = os.path.splitext(nome)[1].lower()
            if cache_ocr is not None and extensao in EXTENSOES_IMAGEM:
                caminho_fisico = _localizar_arquivo(base, nome)
                if caminho_fisico:
                    resultado = cache_ocr.ler(caminho_fisico)
                    bloco.conteudo = resultado.texto
                    bloco.ocr_lido = resultado.lido
                    bloco.ocr_confianca = resultado.confianca_media
                    bloco.ocr_erro = resultado.erro
                    bloco.ocr_aviso = resultado.aviso
                else:
                    bloco.ocr_erro = "arquivo não encontrado na pasta de imagens"

            bloco.classificacao = excecoes.classificar(bloco.conteudo or bloco.alt)
            leitura.fita.append(bloco)

    fechar_paragrafo()
    return leitura


def _registrar_espacos(leitura: LeituraHTML, bruto: str) -> None:
    """
    Anota espaço duplicado ou espaço antes de pontuação no texto da peça.

    Não vira divergência: a comparação já ignora espaçamento, e isso não muda
    o que o leitor de tela entrega. Fica como observação porque é o tipo de
    detalhe que passa batido na revisão e aparece feio na caixa de entrada.
    """
    for linha in bruto.splitlines():
        if len(leitura.espacos_irregulares) >= 8:
            return
        trecho = linha.strip()
        if len(trecho) < 4:
            continue
        if RE_ESPACO_DUPLO.search(trecho) or RE_ESPACO_ANTES_PONTUACAO.search(trecho):
            amostra = re.sub(r"[^\S\n\r]{2,}", " ␣ ", trecho)[:90]
            if amostra not in leitura.espacos_irregulares:
                leitura.espacos_irregulares.append(amostra)


def _localizar_arquivo(pasta: str, nome: str) -> str | None:
    """Procura o arquivo na pasta ignorando maiúscula/minúscula e subpastas."""
    alvo = nome.lower()
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower() == alvo:
                return os.path.join(raiz, arquivo)
    return None
''',
    # ---- validador/pacote.py ------------------------------------------------------
    "pacote": r'''"""
Orquestração da conferência de um pacote.

Recebe a pasta que o analista de marketing enviou, descobre sozinho onde está o
HTML, os dois docx e as imagens, e roda as três verificações.
"""

import os
from dataclasses import dataclass, field

from . import (comparador, docx_parser, html_parser, imagens as mod_imagens,
               presenca, regras)
from .ocr import CacheOCR, aviso_de_idioma, ocr_disponivel

NOMES_PASTA_IMAGENS = ("imagens", "images", "img", "imgs", "assets", "peças", "pecas")


@dataclass
class ResultadoPacote:
    pasta: str
    quebra: str = ""
    caminho_html: str = ""
    caminho_conteudo: str = ""
    caminho_assunto: str = ""
    pasta_imagens: str = ""
    leitura_html: object = None
    leitura_conteudo: object = None
    leitura_assunto: object = None
    resultado_imagens: object = None
    resultado_texto: object = None
    apontamentos_assunto: list = field(default_factory=list)
    bloqueios: list[str] = field(default_factory=list)   # impedem a publicação
    alertas: list[str] = field(default_factory=list)     # o analista precisa saber
    avisos: list[str] = field(default_factory=list)
    erros: list[str] = field(default_factory=list)
    ocr_ativo: bool = False
    motivo_ocr: str = ""
    modo_texto: str = "sequencia"   # "sequencia" (com OCR) | "presenca" (sem OCR)
    nome_pasta: str = ""            # como o pacote chegou: briefing+CPI+ação

    @property
    def status(self) -> str:
        if self.erros:
            return "erro"
        if self.bloqueios:
            return "reprovado"
        problemas_imagem = self.resultado_imagens and not self.resultado_imagens.aprovado
        status_texto = self.resultado_texto.status if self.resultado_texto else "erro"
        if problemas_imagem or status_texto == "reprovado":
            return "reprovado"
        if status_texto in ("atencao", "parcial") or self.apontamentos_assunto:
            return "atencao"
        return "aprovado"


def _localizar_html(pasta: str) -> list[str]:
    """
    Varre o pacote inteiro atrás do HTML da peça.

    O arquivo pode estar na raiz ou dentro de uma pasta "html" — depende da
    agência. Entre vários, ganha o que tem mais cara de peça: index primeiro,
    depois o maior, porque HTML de e-mail é pesado e um arquivo pequeno
    costuma ser um fragmento ou um teste.
    """
    encontrados = []
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.startswith("~") or arquivo.startswith("."):
                continue
            if arquivo.lower().endswith((".html", ".htm")):
                encontrados.append(os.path.join(raiz, arquivo))
    encontrados.sort(
        key=lambda c: (
            0 if os.path.basename(c).lower().startswith("index") else 1,
            -os.path.getsize(c),
        )
    )
    return encontrados


EXTENSOES_IMAGEM = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")


def _localizar_pasta_imagens(pasta: str, caminho_html: str,
                             referenciadas: list[str] | None = None) -> str:
    """
    Descobre onde estão as imagens do pacote.

    A estrutura muda conforme a agência que desenvolveu: às vezes o HTML fica
    solto na raiz com uma pasta "imagens" ao lado, às vezes vem uma pasta
    "html" com o arquivo dentro e a pasta de imagens dentro dela. Em vez de
    apostar num layout, a busca vai do critério mais confiável para o mais
    genérico.
    """
    candidatas: dict[str, list[str]] = {}
    for raiz, _, arquivos in os.walk(pasta):
        imagens = [a for a in arquivos if a.lower().endswith(EXTENSOES_IMAGEM)]
        if imagens:
            candidatas[raiz] = imagens
    if not candidatas:
        return os.path.dirname(caminho_html) if caminho_html else pasta

    # 1. a pasta que mais cobre os arquivos que o HTML realmente chama.
    #    É o critério mais forte: liga o que está no disco ao que está no código.
    if referenciadas:
        alvo = {n.lower() for n in referenciadas}
        melhor, melhor_cobertura = None, 0
        for caminho, arquivos in candidatas.items():
            cobertura = len({a.lower() for a in arquivos} & alvo)
            if cobertura > melhor_cobertura:
                melhor, melhor_cobertura = caminho, cobertura
        if melhor and melhor_cobertura:
            return melhor

    # 2. pasta com nome conhecido
    for caminho in candidatas:
        if os.path.basename(caminho).lower() in NOMES_PASTA_IMAGENS:
            return caminho

    # 3. a que tem mais imagens
    return max(candidatas.items(), key=lambda item: len(item[1]))[0]


def validar(pasta: str, quebra: str | None = None, usar_ocr: bool = True,
            idioma_ocr: str = "por", ao_avancar=None) -> ResultadoPacote:
    resultado = ResultadoPacote(pasta=pasta)
    resultado.nome_pasta = os.path.basename(os.path.normpath(pasta))

    if not os.path.isdir(pasta):
        resultado.erros.append(f"pasta não encontrada: {pasta}")
        return resultado

    # --- localizar arquivos ---
    htmls = _localizar_html(pasta)
    if not htmls:
        resultado.erros.append("nenhum arquivo .html encontrado no pacote")
        return resultado
    resultado.caminho_html = htmls[0]
    if len(htmls) > 1:
        outros = ", ".join(os.path.basename(h) for h in htmls[1:])
        resultado.avisos.append(
            f"mais de um HTML no pacote; usando '{os.path.basename(htmls[0])}'. Outros: {outros}"
        )

    documentos = docx_parser.localizar_docx(pasta)
    if not documentos:
        # lista o que existe: quase sempre o motivo é .doc antigo, arquivo
        # ainda dentro de um zip, ou o pacote apontado um nível acima
        outros = []
        for raiz, _, arquivos in os.walk(pasta):
            for arquivo in arquivos:
                if arquivo.lower().endswith((".doc", ".zip", ".rar", ".7z", ".pdf")):
                    outros.append(arquivo)
        pista = ""
        if outros:
            pista = (" Encontrei no pacote: " + ", ".join(sorted(set(outros))[:6])
                     + ". Arquivos .doc antigos precisam ser salvos como .docx, "
                     "e compactados precisam ser extraídos antes.")
        resultado.erros.append(
            "Nenhum arquivo .docx encontrado neste pacote." + pista
        )
        return resultado

    conteudo, assunto = docx_parser.identificar_papeis(documentos)
    resultado.leitura_conteudo = conteudo
    resultado.leitura_assunto = assunto
    resultado.caminho_conteudo = conteudo.caminho if conteudo else ""
    resultado.caminho_assunto = assunto.caminho if assunto else ""

    if not resultado.leitura_conteudo:
        nomes = ", ".join(os.path.basename(d) for d in documentos)
        resultado.erros.append(
            "Encontrei .docx no pacote, mas nenhum com corpo de texto para comparar "
            f"com o HTML. Arquivos vistos: {nomes}."
        )
        return resultado
    if not resultado.leitura_assunto:
        resultado.avisos.append(
            "Não identifiquei um docx de assunto/pré-header. As regras de "
            "publicação que dependem dele não foram conferidas."
        )

    # --- OCR ---
    cache = None
    if usar_ocr:
        disponivel, motivo = ocr_disponivel()
        resultado.ocr_ativo = disponivel
        resultado.motivo_ocr = motivo
        if disponivel:
            cache = CacheOCR(idioma=idioma_ocr)
            if cache.aviso_idioma:
                resultado.avisos.append(cache.aviso_idioma)
            sem_portugues = aviso_de_idioma()
            if sem_portugues:
                resultado.avisos.append(sem_portugues)
        else:
            resultado.avisos.append(
                f"OCR indisponível ({motivo}). O texto dentro das imagens não foi "
                "conferido; as demais verificações rodaram normalmente."
            )
    else:
        resultado.motivo_ocr = "desativado por parâmetro"

    # --- leitura do HTML e montagem da fita ---
    # Primeira passada sem OCR só para descobrir quais arquivos o código chama;
    # com essa lista dá para achar a pasta de imagens certa mesmo em estrutura
    # que não conhecemos.
    referencias = html_parser.ler_html(resultado.caminho_html, pasta).imagens_referenciadas
    resultado.pasta_imagens = _localizar_pasta_imagens(
        pasta, resultado.caminho_html, referencias
    )

    # Lê as imagens em paralelo ANTES de montar a fita. O percurso do DOM é
    # sequencial por natureza — precisa respeitar a ordem de leitura — mas a
    # leitura em si não: adiantar tudo aqui encurta a espera sem mudar o
    # resultado, porque o percurso depois só consulta o que já está pronto.
    if cache is not None:
        caminhos = []
        for nome in dict.fromkeys(referencias):
            achado = html_parser._localizar_arquivo(resultado.pasta_imagens, nome)
            if achado:
                caminhos.append(achado)
        cache.pre_carregar(caminhos, ao_avancar=ao_avancar)

    resultado.leitura_html = html_parser.ler_html(
        resultado.caminho_html, resultado.pasta_imagens, cache_ocr=cache
    )
    resultado.erros.extend(resultado.leitura_html.erros)
    if resultado.erros:
        return resultado

    remotas = getattr(resultado.leitura_html, "imagens_remotas", [])
    if remotas:
        resultado.avisos.append(
            f"{len(remotas)} imagem(ns) chamada(s) por URL, não pelo pacote — "
            "é o caso da peça já hospedada. Elas não entram na conferência de "
            "pasta nem têm o texto lido: " + ", ".join(remotas[:5])
        )

    # --- verificação 1: imagens ---
    resultado.resultado_imagens = mod_imagens.verificar(
        resultado.pasta_imagens,
        resultado.leitura_html.imagens_referenciadas,
        quebra=quebra,
    )
    resultado.quebra = resultado.resultado_imagens.quebra

    # --- verificação 2 e 3: texto ---
    # Com OCR, a fita está completa e vale comparar sequência. Sem OCR, o texto
    # das imagens falta na fita mas sobra no docx: comparar sequência aí inventa
    # divergência. Nesse caso só perguntamos se o texto vivo consta no docx.
    imagens_sem_leitura = any(
        b.tipo == "imagem" and not b.ocr_lido and not b.oculto
        for b in resultado.leitura_html.fita
    )
    resultado.modo_texto = "presenca" if imagens_sem_leitura else "sequencia"
    if imagens_sem_leitura:
        resultado.resultado_texto = presenca.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )
    else:
        resultado.resultado_texto = comparador.comparar(
            resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos
        )

    # --- verificação 4: pré-header ---
    if resultado.leitura_assunto:
        resultado.apontamentos_assunto = comparador.comparar_assunto(
            resultado.leitura_assunto, resultado.leitura_html
        )

    # --- verificação 5: regras de publicação ---
    _aplicar_regras(resultado)

    return resultado


def _conferir_disclaimer(resultado: ResultadoPacote) -> None:
    """
    Endereço no disclaimer precisa vir com o código que impede o link.

    O cliente de e-mail transforma sozinho qualquer coisa com cara de endereço
    em link clicável. No disclaimer isso não pode acontecer, então a peça
    separa os caracteres com um invisível (&#xFEFF;) no ponto onde o cliente
    procuraria o padrão de domínio. Sem esse código, o link é gerado.
    """
    if not resultado.leitura_html:
        return

    for bloco in resultado.leitura_html.fita:
        if not bloco.classificacao.startswith("obrigatorio:disclaimer"):
            continue

        # Link com texto de frase — "Saiba mais", "Cancele aqui", "Fale
        # Conosco" — é intencional e existe em quase todo disclaimer. O que a
        # regra proíbe é o ENDEREÇO virar link: é isso que precisa da proteção.
        for texto_do_link in bloco.textos_de_link:
            if regras.enderecos_sem_protecao(texto_do_link):
                resultado.bloqueios.append(
                    "Endereço dentro de um link clicável no disclaimer: "
                    f"\u201c{texto_do_link.strip()[:90]}\u201d"
                )

        desprotegidos = regras.enderecos_sem_protecao(bloco.bruto)
        for endereco in desprotegidos:
            resultado.bloqueios.append(
                f"Endereço sem o código que impede o hyperlink no disclaimer: "
                f"\u201c{endereco}\u201d. Separe os caracteres com &#xFEFF; "
                "como nas demais peças."
            )


def _conferir_links_no_docx(resultado: ResultadoPacote) -> None:
    """
    O CONTEUDO.docx não pode ter hyperlink.

    Ele é a transcrição do que a peça mostra, e vai para o cadastro como texto.
    Link ali veio de cópia com formatação, e o endereço costuma viajar junto
    para o Content Builder.
    """
    leitura = resultado.leitura_conteudo
    if not leitura or not getattr(leitura, "links", None):
        return

    for visivel, endereco in leitura.links[:5]:
        rotulo = f"\u201c{visivel}\u201d \u2192 {endereco}" if visivel else endereco
        resultado.bloqueios.append(
            f"Há hyperlink no CONTEUDO.docx: {rotulo[:120]}. "
            "O documento deve conter só o texto da peça."
        )


def _conferir_datas(resultado: ResultadoPacote) -> None:
    """
    Aponta datas já passadas na peça.

    Peça reaproveitada de mês anterior costuma trazer a data antiga junto, e o
    disclaimer é onde isso mais escapa. Fica como aviso: às vezes a data
    passada é proposital — início de vigência, data de contrato — e quem
    decide isso é o analista.
    """
    if not resultado.leitura_html:
        return

    achadas: dict[str, str] = {}
    for bloco in resultado.leitura_html.fita:
        for data in regras.datas_vencidas(bloco.conteudo):
            if data in achadas:
                continue
            onde = bloco.referencia if bloco.tipo == "imagem" else "texto do HTML"
            achadas[data] = onde

    if resultado.leitura_conteudo:
        for paragrafo in resultado.leitura_conteudo.paragrafos:
            for data in regras.datas_vencidas(paragrafo):
                achadas.setdefault(data, "CONTEUDO.docx")

    for data, onde in list(achadas.items())[:6]:
        resultado.alertas.append(f"Data vencida: {data} (em {onde}) — verificar.")


def _aplicar_regras(resultado: ResultadoPacote) -> None:
    """
    Regras do banco, separadas do restante da conferência.

    O que impede a publicação vira bloqueio e reprova o pacote. O que só merece
    atenção vira alerta e não muda o veredito — assunto longo não é erro, é
    informação para o analista decidir.
    """
    # Redirect: sem nenhum no código, a peça não sobe.
    if resultado.leitura_html and resultado.leitura_html.redirects == 0:
        resultado.bloqueios.append(
            "Nenhum redirect encontrado no HTML. A publicação exige pelo menos um."
        )

    _conferir_disclaimer(resultado)
    _conferir_links_no_docx(resultado)
    _conferir_datas(resultado)

    leitura = resultado.leitura_assunto
    if not leitura:
        return

    # Pré-header sem ponto final não passa na publicação.
    if leitura.pre_header:
        if not regras.pre_header_tem_ponto_final(leitura.pre_header):
            resultado.bloqueios.append(
                "O pré-header não termina em ponto final: "
                f"\u201c{leitura.pre_header}\u201d"
            )
        excedente = regras.excedeu(leitura.pre_header, regras.LIMITE_PRE_HEADER)
        if excedente:
            resultado.alertas.append(
                f"Pré-header com {len(leitura.pre_header.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_PRE_HEADER} de referência."
            )

    if leitura.assunto:
        excedente = regras.excedeu(leitura.assunto, regras.LIMITE_ASSUNTO)
        if excedente:
            resultado.alertas.append(
                f"Assunto com {len(leitura.assunto.strip())} caracteres, "
                f"{excedente} acima dos {regras.LIMITE_ASSUNTO} de referência."
            )


def _tem_direto(pasta: str, extensoes: tuple) -> bool:
    """Arquivo com essa extensão solto na própria pasta, sem descer níveis."""
    try:
        return any(
            item.lower().endswith(extensoes)
            and not item.startswith(("~", "."))
            and os.path.isfile(os.path.join(pasta, item))
            for item in os.listdir(pasta)
        )
    except OSError:
        return False


def _tem_em_algum_lugar(pasta: str, extensoes: tuple) -> bool:
    for _, _, arquivos in os.walk(pasta):
        if any(a.lower().endswith(extensoes) and not a.startswith(("~", "."))
               for a in arquivos):
            return True
    return False


def _e_pacote(pasta: str) -> bool:
    """
    Um pacote tem HTML e docx dentro dele, em qualquer nível.

    Exigir os dois é o que separa o pacote de verdade de uma subpasta "html".
    A pasta html tem o arquivo da peça, mas os docx ficam um nível acima — se
    o critério fosse só "tem HTML", ela seria confundida com um pacote e a
    conferência rodaria sem o texto para comparar.
    """
    return (_tem_em_algum_lugar(pasta, (".html", ".htm"))
            and _tem_em_algum_lugar(pasta, (".docx",)))


def localizar_pacotes(raiz: str) -> list[str]:
    """
    Descobre se o que foi arrastado é UM pacote ou uma caixa com vários.

    Não dá para exigir que a pessoa escolha o modo certo antes de arrastar: ela
    tem a pasta na mão, não a estrutura na cabeça. E a estrutura varia com a
    agência que desenvolveu — o HTML tanto vem solto na raiz quanto dentro de
    uma pasta "html", com as imagens ao lado dele.
    """
    if not os.path.isdir(raiz):
        return []

    # Arquivo de pacote solto na raiz significa que a raiz é o próprio pacote:
    # os docx ficam ali e o HTML pode estar numa subpasta.
    if _tem_direto(raiz, (".html", ".htm", ".docx")):
        return [raiz]

    filhos = []
    try:
        itens = sorted(os.listdir(raiz))
    except OSError:
        return []
    for item in itens:
        caminho = os.path.join(raiz, item)
        if os.path.isdir(caminho) and _e_pacote(caminho):
            filhos.append(caminho)

    if filhos:
        return filhos
    if _e_pacote(raiz) or _tem_em_algum_lugar(raiz, (".html", ".htm")):
        return [raiz]
    return []


def validar_lote(pasta_raiz: str, **kwargs) -> list[ResultadoPacote]:
    """Confere cada pacote encontrado dentro da pasta."""
    return [validar(caminho, **kwargs) for caminho in localizar_pacotes(pasta_raiz)]
''',
    # ---- validador/serializacao.py ------------------------------------------------
    "serializacao": r'''"""
Converte o resultado da conferência em JSON, para a interface web desenhar.
"""

import os

from . import regras


# Rótulos descritivos de propósito. A ferramenta reporta o que está diferente
# entre os dois arquivos; ela não diz qual dos dois está certo nem o que a peça
# deveria conter. Essa decisão é de quem produziu a campanha.
ROTULOS = {
    "faltando": "Está no HTML, não está no CONTEUDO",
    "trocado": "Escrito de forma diferente nos dois",
    "sobrando": "Está no CONTEUDO, não está no HTML",
    "fora_de_ordem": "Mesmas palavras, ordem diferente",
    "acento_pontuacao": "Acento ou pontuação diferente",
    "espacamento": "Mesmo texto, espaçamento diferente",
}

# Nome do bloco onde a divergência caiu — é localização, não julgamento de
# conteúdo: ajuda quem lê o report a achar o trecho na peça.
BLOCOS = {
    "disclaimer": "no bloco de disclaimer",
    "opt-out": "no bloco de descadastro",
    "atendimento": "no bloco de atendimento",
}


def _descricao_do_motor() -> str:
    """
    Qual motor leu as imagens nesta conferência.

    Vai junto no resultado porque cada motor escreve diferente: um devolve
    "você" com acento, outro "voce". Comparar um docx gerado num motor contra
    uma peça lida noutro acusa divergência em cada acento, e sem essa
    informação na tela não há como desconfiar disso.
    """
    from .ocr import motor_ativo

    motor = motor_ativo()
    return motor.descricao if motor else ""


def _divergencia(d) -> dict:
    rotulo = ROTULOS.get(d.tipo, d.tipo)
    return {
        "tipo": d.tipo,
        "rotulo": rotulo,
        "gravidade": d.gravidade,
        "bloco": BLOCOS.get(d.obrigatorio, ""),
        "tolerado": getattr(d, "tolerado", False),
        "obrigatorio": d.obrigatorio,
        "citacao_html": getattr(d, "citacao_html", ""),
        "citacao_docx": getattr(d, "citacao_docx", ""),
        "origem": d.origem,
        "trecho_html": d.trecho_html,
        "trecho_docx": d.trecho_docx,
        "contexto_antes": d.contexto_antes,
        "palavras_ausentes": (d.contexto_antes.replace("palavras ausentes: ", "")
                              if d.contexto_antes.startswith("palavras ausentes:") else ""),
        "contexto_depois": d.contexto_depois,
    }


def _imagens(ri) -> list[dict]:
    if not ri:
        return []
    itens = []
    add = lambda g, r, t: itens.append({"gravidade": g, "rotulo": r, "texto": t})

    for nome, motivo in ri.fora_da_taxonomia:
        add("alta", "Nome fora do padrão da quebra", f"{nome} — {motivo}")
    if ri.numeros_faltando:
        add("alta", "Numeração com furo",
            "faltam os números " + ", ".join(f"{n:02d}" for n in ri.numeros_faltando))
    if ri.nao_comeca_em_um:
        add("media", "Não começa em 01", "o primeiro número da pasta não é 01")
    if ri.numeros_duplicados:
        add("alta", "Número repetido",
            "o número " + ", ".join(f"{n:02d}" for n in ri.numeros_duplicados)
            + " aparece em mais de um arquivo")
    for nome in ri.extensao_invalida:
        add("media", "Extensão fora do padrão", nome)
    for nome in ri.no_html_fora_da_pasta:
        add("alta", "Chamada no HTML sem arquivo na pasta",
            f"o HTML chama {nome}, que não está na pasta de imagens")
    for nome in ri.na_pasta_fora_do_html:
        add("alta", "Arquivo na pasta sem chamada no HTML",
            f"{nome} está na pasta, mas não aparece no código")
    for na_pasta, no_html in ri.divergencia_de_caixa:
        add("alta", "Maiúscula/minúscula diferente", f"pasta: {na_pasta} · HTML: {no_html}")
    for nome, kb in ri.acima_do_peso:
        add("alta", "Acima de 1 MB",
            f"{nome} tem {kb / 1024:.1f} MB — o limite para publicação é 1 MB")
    for nome in ri.sem_numeracao_zero_a_esquerda:
        add("baixa", "Sem zero à esquerda", f"{nome} — o padrão é 01, 02, 03")
    return itens


def para_json(r, id_relatorio: str = "") -> dict:
    ri, rt = r.resultado_imagens, r.resultado_texto

    observacoes = list(r.avisos)
    for a in r.apontamentos_assunto:
        observacoes.append(f"Pré-header do docx não localizado no HTML: {a.trecho_docx}")
    # Leitura de imagem com confiança baixa: o texto entrou na comparação, mas
    # pode ter caractere errado. Melhor dizer onde a máquina teve dúvida do que
    # deixar passar como se fosse certeza.
    if r.leitura_html:
        incertas = []
        # falha técnica na leitura vem primeiro: é defeito a corrigir, não
        # dúvida sobre o conteúdo da peça
        falhas = []
        for bloco in r.leitura_html.fita:
            if bloco.tipo != "imagem":
                continue
            if getattr(bloco, "ocr_erro", ""):
                marca = f"{bloco.referencia}: {bloco.ocr_erro}"
                if marca not in falhas:
                    falhas.append(marca)
                continue
            if getattr(bloco, "ocr_aviso", ""):
                if "incerta" in bloco.ocr_aviso or "nenhum texto" in bloco.ocr_aviso:
                    marca = f"{bloco.referencia} ({bloco.ocr_aviso})"
                    if marca not in incertas:
                        incertas.append(marca)
        if falhas:
            observacoes.append(
                "Falha ao ler estas imagens (é defeito do sistema, não da peça): "
                + "; ".join(falhas[:4])
            )
        if incertas:
            observacoes.append(
                "Imagens com leitura duvidosa: " + "; ".join(incertas[:5])
            )

    if r.leitura_html and getattr(r.leitura_html, "espacos_irregulares", []):
        amostras = "; ".join(r.leitura_html.espacos_irregulares[:4])
        observacoes.append(
            "Espaço duplicado ou espaço antes de pontuação no texto do HTML "
            f"(não reprova, mas vale revisar): {amostras}"
        )
    if r.leitura_html and r.leitura_html.alts_vazios:
        nomes = ", ".join(r.leitura_html.alts_vazios[:8])
        observacoes.append(f"Imagens sem atributo alt no HTML: {nomes}")

    apontamentos_imagem = _imagens(ri)
    divergencias = [_divergencia(d) for d in rt.divergencias] if rt else []
    total_apontamentos = (len(apontamentos_imagem) + len(divergencias)
                          + len(getattr(r, "bloqueios", [])))
    graves = sum(1 for a in apontamentos_imagem if a["gravidade"] == "alta")
    graves += sum(1 for d in divergencias if d["gravidade"] == "alta")
    graves += len(getattr(r, "bloqueios", []))

    return {
        "id": id_relatorio,
        "total_apontamentos": total_apontamentos,
        "apontamentos_graves": graves,
        "status": r.status,
        "nome_pasta": getattr(r, "nome_pasta", "") or os.path.basename(r.pasta.rstrip("/\\")),
        "quebra": r.quebra or "",
        "pasta": r.pasta,
        "arquivo_html": os.path.basename(r.caminho_html) if r.caminho_html else "",
        "arquivo_conteudo": os.path.basename(r.caminho_conteudo) if r.caminho_conteudo else "",
        "arquivo_assunto": os.path.basename(r.caminho_assunto) if r.caminho_assunto else "",
        "erros": r.erros,
        "bloqueios": list(getattr(r, "bloqueios", [])),
        "alertas": list(getattr(r, "alertas", [])),
        "redirects": getattr(r.leitura_html, "redirects", 0) if r.leitura_html else 0,
        "assunto": getattr(r.leitura_assunto, "assunto", "") if r.leitura_assunto else "",
        "pre_header": getattr(r.leitura_assunto, "pre_header", "") if r.leitura_assunto else "",
        "limite_assunto": regras.LIMITE_ASSUNTO,
        "limite_pre_header": regras.LIMITE_PRE_HEADER,
        "observacoes": observacoes,
        "ocr_ativo": r.ocr_ativo,
        "motor_ocr": _descricao_do_motor() if r.ocr_ativo else "",
        "modo_texto": getattr(r, "modo_texto", "sequencia"),
        "motivo_ocr": r.motivo_ocr,
        "imagens": {
            "material_de_apoio": ri.material_de_apoio if ri else [],
            "total_pasta": len(ri.arquivos) if ri else 0,
            "total_chamadas_html": ri.total_referencias_html if ri else 0,
            "reaproveitadas": ri.repeticoes_no_html if ri else {},
            "apontamentos": apontamentos_imagem,
        },
        "texto": {
            "similaridade": rt.similaridade if rt else 0,
            "divergencias": divergencias,
            "dispensados": rt.trechos_dispensados if rt else [],
            "sem_leitura": rt.blocos_sem_ocr if rt else [],
            "blocos_conferidos": getattr(rt, "blocos_conferidos", 0) if rt else 0,
            "correcoes_ocr": getattr(rt, "correcoes_ocr", []) if rt else [],
            "imagens_reordenadas": getattr(rt, "imagens_reordenadas", []) if rt else [],
        },
    }
''',
    # ---- validador/relatorio.py ---------------------------------------------------
    "relatorio": r'''"""
Relatório de conferência em HTML — arquivo único, abre em qualquer navegador,
sem servidor e sem dependência externa. Serve como evidência da conferência.
"""

import html
import os
from datetime import datetime

CSS = """
:root{
  --tinta:#1c1f23; --tinta-fraca:#5b6570; --linha:#dfe3e8;
  --fundo:#f6f7f9; --papel:#ffffff;
  --marca:#cc092f; --ok:#12734f; --atencao:#a86400; --erro:#b3122c;
  --ok-fundo:#e8f4ee; --atencao-fundo:#fdf3e0; --erro-fundo:#fdeaed;
}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px 72px;background:var(--fundo);color:var(--tinta);
  font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.55}
.folha{max-width:960px;margin:0 auto}
header{border-left:5px solid var(--marca);padding:4px 0 4px 18px;margin-bottom:28px}
header h1{margin:0;font-size:25px;font-weight:650;letter-spacing:-.2px}
header .quebra{font-size:15px;color:var(--tinta-fraca);margin-top:2px}
header .meta{font-size:13px;color:var(--tinta-fraca);margin-top:8px}

.veredito{display:flex;align-items:center;gap:16px;background:var(--papel);
  border:1px solid var(--linha);border-radius:10px;padding:20px 22px;margin-bottom:26px}
.veredito .selo{font-size:19px;font-weight:700;padding:7px 16px;border-radius:6px;white-space:nowrap}
.selo.aprovado{background:var(--ok-fundo);color:var(--ok)}
.selo.atencao{background:var(--atencao-fundo);color:var(--atencao)}
.selo.reprovado,.selo.erro{background:var(--erro-fundo);color:var(--erro)}
.veredito p{margin:0;color:var(--tinta-fraca);font-size:14px}

.numeros{display:flex;gap:28px;flex-wrap:wrap;margin-top:14px;padding-top:14px;
  border-top:1px solid var(--linha)}
.numeros div{min-width:92px}
.numeros b{display:block;font-size:21px;font-weight:650;font-variant-numeric:tabular-nums}
.numeros span{font-size:12.5px;color:var(--tinta-fraca)}

section{background:var(--papel);border:1px solid var(--linha);border-radius:10px;
  padding:22px 24px;margin-bottom:18px}
section h2{margin:0 0 4px;font-size:17px;font-weight:650}
section h2 .contagem{font-weight:400;color:var(--tinta-fraca);font-size:14px}
section .resumo{margin:0 0 16px;color:var(--tinta-fraca);font-size:13.5px}

ul.itens{list-style:none;margin:0;padding:0}
ul.itens li{padding:9px 0 9px 14px;border-left:3px solid var(--linha);margin-bottom:7px;
  background:#fbfcfd;border-radius:0 5px 5px 0;font-size:14px}
li.alta{border-left-color:var(--erro)}
li.media{border-left-color:var(--atencao)}
li.baixa{border-left-color:var(--tinta-fraca)}
li.ok{border-left-color:var(--ok)}
li .rotulo{font-weight:650;margin-right:7px}
.obrigatorio{background:#eef1f4;color:var(--tinta-fraca);font-size:11.5px;
  padding:2px 8px;border-radius:4px;margin-left:8px;font-weight:600}
.citacoes{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:11px}
.citacao{display:flex;flex-direction:column;gap:4px;min-width:0}
.citacao-fonte{font-size:11px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:var(--tinta-fraca)}
.citacao blockquote{margin:0;padding:10px 13px;border:1px solid var(--linha);
  border-radius:6px;background:#fff;font-family:Consolas,"Courier New",monospace;
  font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-word}
.citacao blockquote::before,.citacao blockquote::after{content:\'"\';color:var(--tinta-fraca)}
@media(max-width:700px){.citacoes{grid-template-columns:1fr}}
li .arquivo{font-family:Consolas,"Courier New",monospace;font-size:13px;
  background:#eef1f4;padding:1px 6px;border-radius:4px}

.diff{margin-top:8px;border:1px solid var(--linha);border-radius:6px;overflow:hidden}
.diff div{padding:8px 12px;font-size:13.5px}
.diff .lado{display:flex;gap:10px;border-bottom:1px solid var(--linha)}
.diff .lado:last-child{border-bottom:none}
.diff .tag{flex:0 0 74px;color:var(--tinta-fraca);font-size:12px;padding-top:1px}
.diff .html{background:#fff}
.diff .docx{background:#fafbfc}
.contexto{font-size:12.5px;color:var(--tinta-fraca);margin-top:6px}
.contexto code{background:#eef1f4;padding:1px 5px;border-radius:3px;font-size:12px}

.vazio{color:var(--ok);font-size:14px;margin:0}
.aviso{background:var(--atencao-fundo);border-left:3px solid var(--atencao);
  padding:11px 14px;border-radius:0 5px 5px 0;margin-bottom:9px;font-size:14px}
footer{margin-top:26px;font-size:12.5px;color:var(--tinta-fraca);text-align:center}
@media print{body{background:#fff;padding:0}section,.veredito{break-inside:avoid}}
"""

# Descritivo, não prescritivo: a ferramenta relata a divergência entre os dois
# arquivos e não opina sobre o que a peça deveria conter.
FRASES_STATUS = {
    "aprovado": "Nenhuma divergência entre o HTML e o CONTEUDO.docx.",
    "atencao": "Pontos para o analista avaliar.",
    "reprovado": "Divergências encontradas entre o HTML e o CONTEUDO.docx.",
    "erro": "Não foi possível concluir a conferência.",
}


def _e(texto) -> str:
    return html.escape(str(texto), quote=False)


def _secao_imagens(r) -> str:
    if not r:
        return ""
    itens = []

    for nome, motivo in r.fora_da_taxonomia:
        itens.append(("alta", "Fora da taxonomia",
                      f'<span class="arquivo">{_e(nome)}</span> — {_e(motivo)}'))
    if r.numeros_faltando:
        numeros = ", ".join(f"{n:02d}" for n in r.numeros_faltando)
        itens.append(("alta", "Sequência com furo",
                      f"faltam os números {numeros} na pasta"))
    if r.nao_comeca_em_um:
        itens.append(("media", "Sequência não inicia em 01", "primeiro número da pasta não é 01"))
    if r.numeros_duplicados:
        numeros = ", ".join(f"{n:02d}" for n in r.numeros_duplicados)
        itens.append(("alta", "Número repetido", f"o número {numeros} aparece em mais de um arquivo"))
    for nome in r.extensao_invalida:
        itens.append(("media", "Extensão fora do padrão", _e(nome)))
    for nome in r.no_html_fora_da_pasta:
        itens.append(("alta", "Chamada sem arquivo",
                      f'o HTML chama <span class="arquivo">{_e(nome)}</span>, que não existe na pasta'))
    for nome in r.na_pasta_fora_do_html:
        itens.append(("alta", "Imagem não utilizada",
                      f'<span class="arquivo">{_e(nome)}</span> está na pasta, mas não é chamada no HTML'))
    for na_pasta, no_html in r.divergencia_de_caixa:
        itens.append(("alta", "Caixa divergente",
                      f'pasta: <span class="arquivo">{_e(na_pasta)}</span> · '
                      f'HTML: <span class="arquivo">{_e(no_html)}</span>'))
    for nome in r.sem_numeracao_zero_a_esquerda:
        itens.append(("baixa", "Numeração sem zero à esquerda",
                      f'<span class="arquivo">{_e(nome)}</span> — o padrão é 01, 02, 03'))

    corpo = "".join(
        f'<li class="{classe}"><span class="rotulo">{_e(rotulo)}</span>{texto}</li>'
        for classe, rotulo, texto in itens
    )
    if not corpo:
        corpo = '<p class="vazio">Nomes seguem a quebra, sequência sem furo e todas as imagens aparecem no HTML.</p>'
    else:
        corpo = f'<ul class="itens">{corpo}</ul>'

    repetidas = ""
    if r.repeticoes_no_html:
        lista = ", ".join(f"{_e(n)} ({q}x)" for n, q in sorted(r.repeticoes_no_html.items()))
        repetidas = f"<p class='contexto'>Reaproveitadas no HTML (permitido): {lista}</p>"

    return f"""
    <section>
      <h2>Imagens <span class="contagem">· {len(r.arquivos)} na pasta · {r.total_referencias_html} chamadas no HTML</span></h2>
      <p class="resumo">Taxonomia, sequência numérica e cruzamento entre a pasta e o código.</p>
      {corpo}{repetidas}
    </section>"""


def _secao_texto(r, modo="sequencia") -> str:
    if not r:
        return ""
    blocos = []
    for d in r.divergencias:
        rotulos = {
            "faltando": "Está no HTML, não está no CONTEUDO",
            "trocado": "Escrito de forma diferente nos dois",
            "sobrando": "Está no CONTEUDO, não está no HTML",
            "fora_de_ordem": "Mesmas palavras, ordem diferente",
            "acento_pontuacao": "Acento ou pontuação diferente",
            "espacamento": "Mesmo texto, espaçamento diferente",
        }
        nomes_de_bloco = {"disclaimer": "no bloco de disclaimer",
                          "opt-out": "no bloco de descadastro",
                          "atendimento": "no bloco de atendimento"}
        classe = d.gravidade
        rotulo = rotulos.get(d.tipo, d.tipo)
        marca = ""
        if d.obrigatorio:
            marca = (f'<span class="obrigatorio">'
                     f'{_e(nomes_de_bloco.get(d.obrigatorio, ""))}</span>')
        diff = ""
        if d.trecho_html or d.trecho_docx:
            diff = f"""<div class="diff">
              <div class="lado html"><span class="tag">HTML</span><span>{_e(d.trecho_html) or "—"}</span></div>
              <div class="lado docx"><span class="tag">CONTEUDO</span><span>{_e(d.trecho_docx) or "—"}</span></div>
            </div>"""
        contexto = ""
        if d.contexto_antes.startswith("palavras ausentes:"):
            contexto = (f'<p class="contexto"><b>Palavras que faltam no docx:</b> '
                        f'<code>{_e(d.contexto_antes.replace("palavras ausentes: ", ""))}</code></p>')
        elif d.contexto_antes or d.contexto_depois:
            contexto = (f'<p class="contexto">Contexto: '
                        f'<code>{_e(d.contexto_antes)}</code> … '
                        f'<code>{_e(d.contexto_depois)}</code></p>')
        citacoes = ""
        if getattr(d, "citacao_html", "") or getattr(d, "citacao_docx", ""):
            citacoes = (
                '<div class="citacoes">'
                '<div class="citacao"><span class="citacao-fonte">Como está no HTML</span>'
                f'<blockquote>{_e(d.citacao_html) or "—"}</blockquote></div>'
                '<div class="citacao">'
                '<span class="citacao-fonte">Como está no CONTEUDO.docx</span>'
                f'<blockquote>{_e(d.citacao_docx) or "—"}</blockquote></div>'
                '</div>'
            )
        blocos.append(
            f'<li class="{classe}"><span class="rotulo">{rotulo}</span>'
            f'em <span class="arquivo">{_e(d.origem)}</span>{marca}{diff}{contexto}'
            f'{citacoes}</li>'
        )

    corpo = f'<ul class="itens">{"".join(blocos)}</ul>' if blocos else (
        '<p class="vazio">O CONTEUDO.docx e a leitura do HTML têm as mesmas palavras, na mesma ordem.</p>'
    )

    dispensados = ""
    if r.trechos_dispensados:
        lista = "; ".join(_e(t) for t in r.trechos_dispensados[:4])
        dispensados = (f'<p class="contexto">Ignorado por ser texto de template: '
                       f'{lista}</p>')

    parcial = ""
    if r.blocos_sem_ocr:
        lista = " ".join(f'<span class="arquivo">{_e(i)}</span>' for i in r.blocos_sem_ocr)
        parcial = ('<div class="aviso" style="margin-top:16px">O texto dentro destas '
                   f'imagens não foi conferido. Confira no olho: {lista}</div>')

    if modo == "presenca":
        descricao = ("Conferência parcial: sem a leitura de imagens, comparei apenas o "
                     "texto escrito no código do HTML contra o CONTEUDO.docx, palavra a "
                     "palavra. O que está dentro dos banners não entrou na conta.")
    else:
        descricao = ("Comparação palavra a palavra entre a ordem de leitura do HTML "
                     "(texto vivo + texto dentro das imagens) e o CONTEUDO.docx.")

    return f"""
    <section>
      <h2>Texto <span class="contagem">· {r.similaridade}%</span></h2>
      <p class="resumo">{descricao}</p>
      {corpo}{dispensados}{parcial}
    </section>"""


def _secao_bloqueios(resultado) -> str:
    """Regras de publicação que a peça não cumpre. Abre o relatório."""
    bloqueios = list(getattr(resultado, "bloqueios", []))
    alertas = list(getattr(resultado, "alertas", []))
    if not bloqueios and not alertas:
        return ""

    partes = ""
    if bloqueios:
        itens = "".join(
            f'<li class="alta"><span class="rotulo">Impede a publicação</span>{_e(b)}</li>'
            for b in bloqueios
        )
        partes += f'<ul class="itens">{itens}</ul>'
    if alertas:
        partes += ('<p class="contexto" style="margin-top:12px">'
                   + " · ".join(_e(a) for a in alertas) + "</p>")

    return f"""
    <section>
      <h2>Regras de publicação</h2>
      <p class="resumo">Requisitos do banco para a peça subir.</p>
      {partes}
    </section>"""


def _secao_avisos(resultado) -> str:
    itens = list(resultado.avisos)
    for a in resultado.apontamentos_assunto:
        itens.append(f"Pré-header do docx não localizado no HTML: “{a.trecho_docx}”")
    if resultado.leitura_html and resultado.leitura_html.alts_vazios:
        nomes = ", ".join(resultado.leitura_html.alts_vazios[:8])
        itens.append(f"Imagens sem atributo alt no HTML: {nomes}")
    if not itens:
        return ""
    corpo = "".join(f'<div class="aviso">{_e(i)}</div>' for i in itens)
    return f'<section><h2>Observações</h2>{corpo}</section>'


def gerar(resultado, caminho_saida: str) -> str:
    status = resultado.status
    rt = resultado.resultado_texto
    ri = resultado.resultado_imagens

    if resultado.erros:
        conteudo = "".join(f'<div class="aviso">{_e(e)}</div>' for e in resultado.erros)
        corpo = f'<section><h2>Erros</h2>{conteudo}</section>'
        numeros = ""
    else:
        corpo = (_secao_bloqueios(resultado) + _secao_imagens(ri)
                 + _secao_texto(rt, getattr(resultado, "modo_texto", "sequencia"))
                 + _secao_avisos(resultado))
        numeros = f"""
        <div class="numeros">
          <div><b>{len(ri.arquivos) if ri else 0}</b><span>imagens</span></div>
          <div><b>{rt.similaridade if rt else 0}%</b><span>aderência</span></div>
          <div><b>{len(rt.divergencias) if rt else 0}</b><span>divergências</span></div>
          <div><b>{"sim" if resultado.ocr_ativo else "não"}</b><span>leitura de imagem</span></div>
        </div>"""

    agora = datetime.now().strftime("%d/%m/%Y às %H:%M")
    documento = f"""<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Conferência · {_e(resultado.quebra or os.path.basename(resultado.pasta))}</title>
<style>{CSS}</style></head><body><div class="folha">
  <header>
    <h1>Conferência de pacote</h1>
    <div class="quebra">{_e(resultado.quebra or os.path.basename(resultado.pasta))}</div>
    <div class="meta">{_e(resultado.pasta)} · {agora}</div>
  </header>
  <div class="veredito">
    <div>
      <div style="display:flex;align-items:center;gap:14px">
        <span class="selo {status}">{status.upper()}</span>
        <p>{FRASES_STATUS.get(status, "")}</p>
      </div>
      {numeros}
    </div>
  </div>
  {corpo}
  <footer>Validador de pacotes · Orquestração e Ativação de Campanhas</footer>
</div></body></html>"""

    os.makedirs(os.path.dirname(os.path.abspath(caminho_saida)), exist_ok=True)
    with open(caminho_saida, "w", encoding="utf-8") as f:
        f.write(documento)
    return caminho_saida
''',
}


class _CarregadorDoScript(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """Entrega o pacote "validador" a partir dos textos embutidos neste arquivo."""

    def find_spec(self, nome, caminho=None, alvo=None):
        if nome == "validador":
            return importlib.util.spec_from_loader(nome, self, is_package=True)
        if nome.startswith("validador."):
            filho = nome.split(".", 1)[1]
            if filho != "__init__" and filho in _FONTES_VALIDADOR:
                return importlib.util.spec_from_loader(nome, self)
        return None

    def create_module(self, spec):
        return None

    def exec_module(self, modulo):
        nome = modulo.__name__
        chave = "__init__" if nome == "validador" else nome.split(".", 1)[1]
        # __file__ aponta para este script: é daqui que o OCR tira a pasta do
        # cache e o resumo que identifica a versão do código de leitura
        modulo.__file__ = _CAMINHO_DO_SCRIPT
        # o OCR calcula a versão da leitura a partir do texto dos seus módulos
        modulo.__dict__["_FONTES_DO_SCRIPT"] = _FONTES_VALIDADOR
        codigo = compile(_FONTES_VALIDADOR[chave],
                         f"{_CAMINHO_DO_SCRIPT}::validador/{chave}.py", "exec")
        exec(codigo, modulo.__dict__)


sys.meta_path.insert(0, _CarregadorDoScript())

# endregion


# region 3. Front-end embutido
# Front do Validador (static/style.css e static/script.js, sem alterações)
_CSS_VALIDADOR = r'''/* ==============================================================================
 * Validador de pacotes EMKT — Bradesco · CRM · Publicação e Orquestração
 * ==============================================================================
 * Mesma estética do "Pasta-Programa" e do "Busca Fácil": paleta, tokens de
 * raio/sombra/espaçamento, cabeçalho com barra de acento, loader de abertura
 * e modo escuro idênticos.
 *
 * Organização (use Ctrl+F para pular direto pra seção):
 *   0. Tokens (claro) e tema escuro     6. Resultado: cabeça e números
 *   1. Base e reset                     7. Apontamentos e diff
 *   2. Loader (tela de abertura)        8. Estados, avisos e toast
 *   3. Cabeçalho e título da página     9. Rodapé de motor de leitura
 *   4. Painéis, abas, campos, botões   10. Responsivo, movimento e impressão
 *   5. Área de arrastar a pasta
 * ============================================================================== */

/* ==============================================================================
   0. Tokens
   ============================================================================== */

:root {
  /* --- Marca --- */
  --bradesco-red: #cc092f;
  --bradesco-red-dark: #a20724;
  --bradesco-red-light: #ff3b5c;
  --bradesco-red-glow: rgba(204, 9, 47, 0.35);
  --bradesco-red-tenue: rgba(204, 9, 47, 0.06);

  /* --- Superfícies --- */
  --bg: #f5f5f5;
  --card-bg: #ffffff;
  --surface-2: #f0f0f0;
  --surface-3: #e9e9e9;
  --border: #e5e5e5;
  --border-strong: #d3d5d9;

  /* --- Texto --- */
  --text: #1a1a1a;
  --text-muted: #666666;
  --text-dim: #6b6b6b;

  /* --- Estado --- */
  --ok-fg: #15803d;   --ok-bg: rgba(34, 197, 94, 0.15);   --ok-dot: #22c55e;
  --warn-fg: #b45309; --warn-bg: rgba(245, 158, 11, 0.15); --warn-dot: #f59e0b;
  --danger-fg: var(--bradesco-red); --danger-bg: rgba(204, 9, 47, 0.15);

  /* --- Veredito do pacote --- */
  --aprovado: #15803d;
  --aprovado-bg: #f0f9f3;
  --aprovado-borda: #cbe6d6;
  --atencao: #b45309;
  --atencao-bg: #fdf6e3;
  --atencao-borda: #ecd9a4;
  --reprovado: #c0392b;
  --reprovado-bg: #fdeeec;
  --reprovado-borda: #f0c4bd;

  /* --- Gravidade do apontamento --- */
  --grav-alta: var(--bradesco-red);
  --grav-media: #b45309;
  --grav-baixa: #6b7280;

  /* --- Raio, sombra, espaçamento, camadas --- */
  --radius-sm: 6px;  --radius-md: 8px;  --radius-lg: 12px;  --radius-full: 999px;
  --shadow-card: 0 1px 2px rgba(0, 0, 0, 0.03);
  --shadow-chip: 0 1px 3px rgba(0, 0, 0, 0.10);
  --shadow-raised: 0 6px 18px rgba(0, 0, 0, 0.08);
  --shadow-overlay: 0 20px 60px rgba(0, 0, 0, 0.35);

  --space-1: 4px;  --space-2: 8px;  --space-3: 12px; --space-4: 16px;
  --space-5: 20px; --space-6: 24px; --space-7: 32px;

  --z-sticky: 10; --z-header: 20; --z-toast: 200; --z-loader: 9999;

  /* --- Tipografia ---
     Manrope/JetBrains Mono vêm do Google Fonts. Se o proxy corporativo
     bloquear, a pilha do sistema assume e a tela continua inteira — só não
     fica com a fonte da marca. */
  --fonte: 'Manrope', 'Segoe UI Variable Text', 'Segoe UI', -apple-system,
           BlinkMacSystemFont, Roboto, 'Helvetica Neue', Arial, sans-serif;
  --fonte-mono: 'JetBrains Mono', 'Cascadia Mono', ui-monospace, 'SFMono-Regular',
                Consolas, 'Liberation Mono', Menlo, monospace;

  --t-xs: 11px;
  --t-sm: 12.5px;
  --t-base: 14px;
  --t-md: 15px;
  --t-lg: 19px;

  --transicao: 160ms cubic-bezier(.22, .61, .36, 1);
}

/* ------------------------------------------------------------------------------
   Tema escuro — só redefine tokens. Nenhum componente tem cor chumbada.
   ------------------------------------------------------------------------------ */
html { color-scheme: light; }

html[data-theme="dark"] {
  color-scheme: dark;

  --bg: #14161a;
  --card-bg: #1c1f26;
  --surface-2: #20242c;
  --surface-3: #262b34;
  --border: #2c313c;
  --border-strong: #3a414e;

  --text: #eef0f3;
  --text-muted: #a3a9b5;
  --text-dim: #8a92a0;

  --bradesco-red-tenue: rgba(255, 59, 92, 0.10);

  --ok-fg: #7ee787;   --ok-bg: rgba(34, 197, 94, 0.14);
  --warn-fg: #f2cc60; --warn-bg: rgba(245, 158, 11, 0.14);
  --danger-fg: #ff8a9c; --danger-bg: rgba(204, 9, 47, 0.20);

  --aprovado: #7ee787;
  --aprovado-bg: rgba(34, 197, 94, .12);
  --aprovado-borda: rgba(126, 231, 135, .28);
  --atencao: #f2cc60;
  --atencao-bg: rgba(245, 158, 11, .12);
  --atencao-borda: rgba(242, 204, 96, .28);
  --reprovado: #ff8a9c;
  --reprovado-bg: rgba(204, 9, 47, .16);
  --reprovado-borda: rgba(255, 138, 156, .30);

  --grav-alta: var(--bradesco-red-light);
  --grav-media: #f2cc60;
  --grav-baixa: #8a92a0;
}

/* ==============================================================================
   1. Base e reset
   ============================================================================== */

* { box-sizing: border-box; }

/* O atributo hidden precisa vencer os display:flex/grid dos componentes —
   sem isto os painéis de estado aparecem vazios na tela. */
[hidden] { display: none !important; }
.hidden { display: none !important; }

html { scroll-behavior: smooth; }
html, body { margin: 0; padding: 0; }

body {
  min-height: 100vh;
  background: var(--bg);
  color: var(--text);
  font-family: var(--fonte);
  font-size: var(--t-base);
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
}

h1, h2, h3, h4 { margin: 0; }
button { font-family: inherit; cursor: pointer; }
input, select, textarea { font-family: inherit; color: inherit; }

::selection { background: var(--bradesco-red); color: #fff; }

:focus-visible {
  outline: 2px solid var(--bradesco-red);
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}

/* Transição suave ao trocar de tema — só nas superfícies grandes. */
body, .panel, .app-header, .resultado, .apontamento, .estado, .chip-face {
  transition: background-color 160ms ease, border-color 160ms ease, color 160ms ease;
}

/* ==============================================================================
   2. Loader (tela de abertura)
   ============================================================================== */

.loader {
  position: fixed; inset: 0; z-index: var(--z-loader);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  background: radial-gradient(120% 120% at 50% 28%, #e00a34 0%, var(--bradesco-red) 45%, #7c051d 100%);
  transition: opacity .5s ease .15s, visibility .5s ease .15s;
}

.loader.hide { opacity: 0; visibility: hidden; pointer-events: none; }

.loader-icon {
  position: relative;
  width: 104px; height: 104px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  background: #fff; color: var(--bradesco-red);
  box-shadow: 0 0 0 6px rgba(255, 255, 255, .14), 0 16px 44px rgba(0, 0, 0, .35);
  animation: loaderPulse 2.2s ease-in-out infinite;
}

.loader-icon svg { width: 52%; height: 52%; }

/* A imagem do CDN cobre o símbolo desenhado com um disco branco próprio: se
   carregar, aparece a marca; se o proxy bloquear, o onerror remove a <img> e
   o símbolo desenhado continua ali. Nada de ícone quebrado no meio da tela. */
.loader-icon img {
  position: absolute; inset: 0;
  width: 100%; height: 100%;
  padding: 19%; border-radius: 50%;
  background: #fff; object-fit: contain;
}

.loader-icon:has(img) svg { display: none; }

.loader-eyebrow {
  margin-top: 24px;
  font-size: 10px; font-weight: 700; text-transform: uppercase;
  letter-spacing: .3em; color: rgba(255, 255, 255, .75);
  animation: loaderFadeUp .7s ease both;
}

.loader-title {
  margin-top: 6px;
  font-size: clamp(20px, 4vw, 26px); font-weight: 800;
  letter-spacing: -.02em; color: #fff; text-align: center;
  animation: loaderFadeUp .7s .15s ease both;
}

.loader-bar {
  width: 160px; height: 3px; margin-top: 28px;
  border-radius: var(--radius-full); overflow: hidden;
  background: rgba(255, 255, 255, .18);
  animation: loaderFadeUp .7s .45s ease both;
}

.loader-bar::before {
  content: ""; display: block; width: 40%; height: 100%;
  border-radius: inherit; background: #fff;
  animation: loaderSweep 1.1s ease-in-out infinite;
}

@keyframes loaderPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
@keyframes loaderFadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
@keyframes loaderSweep { 0% { transform: translateX(-100%); } 100% { transform: translateX(350%); } }

/* No escuro o loader mantém o vermelho, só com a luz apagada: o fade "pousa"
   quase na cor da tela em vez de dar um estouro de contraste. */
html[data-theme="dark"] .loader {
  background: radial-gradient(120% 120% at 50% 28%, #6b0419 0%, #40030f 45%, #16090c 100%);
}
html[data-theme="dark"] .loader-icon {
  box-shadow: 0 0 0 6px rgba(255, 255, 255, .08), 0 16px 44px rgba(0, 0, 0, .6);
}

/* ==============================================================================
   3. Cabeçalho e título da página
   ============================================================================== */

.brand-accent-bar {
  height: 3px;
  background: linear-gradient(90deg, var(--bradesco-red) 0%, var(--bradesco-red) 60%, var(--bradesco-red-light) 100%);
}

.app-header {
  position: relative; z-index: var(--z-header);
  background: var(--card-bg);
  border-bottom: 1px solid var(--border);
}

.header-inner {
  max-width: 1480px; margin: 0 auto;
  padding: var(--space-4) var(--space-6);
  display: flex; align-items: center; justify-content: space-between; gap: var(--space-4);
}

.brand { display: flex; align-items: center; gap: var(--space-3); }

.brand-logo {
  position: relative;
  width: 40px; height: 40px; flex-shrink: 0;
  display: grid; place-items: center;
  border-radius: var(--radius-sm);
  overflow: hidden;
  color: #fff;
}

/* O quadrado vermelho vive no próprio SVG (não no .brand-logo): assim, quando
   a logo do CDN carrega, não sobra nenhuma franja vermelha na volta dela. */
.brand-logo svg {
  width: 100%; height: 100%; padding: 8px;
  background: var(--bradesco-red); border-radius: inherit;
}

.brand-logo:has(img) svg { display: none; }

.brand-logo img {
  position: absolute; inset: 0;
  width: 100%; height: 100%;
  border-radius: inherit;
  background: #fff; object-fit: contain; padding: 5px;
}

/* No escuro o disco branco em volta da logo vira um quadrado aceso no meio do
   cabeçalho. A logo tem fundo transparente, então basta tirar o branco: ela
   pousa direto na superfície do card. */
html[data-theme="dark"] .brand-logo img { background: transparent; padding: 3px; }

.brand-eyebrow {
  font-size: var(--t-xs); font-weight: 700; letter-spacing: .08em;
  text-transform: uppercase; color: var(--text-dim);
}

.brand-title { font-size: var(--t-md); font-weight: 800; letter-spacing: -.01em; }

.header-right { display: flex; align-items: center; gap: var(--space-2); }

.chip {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 6px 11px;
  border: 1px solid var(--border); border-radius: var(--radius-full);
  background: var(--card-bg); color: var(--text-muted);
  font-size: var(--t-xs); font-weight: 700;
  transition: border-color var(--transicao), color var(--transicao), background var(--transicao);
}

.chip-btn:hover { border-color: var(--bradesco-red); color: var(--bradesco-red); }
.chip-btn:active { transform: scale(.97); }

.app-main { max-width: 1480px; margin: 0 auto; padding: var(--space-7) var(--space-6) 72px; }

.page-title { margin-bottom: var(--space-6); }

.page-title h1 {
  display: flex; align-items: center; gap: var(--space-3);
  font-size: clamp(21px, 3vw, 27px); font-weight: 800; letter-spacing: -.02em;
}

.page-title-icon { color: var(--bradesco-red); flex-shrink: 0; }

.page-title p {
  margin: var(--space-3) 0 0;
  max-width: 76ch;
  font-size: var(--t-base); color: var(--text-muted);
}

.page-title b { color: var(--text); font-weight: 700; }

/* ==============================================================================
   4. Painéis, abas, campos, botões
   ============================================================================== */

.panel {
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
}

.painel-fluxo { display: flex; flex-direction: column; gap: var(--space-4); }

#status-area:empty { display: none; }

.scan-panel { padding: var(--space-5); }

.card-header {
  display: flex; align-items: center; gap: var(--space-2);
  margin-bottom: var(--space-4);
  color: var(--bradesco-red);
}

.card-header svg { flex-shrink: 0; }
.card-title { font-size: var(--t-md); font-weight: 800; letter-spacing: -.01em; }

/* --- Abas de entrada --- */

.abas {
  display: flex; gap: var(--space-2);
  margin-bottom: var(--space-5);
  padding: 4px;
  background: var(--surface-2);
  border-radius: var(--radius-md);
}

.aba {
  flex: 1;
  display: inline-flex; align-items: center; justify-content: center; gap: 7px;
  padding: 10px 14px;
  border: 0; border-radius: var(--radius-sm);
  background: transparent; color: var(--text-muted);
  font-size: var(--t-base); font-weight: 700;
  transition: background var(--transicao), color var(--transicao), box-shadow var(--transicao);
}

.aba svg { width: 16px; height: 16px; flex-shrink: 0; }
.aba:hover:not(.ativa) { color: var(--text); }

.aba.ativa {
  background: var(--card-bg); color: var(--bradesco-red);
  box-shadow: var(--shadow-chip);
}

/* --- Campo de caminho --- */

.field { display: flex; flex-direction: column; gap: 6px; min-width: 0; }

.field label {
  font-size: var(--t-sm); font-weight: 700; color: var(--text-muted);
  letter-spacing: .02em;
}

.input-wrap { position: relative; display: flex; align-items: center; }

.input-icon {
  position: absolute; left: 12px;
  width: 17px; height: 17px;
  color: var(--text-dim); pointer-events: none;
  transition: color var(--transicao);
}

#caminho {
  width: 100%;
  padding: 11px 13px 11px 38px;
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--card-bg); color: var(--text);
  font-family: var(--fonte-mono); font-size: var(--t-base);
  transition: border-color var(--transicao), box-shadow var(--transicao);
}

#caminho::placeholder { color: var(--text-dim); }
#caminho:hover { border-color: var(--border-strong); }

#caminho:focus {
  outline: none;
  border-color: var(--bradesco-red);
  box-shadow: 0 0 0 3px rgba(204, 9, 47, .08);
}

.input-wrap:focus-within .input-icon { color: var(--bradesco-red); }

.dica { font-size: var(--t-xs); color: var(--text-dim); }

/* --- Opções --- */

.opcoes {
  display: flex; flex-wrap: wrap; gap: var(--space-5);
  margin-top: var(--space-4); padding-top: var(--space-4);
  border-top: 1px dashed var(--border);
}

.opcao {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: var(--t-sm); color: var(--text-muted); cursor: pointer;
}

.opcao input { accent-color: var(--bradesco-red); width: 15px; height: 15px; cursor: pointer; }

.select-motor {
  padding: 5px 9px;
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--card-bg); color: var(--text);
  font-size: var(--t-sm); font-family: inherit; cursor: pointer;
  max-width: 260px;
}

.select-motor:hover { border-color: var(--bradesco-red); }
.opcao:hover { color: var(--text); }

/* --- Botões --- */

.btn-primary, .btn-ghost {
  display: inline-flex; align-items: center; justify-content: center; gap: var(--space-2);
  border-radius: var(--radius-sm);
  font-weight: 700; line-height: 1.2;
  transition: background var(--transicao), border-color var(--transicao),
              color var(--transicao), box-shadow var(--transicao), transform var(--transicao);
}

.btn-primary {
  padding: 10px 22px; min-height: 44px;
  border: none;
  background: var(--bradesco-red); color: #fff;
  font-size: 13px; letter-spacing: .06em;
  white-space: nowrap;
  /* Pulsa 3 vezes e para: chama atenção quando a tela abre e depois sossega. */
  animation: pulseGlow 1.8s ease-in-out 3;
}

.btn-primary:hover:not(:disabled) { background: var(--bradesco-red-dark); }
.btn-primary:active:not(:disabled) { transform: scale(.97); }

/* Desabilitado nunca troca de cor — só perde opacidade. Um rosa claro com
   texto branco sumia no tema escuro. */
.btn-primary:disabled {
  background: var(--bradesco-red); opacity: .5;
  cursor: progress; animation: none;
}

@keyframes pulseGlow {
  0%, 100% { box-shadow: 0 0 0 0 var(--bradesco-red-glow); }
  50% { box-shadow: 0 0 0 8px transparent; }
}

.btn-ghost {
  padding: 8px 13px;
  border: 1px solid var(--border);
  background: var(--card-bg); color: var(--text);
  font-size: var(--t-sm);
  white-space: nowrap;
}

.btn-ghost svg { width: 16px; height: 16px; flex-shrink: 0; }
.btn-ghost:hover:not(:disabled) { border-color: var(--bradesco-red); color: var(--bradesco-red); }
.btn-ghost:active:not(:disabled) { transform: scale(.97); }
.btn-ghost:disabled { opacity: .45; cursor: not-allowed; }

.acoes {
  display: flex; align-items: center; gap: var(--space-3);
  margin-top: var(--space-5); flex-wrap: wrap;
}

.btn-spinner {
  width: 14px; height: 14px;
  border: 2px solid rgba(255, 255, 255, .35);
  border-top-color: #fff;
  border-radius: 50%;
  animation: girar .7s linear infinite;
}

@keyframes girar { to { transform: rotate(360deg); } }

/* --- Aviso de somente leitura --- */

.assurance {
  display: flex; align-items: flex-start; gap: 7px;
  margin: var(--space-4) 0 0;
  padding-top: var(--space-3);
  border-top: 1px dashed var(--border);
  font-size: var(--t-xs); color: var(--text-dim);
}

.assurance svg { width: 15px; height: 15px; flex-shrink: 0; margin-top: 2px; color: var(--ok-fg); }
.assurance b { color: var(--text-muted); font-weight: 700; }

/* ==============================================================================
   5. Área de arrastar a pasta
   ============================================================================== */

.solta {
  position: relative;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: var(--space-2);
  padding: 44px var(--space-6);
  border: 2px dashed var(--border-strong); border-radius: var(--radius-md);
  background: var(--surface-2);
  text-align: center; cursor: pointer;
  transition: border-color var(--transicao), background var(--transicao), transform var(--transicao);
}

.solta:hover { border-color: var(--bradesco-red); background: var(--bradesco-red-tenue); }

.solta.sobre {
  border-color: var(--bradesco-red);
  background: var(--bradesco-red-tenue);
  transform: scale(1.01);
}

.solta-icone {
  width: 44px; height: 44px;
  color: var(--text-dim);
  transition: color var(--transicao), transform var(--transicao);
}

.solta:hover .solta-icone,
.solta.sobre .solta-icone { color: var(--bradesco-red); transform: translateY(-3px); }

.solta strong { font-size: var(--t-md); font-weight: 800; }
.solta span { font-size: var(--t-sm); color: var(--text-muted); max-width: 54ch; }

.solta-lista {
  display: none;
  margin-top: var(--space-2);
  padding: 8px 14px;
  border-radius: var(--radius-full);
  background: var(--aprovado-bg); color: var(--aprovado);
  border: 1px solid var(--aprovado-borda);
  font-size: var(--t-sm); font-weight: 700;
  animation: entrar .28s cubic-bezier(.22,.61,.36,1) both;
}

.solta-lista.visivel { display: inline-flex; align-items: center; gap: 7px; }

@keyframes entrar { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }

/* ==============================================================================
   6. Resultado: cabeça e números
   ============================================================================== */

#resultados { display: flex; flex-direction: column; gap: var(--space-4); }

/* O resultado vira duas colunas: um mapa que fica parado à esquerda e o
   conteúdo que rola à direita. Conferência é trabalho metódico — perder o
   veredito e os números de vista ao descer na lista atrapalha. */
.resultado {
  display: grid;
  grid-template-columns: 290px minmax(0, 1fr);
  background: var(--card-bg);
  border: 1px solid var(--border); border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
  overflow: hidden;
  animation: entrar .32s cubic-bezier(.22,.61,.36,1) both;
}

.resultado[data-status="aprovado"]  { border-left: 4px solid var(--aprovado); }
.resultado[data-status="atencao"],
.resultado[data-status="parcial"]   { border-left: 4px solid var(--atencao); }
.resultado[data-status="reprovado"],
.resultado[data-status="erro"]      { border-left: 4px solid var(--reprovado); }

.resultado-mapa {
  position: sticky; top: 0; align-self: start;
  display: flex; flex-direction: column; gap: var(--space-4);
  max-height: 100vh; overflow-y: auto;
  padding: var(--space-5);
  border-right: 1px solid var(--border);
  background: var(--surface-2);
}

.mapa-topo { display: flex; flex-direction: column; gap: 6px; align-items: flex-start; }
.mapa-frase { margin: 0; font-size: var(--t-sm); color: var(--text-muted); }

.mapa-numeros {
  display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2);
  margin: 0; padding: var(--space-3) 0;
  border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
}

.mapa-numeros div { display: flex; flex-direction: column; }
.mapa-numeros dt { font-size: var(--t-xs); color: var(--text-dim); }
.mapa-numeros dd {
  margin: 0; font-size: var(--t-md); font-weight: 800;
  font-variant-numeric: tabular-nums;
}

.mapa-secoes { display: flex; flex-direction: column; gap: 2px; }

.mapa-item {
  display: flex; align-items: center; justify-content: space-between; gap: var(--space-2);
  padding: 9px 11px;
  border: 0; border-left: 3px solid transparent; border-radius: var(--radius-sm);
  background: transparent; color: var(--text-muted);
  font-size: var(--t-sm); font-family: inherit; text-align: left;
  transition: background var(--transicao), color var(--transicao),
              border-color var(--transicao);
}

.mapa-item:hover { background: var(--card-bg); color: var(--text); }
.mapa-item b { font-variant-numeric: tabular-nums; font-size: var(--t-sm); }
.mapa-item.grave { border-left-color: var(--reprovado); }
.mapa-item.grave b { color: var(--reprovado); }
.mapa-item.aviso { border-left-color: var(--atencao); }
.mapa-item.aviso b { color: var(--atencao); }
.mapa-item.ok { border-left-color: var(--aprovado); }
.mapa-item.ok b { color: var(--aprovado); }

.mapa-rodape {
  display: flex; flex-direction: column; gap: var(--space-2);
  margin-top: auto; padding-top: var(--space-3);
  border-top: 1px solid var(--border);
}

.mapa-motor { font-size: var(--t-xs); color: var(--text-dim); }
.resultado-conteudo { min-width: 0; padding-bottom: var(--space-3); }

/* clarão rápido ao chegar pelo mapa, para a vista achar onde parou */
.secao-alvo { animation: chegada 1.3s ease-out; }
@keyframes chegada {
  0% { background: var(--bradesco-red-tenue); }
  100% { background: transparent; }
}

.bloco-avisos { background: var(--surface-2); }
.bloco-avisos h3 { color: var(--atencao); }

.resultado-topo {
  display: flex; align-items: center; gap: var(--space-3); flex-wrap: wrap;
  padding: var(--space-5) var(--space-5) var(--space-4);
  border-left: 4px solid var(--border);
}

.resultado[data-status="aprovado"]  .resultado-topo { border-left-color: var(--aprovado); }
.resultado[data-status="atencao"]   .resultado-topo,
.resultado[data-status="parcial"]   .resultado-topo { border-left-color: var(--atencao); }
.resultado[data-status="reprovado"] .resultado-topo,
.resultado[data-status="erro"]      .resultado-topo { border-left-color: var(--reprovado); }

.selo {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 7px 14px;
  border: 1px solid transparent; border-radius: var(--radius-full);
  font-size: var(--t-sm); font-weight: 800; letter-spacing: .08em;
  text-transform: uppercase;
}

.selo::before {
  content: ""; width: 7px; height: 7px; border-radius: 50%;
  background: currentColor; flex-shrink: 0;
}

.selo.aprovado { background: var(--aprovado-bg); color: var(--aprovado); border-color: var(--aprovado-borda); }
.selo.atencao, .selo.parcial { background: var(--atencao-bg); color: var(--atencao); border-color: var(--atencao-borda); }
.selo.reprovado, .selo.erro { background: var(--reprovado-bg); color: var(--reprovado); border-color: var(--reprovado-borda); }

.resultado-quebra {
  font-family: var(--fonte-mono); font-size: var(--t-md); font-weight: 600;
  word-break: break-all; flex: 1; min-width: 0;
}

.resultado-frase {
  padding: 0 var(--space-5) var(--space-4);
  margin: 0; font-size: var(--t-sm); color: var(--text-muted);
}

.numeros {
  display: flex; flex-wrap: wrap; gap: var(--space-7);
  padding: var(--space-4) var(--space-5);
  border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);
  background: var(--surface-2);
}

.numeros div b {
  display: block;
  font-size: 21px; font-weight: 800;
  font-variant-numeric: tabular-nums; letter-spacing: -.02em;
}

.numeros div span { font-size: var(--t-xs); color: var(--text-muted); }

.bloco { padding: var(--space-5); }
.bloco + .bloco { border-top: 1px solid var(--border); }

.bloco h3 {
  display: flex; align-items: baseline; gap: var(--space-2); flex-wrap: wrap;
  margin-bottom: var(--space-3);
  font-size: var(--t-base); font-weight: 800;
}

.bloco h3 .qtd { font-size: var(--t-sm); font-weight: 500; color: var(--text-muted); }

/* --- Cabeçalho do resultado: pasta em destaque, quebra como apoio --- */

.resultado-identidade { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }

.resultado-pasta {
  font-size: var(--t-md); font-weight: 800; letter-spacing: -.01em;
  word-break: break-word;
}

.resultado-quebra {
  font-family: var(--fonte-mono); font-size: var(--t-xs);
  color: var(--text-dim); word-break: break-all;
}

.resultado-ordem {
  display: inline-flex; align-items: center;
  padding: 5px 11px; border-radius: var(--radius-full);
  background: var(--surface-3); color: var(--text-muted);
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .06em;
  white-space: nowrap;
}

/* ==============================================================================
   6b. Painel do lote
   ============================================================================== */

.lote-resumo, .unico-resumo { padding: var(--space-5); }

.lote-etiqueta {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 5px 12px; margin-bottom: var(--space-2);
  border-radius: var(--radius-full);
  background: var(--bradesco-red); color: #fff;
  font-size: 10.5px; font-weight: 800; letter-spacing: .12em; text-transform: uppercase;
}

.lote-etiqueta.unico { background: var(--surface-3); color: var(--text-muted); }

.lote-titulo {
  font-size: var(--t-lg); font-weight: 800; letter-spacing: -.02em;
  word-break: break-word;
}

.lote-cabeca {
  display: flex; align-items: flex-start; justify-content: space-between;
  gap: var(--space-4); flex-wrap: wrap;
}

.lote-rodando {
  display: inline-block; margin-left: 10px;
  padding: 3px 11px; border-radius: var(--radius-full);
  background: var(--atencao-bg); color: var(--atencao);
  font-size: var(--t-xs); font-weight: 700;
  animation: piscar 1.4s ease-in-out infinite;
}

@keyframes piscar { 0%, 100% { opacity: 1; } 50% { opacity: .45; } }

.lote-placar { display: flex; gap: var(--space-2); flex-wrap: wrap; }

.placar {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 7px 13px;
  border: 1px solid transparent; border-radius: var(--radius-full);
  font-size: var(--t-sm); font-weight: 600;
}

.placar b { font-size: var(--t-md); font-weight: 800; font-variant-numeric: tabular-nums; }
.placar.aprovado  { background: var(--aprovado-bg);  color: var(--aprovado);  border-color: var(--aprovado-borda); }
.placar.atencao   { background: var(--atencao-bg);   color: var(--atencao);   border-color: var(--atencao-borda); }
.placar.reprovado { background: var(--reprovado-bg); color: var(--reprovado); border-color: var(--reprovado-borda); }

/* --- Ordenação --- */

.lote-ordenacao {
  display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap;
  margin-top: var(--space-5); padding-top: var(--space-4);
  border-top: 1px dashed var(--border);
}

.lote-ordenacao-rotulo {
  font-size: var(--t-xs); font-weight: 700; letter-spacing: .06em;
  text-transform: uppercase; color: var(--text-dim); margin-right: var(--space-1);
}

.ordenar {
  padding: 6px 13px;
  border: 1px solid var(--border); border-radius: var(--radius-full);
  background: var(--card-bg); color: var(--text-muted);
  font-size: var(--t-sm); font-weight: 600;
  transition: border-color var(--transicao), color var(--transicao), background var(--transicao);
}

.ordenar:hover { border-color: var(--bradesco-red); color: var(--bradesco-red); }

.ordenar.ativa {
  background: var(--bradesco-red); border-color: var(--bradesco-red); color: #fff;
  font-weight: 700;
}

/* --- Índice clicável dos pacotes --- */

.lote-indice { list-style: none; margin: var(--space-4) 0 0; padding: 0; }

.indice-linha {
  display: flex; align-items: center; gap: var(--space-3);
  padding: 10px var(--space-3);
  border: 1px solid var(--border); border-left: 3px solid var(--border);
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  background: var(--card-bg); color: inherit; text-decoration: none;
  transition: background var(--transicao), border-color var(--transicao), transform var(--transicao);
}

.lote-indice li + li { margin-top: 6px; }

.indice-linha[data-status="aprovado"]  { border-left-color: var(--aprovado); }
.indice-linha[data-status="atencao"],
.indice-linha[data-status="parcial"]   { border-left-color: var(--atencao); }
.indice-linha[data-status="reprovado"],
.indice-linha[data-status="erro"]      { border-left-color: var(--reprovado); }

.indice-linha:hover { background: var(--surface-2); transform: translateX(2px); }

.indice-ordem {
  flex: 0 0 26px; height: 26px;
  display: grid; place-items: center;
  border-radius: 50%; background: var(--surface-3);
  font-size: var(--t-xs); font-weight: 800; font-variant-numeric: tabular-nums;
  color: var(--text-muted);
}

.indice-nome {
  flex: 1; min-width: 0;
  font-size: var(--t-base); font-weight: 700;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.indice-numero {
  font-family: var(--fonte-mono); font-size: var(--t-sm);
  font-variant-numeric: tabular-nums; color: var(--text-muted);
  white-space: nowrap;
}

.indice-linha .selo { font-size: 10px; padding: 4px 10px; }

/* ==============================================================================
   7. Apontamentos e diff
   ============================================================================== */

.lista-apontamentos { list-style: none; margin: 0; padding: 0; display: flex;
  flex-direction: column; gap: var(--space-2); }

.apontamento {
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--border); border-left: 3px solid var(--grav-baixa);
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  background: var(--surface-2);
  font-size: var(--t-base);
}

.apontamento.alta  { border-left-color: var(--grav-alta); }
.apontamento.media { border-left-color: var(--grav-media); }
.apontamento.baixa { border-left-color: var(--grav-baixa); }

/* Acento e pontuação: existe margem de tolerância aqui e quem decide é o
   analista, então o apontamento não usa o vermelho de divergência de palavra. */
.apontamento[data-tipo="acento_pontuacao"] { border-left-color: var(--grav-media); }

.apontamento-rotulo { font-weight: 800; margin-right: 7px; }
.apontamento.alta  .apontamento-rotulo { color: var(--grav-alta); }
.apontamento.media .apontamento-rotulo { color: var(--grav-media); }

.arquivo {
  font-family: var(--fonte-mono); font-size: var(--t-sm);
  padding: 2px 7px; border-radius: var(--radius-sm);
  background: var(--surface-3); color: var(--text);
  word-break: break-all;
}

.marca-tolerado {
  display: inline-block; margin-left: 8px;
  padding: 2px 9px; border-radius: var(--radius-full);
  background: var(--atencao-bg); color: var(--atencao);
  border: 1px solid var(--atencao-borda);
  font-size: 10.5px; font-weight: 700; letter-spacing: .03em;
}

.marca-bloco {
  display: inline-block; margin-left: 8px;
  padding: 2px 9px; border-radius: var(--radius-full);
  background: var(--surface-3); color: var(--text-muted);
  font-size: 10.5px; font-weight: 700; letter-spacing: .03em;
}

/* --- Bloqueio de publicação: regra do banco, não divergência de texto --- */

.bloco-bloqueio {
  background: var(--reprovado-bg);
  border-bottom: 1px solid var(--reprovado-borda);
}

.bloco-bloqueio h3 { color: var(--reprovado); }

.apontamento.bloqueio {
  display: flex; align-items: flex-start; gap: 10px;
  background: var(--card-bg);
  border-color: var(--reprovado-borda); border-left-color: var(--reprovado);
  font-weight: 600;
}

.apontamento.bloqueio svg {
  width: 18px; height: 18px; flex-shrink: 0; margin-top: 1px;
  color: var(--reprovado);
}

/* --- Assunto e pré-header --- */

.campos-email { display: flex; flex-direction: column; gap: var(--space-2); }

.campo-email {
  display: flex; align-items: baseline; gap: var(--space-3);
  padding: 10px var(--space-4);
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--surface-2);
}

.campo-rotulo {
  flex: 0 0 88px;
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .05em;
  text-transform: uppercase; color: var(--text-dim);
}

.campo-valor { flex: 1; min-width: 0; font-size: var(--t-base); word-break: break-word; }

.campo-contagem {
  font-family: var(--fonte-mono); font-size: var(--t-xs);
  font-variant-numeric: tabular-nums; color: var(--text-dim);
  white-space: nowrap;
}

/* Passar do limite não impede a publicação, então a marcação é discreta:
   muda a cor da contagem, não a do campo inteiro. */
.campo-email.passou .campo-contagem { color: var(--atencao); font-weight: 700; }
.campo-email.passou { border-color: var(--atencao-borda); }

.alertas-sutis {
  margin: var(--space-3) 0 0;
  font-size: var(--t-xs); color: var(--text-dim); line-height: 1.7;
}

/* --- Citações literais: como está em cada arquivo --- */

.citacoes {
  display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3);
  margin-top: var(--space-3);
}

.citacao {
  display: flex; flex-direction: column; gap: 5px; min-width: 0;
}

.citacao-fonte {
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .05em;
  text-transform: uppercase; color: var(--text-dim);
}

.citacao blockquote {
  margin: 0; padding: var(--space-3) var(--space-4);
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--card-bg);
  font-family: var(--fonte-mono); font-size: var(--t-sm); line-height: 1.65;
  white-space: pre-wrap; word-break: break-word;
  position: relative;
}

/* As aspas deixam claro que é transcrição literal do arquivo, não uma
   interpretação da ferramenta. */
.citacao blockquote::before,
.citacao blockquote::after { content: '"'; color: var(--text-dim); }
.citacao blockquote::before { margin-right: 1px; }
.citacao blockquote::after { margin-left: 1px; }

/* --- Card do apontamento: imagem ao lado da comparação --- */

.apontamento-cabeca {
  display: flex; align-items: center; gap: 6px; flex-wrap: wrap;
  margin-bottom: var(--space-3);
}

.apontamento-corpo { display: flex; gap: var(--space-4); align-items: flex-start; }
.apontamento-corpo.com-imagem .apontamento-texto { flex: 1; min-width: 0; }
.apontamento-texto { flex: 1; min-width: 0; }

.confronto {
  display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3);
  margin-bottom: var(--space-3);
}

.confronto-lado { display: flex; flex-direction: column; gap: 5px; min-width: 0; }

.confronto-titulo {
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .04em;
  text-transform: uppercase; color: var(--text-dim);
}

/* O lado da máquina é marcado: é ali que mora o erro de leitura, e quem
   confere precisa saber disso de relance. */
.confronto-titulo.maquina { color: var(--bradesco-red); }

.confronto blockquote {
  margin: 0; padding: var(--space-3);
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--card-bg);
  font-family: var(--fonte-mono); font-size: var(--t-sm); line-height: 1.6;
  white-space: pre-wrap; word-break: break-word;
}

.confronto-lado:first-child blockquote { border-left: 3px solid var(--bradesco-red); }

/* --- Prova visual e conferência manual --- */

.prova {
  flex: 0 0 240px;
  display: flex; flex-direction: column; gap: 6px;
}

.prova-imagem {
  width: 100%; max-height: 320px;
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: #fff; object-fit: contain; cursor: zoom-in;
  transition: border-color var(--transicao);
}

.prova-imagem:hover { border-color: var(--bradesco-red); }
.prova-dica { font-size: var(--t-xs); color: var(--text-dim); }

.apontamento-acoes {
  display: flex; align-items: center; justify-content: space-between;
  gap: var(--space-3); flex-wrap: wrap;
  margin-top: var(--space-3); padding-top: var(--space-3);
  border-top: 1px dashed var(--border);
}

/* --- Lupa: imagem grande sem sair da página --- */

.lupa {
  position: fixed; inset: 0; z-index: 500;
  display: none; align-items: center; justify-content: center;
  flex-direction: column; gap: var(--space-3);
  padding: var(--space-6);
  background: rgba(10, 12, 16, .88);
}

.lupa.aberta { display: flex; }
.lupa img { max-width: 92vw; max-height: 82vh; background: #fff;
  border-radius: var(--radius-md); box-shadow: var(--shadow-overlay); }
.lupa-nome { font-family: var(--fonte-mono); font-size: var(--t-sm); color: #d8dbe0; }

.lupa-fechar {
  position: absolute; top: var(--space-4); right: var(--space-5);
  width: 40px; height: 40px;
  border: 0; border-radius: 50%;
  background: rgba(255, 255, 255, .12); color: #fff;
  font-size: 24px; line-height: 1;
}

.lupa-fechar:hover { background: rgba(255, 255, 255, .24); }

.prova-link {
  border: 0; background: transparent; padding: 0;
  color: var(--bradesco-red); font-size: var(--t-sm); font-weight: 600;
  text-align: left; text-decoration: none;
  border-bottom: 1px dotted currentColor; width: fit-content;
  font-family: inherit; cursor: pointer;
}

.prova-link:hover { border-bottom-style: solid; }

.conferido {
  display: flex; align-items: center; gap: 8px;
  margin-top: var(--space-3); padding-top: var(--space-3);
  border-top: 1px dashed var(--border);
  font-size: var(--t-sm); color: var(--text-muted); cursor: pointer;
}

.conferido input { accent-color: var(--ok-fg); width: 15px; height: 15px; cursor: pointer; }

/* O apontamento conferido não some: fica registrado como verificado por
   pessoa. Some seria perder a informação de que alguém olhou. */
.apontamento.ja-conferido { opacity: .62; border-left-color: var(--ok-fg); }
.apontamento.ja-conferido .apontamento-rotulo { color: var(--ok-fg); }
.apontamento.ja-conferido .conferido { color: var(--ok-fg); font-weight: 600; }

.placar-conferencia {
  display: flex; align-items: center; justify-content: space-between;
  gap: var(--space-3); flex-wrap: wrap;
  margin: 0 0 var(--space-3);
  padding: 10px var(--space-3);
  border-radius: var(--radius-sm);
  background: var(--surface-2); color: var(--text-muted);
  font-size: var(--t-sm);
}

.btn-liberar {
  padding: 9px 18px; border: 0; border-radius: var(--radius-sm);
  background: var(--ok-fg); color: #fff;
  font-size: var(--t-sm); font-weight: 700; font-family: inherit;
}

.btn-liberar:hover { filter: brightness(1.08); }
.btn-liberar:active { transform: scale(.97); }

.placar-conferencia.completo {
  background: var(--aprovado-bg); color: var(--aprovado);
  border: 1px solid var(--aprovado-borda);
}

/* --- Diff HTML × CONTEUDO --- */

.diff {
  margin-top: var(--space-3);
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  overflow: hidden; background: var(--card-bg);
}

.diff-linha {
  display: flex; gap: var(--space-3);
  padding: 9px var(--space-3);
  font-size: var(--t-sm);
}

.diff-linha + .diff-linha { border-top: 1px solid var(--border); }
.diff-linha.docx { background: var(--surface-2); }

.diff-tag {
  flex: 0 0 92px;
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .06em;
  text-transform: uppercase; color: var(--text-dim); padding-top: 1px;
}

.diff-valor { flex: 1; min-width: 0; font-family: var(--fonte-mono); word-break: break-word; }

.nota {
  margin: var(--space-2) 0 0;
  font-size: var(--t-xs); color: var(--text-dim);
}

.nota code {
  font-family: var(--fonte-mono);
  padding: 1px 6px; border-radius: var(--radius-sm);
  background: var(--surface-3); color: var(--text-muted);
}

.nota b { color: var(--text-muted); }

/* ==============================================================================
   8. Estados, avisos e toast
   ============================================================================== */

.status-carregando {
  display: flex; align-items: center; gap: 11px;
  padding: 15px 18px;
  background: var(--card-bg);
  border: 1px solid var(--border); border-left: 3px solid var(--bradesco-red);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
  font-size: var(--t-base); color: var(--text-muted);
}

.status-carregando .pontos { display: inline-flex; gap: 4px; flex-shrink: 0; }

.status-carregando .pontos i {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--bradesco-red);
  animation: pulsar 1.1s ease-in-out infinite;
}

.status-carregando .pontos i:nth-child(2) { animation-delay: .18s; }
.status-carregando .pontos i:nth-child(3) { animation-delay: .36s; }

@keyframes pulsar {
  0%, 100% { opacity: .25; transform: scale(.8); }
  50%      { opacity: 1;   transform: scale(1); }
}

.status-texto { flex: 1; min-width: 0; }
.status-alvo { font-family: var(--fonte-mono); font-size: var(--t-sm); word-break: break-all; }

.cronometro {
  font-family: var(--fonte-mono); font-variant-numeric: tabular-nums;
  font-weight: 600; font-size: var(--t-sm);
  color: var(--text-dim); white-space: nowrap;
}

/* --- Estados vazio / erro --- */

.estado {
  display: flex; align-items: flex-start; gap: var(--space-3);
  padding: 40px 24px;
  background: var(--card-bg);
  border: 1px dashed var(--border-strong); border-radius: var(--radius-md);
}

.estado svg { width: 22px; height: 22px; flex-shrink: 0; color: var(--text-dim); }
.estado strong { display: block; font-size: var(--t-md); margin-bottom: 3px; color: var(--text); }
.estado p { margin: 0; font-size: var(--t-sm); color: var(--text-muted); }

.estado--erro {
  border-style: solid;
  border-color: var(--reprovado-borda);
  background: var(--reprovado-bg);
}

.estado--erro svg { color: var(--bradesco-red); }
html[data-theme="dark"] .estado--erro svg { color: var(--bradesco-red-light); }

/* --- Aviso em caixa --- */

.aviso {
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--atencao-borda); border-left: 3px solid var(--atencao);
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  background: var(--atencao-bg); color: var(--text);
  font-size: var(--t-sm);
}

.aviso + .aviso { margin-top: var(--space-2); }
.aviso b { font-weight: 800; }

.tudo-certo {
  display: flex; align-items: center; gap: 9px;
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--aprovado-borda); border-radius: var(--radius-sm);
  background: var(--aprovado-bg); color: var(--aprovado);
  font-size: var(--t-base); font-weight: 700;
}

.tudo-certo svg { width: 18px; height: 18px; flex-shrink: 0; }

/* --- Preview lado a lado --- */

.preview { border-top: 1px solid var(--border); background: var(--surface-2); }

.preview-abas {
  display: flex; align-items: center; gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--border);
  background: var(--card-bg);
  flex-wrap: wrap;
}

.preview-aba {
  padding: 7px 14px;
  border: 1px solid var(--border); border-radius: var(--radius-full);
  background: var(--card-bg); color: var(--text-muted);
  font-size: var(--t-sm); font-weight: 600;
  transition: border-color var(--transicao), color var(--transicao), background var(--transicao);
}

.preview-aba:hover { border-color: var(--bradesco-red); color: var(--bradesco-red); }

.preview-aba.ativa {
  background: var(--bradesco-red); border-color: var(--bradesco-red);
  color: #fff; font-weight: 700;
}

.preview-baixar {
  margin-left: auto;
  font-size: var(--t-xs); color: var(--text-dim);
  text-decoration: none; border-bottom: 1px dotted var(--border-strong);
}

.preview-baixar:hover { color: var(--bradesco-red); border-bottom-color: var(--bradesco-red); }

/* --- Busca cruzada --- */

.busca-cruzada {
  display: flex; align-items: center; gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--border);
  background: var(--card-bg);
  flex-wrap: wrap;
}

.busca-icone { width: 17px; height: 17px; color: var(--text-dim); flex-shrink: 0; }

.busca-campo {
  flex: 1; min-width: 200px;
  padding: 8px 12px;
  border: 1px solid var(--border); border-radius: var(--radius-sm);
  background: var(--surface-2); color: var(--text);
  font-size: var(--t-sm); font-family: inherit;
}

.busca-campo:focus {
  outline: none; border-color: var(--bradesco-red); background: var(--card-bg);
  box-shadow: 0 0 0 3px rgba(204, 9, 47, .08);
}

.busca-placar { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }

.busca-marca {
  padding: 3px 10px; border-radius: var(--radius-full);
  font-size: var(--t-xs); font-weight: 700;
}

.busca-marca.tem { background: var(--aprovado-bg); color: var(--aprovado); }
.busca-marca.nao-tem { background: var(--surface-3); color: var(--text-dim); }

/* O aviso só aparece quando o trecho está de um lado e falta do outro — que é
   exatamente o que a conferência procura. */
.busca-alerta {
  padding: 3px 10px; border-radius: var(--radius-full);
  background: var(--reprovado-bg); color: var(--reprovado);
  border: 1px solid var(--reprovado-borda);
  font-size: var(--t-xs); font-weight: 700;
}

.busca-limpar {
  border: 0; background: transparent; color: var(--text-dim);
  font-size: var(--t-xs); text-decoration: underline; padding: 4px;
}

.busca-limpar:hover { color: var(--bradesco-red); }

mark {
  background: var(--atencao-bg); color: var(--text);
  padding: 1px 2px; border-radius: 3px;
  box-shadow: inset 0 -2px 0 var(--atencao);
}

/* Dentro da citação, o trecho que diverge fica sublinhado em vermelho: a
   pessoa lê o parágrafo inteiro e enxerga na hora onde está a diferença, sem
   ter de cruzar com o quadro de baixo. */
mark.marca-divergencia {
  background: transparent; color: inherit;
  padding: 0; border-radius: 0;
  box-shadow: none;
  border-bottom: 2px solid var(--bradesco-red);
  font-weight: 700;
}

.apontamento.ja-conferido mark.marca-divergencia { border-bottom-color: var(--ok-fg); }

/* Bloco que não contém o trecho procurado desbota, para o que casa saltar aos
   olhos sem tirar o resto da tela. */
.leitura-bloco.sem-resultado,
.preview-paragrafo.sem-resultado { opacity: .32; }

.preview-paragrafo { cursor: pointer; transition: background var(--transicao); }
.preview-paragrafo:hover { background: var(--surface-2); border-radius: var(--radius-sm); }
.preview-conteudo-texto { flex: 1; min-width: 0; }

.leitura-vazia {
  font-size: var(--t-sm); color: var(--text-dim); font-style: italic;
}

/* --- Fita de leitura --- */

.preview-leitura-corpo {
  height: clamp(320px, 60vh, 820px);
  overflow-y: auto;
  padding: var(--space-4);
  background: var(--card-bg);
}

.leitura-bloco {
  padding: var(--space-3);
  border: 1px solid var(--border); border-left: 3px solid var(--border-strong);
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  margin-bottom: var(--space-2);
  background: var(--surface-2);
}

/* imagem tem a marca vermelha: é o trecho que passou por leitura automática,
   e portanto o que pode ter erro de reconhecimento */
.leitura-bloco.imagem { border-left-color: var(--bradesco-red); }

.leitura-cabeca {
  display: flex; align-items: baseline; justify-content: space-between;
  gap: var(--space-2); margin-bottom: 6px;
}

.leitura-origem {
  font-family: var(--fonte-mono); font-size: var(--t-xs);
  color: var(--text-dim); word-break: break-all;
}

.leitura-reordenado {
  display: inline-block; margin-left: 8px;
  padding: 1px 8px; border-radius: var(--radius-full);
  background: var(--surface-3); color: var(--text-muted);
  font-family: var(--fonte); font-size: 10.5px; font-weight: 700;
}

.leitura-confianca {
  font-family: var(--fonte-mono); font-size: var(--t-xs); font-weight: 700;
  color: var(--ok-fg); white-space: nowrap;
}

.leitura-confianca.baixa { color: var(--atencao); }

.leitura-texto {
  font-size: var(--t-base); line-height: 1.6;
  white-space: pre-wrap; word-break: break-word;
}


.leitura-aviso { margin: 6px 0 0; }

.preview-colunas {
  display: grid; grid-template-columns: 1fr 1fr; gap: 1px;
  background: var(--border);
}

.preview-coluna {
  display: flex; flex-direction: column;
  background: var(--card-bg);
  min-width: 0;
}

.preview-cabeca {
  padding: 10px var(--space-4);
  border-bottom: 1px solid var(--border);
  background: var(--surface-2);
  font-size: var(--t-xs); font-weight: 800; letter-spacing: .05em;
  text-transform: uppercase; color: var(--text-dim);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}

/* Altura fixa nas duas colunas: é o que permite rolar uma comparando com a
   outra, que é como a conferência é feita hoje com duas janelas abertas. */
/* Acompanha a altura da tela: em notebook 1366x768 uma altura fixa de 620px
   empurra o rodapé para fora, e em monitor grande sobra espaço à toa. */
.preview-palco,
.preview-texto-corpo { height: clamp(320px, 60vh, 820px); }

/* O palco recorta a peça reduzida; a rolagem acontece dentro do iframe. */
.preview-palco { overflow: hidden; background: #fff; }

.preview iframe {
  border: 0; background: #fff;
  transform-origin: top left;
}

.preview-texto-corpo {
  overflow-y: auto; padding: var(--space-4) var(--space-5);
  font-size: var(--t-base); line-height: 1.75;
}

.preview-paragrafo {
  display: flex; gap: var(--space-3);
  margin: 0 0 var(--space-3);
  padding-bottom: var(--space-3);
  border-bottom: 1px dashed var(--border);
  word-break: break-word;
}

.preview-paragrafo:last-child { border-bottom: 0; }

.preview-numero {
  flex: 0 0 24px; height: 20px;
  display: grid; place-items: center;
  border-radius: var(--radius-sm); background: var(--surface-3);
  font-family: var(--fonte-mono); font-size: 10.5px; font-weight: 700;
  color: var(--text-dim);
}

.preview-dica { padding: var(--space-3) var(--space-5); margin: 0; }

.btn-preview.ativo {
  border-color: var(--bradesco-red); color: var(--bradesco-red);
  background: var(--bradesco-red-tenue);
}

/* o rótulo é longo para a coluna do mapa: quebra em duas linhas em vez de vazar */
.btn-workbench { white-space: normal; line-height: 1.25; }

/* --- Link do relatório --- */

.rodape-resultado {
  display: flex; align-items: center; justify-content: space-between; gap: var(--space-3);
  flex-wrap: wrap;
  padding: var(--space-4) var(--space-5);
  border-top: 1px solid var(--border);
  background: var(--surface-2);
}

.link-relatorio {
  display: inline-flex; align-items: center; gap: 8px;
  color: var(--bradesco-red); font-size: var(--t-sm); font-weight: 800;
  text-decoration: none;
  transition: gap var(--transicao);
}

.link-relatorio svg { width: 16px; height: 16px; }
.link-relatorio:hover { gap: 12px; text-decoration: underline; text-underline-offset: 3px; }

/* --- Toast --- */

.toast {
  position: fixed; top: 84px; right: var(--space-6); z-index: var(--z-toast);
  display: flex; align-items: center; gap: 10px;
  max-width: 380px;
  padding: 13px 17px;
  background: var(--card-bg);
  border: 1px solid var(--border); border-left: 3px solid var(--bradesco-red);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-raised);
  font-size: var(--t-sm);
  opacity: 0; transform: translateX(20px);
  pointer-events: none;
  transition: opacity var(--transicao), transform var(--transicao);
}

.toast.visivel { opacity: 1; transform: translateX(0); }
.toast.ok { border-left-color: var(--ok-fg); }

/* ==============================================================================
   9. Rodapé de motor de leitura
   ============================================================================== */

.barra-motor {
  display: flex; align-items: flex-start; gap: 9px;
  margin-top: var(--space-4); padding-top: var(--space-4);
  border-top: 1px dashed var(--border);
  font-size: var(--t-xs); color: var(--text-dim);
}

.barra-motor svg { width: 15px; height: 15px; flex-shrink: 0; margin-top: 1px; }
.barra-motor.ativo svg { color: var(--ok-fg); }
.barra-motor.inativo svg { color: var(--warn-fg); }
.barra-motor b { color: var(--text-muted); font-weight: 700; }
.barra-motor ul { margin: 7px 0 0; padding-left: 18px; }
.barra-motor li { margin: 3px 0; }
.barra-motor code {
  font-family: var(--fonte-mono);
  padding: 1px 6px; border-radius: var(--radius-sm);
  background: var(--surface-3); color: var(--text-muted);
}

/* ==============================================================================
   10. Responsivo, movimento e impressão
   ============================================================================== */

@media (max-width: 1100px) {
  .resultado { grid-template-columns: 1fr; }
  .resultado-mapa {
    position: static; max-height: none;
    border-right: 0; border-bottom: 1px solid var(--border);
  }
  .mapa-numeros { grid-template-columns: repeat(4, 1fr); }
}

@media (max-width: 900px) {
  .header-inner, .app-main { padding-left: var(--space-4); padding-right: var(--space-4); }
  .numeros { gap: var(--space-5); }
  .mapa-numeros { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 640px) {
  .app-main { padding-top: var(--space-5); }
  .abas { flex-direction: column; }
  .brand-eyebrow { display: none; }
  .solta { padding: 32px var(--space-4); }
  .diff-linha { flex-direction: column; gap: 4px; }
  .citacoes, .confronto { grid-template-columns: 1fr; }
  .apontamento-corpo { flex-direction: column; }
  .prova { flex: none; width: 100%; }
  .preview-colunas { grid-template-columns: 1fr; }
  .preview-palco, .preview-texto-corpo,
  .preview-leitura-corpo { height: clamp(280px, 46vh, 460px); }
  .preview-baixar { margin-left: 0; width: 100%; }
  .campo-email { flex-direction: column; gap: 4px; }
  .campo-rotulo { flex: none; }
  .diff-tag { flex: none; }
  .acoes .btn-primary { width: 100%; }
  .indice-linha { flex-wrap: wrap; gap: var(--space-2); }
  .indice-nome { flex: 1 0 100%; order: -1; white-space: normal; }
  .lote-rodando {
  display: inline-block; margin-left: 10px;
  padding: 3px 11px; border-radius: var(--radius-full);
  background: var(--atencao-bg); color: var(--atencao);
  font-size: var(--t-xs); font-weight: 700;
  animation: piscar 1.4s ease-in-out infinite;
}

@keyframes piscar { 0%, 100% { opacity: 1; } 50% { opacity: .45; } }

.lote-placar { width: 100%; }
  .toast {
    top: auto; bottom: var(--space-4);
    left: var(--space-4); right: var(--space-4); max-width: none;
    transform: translateY(20px);
  }
  .toast.visivel { transform: translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
    scroll-behavior: auto !important;
  }
  .loader { transition: none; }
}

@media print {
  .loader, .app-header, .scan-panel, .toast, .rodape-resultado { display: none !important; }
  body { background: #fff; }
  .resultado, .panel { break-inside: avoid; box-shadow: none; }
}
'''

_JS_VALIDADOR = r'''/* ==============================================================================
 * Validador de pacotes EMKT — Bradesco · CRM · Publicação e Orquestração
 * ==============================================================================
 * Organização:
 *   1. Utilitários            4. Envio da conferência
 *   2. Tema claro/escuro      5. Desenho de um pacote
 *   3. Abas de entrada        7. Motor de leitura de imagens
 *   4. Arrastar a pasta       8. Inicialização
 * ============================================================================== */

(function () {
  'use strict';

  /* ============================================================================
     1. Utilitários
     ========================================================================== */

  const $ = (sel) => document.querySelector(sel);

  /** Última resposta do servidor, guardada para reordenar o lote sem precisar
   *  conferir tudo de novo — reler dez pacotes por causa de um clique em
   *  "ordenar" seria absurdo. */
  let ultimaConferencia = null;
  let ordenacaoAtual = 'pior';

  /** Escapa antes de injetar no HTML: nome de arquivo e texto de peça vêm de
   *  fora e podem conter < e &. */
  function esc(valor) {
    return String(valor == null ? '' : valor)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  let timerToast = null;

  function toast(mensagem, tipo) {
    const caixa = $('#toast');
    if (!caixa) return;
    caixa.className = 'toast' + (tipo === 'ok' ? ' ok' : '');
    caixa.textContent = mensagem;
    requestAnimationFrame(() => caixa.classList.add('visivel'));
    clearTimeout(timerToast);
    timerToast = setTimeout(() => caixa.classList.remove('visivel'), 4200);
  }

  /* ============================================================================
     2. Tema claro/escuro
     ========================================================================== */

  const CHAVE_TEMA = 'bradesco_validador_emkt_theme';

  function aplicarTema(tema) {
    document.documentElement.setAttribute('data-theme', tema);
    const escuro = tema === 'dark';
    $('#theme-icon-moon').classList.toggle('hidden', escuro);
    $('#theme-icon-sun').classList.toggle('hidden', !escuro);
    $('#theme-label').textContent = escuro ? 'Claro' : 'Escuro';
    try { localStorage.setItem(CHAVE_TEMA, tema); } catch (e) { /* bloqueado: segue */ }
  }

  function ligarTema() {
    const atual = document.documentElement.getAttribute('data-theme') || 'light';
    aplicarTema(atual);
    $('#btn-theme-toggle').addEventListener('click', () => {
      const agora = document.documentElement.getAttribute('data-theme');
      aplicarTema(agora === 'dark' ? 'light' : 'dark');
    });
  }

  /* ============================================================================
     3. Arrastar a pasta
     ========================================================================== */

  let arquivosSelecionados = null;

  function registrarArquivos(lista) {
    arquivosSelecionados = Array.prototype.slice.call(lista);
    const caixa = $('#solta-lista');
    if (!arquivosSelecionados.length) {
      caixa.classList.remove('visivel');
      return;
    }
    const primeiro = arquivosSelecionados[0];
    const relativo = primeiro.caminhoRelativo || primeiro.webkitRelativePath || '';
    const nome = relativo.split('/')[0] || 'pacote';
    // conta as subpastas de primeiro nível: dá uma prévia de quantos pacotes
    // devem sair, antes mesmo de enviar
    const subpastas = new Set();
    arquivosSelecionados.forEach((a) => {
      const partes = (a.caminhoRelativo || a.webkitRelativePath || '').split('/');
      if (partes.length > 2) subpastas.add(partes[1]);
    });
    const previa = subpastas.size > 1
      ? ' · possivelmente ' + subpastas.size + ' pacotes'
      : '';
    caixa.innerHTML = '<b>' + esc(nome) + '</b> · ' + arquivosSelecionados.length +
      ' arquivo(s)' + previa;
    caixa.classList.add('visivel');
  }

  /** Percorre a árvore da pasta arrastada. O input comum só entrega arquivos
   *  soltos; a API de entradas preserva as subpastas, que é onde ficam as
   *  imagens. */
  function percorrer(entrada, caminho, coletados) {
    return new Promise((resolve) => {
      if (entrada.isFile) {
        entrada.file((arquivo) => {
          Object.defineProperty(arquivo, 'caminhoRelativo', { value: caminho });
          coletados.push(arquivo);
          resolve();
        }, resolve);
        return;
      }
      const leitor = entrada.createReader();
      const todos = [];
      const ler = () => leitor.readEntries(async (filhos) => {
        if (!filhos.length) {
          for (const filho of todos) {
            await percorrer(filho, caminho + '/' + filho.name, coletados);
          }
          resolve();
          return;
        }
        todos.push.apply(todos, filhos);
        ler();
      }, resolve);
      ler();
    });
  }

  function ligarArrastar() {
    const area = $('#area-solta');
    const seletor = $('#seletor');

    area.addEventListener('click', () => seletor.click());
    area.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); seletor.click(); }
    });
    seletor.addEventListener('change', (e) => registrarArquivos(e.target.files));

    ['dragenter', 'dragover'].forEach((evento) =>
      area.addEventListener(evento, (e) => { e.preventDefault(); area.classList.add('sobre'); }));
    ['dragleave', 'drop'].forEach((evento) =>
      area.addEventListener(evento, (e) => { e.preventDefault(); area.classList.remove('sobre'); }));

    area.addEventListener('drop', async (e) => {
      const itens = e.dataTransfer && e.dataTransfer.items;
      if (!itens || !itens.length) return;
      const entrada = itens[0].webkitGetAsEntry && itens[0].webkitGetAsEntry();
      if (!entrada || !entrada.isDirectory) {
        toast('Arraste a pasta inteira do pacote, não um arquivo solto.');
        return;
      }
      const coletados = [];
      await percorrer(entrada, entrada.name, coletados);
      registrarArquivos(coletados);
    });
  }

  /* ============================================================================
     4. Envio da conferência
     ========================================================================== */

  let inicioContagem = 0;
  let timerContagem = null;

  function mostrarCarregando(lendoImagens) {
    inicioContagem = Date.now();
    $('#status-area').innerHTML =
      '<div class="status-carregando">' +
        '<span class="pontos" aria-hidden="true"><i></i><i></i><i></i></span>' +
        '<span class="status-texto">' +
          '<span class="status-alvo">' +
            (lendoImagens ? 'Conferindo o pacote e lendo o texto das imagens…'
                          : 'Conferindo o pacote…') +
          '</span>' +
        '</span>' +
        '<span class="cronometro" id="cronometro">0,0s</span>' +
      '</div>';

    clearInterval(timerContagem);
    timerContagem = setInterval(() => {
      const alvo = $('#cronometro');
      if (!alvo) return;
      const s = (Date.now() - inicioContagem) / 1000;
      alvo.textContent = s.toFixed(1).replace('.', ',') + 's';
    }, 100);
  }

  /** Troca só o texto da barra, mantendo o cronômetro correndo. */
  function atualizarCarregando(texto) {
    const alvo = document.querySelector('.status-alvo');
    if (alvo) alvo.textContent = texto;
  }

  function pararCarregando() {
    clearInterval(timerContagem);
    $('#status-area').innerHTML = '';
  }

  function estadoErro(mensagem) {
    return '<div class="estado estado--erro">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" ' +
        'stroke-linecap="round" stroke-linejoin="round">' +
        '<circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><path d="M12 16.5h.01"/></svg>' +
      '<div><strong>Não deu para conferir</strong><p>' + esc(mensagem) + '</p></div></div>';
  }

  async function conferir() {
    const botao = $('#btn-conferir');
    const rotulo = $('#btn-conferir-rotulo');
    const alvo = $('#resultados');
    const usarOcr = $('#usar-ocr').checked;

    if (!arquivosSelecionados || !arquivosSelecionados.length) {
      toast('Escolha ou arraste a pasta primeiro.');
      return;
    }

    botao.disabled = true;
    rotulo.textContent = 'Conferindo…';
    $('#btn-spinner').hidden = false;
    alvo.innerHTML = '';
    mostrarCarregando(usarOcr);

    try {
      const envio = new FormData();
      for (const arquivo of arquivosSelecionados) {
        const relativo = arquivo.caminhoRelativo || arquivo.webkitRelativePath || arquivo.name;
        envio.append('arquivos', arquivo, relativo);
      }
      envio.append('usar_ocr', usarOcr ? 'true' : 'false');
      const seletor = $('#motor');
      if (seletor && seletor.value) envio.append('motor', seletor.value);

      // Lê a resposta conforme ela chega, em vez de esperar o fim: num lote,
      // o primeiro pacote aparece em segundos e já dá para começar a reportar
      // enquanto os outros rodam.
      const resposta = await fetch('/api/conferir-em-fluxo', { method: 'POST', body: envio });
      if (!resposta.ok || !resposta.body) {
        pararCarregando();
        alvo.innerHTML = estadoErro('Falha na conferência.');
        return;
      }

      const leitor = resposta.body.getReader();
      const decodificador = new TextDecoder();
      let sobra = '';
      let recebidos = [];
      let cabecalho = null;

      for (;;) {
        const { done, value } = await leitor.read();
        if (done) break;
        sobra += decodificador.decode(value, { stream: true });
        const linhas = sobra.split('\n');
        sobra = linhas.pop();          // a última pode estar pela metade

        for (const linha of linhas) {
          if (!linha.trim()) continue;
          let evento;
          try { evento = JSON.parse(linha); } catch (e) { continue; }

          if (evento.tipo === 'erro') {
            pararCarregando();
            alvo.innerHTML = estadoErro(evento.erro);
            return;
          }
          if (evento.tipo === 'inicio') {
            cabecalho = evento;
            atualizarCarregando(evento.total > 1
              ? 'Conferindo ' + evento.total + ' pacotes…'
              : 'Conferindo o pacote…');
          }
          if (evento.tipo === 'andamento') {
            atualizarCarregando(
              (cabecalho && cabecalho.total > 1
                ? 'Pacote ' + evento.posicao + ' de ' + cabecalho.total + ': '
                : '') + evento.nome);
          }
          if (evento.tipo === 'pacote') {
            recebidos.push(evento.resultado);
            ultimaConferencia = {
              modo: cabecalho ? cabecalho.modo : 'unico',
              origem: cabecalho ? cabecalho.origem : '',
              total: cabecalho ? cabecalho.total : recebidos.length,
              resultados: recebidos,
              parcial: recebidos.length < (cabecalho ? cabecalho.total : 1),
            };
            renderizar();
          }
          if (evento.tipo === 'falha') {
            recebidos.push({
              id: 'falha-' + recebidos.length, nome_pasta: evento.nome,
              status: 'erro', erros: [evento.erro], observacoes: [],
              imagens: { apontamentos: [], total_pasta: 0, total_chamadas_html: 0 },
              texto: { divergencias: [], similaridade: 0, sem_leitura: [] },
            });
          }
        }
      }

      pararCarregando();
      if (ultimaConferencia) {
        ultimaConferencia.parcial = false;
        renderizar();
      }

      const reprovados = recebidos.filter((r) => r.status === 'reprovado').length;
      if (cabecalho && cabecalho.modo === 'lote') {
        toast(recebidos.length + ' pacotes conferidos · ' + reprovados + ' com divergência.',
              reprovados ? '' : 'ok');
      } else if (reprovados) {
        toast('Divergências encontradas. Veja os apontamentos abaixo.');
      } else {
        toast('Conferência concluída.', 'ok');
      }
    } catch (erro) {
      pararCarregando();
      alvo.innerHTML = estadoErro('Não consegui concluir: ' + erro.message);
    } finally {
      botao.disabled = false;
      rotulo.textContent = 'Conferir';
      $('#btn-spinner').hidden = true;
    }
  }

  /* ============================================================================
     5. Desenho de um pacote
     ========================================================================== */

  // Frases descritivas: a ferramenta relata o que encontrou de diferente entre
  // os arquivos. O que fazer com isso é decisão de quem produziu a campanha.
  const FRASES = {
    aprovado: 'Nenhuma divergência entre o HTML e o CONTEUDO.docx.',
    atencao: 'Pontos para o analista avaliar.',
    parcial: 'O texto do código confere. O que está dentro das imagens não foi conferido.',
    reprovado: 'Divergências encontradas entre o HTML e o CONTEUDO.docx.',
    erro: 'Não foi possível concluir a conferência.',
  };

  const ICONE_OK =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

  /** Mostra o texto com a contagem de caracteres. O limite não é proibitivo,
   *  então o excedente aparece em cinza-alerta, sem alarme. */
  function campoEmail(rotulo, texto, limite) {
    if (!texto) return '';
    const tamanho = texto.trim().length;
    const passou = limite && tamanho > limite;
    return '<div class="campo-email' + (passou ? ' passou' : '') + '">' +
      '<span class="campo-rotulo">' + esc(rotulo) + '</span>' +
      '<span class="campo-valor">' + esc(texto) + '</span>' +
      '<span class="campo-contagem" title="limite de referência: ' + limite +
        ' caracteres">' + tamanho + '/' + limite + '</span>' +
    '</div>';
  }

  function tudoCerto(texto) {
    return '<div class="tudo-certo">' + ICONE_OK + '<span>' + esc(texto) + '</span></div>';
  }

  function desenharApontamentosImagem(img) {
    if (!img.apontamentos.length) {
      return tudoCerto('Nomes seguem a quebra, sequência sem furo e todas as imagens aparecem no HTML.');
    }
    return '<ul class="lista-apontamentos">' + img.apontamentos.map((a) =>
      '<li class="apontamento ' + esc(a.gravidade) + '">' +
        '<span class="apontamento-rotulo">' + esc(a.rotulo) + '</span>' +
        esc(a.texto) +
      '</li>').join('') + '</ul>';
  }

  function desenharDivergencias(txt, r) {
    if (!txt.divergencias.length) {
      return tudoCerto('O CONTEUDO.docx e a leitura do HTML têm as mesmas palavras, na mesma ordem.');
    }

    return '<ul class="lista-apontamentos">' + txt.divergencias.map((d, indice) => {
      const ehImagem = /\.(png|jpe?g|gif|webp)$/i.test(d.origem || '');
      const chave = r.id + '|' + indice;

      // O nome da coluna diz de onde veio o texto. "Como está no HTML" dava a
      // entender que era o código; quando a origem é imagem, aquilo é o que a
      // MÁQUINA leu — e é justamente o que pode estar errado.
      const rotuloLeitura = ehImagem
        ? 'O que o sistema leu da imagem'
        : 'O que o sistema leu do código';

      // Sublinha, dentro da citação inteira, exatamente o trecho que diverge.
      // Sem isso a pessoa lia o parágrafo todo procurando onde estava a
      // diferença que o quadro de baixo já tinha apontado.
      const ladoLeitura = destacar(d.citacao_html || d.trecho_html || '',
                                   d.trecho_html, 'marca-divergencia');
      const ladoDocx = destacar(d.citacao_docx || d.trecho_docx || '',
                                d.trecho_docx, 'marca-divergencia');

      const comparacao =
        '<div class="confronto">' +
          '<div class="confronto-lado">' +
            '<span class="confronto-titulo maquina">' + rotuloLeitura + '</span>' +
            '<blockquote>' + (ladoLeitura.html || '—') + '</blockquote>' +
          '</div>' +
          '<div class="confronto-lado">' +
            '<span class="confronto-titulo">Como está no CONTEUDO.docx</span>' +
            '<blockquote>' + (ladoDocx.html || '—') + '</blockquote>' +
          '</div>' +
        '</div>';

      const trechoDiff =
        '<div class="diff">' +
          '<div class="diff-linha html"><span class="diff-tag">Leitura</span>' +
            '<span class="diff-valor">' + (esc(d.trecho_html) || '—') + '</span></div>' +
          '<div class="diff-linha docx"><span class="diff-tag">CONTEUDO</span>' +
            '<span class="diff-valor">' + (esc(d.trecho_docx) || '—') + '</span></div>' +
        '</div>';

      let nota = '';
      if (d.palavras_ausentes) {
        nota = '<p class="nota"><b>Palavras que faltam no docx:</b> <code>' +
          esc(d.palavras_ausentes) + '</code></p>';
      } else if (d.contexto_antes || d.contexto_depois) {
        nota = '<p class="nota">Contexto: <code>' + esc(d.contexto_antes) +
          '</code> … <code>' + esc(d.contexto_depois) + '</code></p>';
      }

      // A imagem ao lado da comparação é a conferência humana: é olhando o
      // banner que se decide se o texto divergente está na peça ou se foi a
      // leitura que errou.
      const painelImagem = ehImagem
        ? '<div class="prova">' +
            '<span class="confronto-titulo">O que está na imagem</span>' +
            '<img src="/preview/' + esc(r.id) + '/imagem/' + encodeURIComponent(d.origem) +
              '" alt="' + esc(d.origem) + '" loading="lazy" class="prova-imagem" ' +
              'data-ampliar="' + esc(d.origem) + '" data-id="' + esc(r.id) + '">' +
            '<span class="prova-dica">clique para ampliar</span>' +
          '</div>'
        : '';

      const acoes =
        '<div class="apontamento-acoes">' +
          '<button type="button" class="prova-link" data-ir-peca="' + esc(r.id) + '" ' +
            'data-alvo="' + esc(d.origem) + '" data-texto="' +
            esc(d.trecho_html || '') + '">ver este ponto na peça</button>' +
          '<label class="conferido">' +
            '<input type="checkbox" class="conferido-marca" data-chave="' + esc(chave) +
              '" data-grave="' + (d.gravidade === 'alta' ? '1' : '0') + '">' +
            '<span>Conferi manualmente — a peça está correta</span>' +
          '</label>' +
        '</div>';

      return '<li class="apontamento ' + esc(d.gravidade) + '" data-tipo="' +
        esc(d.tipo) + '" data-chave="' + esc(chave) + '">' +
        '<div class="apontamento-cabeca">' +
          '<span class="apontamento-rotulo">' + esc(d.rotulo) + '</span>' +
          'em <span class="arquivo">' + esc(d.origem) + '</span>' +
          (d.bloco ? '<span class="marca-bloco">' + esc(d.bloco) + '</span>' : '') +
          (d.tolerado ? '<span class="marca-tolerado">diferença esperada · não reprova</span>' : '') +
        '</div>' +
        '<div class="apontamento-corpo' + (ehImagem ? ' com-imagem' : '') + '">' +
          painelImagem +
          '<div class="apontamento-texto">' + comparacao + trechoDiff + nota + '</div>' +
        '</div>' +
        acoes +
      '</li>';
    }).join('') + '</ul>';
  }

  function desenhar(r, posicao) {
    if (r.erros && r.erros.length) {
      return '<article class="resultado" data-status="erro">' +
        '<div class="resultado-topo">' +
          '<span class="selo erro">Erro</span>' +
          '<span class="resultado-identidade">' +
            '<span class="resultado-pasta">' + esc(r.nome_pasta) + '</span>' +
          '</span>' +
        '</div>' +
        '<div class="bloco">' + r.erros.map((e) =>
          '<div class="aviso">' + esc(e) + '</div>').join('') + '</div>' +
      '</article>';
    }

    const img = r.imagens;
    const txt = r.texto;
    const parcial = r.modo_texto === 'presenca';

    // Bloqueio abre o resultado: são as regras de publicação do banco, e sem
    // elas a peça não sobe. Vem antes de qualquer divergência de texto.
    const bloqueios = (r.bloqueios && r.bloqueios.length)
      ? '<div class="bloco bloco-bloqueio"><h3>Impede a publicação ' +
        '<span class="qtd">· ' + r.bloqueios.length + '</span></h3>' +
        '<ul class="lista-apontamentos">' + r.bloqueios.map((b) =>
          '<li class="apontamento alta bloqueio">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
              'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/>' +
              '<path d="M12 8v5"/><path d="M12 16.5h.01"/></svg>' +
            '<span>' + esc(b) + '</span></li>').join('') + '</ul></div>'
      : '';

    // Alerta é discreto de propósito: passar do limite de caracteres não
    // proíbe nada, só corta na caixa de entrada de alguns clientes.
    const alertas = (r.alertas && r.alertas.length)
      ? '<p class="alertas-sutis">' + r.alertas.map(esc).join(' · ') + '</p>'
      : '';

    const cabecalhoEmail = (r.assunto || r.pre_header)
      ? '<div class="bloco"><h3>Assunto e pré-header</h3>' +
        '<div class="campos-email">' +
          campoEmail('Assunto', r.assunto, r.limite_assunto) +
          campoEmail('Pré-header', r.pre_header, r.limite_pre_header) +
        '</div>' + alertas + '</div>'
      : '';

    const avisoModo = parcial
      ? '<div class="bloco"><div class="aviso"><b>Conferência parcial.</b> ' +
        'Sem a leitura de imagens, comparei apenas o texto escrito no código do HTML ' +
        'contra o CONTEUDO.docx — ' + txt.blocos_conferidos + ' bloco(s). O texto que ' +
        'está dentro dos banners não entrou na conta, e por isso nada que sobra no docx ' +
        'foi cobrado.</div></div>'
      : '';

    // Arte de conferência que a agência manda junto: não é peça publicada.
    // Aparece como nota para deixar claro que o sistema viu e desconsiderou.
    const apoio = (img.material_de_apoio && img.material_de_apoio.length)
      ? '<p class="nota"><b>Fora da conferência</b> (arte de apoio, não é chamada ' +
        'no código): ' + img.material_de_apoio.map((m) =>
          '<span class="arquivo">' + esc(m[0]) + '</span> — ' + esc(m[1])).join('; ') + '</p>'
      : '';

    const repetidas = Object.keys(img.reaproveitadas || {}).length
      ? '<p class="nota">Reaproveitadas no HTML (permitido): ' +
        Object.keys(img.reaproveitadas).map((n) =>
          esc(n) + ' (' + img.reaproveitadas[n] + 'x)').join(', ') + '</p>'
      : '';

    const correcoes = (txt.correcoes_ocr && txt.correcoes_ocr.length)
      ? '<p class="nota"><b>Corrigido na leitura das imagens</b> (palavra colada ou ' +
        'caractere confundido): ' + txt.correcoes_ocr.map(esc).join('; ') + '</p>'
      : '';

    // A reordenação precisa ficar visível: o sistema mudou a ordem da leitura
    // por conta própria, e quem confere tem direito de saber disso.
    const reordenadas = (txt.imagens_reordenadas && txt.imagens_reordenadas.length)
      ? '<p class="nota"><b>Ordem ajustada pelo CONTEUDO.docx</b> em ' +
        txt.imagens_reordenadas.map((n) =>
          '<span class="arquivo">' + esc(n) + '</span>').join(', ') +
        '. Dentro de uma imagem com blocos não existe ordem de leitura única, ' +
        'então vale a sequência que o docx escreveu. Só acontece quando todo o ' +
        'texto da imagem foi encontrado lá.</p>'
      : '';

    const dispensados = (txt.dispensados && txt.dispensados.length)
      ? '<p class="nota">Ignorado por ser texto de template: ' +
        txt.dispensados.map(esc).join('; ') + '</p>'
      : '';

    const semLeitura = txt.sem_leitura.length
      ? '<div class="bloco"><h3>Imagens não lidas ' +
        '<span class="qtd">· ' + txt.sem_leitura.length + ' de ' + img.total_pasta + '</span></h3>' +
        '<div class="aviso">O texto dentro destas imagens não foi conferido. ' +
        'Confira no olho: ' + txt.sem_leitura.map((s) =>
          '<span class="arquivo">' + esc(s) + '</span>').join(' ') + '</div></div>'
      : '';

    const observacoes = r.observacoes.length
      ? '<div class="bloco"><h3>Observações</h3>' +
        r.observacoes.map((o) => '<div class="aviso">' + esc(o) + '</div>').join('') + '</div>'
      : '';

    // --- mapa lateral: o que existe neste pacote, em números clicáveis ---
    const secoes = [];
    if (r.bloqueios && r.bloqueios.length) {
      secoes.push(['bloqueios', 'Impede a publicação', r.bloqueios.length, 'grave']);
    }
    if (r.assunto || r.pre_header) secoes.push(['email', 'Assunto e pré-header', '', '']);
    secoes.push(['imagens', 'Imagens', img.apontamentos.length,
                 img.apontamentos.length ? 'grave' : 'ok']);
    const graves = txt.divergencias.filter((d) => d.gravidade === 'alta').length;
    secoes.push(['texto', 'Texto', txt.divergencias.length,
                 graves ? 'grave' : (txt.divergencias.length ? 'aviso' : 'ok')]);
    if (r.tem_preview) secoes.push(['comparar', 'Comparar lado a lado', '', '']);
    const quantosAvisos = (txt.sem_leitura.length ? 1 : 0) + r.observacoes.length +
      (r.alertas ? r.alertas.length : 0);
    if (quantosAvisos) secoes.push(['avisos', 'Avisos', quantosAvisos, 'aviso']);

    const mapa =
      '<aside class="resultado-mapa">' +
        '<div class="mapa-topo">' +
          '<span class="selo ' + esc(r.status) + '">' + esc(r.status) + '</span>' +
          '<span class="resultado-pasta">' + esc(r.nome_pasta) + '</span>' +
          (r.quebra ? '<span class="resultado-quebra">quebra: ' + esc(r.quebra) +
            '</span>' : '') +
        '</div>' +
        '<p class="mapa-frase">' + (FRASES[r.status] || '') + '</p>' +
        '<dl class="mapa-numeros">' +
          '<div><dt>imagens</dt><dd>' + img.total_pasta + '</dd></div>' +
          '<div><dt>chamadas</dt><dd>' + img.total_chamadas_html + '</dd></div>' +
          '<div><dt>aderência</dt><dd>' + txt.similaridade + '%</dd></div>' +
          '<div><dt>redirects</dt><dd>' + r.redirects + '</dd></div>' +
        '</dl>' +
        '<nav class="mapa-secoes">' +
          secoes.map(([chave, rotulo, valor, estado]) =>
            '<button type="button" class="mapa-item ' + estado + '" ' +
              'data-secao="' + esc(r.id + '-' + chave) + '">' +
              '<span>' + rotulo + '</span>' +
              (valor === '' ? '' : '<b>' + valor + '</b>') +
            '</button>').join('') +
        '</nav>' +
        '<div class="mapa-rodape">' +
          (r.tem_preview
            ? '<button type="button" class="btn-ghost btn-preview" data-preview="' +
              esc(r.id) + '"><span class="preview-rotulo">Comparar lado a lado</span></button>'
            : '') +
          (r.tem_preview
            ? '<button type="button" class="btn-ghost btn-workbench" data-workbench="' +
              esc(r.id) + '" title="Leva o HTML deste pacote para o editor da aba SFMC ' +
              'Workbench, sem copiar e colar.">Abrir o HTML deste pacote no Workbench</button>'
            : '') +
          '<a class="link-relatorio" href="/relatorio/' + esc(r.id) + '" target="_blank" ' +
            'rel="noopener">Relatório para o chamado</a>' +
          (r.motor_ocr ? '<span class="mapa-motor">leitura por ' + esc(r.motor_ocr) +
            '</span>' : '') +
        '</div>' +
      '</aside>';

    const blocoEmail = (r.assunto || r.pre_header)
      ? '<section class="bloco" id="' + esc(r.id) + '-email"><h3>Assunto e pré-header</h3>' +
        '<div class="campos-email">' +
          campoEmail('Assunto', r.assunto, r.limite_assunto) +
          campoEmail('Pré-header', r.pre_header, r.limite_pre_header) +
        '</div>' + alertas + '</section>'
      : '';

    // Avisos ficam DEPOIS da comparação: eles não impedem nada, e no topo só
    // empurravam para baixo o que a pessoa precisa decidir.
    const blocoAvisos = quantosAvisos
      ? '<section class="bloco bloco-avisos" id="' + esc(r.id) + '-avisos">' +
        '<h3>Avisos <span class="qtd">· não impedem a publicação</span></h3>' +
        semLeitura + observacoes + '</section>'
      : '';

    return '<article class="resultado" id="pacote-' + esc(r.id) + '" data-status="' +
      esc(r.status) + '">' +
      mapa +
      '<div class="resultado-conteudo">' +
        (posicao ? '<span class="resultado-ordem">' + posicao + '</span>' : '') +
        bloqueios + avisoModo + blocoEmail +
        '<section class="bloco" id="' + esc(r.id) + '-imagens"><h3>Imagens</h3>' +
          desenharApontamentosImagem(img) + repetidas + apoio + '</section>' +
        '<section class="bloco" id="' + esc(r.id) + '-texto"><h3>Texto ' +
          '<span class="qtd">· ' +
          (parcial ? 'só o texto do HTML × CONTEUDO.docx'
                   : 'HTML + imagens × CONTEUDO.docx') + '</span></h3>' +
          desenharDivergencias(txt, r) + reordenadas + correcoes + dispensados +
        '</section>' +
        '<div id="' + esc(r.id) + '-comparar">' + blocoPreview(r) + '</div>' +
        blocoAvisos +
      '</div>' +
    '</article>';
  }



  /* ============================================================================
     6d. Conferência manual e navegação até o ponto
     ========================================================================== */

  /** Divergências que a pessoa já olhou e considerou certas na peça. */
  const conferidos = {};

  function aplicarConferido(marca) {
    const item = marca.closest('.apontamento');
    if (item) item.classList.toggle('ja-conferido', marca.checked);
  }

  /**
   * Mostra quantos apontamentos já passaram pelo olho humano.
   *
   * Num pacote onde a leitura das imagens saiu ruim, a lista de divergências
   * vira fila de trabalho: o contador diz o que falta olhar, e o que já foi
   * olhado não some — fica registrado como verificado.
   */
  function atualizarPlacarConferencia() {
    document.querySelectorAll('.resultado').forEach((cartao) => {
      const marcas = cartao.querySelectorAll('.conferido-marca');
      const feitas = cartao.querySelectorAll('.conferido-marca:checked').length;
      let placar = cartao.querySelector('.placar-conferencia');
      if (!marcas.length) { if (placar) placar.remove(); return; }
      if (!placar) {
        placar = document.createElement('div');
        placar.className = 'placar-conferencia';
        const destino = cartao.querySelector('.mapa-rodape');
        if (destino) destino.insertBefore(placar, destino.firstChild);
      }

      // Só o que reprova precisa de conferência para liberar o pacote; o que
      // já era aviso continua aviso.
      const graves = cartao.querySelectorAll('.conferido-marca[data-grave="1"]');
      const gravesFeitas = cartao.querySelectorAll(
        '.conferido-marca[data-grave="1"]:checked').length;
      const podeLiberar = graves.length > 0 && gravesFeitas === graves.length;
      const jaLiberado = cartao.dataset.liberado === '1';

      let texto = feitas + ' de ' + marcas.length + ' conferidos manualmente';
      if (feitas === marcas.length) {
        texto = '<b>Todos os ' + marcas.length + ' apontamentos conferidos.</b>';
      }
      placar.innerHTML = '<span>' + texto + '</span>' +
        ((podeLiberar && !jaLiberado)
          ? '<button type="button" class="btn-liberar">Confirmar e liberar</button>'
          : '');
      placar.classList.toggle('completo', feitas === marcas.length);

      const acao = placar.querySelector('.btn-liberar');
      if (acao) acao.addEventListener('click', () => liberarPacote(cartao));
    });
  }

  /**
   * Muda o veredito depois que a pessoa conferiu tudo que reprovava.
   *
   * O selo não vira um APROVADO comum: vira "aprovado após conferência". Quem
   * ler o relatório depois precisa saber que a liberação passou por decisão de
   * alguém, e não pela máquina ter achado tudo certo.
   */
  function liberarPacote(cartao) {
    const graves = cartao.querySelectorAll('.conferido-marca[data-grave="1"]');
    const feitas = cartao.querySelectorAll('.conferido-marca[data-grave="1"]:checked');
    if (!graves.length || graves.length !== feitas.length) return;

    cartao.dataset.liberado = '1';
    cartao.dataset.status = 'aprovado';
    const selo = cartao.querySelector('.mapa-topo .selo');
    if (selo) {
      selo.className = 'selo aprovado';
      selo.textContent = 'aprovado após conferência';
    }
    const frase = cartao.querySelector('.mapa-frase');
    if (frase) {
      frase.innerHTML = '<b>Liberado por conferência manual.</b> ' + graves.length +
        ' divergência(s) verificadas por pessoa e consideradas corretas na peça.';
    }
    atualizarPlacarConferencia();
    toast('Pacote liberado por conferência manual.', 'ok');
  }

  /**
   * Mostra a imagem em tamanho grande sem sair da página.
   *
   * Abrir em outra aba tirava a pessoa de onde ela está conferindo, e voltar
   * custava perder a rolagem da lista.
   */
  function ampliarImagem(id, nome) {
    let caixa = document.getElementById('lupa');
    if (!caixa) {
      caixa = document.createElement('div');
      caixa.id = 'lupa';
      caixa.className = 'lupa';
      caixa.innerHTML = '<button type="button" class="lupa-fechar" ' +
        'aria-label="Fechar">&times;</button><img alt=""><span class="lupa-nome"></span>';
      document.body.appendChild(caixa);
      const fechar = () => caixa.classList.remove('aberta');
      caixa.addEventListener('click', (e) => { if (e.target === caixa) fechar(); });
      caixa.querySelector('.lupa-fechar').addEventListener('click', fechar);
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fechar(); });
    }
    caixa.querySelector('img').src = '/preview/' + id + '/imagem/' + encodeURIComponent(nome);
    caixa.querySelector('.lupa-nome').textContent = nome;
    caixa.classList.add('aberta');
  }

  /**
   * Leva à posição exata do apontamento dentro da peça.
   *
   * Abrir a peça no topo e mandar procurar não ajudava: em peça de dez
   * banners, achar o trecho é o trabalho todo.
   */
  function irAoPontoNaPeca(id, arquivo, texto) {
    const painel = document.getElementById('preview-' + id);
    if (!painel) return;
    const botao = document.querySelector('[data-preview="' + id + '"]');
    const precisaAbrir = painel.hidden;
    if (precisaAbrir && botao) abrirPreview(id, botao);

    setTimeout(() => {
      const aba = painel.querySelector('[data-vista="peca"]');
      if (aba && !aba.classList.contains('ativa')) aba.click();
      painel.scrollIntoView({ block: 'center', behavior: 'smooth' });
      setTimeout(() => destacarNaPeca(painel, arquivo, texto), 420);
    }, precisaAbrir ? 1100 : 80);
  }

  function destacarNaPeca(painel, arquivo, texto) {
    const quadro = painel.querySelector('iframe');
    if (!quadro) return;
    try {
      const doc = quadro.contentDocument;
      if (!doc) return;
      doc.querySelectorAll('.alvo-validador').forEach((no) =>
        no.classList.remove('alvo-validador'));

      let encontrado = null;
      if (arquivo && /\.(png|jpe?g|gif|webp)$/i.test(arquivo)) {
        const procurado = arquivo.toLowerCase();
        doc.querySelectorAll('img').forEach((img) => {
          const origem = (img.getAttribute('src') || '').toLowerCase();
          if (!encontrado && origem.indexOf(procurado) !== -1) encontrado = img;
        });
      }
      if (!encontrado && texto) {
        const chaveAlvo = chaveDeBusca(texto).slice(0, 40);
        if (chaveAlvo) {
          const percorre = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
          let no;
          while ((no = percorre.nextNode())) {
            if (chaveDeBusca(no.nodeValue).indexOf(chaveAlvo) !== -1) {
              encontrado = no.parentElement;
              break;
            }
          }
        }
      }
      if (!encontrado) return;

      if (!doc.getElementById('estilo-validador')) {
        const estilo = doc.createElement('style');
        estilo.id = 'estilo-validador';
        estilo.textContent =
          '.alvo-validador{outline:3px solid #cc092f !important;' +
          'outline-offset:2px;background:rgba(204,9,47,.08) !important;' +
          'animation:piscaAlvo 1.1s ease-in-out 3}' +
          '@keyframes piscaAlvo{0%,100%{outline-color:#cc092f}50%{outline-color:transparent}}';
        doc.head.appendChild(estilo);
      }
      encontrado.classList.add('alvo-validador');
      encontrado.scrollIntoView({ block: 'center' });
    } catch (e) { /* origem bloqueada: segue sem destacar */ }
  }

  /* ============================================================================
     6c. Painel do lote e ordenação
     ========================================================================== */

  const ORDENACOES = {
    pior:        { rotulo: 'Pior primeiro',        chave: (r) => [-r.apontamentos_graves, -r.total_apontamentos, r.texto.similaridade] },
    aderencia:   { rotulo: 'Menor aderência',      chave: (r) => [r.texto.similaridade, -r.total_apontamentos] },
    apontamento: { rotulo: 'Mais apontamentos',    chave: (r) => [-r.total_apontamentos, r.texto.similaridade] },
    imagens:     { rotulo: 'Imagens com problema', chave: (r) => [-r.imagens.apontamentos.length, r.texto.similaridade] },
    nome:        { rotulo: 'Nome da pasta',        chave: (r) => [String(r.nome_pasta || '').toLowerCase()] },
  };

  function comparar(a, b) {
    const ca = ORDENACOES[ordenacaoAtual].chave(a);
    const cb = ORDENACOES[ordenacaoAtual].chave(b);
    for (let i = 0; i < ca.length; i++) {
      if (ca[i] < cb[i]) return -1;
      if (ca[i] > cb[i]) return 1;
    }
    return 0;
  }

  function painelLote(dados) {
    const lista = dados.resultados;
    const conta = (status) => lista.filter((r) => r.status === status).length;
    const aprovados = conta('aprovado');
    const reprovados = conta('reprovado') + conta('erro');
    const atencao = lista.length - aprovados - reprovados;

    const botoes = Object.keys(ORDENACOES).map((chave) =>
      '<button type="button" class="ordenar' + (chave === ordenacaoAtual ? ' ativa' : '') +
      '" data-ordem="' + chave + '">' + ORDENACOES[chave].rotulo + '</button>').join('');

    return '<section class="panel lote-resumo">' +
      '<div class="lote-cabeca">' +
        '<div>' +
          '<span class="lote-etiqueta">Conferência múltipla</span>' +
          '<h2 class="lote-titulo">' + lista.length +
            (dados.parcial ? ' de ' + dados.total : '') + ' pacotes em ' +
            '<span class="arquivo">' + esc(dados.origem) + '</span>' +
            (dados.parcial ? '<span class="lote-rodando">conferindo…</span>' : '') +
          '</h2>' +
        '</div>' +
        '<div class="lote-placar">' +
          '<span class="placar aprovado"><b>' + aprovados + '</b> aprovado' + (aprovados === 1 ? '' : 's') + '</span>' +
          '<span class="placar atencao"><b>' + atencao + '</b> atenção</span>' +
          '<span class="placar reprovado"><b>' + reprovados + '</b> reprovado' + (reprovados === 1 ? '' : 's') + '</span>' +
        '</div>' +
      '</div>' +
      '<div class="lote-ordenacao"><span class="lote-ordenacao-rotulo">Ordenar por</span>' +
        botoes + '</div>' +
      '<ol class="lote-indice">' +
        lista.slice().sort(comparar).map((r, i) =>
          '<li><a href="#pacote-' + esc(r.id) + '" class="indice-linha" data-status="' + esc(r.status) + '">' +
            '<span class="indice-ordem">' + (i + 1) + '</span>' +
            '<span class="indice-nome">' + esc(r.nome_pasta) + '</span>' +
            '<span class="indice-numero" title="aderência do texto">' + r.texto.similaridade + '%</span>' +
            '<span class="indice-numero" title="apontamentos">' + r.total_apontamentos + ' apont.</span>' +
            '<span class="indice-numero" title="imagens na pasta / chamadas no HTML">' +
              r.imagens.total_pasta + '/' + r.imagens.total_chamadas_html + '</span>' +
            '<span class="selo ' + esc(r.status) + '">' + esc(r.status) + '</span>' +
          '</a></li>').join('') +
      '</ol></section>';
  }

  function cabecaUnica(dados) {
    const r = dados.resultados[0];
    return '<section class="panel unico-resumo">' +
      '<span class="lote-etiqueta unico">Conferência unitária</span>' +
      '<h2 class="lote-titulo">' + esc(r.nome_pasta) + '</h2>' +
      '<p class="nota">Um pacote conferido. Para conferir vários de uma vez, ' +
        'arraste a pasta que guarda os pacotes.</p>' +
    '</section>';
  }

  function renderizar() {
    const dados = ultimaConferencia;
    if (!dados) return;
    const alvo = $('#resultados');

    if (dados.modo === 'lote') {
      const ordenados = dados.resultados.slice().sort(comparar);
      alvo.innerHTML = painelLote(dados) +
        ordenados.map((r, i) => desenhar(r, (i + 1) + ' de ' + dados.total)).join('');
      alvo.querySelectorAll('.ordenar').forEach((botao) =>
        botao.addEventListener('click', () => {
          ordenacaoAtual = botao.dataset.ordem;
          renderizar();
          document.querySelector('.lote-resumo').scrollIntoView({ block: 'start' });
        }));
    } else {
      alvo.innerHTML = cabecaUnica(dados) + desenhar(dados.resultados[0], '');
    }

    alvo.querySelectorAll('.btn-preview').forEach((botao) =>
      botao.addEventListener('click', () => abrirPreview(botao.dataset.preview, botao)));
    alvo.querySelectorAll('.btn-workbench').forEach((botao) =>
      botao.addEventListener('click', () => abrirNoWorkbench(botao.dataset.workbench, botao)));

    // o mapa lateral leva direto à seção, e abre a comparação quando é o caso
    alvo.querySelectorAll('.mapa-item').forEach((item) =>
      item.addEventListener('click', () => {
        const destino = document.getElementById(item.dataset.secao);
        if (!destino) return;
        if (item.dataset.secao.endsWith('-comparar')) {
          const painel = destino.querySelector('.preview');
          const botao = alvo.querySelector('[data-preview="' +
            item.dataset.secao.replace('-comparar', '') + '"]');
          if (painel && painel.hidden && botao) botao.click();
        }
        destino.scrollIntoView({ block: 'start', behavior: 'smooth' });
        destino.classList.add('secao-alvo');
        setTimeout(() => destino.classList.remove('secao-alvo'), 1400);
      }));

    alvo.querySelectorAll('[data-ir-peca]').forEach((botao) =>
      botao.addEventListener('click', () =>
        irAoPontoNaPeca(botao.dataset.irPeca, botao.dataset.alvo, botao.dataset.texto)));
    alvo.querySelectorAll('[data-ampliar]').forEach((imagem) =>
      imagem.addEventListener('click', () =>
        ampliarImagem(imagem.dataset.id, imagem.dataset.ampliar)));

    alvo.querySelectorAll('.conferido-marca').forEach((marca) => {
      marca.checked = !!conferidos[marca.dataset.chave];
      aplicarConferido(marca);
      marca.addEventListener('change', () => {
        conferidos[marca.dataset.chave] = marca.checked;
        aplicarConferido(marca);
        atualizarPlacarConferencia();
      });
    });
    atualizarPlacarConferencia();
  }

  /* ============================================================================
     6b. Preview lado a lado
     ========================================================================== */

  /**
   * Abre a peça renderizada e o texto do docx lado a lado, com rolagem.
   *
   * É a conferência do jeito que a pessoa já faz hoje — duas janelas abertas,
   * olho indo de uma para outra. A diferença é que aqui as duas chegam juntas,
   * na mesma tela, sem procurar arquivo.
   */
  async function abrirPreview(id, botao) {
    const painel = document.getElementById('preview-' + id);
    if (!painel) return;

    const aberto = !painel.hidden;
    painel.hidden = aberto;
    botao.classList.toggle('ativo', !aberto);
    botao.querySelector('.preview-rotulo').textContent =
      aberto ? 'Ver peça e CONTEUDO lado a lado' : 'Fechar comparação';
    if (aberto || painel.dataset.carregado === '1') return;

    painel.dataset.carregado = '1';
    const coluna = painel.querySelector('.preview-texto-corpo');
    try {
      const resposta = await fetch('/api/preview/' + id + '/conteudo');
      const dados = await resposta.json();
      coluna.innerHTML = dados.paragrafos.length
        ? dados.paragrafos.map((linha, i) =>
            '<p class="preview-paragrafo" data-indice="' + i + '">' +
            '<span class="preview-numero">' + (i + 1) + '</span>' +
            '<span class="preview-conteudo-texto">' + esc(linha) + '</span></p>').join('')
        : '<p class="nota">O docx não tem parágrafos de texto.</p>';
      painel._dadosDeBusca = painel._dadosDeBusca || { leitura: [], docx: [] };
      painel._dadosDeBusca.docx = dados.paragrafos.slice();

      // clicar no parágrafo joga ele na busca: é o "procurar este trecho na
      // peça" sem precisar selecionar, copiar e colar
      coluna.querySelectorAll('.preview-paragrafo').forEach((no) =>
        no.addEventListener('click', () => {
          const campo = painel.querySelector('.busca-campo');
          campo.value = dados.paragrafos[Number(no.dataset.indice)] || '';
          buscarNoPainel(painel, campo.value);
          trocarParaLeitura(painel);
        }));
    } catch (e) {
      coluna.innerHTML = '<p class="nota">Não consegui carregar o texto do docx.</p>';
    }

    const campoBusca = painel.querySelector('.busca-campo');
    let adiar;
    campoBusca.addEventListener('input', () => {
      clearTimeout(adiar);
      // espera a digitação parar: em texto longo colado, buscar a cada tecla
      // deixaria o campo travado
      adiar = setTimeout(() => buscarNoPainel(painel, campoBusca.value), 160);
    });
    painel.querySelector('.busca-limpar').addEventListener('click', () => {
      campoBusca.value = '';
      buscarNoPainel(painel, '');
      campoBusca.focus();
    });

    painel.querySelectorAll('.preview-aba').forEach((botao) =>
      botao.addEventListener('click', () => {
        trocarVistaPreview(painel, botao.dataset.vista, botao);
        if (botao.dataset.vista === 'leitura') carregarLeitura(id, painel);
      }));

    const quadro = painel.querySelector('iframe');
    // A largura real só é conhecida depois que a peça carrega; até lá vale o
    // palpite padrão, que já evita o salto visual.
    quadro.addEventListener('load', () => agendarAjuste(painel), { once: true });
    quadro.src = '/preview/' + id + '/peca';
    agendarAjuste(painel);
    observarTamanho(painel);
  }

  /**
   * Mede só depois que o navegador terminou o layout.
   *
   * O painel acabou de deixar de ser `hidden`: medir na mesma linha devolve a
   * largura antiga (ou zero) e a peça sai esticada. Dois quadros de espera
   * resolvem — no primeiro o navegador aplica o display, no segundo as medidas
   * já são as definitivas. Era isso que "consertava" ao abrir o inspetor: o
   * DevTools forçava um novo cálculo.
   */
  function agendarAjuste(painel) {
    requestAnimationFrame(() => requestAnimationFrame(() => ajustarEscala(painel)));
  }

  /** Recalcula sempre que a coluna muda de tamanho: janela, zoom, inspetor. */
  function observarTamanho(painel) {
    if (painel.dataset.observado === '1' || typeof ResizeObserver === 'undefined') return;
    painel.dataset.observado = '1';
    const palco = painel.querySelector('.preview-palco');
    if (!palco) return;
    new ResizeObserver(() => {
      if (!painel.hidden) ajustarEscala(painel);
    }).observe(palco);
  }

  /** Palpite inicial, usado só até a peça carregar e informar a largura real. */
  const LARGURA_PADRAO = 700;

  /**
   * Descobre a largura para a qual a peça foi desenhada.
   *
   * Não dá para medir o conteúdo renderizado: HTML de e-mail usa tabela em
   * 100%, que se adapta ao espaço disponível. Medir assim devolvia a largura
   * do próprio iframe — a conta ficava circular e a peça encolhia a cada
   * abertura. A largura de verdade está declarada nos atributos: <table
   * width="700"> ou um max-width no style.
   */
  function larguraDaPeca(quadro) {
    try {
      const doc = quadro.contentDocument;
      if (!doc || !doc.body) return LARGURA_PADRAO;

      const medidas = [];
      doc.querySelectorAll('table, td, div').forEach((el) => {
        const atributo = parseInt(el.getAttribute('width') || '', 10);
        if (atributo > 300) medidas.push(atributo);
        const limite = parseInt((el.style && el.style.maxWidth) || '', 10);
        if (limite > 300) medidas.push(limite);
      });

      if (medidas.length) {
        // a maior largura declarada é o container da peça
        return Math.min(Math.max.apply(null, medidas), 1200);
      }

      // sem largura declarada, mede o conteúdo — com o iframe largo, para a
      // tabela em 100% não devolver a largura do próprio quadro
      const anterior = quadro.style.width;
      quadro.style.width = '1200px';
      const medido = Math.max(doc.body.scrollWidth, doc.documentElement.scrollWidth);
      quadro.style.width = anterior;
      return medido > 300 ? Math.min(medido, 1200) : LARGURA_PADRAO;
    } catch (e) {
      return LARGURA_PADRAO;   // origem bloqueada: usa o padrão
    }
  }

  /**
   * Encolhe a peça para caber na coluna.
   *
   * HTML de e-mail é desenhado numa largura fixa (600 a 900 px). Dentro de meia
   * tela ele apareceria cortado ao meio — justamente a parte da direita, onde
   * costuma estar o valor da oferta. Reduzir a escala mostra a peça inteira,
   * que é o ponto de olhar para ela.
   */
  function ajustarEscala(painel) {
    const palco = painel.querySelector('.preview-palco');
    const quadro = painel.querySelector('iframe');
    if (!palco || !quadro) return;
    const disponivel = palco.clientWidth;
    if (!disponivel) return;   // ainda sem layout: o observador chama de novo
    const largura = larguraDaPeca(quadro);
    const escala = Math.min(1, disponivel / largura);
    quadro.style.width = largura + 'px';
    quadro.style.height = (palco.clientHeight / escala) + 'px';
    quadro.style.transform = 'scale(' + escala.toFixed(3) + ')';
  }

  // rede extra para navegador sem ResizeObserver
  window.addEventListener('resize', () => {
    document.querySelectorAll('.preview:not([hidden])').forEach(agendarAjuste);
  });


  /**
   * Desenha a fita de leitura: o que o sistema entendeu, bloco a bloco.
   *
   * Quando um apontamento não faz sentido, é aqui que se descobre o motivo —
   * se a imagem foi lida errado ou se o docx é que está diferente. Sem isso a
   * leitura da máquina fica invisível, e só resta confiar ou desconfiar.
   */
  async function carregarLeitura(id, painel) {
    const alvo = painel.querySelector('.preview-leitura-corpo');
    if (alvo.dataset.carregado === '1') return;
    alvo.dataset.carregado = '1';
    alvo.innerHTML = '<p class="nota">Carregando…</p>';
    try {
      const resposta = await fetch('/api/preview/' + id + '/leitura');
      const dados = await resposta.json();
      alvo.innerHTML = dados.blocos.map((b) => {
        const imagem = b.tipo === 'imagem';
        const confianca = (imagem && b.confianca)
          ? '<span class="leitura-confianca' + (b.confianca < 80 ? ' baixa' : '') + '">' +
            b.confianca + '%</span>'
          : '';
        const marcaOrdem = b.reordenado
          ? '<span class="leitura-reordenado">ordem do docx</span>' : '';
        const aviso = b.aviso
          ? '<p class="nota leitura-aviso">' + esc(b.aviso) + '</p>' : '';
        const corpo = b.texto
          ? '<div class="leitura-texto">' + esc(b.texto) + '</div>'
          : '<div class="leitura-vazia">— sem texto lido —</div>';
        return '<div class="leitura-bloco' + (imagem ? ' imagem' : '') + '">' +
          '<div class="leitura-cabeca">' +
            '<span class="leitura-origem">' + esc(b.origem) + marcaOrdem + '</span>' +
            confianca +
          '</div>' + corpo + aviso +
        '</div>';
      }).join('') || '<p class="nota">Nada lido.</p>';
      painel._dadosDeBusca = painel._dadosDeBusca || { leitura: [], docx: [] };
      painel._dadosDeBusca.leitura = dados.blocos
        .filter((b) => b.texto).map((b) => b.texto);
      const consultaAtual = painel.querySelector('.busca-campo').value;
      if (consultaAtual) buscarNoPainel(painel, consultaAtual);
    } catch (e) {
      alvo.innerHTML = '<p class="nota">Não consegui carregar a leitura.</p>';
    }
  }

  /**
   * Forma usada para comparar na busca.
   *
   * É aqui que a busca ganha do CTRL+F do Word. Colar um trecho do HTML na
   * caixa do Word leva junto quebra de linha e espaço duplo, e a busca volta
   * 0/0 mesmo com o texto lá. Reduzindo os dois lados a letras e números sem
   * acento, o que sobra é o conteúdo — e aí ele é encontrado.
   */
  function chaveDeBusca(texto) {
    return String(texto || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')   // tira acento
      .replace(/[^a-z0-9%$&]+/g, '');                      // tira pontuação e espaço
  }

  /** Destaca as ocorrências mantendo o texto original visível. */
  function destacar(texto, consulta, classe) {
    const original = String(texto || '');
    const chaveAlvo = chaveDeBusca(consulta);
    if (!chaveAlvo) return { html: esc(original), ocorrencias: 0 };

    // mapeia cada caractere significativo de volta à posição no texto original
    const posicoes = [];
    let reduzido = '';
    for (let i = 0; i < original.length; i++) {
      const pedaco = chaveDeBusca(original[i]);
      if (pedaco) { reduzido += pedaco; posicoes.push(i); }
    }

    let saida = '';
    let cursor = 0;
    let ocorrencias = 0;
    let de = reduzido.indexOf(chaveAlvo);
    while (de !== -1) {
      const inicio = posicoes[de];
      const fim = posicoes[de + chaveAlvo.length - 1];
      saida += esc(original.slice(cursor, inicio));
      saida += '<mark' + (classe ? ' class="' + classe + '"' : '') + '>' +
        esc(original.slice(inicio, fim + 1)) + '</mark>';
      cursor = fim + 1;
      ocorrencias += 1;
      de = reduzido.indexOf(chaveAlvo, de + chaveAlvo.length);
    }
    saida += esc(original.slice(cursor));
    return { html: saida, ocorrencias: ocorrencias };
  }

  /**
   * Procura o trecho nos dois lados ao mesmo tempo.
   *
   * O ponto não é achar: é comparar. Se aparece no CONTEUDO e não aparece na
   * leitura da peça, o texto foi escrito e não publicado. Se aparece só na
   * peça, ficou de fora do docx e o cliente com deficiência visual não recebe.
   */
  function buscarNoPainel(painel, consulta) {
    const dados = painel._dadosDeBusca;
    if (!dados) return;

    const campoVazio = !chaveDeBusca(consulta);
    let achadosLeitura = 0;
    let achadosDocx = 0;

    painel.querySelectorAll('.leitura-texto').forEach((no, i) => {
      const bruto = dados.leitura[i] != null ? dados.leitura[i] : no.textContent;
      const r = destacar(bruto, consulta);
      no.innerHTML = r.html;
      achadosLeitura += r.ocorrencias;
      const bloco = no.closest('.leitura-bloco');
      if (bloco) bloco.classList.toggle('sem-resultado',
        !campoVazio && r.ocorrencias === 0);
    });

    painel.querySelectorAll('.preview-paragrafo').forEach((no, i) => {
      const alvo = no.querySelector('.preview-conteudo-texto');
      if (!alvo) return;
      const bruto = dados.docx[i] != null ? dados.docx[i] : alvo.textContent;
      const r = destacar(bruto, consulta);
      alvo.innerHTML = r.html;
      achadosDocx += r.ocorrencias;
      no.classList.toggle('sem-resultado', !campoVazio && r.ocorrencias === 0);
    });

    const placar = painel.querySelector('.busca-placar');
    painel.querySelector('.busca-limpar').hidden = campoVazio;
    if (campoVazio) { placar.innerHTML = ''; return; }

    const marca = (quantidade, rotulo) =>
      '<span class="busca-marca ' + (quantidade ? 'tem' : 'nao-tem') + '">' +
      rotulo + ': ' + quantidade + '</span>';
    placar.innerHTML = marca(achadosLeitura, 'peça') + marca(achadosDocx, 'CONTEUDO') +
      (achadosLeitura && !achadosDocx
        ? '<span class="busca-alerta">está na peça e não no CONTEUDO</span>' : '') +
      (!achadosLeitura && achadosDocx
        ? '<span class="busca-alerta">está no CONTEUDO e não na peça</span>' : '');
  }

  /** Leva para a aba de leitura, carregando-a se ainda não foi aberta. */
  function trocarParaLeitura(painel) {
    const botao = painel.querySelector('[data-vista="leitura"]');
    if (!botao || botao.classList.contains('ativa')) return;
    botao.click();
  }

  function trocarVistaPreview(painel, vista, botao) {
    painel.querySelectorAll('.preview-aba').forEach((b) =>
      b.classList.toggle('ativa', b === botao));
    const palco = painel.querySelector('.preview-palco');
    const leitura = painel.querySelector('.preview-leitura-corpo');
    const cabeca = painel.querySelector('[data-papel="cabeca-esquerda"]');
    const quadro = painel.querySelector('iframe');
    const ehPeca = vista === 'peca';

    // Guarda onde a peça estava antes de escondê-la. Sem isso ela voltava ao
    // topo a cada troca de aba, e comparar um trecho do meio da peça com a
    // leitura virava um exercício de rolar tudo de novo.
    if (!ehPeca && quadro) {
      try {
        const doc = quadro.contentDocument;
        painel.dataset.rolagemPeca = String(
          (doc.documentElement && doc.documentElement.scrollTop) ||
          (doc.body && doc.body.scrollTop) || 0);
      } catch (e) { /* origem bloqueada: segue sem guardar */ }
    }

    palco.hidden = !ehPeca;
    leitura.hidden = ehPeca;
    cabeca.textContent = ehPeca
      ? 'Peça · ' + (painel.dataset.arquivoHtml || '')
      : 'Leitura do sistema · na ordem do leitor de tela';
    // a escala do iframe é medida com o painel visível; voltando para a peça
    // ela precisa ser refeita
    if (ehPeca) {
      agendarAjuste(painel);
      const guardada = Number(painel.dataset.rolagemPeca || 0);
      if (guardada) {
        // depois do ajuste de escala, que mexe no tamanho do quadro
        requestAnimationFrame(() => requestAnimationFrame(() => {
          try {
            const doc = quadro.contentDocument;
            if (doc.documentElement) doc.documentElement.scrollTop = guardada;
            if (doc.body) doc.body.scrollTop = guardada;
          } catch (e) { /* segue */ }
        }));
      }
    }
  }

  /* Leva o HTML do pacote para o editor da aba SFMC Workbench.
     O servidor devolve o arquivo já decodificado; a aba do Workbench carrega no
     editor de entrada (WB.abrirPeca, em app.js) e fica com o botão Desfazer. */
  function abrirNoWorkbench(id, botao) {
    if (!window.WB || typeof window.WB.abrirPeca !== 'function') {
      toast('O Workbench não carregou. Recarregue a página e tente de novo.');
      return;
    }
    botao.disabled = true;
    fetch('/api/preview/' + encodeURIComponent(id) + '/html')
      .then((resposta) => {
        if (!resposta.ok) throw new Error('HTTP ' + resposta.status);
        return resposta.json();
      })
      .then((dados) => {
        // primeiro mostra a aba: o editor mede o tamanho dele ao aparecer
        const abaWorkbench = document.getElementById('aba-btn-workbench');
        if (abaWorkbench) abaWorkbench.click();
        window.WB.abrirPeca(dados.html, dados.arquivo || 'peca.html');
      })
      .catch(() => toast('Não consegui buscar o HTML deste pacote. Refaça a conferência.'))
      .finally(() => { botao.disabled = false; });
  }

  function blocoPreview(r) {
    if (!r.tem_preview) return '';
    return '<div class="preview" id="preview-' + esc(r.id) + '" hidden ' +
      'data-arquivo-html="' + esc(r.arquivo_html) + '">' +
      '<div class="preview-abas" role="tablist">' +
        '<button type="button" class="preview-aba ativa" data-vista="peca">' +
          'Peça renderizada</button>' +
        '<button type="button" class="preview-aba" data-vista="leitura">' +
          'O que o sistema leu</button>' +
        '<a class="preview-baixar" href="/preview/' + esc(r.id) + '/conteudo-gerado.docx" ' +
          'title="Gera um docx com esta leitura. Serve para montar pacote de teste, ' +
          'não para conferir a peça.">Baixar esta leitura em .docx</a>' +
      '</div>' +
      '<div class="busca-cruzada">' +
        '<svg class="busca-icone" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
          'stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/>' +
          '<path d="m20 20-3.5-3.5"/></svg>' +
        '<input type="search" class="busca-campo" placeholder="Cole ou digite um trecho para procurar nos dois lados" ' +
          'autocomplete="off" spellcheck="false">' +
        '<span class="busca-placar"></span>' +
        '<button type="button" class="busca-limpar" hidden>limpar</button>' +
      '</div>' +
      '<div class="preview-colunas">' +
        '<div class="preview-coluna">' +
          '<div class="preview-cabeca" data-papel="cabeca-esquerda">Peça · ' +
            esc(r.arquivo_html) + '</div>' +
          '<div class="preview-palco">' +
            // sandbox sem allow-scripts: a peça é só para olhar, e HTML de
            // e-mail não deve executar nada dentro da ferramenta
            '<iframe title="Peça renderizada" sandbox="allow-same-origin" loading="lazy"></iframe>' +
          '</div>' +
          '<div class="preview-leitura-corpo" hidden></div>' +
        '</div>' +
        '<div class="preview-coluna">' +
          '<div class="preview-cabeca">Texto · ' + esc(r.arquivo_conteudo) + '</div>' +
          '<div class="preview-texto-corpo"></div>' +
        '</div>' +
      '</div>' +
      '<p class="nota preview-dica">As duas colunas rolam separadamente. ' +
        'A peça abre com as imagens do próprio pacote.</p>' +
    '</div>';
  }

  /* ============================================================================
     7. Motor de leitura de imagens
     ========================================================================== */

  const ICONE_INFO =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" ' +
    'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/>' +
    '<path d="M12 11v5"/><path d="M12 7.5h.01"/></svg>';

  function consultarMotor() {
    fetch('/api/status-ocr').then((r) => r.json()).then((s) => {
      const barra = $('#barra-motor');

      // Com mais de um motor instalado, a escolha fica na mão de quem confere:
      // cada um erra em imagens diferentes, e só testando nas peças de verdade
      // dá para saber qual serve melhor.
      const disponiveis = s.disponiveis || [];
      if (disponiveis.length > 1) {
        const seletor = $('#motor');
        seletor.innerHTML = disponiveis.map((m) =>
          '<option value="' + esc(m.nome) + '"' + (m.nome === s.motor ? ' selected' : '') +
          '>' + esc(m.descricao) + '</option>').join('');
        $('#opcao-motor').hidden = false;
      }
      // motor velho demais: a leitura falha em silêncio e o apontamento
      // aparece como se fosse erro da peça
      if (s.disponivel && s.aviso_versao) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO + '<span>' + esc(s.aviso_versao) + '</span>';
        return;
      }
      // pediram um motor que não está instalado: dizer isso é mais útil do
      // que mostrar a lista genérica de instalação
      if (s.disponivel && s.aviso_escolha) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO + '<span>' + esc(s.aviso_escolha) +
          ' A leitura está rodando por <b>' + esc(s.descricao) + '</b>.</span>';
        return;
      }
      if (s.disponivel && s.portugues) {
        barra.className = 'barra-motor ativo';
        barra.innerHTML = ICONE_INFO +
          '<span>Leitura do texto das imagens <b>ativa</b> · ' + esc(s.descricao) + '</span>';
        return;
      }
      if (s.disponivel) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO +
          '<span>Leitura ativa por <b>' + esc(s.descricao) + '</b>, mas sem o idioma ' +
          'português — acentos saem imprecisos.' +
          (s.dica_idioma ? '<br>' + esc(s.dica_idioma) : '') + '</span>';
        return;
      }
      const opcoes = (s.motores || []).map((m) =>
        '<li>' + esc(m.descricao) + ' — ' + esc(m.motivo) + '</li>').join('');
      barra.className = 'barra-motor inativo';
      barra.innerHTML = ICONE_INFO +
        '<span>Leitura do texto dentro das imagens <b>indisponível</b>. A conferência ' +
        'roda em modo parcial. Para ativar, basta um destes:<ul>' + opcoes + '</ul></span>';
    }).catch(() => { /* rodapé é informativo: falhar aqui não atrapalha a conferência */ });
  }

  /* ============================================================================
     8. Inicialização
     ========================================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    ligarTema();
    ligarArrastar();
    $('#btn-conferir').addEventListener('click', conferir);
    consultarMotor();
  });
})();
'''

# Front do Workbench: CSS reescrito com os tokens do Validador (escopo #aba-workbench)
_CSS_WORKBENCH = r'''/* Barra de abas do script unificado: mesmos tokens do Validador. */
.abas-app { background: var(--card-bg); border-bottom: 1px solid var(--border); position: relative; z-index: var(--z-sticky); }
.abas-app-inner { max-width: 1480px; margin: 0 auto; padding: 0 var(--space-6); display: flex; gap: var(--space-1); overflow-x: auto; }
.aba-app {
  appearance: none; background: none; border: 0; border-bottom: 3px solid transparent; border-radius: 0;
  padding: 13px 18px; font-family: inherit; font-size: var(--t-sm); font-weight: 800; letter-spacing: .02em;
  color: var(--text-muted); white-space: nowrap; cursor: pointer;
  transition: color var(--transicao), border-color var(--transicao);
}
.aba-app:hover { color: var(--bradesco-red); }
.aba-app[aria-selected="true"] { color: var(--text); border-bottom-color: var(--bradesco-red); }
@media (max-width: 700px) { .abas-app-inner { padding: 0 var(--space-3); } }

#aba-workbench,
#dlg,
#toasts {--ac: var(--bradesco-red);
  --acs: rgba(204, 9, 47, 0.14);
  --sf: var(--card-bg);
  --sf2: var(--surface-2);
  --ink: var(--text);
  --mu: var(--text-muted);
  --ln: var(--border);
  --er: var(--danger-fg);
  --ers: var(--danger-bg);
  --wa: var(--warn-fg);
  --was: var(--warn-bg);
  --ok: var(--ok-fg);
  --oks: var(--ok-bg);

  --sx-tag: #0f4c81; --sx-attr: #7a3e9d; --sx-str: #15803d; --sx-cmt: #7b8794;
  --sx-amp: #8a4b00; --sx-ampbg: #fff3d6; --sx-ampkw: #cc092f; --sx-ampvar: #6b2fb3;
  --sx-pvar: #00747a;}
html[data-theme="dark"] #aba-workbench,
html[data-theme="dark"] #dlg,
html[data-theme="dark"] #toasts {--acs: rgba(255, 59, 92, 0.22);
  --sx-tag: #6db3f2; --sx-attr: #c9a3f0; --sx-str: #7ee787; --sx-cmt: #7d8ea3;
  --sx-amp: #f2cc60; --sx-ampbg: #2e2410; --sx-ampkw: #ff8a9c; --sx-ampvar: #d0a8ff;
  --sx-pvar: #5fd4da;}
#aba-workbench button,
#aba-workbench input,
#aba-workbench textarea,
#aba-workbench select {font: inherit; color: inherit;}
#aba-workbench button {background: var(--sf); border: 1px solid var(--ln); border-radius: var(--radius-sm);
  padding: 7px 13px; font-size: var(--t-sm); font-weight: 700; line-height: 1.2; cursor: pointer;
  transition: border-color var(--transicao), color var(--transicao), background var(--transicao), transform var(--transicao);}
#aba-workbench button:hover:not(:disabled) {border-color: var(--ac); color: var(--ac);}
#aba-workbench button:active:not(:disabled) {transform: scale(.97);}
#aba-workbench button:disabled {opacity: .45; cursor: not-allowed;}
#aba-workbench button.danger {color: var(--er);}
#aba-workbench button.danger:hover:not(:disabled) {border-color: var(--er); color: var(--er);}
#dlg button.danger {background: var(--bradesco-red); border-color: var(--bradesco-red); color: #fff;}
#dlg button.danger:hover:not(:disabled) {background: var(--bradesco-red-dark); border-color: var(--bradesco-red-dark); color: #fff;}
#aba-workbench button.p {background: var(--ac); border-color: var(--ac); color: #fff;}
#aba-workbench button.p:hover:not(:disabled) {background: var(--bradesco-red-dark); border-color: var(--bradesco-red-dark); color: #fff;}
#aba-workbench textarea,
#aba-workbench input[type=text],
#aba-workbench input[type=number] {width: 100%; background: var(--sf2); border: 1px solid var(--ln); border-radius: var(--radius-sm); padding: 8px 10px;}
#aba-workbench textarea:hover,
#aba-workbench input[type=text]:hover,
#aba-workbench input[type=number]:hover {border-color: var(--border-strong);}
#aba-workbench select {background: var(--sf); border: 1px solid var(--ln); border-radius: var(--radius-sm); padding: 5px 9px; font-size: var(--t-sm); cursor: pointer;}
#aba-workbench select:hover {border-color: var(--ac);}
#aba-workbench input[type=checkbox] {accent-color: var(--bradesco-red); width: 15px; height: 15px; cursor: pointer;}
#aba-workbench [aria-invalid="true"] {border-color: var(--er) !important; background: var(--ers) !important;}
#aba-workbench textarea {font: 12.5px/1.5 var(--fonte-mono); resize: vertical;}
#aba-workbench table {border-collapse: collapse; width: 100%; font-size: var(--t-sm);}
#aba-workbench th,
#aba-workbench td {text-align: left; padding: 7px 9px; border-bottom: 1px solid var(--ln); vertical-align: top;}
#aba-workbench th {color: var(--text-dim); font-size: var(--t-xs); font-weight: 700; letter-spacing: .06em; text-transform: uppercase;}
#aba-workbench td.m {font-family: var(--fonte-mono); font-size: 12px; word-break: break-all;}
#aba-workbench .tw {overflow-x: auto; max-height: 340px; overflow-y: auto;}
#aba-workbench .tw.livre {max-height: none;}
#aba-workbench kbd {font: 11.5px var(--fonte-mono); border: 1px solid var(--ln); border-bottom-width: 2px; border-radius: 4px; padding: 0 5px; background: var(--sf2); color: var(--ink);}
#aba-workbench .mu {color: var(--mu); font-size: var(--t-sm);}
#aba-workbench .row {display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin: 8px 0;}
#aba-workbench .row.end {justify-content: flex-end;}
#aba-workbench .row label {display: inline-flex; align-items: center; gap: 8px; font-size: var(--t-sm); color: var(--mu); cursor: pointer;}
#aba-workbench .top {display: flex; flex-wrap: wrap; gap: var(--space-3); align-items: center; justify-content: space-between; margin-bottom: var(--space-5);}
#aba-workbench .top h1 {font-size: var(--t-lg); font-weight: 800; letter-spacing: -.02em;}
#aba-workbench .top p {margin: 2px 0 0; color: var(--mu); font-size: var(--t-sm);}
#aba-workbench .act {display: flex; gap: 8px; align-items: center; flex-wrap: wrap; justify-content: flex-end;}
#aba-workbench .pill {display: inline-flex; align-items: center; padding: 6px 12px; border-radius: var(--radius-full);
  font-size: var(--t-xs); font-weight: 700; background: var(--sf2); border: 1px solid var(--ln); color: var(--mu);}
#aba-workbench .pill.bad {background: var(--ers); color: var(--er); border-color: var(--er);}
#aba-workbench .pill.warn {background: var(--was); color: var(--wa); border-color: var(--wa);}
#aba-workbench .pill.good {background: var(--oks); color: var(--ok); border-color: var(--ok);}
#aba-workbench .seg {display: inline-flex;}
#aba-workbench .seg button {border-radius: 0;}
#aba-workbench .seg button:first-child {border-radius: var(--radius-sm) 0 0 var(--radius-sm);}
#aba-workbench .seg button:last-child {border-radius: 0 var(--radius-sm) var(--radius-sm) 0;}
#aba-workbench .seg button + button {margin-left: -1px;}
#aba-workbench .seg button[aria-pressed="true"] {background: var(--ac); color: #fff; border-color: var(--ac);}
#aba-workbench .kpis {display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-3); margin-bottom: var(--space-4);}
#aba-workbench .kpi {background: var(--sf); border: 1px solid var(--ln); border-radius: var(--radius-md); box-shadow: var(--shadow-card); padding: 12px 16px;}
#aba-workbench .kpi b {display: block; font-size: 26px; line-height: 1.1; font-weight: 800; letter-spacing: -.02em;}
#aba-workbench .kpi span {color: var(--mu); font-size: var(--t-sm);}
#aba-workbench .grid {display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, .9fr); gap: var(--space-4);}
#aba-workbench .card {background: var(--sf); border: 1px solid var(--ln); border-radius: var(--radius-md); box-shadow: var(--shadow-card);}
#aba-workbench .tabs {display: flex; overflow-x: auto; border-bottom: 1px solid var(--ln);}
#aba-workbench .tabs button {border: 0; border-bottom: 3px solid transparent; border-radius: 0; background: none;
  padding: 12px 15px; white-space: nowrap; color: var(--mu);}
#aba-workbench .tabs button:hover:not(:disabled) {color: var(--ac); border-bottom-color: transparent;}
#aba-workbench .tabs button[aria-selected="true"] {border-bottom-color: var(--ac); color: var(--ink);}
#aba-workbench .tabs i {font-style: normal; background: var(--bradesco-red); color: #fff; border-radius: var(--radius-full); padding: 0 7px; margin-left: 6px; font-size: 11px;}
#aba-workbench .pn {padding: var(--space-4) var(--space-5);}
#aba-workbench .pn[hidden] {display: none;}
#aba-workbench .pn a {color: var(--ac);}
#aba-workbench #drop {position: relative; border: 2px dashed var(--ln); border-radius: var(--radius-md); padding: 4px; transition: border-color var(--transicao), background var(--transicao);}
#aba-workbench #drop.on {border-color: var(--ac); background: var(--acs);}
#aba-workbench .dzh {display: none; position: absolute; inset: 4px; align-items: center; justify-content: center; background: var(--acs); color: var(--ac); font-weight: 800; border-radius: 4px; z-index: 5; pointer-events: none;}
#aba-workbench #drop.on .dzh {display: flex;}
#aba-workbench .keys {margin-left: auto;}
#aba-workbench .keys kbd:not(:first-child) {margin-left: 2px;}
#aba-workbench .ck {list-style: none; margin: 0; padding: 0; display: grid; gap: 8px;}
#aba-workbench .ck li {border: 1px solid var(--ln); border-left-width: 5px; border-radius: var(--radius-sm); padding: 9px 13px; background: var(--sf2);}
#aba-workbench .ck li b {display: block;}
#aba-workbench .ck .bloq {border-left-color: var(--er);}
#aba-workbench .ck .alerta {border-left-color: var(--wa);}
#aba-workbench .ck .ok {border-left-color: var(--ok);}
#aba-workbench .ck .bloq b {color: var(--er);}
#aba-workbench .ck .alerta b {color: var(--wa);}
#aba-workbench .ck .ok b {color: var(--ok);}
#aba-workbench .b {padding: 2px 9px; border-radius: var(--radius-full); font-size: 11.5px; font-weight: 700; white-space: nowrap;}
#aba-workbench .b.bloq {background: var(--ers); color: var(--er);}
#aba-workbench .b.alerta {background: var(--was); color: var(--wa);}
#aba-workbench .b.ok {background: var(--oks); color: var(--ok);}
#aba-workbench .rel {border: 1px solid var(--ln); border-radius: var(--radius-md); padding: 8px 14px 4px; margin: 0 0 var(--space-3);}
#aba-workbench .rel legend {font-weight: 800; padding: 0 4px;}
#aba-workbench .relf {display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px;}
#aba-workbench .relf label {font-size: var(--t-sm); color: var(--mu); display: grid; gap: 2px;}
#aba-workbench .relf input {padding: 6px 9px; color: var(--ink);}
#aba-workbench .locs {display: flex; flex-wrap: wrap; gap: 4px; align-items: center; margin-top: 6px;}
#aba-workbench .locs > .mu {margin-right: 2px;}
#aba-workbench button.ln {font: 12px var(--fonte-mono); padding: 1px 7px; border-radius: var(--radius-full); background: var(--sf); min-width: 34px;}
#aba-workbench button.ln:hover:not(:disabled) {background: var(--acs);}
#aba-workbench td button.ln {margin-left: 2px;}
#aba-workbench .manual {background: var(--was); color: var(--wa); border-radius: var(--radius-sm); padding: 7px 11px; margin: 0 0 8px;}
#aba-workbench h2.sub {font-size: var(--t-md); font-weight: 800; margin: 18px 0 6px;}
#aba-workbench .rgt td {vertical-align: middle;}
#aba-workbench .rgt select {min-width: 130px;}
#aba-workbench select.nv-bloq {color: var(--er); border-color: var(--er);}
#aba-workbench select.nv-alerta {color: var(--wa); border-color: var(--wa);}
#aba-workbench select.nv-off {color: var(--mu);}
#aba-workbench .rgp {display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px;}
#aba-workbench .rgp label {display: grid; gap: 3px; font-size: var(--t-sm); color: var(--mu); align-content: start;}
#aba-workbench .rgp input,
#aba-workbench .rgp textarea {color: var(--ink);}
#aba-workbench .err {background: var(--ers); color: var(--er); border-radius: var(--radius-sm); padding: 8px 11px; margin: 8px 0;}
#aba-workbench .err[hidden] {display: none;}
#aba-workbench details.json {margin: 14px 0;}
#aba-workbench details.json summary {cursor: pointer; font-weight: 800;}
#aba-workbench details.json textarea {margin-top: 8px;}
#aba-workbench .pvw {position: sticky; top: 12px; align-self: start;}
#aba-workbench .pvh {display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; padding: 11px 16px; border-bottom: 1px solid var(--ln);}
#aba-workbench .pvo {display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: center; padding: 9px 16px; border-bottom: 1px solid var(--ln); font-size: var(--t-sm); color: var(--mu);}
#aba-workbench .pvo label {display: inline-flex; gap: 6px; align-items: center;}
#aba-workbench .pvo select {padding: 3px 7px;}
#aba-workbench .stage {padding: var(--space-4); background: var(--sf2); border-radius: 0 0 var(--radius-md) var(--radius-md);}
#aba-workbench .stage .mu {margin: 10px 0 0;}
#aba-workbench .frame {margin: 0 auto; width: 100%; transition: width .2s;}
#aba-workbench .frame.m {width: 375px; max-width: 100%;}
#aba-workbench .frame.dark iframe {border-color: var(--border-strong);}
#aba-workbench iframe {width: 100%; height: 560px; border: 1px solid var(--ln); background: #fff; border-radius: 4px; display: block;}
#toasts {position: fixed; right: 16px; bottom: calc(16px + env(safe-area-inset-bottom, 0px)); display: grid; gap: 8px; z-index: var(--z-toast);}
#toasts .t {display: flex; align-items: center; gap: 12px; background: var(--card-bg); color: var(--text);
  border: 1px solid var(--border); border-left: 3px solid var(--bradesco-red);
  padding: 9px 9px 9px 14px; border-radius: var(--radius-md); box-shadow: var(--shadow-raised);
  max-width: min(440px, calc(100vw - 32px)); font-size: var(--t-sm);}
#toasts .t span {padding: 2px 6px 2px 0;}
#toasts .t button {background: transparent; color: var(--bradesco-red); border: 1px solid var(--bradesco-red); border-radius: var(--radius-sm);
  padding: 3px 10px; font-family: inherit; font-size: var(--t-xs); font-weight: 700; white-space: nowrap; cursor: pointer;}
#toasts .t.e {border-left-color: var(--bradesco-red); background: var(--danger-bg);}
#dlg {border: 1px solid var(--border); border-radius: var(--radius-lg); background: var(--card-bg); color: var(--text);
  padding: 20px 22px; max-width: 440px; box-shadow: var(--shadow-overlay); font-family: var(--fonte);}
#dlg::backdrop {background: rgba(10, 12, 16, .5);}
#dlg h2 {font-size: var(--t-lg); font-weight: 800; margin: 0 0 8px;}
#dlg p {margin: 0 0 14px; color: var(--text-muted); font-size: var(--t-base);}
#dlg button {background: var(--card-bg); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 7px 13px; font-size: var(--t-sm); font-weight: 700; cursor: pointer; color: var(--text); font-family: inherit;}
#dlg button:hover {border-color: var(--bradesco-red);}
#dlg .row {display: flex; gap: 8px; align-items: center; justify-content: flex-end; margin: 8px 0 0;}
#aba-workbench .ed {border: 1px solid var(--ln); border-radius: var(--radius-sm); overflow: hidden; background: var(--sf2);}
#aba-workbench #drop .ed {border: 0;}
#aba-workbench .ed .CodeMirror {height: 440px; font: 12.5px/1.55 var(--fonte-mono);}
#aba-workbench #edOut .CodeMirror {height: 420px;}
#aba-workbench .cm-s-wb.CodeMirror {background: var(--sf2); color: var(--ink);}
#aba-workbench .cm-s-wb .CodeMirror-gutters {background: var(--sf2); border-right: 1px solid var(--ln);}
#aba-workbench .cm-s-wb .CodeMirror-linenumber {color: var(--mu); padding: 0 8px 0 4px;}
#aba-workbench .cm-s-wb .CodeMirror-cursor {border-left: 2px solid var(--ac);}
#aba-workbench .cm-s-wb .CodeMirror-selected,
#aba-workbench .cm-s-wb .CodeMirror-focused .CodeMirror-selected {background: var(--acs);}
#aba-workbench .cm-s-wb .CodeMirror-line::selection,
#aba-workbench .cm-s-wb .CodeMirror-line > span::selection,
#aba-workbench .cm-s-wb .CodeMirror-line > span > span::selection {background: var(--acs);}
#aba-workbench .cm-s-wb .CodeMirror-activeline-background {background: color-mix(in srgb, var(--acs) 55%, transparent);}
#aba-workbench .cm-s-wb .CodeMirror-matchingtag {background: color-mix(in srgb, var(--ac) 18%, transparent);}
#aba-workbench .cm-s-wb pre.CodeMirror-placeholder {color: var(--mu);}
#aba-workbench .cm-s-wb .cm-tag {color: var(--sx-tag);}
#aba-workbench .cm-s-wb .cm-bracket {color: var(--mu);}
#aba-workbench .cm-s-wb .cm-attribute {color: var(--sx-attr);}
#aba-workbench .cm-s-wb .cm-string {color: var(--sx-str);}
#aba-workbench .cm-s-wb .cm-comment {color: var(--sx-cmt); font-style: italic;}
#aba-workbench .cm-s-wb .cm-meta {color: var(--mu);}
#aba-workbench .cm-s-wb .cm-keyword {color: var(--sx-ampkw);}
#aba-workbench .cm-s-wb .cm-number {color: var(--sx-attr);}
#aba-workbench .cm-s-wb .cm-property {color: var(--sx-tag);}
#aba-workbench .cm-s-wb .cm-qualifier,
#aba-workbench .cm-s-wb .cm-builtin {color: var(--sx-attr);}
#aba-workbench .cm-s-wb .cm-atom,
#aba-workbench .cm-s-wb .cm-variable-2,
#aba-workbench .cm-s-wb .cm-def {color: var(--sx-pvar);}
#aba-workbench .cm-s-wb .cm-error {color: var(--er);}
#aba-workbench .cm-s-wb [class*="cm-amp"] {background: var(--sx-ampbg); color: var(--sx-amp);}
#aba-workbench .cm-s-wb .cm-amp-delim {font-weight: 700;}
#aba-workbench .cm-s-wb .cm-amp-keyword {color: var(--sx-ampkw); font-weight: 700;}
#aba-workbench .cm-s-wb .cm-amp-var {color: var(--sx-ampvar);}
#aba-workbench .cm-s-wb .cm-amp-fn {color: var(--sx-tag);}
#aba-workbench .cm-s-wb .cm-amp-string {color: var(--sx-str);}
#aba-workbench .cm-s-wb .cm-amp-comment {color: var(--sx-cmt); font-style: italic;}
#aba-workbench .cm-s-wb .cm-amp-pvar {color: var(--sx-pvar); font-weight: 700;}
#aba-workbench .wb-alertas {width: 14px;}
#aba-workbench .wb-dot {width: 8px; height: 8px; border-radius: 50%; margin: 6px 0 0 4px; background: var(--wa); cursor: pointer;}
#aba-workbench .wb-dot.bloq {background: var(--er);}
#aba-workbench .wb-sb-bloq {background: var(--er); min-height: 3px;}
#aba-workbench .wb-sb-alerta {background: var(--wa); min-height: 3px;}
#aba-workbench .wb-flash {background: var(--was); outline: 1px solid var(--wa); border-radius: 2px;}
#aba-workbench .CodeMirror-dialog {background: var(--sf); color: var(--ink); border-color: var(--ln) !important; padding: 6px 10px; font-family: var(--fonte);}
#aba-workbench .CodeMirror-dialog input {color: var(--ink); background: var(--sf2); border: 1px solid var(--ln); border-radius: 4px; padding: 2px 6px; width: 16em;}
#aba-workbench .CodeMirror-dialog .CodeMirror-search-hint {color: var(--mu);}
#aba-workbench .CodeMirror-dialog button {font-size: 12px; padding: 2px 8px;}
#aba-workbench .ide {display: flex;}
#aba-workbench .ide .gut {margin: 0; padding: 8px 8px 8px 10px; text-align: right; color: var(--mu); font: 12.5px/1.5 var(--fonte-mono); overflow: hidden; height: 440px; user-select: none; border-right: 1px solid var(--ln); min-width: 44px;}
#aba-workbench .ide textarea {height: 440px; border: 0; border-radius: 0; white-space: pre; overflow: auto; resize: none; background: transparent;}
@media (max-width: 900px) {
#aba-workbench .relf,
#aba-workbench .rgp {grid-template-columns: minmax(0, 1fr);}
#aba-workbench .keys {margin-left: 0;}
#aba-workbench .grid {grid-template-columns: minmax(0, 1fr);}
#aba-workbench .pvw {position: static;}
#aba-workbench .kpis {grid-template-columns: repeat(2, 1fr);}
}
@media (prefers-reduced-motion: reduce) {
#aba-workbench .frame {transition: none;}
}'''

# CodeMirror 5 (MIT). O código vai comprimido (zlib + base64) para não pesar no arquivo.
_CSS_CODEMIRROR = r'''/* CodeMirror 5.65.20 — MIT License — https://codemirror.net/5/ */
/* BASICS */

.CodeMirror {
  /* Set height, width, borders, and global font properties here */
  font-family: monospace;
  height: 300px;
  color: black;
  direction: ltr;
}

/* PADDING */

.CodeMirror-lines {
  padding: 4px 0; /* Vertical padding around content */
}
.CodeMirror pre.CodeMirror-line,
.CodeMirror pre.CodeMirror-line-like {
  padding: 0 4px; /* Horizontal padding of content */
}

.CodeMirror-scrollbar-filler, .CodeMirror-gutter-filler {
  background-color: white; /* The little square between H and V scrollbars */
}

/* GUTTER */

.CodeMirror-gutters {
  border-right: 1px solid #ddd;
  background-color: #f7f7f7;
  white-space: nowrap;
}
.CodeMirror-linenumbers {}
.CodeMirror-linenumber {
  padding: 0 3px 0 5px;
  min-width: 20px;
  text-align: right;
  color: #999;
  white-space: nowrap;
}

.CodeMirror-guttermarker { color: black; }
.CodeMirror-guttermarker-subtle { color: #999; }

/* CURSOR */

.CodeMirror-cursor {
  border-left: 1px solid black;
  border-right: none;
  width: 0;
}
/* Shown when moving in bi-directional text */
.CodeMirror div.CodeMirror-secondarycursor {
  border-left: 1px solid silver;
}
.cm-fat-cursor .CodeMirror-cursor {
  width: auto;
  border: 0 !important;
  background: #7e7;
}
.cm-fat-cursor div.CodeMirror-cursors {
  z-index: 1;
}
.cm-fat-cursor .CodeMirror-line::selection,
.cm-fat-cursor .CodeMirror-line > span::selection, 
.cm-fat-cursor .CodeMirror-line > span > span::selection { background: transparent; }
.cm-fat-cursor .CodeMirror-line::-moz-selection,
.cm-fat-cursor .CodeMirror-line > span::-moz-selection,
.cm-fat-cursor .CodeMirror-line > span > span::-moz-selection { background: transparent; }
.cm-fat-cursor { caret-color: transparent; }
@-moz-keyframes blink {
  0% {}
  50% { background-color: transparent; }
  100% {}
}
@-webkit-keyframes blink {
  0% {}
  50% { background-color: transparent; }
  100% {}
}
@keyframes blink {
  0% {}
  50% { background-color: transparent; }
  100% {}
}

/* Can style cursor different in overwrite (non-insert) mode */
.CodeMirror-overwrite .CodeMirror-cursor {}

.cm-tab { display: inline-block; text-decoration: inherit; }

.CodeMirror-rulers {
  position: absolute;
  left: 0; right: 0; top: -50px; bottom: 0;
  overflow: hidden;
}
.CodeMirror-ruler {
  border-left: 1px solid #ccc;
  top: 0; bottom: 0;
  position: absolute;
}

/* DEFAULT THEME */

.cm-s-default .cm-header {color: blue;}
.cm-s-default .cm-quote {color: #090;}
.cm-negative {color: #d44;}
.cm-positive {color: #292;}
.cm-header, .cm-strong {font-weight: bold;}
.cm-em {font-style: italic;}
.cm-link {text-decoration: underline;}
.cm-strikethrough {text-decoration: line-through;}

.cm-s-default .cm-keyword {color: #708;}
.cm-s-default .cm-atom {color: #219;}
.cm-s-default .cm-number {color: #164;}
.cm-s-default .cm-def {color: #00f;}
.cm-s-default .cm-variable,
.cm-s-default .cm-punctuation,
.cm-s-default .cm-property,
.cm-s-default .cm-operator {}
.cm-s-default .cm-variable-2 {color: #05a;}
.cm-s-default .cm-variable-3, .cm-s-default .cm-type {color: #085;}
.cm-s-default .cm-comment {color: #a50;}
.cm-s-default .cm-string {color: #a11;}
.cm-s-default .cm-string-2 {color: #f50;}
.cm-s-default .cm-meta {color: #555;}
.cm-s-default .cm-qualifier {color: #555;}
.cm-s-default .cm-builtin {color: #30a;}
.cm-s-default .cm-bracket {color: #997;}
.cm-s-default .cm-tag {color: #170;}
.cm-s-default .cm-attribute {color: #00c;}
.cm-s-default .cm-hr {color: #999;}
.cm-s-default .cm-link {color: #00c;}

.cm-s-default .cm-error {color: #f00;}
.cm-invalidchar {color: #f00;}

.CodeMirror-composing { border-bottom: 2px solid; }

/* Default styles for common addons */

div.CodeMirror span.CodeMirror-matchingbracket {color: #0b0;}
div.CodeMirror span.CodeMirror-nonmatchingbracket {color: #a22;}
.CodeMirror-matchingtag { background: rgba(255, 150, 0, .3); }
.CodeMirror-activeline-background {background: #e8f2ff;}

/* STOP */

/* The rest of this file contains styles related to the mechanics of
   the editor. You probably shouldn't touch them. */

.CodeMirror {
  position: relative;
  overflow: hidden;
  background: white;
}

.CodeMirror-scroll {
  overflow: scroll !important; /* Things will break if this is overridden */
  /* 50px is the magic margin used to hide the element's real scrollbars */
  /* See overflow: hidden in .CodeMirror */
  margin-bottom: -50px; margin-right: -50px;
  padding-bottom: 50px;
  height: 100%;
  outline: none; /* Prevent dragging from highlighting the element */
  position: relative;
  z-index: 0;
}
.CodeMirror-sizer {
  position: relative;
  border-right: 50px solid transparent;
}

/* The fake, visible scrollbars. Used to force redraw during scrolling
   before actual scrolling happens, thus preventing shaking and
   flickering artifacts. */
.CodeMirror-vscrollbar, .CodeMirror-hscrollbar, .CodeMirror-scrollbar-filler, .CodeMirror-gutter-filler {
  position: absolute;
  z-index: 6;
  display: none;
  outline: none;
}
.CodeMirror-vscrollbar {
  right: 0; top: 0;
  overflow-x: hidden;
  overflow-y: scroll;
}
.CodeMirror-hscrollbar {
  bottom: 0; left: 0;
  overflow-y: hidden;
  overflow-x: scroll;
}
.CodeMirror-scrollbar-filler {
  right: 0; bottom: 0;
}
.CodeMirror-gutter-filler {
  left: 0; bottom: 0;
}

.CodeMirror-gutters {
  position: absolute; left: 0; top: 0;
  min-height: 100%;
  z-index: 3;
}
.CodeMirror-gutter {
  white-space: normal;
  height: 100%;
  display: inline-block;
  vertical-align: top;
  margin-bottom: -50px;
}
.CodeMirror-gutter-wrapper {
  position: absolute;
  z-index: 4;
  background: none !important;
  border: none !important;
}
.CodeMirror-gutter-background {
  position: absolute;
  top: 0; bottom: 0;
  z-index: 4;
}
.CodeMirror-gutter-elt {
  position: absolute;
  cursor: default;
  z-index: 4;
}
.CodeMirror-gutter-wrapper ::selection { background-color: transparent }
.CodeMirror-gutter-wrapper ::-moz-selection { background-color: transparent }

.CodeMirror-lines {
  cursor: text;
  min-height: 1px; /* prevents collapsing before first draw */
}
.CodeMirror pre.CodeMirror-line,
.CodeMirror pre.CodeMirror-line-like {
  /* Reset some styles that the rest of the page might have set */
  -moz-border-radius: 0; -webkit-border-radius: 0; border-radius: 0;
  border-width: 0;
  background: transparent;
  font-family: inherit;
  font-size: inherit;
  margin: 0;
  white-space: pre;
  word-wrap: normal;
  line-height: inherit;
  color: inherit;
  z-index: 2;
  position: relative;
  overflow: visible;
  -webkit-tap-highlight-color: transparent;
  -webkit-font-variant-ligatures: contextual;
  font-variant-ligatures: contextual;
}
.CodeMirror-wrap pre.CodeMirror-line,
.CodeMirror-wrap pre.CodeMirror-line-like {
  word-wrap: break-word;
  white-space: pre-wrap;
  word-break: normal;
}

.CodeMirror-linebackground {
  position: absolute;
  left: 0; right: 0; top: 0; bottom: 0;
  z-index: 0;
}

.CodeMirror-linewidget {
  position: relative;
  z-index: 2;
  padding: 0.1px; /* Force widget margins to stay inside of the container */
}

.CodeMirror-widget {}

.CodeMirror-rtl pre { direction: rtl; }

.CodeMirror-code {
  outline: none;
}

/* Force content-box sizing for the elements where we expect it */
.CodeMirror-scroll,
.CodeMirror-sizer,
.CodeMirror-gutter,
.CodeMirror-gutters,
.CodeMirror-linenumber {
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}

.CodeMirror-measure {
  position: absolute;
  width: 100%;
  height: 0;
  overflow: hidden;
  visibility: hidden;
}

.CodeMirror-cursor {
  position: absolute;
  pointer-events: none;
}
.CodeMirror-measure pre { position: static; }

div.CodeMirror-cursors {
  visibility: hidden;
  position: relative;
  z-index: 3;
}
div.CodeMirror-dragcursors {
  visibility: visible;
}

.CodeMirror-focused div.CodeMirror-cursors {
  visibility: visible;
}

.CodeMirror-selected { background: #d9d9d9; }
.CodeMirror-focused .CodeMirror-selected { background: #d7d4f0; }
.CodeMirror-crosshair { cursor: crosshair; }
.CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirror-line > span > span::selection { background: #d7d4f0; }
.CodeMirror-line::-moz-selection, .CodeMirror-line > span::-moz-selection, .CodeMirror-line > span > span::-moz-selection { background: #d7d4f0; }

.cm-searching {
  background-color: #ffa;
  background-color: rgba(255, 255, 0, .4);
}

/* Used to force a border model for a node */
.cm-force-border { padding-right: .1px; }

@media print {
  /* Hide the cursor when printing */
  .CodeMirror div.CodeMirror-cursors {
    visibility: hidden;
  }
}

/* See issue #2901 */
.cm-tab-wrap-hack:after { content: ''; }

/* Help users use markselection to safely style text background */
span.CodeMirror-selectedtext { background: none; }
.CodeMirror-dialog {
  position: absolute;
  left: 0; right: 0;
  background: inherit;
  z-index: 15;
  padding: .1em .8em;
  overflow: hidden;
  color: inherit;
}

.CodeMirror-dialog-top {
  border-bottom: 1px solid #eee;
  top: 0;
}

.CodeMirror-dialog-bottom {
  border-top: 1px solid #eee;
  bottom: 0;
}

.CodeMirror-dialog input {
  border: none;
  outline: none;
  background: transparent;
  width: 20em;
  color: inherit;
  font-family: monospace;
}

.CodeMirror-dialog button {
  font-size: 70%;
}
'''

_LICENCA_CODEMIRROR = """MIT License

Copyright (C) 2017 by Marijn Haverbeke <marijn@haverbeke.berlin> and others

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE."""

_CODEMIRROR_MIN_JS_B64 = (
    "eNq8vdly48iyIPjeXyHSqmRAEZRIKVdSIVqulVknt5OprE2pcwwEQRElEGABoJYSaXbf29psHuYD2trmeT6iv2Ke75eML7GC"
    "oDJrrKezrCAiEKuHh4e7h7vH/g+tnWf5JH6bFEVe7Nzfe3B/76C385//8X/upMl4p7Mzh4/lzvU8DXb+CC/DMiqSRRXsRGUZ"
    "7MyqeTpPruMJ5Asnkzwrd/LLuEjDm2BnkoRpfh7slHFYRDP1N1oWZV5AVcv5olvl3TTJ4gBr707zdBLszMMqmlXhOVQeRlVy"
    "GcscYZblVVjF0HyepuMQqlikYRTPoFRc7O28fX2y8yaJ4qyMd7zI33kbFskf2c6rELozji9iqGCyk1ezuCj3oNvVohzs70cw"
    "tDmNey+Lq/37+zRsKLHz5vWzF+8+vdjJ4rIKdxYhPPd2ftj/L63pMoNu5ZkXB5V/287Hf8RR1RaiulnE+XQnvl7kRVXu7raX"
    "2SSeQtcn7Zb6CJBcpvGI/+zJrKLy/EFbVWtq4tK7u/x3L5xPRvzTq/yBF4t4tSrjdOrvmcnDqtZeNUvKQHcT+rgEkJRVkUA/"
    "h5dhsROLLLxMzsMKhg3fiifncVYFlZUKkK2meTEPCrF/HkcX+Zf9L5P9ZA/AX3mxH2Ri/+2n1y92IFGnJWL/pEgmUNWXfW80"
    "OH3YfXy2+jK5PQjW/pe9vR+Ky4H3ZdLx92HgcYQlcrH/YnIeQ3Y3PRTZapWsVnmQinB318tGkzxazqHmPfXjLYx5tXow6Hg5"
    "ZPVP+2d+UIpWvru7/0s8/kcCfTA9iwTMx/4/KxxE58sePMy3JRd6Nivy+WZPJmK5u9tZQvXBVOy/X8RFaFc8E/tPFos0hvUz"
    "XyyruJCfDCAv42ySF36wAICF0c77Tzu/7vS/TL48904fMXy+TPwvz02V52L/wyzMqnz+0yeTOhczgMP+23ycpNDLL1dmBKuV"
    "aW0eXp/ky2j2IU+yqjw+8INL6GE2KfLEmqgbMV+tLler/at4/P7T6imsoouncVHcrGiAO2+TLFE/ocHV6xfcrjX/Y6wCRyRr"
    "rfzgWux/GT8r3n/6MjZNXYn9qyRTBSHXhZju7sZ7tMi9/Z9hMQKOEth/wIn5wd/3hxcw1Avxbjkfx4V3gVML5XZ3L45F/z58"
    "mopWH+e65xMyPxNjSIxWqyliyjJNhbhYrS6O+gd7/T6U/CSK1QqwKD0Wj4dqVey8gd7dFnG1LDJY4lc7H+PzF9cLr+39a/Xl"
    "S+m3O3GnDUj8Hb3B/z+0/TW29jY4ES4FwNRCxHtRGpblu3Aew+J4A0NlHCr8YTL1Ms6WiGKvTIFGedleAtThupOd9s720jg7"
    "r2b+0KpDZ+wFMqvf8ZJRBsDoJIM2dGZtxvIOxwKr1cM2KuzKLEkn75Bqy7qH1XFv2O1WfrxXxHMg0M8whxfvTZOirOjFH0po"
    "xGtd8XseofyAzeyFiwVgNBevfJP1CWYNikCPVK/YqIiBar9IY3yDKhAeBUxVYo8WKAolldUNEEbYWU7ia6BHftBGupWdG6pY"
    "+YnTiVo7WA5HDp0DgKZA+KC5ylfQyUVvmB9VCiydTl6rrjrNzzQoEjO+5/XxmQHr3HtlXD2poL9jIAVeG7apuB20F0VcQv9C"
    "Iu5AJU2dfzF4oYOHMLy9DLp9AoMEQFTwuggLKIZj8QMASQ5VJFnpq1nSKTC64STHWvr9hmpmeQnLrhIilkVbvfUVDDWuN2L6"
    "9QviE+FSgIidX2Vx8VyCebWKh1Vxc4toxtuznNl1REsaSlaAvON8cgOECVbjGkE/rHZ3q71yFk7yq495XntzKxr62LGtX+X4"
    "K9PdD1vW4ZBWIRGeAqikZ33qCK8YtXfauJI6Nhq/4LoUumB95SJNKg8y467XG2ZHhcKerNPxi9PsbHe39cbDH74icwj7joAy"
    "HUo2nX5bXxcfw+w8HtkU5Y5FRJk9F+FeZBMPdss4gDVECZ+qsKhoGIBrA7dmrjcz9eI8WStHNYAznO0hoTjJJeDxM4DQRhg9"
    "44qOrtUPQM40DRdl7AGVDrgm7Gg7moUFzGdctLG//IE7bH+CrmdrIu4vLWLr38JkxClwW8DkGOr3yupBvDdJYL7Cm72rAld1"
    "4SKvmefXVqGP3kYxCyM+OtWfxxXiJI5/5LwBCxdva+ypVQX2dg/YuHCZVj8n8ZXJ9YdedeJJUUBfFkVe5Uj1eCvYi8I09cLi"
    "nGovg77GA4vV0x2FYaQ3tB0CNNemlT8VIigUBzQCxITlUYnbNVAavxXvzcLy/VX2ocgBFBXUAqunBbRFFLhuGz4C1czOROyi"
    "um7yZ4XVQeLf8gYNBKALFXpIRVgq8PZP//Wl/LLs9cLe2b5PKwg+qq3R0G/A9R4wiMAd9oZDBlgKGWmPfD/12l+qdpDTJpMe"
    "9VYr2PUrRTPDjld14VvYEWk3D+BP0Q2/L4ANTTv99Xo+asY2eCUUFb3ASgJ0hmYvw3SperkeIK/q1oELycJavWLWa2Ze/iGs"
    "yUO+fS+ZCJ41fJlav6sENsoe/wYGcZLGhfiDeP29PDuBj/myoq/24vhcp2e9YXEUm+2v8AFQ8WlxJgyYCjmH3f76HxYS6kZq"
    "QIIOI2Cwe0eig7zUc6AmsDqmsCaAHslSXqx6LTN3dV5/HdgNQZkaiyVhUQ15DLpgJx56LQm11ao40nBC9IlSQCzVuMzkBwrG"
    "VsdsiAL+W9AGOkBN/ihuq/wTMSKDjcXWNuLX3gfYX9rrdfBvccti6qDVXwffidu8SM6TbND+YZ6DwNVeB7+atA4SwbY1ab9t"
    "rFGAcCI0vud1fAceBJcTyDFebi0azBuKvJvhasiF/gICUye01kXWeRtWs715knlhUHUTWj1JB0vClpd3+gG+Fd3k+8K3i62J"
    "I/5dnLbbZ6b3/1Tc6PB32d6RiIf+73uLZTnzfvJ+9zu4mSpC8ftpfGZoxU82tT1VHe72rSxxXMfp0zO5M8f1nRnkYaRKFpNW"
    "mIqAR4OFqF+L2OIjVPb3JN3LHXJUCOcd+jrwqtigroBdWCByVohGu7t/ejiNQUFwymKxf4oEbjKF5/1HD/H5uNfFP9N78HzQ"
    "o5cHU/h+2LuHL4e9x/QS8gt9uUfZ7k3G9+EZ08vjaRR9WYYRvUwehtOzfTMfSWxgCoKjJTfGx+3/+R9tQBpYkPln3PeehbBl"
    "+y2BCW/yK5UAnFysillbYx478kE1arU84NzyZRHZCPrlqu0fd/u7u9QTqKxSdQ0oxVQYxo4kgztTTASqvukghxWfVmeKpe0P"
    "NW9LG4IE9SFD9PABQvzeo8Mu/XlMgO8T4McTetKMRH16HtDzHj3v0xNn6kGfJ6cf4vPemF7ux/h82MPn5AElTSJ6xvQS07TG"
    "VD5+RM+QP2CzD/vY4MNDqvjhPaz4YUi1PBxjlQ9jauXh9BCej/r05VH/MT3py6MD+nJwn18e0vMxv2ADj3n4j3s4pMeH2LPH"
    "92jcj+89oiflus9J93Gwjx9Q3gdY8eNH2L/HYyo3xqE+jjgrQedxRKUn2OzjmIrFWCzs9emJKSE1Gt6jlHuUcu8hPR/Rk4YR"
    "UjfC+5SJgBk+5N/Yo5B6ET6iwtSXkHsR0uyENDthRPVRj0LqS0h9GVNfxtSL8WFMT5zrMYNhfO8ePbHY+P4DemJ1Y4LCmKAw"
    "ppbHNP5x1KMn5aeBR4c009G9Hj0f8Msjeob8gpkjAm5ETURUeUSVRzSgiPAvIsyLIsoTUTo1FE2o7ITSaWwRjW1C45nwSCY0"
    "kgk1NqExTKiZCTUziUJ6YjOTyQEVmFABqnVCFCk+7NPzXpf+YIn43kN6uYctxWP6Pubv48f0HNMTOxtHj+gD9Xnaf0RPzDQ9"
    "vE/Ph/SklIfU5+lDrHb6iJB0+ugePR/Qk/IybZw+5hfC6yk1NUUY9XsHky7+OezR84BfHtLzMT1Dek7oGePz/iN60tf7MRV4"
    "QKWpQ/DnHj5xwuF5n57U0iOq4zE+D+8DrPoP+9Tcwz4WeMhtPzykl/sH9DzE50P6/ZB+jx9SJiQ4/Yc0gIfRY0qa0PcJfnjU"
    "wxUBf+glxI4+PkAwwJ8Dej6kJ47j8SGlHFIljw9hJvph/yE98XOIyAZPnBX4g+MPabAhIgY879OHBxE+Hx7Sy0N+wRGOiXbA"
    "H+zcmIY2PnxASQRXWlP9Ma7p/vgB9XpMAx0/6tGzj8+QIDMO79PzET1xUNFBhB+iw0N6PqAn9j2aULPR5ICe9+gl7tHzgF8e"
    "0RMBNIko8yTG8pMpocME98iDXi+i5wSfVOVBbwq1HETxFF+iKXTvYBLTlwlvuAch7bEH9PL4MT1hpOGDB1gkfICTCc+InhN8"
    "Yo3whKrCR0ju4PmAnmN8HtynJ6UgwQwfUXPhIyrw+ACBCX+wpse0zsLH9+kLLQj4gzU+Hh/SkzPjoguJIIchEXr4E+MTly48"
    "D+h5n57YbnjvkJ5UAPcUeB5QsfE9ej6k5yN6UkVIicIQd0JIuE/PR/SEbk4kfzFFeE3HfSgwZf4D/mBSfMAvOObp9HFMT4cX"
    "KWNHmkaRH7nnJ5XXA87y4YNHu7up5jQMXxDFNkc89Iqj3qg67g0qzfEBP4B1U41PKlL++RXwrA3i6DLeZK+r42LU7Q/6yGGj"
    "vhBEXcXlstCRgKwKwtL+AQiLGbRODHMUJ6mX+AN6maY5VMe8c25JU7GX+6NqUAzpRyHyQQUsteSdJzEJeAZA09hR1Ax1BtlV"
    "lAISW4BLtEhwmpxR23vTIp8fAfeZAxN3rPuRDPGdRG+ZpyUwZXe3PY6h+rgNgx5lIhlAm4kfcJ678rfs/Fr1A71tiWyUQTIN"
    "cRbbIq7h4m1EOBIH9x6O2mP1ryqrq3Ls/CtLSHv37vvvv39H/wL4r6//cdq7N1v/fct32dB4678Am6f2ub7vv4eW8Wf/zV3V"
    "39Esf28rtAWOuH/v4B7IS8DeHon+/YN7o/bH9qB///CBTnz46P6ondG/d++K778vguLdu7n5V/zNf/Omf5n+932WYabif8c/"
    "1fg7NZL5/B3/MFNtgNVFsADEHj7UEDs4OOiN2kV7AHzygUp8dNA7HLWvIPGgdw+kYEC09qD9pr1mZRtJClsFsd5DfnkURmf7"
    "eBp6ingIPzP4+eZjAb8S/DXuZ/Azh5/4wyzoUK1n0iqk8WWcgpTICg1cX5VUN+SiWNfVeWlQ8uqORDutClig5Qj6PQCUwJXe"
    "EyLVEr3KsLvbkuJV6hvpSJGPpS4RTFBsngI5mR4tgY5M/QkL6LGX2nR56vtG+zYTvWAhouGMisy4c+dicjo7G7bn0Pz5CH+L"
    "xWAhzteq1BxKXUKpOZWac6kbKDWHUn0odQM0BTt/OcI00c7ag4zHcIOKnEtxE9B3yOdxjo9tlENl/WPRD66hut7ZcHy07Pah"
    "kTE3cgWpY2ikA4WvoBFs7Fr+hS+d/tkIMwhIGLQDIGhXq9V1S34CmPYhCfNn+He18ijzNR51XunWLwCEFzSyC270GZS/IFIM"
    "VQrxzMdX0X7X1sdR7e8pnXJ/Epd5MtnpEYw/iYtOf/jpaAltfk99/HQGFX8yM/BGXMC3Fn276GInOXdf5h7RUN61g7fiYvj2"
    "6BOUfgsdeHsm3gwvxKduf607fgLT8g6m5YQ6f8LdeQ+1nADE3kB972S970eYJhDz5LS8x2l5J96bOXgCUHhCFT1Bgb3gfJPT"
    "J2c+V/zcHudz8QTG+Rx7rnM+P/Oh9HMz1L8E9cJ7As0/gaEOIj/4RfwFKZwOxUdYDNL90V9qYQyi4IN4Mvxw9Bxq+wBD/3Am"
    "fhk+Ec9h6KrmF8FLRP5X0OdX0GfscKK68Up1+LV4RV3pdF5hrt1dOwvU/cofvuQVgwqf0OsFr4NXgJU4yVTBR/EqeCpeqvX2"
    "h2gXVUpruD/ouVVD3xHrXp1xvaqff4qPwz+PXlEHc9X6n9jBj0d/oqqZzqaAOXoa9ALuRT/4GPzp+8HTjviDFYA/iz9lY39i"
    "ZcQW6JqgvT9xHBv1HAQ/63qCj+JPGhZW8RGr2NIwDl/qRDU18vpCvORDbiB98P4CSJA8/f/Xl7LDqn7KQfTwhTkQD17uLbNy"
    "lkwrDeJeYH0HyhRA7T95L/2m2qHy77h2ylHl3VrlzuQtu/bHpY+V6wl7uVdA/QWqwgYv12vPN/R9Ebunj3kxiTXXyYcdeNit"
    "P4kZsqlVfA2E31eqwfMY8XEei/ppHem+wsnkxWWcVW+SsoqzuPA3k1DPGLT65sQbslRVGM0ol++8ee08a3ew+qHG1Qy692+p"
    "Ai/pqFS/4anQMDutzoSHz9XqPPbx7DkK8VjVNkO4dNWBVh1o8aFfZCWGIb+JneGygUJ9xA2pDYOexPagrbevDhp28Wx3F0dI"
    "ym/FVX/2EiyTk/6SACASbZmRa0CotLzTB8RZW+dtYwc/JIjIBEJhsZFCvunY78APWAgobCGgAO7fPvPLLOnpWsNXLs4Nkwo6"
    "bLvFt0EVLBDXs+o5n1EO6udT8uzyA+eKJ6LVW6/9gMZZkG4Xqgno+PktWmFgkrGye32egehg+nYVm1PPbQizxxaDT9AMIKlu"
    "ho5BB534L4v3i1quVzYy35UBVp462LfMQjIfD1Q+e0WAR5s+7lNELujNdP/CRXk5vbKa457J+CzmwzL7OK12yDWP2XAPX9aB"
    "k3U6reW9sfOaVj7pVuwpHNUT6Kyau/wznl+KVt/U8UbWUVb5AvXt4TlZrow2UqiWKMyiOH26HI/TGDFBV/PWFvBYKIw3cGe0"
    "mTTo4TmV1TlT5QlVSWMM3rgHB+9cvUIFyyVGU5W9soiUfYqxanJw7mqWRDOXYON66AMGjpdVBSOvRH9wYL8eDu7pV1o6B0DJ"
    "x4izUVWk/4iBT+1zLZDXDyqi8U/i4Hkc/OVIw4DJaJh29Nhw6mye+cRrT5JLfUjWnhTh+XkIMG7jkQhwppjwHOaC3p0N6Rca"
    "Hdqc0VieGKMCr10uwgyY0v/8j/8KVaNxl047rYJthlTt67aPFng9nEFjL4ZYWcbVqzg5n+FQn8Sikmm/JBM89OujtYCd6/gA"
    "pBMe8SOfzekK6OCo1rOBef+f/70dED1rSwONwU6SoTlwd5zm0cVw5wqbGuz0F9fDnTnMepJ1C2xqsNOFNHPKWNRss6J5F/dg"
    "aKKNm7CxJbKh1xLPldHUzvN4yGBEsG0F1ZP/5/9+0sZtXbyF3akX9H20EXmaL7MJUNxnaQKFPpIpAJAczNIHer4ty9Cyuwta"
    "XguoK9L8KWqn9miUyNw8j0XGb12ZenTIsH0RBy9jcdgS7S/Zl2zclpZM+1+yfUWiRvZRvrEg7AXyUFUrmqojkQ2VVZJ9uJeh"
    "tQ6dPidowFc7fcbTaN4Zq6D9BVlCraJLun1/BI9Bgva+uVVl0cYKWyIceZLq5nrLDQG4VUeEsM8O9Fc0b0sgZa3PeAf2uDRZ"
    "UOMvvmSjFUJhHbyKxRW0nF/hJHxSth2jugmHqcKxCGkJ1yCkbhEFdNXtCoFX28855kKmItfYy7IZkZV6rQo3VbbEUnaVeGgL"
    "6ACLFLfbOX6EDrEdsNem3p7kkNKm3eV1LIAhivLFDRAQ74UhOGjM8yKuLRaZE/hh6sAQlkyDufoL3NMwox98lFpLHO7TGDjI"
    "4A98GiL1p9w3NVujtswDJJqwKaBBZpxFSVx+K1cEskp8Gp8J2/BILeYNjife3f1j41A59v1Y/IGVGI4SZLONsntZOG+ugL74"
    "iuBiVZQC8vQWlgu/Dipgn7xYFLhIoDQVQTtO+MPS5JYR7P/r9MvVl+5Z58u++tG5nqff6RN+RbsADm3kDZOINu59yNQmHvRb"
    "a/2jzLOvV4u52loC3Kh6xKON1wPYwPh3G7GkbTEw/5B4UYmfkXeU9j4wsZUEJHS6pVXzlLuNdHwf9oYEGh8yI11oLvvzpumA"
    "PUmJ+Gzq1jZmaHeQ+Em9ZI7kNmtOPW3/u93Jz0SG5sMBPkWCP9e4ldgzGlR7sziFotJEN7Nehf0NiNoeOt5gQ6Vmd0Oy1rM+"
    "ZKch4LxJgFfNzNAu8NldeT9KCKNpyueGJTD6jAtgQE8U/czc/DvW5sotYNLMCUc1JNkLl/4ndNCxTZRlkplL7ItjeagmAjnr"
    "YQJJZYU8JWAMLXzaVBIlZ50iI0KGPcl606Dnu7pl0BB3KqCx6CwihXD9jmdEyNYj5FpooIRmyyV2NkDre0zWzAPgK74P4oAy"
    "wIo1jf5ak65ayCgDtaVxEwuq38gaiCblt01Rn4SrRV4K+lFKg0P5gktJqY2rcPwpAT4SNoFHnJKGwJPl6XKefVDlTRJz+LIm"
    "ZJ0+2VVjwvsijIB7Lyws+d3MtVd1Fd/no0FldYybHnTAr2ZFfkXOEy9QtPPaJ7O4ALJZ7mT5Dla80+54VUcV7rRpvmfxjmaf"
    "2kbXBXMzbBXUn3JoycS9IUlj2n2CXBtg40OrrhwRY7bMLhAeHq336iiHiRDJcAx76MUa+p5rROHKQYQ3k/dP97gNmR7ARMqo"
    "3SH2kgp1DZQYcCWdflDf1ZHTQUo0TJA7S8lxy8uF4Vyw6z7K7rJ+53PFHzPN0IBMv0YjaGMYt9HTegeDwumUrIt75buVxZWt"
    "lKi6QAeIQSe9hAX8eJgNM2AvmdXwM5mtI2wrusqRN5SFuG9JVEPbN4U/A4P5WcK0DMifTDE00GQl0O5QN2uffWYGAZIz4HVY"
    "+dERTrqDFGr2OxXjoWXwV7mqO/o8jAeT3Da8JLNCVbmtINDMcB0lDSwJG2PARvTVSLJlDLIaomQAPXZQ1xAzds0AIkKgMesj"
    "hJ6ERzLZdCM0FtCM3eGZ037q00IYQqupbqQTGiBklWvDd6wAAcLbkfzZ4QVvCiVuIbaM9bgL7Lb1Mi/mYUV4qQjAG/3RsSGs"
    "LOUfHxEIpTJF3EHJBymVvTHkleZBkProKoaapClaGc3UAVtZJdHFjY24YVVTV5JcyTiJdDuadXFZmgJpvYCsE71V6Bew30LI"
    "ak0x4plUIewrUxJswDZxcCuXtaCdw8AC/HJbLtyTdK6Jm4uNe8Nr5e4VaGtf4DedGQaRzOrStNKbAENF4YNvD4ar7Kn9vV6h"
    "NsCgGo6LERQqAtpfCp9okxIYB1vc6mrKGZSCj6uRAWTlD9AexCT0fAAZjI03MUpzWzJDnFVbbYmrDVtihoft5FCsf7P1dHGe"
    "ik1fDLWxHwtrM1cuA4FTQXlnBUK4e3it8CKOL7aVlo0q6xhZIQh7vOJqNWXoe+eqqVSRo80x+F9vCCBYawIEXLEhGIu7+tos"
    "r4zQsW1QsQ0ziCejWLlgDYjDk53rdFQ9QbXZk1+Q5opmVYgqx7QlDsmD0Xi5qLltqPXTIoxc2xdZaWwqBRFL+7zIjt8BAmjY"
    "DGSjC3EdmS6SBYn8Gy4mFpd5By5S8a9MklLaSHKr5qk6BkpSx94qaNURbRxGF58XrsOMzA5MZy1zROzsNgx3eOAjw0OjnN3E"
    "EP9sQzow+R0eu4G9Dppq87fy4VSn31io67nLedTQJf3R6ZY/6NXXE06E9DFtgJBbs+VSJOv7X9oVOn5tOslUq1dHQ4gVM2uj"
    "lGSIFTrJ09xYLzk8pWO8O+6NcCgDD5Ja/ZbUuCuSI2zXajwPY3atQTFYjGruDrB90CGgsxjL5Rh+6foDrej0hUiMVqShIzrn"
    "5gKIlgWyuF8h2xZILBxF6NSqmyWT+CVr6MOibHKi0rMI3Rpamk10TpsmWZimN7WMuBBrzaR5fvFkFoeTbdTBSJWaSuFZgC6H"
    "Zzd1SlDGJ/lF7GCvRSw3a0TbLlPMIAx7bC0aXchIele8oRkFEO/zSmz64FplJMxBctXFkc0s+DcwV290beSgSMm6d6XlxqcT"
    "kUb0LZl7XtW9f09jbp2UET/GJF7crodvKCPbEMTYJfruiH8W95dIOZD0vjl6QhmRQik8LK4DGi/sjidDJV9wV2RwlxKFHeh/"
    "EKFHoQRSqxfYfUub+2V4rXIYHcVDRQSS0/JsmB3HaGkjzUvKoB/EAXzo9NGHK4DFdAAtav41xnVNx8Ho7rmXL8I/gRjr4kVQ"
    "dguooC07vdPuVBglpOgcsIaXrImLI9hLoWIlxyenBTQ35D/Cy0d5R3mK2xXBogA5XQ09DIqN6S7qcw1N94blUR2URpor/dQr"
    "FaW7pVgI5SAJyG0dfuV74/Nn+Hu1ygnE9DLKB+Rnb7jaS1umalUcVKHEMwP+BYSxJWq4pWbhhsqSBTWpQiy++Ri6vMAGCOFf"
    "gZCZoqD5hj7u7qJ+0GBjxtVjjBeJ2IB5CSk8GWIJKjjp55MpyIkgwZfhJUi+Mh37ieoR+hHkexIGI/ntGb8K/WHgfqBjBCcn"
    "C5OFQBUF9nKm+v+yQOE8LoiHVP1XicISnurfgk5nS1XaDmpHDcWydqlcRQ5VEaAeQR5xko47o5Ys3aEt8J5XXgZ7SVCpQ7b6"
    "ZqvVF0ES5LIFWO1o4l51rZEYbeioHx8O+r2eD7SgGqbH4bDbTQl/0iMAsiv2SU0JtlAKkLLyIAV+D6PsWBOKw4gApnhsmXa8"
    "yBbgF9UoMvQXWAhswwatlu/5DGkJ7FrJRIVWlkFExYYMpfopWa2y46VPWmPoFMhySz0XyVrCB88bjzOl5oABZEEOA7A6j3GH"
    "RucVmaR9ArScQJYQ1vtAg/9XjOEyp+AcueFNWBWXQyt6SmA6xjjlhSSK6owilVpGZw0A69DtwxC+vy9ED4cikr3LJL4CuMyB"
    "7znit5N8lPJq8WnpA6VFkQ0VLB5q+gpaZg4ac2swu5Zl0sZ+Yy3fnNxYf6MjqTqwUdOCGJZLLXVO7D1te+02MT/XFZpNSQow"
    "bOUoGXsgvVxheq6/BE4NlsGSUTzAFp+G2QUOzRwr6CSPD3ksPFZ6A3kUYI7/Cd11wVE9wVN9GkiJ2DJRsuDkumH04QGi7W1G"
    "J0C9M2618Bkv9AF4xQxKwKGAKpYXpWSgltR6Q5mOo4F9hk8QYQeahiCkTnaqfCecXOI6wohecTjfa/trwNS/wZ3hJJ/HjC6a"
    "lelYHDaZPsA0xscb3I1ibB2OB+UfZKHu5udiuR25nNGGnnhYy3C6wTWdkT/5RjJs4UNrlHfVgPu73GTZ6A250yKmcHLevrez"
    "+pevdvq9H/bJRgS1WYOvd62LzLIDCbUyN6Rwgnpnk4E87kFv6ondLlWr6dEGyVf7TY3MSnoVB7Q709Ku1OorAosl16TNyerj"
    "gZU7HqQ7DZhFck88+rdEKU1IDA/tD8xvR3nhDp66vAAGZBMyUANz9xdV8/EZU5PYlpJiCtOxUIK7OkpTkpenwj3Q8StHLLL6"
    "7ByKPasTTCBlodxdYb/g8dKGGAZeherCEG18JeWNJGslz5Ew8JwksaVi5et0NmI6m9FR0ekZbnKr1ZLVcKg9BrF3qUjrUg6e"
    "PgM7AVQrDZZBpCY7Q8NvbfF8UXlL4A1gtmS3VT7fUAHkK01WlcEyNrSoNJ3RqPAUqLWVNtjeaPCv1Zey45Nu3UN9z3mBpk5d"
    "f+R9+dTBaG98pM/HFLG2F8IDMxn3TCXJhE5hx0yTB/6n/bNRW3LHwKtr5rg9lCZ9IK+MKEpNcXpwNnAivlEfKeYbfrPCvrVV"
    "PCfU+cooNyqq08GZ5iss/fybysS6QexQpzPF3jTF45Ds0yLMStkntFdHwUpNu52FB1aieIWIglg5uWtLBuFoalUVTia4fxAI"
    "dndPsTzbN8gNGubuGvXwhkuHbXqicAmndMI6xTs4/hF0vtUPwt1dyUlkARXy+Y9QYkMgee9BKaDZK2x2ohoOptg0PG/ZvWiK"
    "U4sb3hDDHZaiPe+2O145mqEI1ikHM5/kvVYK66AlSukPGh1NGPuHfuJZ4qFMDaLO/fgQFpw/XIpyLVPFhJkOVQGqVLkbC7sG"
    "XE1cfph4C6gDpmTBzptvkeoFJ/i0YvFVDkWah8UFsF/bPL6MTWp9MW2J1qOEhtOCbGEy1YATlcUE5asfb9TjpOA5JgZIoe3e"
    "A07dwxMQoFmsM3DPOkwsPPtgaIpza2/i3HM+V6QRMwEkRttN4s5PCOHxwFfqDvJaAZVgZ2eqAQQw22gbpVZqI5oBG0vF4Vco"
    "+GyOv1Gtvq33cLxunVm42+WWbBd5Eob6EJz9ZQGaIZCsKF2WyWX8Jp5WI+mcK6qBctP1UZbXnrbtMex1WBss05A2JSlBtVQj"
    "UGEZFxXW5ivqohqtcrfJj7hYR+QGTC2SOzBtIl5mTTOSlXe4WXFHgpTVqpgffRk0XsHCTYCkBeX/b1D7pgF8G8C+BV7fPkl3"
    "AE1DC7N2WUDlsRgwdisXkBntDUBJKGCjpWIBWv+TxynKRBdE51ECIjJFNNPgnQB4J0epAe+EBzcV6enkzMB0ipMoiSvQmDKY"
    "Srj4w9kIxXPMIAEy033GX52lP6CPyRpJrjFBW0DTiyNLa7VQfqDl6UI33RLn5Czu4Z8OSOESMOcEJ/89sifnqi8AW04XwLHg"
    "rggJqQXscxXLk3N1tmZb8576F3m/BrD1lS3aZktMwgM09kc9TdmSMOKeXwY37jR0D/DzDXLiBuRjGPfYBvnYl/v46fiMx3oJ"
    "HbrcRBLKwENl/QXth0YRew01Xx/dQJXX/pxLXvpD+avUfMbcihxa1Qy2h5W91szxOfoz8XQUBDq0eOPFU1CXiW0v1FqhkGm/"
    "zOLsxXxR3aCCXWpSq243MPbVqqVRzJpH43tQ2Z4VNXK9EYausje2CnY01Q322yL5NMaouFZFoqbq/GBtRd9cPzvDNddvm/a9"
    "qBzzcZdKdPsDy93l5ZasTMGcrK9qZke2RY80P9GLC728WyYWRTFUOsMpsMIea2jlzxx3t4wpeMKLbLWiEXRfVFJRksuKurmM"
    "DUdFqhwKAJlYrWgU3ZeUXZmYoNo4mXQxzp8VPtMeA2zdJxUHdXYmPLM2A9aqBBx+N7PD73oJG81qHJSRQye7u7y8vGrE4xlQ"
    "LyV9f4V8ZKIIyFHPJ4shndDAtXy0p4gG0OpZ4szTzc996/Mff3fEuP1lDdsfGqgN84bR1ngHvfdYX3B/lLugDYa8Dgad0GAk"
    "+2dlh+PkPklzT9iVTyhuSG1YoR5WCsNKj0IzrJSrKEUoaWq5MTIVwkB/IYTtoQAM6BcxxhaMrCoP4WyC4dcpS4XnVoSeJsPL"
    "SgZbaXnLYwGUenKEKtPlEf2GFAQFv5lOuesST5rcRa1awziHvYH11oPmuZm/WRmNLvOPVHXqvadtU9B/0vJZcCn7sBIf2eQk"
    "Vku920fEdW1ULQt6h7qoic3Ez+itq1eFENmoGlSw+i0U/2zRUpD80FyBVcpuKBzE/t+NH2vrx4rO4UwmPlUTT7H2oZ8JOeOb"
    "3ab2O5bv4Y9O509ILVfDRds8VRKVBndYtFtGrUDSQFcsY1Uml3oe1MkLF7hKJucx+XWRXV8m989sY/pxsnd3/61OuaxpNbbz"
    "9omctGPTnFlmNmADKAUjKpmx0ug9Umv85QhOqjCLxsU27Cw4+o9jCKcHvoVQO9B3YqYDfHHvsT5voeGtpAmeicOEqLMbom/4"
    "VNwKneM0whtd4RoH6uuZSKyZMC4C1aanmxcLWnW+sk3WYb5dW1vLCp1tbTP2FcfQ6tLKtqPNf9cmYnGhLJvzYS6QOvt1y2Y2"
    "7s0bzIy1Bsl8RA8PlAUwRpVuNlXNbsa7+lUZaJNnLWdTi9XMPId6t0URNP8m6oOr+FZL1kS8CUMzkRhhnk2apdzdTVjqJiBw"
    "PU+tenK3nqIrMof7zrX8DpVC+dyoANxs3MjmHvebw4fKc1Ua4CSPhhUplVEl/zvaCBTydDPQ6azfEr+itkAmWV+fzdAxD/3e"
    "UUWJ5311bXghCObD4rhWJZ1Ku40UpmJAozWbKf2+Rb+Noxdx8IFtAgNlWMZzKooRmyf5A9us5J+V9AknlGNVIvHp69+dUyO0"
    "zs6bDJG4MX8dPIu93+WR808YLDyIC8e1qCqMg1C8WmF4jx82vcYsHVHl6ClHcTH4Scf3L07jM1RHoRtSbM5mvnzq7J8H6L77"
    "3W7bNlYuCnvreK48iLW4FZSj9gKaS7Jz5SG8hx7CA7YLyMTtoogHUA7+tAMQFgIrrjPdQNQGgT3PKgDioIBf6aAXLPISntF8"
    "AE0XYQK5zsnqc4AXlKCzKb2VA4oU/540qV4b6/oFw8yjLZy/RnSMw3JZxLZvFO9pwPvC0MtqxH8k4pMyAM8dpb2K/HqaYJAc"
    "eb4QqnA7Geli8RYRGDyfyCVF8CG2Yt7L5pHYhmKBx/l8EDxJCnZI9dnxTVeAi1q/kUsubooLtJ1O8fQ7C8gCJQ/IQVY1A7gb"
    "F1mYvuXmYG8A1MoxzkpeN91wE5TVC3VC/hYvtmQKMmMk025vVG7MZqg2/bZZn/4UWNm4Tj8gfgCGLGeEuYIFC+wYpSbbk6ji"
    "3C3ySxPUubZk5Gk8IFhShYFJi0BiRQzxB56bEyNcuAm2AgIT/MCr1eOW4SSrFLTis85HKcz0cMiGFQczhLU4Ri/6cKzv+0nN"
    "BRvALqd7fy7j4oadqvNid7eW4LX3uHxb4pdqw1wL0+YMXbyVoTsLowvtXspxVdoFugkXSDzbgT5byzDchc9/TGUb8137vjnN"
    "tsdUVniNgRT+R5uIUZJdhmkyQYNtE3MAeK2kSmEUX74s8SDfiXa5pwLKe/0HZPHkeFyHRRJ203Acp+1AVoNn7MYBp3DOmUql"
    "ACFJCwQr6evO5Gfk2t+RwYS06OoDg7a/s7NBpGPLLw/5oXY7qCl0LQJkXPr9YXun3RLAxaFsmrSECeC+u3t40BIOENBlHxAx"
    "FxjmAaDdQccoPF4TxmkvW9Nxl0Nd/UEV4KFuNJcmbOUijpIwJaPXAG+HGtIBlnQE8G+j+j0qyuf+ZRGes/e8HeIOzzEnhOmv"
    "8bxRzNiiVEz4RqcK7+hajBZ8GtmdDTRDQvqacwbLXGwLErGUx5mzYNZBxSZHABlFDqkwgTnmsCwH7sc5Xgik6U0szZHR1vg8"
    "mPNlQWlHnMs0cU5HZgvJLM4gocNxRi7VJpHwPQJCLE57Zyo+HwG4fs44Fjddqv/7m6F3KbZ0+p/e2A/aenX733Qx0uXWEB3Q"
    "NT2qMbnEcywJ7C0s1S+Z/D3ytnfJlBi1//P/+G/tATz/r4bFu9FZ3Q2CjeoGhp+AxhwYWWj4wVxM6FG5r9T6FRy43MSBS6sr"
    "wy3Y0A8oFzngrAluO7KMZvKj7Wi6FclMYdVxvpStpxrT1bNxlrN4xeGBEEubDOjl0/cxgBTf/DddrYCKyA3oGp2+2u0hGkJc"
    "d/BWsIR/JcyNXhmSfBqdBdfy/hdzZHGBnselX9bd3S98iu8Auz5QLQysSLsB/75yZ+wiKE8vzGlo3LjBX/nr5g+RHaUpLxwD"
    "bWMpqKwGAgr8mQBTkHTaO4AqMI4o7o4pgBxgbj1FE68IZU2Yp6WIOlqIHBp5d6LEe477WWn2peV5E1GdTvEGq/w42t2dyDMw"
    "NEEBSi8Jan4sliausdvfYcz2BNJ6A3N3AUEwA9soQp6Aj5rIuZczqmyAh/DLVoSFRd08sZWhFsOoEdCceBuKgvQfYH5aoIrl"
    "SrLFstrL4nhSPuNJ0vOLigbYi8idt2H+tlxmx0iHLFyyub5ZPdFGIXHiM8o29AaKfc7iSVJhdCdUeTZ3IPHN4qrvh074rrSo"
    "mxfbuqJEyvik33EU1jSJAfAOwSSYBjOQ5eUiX4DwcC76wRyZgEveHdFVF4ipf1uKSCxFip+m2koF/1yK/r5RLtygaDBWyMfH"
    "XZaS41pFa81Or8+CC3FlHQ3bB7wX8oD3SmqPFru7FxY++DeMCBcmIuCVROOFVjJdkZIJn8eL1erCVlVdkYZsYdXvW6GgrkhV"
    "dUXaKchzeXwlz/zoCyAwWgleOPxmycZCViLlINkjFV46SjvtIXsWUDJ+lRbfQJKccXpLVZfJgNkBQXRm7P0lZB0DIo8tdt7k"
    "Cq7I7OGCOUrI6gGdBdKNDL9kVi8Ut3mBx2SMzoaQPkNC6nyxajh9dibsb/A+dADstSZ0YjFRh6EX8sRiIq44cOoOD/lYApg1"
    "rgRiUgciIzPWnfkEePTpaKzw6BP6cIxPP6HXBsEhYpBB0hlrqqH1iZ5aE1G3N3xzdGOw8Y0fFhS86+b0DRfErk/ksUzPJ8TH"
    "UxHMJbEKiddo1ukP8IffXQQT+7wXv1P/A5NbktHhRCEdAAEPnHCIi2Mxk9ya6uVbY5M0g11dLkIZS/lELDpza8ttyTOXd+Lk"
    "+O1ormny2+7CH8yHlZbdYQDvgnAUdsoBbBrBovNO1oKxmCNATCAKU4L6ybF469/OhaoMqwLS8FbG2ViIE9h02u31XIfHzIHG"
    "FKfnnQ6yN6IqPH4BccawTL7kStQo34v+8L3R5L/HGXV661b+Hqqmit+jf5BTse1/X7ghuFHTJm2wUG3S7PcbFKyzdE5ezAlG"
    "sGkrZR05ekoxV1KcFtXSqKq8nzz96vvdAjCmz1nx1k5hlHzGDnWWTCZxJn6shxWIigZvD6SzuaiG+VExhL2W0SAkw0EEA5mq"
    "/i79dNDwLkctbt4JqaeBdBULLY8J8r4oTDSvSVG/sKD4WnzTW9W3bwzkNVzitQJLNAOAbTKePAvxtu/oohxM8MOkGHj4xKFa"
    "l7jNiqDn2/cENsRC2VRuonrRDpuaoAY2YHV8YWvhc4SKFTeg0O6Jk2KogbLdHgMNMTxr9hbFNqcCtOxFBXPZIGnrb3iGTEau"
    "KCuPLnkOBu3zJYbcoLSxaWAg2VpMvlFZedts06Vx14U8ulrrBoRr2HFeOOYNhKySlSC2hhJkDDlL59oGhiXBCgY7BUwmXuNK"
    "khxp8c1Nosim1ZKUxlfdU4wNyIJYAb46/JH6xMEldZ/kfcJ/sSB/4KuyZmTzwrXG2Kat1KsbeVCiITKOz8jbXkguY63gLdQv"
    "9A1cJimGrihq6/rS6ZA8r7PvlpY9HvIndeMvHS3QNEj1V3U3SCmXzKQyc1GjQcVYglqZaqnHWrJbrLb3dCahSwZWBmGVDCT+"
    "wbipw+7ghH3vqsx522oKC6KbHOlfZCEsA5U4KuCBm6auny6QO6ip+I19ehthYl79YmS/2l0eeM4XB97mpm2nMqdqNo7WHKtm"
    "3GHJ0STbOaUx41O6f8Vz1hvdpmvd5h3EdwoaTn/Wa7YSkIBCbSsDl/pgDbaeYcAop/BB46Ctwm37QxuV1azp3868uRrYQT11"
    "uIkxmNHyabPIKlknM0U0HXPnhL/iwPmXdBJVr081iO6u4KkztfU0XSmNhb/SaJRcq2Z6o6AzwfZxFOfsmilEh+SN+oM2Bosd"
    "IHgtJ4PkOp78SJlGGb99yMtBN5MlT/IqTCmAr99pY1RdGWG33dnMgRnaX8e0TSAlLiJvZlGEaa32PWtsb4mxLlm3pIZlIk+h"
    "c7Tiewiy6NGq5vdrEJXXP7f/V4COQ2ymTZp95umglapYxl+FICBP6AIstQh3fdZRtrQvOm834oYftLYBb3c3P62ffWb8tX1G"
    "B0cmv0jrGksCL8YHU7UjZWqubmcT/nFaWbBXgEWDj+1dqqGpgaXs5mv0DbXwFc8EtfSnPPJVGW7w0yKOHLd8acLWmO+0PLP2"
    "56XI61rGyEeQRmfDJZ6BNcHrdHnWhI13QCM627I6aaDyc9u9iuDaCEJ7YZqcZ4hdRNn0m9yMjInVG68Od8k4su0pkUSz64Ds"
    "oU4UhonIfYyGh/6Pn5JxSpFn+EwmsRQiaOK1QVgTf3ihOms54m5oBBUrZA7ckIuRfFBCzExinR4bRkWnIi2yj4RtvsX64ivG"
    "JbB2mOBC8c1BVeMqde9xF3pWGL8/urKihwVIBHTjDDqn/BR3TBal4/3sLJAXXljXChS2MSfteDw/RmWTIxUkn/ceUUL5HQSc"
    "dMPMqBTpaXgWRJpOnrJgumkMIbGg45VmLkfko2XeUbHlD9XV2m/x4mu6iwOITLSpLk3oZoguXQNQGtL4qfBQLUnwvptMRqRj"
    "LffCMeDRKHcpJtQgFwhajhHtHOQ1FX0wxbbawLcX4VXbuVfBZStQhnj1ie739m9B0NXLB3UC1mIy2gFpNpMACye3GFqnQxke"
    "gqO6mz2FFi9pgi/j4kfZbS9BO6n6VqOCZexJ45Y3XNOWrVplJrIhEkpdO+2YwBlKarpvmpDSnGhraS6wYEF7A+fkUPzUl+62"
    "zlho/KZwou7XrdR0eFJt0ZVHe9GcVF2WKRu+/mVU9eN8ciPFPV/JDQ0C6bA9rAMARQN5mQAT3y5uoS7pL+27DogWt30bGLIa"
    "TZ9NeYkAsE4w1L9T/r1X1e1DAr0UY7kUJbtveWNI+y8p8loSiH35gnU1R1EPxPOOIikUCHnZu2GhzRZJtU7udqtVH002sRWO"
    "Xs2LFNPO717OPq46U52QIYRRmMZGkfIXDdaaJ67agWJS4YmHHNhJvrCuAHHzUpUOALqbFdQh817hoTSKmXzgRfXKCmntpJs7"
    "Iez5IhOyNqzgOtWEx0XM90OYWwee5XMgZjFr6Edb0jGgYaWc1lmXn4lbwk4Aaxm/ziq8DsHQAGiDrNw2v7KZ7FptmgnQ6ndo"
    "V4yFViv1yvdL8O05zpDx+NUyjHlig/1+r2todEbL62nIpM7yHnUnSmUvadm466JLtVt1jjdq++ubapMY0FBdHQV+KZzLqKSm"
    "R87/7TxcDGLb2Cog4Fhp9L4eypusysrfiCVc3+N1VvROv6MpCrnV2Bx+WW9cEWu3k3A7GKtZ2gqe+cfFHU0lW5uCL3z/68B1"
    "XPhg7ZFyOl5h0kvJOBXOnVQvCsvXwOKrTbCb6shNPcn9jVnG9NNz1gydDf+GCg/aZC3eO2xI/uwURJRGhYoBY7y7XJ0cWhXB"
    "8qMxFD6aJbRYxzXKiIEeUIxCqUmFjYCUvRlAYInaaDripQup6BD/82LCsdOgSvIxbdR3QZNopI5RuTJxl8LR1vRTyBn2GHgn"
    "Cs2BkOZRkOIxs0IXEe/MTPN7z5WiZPVBIi3rWF+keBpYMhm3JfEJiwyqAGdnAMOOo4rDFCGeJdaqSRinFD4BU04/ApCfeFmW"
    "A7xBxXjOOdxuJbOTx1O3L+PtUHg39NZt24Z41E5dLiv9EanU8RsIcQMyto0qYmPwB3zDIbDKacsdPchSme5C0Vajb7RwhW1l"
    "/suXzhFBZGZGL7aZqjAjHxiZStxESyTmPKCWH8PC07H+ba2QSKywf1KLZt3lhNuNHlXpoc7EdvTq9oepOoVgVy+QEeAPxtGh"
    "c8lwXIIkMM6rKp93I/nDx9tcZNAR/bWDHlULf/+gW9CP9VrmKFRxlU6SD05AwNPhgpoWTN4QtFFGZhFPC7K1X7DogJHi6Awh"
    "EjLoFEnqwP0HE/StkIfUCLxDIUrN4xjyzSYz98gcRoadoDvHLR2lsoPMmZ/kOJsRhu3tdiN2i3I+LY/k6wvUMH5DXUsOAbwc"
    "sv+NMr7qCQF9WQphquva5UalzRRuweTBH4X3lmStpb+JDxnGsSG/m4RZg9UKW5Wn1EsRBVFX9AGWbfraXlPf+n0KxLZhf9qS"
    "XA7s0nGccdQdgDq97aX5eRKF6a/PP7xerTbTdL5JfJlEMWdr1aJMsRzxUccM+2jf3mVsAq+ZF6u+cknXXfd4DXULQq8EvqWr"
    "K3mq4/7asqyVPnQNg93fGBc072b7bSMbpmiyi9xgRY3+UEj2r+LZgndYVAOMerH4IQt4pQ0queR+yHC1bUgeiX2b7WwYoTu8"
    "B1uMmmOfzIma6Brkm8EiqmORvhixP5qdykrQE3GmycygdzYot4F6ra/Lgw2XQgsmMPMJDZgczZhnVUFc6kjvdAUvi07EYiRZ"
    "aKpDccz00okyAxKfoLdA6CnYLSTs1oOPhfb1OicftkWXCRZlR4MISdis1EvhnXfmQAUp8gDtMjVKHnC4gRvLgLrlXR7dnI7P"
    "/OEYTfLYMnI8giR0/OgFVwK/BhdSLvA0hCcjCZsBA8tXXbFG7ZGeUWam8gqeTmaEw7WCwRXwuXWq4F3AcM+XRJ+HBjtKmMs0"
    "fkY3cDIF/8B2+1SigGrFeQA/uGYx1+vqYm30bTlXTRu02rVFDkuYB5zb48m5Q9ThZJRTExSLQ88gpcrfuZpNOnB4XQQfCwnF"
    "nqyvRzX1VOGe5ff0tGiMuxlIkzqYx8gYA0QdcUjRakWMtqol/iHrlaN0BKQSPS/7QSh4NkDmOyqBSUFfy27qd/oDLxLGqP5w"
    "tarokmWs4/CMvcIT4eWihNzdfgBsbklePWrFsgUScRBIJanxg7MgpVoKIbzMipcy4k4MVGGqCbX5ElMK2nkSX22GUFn3AEQY"
    "/Ht4xu/9M6tCdAaOTw86HuwVh/6ZHibZ+SlkhVoTQQOQoZnMcNVAqYnOPWiihT/ub7bhEZhxaHrs0lJJ0krc34E3JU5gkATA"
    "BwzyQHEBgzAwm+cgDdSmOigtZvQPRyb4yMaKEjJ1xW6sDW3xDiqMquTe40hy4NAxhUos34lhwp7nBcXOqZdNut2mcAd/Gl2G"
    "JC1kFVH3JwriDR5ShlhlG6W6TYstVVbQ6w35sMJrwyx/9oLdD7dILNzYu2Z5w9+wqLEFP7sXfxZeTSqs7Gt6/0GdoK5YSmTW"
    "a6C5PukURP0LmsK/Uqo195NRhrjhaO1NkHQnek+t+47aHZEHVRy03TW8+WyrN5a7u5cjjN+Lqs1tuyTzHlrts6FI4tK+paL1"
    "8SJfeQ/vzwjYRXge//qeNGQ8CKlSlWbPeDkO18FaFqzD8uH/+z3GLfNbO3wCskFTf3/79v46asN/W45d5AWuDkiCgk2kNw9p"
    "LIdw1NnwgQPre98UHCywaUF+Vz+raWk57t9kAUCCDzlBKVlJ5GuiKujfBoySCQPDmoJ2mgNTKA0sQvGdCvMi05G1CjvixFob"
    "/iDs1rQtDLegjUDEIiA5M3dOLerbpWxcZRXqNoY4RG90HIlnVTTqDQAxXnkUYVIeNTGfVcv1WediLrojMMJBwdeOleYuNwJV"
    "aIEqtK/x/dXW4pH+XJgoOpWMoiNZGopyni8IcBIIhZ91hepJkHSF6rs209EgxthshfGE0/pH1G5vBRG6usnGO+TdvljzFP4d"
    "ONtcf9YNDX+WwAtWafnDO6inND6EQ9oaVF6U5AffsbbqA/9BQRSdKeyD2N8d70Nge7TPBghLOmIBaWsSyBeO5BY84P3RCpgd"
    "jhgLABmYzZJ/JXKovuB5xzpD3Kx3N2CvjZeszPLlZQULDOldd2IOSrKfBIZM3ddFTkLHbvCBkVe6CWjZz4omYMdKGU8G+DRI"
    "DjFoN4hBLR0AMfRUXhCORyUINGVgpVjXdC9rgXtDrxjFkD8O+hhRrMIIp5cxxu1iI5iJmKLdR4lOV1MxiYOZWIK0PnGrdyI4"
    "T1EM28urWVxQ3qnO24K8fmBp0f/pMDOw19JlVwxof/v+VghHSvqBotLK1bU5U0igMr/j0CMHi5XQysJqohn1jrp40ELpn4rN"
    "MEbmIjgdqf76Y5yKJKAQunv5sioTtJAEUcK6DDFrCMhPGpai00gr0WlBNvATesLLG9D4YA64bqWLTESBkeILcnuS16Jl6lo0"
    "DBxynG/Wo3MEHJfed2NyYBP9ABqojnp0hXDPvs+DiiS+CsSbCtK5hLQKC1wAf1DEQpiljpcSbI576KgtAXPcw0hlPusiSzcE"
    "P8ZvYiN4+hzJk5FE5YqGqnnB3+zz88rSzwFl5e1ORRSxx5eLZWzMtCv3JAHQAqP0M1YciWwN49KBcm7HMXAHwMQjK598pRpi"
    "OY4zvA8lsftZZBtnGGznLw8A/ECPRO7mssYMpSKKEcHKS+M3vlFjixgaHkLh88Vl0BlsJxuxJQCwNyx6H9uGwUbJSfxDV+73"
    "jPrqlCVk4KL+luidS8haGEx4wRGEXeKIc7pkrJkIr3nBj9JsEGa+7EUeLKknw1SAUNpviQlTLH/Ezi7kCgNoXAIhxJ8DTu72"
    "iZxNA/QsI3Q+5z/z+pwxLSIA504o/4atv9XKlP9kq08x0DDXEd5Jz2zEESravYWooLnCp8hv7JF4Kd3Fz5Xbc9Y95xLnPAnd"
    "DJ2egboO5wJ4mjHwKH2gnWI8kvR/oKgq0OWbERceyMKsP4tWq3kLJWx4pvC704HyIDrPdRXzWmSmkapzIMc/73oRL0416hBG"
    "h5tMvRdSL0R7NN21OA9mCjth4mDvnYpr3l0vRXJ0jYDCYIYgY17LuileoaFMUIWgO2rJc3Ae4PCDyyDrTi3sDLPmyNf2pOpg"
    "cQmfIADSlIw0euPKPNNx2EARbzhsMrxpmOiNV48KKTrQOZrWXpBYHsXcGFliHveUHZ9pGNaD2yChbkkefRugdRocQl+XqtXd"
    "3SWt4pCYA2ix2zfxwa2bLdItUJJkJePwuukeETOAUIonFMP9L6W6HdA5G4jwvs7d3ajb1XvA0vHC5DMLBQ4+uuAgB8nplEOg"
    "AodAHncCkBTDvh6JUmtQXzH3BdCaMbRG2gktCmbk6dYf6AtyyoCrAhRl1du5WBzlo7y76PTjx4NFNx96reVqNTk+p9B8Ygbd"
    "PDdxceETJCanZvbO/GDJDpwlFbjlyQHuYIDgDqhP8JP+rjEzOy/rrEsZ7DkfRJuZLQ+xrGZ+VJf/6+Yf5ouJtPsaGIjXZGFM"
    "5h8bFsaW/UdNrXHvMbkIvS7ucjnWfvl8aFHLDK2OMXjB8O9UsrbNVqD78mTitWs2s3+/p0nv8SE7MdfVI0BR35m6yI3fckmO"
    "msGrFS916OoPw3q8lWv9r43nNgrWwC1vBbU9xsLXkt+2A59EKNsXdXyz39fjT/BA09voJl5lBWJI3zIYWNZuEbWDkN2u0XRn"
    "TXKnsiVjKxVUpFDIcpVsWdaiTxrGj8sdg1rnAugm2+TQsk0eFkAJoQKeXWysk1std4BN5gyWBY7Sl2pr90lGAVBqFn2Dqsks"
    "LjAGy8DTW/bJgyywzSChdINRnMWXTTLHyEcb99ypAovvFsIpk3XZsXWXSekc/RTbDu8z1FVr8nc/uNuWad8RlbqHmqHR2yNr"
    "hX5UgpeOX7jTk0we6aOSDQtfdlfU6Yrah2jzoxLNveAoCWGovo0PhsMa5R2PxhXFSeolNmOyj3FY+yDpDfKOLY7NMifiHnS/"
    "EATSYdUcIw+IBn011p67u/Ja+rXtJ5k1XFJl3ZNWGCNEMmLcNETM8qorIyq0N4PQ0SkNBjv4qroFL8skcxFK/LUrNRShTvqt"
    "S2qvdSQvLL212lqr2zxI2MSNnzYO2LulFEZ8gxaZIyvaoa9dsiOUrm/1fWiBmumG69C6GgsilIq5vkDjao9/kquN5+Xd97ZI"
    "Lsmeg65+d2kMTiPLLzTbbsZlDLYI2ihQV90GUy9LnHa8aItaXhOW07Gdw0rxem5a7XZdlo+nLX7ydTAkO7MQJKM/yqisfMxi"
    "Psgr/qhyaaDVU7Krg4oYnETfz2bFNF2Sfdcb28WmIVGe3W1+EJWxF8O6reiTlbodDiCNsXL/YVQ2VkduaBVq98Ij60Y5KvVZ"
    "lSo6mX9sPo6o4MAzKR0BXKusF6Pw6EqrI+eausLql9u6k1FpbcYZidDQPOo18pFsUeZUDv/yMqDAlBccE/Sd06cBNbjWw7W6"
    "In3CxowMFalpwubWeuRwZbV3kouQW7NbkDuvXSNw7+540t3dclsjqWwEI75EGB0a+e1Ujkq6Zfn6q1O4lEX9ptGzkJNsGkAi"
    "b1wcMTV4N5J/oeCgUokdRnXCxUZvZtts/1JrzpoxVEerV8xPcpd1Ju5tZJmZGMtM+bOTqF5lW3oVtAC5Mo0bq1WFel058zr0"
    "es1gVLOkbBumMCRXppsYnE47xOP9W92+EJ+9MEC9TSjN1hwXK4L/7SaN2yCNNokJ3I8Y2KBJ7Sgs/nLcYPAmhxWEtcZonzzB"
    "iMliG2GTTB6h1ADkKoT5oDAmxWkD2ZaX2ebDEuhw2hEh+sFhbSRrtwTvChkK3XjzAF7PoqVyZ18QaSc8zblsF/jfTkcuX5F2"
    "KwqpTLGF+aYmTeMKvyWKoarby456o97AasJpA8pnP0AjXcqHahRuLsBVs94yestxbhs3z/tSgeFV3bPBTEnaCd08NkxkGA+k"
    "/eyt30oMlnU6RUMQ46saLkmfp1l+xRE0iZmqfQVxCI2eTAZ7uV4ok2KybhZqF2z1fGM6DZCVwkmGS7rMYQf6avBE0m+Xqs1v"
    "yB9aLPV30bKs8jmbBmEwRNkl98qBAuvfK5zAGKk0al+t6HoTzLAokjl5LSlNk11O3frisZbH41Aum2zLaoX6H/n5qIFhMTca"
    "xHhPiufzJQmSNQsByqWPzp7PEOBLVDEjQnsRHkRrgyiYRx4z3rciJyxDzQiVwqDO4QTVq1DqDaUEuX2HkHEBrB1fyMO5eiiO"
    "1jfYYqH4WzQ6qGKETkfEZtxo81lB4nqx0bEtebCpD2jelZHe1kmWfksWW5opWznK7f9gOh1Z3eVaOP7sNKxkZ3QYWuLhf2GB"
    "UkVqs6IY6O3gt0ZI0e3AUgXAh7TDxPGa88Lj3ig0JghaDwCLjR3q6GI2Oncz9//9DajaftFlDLv/JCxuDMBT2RuJlhh7LXUn"
    "gJq2piF1poG/6slI3cnYe3T/B9V7Mxm6jByh5Rrp3jYfS/tHeCK2kyBe1UTtN5sHbjZ/gJGJvomGOFIL3cBJEllpEIrP0nh2"
    "AjKz78okSwnid0OpsIxEO60wfE5iTkY2TmxxyzWHb4FEXxalyC3EeiebxaaZ39AOMvWMJ207Zk44LvMU5NjhjvIBj8lT8Eu2"
    "c9c/PDxFj8Oah7i6d2JUduNB4X9LTYwTXLhb+Rt+mxPP4kFQlJ6gDJsgFzLFKGdGb2DAOPPs47XfpPKdzicZNhPHUWjhOdI/"
    "ndBNGH4VbjxyxtB2Uarr0WylZrqoNBszK88oYS37IEEde9czSvaJo2Tnz8BQjA7w4Cf3gVdZs7HvIvaARNunaHWVju013DJ3"
    "uNOYqOeBtdMleJ0kX7wR25dtSLY0hoaHXsgK8QIZULwIiExA5RsaHiKP7OkFEEoFuB9ozX3IN9qgmUEotfrtokrROAP7k+Mm"
    "gOcoeJO66ae/9s5RrduTcnI2mg6ywBlnEkxU6GO1jIJLMYNv87olaXAD6VW3j18c0xA/GAstiON9FcG1fEc/GCGmwRUenE2C"
    "C9E6X60meJ+csZKcejdEfi758O+Qu/NMeNHoejAG0FwEn/BlPLiGl6tROvDmo8uBVHkEb8SzUYlJN4NLeYYxXHqfAqoueNPF"
    "X9KzxYh/b4OT4F3wfjgfeW/RC2PMFV9ylSdoBTJYkCGMOUV6B6npADEbUtVZ1nssfQ19hAI38vx3gHWOasUHKVTbUk2V0BRT"
    "r3eUSDWkgxtu/z0Vt9sZlH6w9N7KQZ1035pB6V9HBMbd3aWX6jRecvQBK3jHP4P3XfyloOK1gHmCHeES0IgjO+bi0g8g5YZS"
    "KAFotdcKZb5Q5gt1vpDzhZBv7Qe3bKHLx/ohm2dP5QWfHh7DVsSq4dxPpUnCjJVnE5kQTNHoZ0aWKXrWFkynptI05ZxfZclg"
    "jpaAC1/gn3M8Inbrmo8WNmnr9PkOCXImuoG8XA1k67HbG7UtL6ilcJaEnoyqByNv6akZ5Dnh+Kl6UnASGNZyTjW4/UG9KOfo"
    "mkSV85undu1yKrlFid9m2qCYw65PYVPW93tZUtGQrhF8nQG+XYYpRt0AeNClbCxmtHrDSvJzz5NLyX5cJmUyTtKkIoamzvc9"
    "xRo+QqPAeun6BGzguhUrth85+r3Eznn+avUEux3c2aAHfSpgzwAqJCPzrLf3AI1Pt3xiruDOocn6baOTEynn2Z3eEOym/CWo"
    "wX61ek8upZYbvKyNs1EIRWD3n6bLgmJvoN7QiproQG1LETry2lpdv96l3d0n3KWg37Pv13svGcU72mnpb8DmwdZ8fqLiC25v"
    "HriGLJfMccsSK4FtnLzP0huruIaZx5dH0DvdG7EBVwTTB2sS5PGUw7LJrG2tn0WGV58AxenLvKAo09fV2zhbKt0LfGiYXoyE"
    "j0wt3ljaODsbrs92OTJ7OOj5mxFSgDGJk8t4IhEL2IAaujz52qxQZ2sTLOE3hjzbwNcPTr4VfH7g0gvLPV/Sja9grJlXC/6z"
    "ZEroAWh4v2eP+PkdR7NsqogrVweYUAw9y6fV188eaYNMrKruyIjcntSjVY5PQ6n0R5F0Dzstz+haj8aDSCesO91rK9VNRK6T"
    "jrTIkyKejJGpLEEijhqiB9xxEqSVw0TMugUAaLa2tlCZcduB2UQoH7kue861lnjeVXM9pqsDoiaH5EagsVzOLnrAlEtG3Blf"
    "l1TJ3vnxXq93f7U6P+riDzpeOSI70K6ATT3Wp2ITP/grky+AizW/lzmAdH4UOX4vc5gdKkKhFOYcJHp6XLP+ZtsGvmBYmOPU"
    "ae1kbXh5vOEmom8L2/JFXAYbXyQQgrt8TtbrtXZSzck927MwWntHdIS97/9l9v36ybNyy6mdPNsXEOtz5uoMD8zrIWroTodC"
    "KR8yB+vsTfKXms6g4NthW3SD4GJkLVFWUwzihnEN5VqepjleYdWl8DLaVtfUKK3g1I9B1olrBgrcQQxCjaJrhtoI+sU3klKM"
    "2DgjWxitAOJ368K80iTK6+2G6VE+Ag45VdV9V3m/o7Vm6vtbugBMoJbsMOqqdWnnMfqHe7lbU+lj/JPGmqBRfdc0m0/laDll"
    "ZMkg7/TtOfmQNYbORa9lG8OHpA2SvBGqoKzzU9o3FeDVIZKer9FGyqBomFaYBooCAwO4xevUtLstWuTlHPeN3UopCSTqoT7U"
    "gB2Zca/zjqKklZznKCM3AS52nHbpcnv+kvihaVqUwOSz+4g+41SlEiW6L03sdvb+9VD8U/n8LvRn2UJTVc+ueans/psDUPYG"
    "RaPJzfRuqJJf52bSJlwxtTsBAYvVZs2NLYT0L5c6vuOZ0oAsCOzsy8HfOjOKVomWtf3eKLSaET3ptX40ddOdjZfqmHS9BRrg"
    "wo6uXNuPZ50puoZ6TlH5saOyd6H10Ao/I1GXQYQ85uuMnQNrCCek1qwJN4md05i5kcPv2NbbL4mKUis6jBm6uhHn6qGrtFv8"
    "Q15KI0Z06oEHu79tCB8cbewtfbRDpWh6qQ0epF5lteKhmqFvooOo1Pdi4zsCxXYGeu1Y/mwMYlg11ICDI6HzI3aTnU/kDQny"
    "Ba+pqKTLn829fdywByIqxP4j1jJjT3A2ZSFvktoS5F2im0mPE41pEm+Uy5mvfFCsDFJoVruD38nW/pDgnVgg1C8njj/AU4l4"
    "ehuuoVG38o8O0OVgtZolODAK27D2gz944Og4CnOC34BYYQ6Usux7ys2NoaJu74PDbzBS4x86SNqdIbTICWJ7JTACwKnVSjo2"
    "OEMT1YaF3DgEggLU5JPK41V+8JXKHa5oMwegrgWNPy10aYZHtb09DkF2t1UfQqMYVVq6MxS1cYaJquIU+xgzSjmrOisvmCeu"
    "m3IDYf4KGNQSvhvcmMtzoPVz1nxtbrNxp3PSUd9KbQZXshQ2Gg2qLeiFso7O0shzWXMzqBqnLLDmZ7MhzoLt3GF7GgCo3rAn"
    "TtPmWwx6AYxXdjQL7BUE3CKFmetUJrxc4MbCw7DpToJjG1uwlvMfWfMdwNFchvLK+LqQy7ioTLzWhjsYAMu78hAIL7z1XVvp"
    "S40aHNKXrhzJi+SvO+tUB0NAfL4f7mALOmWziZnVxDBDG0UOLJqYn91+EONpGd2ANUc3sjYXageWwJ85mLC7i9ehGy6wjZBI"
    "yCF6TZUkjZUk9jxjHQ7VbtPY86yS1TDIZ3F0EU9+j4ucDb5bfXPRhIGYin2aZNIsXs+P+cLl2/1HCKb18B+ZdR8K2/6JTUvZ"
    "2Mbu49iJHNon+2QbAXUGeVjep4hxLsIN+aaBegf1kfI4zaOLdlD/rtjoUUZHgYN2r61ZebNyux5kwEuKTXFLst929B/X9yFn"
    "EIk8eCYu2+qWJvu9YOtg7HFs6wiOhK9Q3ZjPRqDYGQp5+7YBymYeOpmP9yRZoYxD5TOuaVFXZ+jCpmJAyBVtdJ3NERpAqCqz"
    "8STfAGDjGJ2ub2kRYSV9GRuXB926Z00eWTf3+AgP8/+lMr4Kowtv6xoDTudW+gMjLHTQKnxZrwNn6TibmrOC7KFa+2dcW7mm"
    "cCw7BCDBIM6v8LvseExhnXUXn4aFVcdmKUlMYJ1v6Szi7UZfXby2elpD+Fo/f4avX+kmVrBRhsnmRh+dObJvhedLj8bAvixG"
    "7f4BITxRs+EGUs2aqSAjUby5RqxzknqZhiOUTXhT8Mt/bIyQk2vj24TRxm4bN55MUdRxrx8fBsbH1zO+CduUoR6DGc0vtGlL"
    "zLZJaFL2IU8y3IlYmO4HHsUR66jQYf7+gT/YXk4V7MjwXvsHgQ461vd9wKFRvB2QAzOkjK6/cgBFuvlNBLAmz1Lm1a5H0Xn8"
    "oOELAgS2QKzvc2a3YIXW+lGKSxSUUxB/6m/EeVVBgZ3IqJr3Gv6b66jFx70nQ0/XK1mtslZjNRhCt7EEkrvmIHh01BBQ+9z1"
    "4Nu7bUWo2apmK2y+nrkHjiPDJk5OXHiK+iwwyqbyWlMxntkMrLHQU97vudQrpaNVcq8sx8v8JcayLTSfgPfSytKqAObfKfM0"
    "mexURZiVjDfAVnI/MGSuVLx61sBeJszeN27F2/LN3K7qETZmvrKhwSZOg692oK1NFe3pt8LIv4uvq5P8k6rFzmVLEp5SrH1l"
    "nA2ZtgyyISePsLJvCNHjvKv19vrzXfypOpW8VTHxVKg82J0/f8PuDCt9Sz5nY9zItkGSmIh8l4lb5nIH/8hIThl8zixa8mvN"
    "ntqsnQZZmpYUNeRtkaNhhchLQ5pOOu8s4jdXSRvVd9mpZamrvlEkrDMnPMJGm7U7lZqa4Gkm4Qg2/jneyDHJrzJHPto47f1b"
    "B9LSTmEd9Eh62rzmw3bHU5d8rE37tPPaQhjumKzF8QdSebYO4q/OyYe/PSckdP+GdvwmzpGRwZR+VtxG80EcWH4uAxAGybZH"
    "iv+2JiSwInxjPl5BrxFSGFDyBrcJTGdPgPfjP0q2GGLV7hPoxSXs1K/o/pSi8Rtejgl9QKMOaX5vdYube8vHgNRPo56iuoz2"
    "2nlFP1+OH4CziQWTyaDT+S1DJfQFXePJGdaB1vkGy2K0LABzS3XjCfAVgFvlj0W+XIhlIW7h2wCPATfu9Tw9szTX/9zUJ6MO"
    "uSkqemwaYIEWfTRbTfJzvUkK7jbJOY5zYfw2Ctjkq9PijG8lrV+GxKEccYibbh6UTq4eaA/fPIEc0bL+lafwaFsh1Za/LcNp"
    "c4WdjjUK4Aejub9eXwH7FXtmwP4aHZimSQYZb27lRa9BRV5NsBYbr8aVZ74WGDgOJI6/OsNLeHmlkOdNq7kKyk2TUAP+T0AC"
    "AP51qDuONXHCQfaG9YtTrcsOKsyTnNkXwqJdrc6TIzeHefIzO4ASOlJXtgN1hnnCMx9DONt+yT+5WDonLamyf2tGQfWxssgP"
    "yAhAmiYY412rKS0dK1876GhuRHPO7hY9Z9XEnknOgdWUxDZUDvfHxy6SfevWe9BUghk+4jG5l27d9fGSLQLr+h0atbv7W8XJ"
    "82VZyZsRYturEG2sLKLKocNbWgN2wm4HFiFj+y/zbg7gjwrLXdDNI8/j8ZII6UKI99e49hQ4Z43WOJpRskcB3C1s7suE9mU7"
    "mQ54rO4HbBIwcDqE5ojWqC08jBNmarjJyXPJurltTBKPcFRls8pXyR14XK+WJBqaHphLFcD1Z0rahE6r2hYaPIZN9w/oHmHK"
    "SS4+4EXqugLzyzayZRPtzmFQNRjZiFqNTgdtnZhRlhXNy6XY8A7p1OpG5X7lW9c5KXmKsDa8/tR4fP31ervPsV4+XHOhTshZ"
    "2935eE16+020u58ovsUPsKjN+VCtIadDRHvccJY1LXYdMvLSMgcIQE3dA67d3T+Ry7OOY+84xKrX5su787ZZOPWNcoBYF5S6"
    "6IcQv3ivEb7DBqjhSr7byXKjCDpQNE+U4QTxVlzDCsKM/cinjQY1Df0zK+w8achUn/7d3be06qo6r67qIxZzc1xsLgoLizhP"
    "OklG62PiDYw66w6SEGQ8KL7fqN73KfddEhkVUWHvahbHKcXS/lVd9WARPGWYEDtI0nLoH92rZ1XjVPqb9ADf2Al2d/9giFvE"
    "lcmovLuvVsRCTzsJcC7geM1WjxTbt+X+kaF2WqF4EVsjaAKScIBBE8VTBScdoVeUvDQSAzb2LQ+QKqgolqmVp6ECzNHtDyjo"
    "qXb/qOos0X3ihaSPEbD6qfQgRVsovp+tGv3ONx1hKHS2t0hEzeJCRkMpmywuKCxKUG6xuKiVrNtbpMreorTtLcgW1rEuCCYb"
    "R/DGvz+ykcIjMdJKks5RTdYYS/+4T84orZ6One9SM+9PuzYmUtuP/idOfa3Qt4PS7yTEc1cUu7bOsvhNH9BKxk2RFjPD1uad"
    "K9dktM2Z2ezodVblGEC77W/RLt4VPwldxFFYyHExSg0EiGNxoXw1tclcJ2MDwBE6lmm7N0499nInlHeCl/Uy/Vyt8nokb9dg"
    "kS47QA8AeacBUI1zhcjaxfY//+O/KnfLBsfKO/wfpRclD6FbWIEYuk4E2686UlpOlK5torQTsJSrX61L+YFW2rvXcvDUa+Yg"
    "cM3yfHm/5LApvLTt7hPiTdOMIQo38EC+qZitzg/RsJisX9fqTHMe3ozjV3TAIO/rJqd/Sv6czewPiCfmQmZ298+NKXHq56fp"
    "GbWsBM7Vahx7mBrgGUbclv737p3OoX1/MwWnsKvY3YUqMDVoLzNZiYXHlhUyBR2xzIvusD0i+0GtyqEmqqAtwzxg1Ej7s9n8"
    "zbaNEXaTcuZZu3GS6BUstSE6jLnnD3/nEFvFza1J1OI8aVIszUqeOK7atk3EZuWIF+kNRg8uzmkJlk2tNeSqN2+FCE2sqFhu"
    "63wEbHcgllXjl1ofMMnpxpa8dk+ojN2ZdEtnmO+RljZ8KRts09/et7/dMadXZaLccYhzBPxLSXov8qxK4mLjSkREHWYBdV46"
    "zKuCP7woCRxXnyiphWjjYBjVZjMNkbzUBtFBMfY5NNgxLM1VXlyghhj2jBuK4LZZI+4Wp2cqFlxmhyMjGYAj0rBOIag33rnf"
    "AxZKz1HOgWUag3eYuFIh3fMG8koJHE1ui5LHpudALF+prrJnxejfGOh2jjfFZQxZX+pGxbyi0G0ZMoMY1smTGUSKXv7clijl"
    "DxkzW6aThhl6shTyemzIsBy5H8VyEFGUcifRVUGCiBOuVoqytfQQNV2MWmKJF2NFqxWGWo3UNeeQrH5iqr7XHNOtS87Rf6gF"
    "YsTUpp5TfyLC0+mZaQ5jx0KuhDW9mfScyRkcT5DRxHgw4WWMN6hRvEp2SWDjE2cyjsRdswEklIDOkYezjTaw4e/vC9EbqfZ4"
    "suxGEcs11uo7T3mluTj8PKZAEq0enVxs4LBsL2D00KmWZbCdHiiwJHrHIVJukRpXo5rY2lSKrJVQXFMcOpqisVXgMhHbLphU"
    "Whs+XIfFsMgLtCeV72WCV5L/kqmbEZDDZ3ORSVIBL1jybi1aWW0blIpEzCo/6JPgRgNNO6c6aW4ysaR8earER85K3gb8iSQ1"
    "USh7jjmskEx/5HulgaZYB3yTZNtBuSZ3VW20ChsoblfAkcBbFTeN4rMEmwyRXNjX0+pvGDO5qMf9K5ri/jUkWipGdBoqgBWL"
    "i3iCnJeQnygQAoWgUjdk94eXSMuhsRvp3GzAYy6at68TAC7dwlN7VF2zBhTOsDNBkKnIiKHxX0kCe9ydbWWRl1KgOgKg5F3r"
    "/YDDAFhBWjgKWmEFWAoUVDCitvrdDbms0x8NPj84odimQocIy7HrOrxhqG8HyVvCVv2GLT0HOEXoQYUCulHiOFhvZ/mFr2Ot"
    "HGwftr62QNEUzvb2dILVQf1HwgSyG3n8W0TqRpvAfBQYIcK8HlcjN7P5pIMIchKQSTMfzOFSucwOMSjjyflui4Hq6FExckvZ"
    "QQxVJrynfqBejostLfUCagvy6sZOQKxcy1CpgS18CfZkk0HgbJSxHB/p7ncT88gub0wvI15UtORTdYmqWfzbFuP/9wVuLV/y"
    "CqvdWWpHANiIU1uRAjOWd3MAFrb+qt2Z9jy5xNmqFyzEbYjngvGLtBpUdDG5uWJe6zMVkj7FC7DsD3hZ0V6YRbO8eEdx6zgA"
    "I95X29QBOy9fw2Dehf0xUF/krGbOK3wllaYspn+rdF3IevNNCD2cVRWr9vgedUM5Y9csXLIc7+wIvrJiN+45lXNLce/U0JHh"
    "NAazZldKzV0WlR27W/WwpEAu1gVzywLton5B/eYJUFMYp6hGVWPPB5V9x6ljYecH5lrSSC434D/NUg4meASOcT+Z7ZgoLeBU"
    "RKeTM46oIt3ItXPjVEYvnNb9eIXI5a3IQE7569APRQpi+VDeOKAcElEvfYRs6tSC5XBq3Zf+2dNvQZsNlNr+MV6B6s1I4UMX"
    "qk+DJZKMAE9J33l2ZX5gv31TQPykMpeeBEsiRKEchz1ptvv7lenEMHeNbxZAtdbLDlSAmy9HrgwVPJCsNRAKuYv7wVdQFiPf"
    "u6SJCUxQJyeIVHrpOy8tICYfPSvB5/Mk/a7DjbT2/+W9fvfh88nq5MWvJ08+vnjif6ej7JnsCCYKrUfNWNTiLwNwvIEviF36"
    "sPlZL3XfN7KqachRMPLBhKU8dAkXnVXwNH9EXCJSBoTiBbkrWaQodmgP7kDqIlAPka2QC+tJmlI9CJcC7Ya41gzfmCZ6Vv/V"
    "WBRxWntLvCShMNFh+FUf7VCKcbN1TuqL+gGc5MB7Qcqo4vAsdZYlqHEsNYaF3QjvoRthE16ylrdlBZ+dSj7bBOquNP8HQG/1"
    "hsMMl+ktR8XeZh1b1Zn/FnP/fkZHj5bEYgixiv1qBbR2AgFQ9O5b5/Rhu2dal73G5X3zfvCVNoO6OLCpeqiLBRtqFL4uHbdw"
    "KazIlOfaLzhhK+chRX8NyP458YPzhP9K7gSgu0ZlyXmG8VKCNk9a27WL0zyb1Y0ixkliusEd3ghMvCU3cqae3aaacT6SxDgw"
    "DTGCNwAQbO+LuLO825dNyFpXEThioDS7IAtwgDuBHfDnlm2zp/wq/ek2IJ9JyNMa17pZKziho1JrcJIcxg2GNeyeycflU9xE"
    "5B4nD3dxGq0I+0Yj2HwWr9e8dkhUB/GqQIMFUMWa7G0lGomQnb/BYL1jTH6syPvJNo9SFZm62gtTwKlfOEoIqlo3Lz/ZYjxt"
    "3bct6FqSbtVkRNCpn8I5N6/YOg5g5xgSbAhWODdp4GUTdFmGjKzT2CWkP5jpvOHN9gSDhWB9eRpGF+fkR+uWMOluWSXIUlYC"
    "HzqzUNzt2iFIagcUSilCt1XRetsYqhoGcFzZTsJW49YCID0EB7dsYpBdicfcDOJwW672F2PoZ+7NCoXWd2bOVcnqDD7TV1A3"
    "hVrV7quFv3lLUEb9tAPu8sC7cUq3pecisb3gbGQJ4ZNtgJfrO8yokz/acy795tqBHsBrPOes2STlgVPUrjz00Y1TFVZatY26"
    "OmGQ1W6T3sw0UvAcdPvB1s66jfGyQHJnAu621B1xLeuup5sN3uAU4/6gCTEZaca2kaa6Nfc0wXva1S0h7bL6f6l70+a2zSxc"
    "8K+IrLQuEII2acfpNCiY5dhxVi+JnVVRZyASktCmAAYAbSsiq+63+TD/YH7e/SVznnPeFQBldd+eqZruigUC776e9TkVEQhD"
    "4hSu1ll5dlCyzEcJn6OSAxRpLOc9M1oPmSFhXjmEuXlebDJQJdRmkVpfmzLiMuKS43RneEhYoCCgRyftvupUEWwUHbqRiE/7"
    "rgj2A3LCNM2ei1mdnYvEC4XSinyCyNMaD/e4OOFVaprIC1OGapU0t0MflqYcDEc4W4AapEGhF3UNFilJbxxoZh6ctq8MqLRC"
    "zM68xYQAQuokabO1lYl/OIyFxeVF59yH73k8T72VeMk39qWf8F2uQuqZ8LAQHIt0nK2hkgLqBN81ItkP0KwTjs845TDs5r6d"
    "twPlc51ukg/Miluf76xzy8oUH5k82VfPolxKSpcXSXq8/q0BRZWt2CZ4dvDXWOImHEy5CMPd7O+WCivAydXBvT+xSmA68uzf"
    "zcDWCqbvx6ZKv7xW592O2BE8uWEYyk2DVPGBSJSUgNGp1rSlewnRUMxKEVpa0IXF/tpkrkAF2uQqv184p7Gp1bXBRjseUXjz"
    "XFsUcm3J8mDi2J1M2bTELM76Q+u5NlPjnHRmL/l94ma3GmtrOunZoM627GwRjTZBm2Msq1WxwV6V/pZubTqncK92Km1zeDid"
    "PEiSZMlaXK3xUufoKl+/TEEDQE7UBDSAoduCdkvhH7lilo5OQUpo0CbKFmX2l8HPcLvddfychBHk04eHVxzUxiRlpFVQj+xv"
    "n4kYyF4Zc5+mMu0N48z5gY44UZkUI6noOvrW4fTKNjtn0+oIOKUv41KLpDf4j8qlo+RgdfnykLIl/0CSPXKOsu1uUTqur6V1"
    "np24p791a5iqpW2ItLKH4CtbJJrU67JBUlA7zGTZDbypX72Uuf5KF6YxIf2fCjxyYt9Yy2msRYicn/yS6Kdf9ZMyui07RrcY"
    "BAW0KidoC/NWd43ld6/LzcIcPw7xkxDNmBvKKPf4h4gu+hISOeK9G6BRb3LXX5SFEYlv6vgm478aC4H1xELGOQY4kVeOcPZJ"
    "j2o+I8IrO3JLUiRYRuTrqTbvEacpm+g4O1GO7W+I6o0e54qaMzEzPJpQBpsYjvQXpgvt719njjaHMdzgydak+YrlrO/zGtKa"
    "r1788PVvL56/fvTdH49++fqVjmzH6Zywdn1Zf/rih9dfP1YZ55XJFvvB8GyLwuj6fdxEV154pO+c7nDXZsY87P3HyWPojK/k"
    "rwMmrvgEPjXvyaGp7cCNJuSCzgplqw0Yinm/DGQNDIRM0IprrRhh113ttrq/SFce1f6W7EMd3puB18GtGjkUdGwteKJRa9ig"
    "9s571ildERH/OJ9xjCb4LjbpMxanB7n+/QvHieXHXynx1IG0VEIWBI/Wx3x0YayWBUNo4VlirM1XBdiy8Cw6VGQ2otuJ0l9L"
    "yC1WWtVhFuudcg7gTFZXRZdUM4t3zgfJYnaenDt6IiOfeEs76+3Rpd5Pb0XEcnn89oS1CUly7g11Vyl2PmPR6UG2k+YhFOjg"
    "TEuDU60IRZMPD9nk2/HHcWy8R+XHKd1gf+5JIZFxOQlHN+AhODx8BaSFCLDLxCu5h6QYbMkQ6aaoyPJUUfS+Y7f+Lnk/WvVa"
    "0syujibz964b0fvR1fjBJIzfJb3i7ejd6GpE3yMLHfheG9S/I+b2Tc4GFJNBe1nJzvM6Mm/1yxOgrbybwO3NytwiuXmme2QP"
    "grcx0Pfq0hgjnuW8lyJq3Eq9b79CukjUkq6b7oG75sd2m9lPv9BJaD79MvO7u+redTgN6Sin/z5+k4+q8G5Af6ZhNBq9ycMd"
    "ANiBShqYEkfuEABSmRKlcyphfOfB/bjC0/RBvJE3f48vpPjx9O592cyv89bNxjeMhDLT8Dkm3lnS7Gav3TsNX9LqqovWcOAU"
    "c+wXcrKLvDKyPzfpqu7YKSTMSWvZ3kR8gUwhg8QvFF5RXtw2lcB7ZwWFvlFcNyWbx2l9utuTExYbml9i1tEYCwRjmhBut/Ke"
    "A6wV/MeaZmiR1qQ1FMssWz8u11f9RALRqze2N6MGsSbieR7UTeC3W7cr6n6RthkqgAp4zfemN8Bhq6k1XUqUojh/pWJKfYCw"
    "8ZubKVm325LsRAe6s5NuBsyvHPKHlHic9tJl/J4sdIL7sut3t/5KT2/hTW/FE5oy2rYK/hI+TOgwSxs2N0IQmPAoMdF/dUDF"
    "8VQIsee9m0lG3mBR0WhjH9mQFXnLIMRVRBh5Qf0svWLaFnoFNLShKaicc841ukdzdfAaHcUGuscq+VHgw61z1rTtr67smuGz"
    "DtHecTmenkR1QkWuuP9RqgtU8YgHqZ63ef1wEtc0YDqqwAaZVDtMtmiTLJzCeEyjJZ2FuhSdEqGjMFrxyrxY8YsZbCEPD8fj"
    "Cr6Ja7buGo/L6F6kVv9yvokX0XK+iBFQeuevbAy1E5rCd1dQaY5VQfSJTpbwJHJjjDzJvTjx4EPgIuegro88r2Jim78JMi/M"
    "9iiYggZ1Es1V9sVFjAMeyjMHHN+6Z6SNhTG2Yaizmf3UlO4SfQKiz/ircuMar3HsesQfxo3tQTgWQMeFwdrOVOAjkxw3+ijh"
    "8uECyO8XFyHirFVecLWf+6X1gnPRDbjpwV04cTWLk5mSlKvJ+QscnTp3iUzin3zcwpxQT/oL5ZVeiYOre6BZiHmzAzt9xV9M"
    "bqXDHnBPFxejCn2NzZeRkj6PG2WQjZROFV8oD3qQUTDgTr7NHOWUff+C34TRU1/M/NTJ3gl0nznm6jYQjbJeZ6dVhcumYArE"
    "h4C/7EKnbmNsvscvxIsmbFChTVQWFPFlRrMXGWx4Fpk7cOH+XpskKsQWDRVbRqoldHg4HCbJN4GsUxgNDTCFuOIXl9aW/qJc"
    "sWRF8AfEJspFDM+tt6z1c3J2bjWv6M4RZYr1XuKo2nl4Pej63Mp+ZYDp/3jAjTMwQ1nwZ35SX39uoGN42Vh7AWLX5hwifTrL"
    "ke9CuYvBwxqucNJe2A6Ikn9hDCVcXPi0ZweWSYazn4P/ORvrtyZY4OwXkYilC6qd8H4yZSqEAccvYLeJDYKb6bjioYRozFR4"
    "cbh8fBMsEEgtDxY2ejKxhJJgLNlEU3+GkciUqRuCpDOfpCg4i/FnCorE+mFs0hirHbXe5DQ5T9yCEJa9DJaRRGGM6Nha49pV"
    "RUtzonUYnRu/CtMi9fHcxn/fJMkS5Ayd6aYRZbCJxOvFCcROR8LobOS9rvnMdKPGXVJDp15DL73Z6S8AUxXtrXRxPMGMSvAm"
    "rx+jaXRpe3KrHqCw0bLbBl2+N4hU/lp17jatw5yc9RV+IdvhbWdw1vB17qkU66vb17e0KW7YJz+Ym2BgwU+CgjaY4w/2JluG"
    "PpiPfm1Vp6kOyaI/HadMW65whA6SXEeOLsEp1heAffgqr5sZxAsAImgkZQQHTvVYIKwKXGAzFWvZpUk+txRCA6CF5qIq3zE1"
    "8wU0B8HwNdGeB9oO8oCe0xWCl10d5MXBps7uiN9uuYArD9C/s+iC9Z18cUX/Umjx+vA1wUjZU1U978Uf+LXxc/MF2Dj3XdS6"
    "KLi664AjhmrQe1PN/GX8OuyxCnfVNMjoAvTnBvh2WRbCSeHHpuj8fJKtATpC5Jj5FU/vKtxnCPiflUvIGBLzghggfuGkebH2"
    "PiuYKud7lZ/nhZ9GXtl051mRVamMMX5fpu+/tK/QQO9N7JhH/OTZpkl8D7B9ysW/KWOm2iJssvj7zBCUQjzu9In/EZutRQ5V"
    "GBniDyKJHzxPM3uxfiDfTsJL2OZ+m2vYrpkx3BCrim/gKCDknzJhhIxz7VnH/Zi3Y3XATbVuyupqlqsZVqVCGKhCCK+sjynH"
    "8cr1vCXFdpu7k0QLteQntiVVT8FwNLRfdBBfxBjN3UXycDVm6nPuUS6qdSylZW/AGK6n2+3w494yQ4lw2svoNfPgWzZSKHHL"
    "fqOfwlgezOU1MJ/UcM7NCz8pDtOBvDn2PozvneisKqfMhFupxIfbBXnkDCe1P6Xbv9S29mFElF6qV6MsOab+7DswhWADm1LY"
    "i9hklotQrW/nzqyphlyawbwtIhyq5m63f2CEiPaPVAqifK5VefGxKusksvstzp3Nt1O5pOaSmF5vuHJ7TAA7jz+xsgrQFTKM"
    "kxPTEj/Bzi0Zzsvunh+Ncn+DR97KSnLv7FnZEc/dUyfylnLeOmz0WotSxjrIAHTAS/PRcomYiXaTfbl/k0GVAIcdKWpWJW4L"
    "WJLdrpZNefze+N3RWUz67XYPAk7S2H2iji3eRTntJuzQnD2sXPYSXnHeC6ToCLMgayj6XgvCGo6NsRkBt+lHya03vDiemXWL"
    "BT1XS8ZbY+PpSdLEf0BwoZP6k29Osqg90mXkrgYaNtrc0wG6xpqrH7IlTcW34JvlnHRm/A/vDvmGEZ/tYHLoOZbb0gkNc1pe"
    "w27+jzorpjke1uu0qP8YjoguW55wEPJM2Fmjfci0m2boBhMS002h85nV0asBLDvsnYnAeoWyaWEFNPdBt7bkehciqHripYdc"
    "vXQRF3+xpqaek5sRGCs4SSd0ehVmwPLkUuGjAXlU3qyuHmOIs+VcSSUNzQtnRUbNkjFjHEpznBtxkGCnxplt2q/ejPQhlbb7"
    "zNLpqrcfBYgejWjpiIOoP3lYSNNoLCqgW1rR8E4gm4rkSWNs3Z0K+Kfxdq5ayJmVW4UylquUUSb9Udqs1NH2CUpL6qK0XFvL"
    "4xTQLAtKsnCBXBZgxMrjhZ6QJKnVk7HQPCC+V3pYK84nZYvo/CRJHf8+C9BrmIKe0ct6epXp7mjaRQ1oNe+V9guAaknXnHOj"
    "wRRVe6etgGpRaCtRdXOtdlaM24NFoySwqYR0lZtZGBAphonChbqDS3oiZp7pQcFtgKOKYXKWYBIWIfG5SxrLZnER3P2nLLTg"
    "9+Uo/OguSBRIlsWgItgcT2nViCvdN8EqPKbtB28/YPJmTXaAZ3AyZllZWF7n1AC7ZW8bkfOpiDIyzKnEwjyazMoBflT8Y47N"
    "HzVJReM5kDSVBHvHO1cW/DyHp3n7VUXHmccTfmPaBLmQKDFz1pLjkJe4c5d+SGCIqsRZi1jaHDIlLVf+XtEiWnMGAT0LnCBi"
    "9qSmWbln1d2m1khQ1/rEq5DxFzgITVOUfLUkLgj/CJIv7W00QItPi4741JOiN2WXPnCqVkcflQkVVRV5Refdot1xqJyiOd8j"
    "EeF7iYqy7VSr72ZcazRo39BamuUgLDQRWxwX7gUblbqIMM71owOQZCow6aIvBdwDlKW98yUEYb6Mn6fPvRJMvuvgjQS2Zonl"
    "Kx90cRiKmPPwEIkwPPvShbyi+32Kr6WTCF4pJ4jYocUusrur56XjpaUy86CqPQ2Z1jCe8RWAm09rFu0b0SjuIqEJYyYc5Nkw"
    "l6c3jEHEl7wMw+nNwxDJ6oTxlrQQQAlqis3a1aPQovzGU7qId3rWZybkb3XnNE8hhGGOxGxU0S20dq90lU6d8TSehrMUk1yX"
    "yiac4fcg0ZkmiQmjsd0qabaNKM+BPy/hWCrikGCo48pjOTztYGdyLZhCQ4OhUaEEUc9WLKG2Z4SsSAexM5lGzoc26ieC0r+T"
    "QQ+NUNlD/h76iE+rEiST7bnsCBFRTd2EtbOTDWkQacjs7imlNZHOAbVKmjY533PGMV6Vd7DVyQaVp1pdtILYTT2jPURHiK4R"
    "Okd5P69jlYfnnXPwE9LPQGXSWtOJGRNJUjJgoJCgreMvAnxIjqNXK+mjhVVU5XN7IDbOYRg79myL0r2K5Bb8TeQ3LGcXosOl"
    "b305pfetR1jpfT9OMW4rRT3RCA1lqcBQZkgEQT0faP00Y/3D4WGx2tT524zNdzY6A9sGt3LwOzfLD9oGzJgJnTFuCqIY8+MR"
    "83pKF3yEZz4CdeoGnqObOR4e6pT0KOkkQj2lptOk1keJoFN+UbDff1R3KXfJ5o/n9XiczjQhuRNcTVC99Z20KS/zhXUDspTK"
    "MoHnW7EMCjonpjEE02cORcavN/ECvVkmZ5jiZTQuouXh4bKlh2SeANry9ieOb0/H1RInGUaFijw7msRnDycGrGMhJYuzyk7g"
    "EpyGyQEmafkFlOeMhcBNuqBsF3uaczFfSBIpW1RqxsnJLt9Nz/ItttspcQBmZRPLCtsZmizn1QDiMfN73JNmzIn05ZLyUbhI"
    "i+aLZd7gRBP9PLOWXiDbM+dM0pQ/iEXWRi4u5tLVhyrvnK84A4eLsFfCplWIPocMSRJQj9w9GXpafnl55LO046mF2B1NqYFS"
    "KE6JFjyvS1BclEr56+IR2H4KLhmoSn7nhGyP/nBKWbcop2satUW2ktAeEhnaMAmNYRKU0k/d70aOJHnjrjVYcUcXC+c4QwQI"
    "VE874g8TxFC4CGYQak+EtpDrNIAhjryBV0Aub6CazcVY8gC2h4ySpRqWlNB0uyTHhymNLoGhuzAPbr5e74mWN4yFySrM+BVm"
    "/Apv/HQzHan2uZkWQc281P6vukZjeaoujfMyVDlmKodSy9eb9brK6ho7QZvT8ZHlkaEfoD4N0cmyDLVmQN7oZfOsEdvYfnpU"
    "O10qaY9a0ZVe8B2Ior4bTEcE6b3BHDw29wZrtBRgNgC+htBU221xeDieDpIfAyCsU48QIhnMFe1VJYvd0XKxkgxPcpInx07E"
    "9Gp3oiiYwramdK7dQsiWVA5aOMgwr5738Oo58eqClgmAK6yVlbbz2W75FS8k3GshzvVrAXg6rqMpsdaJm0JhOSe2IMozC5Yo"
    "aZD6FzVNHIiWTb9gQMqi4QjoLvEz/yCWCIOzdu4Vr3MRKuwgrRQbLeXHkEcbGoVRstFk+P2dA03t66LYxCy0Q29Ztln+kAZy"
    "PM7DS6xGtdWO8xO72/BDb7h8fjwcnuw5t3bKZOBS6GpnG6o3WJXTQeJJyoiAH+pXx5OT7XYyaKs19KJUBlAzo6rqZxcBS64S"
    "KPmaZkqIP2sp29hYabvVy9jwu1jOj8vASucZaUYkjSaNqYiJdF3XznO57zDUC4bx6D9WRPCHgOweYW9bkQqZThthCEkz9Fzz"
    "knnzuFSyZ9oY7jd5GUsiJeZbGfqeqOsVnBer+SB3tCseOxTrL+FsQdwE2riADbgyb+CWlq6eoezRxc6UJhIVisLLKCRFQKVW"
    "Ll87SraWhzNDGP4BGVMtXGCrfV5Wli/k0bWRy9P1S8syTfKd2uUnMyorRVl1SxK4cXVXpau7YodJq1NyFUzbLZ1TvobJAYD9"
    "D64GOm1csbwsm1zLMJVprbmQG9CwA75ICmYT1WCsjKo2ut7NNo6+r1C7oUyq+c/yIoZwcXYqhZTRrypZNKhkqeoF60ONt2/l"
    "J3mAiKQzOa97tppYFstWS2/YagXMWfu3mkQKNC1E/NMLOzj2ULuQQ+0iVOhfZ8EFL1xz3a/vvN25UM5X9oCaMOiZ0ZaInVq2"
    "SrRBd+aJ+/oU94otZXpR+FplMGrAq7SBZ8asrv3Kv8Bp7cKuNE9ECdeXhY4PJHS4+jtu3LCpVeLKNTk+gPb5ZGwC8fpkG9G3"
    "hRZNGvQ2Z2BOS0+SLMvhBvrpVNNP4O5VTAGPVg9lqH3D3n3Ws9YGbRA47x96dLiy1rGhonRNRrfZqsuMmFPTjJsF0CZl6OFx"
    "OljfzEJo84s8Mna6fC8eGzPLk86taGD2bZtnpqSHHLpH1WlZBKqsjJj9KT3GR1dn7studTBVFyuuZdIxSokkgIm6SWVNzfcC"
    "KpYLlpPrVVRqo8VUjBZX8CStlYfsbJ/VUlAnTRP8xECghfK4FehQJmJr2ux76Feos5XrqznXEo7vsgsFHm5lXBg8goFVJhC+"
    "hbOv6VTi5XgmMX33ttI0p+yx7o66MeJ+aRhe/2Hu++uySl479EKT7HvzNvaNIyfEQGLLr4QZcjghFWqNI5DMgk6YkKwP3ZpV"
    "vR66NUIxBVkPQn0znoIAdk8NWfJ0s9AxWjysZsV4rDcSr8cidMx0lbMh7vUDmoQGnF15drBu6FAvEOC6LN88wqF2BPPRKilG"
    "U3Wn73qa47a/8zFibsKuIAuEp+AbWub4sqrGpTbDn4lF7JxN5GJ5DVkj/m63Xar0qzzQyNucR9VrV+sijN867xX0t0KLlYtf"
    "B5OAHa/7RmJgLLfbjQbxVGcOtn7qiQbUTo7Nnu7sd4C7t20xzxjhwKwlG8dCBDqtlw7LdhbuHJfYXhfxnRz0QHiPlXE4sN7F"
    "4vsPPlKUwIjYmVLkPG1ZiiBYWsHS1L1y3nfFWzNhLSuiDBrmNlkRWSVBmRzTz5MQlq9EeUJhGmlIokRDEjXKyxrsE7ehRnCx"
    "6NwyPBUzOmrg9QjnrkHDO1fAdSROCnPlCJLQbKhXBlxHlAdEfzllvOkT3N+o/Y4Qe8hTgV/TpVOuc8RWDAJJlJRGBQ6yWj7j"
    "xJi1w7T4uoEVXf7ULf0acVu0F4gI81sfxSeEPwmyqq82L1tkmMuSm2+KNa+OFs7dK89JqRlvGdUiWmivhjACCywJ9A1c8Dt8"
    "NDRCc5SY7+E14mPpw0YEmcrFaRKxJ2iOuXGW3ePSswFxrC4L66wTtcmJoBhXOF0wt8JjybqN+IViyeSVrepVR83b4HLVllcC"
    "1uSs37lSTywVixnnuFIbjReQz1nOGRQBJLqaZtd0XQ4dqwu5+F1prHgZ0Ma4p7Lft49lBYSOfZY6Kj2HSyE6ORONJesflIee"
    "IBE6OAK25gUgSih/krXrMi5NXfysDM5LVBUo/k3x5lX+F46TCi+UT3XutmrHNUEyrAMraITWTod3zz2ICRaVdqSvG+XyqXeJ"
    "dkMkLsTL3pQ9mRe3zMzee/scgQ23IF69LnehIDQUB+F/X1zsou9KWwnsNtX4xXtqcsMv7dQtxKgosU+EOKQDHN1GtIiPCl4j"
    "emWb0tjb0s7C2M7a9w0CV9EllkdDsW0B2phthtq4Ek5cw/3Gvu8Wri8T4MjmpQziu9BtPEhdpz0jvSxkU7jVq2MjM8D8jX1q"
    "JwPTsiccMlYyYiF7azQC2fm80zBbBMY04zHNYJNVOVUCusQ4+e520bN/b44Z7vqGuTWJxnQ29fgC6z3sngyuN7D+ThPPcBnO"
    "pmUp9pG562xwoSgfZ0DzLvRRwtIOp43MEkXeOkrHhdn/orDwm6eWTzUeR1MW49l9z1bUAZVRanDfLJmIMRv1Ot/paFc8Cs3R"
    "vQedwrW993Y78L8QSeKQxN+VWsjPVmiSUgNXr1SHzKHIfrN0Tq/Ck6hdqLd69myHHr/87mQ1oV80woHrFmW32TcYlFFieCR/"
    "L7U3QX8bCu+YME3RMIntBaNgIvM7Ttu0GZFgEdVs9OwcXg8fTOx4AG3R/fi3ew9G9x5Ar0D0kf9ppl2L1FTk3i5fRatRcu8B"
    "nLfNMtSdj3pXH/U1miixozOBqtgkb501qVoSHIPv1TpfrYJQ6clpYZY08fZL7IN0DHpX6FEy1boOcbqZLUvFyqKHuJo7bc7a"
    "hYwfRA9CpRmTXrDmVI4IHQ9Mj4eOZq68pn80eUypdKLOOi/NdoUKFye+seUsui2FGEANp3gVmw0UNSdRlhS7xnxXD7t3lKin"
    "bw9pfGxrvHH/8CH931vipbbXcc7Eciw2KTnLKJ7DmgYqWxfTQx1jad8xRqtFcBVelx1DNzavMP2AgWoVVoht8uJd8bIq17TL"
    "roIiVMcetZpBTMOZcgJbaOKRYYBcOIbnRvPxEe7Lo8B4M2sG1AsC78HsUHVfiHJm97p08Sog1U9a8f+UCxkKAFtqL27gmQKf"
    "LarsO9DyTSDKXXEhhj9Smx3zrLgbsFhcAkwT1OLM+S6ZWXEBQh4rODgBFZKL7btKBUDMYFfrxRhX2wTGTAwW1Yo39lwYavoe"
    "sZihiIZSAcKLKXsyFmHxS2Vqw36YoMchHN9F/uApeVPv8OlxUydY5Y1pYcfPo+xN2Jrc9HPcwDo0+FIRRuxvCY0HuHZ9SdOY"
    "Qo9DHa7cDldqWTBmvjijQzZG46A4Kupz5fVZI7BX6DXVALE53VuPs+B1KRPwoiR+4lHZhyYix652WWSKSZ3czqrOl8lo9KJ0"
    "lvUTTzghyB2F8jwN2wEqXXvn5M+ArR8kaaJQtsvk2CsRHH8JYQY8XmW+AcSlDT06roIS2dAmTFa0SYjl5DApbDepTPS5FmX9"
    "ESmbD66xbf2edXxw65DPe+V/W5/cyeuXcvZLq2bsl4ZVieP5rzJAGKid06nZbRQHT6ziAFmUVRMV+EgJ5lNthK7wUv6ELBA6"
    "ryiFRh2eb8otp5SD4ueLrPgC3JSpSklSsvUqXWTLn3MW15aG6mFZbOmO5pOAPUEYa9TN5oOZ6n2JFZ4Wy1X2rNzUmaDHIS6y"
    "LbALA5yfF2WVjQWK0AIBF4rCUWGrvTLsl0TNsOkAr8g/G2M1JXZf7Fkk8k7NK3Kayk3TdXX+muvJi/MDU/6BmIEc0CXZ5AiK"
    "egAc25UI0Q/S4iB7n9ecRYB1X6OJuxLxV16XX4ku7/CQ9feu8YeWuA1RPAAzhztl/gp1voDlMVICt3fBui3HDqbuMYGhW3dx"
    "eOgMDa2NxZ7YJj/h7IDHvglJJlJ3QGsz0qpXDJtGyyjysTbZF5GKzjgVvOtnupFfZQ1Hf3HsavjWcH7zcldpoeDAVek5ZWF9"
    "1S27nrlvysObHZHmvNe+PU8ri+Jkif4PY0bmQkU0Y62KoFdSzllp06SLC5bmEqOAox0aT6isamPVyLajKhirWnbzSr/TtmLO"
    "cRDRQbNrDfWH7JzoLP+yUQCiHEd3EkoR2P4vCrZJPTy8zKhhPcaqUZctVlkDKUZbOtG8PWPrx8D3hzCXv33t+UmLKA4FqqUf"
    "hK0O0sZWVwyAV9nylRfcgjcyDvfFPnWQt+0vi2ARtYbJykUdCH4cRzVg8l4BTAW/smJpnhc1n1epPqH4V5M3K4sEuVHzO9sc"
    "qVmdbUSJvIg2RgmiO3N4uCqpC3Sj8vW9iIaygsQxNkLUR22zVO4e3UjqGZizrn1xLxmYyW2DwWM99OEhB8SO3mQS4HnINQxD"
    "D56OjcvYQ/Os8pIhogzUixV79lu6X5x8FE6uWOC3pWdsyKZt8K3ohs3ZXjRB6m6ySBGLCG3oSgiWc6YBicgBtr8McqyxIAds"
    "ti14o0igwXHE5AyJ1HvYVbiHwqN27QaBVmf1G0Gtcgm7FOubN14a1U4MJqLBJKJZJ3e/8rUVBaVvAI0i4SdX4ka0CFDQfmmC"
    "RTjbPMza57fRyHa+JItoT+pk0/1iNbXhzjANPf27FDqdtQudXmhci87yxcEiwlq1Zew6Nnq0oPMOqveMtxfzTsJECFcgW6zD"
    "EbBxw+Hh9zYsr7C6qkLNhavzbxd52xEbo89XNipmCgj48HB4WpZvUPlQSZ+RE6MPwNsWg9Uzx17kBzXBrAGjTVL2bBLDwaV6"
    "nVfQEDXzMm6APq2Q8sJoDIy40LrTOhl52xTtbLCT8PIUO2to7SoM26N0KxaLz5jxVNA75Evhnl0zmpGC2aMiahWUaxKoZP2P"
    "UoSnyRcVaGEeErjg/lnhmCj2OSYVvYyWzdC+aiLs+kqsQUIbwE2YOS3T1L9nVYc7rMEdVuF4Nav5tACsheIEa4YRKsya1Rwd"
    "JEMw7vJG11IdbZDTQWc9ubvoUptsOK/UxaDkPBJe+hm3odZGzX3fZOlxbDX++GNx4X7e+8HRsHMJrnJDu/z7nQW0d39nu3qR"
    "H513iCpHx89/PCK93bb9+urGXjHv/Ujx3n/1st2XKquDiwrg27Z+4UZto8OO/1x6GJLYW2hcHfjmWyqmQ6neu8ZjfQZ8RlTo"
    "ghuWvmDdJUKVAkxgbY8r3SuMLJtBem96LQbNKgg73v5qxHpCMZlv8JPHKfcjm8fgOmDS0tFzRLYcT4KFOWuNOLuqwnb/r/+Y"
    "Htt70c16EG1b/YOay30PPFt1Kc1aRBka/9cHbilX36UngU9gUSbSev1LrdcvICt62paQGjmPSNVdK6enpb0giP956spxZi4m"
    "Py3AZ6WgE3DztXbnWCHRDSX8SnhC/4/UHUELV+sjjVg0cX4y+68IB5cmkBc0PIWDcqVee7ZiIsjrmGBVSvLC6KMTJeeF+esj"
    "BjJUuZibYXb1zzwQhs7Ky74obXXiiKslaxxWJwOejhw8Bv1MIZTlc36Ih6uGSG61iuCIj551zHqEtpAGWsseGPl9nctAO1ZV"
    "yn8h2zGQAH+VHv0R7mZPXb1plQWuHjW6Jv6Yqt4sqM/x05JVAR1NQDWX/ot4fmwnMWrGELXFzmf3o3kcGY1aZHVve3Xt2kjC"
    "Uy1Xo4S1y64Nhqcn85oF4brS/fapfT2Nq5eRsp1nzU/pauPrHOVY/EaxVx/oZGggqRMitOYwd/tXCcO/7dZdKSktYOo0pLq1"
    "rnOVB91qy8YdVkNZtasdT2fnpbs2GmVsW8HYlt9Xffa23UVmRFa6XRAnrFYxsMhBTMk+JKr0q0Kp4y6jCRrmrL6GVx+1VSSL"
    "HKE47iI0vVc56AW89WR40cNqrn9igcEsCzPTV4wWSX2vOqnzZWFkS/TmpJpT34byIFMzJJZTPVZ7Z4nqxwj1LAwFxsefv2Ip"
    "qRt7BKoVxkuJvCRxi/YpTLv1yaunLbOVC3pK3HPNNk3gpJMqfsrrTSqhA3qydGyx5NCxtYbRT1IoxuJxuSmam60tjB3kvmSc"
    "gIpLb5HMXdi7SJE4fR238829FynYvknygBn8oDa0PYewMBryphVU8aEYGalX8iMe0qE9lPRNKQ96qzNSeazh1DFwtXW8rfeO"
    "nvG4oKOgjSd2U6Ye8DE+TNQYeKeJOstLf5N01wDDlAPSfBLGmchMcJyGketDfJui3f0HgHQpRe68Gwv6Ju8URHvIPR16Cqrb"
    "JYXXmWrQhVNOX87Pr26RNwtaU8X7o2kPTN3XIVExOS5l+/ChcsbdyV38FKkdbooOhIp9iVVKg+t81+SZGAY7VucGaN7bCOJ/"
    "Y4/uF7k50gs11tTFdHnzlDmGUX2QPoWHyb5vgexrReGgQfPUn7srsdc0SF+RznS1Ipc6CPL64oDyX0ci4GcOOzCjkwMCf1Ek"
    "5GGc7/7d6/086z0EPJaLFsN/sc2sKpQwTfnNraM1DMOH3EIx6Cu7b4j3Qpy1p769oJVyvV10LQ4sQGLkSKjDsFt975ZqNUFX"
    "r+TU+X6kmNwivswY4kpopdSEwihjiTexhziiLIY+QugxY4VO+40vBvaw+0BzfQa+THIV57tx43wr4VMjGCsvcxUmg2EPogVe"
    "PMlhXZcr6VjOonIqbRENU47VTad6pT3APbSbVPmCb8TufaPPjiNabvQxMSEyFnEdLed1vFAgeO7XOqrDVtiMLgLYLlAC2gZe"
    "7Y5rNkKAzOrxONQ0awGJ92w1L9TvleIrQGc+NXQmtj/0UN6aoD6qTOIdLHTn/kT4NtQl9Z9r7SIZSVtK/WAGLl5loLvhC75u"
    "6JL2dr7LAGZ8RPSk8298Sb2LFIvatn614geXkY3alueODo8PFAXkW1gE2tGombVdODzdH29r/Q5Xj81ZKZrqmiepkWmoYMrp"
    "qArjXhnyrI//dt8xmrRQBo58ykT40zmNwpKZFdgSVm8gpSncantFCcqIDZ2xbwMupP22jxDNtC7DxXzVMN8tHNi+145LuS+M"
    "8KGG61ZnspYZfSdPkpjTv9VjuZt6ZkVNIrvX/+bPgoKXVb737Y8aI5bJ0E7BPi1+01TPGkFh/00jVxtiwgDbR43GZudEaoV2"
    "knFLJMCviHZ7aVcZwFeGG9Xuwh3nyMLES7fy49YbwMga1kLADOFtnmZia9hOLfMNv086L3ibSGv7hQFO6HAvxguj3HoFA6TO"
    "e3GcnRweoovEenf7Z7GNOrlEykrtb30K2ehjf2/g9Um35tfFWdldA7iyutyHiCO7rLBGh4Ep7MBnUt0kJkiF0MCUnNlivxi1"
    "uDlKdhOJVVOcKRmaeCZ6fYpbM8YpH8PqQCXn5+j0XL9TTxFCKep35jlSppSxseGkzUL0NStjOfG/sz4BhKGf4yGbQvStWVGr"
    "c2LTYEp/mi7enGtSgb6phtOXbvH6i+nIkK2UYDCLOfsuYOFS3cgrG0YPP0fJ8GA4qpTRLhvazoxrh9yrkMj9/28IIuW3hUWb"
    "2z6bBQj9TiH7x8L2luz6DYhcDJoAJJc2s0b25Wj2IxhMmoh4TKlbqEBJEo4C9URnzCDRqEFzGvJ4OAxHOkMKv2XsEW/k1coT"
    "q9Mbxn0fuDpTfmLOC09ZMV+zEU/zO0X5lQSmZbWNtj7wY0zTca3cBrUdcNRVQTV6v7DGThskH5+Edri178SjZl5pnJW40loh"
    "wwtrhsq1WbZZiSWawJ4g176updiG2DBBRSJm35lVX8zYREt7BYy+q6jmENZmX7DjolYow7CpRz/tTAlqO6tg1GWNgZVFEZUT"
    "9fhPNjH7S1KDd0aWKnyy3VVqen2vMm0OEWnLxHjP3D+5QbJDtUSMh4r2EB9XiQ8437qfK5uJuA+I/Nq1OY0bA9PYsLn9aypt"
    "rmc5RkhiYxgqwOj2d+QbxAKTTuyQJaE8Rx3jVfnaeW1w53Sns8TpNpa5NQUJIfJUStlHTQ+Zw0y9vqoCt6RQ7Btc04+Z767g"
    "s/6OqwXY/JlZ8IKAmSv4S44oZ4YyZ8TLnOEu1ReFKJ9ra0dRoyKRAkB35ACmb5114Y2JK7ifeRjUbEHn0qZMsmQaq7Bt8Wgs"
    "ycr2sKThHrj3leaTBep9JvYbNdu+5Emi/dbR+Yf8Wo5AAL6LXQ3HSxOYBJ1XfbCwmfJKEEO3W6A0VYEBjKd8Cie+PaQmyW40"
    "ymFAzsT2o9WqNaaaBzo+6Y5V3yn47ywZZc+ihUQYCUGvwxvdPFrWu2hd1gDQYa69u5I9lZPrM+GIkoyOfW8njBVU7qqhRhwT"
    "oHxocFCYxpvM4NwTEUe5s6cNK7MAQxbxfYcGt5UCsvFae21xMdNm/koxzx1htKoLGyFzMnPMJW/bO2dc1Mr22PyRH8KTu9PA"
    "s3HdxxcpXfttFY1tXXQng+pESyVtVVP9+neEz25cXXxLN4+PgJDWQrfG0WQzE+yxgxItq8Ml8msuSfOJgVajWYtiHitxznhS"
    "Lvz7C4wXs1oOS6kCg/TqR2c6rKLeCbyrNX6GmNPpJDg/8O+RGDlkjDNo3fTcKYKviUDSKB7bnY5bzULmBHdjlxfNGPvCD2MI"
    "9YYBMpxfjq0SseyLuIhsgbFbOk4hk4eTch+0z0s8mOzNeRLt1de3seC1NkC7RovhsdCGylIpV+Odeu8UmGPasJeNFoCydw/i"
    "cRVac2efmOqAfkEb2vAgEAO6MgZCiIZXRD/LbR7yMbwpMAbtBYUTwjWB+StldaiYoEbOcIc9Hshtv6LGM2eDb1Fzws5XiQNP"
    "gRyKNm0iDkVoWiatjV6WgWm5xvvgk0wvEX+NqDviWCK77Iu9VmkAunypAq1l/WYvvkdA0icIktXvS3+SfqEQq5LYwuQ7vaH9"
    "o1tL95Qi9xnto32iUOwxEZou88bV9vrJFpdEhxrh/V6Rmdqfc4WiE7gvw/hpZnTg5j64CVmCEhEd/HsxZBr4id7uveKcmcQv"
    "HCSiemfbIBpQFZjeHhXGStpYFWknvnagX3Om2JCxO8diI88DdVQuLl3Zz7/YYuMShMYuFNGNazh0J9MGm95b1M7H4lfQu9iw"
    "umVLXkVL9ocSFQzeY6ln1J/BM/i+aPQ1uqSvX2GcI2w6Ks3Eq9JxqdfwFc54tTJ8W9qkr4nXqM+I4jrLV5nQQvAtuJPXPyjn"
    "FrpBtBejNhRVXktPKQtSZZX3qgdGls6tR1WVXgHFg6jPqHYNBUcjCfRSIt5Ih6JT5tRMirB1ZBWKS5gCwWK/YKtbKtGRPfOp"
    "LqZdKNo8ydvV5WnDnXVaN9lwxwZBXDM0+fr5kahgdYvMM8csR1jsEEzhIvGRZBmHULs4pKtV+e5JVa4xaODV2LI4Ycvi/Wno"
    "pODzOqwDJ4qRulLNhNBpTqcF3PR6kGJqNA0JVmXaY4sONI16s2pmd49/fz+ZjOmfz+i/jB6mZyfX93Z3lYwKds4lIpUAbE3K"
    "hEfUoxp8cMAC7A0t6Y2FbIYn0CIojjcn0Ua1nodEoG6XVXpOI3+O7OCyeGpdCL8KwH2hpbs6ubD4GeaVDg2EbCs3TdBzyhgJ"
    "CutL75yViw23/x7sGasrFUygtUHooKS9lAbD1+LCBIA2hc4229uJQd9rIHBdcSQBcEeucQv7fzlLrGLg9TOzoxBZ8+LozF6R"
    "F+F7nXw4jM6OLwxEFz+zZnKIuofQBrS1wsHSaDkjtdyhEegfnd2CxW20nTxg1B8UOr7OhMrEdMbzq+FttqbKleHgY8AcBH3Z"
    "wqjvrQqjbuPwlorc0KF2MT9frDI81p9fPdb+bK55wAeSBo7L7hDmc8cnbStKx3iALSlthhlHQFTisl1lYx5C9AiUBNGD9aga"
    "hQAyHGcDtSDxls0JA0Ujxb9KeIPbILul3qqzfyEYB7VcTl9oTUGkewoJ431DV2P/rshENUEj+lNJmwCx5nF1OcWerja9Wg7K"
    "8giQvhFa6ALZ/eRcXmY2aQEu6AbMlo+JIv45X4KhUW+wK75SaGDq1ct0CT3uVypSr+KcTtOqfky07joTRomDMjA4hrEi+LZM"
    "ru/Hw5fppqaR+Cwefp4u3tRYesPoH/HwdXo6jKaUQPl4Tj+Nh68Q1Yse/x4PHzfVip4o26MVXv3DlHRvQl/Tdf1duXhDvyjt"
    "F/ViGN2/R/ml9Ptc7Xn245qeP5HnJ+W7gn49QH20y+5TbV+Vl0hMBXCEl+g+VcZZqC4J4RJ9QnVJzk9QTpUXzatFhZ9UkLhd"
    "0zOV9UTAsKIHlHc2jD6dxsOEukl/iPKjh3v64b56mE4o18f4+3dOOp1QzjH9nVKVd/CX8t6lv6hJZM7S4enf70vCzz7lqqaf"
    "qQI+o+ZH+KsK+ocq6B+qILTh/6ABw1Ae01+M4++/44ESnOAvJfgf+PuJauOn9+9hVDEmeLyvxwI/PtGjhh8PzIDRr7/fs8OB"
    "n/f1SOOHHn88f2pnCT//7k7Up/fvT+6ZId5FP4Im+7E8muJf2pnflsf095PPThJ5+senJ8krNjsPfiyta8aXZfLpg9mX5VHy"
    "jwn9kYxfljotM27YBTg/gi+djH+UyXT2B+Wb3qM/ko/+0qxwjfTI/T5Jhk+Hoz9Kpus+ogXveLz8UjoSp4hDqmtoy+DuOJgP"
    "Pgrv0t2blMeljcs2a8cvMjYmjhVNqWKr3/1nsLhcbi+zJt1ehh/dzYUeWBGhCBcOrT68+880WDXh3E3Q+AmCxXZBG26LG56W"
    "mldWpZOyNvPuP+sAu7RVXBuS4MeCaPvyvKAjYXlADE5+lmdEHdHpHh8MRyvicjkuirUqBsNAO308HGUS84R+4wyQF7l6cbmU"
    "34X85vNC3rhxQ51DDxOimXtg5mQCkdGCzamMLiRTuO00JGjs9owIP3Ruc36xDZbZNm1CuHvRAEnfKacbAGl4586dIWJAX6vI"
    "j1yeCZ9kCfIM+mdZC8MDuuR+KUNj7tW185IYL0SxqyBKZWI0Y+PpPFhpuzguKqXqY35ndGujaegl4GaGyuevgayZ2i4A/4jx"
    "1YcwAd8KIpHoqj44zdmypz6g7vBkiioU5STpzum46e8CQ9+E2fHihKpbGNmwM2m/dZA2wdul0AWxQw6sFuGXwzD4zXEmakpY"
    "LWpV5bAo2Xx46EyE/XhJhHQ+tC6lIBOg1lKfRXWyHAoF6cw6D8rwuDz9F5FqB8w8nRCL+4J/e1CS6kgR7yGvCGMCL4DqzidB"
    "X9fDpCPDOQl6FkO3FLioaxj3VFeWusTh986W6LrnzLOYzrTszpvsCgehnh65gynZdsuXsDzJHS3PuCUSFzf0m3YUDSucTVfN"
    "txlR21wUO2Z7Wz54TDOMk4wSETeJ04ieiLeWVpgM9kzgHCpdbPIiB5plM+gzA2YrjQQOlYZIT0zC/sMkSw2G99nh4f1PoIdR"
    "4ySqmLTytd1V0jeWiuet2LeehuLLKl1fcDOC++0i+S8LavEYRt8AWEkiltj4o6nj+tCd0I+oCSduLOUq7aCAGrbO2OcaA9jK"
    "82G0y7OR+MgzK4GAeFMsORFwFELPIypBL9VCIogoOaiYpUaljvEDiGQGcJUPWiRY6MjzuzbSlqXUHdvLBraXzXgMBizTDBhj"
    "JHJt/NSU0XCk8UpniC8Zuh6jReqvWgbUY9OZZgTOz8whogkVDz0diCD6OhF981ZhUjgtFLcg5gWKeU/UsyKqjibzYXomFiAC"
    "huJGpi/Tlr8jrQPllSecuhGrscX02EA0rTPom/wkEkBRTRfdLznV/Q1HZga0VY3fSRJME44i8zZbhZ2WSYhl/ghwp/6WaFCI"
    "p5XgQqVcUeWHe4gnCpL9K6QCagXN25rSbrI+IZJKlXGqJNnsom5jxciYwzONp0Bq1K1OEkROTzE5VZSye63ExeaGIb2KAzVz"
    "bIJLgAghIM1u137b6U484Xe6vlgNW7j7qLxzmtb5Irlm9f/wvAT9KaS0xIhUrxRB/eMaLyBTA50M4lj/FkKZqGn9gglrkNr6"
    "BftKvbpMwaQIpY0vmubWxLZ+J+UJ5R4D3Ret4OABw8iwbubD59KxSB2blrfrpCBGD+/OUrqBmelTWfAcD6H7LJpHm6ZEX2Ap"
    "OKRRxVZ4VCy/5o/DSNiAeNiU5+er7MXbrHpX5eAviPOLhzUdfisrTCFugQZ5vXgiVSbXcmc8GsYqPOejFXGW8vKJNJd6jPHS"
    "b3+jt2IorZpq3oo1tKT6tfWbmRwM5pNywSOvP2Be1HueInlLU+DOrGoP5sCfYPnACwQfvqQbfy3LRb7IOjGf1LLhi9VkMotB"
    "fbB5zLqRwlrTyCWamZYWyilqP6sVIl9fYZDTtyb1U/oNjZn+/aX6/RyiO2909ZeXVfbW//KUx5kFZv6HH+wHZ0qPzaL6LoNR"
    "m7w9MW+fOZ35UU20XTteBT+qGXY/Y/h63jvUGMzwaIPLMswu00V9pdfg02Frd6tRH/rngLx92bM+nvcujkedSZZ11zfDPw39"
    "/e72135zVuSwfRao1d7d6Dw2rRX0c1kt/QX0LX14k69W7oZ7Te8ayHfXZQ0Qn8rM2wv6Qkxawal5RGlAnZ1NxF1nY9O77r6m"
    "l91trV7qXUw/f/V/9u5peq82b+ttd6OjKXpLm7fe1nT3s781ve2MkrztrFcKvfd3s3sAfHg770ul5xrf9295qtzd8fTT3fD0"
    "s3+/Ox/Udud5pKp693r3m53o7m6nl93NTi/bCxOYVtmyNZRuV50U7izccGaor+0jwz3u23dDZ3W4B8mxOkmioRwjwxPeAeou"
    "TU7n3naI3VtPDG/T5NrsjPiijFo3Za/fhx9eN7tjvJAD7T8MxYDzlt2M2UE+0vu6r2DmQFwTMOa0OYhCYLDdEDxDYvnYCAqe"
    "m7/lJ038BGbrTOojFzRmrqN1SUQUFRrMRnJD6OFdfHMi1vQrK3sn9pd414mP9A4ISPa4uVXv3RJLHUUzEEtKFccM4K88GCqg"
    "mfrKrTZ16gX84UqzTqVZT6X6nS6/tU9u1TcT144lq3QD1GpAo+Eyfztkin30YOa2BrwuEuLwD65XqGlCzVnH1U5lkuHe2zih"
    "nf97rWPFfKdNvh7tSf72Tnl2RhuGtSij6aTV5tm+dVNwD9itrHcP4kvA7qP7UuBLoMr4wIb2kuhSP5DHS4I89ujqz9DyQ++L"
    "y61LActy+zJcCCgUYMicW5VRf34V9DjYrYQpt2fMLrrW5gYjqEWH0Wme1vF059fJzNT/TsW1rfgWdd52pPZU1mepbk9Y2J70"
    "um/PmuRzjpkXZoiuBIM3BsHzTKCzHcDZCxZpiWdSYXBJIKMYTNi+vInGU4GY/vBgj52e793OH+y72d58PX3w+Dn439/lu+gX"
    "0+59Z+T/F83+QLP+87V727b1n5n9Z+IBoswcZRpoJijUXV9nabW4CO7+/upuOHd3C52ZTod+XPf3BMvpJ4A2ssfJ0KRnQccN"
    "ObwMSlbygQrW6bmT/hYV2Aya1duf4SuuAleUzXHDnpAsfo5ytbksblULp3Rz3aomJxe4vNvU9I7SSQ7L3HygGrizrZ08t6nG"
    "yYOW3aYa3TKPpe3PI4SeHrplti7zonHyMnd0c1Znojwe+cMVOu1EttvV5WRyWMAPV2bG0WP8PlidyWZle/155Lu974c1yypN"
    "zmd7W9nJmS6XNh9YwdvWuDltqnShKoWUEeLKPSRRy2hr+LuT7VV51snaAkTJOkZmfGBqE8MmPYUFTa8KRsFIAp5AEZFp8lNg"
    "T08dahVhFqEIVJ5R3wfFOP0bwm1kPWglDc+slsu2/Ol60Jjm+8Y9xg2SLR6Xl5cpEQtDM5AYHl+u0ze0+9U8PSO2zxoM3CQs"
    "wTyGMtc4e3RRlZb0yR2+UhQgHLIHzGRpNFuBuIMSDZqrgJKUgIiZkB8eTsK+7yM2fHdh4gKOqFk9agKVf+S/uMfhxd0q7gEF"
    "ZTgy4za0+PC5DqoN7YoTOjtt943qkd6lPR25oY2TcJT1WeOOUp0idfCLTJFQrjjvW82HGZ4LmZQjmMnOFzTAphTUX1v2/19Y"
    "L1bDNKugK6zG47DV/94+R/D5MFEgJWYmCB4N7jPrq29fREEBJ1HHE3ZsY7GOlOJPQTwY9WSk5Z63Po4gbOKYAbzvfF1JfyGt"
    "ROCsrQHTKt3POPzEsZk0KedzAZEm/+EzNHVUl7VXoOLB5OAqbPmVepVDYwkQnq7GcpBzGJlc3Mmh6vPCE6bvg4oPQpEcuSRl"
    "yCHRJTCnCccJShTRCPFgWBggaUsc6fkkLqlVdZMv3lwZn9LK9muROuBofUGNBzQ2aQpTUgdKoGXemxX1pspelqsVztqZCe2u"
    "QzxDxEhjQjlhGZ15jgFs4Sv2zfVmva7o/oMviTij+/a/XA7iOANoitbCIPlyRyweQsRct1MxAlJfqVM9CDnbxW5SPmG+tUtn"
    "mbateXRJb7KrV9mfDPHEw/U9XCn6rHDu/v4/tJFVg6vHzc62qPEmxRESPJi4h0ErYZI7Y+NkjtrDT72jstjg9gyNz0dAeZAu"
    "2MidmrG23bOr4KzT55uj0Dmtepau6x7T5t8Ab9JKhnB0VaSizIVmGqynjKImaOFXsIepDw9VMZ0vXM522/os9fC3nYoZPvNs"
    "qHrHlA4FM3ucQCIc0Nev1FvlyW+TsQ2WKpOet9vgVUaHSvSsYGjgwSC3Y3vhnRxZSi3GUanmZcCnj2PaM/BbN+flaAx8IJXo"
    "kZaoXcxQV9stZ2mn7N3e87v/PC+PH41/OzHLFeZIJZ9WXtlUcNxbbjtVyNtqnaoQz3oUztOuK9IApippdY6gRfoJcY/81U0v"
    "n+bZig4WxpvQsA2LTZ38HHzNgAvKmQnBT4loWB1Np4eH9/7u2SYFuHXQUsbRxSFijimVZta0jpDpp0lSwDVZT44KQ3eRcm2z"
    "MyqV+pnPCwlBRMvgs88GyPI1kEiDU4RAUlZhmbEKQ5is7v0n4NzEWuF25nNvcEr/0Sr7BK3A+HhLRJV2eGj8ERwqtv9tIIVH"
    "U2nj3d9Pnehii6qs64s0r34/1SuhI0gy8X2oD12P6Y7gyc59hVSo1rMVE6M6mtPXNJzDvrZQY68y45zBO5KYM2xE7/UlQCMQ"
    "Igyfwt3LG4q77C/ucm9xO3Aadi9f8irGwnCXlglwwFCw5pJ6b1GDTQFv/yvboOWyt92qDcB+9HplDOwQn3KQL2VkaGViqgci"
    "+lKW5DMxFqySZG3MMdVmFq8o9g7kZp+huncX+eICVIJ6PJpOqBkDtUf0bdBnsq4NyaqYTunh76dyqO6DvZFj8H/QCTiCof8H"
    "T8EdeynmvN38gSwLGoWXoAhwVu/EPeYqjU7T6H2a9MYgbvLLzASTKGuNNH+6aZqySCqH7nzXml+m4bXvCs+1marqDvHu+dvs"
    "dbnBCFaqeSBXyqqp+TUUB3Cn7KWzQNfxYrNnQ/QM4Svh2Mdh38TfJavEcyw9XeHgi270a+vPNFEuPYabG7xyJ7hQXqEgzF6w"
    "92hJE9snwjfupJpWPaUD+5Q4tPISfuLKWHQeXKXJqVp1Q1o76xXxYvEVpb3qpj0VEu59qt5EVzrnstycck6U56cxpYteecgR"
    "5vJQW2QNZ58j/rryW0OgnpwtcIWilHPbOhn2vA7E0r8vzoOQ+8PHK6LJhzPdSGwFevtEfo3KWPebj/+APr2W36PS6irYZLCZ"
    "iztLfI+fn+VLolGG2q2FmPaIN883iJkJOKUPkwXMEAnRHw0a30a4+A/I+CKRWKA+wX4zeV7IHs4jBOBkN1FMwtxfVkKxpnNn"
    "Sf8reI3APhFQszvEAi1YucSjbpBiAyqYNYIaQRdmWZzl57TlGJdoiOVdzHWG+HrnAl5tirzRc/t+XjnXdWWogEqdyDNJnpTz"
    "IVjDlFecWXo8iyxjje3ioFcsCo1F1r8z9Yr+Q0c3ll+YjdyAmjofcOrohml86hxhGJ9n7ziPPCanc7fRmnQxGSB6flE8ofOB"
    "M9mfCage3Usnp1mx+U4jlC2sFffMUvA4c+CqfHj4l8TW89eYHaKKhUML69dLdODD8RSWsU3AXxTEbn4SGuV1CCPo5s77H2Dw"
    "G0raXIEMhw/Nt6NJON8Hs2bInAgOldSLMm/p6Gsek96jNzQckevKq5wQ5X1GRdP7z1ebinGweF9dpPVTOYnmexNSKfFzYT+I"
    "OsoZ53BN9Zfviqx64lM3IHsWt0gnCs6NSqm7JM7AIqyJlj0fSym+FLYIMhe1rrbbb3ItKRGCV/7RyzaisRtcbLd0zv8jSVbz"
    "/ptqT5vvnJbLK3ViX9ORgkER58OY8dzyHk/tuPWSsYg9zXKZUDdYNJOeQnG4WOVU7i/jTD+Fo87XX83XX8OHyZQuz2WPBz3c"
    "XXez/auFA8X3rJZFtGDn72RQODsPNOytJv3y1pN+edOkX+6Z9BvW5+RmyqNvfqLW0MjR0PMyYIYfQrsy7IluQguK98asu4l5"
    "Oc54neoYwNjVjKe0McfIrDCn5EAv13lQSzoXXCBaJTWdQ/PNcX0SK6Exe+DDra30w15EtfNGYLrZ/8veCXT3y8VidxAV4xYb"
    "MSKHkL0MylEn46nFdFgmb4RpV+XMEPJbNf/7PFhFSy0lXoqI2OzFeLnTlc6BKFGjuxuNxZGDmHiBo29jQvuuiFqow+i6Vptu"
    "alAwPuaFNdzRKOgSHtJRjTHSSg862/nK0z32xtmtTTsG1qGuWL+rR9BwTG5ugZ7bMG5QaB2too9obupkIn1SAOrUGZT0kU3P"
    "i+MsqSytf6Hop8kAEO5ncHIC80TcQd8MXlsHyuMTxltqK882yU/BbwgjXDk6noilwWlIR4j62rhfG/X1wgaY2GB7rq04mX+f"
    "Jy7opoX9o43shaYwBkuRI45204ez86PkcnauJX1vE27UuWrPVfJr8DZCk2YXxELOc097UjbBeXTFyhf8peXwVi+HK2zrvWlR"
    "6BpQVAj7aiIi+xlkO9ilsmhFv3BWTC4LtbU4IrNsdnyO8a+vi6b8Kc/eQQ5gdtVp9D5ZRe9kbzV6b0VvkvdqN82oknd6Z70h"
    "0oK4lOSd7LA3CR1/7zVN8s6EC4k5ic6TLJCISRPJpyjXx8miE9XjMe2jvripiY6UAwJcKs87ugqcOAhrD0Q/4BtpZQEWrlIb"
    "aLtV64yV+2C56hNxz7J84TCmM0fW51vckhDWEwwvPJXk2S8Fx286UokTTgDXqIF1jZrEU93sxXa7sJpPWxAIcy8afVgn6s1Y"
    "vfg4YJSnJGlpaebTeDylKbOH6Eb6VYheRvdrmWzGKZ3HeD3mbnzsOHDRmYlW0pFJjRxPt1v8nS+PJvHy4WQnZ0l5vBgFNVJO"
    "whPawrW4gJ2pftImvpifiRvYGfwAz+l3x4fN8O0YprU7f+fzRt9ASomqtvKativE/7gxTSSYktZpdOrtoMfYJR8pAJF1YsmG"
    "c0DKbtiT+jHTOT/Q0AU4ZRzwqUtrfjUandOJZ++pvvNRHIDNcZpGZyFj43Y5uOiCEspdnfxcBBx2A7pdqJc59AYRkGJPLWuI"
    "FrVDeJQtDew58xKXjLcVTR9MnG1eJ4aiO1rDTGw+vjeJzbuHayI5m6a8nNPbCSi5D1bjknoG4nGU1BHqRwNQvyMtxBBmfeIF"
    "8AznyfTuBBGZFJXdpmVvS99f3ZJjOIWNRjt8gg2VIHK0Fj9EFPQEEXCUrIzGiOVD80v6J37LyuLoVPK8tfSu39XT29KsV+Ht"
    "qOBTh1iEjEEkDPFztAwHjp6iw0MWdkKuks+BXoaAWHx2FuGHpGhdWjaM74v66dW8K5J8TBQk9fVZVmxQ43NwkqG7FN54elpF"
    "KlVuaNDngD6TfSSiAue7RC1lqyvoeDgNyxG6ZVh33glDkjlm/NaCXytPKr5tZn4JhfJelij2ugOP2yrGqBTAggaCzqwOEXda"
    "PUM3rtgrRKHuvv5VBJEQQ+Vmk0palcAiTWnpFfAa84dC7ZytyrJyNMsCK1/vO9juVAwabgVhBS8NxTGkDj+xSlKjL9lTmIDs"
    "rtTZsd0O3mQsHNPz8IwLLsd8lK3H6Z23RH68YCPemR/Evt3+V+ts0RfPPjX9WwAx63m55LD2aMji8HBxc68fGhyKg1NuKGyj"
    "zbJwgbacRoCwN+oiiFu5U85yfpV6kXPV4jDw/pCMRh4a1HcqwzNn2ui3q4lSUAcynroou6+Gzvz1V+ukjQbK9FuUK5xqId8v"
    "uazt9hXL3G7Yx43T/Gepj3CmjygzSMkN37S+MLj7e/3x4nJcj39/Nbp7HiGogMNGXGRu0uCf29/rkDIg4QHnGobRt9DF7d6n"
    "btBlEacnexQvRgEy+mQyeZgdHgqx2BhtSMjaIkchsuNd8TpNrjWwSBel01HQ3fmarv/hbhc9pxy76EXqIRE9cs+9QTNIBgCX"
    "rAbJ69QC33hYb09V1hpWIvPLLL7KZrlrRdIn0QBZRw90ie5NmQnWF3GleLgppSgPizv4e1O6VcbOhwCEoIf9KSFaKe7gr7uF"
    "nqglpeefwxRg6dCAz4OXQWdBeVpRvBu6uxegb6Adr1YZmEHBVhsO2ynkPQPpxcHr21XyayNkG8gBQJtmah3efId+ybZkrHey"
    "nf7LM6awGtR22Oy/Ui9stsom8XrUgCWIJ/gnLB5o1f0ZPE9BmxqzgObOWxgKzDrKkWJuoKeJgmAA3EjBy3lGeIyBqA2/YknI"
    "oNJuxGr+oVBhAUpczGwwj79SOVVeYUrq48b5daJQiUsNT8tTwLne5Uza5OitB2FUmnPFTpCoKOlskuIabw1ZqNs9xxKCyXQn"
    "+5dCl8Z436DnkmtlABQfn0TYFFQcP6P3X2ZFPOG3YutHhG1HdoiXTEplS44q4aqM8IJhJ4HzdInDZjyNFpvG/enRk1yDI1DF"
    "bxOinBmmbyOxvRGzjpoutDxdiQkwE7o0UOmmKblFh4eDq8PD0qf3ImOF8gEqsc+Oi0NlQfZ5g43FjOjcxjkjmLRdslM809Lv"
    "aPlHrTTL09VCLlbVunlHdYGtJLedsRIQpi3UoL7q3hbYYPciZtjgxhrVOPRmFc6M2L8wEgnlR7bbOfJaSxCoVtAty4RD2O6w"
    "exf3mQJ8p82RZBTaJhT7CoDC33JoVqyrrDKoPVww7H0FMCkqkuusWMYT58rKEdbOV+4HVfIBNFknuXBT0TS7H0YBDgnnW3gH"
    "Kj0Lyuxg6ygs06nA5jPB7ItFlAK3sd+JoLZOyVW6zDf1L0fJFCpt+fUr/XJsYA2NpSPEwEnKWBjqoA38dpzxH5Y8gYzNGBBH"
    "L/yPq1HxcfGQKIpda2K5ZepSduNVmKWZY/GVAf/h1ZiHGO5eAwkOSKNHvdLUurVB8If9mquN0wjcJB800CLF6RhX/vIouT+Z"
    "KFOvHRsEtEaZ7fic8rj/NhWYF3hR/RL5qYAA1En0Kwf77Rsa4XTdAIqtleaXzl1JJARmX3EZ++07y1/ffk4hM4HuZqBwWvqH"
    "h4IHVnAHWU7PtdB7Na5jRU0d0YgplbgEGLDudV4F2r1sVkKnhUHfbhGQVp7DueIr0ygNY5Wgk0ol9Q4eSm6Z2rSXqU1dpjZq"
    "AQiU+rAq5bCi7/qAZ3PPHe30PeO6AB2yGsLeovVZnlpTaI8c5r8ExpYm83M+fXtkRmH0Z+8njgoCNRDzaqayLOxpKF8a7y6y"
    "bNV7hD7LvSPU5nvy4hnbQ7xq92RvXkMb9nTenD+avnAiobTecQgUqHIbn9DHEew5d1FDzAXymi8QJjD6EwSDPtG5e+/pXWGs"
    "KhdVRstcS5aeUlvwl1j7x4U2b+jDn+YIlT2w1I8Cdi9VJqCu6SJ/r10qC9nUa498t9jY4sEkfnK99Tm5pKQn+Vta/C/6Exd0"
    "FPFQRDySCCjme7Dv89mGPJeW8KBPib3dmkN4/BWQcWn7cfHWwEzNT5fS4DPOQ1WvPVR1QfhwAAB4vbjps7MzwRUp39HhOIQy"
    "/Rkfqz3lUqO/vqTTCYYJhiiiCcsvz4eOCcOQGOGcIQkOzvL32XJ2wP7DB5PZATyI6S+8h+/U1SIZoo44R6F3z/Oz2WlaZ59+"
    "Ev0wWX354snq4tH3jz5/hP89/urB54+++PbRoy8efccv8P4L+vP149f098W7JKGNxJE/3zFTVqngdsk06goT8G+xFMT0CqaD"
    "f+DiqZR3OJ8oN/Q+qKIJH50MUM4BXSBF8nDYK71QdhFY1Zipy6/LMGLutn/vMfD7TgQGi6RLp4HsWxhL3Z4ld5lqaFV92khy"
    "hxY+V7SwfGDGQX15a7/wud5bw4vCL7yFY24TPtIJd4oBAsZ69JvHDvXFHIw+V+FWirDNWKhARo75zx4q0kmCqGhqxymW6fDw"
    "Ba52MXh5pNvzIg1fpG0w4QVlf5EeL05UTCV6il5D2ZIbFpHu17y++JpV9O4vSWB4Tgna8HNqxZGb8Of0eKNY19n3uh01ivH5"
    "ziE49Mv8L9rC5/lpvsqbK+K/AdtTXtL6yJbMBCvHURxerHv+gdZ3Vgnjaj4pgYb3PRlikIfhjjhs5UNaJ8T+008RDYjbR1Un"
    "L1JemT+niAlnyOCXXUm2siJRsUaZ3hf30kj5Bcvbkvl95Uo3z5MrCWYp0xVTHhAxQytVblsIrETZziHcfwpWonKXmMDhbCXF"
    "sJ8z1eX+FHmN7LJok0hGFfr07j8hIwzBCoDOg2PAK+UCIOlCZSTq9COAUYTTlSCPVJmik9ZGHmGki0iSL7fbxUPo11RkYcU2"
    "zHSvd4JiueAo6cBDHs7kA1U5p7PhYSleo3NtBqH9RPUAxJOYx1zS145kVBr5Iy3S2DpNq2Tj/mTt6J7oNQqtYBDiRCtdyKgu"
    "ISk7g/MzELr9AhFW83V6WjsBOBwdxOIuTCVm4/FFeDZK0mg5SuCbzWb4RwuqlV58HyzGZ3RULQfJRku13kNLu2S9DA5m/muH"
    "3Th6Rp1lgIh+uiVravH6qHSQdPV2XWv7jvPE/Xy85lVybgFRaIQOD881otWRaQJnvkz8ds3Y5mattc6X0aWNpqV2I4epzpuv"
    "yvJN0uP2SQeKxMwK5dL4ou1n9JSlovTaARD+Ku2aX8uG7foWRgVU+q7Nj8Mwju9NgGSuwpwkcPzS1I0ngnqY0gZ9ykrZRaIj"
    "Zq8Q/cgb5YdT6Lu/ICrpi1S2jwCd/14MacMoTtvP8jedUn4mCTFYCz6dvHPXTyUhcxQ0sRvoSCWjUxm6Rt5/tSm5VTNcSPTC"
    "5s5yES+zylBavEWyLKh7cLuOs5NdaG+HZaI1+xu+Br/GaqUN1KpzPJ2dwe35bDyWebswKY7PTmAfoc1ozpMLNpaZXViDMlYU"
    "PJzM11iFa2X6wMYaMA2XaTNyR7o2V/NzpDyXlMYqSuybunBu9G5xMfomqHVIyjCMV5hKnk4JGlxn/XNbO7/gRZacO200+tVL"
    "FbhqDditcwlWtZgvjs/+tlBVnsS1NnGDE+Jqrpam6Z8jCH2YztkDLDaHA4elElb4kmg79nrkTzC5htPjZbgDg0+9+kHkaRE7"
    "eEc9k3d0jy2VO++TpU1OZymuX/hX9+2apKfRydiRP33te1JywMLTMq2WoP4Zftx90RdsyVGIKwthhTkIC3DP1hy24MYoPa9h"
    "ksv92W4HjUNtbbd5K+KYhniGfwyoZsUeSGAkoiIHEyfukQVod3xcsZ2qfMECZ3fX8Q0s0AJhDxZ6VBA5394+BbZPobdPblLo"
    "WOlBro/uh8SEbbcFCHydZDw9cQ/63IHBsseoChDImBAiJUkTibxe+l2xFpASO7j12Y0kzHYBHFn2RacYDeawYnv/8DpNmB5z"
    "GqdpLnO18MFmi+F5hMzeeyEkj4NF0QZx1GaEZsRC9iDYX30IBAvZVV5N2Flu8W6wg8/THvAVgxrSxr3v8btuJ9EYItK0MrkW"
    "kRYgFHMQDvjGPwRQclZpBPuo0dEpaYY11IYvD9N4AtcSRi+SGuPK6c+/HFqZpWuPGhqHUyLiA6bCF2UFHdkwqubDEmiixI8O"
    "lSCunTRd50264thUxY2p63W2Wi0uMjYiGLhq+D9TE6GOeHg0m3jZdA8jTzRbuaICZwdiqhEfjKfZ5exgLVGlmLlnzjs+mK7f"
    "zw6E+6YfSESH19h7QSwbpiA+KMqCQ6QZsQ/djapu3EZEFr6LDy7yJe1zqsu0pspWKSSmps77bp0T+mHxyWp2EwHjI5KBIe1t"
    "SsHXgjdSrLOL1DBeKh8u5DuVqJVD6tgBjUK+PDhdpTSeiANsI3T10FUNbf9KGBVrY1yzu7zA62eOpeW4ih176oVF81+whZJF"
    "qOKwNELeKEZD+6vCngn3cICbfgLLTYEXqJ+nz4NNGCr60DGIR8LNw+TBg3v/+PTwcHP04NP79yYx3uCB3/z9/if3Z2niRzdw"
    "qH5DG6w8goAbUn0cLOf34inkyeNKk1VwE9/nUrRmj9BeqBADkiC3CeAMOIJ644VxYMQQ/52xv01MGAa4Y10cJROWGFH6iZNG"
    "IfwrA9+zjM6GlhUvdeC4PBHDsT6r2cPDVMxW/3Yv4ToKGuYUEe9RUCxhMo7YTLbbKeV30Qp0qfX37GnqKvfLZg6H5ZgVcW58"
    "zMoNu9prFrFKVtvtUzFbiyqZihW7Z1yfZiCjiDYplrE3lhyCchHY+At6VOZ1UAEjkkdWuW7oNe6OzXY7TZLURXtZJvYNre2j"
    "CdG+KGwpxsc21A/ke8v52VGScihsethAGRUTWZyq+Nn0uLnDjQ81kbzsBG9oxYJQhsBn0YWx7vVWZ+FGTvHFulpeP/eLgm5w"
    "aoNUhLH/me5AHUVilj3EAslstKhslBgwqByn4YrY/YkYfetho2lezQvpZ1wHrJKL1FCpxZXAmO0IA6VXWBksohUnQW5JRpmR"
    "BHkjVZ7KyWX6WWnqz5N1UI4KOuM2XNK5TnGuaHQsdJmUOlATwQ3z4qVcIvgK9foy8fcpcCJQQ8Gnlw2MRdUtAuKOQ4mzcr4D"
    "bX1JS5U9T2nnyJN1QE2ZioTL3UKBBI3q8EjB2EL0kqjnUcaGPMDS0AfcQtxIGrPZB4E6wBfwuDDa4yYpUzoZdEvUxOsQWkk6"
    "M1gzjo0qrf7WQb4IrJhfQzHKe/Z501+UDSvyCyof0lg2l2/MZWK/0RbKOLQy/uXo9dlqnUFnyUUJND88ZQaT2SCojoBTQFVe"
    "wFNlMJX1t3avF3W1hBJEmhZCmQXr6CycD98N4yVdaL+j3ev5kCiRwRKCs1oJztZq2oZrFuTgI830OY35eTJEIzZ0zQySc9pN"
    "R3weJ1Oa7tDMgD2QhYLFsqNkG8oRVVhGA254KF9lGW4kfBXis1t4mYMVDPthAR9c3rnIm1f5kj0Lo0t7i3/bFWeythZU8Epp"
    "8/lsYyWtuYlr12+oayNk1ZjR50TSEjVfZJW82G5B5N7R2jQVRdXL40nZ6vGdBx/XTjVhdJ9WfsJXfqPsaBnOfB3S9bvg9ajN"
    "myWSkJtydF/Sju+LPGIWEBuDw20FU4I7RKfVNEoz3k+IZ5TTnRnnOG+F2ELoJzuUeoZGyYOPK+27XvKc/Jh6EiwV7FvjSMCA"
    "/hGT09CkJK13Yu9r3zK76SfkVyqdGKCJQeZqBb5Z7JikzvISZCRemmTnVbrIXmZVXnIMVH6HuMtPXjxT+gWxQrHU2Zce8/1F"
    "Zck7XuIVXMuFag2dk0/ZAznY+Bog7WcgVRTmRdmPmIaAf1iAw1nJzNaZeMDRrvzbvfmwUtEjOIV2Cfm8gkt6uta+cWYrKF1X"
    "orLBVYdOn1W6rrP5ig/wldgtRCu7O/7wDZXFH/s0ZZsKN9baR37oLDZtT7qgOCL8DoruF9c2uzJga1w/yzVelrWAiut8MAt/"
    "XTKqIza8WgRVMpHzGEu7SJrZrEAoM6OyU9J3uo76WufOHAsfbUZIL+2vvsyyE6ybI6BA/eb24IL6CY7zE5EcFFyHWUq/pJh2"
    "DmdgY5SmbeQGPrn5kmONpCDOsdkwXbN/wVzTHVZQ9gzSzutvIqMo0yaHxmASIVqbNy8YX0Bi2OZXdODPvwnkAYJFF2ncVIMQ"
    "me69TztAgLLS5D5IAvQXodnhsoVppIOXD6eUaEdgAdlGGMLh/iBxe2uKoFsm9b5EopBKOQXDXxmB5WzlzOkgKWYhEcjOKxVm"
    "E+BBKSyr6Fiusbdqey5sFBHv+LeOadSPgsV8YQKKhTzllqREfDEuKF7QlEd+wNhZOkruO/FiR/fEe5DjNkK/pllBGlcUJEMe"
    "ywwA74HIArgcjgo1DQEHvyNqmo0H+OMogJ/fJDxh1QlcZBUQ0DLZBCmzBBKc3U4krScrwD6jYSpoOl/lpzhuiapI590BJv52"
    "MjubnSVnbmIJOU71nEVn7jRNWqtTyWwgahrzgpldjKgkrCJ2MygMg2L1OSuWa+blptYtO0+q2Xq2TtbtL6YZ62jtNgMnyr52"
    "jM65HecjKq6nHbsfXceCHBAnXSNWDYvEKm+4d15GkEsu87dJ1sUOK315mMbHmgHpv2mfa40NmjqYCBCjC3IWzGPe7PN3+ZLK"
    "cKDOLLSZOsWM05BpSKrsK9EgIsDe820VKh1ND+Jw+DQNrrUWAMaELCQrPNuUmu3HWCqPAxWjxkqim+HhbEDjwudyqaLH5frq"
    "8UbbZCp7z8/TgJhsvz0TaY8wI32N6I03X7SAbxsdgHMS/QF26gMt34U7FnV7cnr28vQE92y2yaJ7rYHr6lBm3YLadkApax5u"
    "UgmAbVJLnbHNulqBnZxCkBtGNe0uu09m/0qDGn3+gAXWqjeJLYfKFVeDvk6KXczPwQ8I9zt7igr7LUD66nCNc8BAG+PFBfsh"
    "AgmofPdSwCi8eCnshJqz+TPo82XeKESS6F/g/+yqs4JW56Uj1m2/NRJccdTUahFPXzjABmOnq4Jhn1jpU9DD6ihpWdSXOaXp"
    "MyUU/dNT4vaJnuU9dk9bwOYw/b7UYtW2oTHIdIdevmZTrYztoqJlWWAf7/rKkQr3FiTAlTcX29s+3zzXL1SgcakIpg/0W37D"
    "BtxEzasReFVieCIvFZVtzYLzPXbXjqcC2yw9ti37olgGNrcoFH2bVqf3Pa1xeru+4r2qfm545+4i7yqpF1WWFdDOZdV36SkH"
    "K6BzZ+ldL0Q8ib/K27b2oMrT8QrZYAkbm1SyQfoTtltABwMuG7NPXEAfUSi8EYsm3GcDK/7JjO/6D9qd5i3MYfQz8RCtrtKm"
    "7KmFmRAAPksVfWQ1DHNUdTTkoUrbv8kj8+0ZQGzXKxdcH9bCfqPcS6sHyqjdqH58Jt8qs6fb7WZ2x1h4V6+cSHHJNOyFit3r"
    "g+zkSaGtBMqkECsBVjD6jFSS+G+wWgExIrAC7dTbrZiYHXUzhfrkfbRasd6sVvIuJeH8iOXZSpUG0sX8EGYeiBkqzZnm+vWz"
    "SsFMTQqYA+JEibdZ0ekojwKesAF+wipk+Et5s1BvyjA00AZuw+lO6O/qU5Yxf4n2oLRrkLgx+ykolgBU/PG9k0iY63gCYXnv"
    "2LwuVTmltH+jReH1sVVYm2Kjs2TJnMZc/hzLH5sw5hezTSJNOjs+s990Y5yX907Gzq/7J7udeD+rVlxEa/BymK7H5aZgJFat"
    "9+TYAgx5eJE8CxZM5dNtKnVEG/uAD6F1PN9hR6rI7a495hyEixI8tIsLowvzbcn24p21hOWyXIpG9gIYOrdIFK3FawMEnl14"
    "cyfROowrfWLgFvjSCojYgloERJcZzOLcXcyyhp4GEDvV2uCtUvs398xz2WmLqsKu8KqfHMraAi6DKVEW6uqAhRBLinsJXRup"
    "6lIZr7TzA71NbGp7TrLuoerdVC+C9olpDPEjHaoKJrqdZKYRktL8bLehM1O3OkpnfYJJ76Tql1L651fUI7R0j7JeAaZ3vrUH"
    "VLfw6wK0aFndrjM4Y9wt3fWC8zY46JXLsqCOZUA4eSy+f1mlL/K/zPXNJu5eC+WKd1o1LEqZxeFA306GEq6UjZH2r+10Dytz"
    "H7mgLMI9IkEStgmUgAVakSF2DMKh33SYs7stN+nxIeihA9gyfx8NQBnbk+fCGXezAVm4tXIXWf42Wz5tD6mdaHXjz/aN3vxG"
    "V8uMReQeIcJAkLmh3vo4ipuPAU/0zoEd2pO+FiixrCJWz1RwkAmhfNm21yfipNXIqPGL31s2e3rt20Adqvmm/WPGy+7/QdJz"
    "QsAG1t3/g35dBpKZQ2DQo9kwCTrFPN17NHij5HbL+qh2NRuHh4P2NaJvvs4dcSvCE0fNWyIlutR5F5fFhYT2BFtdiRbkV470"
    "SsoaK9q6T3RlJF9GehW4s2fEerqVxPecn2fVCwCiIwZgcI1Bja3/jAKIjz+LfLlIrCFP9dKXw0IA4vmFOm1E+u4podQR00NL"
    "KP/hD9PHxQfpYyJlisPDtmlmXir4pkc5g91BZhVUQjgX+CO+ZXs3OnbWrmcFKimou/7EeqN38QVdEsdPEu5Vx8kQKW2tYXvA"
    "4Fg806KHBUqJIlcsEEBINQsEJBeG4lPgaYUb9JbVbcZDdjyNfkOgS4xeasJ0aTVCtGL0OZNi1bWWBt4fMwWFAzIJNxXUsXK8"
    "cFXxR7nDhcn3h7nVeZm7PDXGqTY5TEey5LwIClVYGM4lwpOk4tBLrPWpEvuGqffYS5d10mVgUZDSE+hr3EJifbjWlVWMbnTT"
    "DHcCHFXbE8N4QQWIkRGhIBBJbTs2o6lqicpg33Jb2pL9aFDZEbI292ppWPv/G9Dph2zGS8ulP74YkNpdy72s6wTqKE3v5Evi"
    "PBzd3SZgTN6gHCUreIDxA9YpynXsNZcs14HpA7j3UeICHpwpxIqpqz+zyJfnnghocTluulbgfF4tNTJAGV305aM99IZtMSjn"
    "hTYTET/zZ/SJtbKF8sERK9poEYwuLOY5aoFtvxbSlMka642DE09gRLwMvtf6cdmn0BWWoQiCV4x5ehYMz1KYNSTdJsrpkykx"
    "rYG5mon7zt1/BrQ8tqAd19tVvuVE29Mq/Ohuru8QjB5fIXxe3/3nadX3kaGfmh69j67wnO5AJ4zcZTKZXR716C5nl1AGBu6X"
    "48uTcKaaug77aw8kmMA5n0wDBdR44KlPMZaNo4azwFmbe5PJqWBmuW8nk3TCAFkI9cfWIFhWEVEf1SzEfewq+XjRGxMPmvSK"
    "tnwT1XRonSXf68PPccmq7aFZe6chLY6lA4R8Zp5nuPW/CZZE8n8TnIXhki6YNa39M/W3Ho+N+mdJq2iQnNG/orSiItmLiZPr"
    "p2Y02lnHs0m0pv/OE2SNLjlv9NYa8pxr69FL47F1cfQW/l2Oue0Fte3SfzELR6MLM+9XCToQnXIPove2+Ct9BmLP6v7PoR6O"
    "Tt1PZ+6ncLY+en94eOXWaApa01WQJKfut1P3Gxq2nskhsTQ70KmCSLZEQfaxenpGby4eyq34n1Z5MR5H69FotjxeWpFUcmUc"
    "CGxRzlL8p6zQ0V2s0Ajzw5OkMl2E7aU8+ohT8iZ/J252F0Ag5lVnBhAzYGqLrVmYXXzbLarZbgFYHL2he/J9qVbsMqIXjich"
    "7biYD8w2y+aCrnRYyX69QZvngwjgP8nZk6ZTjqswuSXp1Wcx1dIpRS1G+YOMdksDskf8dQPT0tfePeIv1o320I9R5tLhIiDx"
    "dUL6KM9aY7DLOkq16LNJp5Nemj1dHGj2ww/tYVhodbdo36q9TDmA5OhLH7vb/Fjo69DXEHV0mupWbZVgQ0R52SeJEyhLSWJc"
    "HV+fU1lPX7fb0vbrqzQ0z/ujZNlq5yZsV2xfwnypb72hvj5NmVmr7eGQFgSu+CoLO4PjgFy6c9y3q1+qjXlDuiLLlrWadEPW"
    "JApO6tcbbSgx3OJlSPSqK4N5SoS0sWvsMYm8SGsrNtDp+nY9d6Jhr8Xpbvbrv23eoiUE8pdhYwTawsSiEHxN5Yk068B5/RcN"
    "Tf7ftxuZ77UP4RH9g9iayp+0XNk+NG3Th+gpTB52LbOUoOhxEXXQ0OiY0rpHzwiDB1mjENk0rhXGpaBzu15TcJnar+EGit7D"
    "5B9Q77jLiUUI3vpizj2qeB06iu8e24eu0YPpsO8pa7pMxZ7Rl5dctKNUR1tLX8UuPzMHyKndAoUA+KzSyDvcHgUAMchZyADl"
    "FmMyGlvRDzSQSYbKCISEvcRXLiXQnrGz0jfVESRn+ztqVR+UGiItsyYv0VCkNm07BoUb7AIKftgWRF9avJMEDImYMDqbGcnH"
    "oSqcH7LcxYCJA/Q5Rh8Cm5SJlyTtT/CVEiku8qoANEl0bcR6sQcIpYsb7sLdhw1GgAzjkj96DUa3azIvXFyv3rnnnGLds1nt"
    "LDGY8o62xP3u2lHZY9MRasO6yssO3whrbdR4VkZN27qo1eJ/x3pE13cLExKT9AN2JL/+e3Ykmhpw4D4j5eZNF8qbQoXftB5u"
    "qJwPVCCNyCoyUZix6itfGqhCwcP1lBFkPxjVQUcdvwnTHOHKAdnW5yTZ9LqFjKdwpW7K9Shlb4yS/TdCDnzOQG+3KYrRiKUk"
    "+ACMUsGeLAWYMrSxBFsLYo+NjXuHO2L82QuRCvdqaPfrZCMRAmcyNJqAN5B2AkxUrnWC0ZCum6gnDeNIZmpYOFV7UbUYKEU5"
    "KLrSEmsvM564NuV6eKj9+T2NRpv+mWAL9pAf1x1SbObI4DrqZbNr5OKvoqat/Xrq73xB0+WbNugSb5U2QYCNnd+QvuqGwxtL"
    "4xNPNdQj/VoD/iE9qK61ve4+oAydttJ39MqQA95OtQzwMKNENkMZDpLWC5i1+AOlY1ZYO5ZWq3pVxia71hv/eiteYM+W2LcL"
    "Jp1y92iLRZ23Kt8JZdSeB/VhD4fa5iTUhvm39btsiKJu3KxHzZu5LWy3UZN13TaCxFcN9fmdSUtLfG8SOTG4oWqWxmy32Txo"
    "OryS0xoYFXXL+3TCAbY7V9rekXRs8yp/4WnWyOxWc+LsPa/MfmQIFm8ot9uvgMcKLFqt3PWsT28H7KILFfBv31wEHgoCCA9w"
    "AfYQGvQfhyab4F8qFqFz0jB41Onh4d3j3zdnf59Mxvhzdnai9Lq5Vdb2goSHkdRgDB5d80X6+bR0w1lorU7uSi3F2+mze5P7"
    "A8S4FNyr4f/6n/8XkQWfffrpp0lSegpjXbFe+l5oeSIJgKjnxCcxHpx0bRcmbKCRK9cANyvc9tRh4jewZvFtbULHtrS5jLCT"
    "69h/YaQrGStu0xFhzYcfy3M2jIUby40ANLsPK08NNsO8J+I3qulOMu9mi92fuVuFoB/tIao7X4D8b8h/56O4Hzb/CTugsIX8"
    "rXmjaNbZ/474jbWyPbKU9q7vk5E5TPG+y1WWj+VZO6X2Cpe6MdXZ3NcA6Ee5kiCwEKXpOUTApnffGoZ0XXDcdMC19aAts08i"
    "7fgzMFT2snVlHS/chh8eImJmZTTxBki+pMEtYXyQl2FQaVuEEpYI3JBNtEy0EGJR11gfrJT0r0L9xUVIFvPRl2w9clPkoT1l"
    "JQ7uDU7BfAHZzN4kFhpHg9FMXDQa/vV7ccD/Y/zb4SgwMXHHHEtt/CAELauBcp0Ev4zXQsarFLqgv8a8S+MDoNnMDk7TxRs4"
    "/xdLzp3Oh9X5aRrce/AgOrD/3Jk8CIeIpZ4WtdjWDKlUU6aHygOgH8DejFWnJrP29y5AT7lOF3lzFaOi2cFZvgIQ9UG6Wl+k"
    "gfqWPAhnQ9Zyb2hyfZt4hT+KCJNquf2Kk8yPJlEjNuaH8r0uWVaMwL1F66qo+i4qOu6t8M054w6G4inS3irJWwTJad8sdpH7"
    "YPsFtbCRmBtS5SPsfXM6wBLlVXj9OtNy0HP3ELnKgnc01eU7J2bbuef59JbtboEO3JNQARm6qR+4MWQurX3YALtNb+FXHAFI"
    "kS+9Y0bsMl+QtFbnavBiKOH0QA7/1//5f1uZJhzV7cBmc7o+OHfUrjOZuq+gw9KusDcPuRcpUBwg+yYueStmTd0vTPX1nwcX"
    "ne2/lLgh/8C1LUvuFHBsOAT1ORn0HZ7JQnPCnbEOr8WNgcsNeVmIhRORD2XS8jtsD4MdBzZMaBfOYaKdMQVsBg9/4q73OZ/G"
    "FziNwzgbjY6mk3nf2nUVbSUtpwlRyH2NUvHMvf1HC/XDRd5DmKNdh73Zr8PJXLK4LWzTlO0ysexiorUmjtxKik8Gg6zNIfXr"
    "0KC8+fUWyptpb/AaH1155vAmbHsUlRwhTSEyH1cnCb3E0sVjOe/EJ0MMMJpl9XsX57TzFYSsiq8EWT/QZClhRKQUb8thNHSF"
    "7g62A/ea7UY4YgBsTSgTYI6VE2vLGYuXnxvNKfoi55BVKqfFEx5G9+ib/17DAnOoObx24B2HOqkCfh5Gn3gD+vT/Ye9NvNs2"
    "ksThf0XieDWACepIdmZ3QUEcn0kmduKJnZOksxAJkohBgAZAHRb5+9u/uvoCQdmZY/e9fV+eI3Y3+u7q6uqq6qrU+NBa5nab"
    "jp5Wa7eJdWipdEW1sepBhgb5KzFo+xxO4Uzz2tRW0cZD35hCIBGOoqTxvRASHEgJFaKgkkZF17JQxpYGUXuqgE2Sd7tbozyE"
    "Fy5txTJFK5Zpr+ffKHulsOJoOAANTMEvP1Cn0GTRNUo2yCIvyR6g9uDUCfDGBQQE3rhOT89m+Pc/ZhT5L4rEU/j757MJ61nQ"
    "34T+zvDvZ/9Jf/+L/k7pL33985/p73/QX/g6S2aQfzab/VePfibjk3nQBGHt79TqIMlGvkvmz25WyFws1uUk6XpinhJNQ/t0"
    "kGwwFHTm8Ec2AqKLGWCDBcmY3GG/QtWRRZFNyTFd2WKg98AurqDJMbzZMfCr/JB1gtvBjv5ZaNlVdK4cZXFN9see4d3FruZg"
    "EudAYNUH3m1S+weXkMAID/2WxQflOs8BcR4kpN/fMd1z7Dye7dvUQAwTqheXApYYIap1VY4tyk+vyyrWrMyyVvk769MlrSrL"
    "OkMXFT+k1TrOsluo85rSr2FRyRIzuxNgcadBH+gSEhCe4FRX2EguKYMbB2Wxn7b2EratlTomh8ORgB5E0V4GHrlwzsWoPKVC"
    "JMdEt181p6sQ2kzdbETCRLB2AzQ6XCkrxlqUBqA1S+dwg33JDtr1B9uoH83v01gNQVyddgJAZjsIe1ctP7pNSZXcFoh/Q8bf"
    "q+bkkGOPL6gozvBHaq9svmU9mNr2q4iJH3ZO0VfJ7q6b4C2D2/kGZuVN8VpRWw1QarpKVNtCZZc92snJcKi7+j+RIecvxJyz"
    "63Vyl64Tq7LG+9D9RVBQ4ZTBBPeQkjlu2Rx7l8ksksww2nBsLpHor3P1neAMMuw2C0TbMuZ1bMOEW6sQioqYFfPjIslfK0eC"
    "1O/rXG/P/byAjt28pWqh09uNqevPmoatXsa3JDjQFIOi31om0Sb7UHfsUWOhmUBlXv1ueoPuZIE5Q5YrSG2lMJBRFkGzbAOv"
    "3ql9nzhWN2OzZVvGVu863hUiWMMB+hp6Sn5TYZ8+ihkro78fTHyeZqQs7GAamqzHsEbvviNLDn/6/NT6wGD9Mi7nKayM/YWF"
    "mQhoBhqQI5clT6zvsLK4wtQdk++6KN/hDaBDTk5VylP0fmmSZhlCav56Fed0BAfPNWzG0yma3n6CvEGaJ/PJlkeYupBL+zRZ"
    "1QBC6Mlgz6GE21a5edcloprXRj48YzU37ulnf+Lq8VUCyrfUPJ2dfiqhsYxvvlQuOF8Q8Qalk3+3BtQi5G5BwvtAQ4meFGkE"
    "lArRqa3waybCqch4JUJ/LEio36BBqk5nqw998SKkoUrbsQMkjFZz75txNF6jstv3j9WijCsNq1vvQ+x/wuWKNAYWZACzQn/K"
    "ibmzRXcTVHYp1xNYyDBhx6q2h+bH7JlHs58cL7ANv/bQa779hK7tXiETLHe7+ExpmIz7+Ie8yPDN6jBCyS0loii44Y8oYX6p"
    "OCNKxqwrGZToV++S1bqCDjfASIQF6PQKMpi39M0V00rX0DkF5n5aTMJ9D1uLyTaA/fY1EUhhA+q0p9tjcXQ7rAcdvN3AIb/O"
    "SRW/M/bqmC1rsLrITk32a8DdGtHwXL88r40/pZLM5OPdGKcQA8c5OhKPEiM6wrc+E/TedcbCARjBt+x/N4xTc6WzKbvjuniX"
    "5IM61Kb9PWcZ2fqEeHh8jV30d0h7aaM6WMa3RNgDSU+jma2z447fP2xSlWrkeXSKVCU6gkNr90pHHy66w3zsn0dp34drYj9R"
    "A8uDU3yN7VnzpfwLB3cIX2FOToaRhoCTqFjF79cJGjpANj6Gg1WZFiUycClRxTYbmKxW3KVybG0Hx8fiyLjbxes47R5ECrTO"
    "bfO9b61131sWW60PrrMaEq0ELf+Om2qy4XUvPLR2n7T19BhgEMyswMPLHQGvm2r2UDULtIbynWSneax/jkSBDUy2S4uBuE0I"
    "2etTCAnozcny2ATXCBG8IwcAUcMrVhILhAOkequJqI9MuuspASYd7S6To4W6xbNCLT4zUuVhxrecOFygjUXVHdsZRMJ43Hae"
    "AW247aNqFp0nR0fPZeotizEotpXHmzF5iqVXnFo7Cr0x8GvD0ghc9dNpfmepnmx6+LBlcIrG6bvmYWAVZf3qvAQoq3w1BESh"
    "yivf7lT1T6OooDcyxhHRRO/WCfqc4B6jsfpTyFWYdcuV96cioIw4HpR/oSdoRMJvEP08qsPWo/JJrRecETyOj0pU9xdAy6l+"
    "QK5Rt7oVJAKdluDyEc0cGGPtRFi/K6nol8T6LI9LA0ZbnuFY+SefkVM4dp6Ls+XXUTn8bNzXtlkV4yyO8m56cUHSfC8eQKaH"
    "MZq3OfUvoFQaxUZt26OP3bPxOZrxoQofknVMtlmYR/BtKxbrYKMZobbglYOOH/b0C7bs/BSwPPQtE0JdP1DKemc8S+zYxXHd"
    "KKpdCiYQc2ivzmzk+SW/UtBhgFD1el7W1lMu73wqH5bUGJvrbl9GVQHnYT/Uw9OxVa65/owth+zlpmzSFcYQbK7UO4b1GLUh"
    "pSFxacOqljvItYDMfjrEnzHZxUVGpsSNBXPKpTaZmDiFJGPltKuMnHLRYTwe9zNdX+YrxzVMx/H7RshqxccD07id7IeYgOjf"
    "6R+n+NbOP4Wdnx7/Os+KyzhTPatUz/CpsXwbVuP+BOUmU7TEiyiKhdzfwxk8QYGXrxviqKV7iWqA2gld2OZtV8GTAqVb2W1e"
    "Ek1rlA7wK5iBKA53S7Jh3zsLE8Rk2oXiNuBL2RNyNH1vS65OrGr3l1Jccer2yD9Op7j8LSGfgep0HbhoIqSuEcoLS0bReDVg"
    "t9bQK1JqaemTNPuzNOtW6lahfWe3V5HkesZ+KjWS1BX47I2dtOugNsRbj0QRd099upo7FOAnAYnpgSoydWJdQWl3uetcFfA6"
    "KAYZtgGrBjxiSqKVqajNNe84X0y0cxm1eAwFZi0JGPrJuZthkDRKhMkFmhFH0WxKb4nJMrk15bzj8kjjtAcKIHgaTnenISg3"
    "m5TmouulA90ej7f3oPZyP8RDRziqKEptzrue9Cr37Bk0pXDdSde5pdBkpxDstx/kKr6bn13K7SwUvtlDN3M7H94UW7o3/Eg2"
    "c8O9JgMCtJpcRXb5YIJ2GH5pBW6ASDbHH6yjRPsYqIVpqjRNoo7SNEHnzFXzaX46z4sy6dGbO7ghd+BSS66Vdi+sjjwTedcV"
    "AY3rFxmS6ahkbxQRbRbjjyK+RB/R7JAiT9i3hTJhZ3wVtLtAaIAFvhe3inBPLI32oLLMuFrpft/pRqI8GtSi/sOtXUzJtBl0"
    "/sL9MJAx9dzkcE8959GUXTrKZz9Y6xzUnYsZ6bTMek6qv60tTd6JqLU73HCJkB1+VMnWFvnTAdTXMiFuC0GjAnqnFXrsBgAr"
    "WUenYWeZTqcZeemkXnofrRaINt/t6Jq17cmAOmMfIMHvCAWsA8QHk4C6EDYmJhCfFJPGjG5FEcLLolc5nKMx7ALNVD86eoxp"
    "mc1m5+yZxUU/Onpv53rB7xyCpikfvPnMY99JJ2U9/HDV+PD9KlzGJoWELaqSa7SibDQ9w8YjgzjeZdko0iqO0YAKuefWDypN"
    "V5+JbLF5R/tO3enwPoc2Ml4V1ZfhPt9ZZ/2aPKig0fmgjnq1IW6KBikvVubR/BMs5g+x+QanAdXpK78ecBUyfiOKbYD3+C+b"
    "91+bomCVcUDtgEvM88fHt6ZAbtnSdXzOot8MxAxcGA0RyfVyAF1kFcGcn+zQ0I36oSsRBBLkHFVXhAhhO6fb4CecxSn0qL5/"
    "AJYTSUOLtalADe4z8t3lltDXmKyi7ZqLVwxGlQelGZFtKxdGwMdTikcRZ9qGnCRFID3dbi3Y+GE/bKA1pP3wETfhg91S1rD4"
    "mTKSqs6uWN5LGX9LxaCIKsISIf8ATeHF0df6/pyirrwCKMeq/EHMEPXDfQtiLQTQKkO8mxw65xoBD2q8C+SQWhbQtC1rxgy7"
    "+6BTvEf51kLECpRithfFN5VfUFcntp+Q9RlHxcfzIs6ekDcn8j5Oc2KnotI1X2z4dZb4loAZK4FywOELHChHQzC6GN0QO5T6"
    "0dEzVNX9GftRSRfoTMuItA0qhHmjZ+5ev/IW35l4DbPT4RZmdRquZvFYgO1HoMAb7AJmJrXwBNgzOTmpXZBODXMCas1Mci60"
    "6CLU8lHVV17UDsklLnqEgtU9jCynYeWg283DXq+00J32WlWSxS/0lJP6gxYuZoGuvVJ/GxqPVUVbRvMZkHELE/3QzgCgiPWi"
    "C1Fk+cSe6Q45ZfRVZy32mpMt90nfP99aruqQTaR8tMB+Ckwkp1OvmM8z4rCSD2eni/L4DiihqMlipcybjee1pcs2a6T6g1cO"
    "lW09B7QV8nV+QIFvfmcBS6ChEt/Q+ESm0dotvFmJM+K9oos9Uqwo+tH7SriN28A8kdmt51Bs+O0+MzvUZ8ckZjMSKBMS+mUX"
    "vX2ZW+w74vaxYPWrfFaE7Q9hXTUDbY6VibDEooKIHksM8SQ3Tp0kr04fMUb3e07tl7EIagNW/VaFmErcW4aJPZvSDz9I3sAi"
    "M8OnpWKoy+R8ldcFXtF2p0hxHuDiZN/UmgwLfRiScRbhVzCj3VmqXfG174e7F+yBag03GMq3Vc2hsj/CviZ1rxKdwyemAlk/"
    "qQvJiGlLag0lpKf6ISx+o+07cAf9leNVXC0hHO5RvVXUYPidAh42kYbN6WYQmlADAwj8jxyqu1hsdzY2m5O3o2n3geA2MYqC"
    "VgQT1txJtn2NXtxd7ipTsx0JbEuR8vX9BRhmI+S0yjW2zY3p0dEPAlC2DZHmbb6vIYf0N9Og5WofNMh56jJsy8o3opJTIKF0"
    "ujo1a/bSrdORr5kXXzKgwZTjGZ3CoUZftR/DbjdVcjNearLfxKpr+NxQY0DREOgESpamjXS3yXLFTBBeGQISS367m1tn/kUJ"
    "t9DR630Z/6YzSm8cyGpFUpN4skimhsXTV5K0e8b8tUIYCjmaDW/hNjeN7oar1OX7BMpW0GajzLN6Sa/JUvIvjv8kmuNtoAXH"
    "+EL1ef9qVNfxCoXljaubK1rrW8aTLYs6ovGqFKlwsozd+eYXzw8e68U1U9Vyrik1eH3E2NOX2PPWXAqGWVyKmVD7HRmfOnjR"
    "6TXMNylihHsGrB8Cs7pG3/gL/JZ4x5bOvHth5gsy9NEfoIYD4JbA0Qr9vcc6Ff+RsYq41vxYFYKDtuZA/uSi6limsqyz+Ikl"
    "RYcPjsQnCWP/MpmnVY1eQpEmjiztBOIytghx4NRBuU2U4J87kVSEQyTYMX2Yj6N0a9X8BWVorZ8fH7hdoC8F16VlJHSFuUNB"
    "CNxSr6C5Ak2xoFoOIeNf4qiD+PaA7Q8dsBLAAZrgOYApYhvlB5YGTocNsnr48EoT83+LUfX5eWGgxrcjzZn4Wwz79nvvlziA"
    "EN13P1iPNIZ/i8ct595Bm210AITs1txm4HCl92ZIunh2D7BOY+EUVvA5zBM0apS6q+hO6YGHP8dBQ0s8/B4uwZCfn2ugtM3p"
    "IX+hdyAkIkSWK2CQDmE3r/k1AvB5b/fd7rfVylcvnzUc6vyWoOJR3eiKx43t2py7I92YsFUxpHqXrt4UbKQQRdlOsx7pxJ8A"
    "4KNeHFdvZXmGV/Nq19+Ps4qNjgJ+2lfMWShdDKkmxKmP0BjPzpsQJBwH72FPhXdbX799pt/gsD5WCnPEWBbtN3pVpj5EJt3H"
    "Aivz4gDLOFHP+Rw5X31Fyx5rhTpFwaE5iwStc5hPUUkQoehL1zCu0ciD3QEZlcPh48tiemuezrGZBh5xhlXwEyB2/ZayqR3Y"
    "l0j9krUpDAeolbLEhz05jTZL4qvkNSW9TOpFMX2UoTFF8zQGC+Hzl2MuR95kmC+hkpznbvjUUKWnOminxlvbQAe6+8zTavGV"
    "Y5MOH0kdV9CzCDluKH/fWX5b6RkFl6057PS0+ib+JsjpUbuxVe/4mqOm3BOIlYyZxpUDAPn+emJvWyd237wCNlDdM1pGXF6m"
    "h64jVjxCW3Lb3S7gq96OsLY+xF6L7WpnlK5NucA1Ar41HKyDzNUeS1AKEN2imXrYrEv8vV4kSUZatK/SmySrohdoTgA2dfQc"
    "rzXGSHf0PCH7Aeu8FpbUDwFbn5bozxBNqx+FfRSlmP1VXFXRF1hPOs/jLLrERKwu+gW7zc9r8KHp01QTR3CfReSXRQ/QDTNe"
    "vgrKu0TXw1GMYUS2VfQYK1umS8KVVfRbQidsVWRXjMh/wATRoYi+TqScRlZV9D2mMTuS8nzBI1zdkpZA9GsSJJZ6YfQTxrU6"
    "SfSAc5M4AvoVB0pHMnpQcBjtJERJTPMCRdJZmpRfJ7fR3/B7VhTv1iuM/oLRHJ8C4GMb1seMfsZEvvHB3yReRj9je69hapmy"
    "f0nmwKMPmM+KPypkhllOGr3BePKraxA0ek0j/7WqixUe3vGcLh/RC5McvUnYdxNpdUevgkRbD4g+4EQv+cMbM9Qq+rpgvWDA"
    "8ldAU5Hg9E/Hf/7T8WenHUjcuhrDu9oMN2SV6Oho5wss3DpLBolXJu/XKQB95/j4BP5l6eXJBBZjSVysDvIU9I7UhfmcOjri"
    "3+N4OR1w0Bu2VzMmTQrPsMf8rXO/6KzxXTcKjeqOmI27QyT/OslmT7KiQi2gOyI48C4Zs7nKyxL/ToqMf1iKBUH0PkGBWYlm"
    "NSCwoJzpck4/SMhgACZ5Dmc+hPBxAP4uk5pawFeWSwzwIz2yjVnGE8pzzc0C7lsDNYi5tlAzal+mdXZLnZ2Gd9Mp14t/4QKB"
    "1gxWEsY7KbaBf0r+S92p8fCiAJWtZ0XB6Qtun1qSp95flPHlJU3KVDc2rSkH/LgJ0Ik76shWtX5nemH1bWsid04yxAFqScQI"
    "JWDzppOM5iSu0imvRFZM3r1fFzXFpmnJP1f0Q8szwysMOm7DMAwsKTlU0jQvzujvZ/T3c/r77/T3T/T3z/SXXpVQSM/mQi8F"
    "/uYxNcjwQN9hj9Iqis4oTiORqBBYZzQ2WIA7axG2+OMm8LLcmdWRddniOt3JWi04gT7prFtMb+QgpaPWykpIpjWGJSy+KUR3"
    "NrzjMWwDeuTyfU6zTFVSwsu0wjcptANgWzwHSouH0bJ/2uC0BaIa7e+0fNZo2Y2/iedkzAaSTYfO8JmCTYXfLG0i3FU1ifJj"
    "8746wDcO5BhjUS8zUkCsQyMaWeNlauJXw/U4msAf90PKH1L6YDmeQMLYfqJuubOgawA+0CwDNiu6VS7oc2JaKEHWOeppDAC1"
    "x3C/O+z4Kjik4JLot86Tp4/ePMKU0oNYXBdLuCGMxxeIVUkxU+fs9VQuxGP0ThzSRjefo4KXyfb02ydvfn71jJ7HHJ766G4Q"
    "Wv0RaLPEOxmOrkfHv4564xN8XbLyznzTDPVt0LmnhDV0aAgRIXRhcIEvkSnihx5Su1TRCb5UniAEwWp3wg7cVXMM2ZXMgk4d"
    "zw8uEW0inzDsHNGUeVLHH8yc3aig6lbcmz3qPR9NoV94w6BM/Y4fun3/yGcY2qgXNvJAv2kZwk5C51Lozsfbo3OcC36PY7kj"
    "McxmZCgYYEDloYsOGfyCSSF9FGnromOZ+dKTMkUzI1Rg0AESiWevgj2qJ9OdNWog6hjf5+i/Bc7rOJNXQ5ThnDLcOe2IxbPo"
    "EteEt2REITZLQmX5lmKKeZak9iAexN3OAXZGZqpjwiLHg0n+46hj7Jqh5TndBQ/o1aB5fSUh4SFMUZHB7DGbmacyikpnBLO+"
    "LVdXarpbNMBRfZXbxsT5OlEJXQeDA+I5IjecQEJ7NmBTH8ipJm+nk7fDt6OKPYVE5xejzuiP44c7SaMTBAkS4nYsoFg4OpXm"
    "YoZKCjzMUg0TL+GltImWUXJrodQwZRq2+s5mWlq1uuBx3taIzMLLxa2J50uzjKd8rZ+iG4ZKu/jU1EwO1qgBOlf+dxK+JDa7"
    "21Zfb7e+rVo/QiHWmOY2g4VV2l4U10n5BI4MzzHoI3qk2qRglChzN2LyRAE3vtfjJD49okQCyTQwzk+/ndFdqQw8ZIPpY66N"
    "AakbIm+iHIRLBRfQptRUArmtsYz2GJ8EWIGnw6b/NByrzK3ZI4Rq+n3jyIEKKBPuCE5WNTIDwaG2sKjO8uao5nDUwcB2Mw7x"
    "y3g3O0CrthuPCgCms5faVgsvsDoCSMBZGkRTm414A2eAxnOY7zq8NBXeNCqk/WZqEwQ2WZclMR2COEKE1Ale+2F13EKAwJVH"
    "MCxVwtk1Yg1eS3OADuATozXooenPteoPbgnVGfOUTnfEPJHQi102l+YQjUoCXDaor5blaZZEH1JXqPVxX/WkMXoImzWqGMtg"
    "9Wgb0VOT9I6HaTB48ESjmr9n9t61zd4Ta/beNVZTKjuUyqQEdotGd2kVfeIWPbCyowAbsYrO+7p1kUzBWJ0TneAF4TYzKHxY"
    "Zx+81upqgMMHixqUzUKraS/d8zTYqXCzqY4bVPjumudAlNzSuRF6/GsWmyzGLNmGElrFUgjNhynb7szPazMxL5rzzzQDLubL"
    "0HOXfLMxS+LTxmBjsLqyl43K9JuZZPAm1NOOEO7cFGilJS9uU2vhWxp5c18jKv9WOzlCKoBslwEBcGc4Si0yvDt1IoXTgGii"
    "8DJQ8xgmqMMg6xmyJFOWlGOyDqwPoSDAUhA4Rl6EHAD4rAMVl1w5gjDhD/VuJePAhRjj1CuqTyv2V01MVSAkSU/cM0+akGwr"
    "DPVW7qHevHKzQYOU+jZxiM+yYQF4iEIbyq9XbDYlKe6gGTg4WmSVoigelEADCv0XQ5/KrUxdaBMiRi9Tm6JjjX/VNZdms+hi"
    "tX0iMxGDJi3XPQvN1y5RvGSORp/Emp2LrFG34cNohg8ZTXSqZ3KQayrQG1UP/ROffEeSDkR4KtUIElaGfw8Jw6IDcBSswybn"
    "HkC7NUQGZkBdXVZq7H4WWl+zh15bPc9jlBpuNmdEh+FuSuc53SGPjk7OD0dDCo+GQnCXGixOxdQprPHJ23NvdAKkOFyAfg1H"
    "x70xDI0M+npM3hVHR8XwjF+v9VMmMVJzkhTDz8aQBvdtpE6E3EP4/ZTjKzXHljYLxhVt9cs50zBfP9poEVMPP/KL4XiLd5uj"
    "vu60xPUjhGD06OgwtSk/uHSosSkVk0Eq4NXFl5JmQ9NLcWUni6T24cn5CC491eg6HHcvHpww3+sJ7zHGGh24s08O4TrvfHuW"
    "T0N1nw+U6SPWTqkMY6ODIbhoEXPEPPnbmwXlknpXuW9dZYdHL4n05MhrfxtAuSdMuQDUtUs7ZeoHd/iiMNTxgA42l4Ij1z1b"
    "UVQzVYuJnD0GEIbjwKJe+2W/jNhzkF+zBF4fsL7RM0Fee0lXgy2ppe3IX2lCaFqan1F2nE5oshu5tKCjCVpcJU013QN2WqNP"
    "Ac+QLJesEDLf/P+TXHmXgfdbfBVXkzJdOc54rBd/5H/E4uPFaHcV4RD3A2+wIIO036oiz+BkluBmA4duRKgW4ADpzdcTWJUA"
    "baPiMLnNYApRpVYNWBNgY7NBns+D0U18xmb5ZuOTYGYLOy3f7IkR++MGSwISHpJ7bCJn+Kk1HOmeSjqI8bGQnXCJVgvshEkH"
    "7aZZCVPywgIJrOJG5FUciSdu5gZKuxRR9AVgZFiUTjqD7NfImApRdxVOpTpALBqWwbSAP3V5C39hRfCNCIS4cJgGhA/hF3dY"
    "mq8TCAIZiVXCT0e9GQlzsggBP2TjA36nyeUan+9gThWG7DATmAI/ECHtFhOFikxEzS+maOCEInjKYhoFMF9BFc5oPioYGX/m"
    "EBWAQVL+KqHusmNy6hWbrkNrEGERMNhDIEUPT/mEI/hSMIwD8v4Hv8QAjYN1ztA7hfA38Tfw96scBev1LQTxIo/14y92AMVw"
    "1AMyvwSdXK94Wmid/OCWtLfygPcxfuAQdmypkjiEiIbEoRXkj6/jFGjJ7Rbur4voZNgd9R4e/Vt0fnE42Py/t38BgF1FJ2//"
    "4glu3KTTDSkvbLI4n6/jebLBIW9EapiUmyyt6k2V1BvBjxtS2NjgGba5Kibx5WZexquF3znp26wX534FMIz3HKBdXa6LZng6"
    "7M4/dv7I7yT/aDOWXL5fHrQ82NdvgDNAe3+h02OVJO88Ys8yJbZqY5kugzlgG0ISPbU9FUtaHh0o3pfqJ1LWOVC8+HoXz/tD"
    "oAY6oxF2WB/66FPGasTHVtRdRQUQjzfpa7xEHnfIS4RhI46mw9H01/FDbxAOk2djXNfxgJK6/uBEj2qu3z8HKtBaISDrjl2o"
    "WqFavhk1FAFcNxyN77Yjb+QH/REQeooNm1slc18zkPM2zjTUHV10Ags/Uf7T5vhgXDcwnEe953FvBoPaFMPT3n9g4HJ4eoaj"
    "zD9hmCej6U4fLVasmsF8A39GxxwHQrZtTnFWg73TeWKDpoz6YcdlT18FV8IOtmQanqPrhQ0YaYwKQYm/EiwEZ1CglcSBc+IQ"
    "zc0AvAts1gY2haknPIsTfgx1qLrb7ww7ZF8P7rUhrEFnLFb+cvLTABWXCpZrQCMJq+MLFF563nCeLm/X1dj3Bocq/HD0me93"
    "R5c8ZWUyB2Slgbz3WYdZ4jQJUYfyaHiwQIN1+Jnn5fM8//ceFHAb3JrN8gcGps6hteX9NtU6bFjETgbOVXFLSjO1Ae0K/bFd"
    "kinMlVBvUvC8saeQJgdirtNrpPcuUIfs8GT0Wr13kvuntpkiGiv+/m63QAm5lG9AO3PW2bLODZCkiAkvyGi5xInCIQUntRoD"
    "mDfiHkLkkB+Gq0/hyfD84iFsi83RwGx+ovcxS+4Hqj2VABf4zsDBBYBnBnP6CT9l2XFQUz2oO2dR5L2ClV1QGz1uwxsyqroi"
    "0M+O1VJ9VT2DjQst4cv9VOvUzYbpuK/XuKBZQfU4pJXwcRs92a9u84mSuFkX+c3oZPTQG759ON7A7+AQ7sL+w8HoIfw+RJzp"
    "ja7hmIW9ZAER1xVo6g/baAUxE0x9x0K/y7jnrV+ac9Psddi9uSPnWmoLP4Ci4LvVcAtU7RcWOOim3EE3+HCT9iscip0H3BGB"
    "gTtAAHu6hMUY2dj9er+Oq9RGIA6MNEQEWPMsrh/B7eL6ET2RsaLsN0Y4WXrfadtGeDapzddnK0nnp+yydK14tSfhqMJTY3Td"
    "hb/nw7cX44cXGzwc/cFmdDd8uwX8t/Uh0wNhgzT2tzSAzMh+TuwvVj+4MS6PUvJZgHoOUdk768dosrzXi5WJH12hvHaMgWCM"
    "Ot7wbjv2O3o0GTN1oOzRUXX+uThe9e+63dhwWU6jqNeDxA4MPsrINMHhqXpio3koUMnnWMmf/W431VYsZGNmvo+FdPLJsPPH"
    "0cl/KwwBn9lEFQ2Am4wtwdLOYHpnPnUF4eBwd6w9OFvu4l6v2Uf0qeOMbkspTQCIfb5q3UR3SFuTFg8d5RhS241UeKhZUsuh"
    "A4x1atKK9bqI5oZQk1DE23i/KdJRbwIsWSHyX5WnaNK8VMJFNKpZGo/UUaokjLMiKuThV65EgcSvgxOxIQbhpZ4Y92F606J5"
    "FKDSsx/ishJGCG5bn+TFbOFPsTdhRY0lRcM9yfvQIHNP8DMC79WnVLYjbrHMvWD1E2rttXCOkgBDpDKZQhD9W8GMES/5NeSF"
    "mXjN2DlCVVJ1mDWZKjQ9eAZ7Jg9PGcI4IypPuUcZFMerYuX5YTV4Hz72SS4igvVCPzEuhoW2y4a825u+L8WMXE51d6ACoUHj"
    "hAbfkR3zgU4FhBYCbUVg+Zp8+9aJEgYgbHBY6uL0icgHLPGLQc1JpJ8sGLcHCeKQpNfzcf6Y7aVzoTFUW/iib2ov5B0ENWre"
    "QQT2cr5pnAtRvQcWEgNY2kWlruUbIz4RGEDcoFceL+KdYOL6pcHKiRNgEzS4USz/XFbwmPijCo1/i93WNfW1Dx9NXiKvwrSF"
    "m0xhmkMastlIfqOI/kDCtA/NzP3ymJ//YBRQFNdmklhMY+JWLVYmmxz4Vm96+WsPtZSh0pbVIsVBqVzXDOqQ/GujaT3ayqjn"
    "xeAlmbmD+MnXmblsYLpGnwO6MhjJkeniI+uN7Gp9CQehiERXZXqFRrJVrKjJ0ITE48uK7XVyFG+lBRoph6ip+2mLygZjTeyU"
    "wqw0JUBW6GIfLIO7BKFSCOEW7jo4dz/K3DOfRkbb0RtB7Cj7Zhu+gr3zWrmVtySqT71GaqDiGjDIEPtOavSj6fCzf6Ty07bK"
    "3TV6btVv8jTqZhBpdqOZieUiquIv7bfTjVevpSpLLvjU4SiWEmNc+NK5rPi5laCza0uYxt0L5UCxTMdHqp0Ko4yGDgAtvIHq"
    "UlONLkfzeu3l+hgySiUJ26fRWVFj00jqIREFxBaYfaWf9yrEZg4jlhd51MPEGSbdqixRbXPEvjn2Irc+C5N/16LHdVBb2qcl"
    "iefhzOv0ZYdthWL35Re5AeUATpfwJRoSN3U/trXRBAtjXV8SSiZ0XQPIJcF3pAYZfOWHFmdb50V9bPj6dfDYyXG5k8P9zoo6"
    "enE0QwKJbtxINCgqTkDkB1/Y/dC8Zm6Ev0D6nWl1C1mfBVUSfBU8V9PDM5XOWEOlgzAHQb1jnANIb4jJ0AQN6RBFX9l5FAkR"
    "7MxJ8ChpiF6wG68STCvKnVl6FjxNoNhzGiYzk2ld17ANUjThP4snZA5nYJ2t+hZqagpM4UESwkJ+BzOBHbEomWSAtU4TyFne"
    "V+djKLdGKGdRE+YEwEqA6pYgwjsGfZ6S5oqOrnlJ22rX1cAs/IKTouqC+HOCPUsSslDAKKAhc/aCkuFSGsi606p/xb3u4MlQ"
    "rT5t1vzgPcEpl7TOrvumxobSGocgYondLWL3MjDSCwFTBlQSYXDR91ggJMBWYgwN75zM8pFmQ6+C3wjysDqRMugs0s8fEgIw"
    "ETg0v37PXxXDBD8+hvhfZF1gjvzwhZX/vdmbBr/8JlYk6GKqNTigGVotv2Pf+987mrHfe2IKzGT4oS2DrT35tUWeeKQ09kIh"
    "EF9hD7/Rw+8tVTC1la2LZqRhuTK+IOHwGvwt/KXfMrBXgTQWJzhIbg7bjVAlPofl6Au9qzegKvwCCjMU67xbOQgHD8Jf1el0"
    "s2teD5YjbUMvQfqP4Q/ouiAMI6sUis6CinLwQ/ge8ngGhNzZpm7oHSw6dCybcGsYmhrGUPDnRMoyRs8SL4cZ3YppOfzALKWI"
    "FvonSkFRJVdy3/N2c+QdCzgDgkzCv7qoEa4da/h0nQQJLgCCe0I93W5RiQYAy4KjLxxlCEF8w/5oO/JH42B84hMsvvDeW2V+"
    "dU7fQDr+hR8+2AX+B667rVM80H8NHwQpB9+HP6gnJtGFAoCAwJRQgD39g5NRd9Td9HrC20Gl5bWw2nEucsZ85zwFO8jcG749"
    "vxhvzunn4YX/8ALRu6dO7C9JVITwD5iagl+hjiJxkGsLoeFyMdy6q5jTQY2bVyAK1v0H3EhwmsX4Bh8zHCvISSjaABwCvbFq"
    "mbB4dQ+4L8h2WKhEHEQXaHpAONCRKWl43Hpq0PHw9ytPx1dF1XMRByq542j9kPwpnMqPWd+fHFjgKVEYrPPgjtjhzHlUptJ6"
    "n+F0/4Sz+EXwswUqPyuku7XRixmAYcCqUVoiGKzRVPWLBdWXenyqHJy6nmzOx6EN2H/79GI/WMX+qm/AHZgzNBNkeE8HrUv3"
    "q1U6SX538QdW8dpS7wD4ZID6ik+5X9vOtjJR89yGzU17WsAUOAgjT5wVNxjVay+aJ03KDdCoGgufU7fZntIdmQxSXq5lI6ZA"
    "pnhrQ8DuP/WIvd1G1CETnaUikKWlHntDdEujKIl7oUBtP8vwmOOyxB5HNjAjCWWY3c6BPTcFzU2DicsrCJ8QAzwCLLdn+/PE"
    "DjW9NUkU+iiIkLNPqh847eE92ISrCwWfYXbe6iyuMOuf2vCml/VQl9oDBq8Sm2Yq2oD2B30Yv6A7RhPVxIl2smMsXhBrG/l8"
    "g1LLHlL/oncW0sGUKr3LxkVJHTqEmqMolouTF+OSR/yz2Zz6XcJ/7nMnc30FwEQPKHJEotGuXHOgUvpcMMz67JRHi3pgT0IX"
    "B1gmRJIYLR/vPq1KG22lqrIXxMO17sNZsut/6PN+ft5kxZIXmDYebD7W3Dk8jrCqgOfbRR6VvXBbfS994T2Ge4CVb2KQ2pqR"
    "TegSnAtxSDGwkd1Lb+K8ullbteAdLpT9lpIWoO/UZkpNFYLDEzR0kVvbBa87qrppNbpUlMD7YJbAdQ1Xxql3ZiHqtPookrYf"
    "z7k4EzIVM+v6qSMAhGy+z+U27tuyVmGg7xZtiBb3ULMGuqVC8RsqsJH2jgS9Lgh5aIRG9oosVEcqYbzsN8kuCSPk0xg2X0CE"
    "DGVqsDbmifqgaG8odim3jlXCn87NJ0WQUddsquuK8zYRxUqfcExT7oGTedJK+zLpi5QvcVwCGbhiwswTBPdlAqOwH+4lTY7U"
    "33HcvfSWtCQDWZJ9ZwzlCzXeXNjr8J11rPvBWp8Jy8TCrs8SirfT+0LoOQB8lfydZN6VbKPg1p6t2+QfI/Wu7Mou9099O0tn"
    "OAhZJwJmVVH3lzsT6pyfl7ToDvTcuM2eS0Vt1wiCZ7XPjmU9nf021C2r9aIyokqpsMNyxTaI7r8U+NalhesLZe8098m1hdDO"
    "XTy8ZxiWqDexBHWY6Yn99YlVc+TW7Ezia3cSNT+tfWy/4NheeC8SpHW+SYJv7apeOFUd3E87vdjBlQPvG/SaAVDfXPsXZoHg"
    "mH1D2M2+3L+ky/3u7L7cA5fkJ7KVKhVOYwOE21CFH7T0cSu726EKBZwECl4KvUGRFziJqA0nI//GIdHeOAvMeS2J6f4Ftm9G"
    "3+qNHriI+LVd2SOrMocHj88ymc/tgqZwiekbM+cteVzjfoI6yLIbnia77J4PxC5srt2HBpErZV4nwY9JE3Beej8SdvjRHtKP"
    "bi/8jivrkEJCyMDellO8HVrfY6vEhAmcRl65jdxH3b/aD/D8ydPMlzZG4JT4+hZ/xcF07zSKaCPbn316L5/t7+WzT+vlJ/Tx"
    "WUsfn+8QaOoqhjSU059dOuo5de2eJnfb+9Jt7y/MssKV/jJp7u0vP3oT/DIRpj8JirkUYUgbW1pw89X+E3PwHX8LH/OvJc6z"
    "Nmkb40DW6bHd0OOPnZFmVR5/7LxjXl8g4i/3m4Mk1cRgb9aDRRK+x8p3qdDfWnf+b3vYGw04wNsIEiakSYCd3eFUUH9x0doF"
    "S90/DHbf7+wTNL30fvsHuCgAVknAFeynKDlLOz9Bfbtv6/6mYNCiMamQku0qNvFv5qgifGgEM7+1bMz3FtQduufA+/YbpEre"
    "uW/iHui3nld9RxXAkWf39QlYNoQQJbEMBs+S8JUN8j98Orb7SUsEHSHZ/lPA5L4zl6OvmfwITG14G7elS02IvqcN5/awg4tf"
    "eD8EX7cs0vf2aelAlXXneK/Z3y88kkl8kQS/JtBtWxjhdlWTWF8IidUkjQjn8BzvRQEPHKrm130ECfXGlltYgBd//LL/hV32"
    "J6ss2qr9aGmbB/2zPZlji8MSkzxh7Mgef3GItHukylD4bwIoXznk0t/uJfP+mjReT1l609ESn197g1AJFjZVMdso+m14OZmO"
    "NygQ3uTJ9YZFuRuB8g0fcJvhaIhveoJ+ON5EF75yU2Ap0APiUBd+kwrtju5YxXnfEwaUZKBVgFPfcNZekX7MM6Ul81wFvlKB"
    "TzWssAxUT+CqUKBq4CQcjgPBGyFr73hoa8HvFcFp0CHtrw7pWGnVprC0FKSU3QUr7eiItatIaEh/sLhjycHS/LF1+nZe2bqf"
    "XfU++9t9Bh1sIw4f13itmxqv6KV7r/GHgFXn7ddnh9GVaOy3mYS4zxaEfj2A1tfK0AImSwRGb0s63S4EUEer18PAIEeCfDJN"
    "Jp3giac0p8kzza4ViFx0Hc12uNps7Ojt/YYalq4xgxTtAKLjK1E0P0Wl+tooks28Q7oj4pVndGnelSl27wRtURgVn/6ElfYn"
    "DLxr+jqckHmBdRR95VcR6ypqvfn1YfQINhb8PBcXX6R8rPXgKnmswxhGxREe6DDPYNFTbsXpyNgnl2XRr8S9fkBPj94Og9Fx"
    "hI9BQ6CBPOslX9/0KxbVuUoU0kw/8LPSUlPZ+QifSu5gFmVRNO0b+hY1wiBlYBTgu54tWzZAIpSKSRiw+rsybHEWnrL2E07C"
    "FPqFh1RmVWw+2q0VoRqA24k2j7WO0LvZMTthodClBhofn4UH+nGk/WVLQDuIN5uChiAaPIcRj2+zmQFGQbJmWqzhgOUn668p"
    "00B0/QfqvQD0m3yvh85QIKlwk+h4oDNAEL9vwe6gCD97WPg7Nife8gsXLHZw/HAQqrLhZnS3GW39VjsUFXv+7pw83LVEob49"
    "PHG/PVEPxlWGg4cHHXIoLBlMrVByhpY9O2gSCm1aoFWIx2weqgIaxx+O77Z//OOoM+r893+7xiwGJN8DctQ2IcAiPzKgkFGE"
    "ghW+sEa7swAQj9C0EEDTXxOye/FMf3B8mCOaUoY25Yc8x5KysGv9GX0bfiYqw2JVouEjwnLcFji9JUsDaBWwxTSEnc8u1Jo5"
    "mSw/KbNtw+JTG3DsXvT+nlJ/V+9wbZVljOYKk3GM+7v5jxRfxnk6g73U/Ydqyab3l2cDu63LaQxUtJY2nz/Wh99X0f9JcyOW"
    "hrRjPuYObRuf9stzZVqp3+2Wfj1MhuXYtSI5jvTbloN665ovmVRVq90SusUixuuX+pXq10zBV+iSJnLs4cuyY2W+PIANiiB2"
    "DZ+gkRMic74sincVGTpR7ioQIUK1ZOC4PF4m0zQ2SWuV9ByIvnUpqVOVSq4sTNfg0yxq6zN8WODznyKHgyGfwtH/qi3PCvLM"
    "AP/Lx1Sam0clOyhIyqcCckXJn5b0KStKp54rSL3a6dotpJJtuG9geybT4BLfBJhzJcDbRoRnbbVeEaw+gsNouSpy/HjN5mDq"
    "40U6X2TofOub/YPpN9/eae2DOkgar97UkwfbvkUGYKRgAcP6ITv1QT9HUq4siVtT7lpVHrFR5XceP5Vy3s6HxHCBu5jX+X+i"
    "14+ysNIYKsaH3+/4ooPUO7qpgMs+md4oxfRG6VgzeI1GFHcM3dLj+Xs7J0ck3FsWtMkPVQFHH+AhZzZq3qxpHLM1BGPWofRF"
    "nKcfF+O3XZvTx/8mzWvzDWvYKNQBvHdAD4Bm6148RMu7qmY9H+xErFesOsI/Ke0X4L3B8Ne492FMf097/9UbPzxJsTDemjNy"
    "FwHNmTC+og/7cOcejsZoS2O3wdISC7+FzveOx11vEI08H0cGBN26zLweECOz9MYfbKbFMk7zDasgAmmWqhu5AQB2rqOW7gXN"
    "hGLjHKD+TeK8Nccp1qume3fPolrqYsz08cN35tZMtU01RaxNMvyOVbKmW7X88GR/l5IWmZ41ZBRqmwgh6ZRNB4X7crmdGF13"
    "eydUpWM+Yocr9/rjdpTZSM0+Y8o58djwWTPLr/A1o2iMnqlH2o61GUESVHCzOeTXT4cR3RIt28m0LDjTuwZoGhY9Le0M7pk7"
    "uUO0V+0L37x2GwgddEECIrWlvE6bsU/zADpxzCrX1nPocsd+p6UP5j6Le0kvGh02R9cjo7U53JNiPzBmju33Wt84Kin2g7b7"
    "jCoHlnVkNFHnvs202HcfhqWTcyzfnaeSalzmRVu+2Zz104vTftrr+cZaa+n0QtEe3+7U+dQw0SzE4FIv/SK62rVKrczXL9s+"
    "6VfvZqPQw4MPyKpbNZypMzf2zmb6vsElUsw5Fg1sGc7dgRkJF5uUvDk6OvnLRJ3XGuX5jXpjc6Y/Nk2gvavesvjQ8weKLHqw"
    "twqHcDLliSDaKNph06xvw+eV/+CerjV6hKRQDwUbG6F+eiRP8ndrEKt2j8o57JMOkGlEvybTX6XOX8Xhtx6rB53bLKtNsblO"
    "Lt+ltQ89hZUjXzXVbhc7+htVkWjrWYaT0RyLrB2d6ri8RdS5XKcZ3O07mr1lrCUXbCOavjjCTBsXGyjpLOPbywTPGPZOQCKg"
    "VZHFjXyqO+73XVFUZ1Ul62lBld0qcVmjDvLTBeu9bdra5t3NTIxW+L7HcHdju6mDobmxcjjYCkcH20yAHy7as18PjMZWuK/s"
    "LeasncMRDZlUmwc+Y3BLXZrNeKutGXpFN1KGeZ1KHXv7KCqRIuEtkGYEEGS42KKAUGntA8zFSqYN3XwoM82qPSD2VRM7s+zo"
    "LKv14gFqxBe0lkxJ79eRmIsHgjvGOrdNMIBaHjeRE4zLQWKCr/3dR10NYDJ7hBSQTt7+wRsCxci+R8Z3nwf/vt3YCX92o/+5"
    "tcQzFnXvgt1TQMxmz/3OvcImDqylVgxcml+e1cetoO/oI+O0hpY9/f3Q3NxXPFX7ar+zHiknAzXvoej2cKueAxYy8+HuRAza"
    "ZyD0LPPiT0m4qXFBwIhjX+/MDhAE05gCjeU+7wTuuG3AdQ6cfU3ZFtCbx7IFGtQs7eNmex+O5bDQ7Uq8dc+0AbU6bBzg3tqa"
    "uq374665/Y6OuMJbjTg6NYLG343qPx0Bw+SIejeKovKilhDc8yVEAoDconMmLdjXsvkfrtu+G6Q6bfusK5/dX7gN8+9B++FV"
    "ez9bCTmnDx3H387OudekqO7HA2aH3ukdume98fhx9p45FPwm9Gpg/fV+dGGjhVbUEXzWthP2UlT3oiWFT3ZLd3zbZUHnLw59"
    "R2osip5z0ETnPtrOxhi7ue5fFc8iIOk69g29SXWR1V80Per0EC6jq3swjrvBkDlzz2ihrvmn1zVQ/rP2HSVtM78NNC37MVTa"
    "nHtDBGvwlRWuG6RGXO+ru/8xALRBfiC4OtRkNG8CRUj7TGijJNxCep9yEN857yf2NK2HHjp60kQf86/Pv/bG3KEftEXpPXoc"
    "tutr1OMg+BODVw2EoMCk4RaDLvbNvORUg32o3esPQ5r9qF6DxS7bbJ74jpuysk29g0Ts5fAMLc3ja0U0w10GljMMtkPHxs0+"
    "DCU09tKA1S6KXQUHh12sDPvkEVu00ioKqTaa45Bqh2K8nACOzXn6rHLhaeP3Qantz2xFHYMnVRVGdVarLqV9p5fb+tCy99TX"
    "gaeaVpSUVa5BRagvpNRwJ6XiuqWEyUpqDy/jegH3mhvvNFDz0YsBqaWRGa+kw5wZgTfJWlEZss2xQpske78Ie1d2felIrLdb"
    "peU47DDPljC82MZdlxn/FcZuZ4xrjUz2FPLT6/VOvC5j/IX60oyQ1AJIlUWSTckYbUqWO2H5f2Pno8jVm5RJgoGa0GV9hSr7"
    "y8uiqpIptACXQS9FC/HDznU6rReIUdO8p8PxjQ4vEhSDSAYTgRw6Mk2u0knSs2tqJkH2RpJEnep30kwxnRZXK2TKk0sLKdZM"
    "glKNJKmkpeyeL6bhxhcSQ0lZHYbcKky/PXpsaucyKSqvSSnyYrIoi2UiBdwEyO8kkExwLcuM2d0EyO4kVJMYf+ZlirBSlKni"
    "iZpZWaHr8LZJaXwwc+J+WBWEHXBt8tueiS2KK52qwgjjSVnJFFSTRUKDmt7m8TKdQJX5nCQS6TQpem7qOMgisXg67GTotnsS"
    "r8gac1HWJb40CdgTOy4CbG4MoBQWh41DQpfNVq+olxlplODWmZOKxxV1Ji7fwU8mAFeJ+A/LQhL0YwL9qPxgTfszneMSQ2W0"
    "CTmOzporHUNXXSqyJPw0/W1d1U4SmtHPuLOy5fPJAmaIZpOi6VItmw7DoLL41k1JS40DrFTxAOMkzgCV9NCnupMKXee8PaLf"
    "nG+oHeAkrKD5Hh1oTnKdLvFiosX4ASocJHGJfhMw8iFdrgkHoERjCqcW9oVhBlOQ9uxdpVV6mWYpoS9MRUfMtIAm0oP7VzxZ"
    "iOViKx1IGPgrY7PSJ1m6aqTItrWSYBTzRjnYNnPC2lbaqqhSGV1Lau9mT7o7HNirMDGN3ldAfFAKg0SvWqQzygIYg2U2ML5k"
    "qnhmOn9RvEP95l4WXyaZk5BcuQlqyXSC2L7AlHLKC0GB3mVRs9zWiZtpc1KzZIaIcpquq51vJe6mfR/5itBMVSeFpEKbWbyq"
    "EifF7oVeOCvaK9Z1ZY1MUs2026mkwryTSG7Zm6mNvuHI3Vizc5TWGCelNWpqzlApWMiONuvmxEblnNioHe2ZCQhJgluIaGor"
    "0mwJk1pXGT+0LzF+2W2l2TET1fCGp82kEGREEk9JrhbxtLhWkfSDDAhz9OKZ4BGKyZ1ZRdMcnciTUSBySt/TUaCgzQmeAaqi"
    "X0IW7sEOJwXgKj5jUBtTY0mJIlI1sXm8MpFybZfDmE006DQ1V3aamh1Jg1XMTcz9WFGInLZISNl159t4mgNluHTT4OijLTIp"
    "afkn64T/6tnEsJ5LuKdX1Gv7rJmm1YrPIqBw0zx2jzTC8STfiTOu1JyBbd9Il73xidvfU059bCso6NFJI7UhesWaXKmTMVmu"
    "6tveJMnQ4TVQDjX/tQ53jFlof5YR/YY/ONi0UhF7YihhlhG8UhiQvA5XC6Dd36nYdUngApkJNdFvr5jNeHGwjh69aJEwEAZI"
    "fSG7Rn56MyCXslsdY2UuoD9quKjMK5X+Lilz3jMUVQ5/ekgYlbwj6EMBm2TCE2hll+nUYbMinFTDXposTJShmSO3eb1IZKIw"
    "gfgNpvsShWUEKMjhiGpm7MHG3UlL4gqKVCntCecLQAOrszU/kCeIdNJMttdWpzOiaEzhtbqN8A4X6hp/eoBLYh1e10XP7EuT"
    "JgBhEgAodA4u4MZ6ST5tpJimVQqxXlSa9bk0jUHQrgqjbka3EqBjYVsTreDEaZTVTmpjqDpdRgeX1jkShiskDNdq3+mb3eJ2"
    "tUiodDqhL3KCO3cWdX7D5UkUWFSKdelhvcoeng8KJQDup21Evz15FGTHZFrsFDUVnMaVNqJOKUnSxSrFLwk6uEXS2a2FTFSK"
    "uiuouNwWhKLIAPCcc5sHJqchRfT8WTHoQ7JSSdCfyTurtIrD2XJ5u5OoqM1GKtyw6mTO2Suzr01Ek19WkrWhrFR+uw33yZKJ"
    "ag4YUlPiMgMSKzVLgKJMqCDtWvHv+3WSOIhXpWWFykpRurKoQ1slwhWf6Gkdl9Et4+qdujRwGGUgMCb9UQ2aInLhoLC+MlDM"
    "mgiKa/qTYoJSKawn56bnUPcOwwUjCtjMZ5v/4pZ1ODcQaZS1OT/pjXt7WsKp0KODJo+vekB35RJU7AsMy1JhUK0Thtc4b8wx"
    "7fF5KhFrOvT5xoEe33tNHAiLWu6NkrKKqacq1qwKkI3cbgrcNHR/VJeaolwBDkKIgWuB7GYJaVpMxU3HJEEBhYqrKcNjU/C5"
    "Cpq8KkHOdh2/sSPYxVU8lcudhMx+UAkyyyqqZlrFeUusGB7xp+eSxFaSpuWsNE0cU9qqgLsQ92tdJerXqgtjppqkJC4Z80+s"
    "mNkGq5SpAvrVfJ4VMmAspMhxhRI5JgiRNu50LUjfWnZ8nKMOCH3VtY6YXl2mS9LELZiiwKc36kqhR+Qk6oE5qXqGJHVWxnOh"
    "pPV5hFSZSpLthRxy+bFag4hpJZ0s8qSivsmiaiCmAA9UBTVTyJzeiMn1UUcRBC48b1XcmjCKyx2iAgIvYX4xXK+hS4v4KqV9"
    "ICkaSztxfYC2pMqR2PZFnYyNbwrQ3WR93rYltzbSOH/dj7J73EQ13W4q7yRJMxvTTWhOgZPsds/91OjeznZvpDenwU1vb6h9"
    "Ihp4pJHamAoXq0hilccrDWZ2mpxacDNfCSHQqxcA5IuCRBSSrvYPRw1kURQZNfKZ9w3gECJy6LdH1CYHF0nM6Jyj7NYt03GX"
    "usSjnRAO7Sa8ndA+E90JxvB1fKnOwpr0dADVQHcoKnwxDigOqIol1yZibTAU2OlpMpEevh5VKUBJXOIarVdq4inZsDx2U/QR"
    "1UwXAGkm49vFPck9vnbufJJji9KBeF/IrdaJu93Qqc3x6w9OpZoMoRjL5VRMKGAVdel+TtKnNkfNyUtx+1ZACZpTxDHntspJ"
    "Kz5/NGeRUoHWzSuxc0UJ6NG3pC3VHKWc67xL6mINoBYrCtSpRoXNiWiS9AxhSmqXTh02v51kOPpWqqUgYaXusuPpo9zr1nmK"
    "7+Z6l+kUPe3BuV72+OELymHwfRbyABQ0O2z5qwKFQZdxJgQax62ucYLmSnBUUQIc0xIfidUmojcrR6/wcslfJXC9AEqB1xBj"
    "6ZSvmYowu0YBx2QhDaDKg744UcRcqigqS3ldpnjVV/TvB03o4j1AEZ8UFoYeku3kj4JQhyOq0GINgNLCCBs4ZshTkjRhmypD"
    "ZbNeKWIyi3ytB4QOOSLSEkdbQN+aKlIWU8beL8K4JKGQaYyiMs7dmzdZUyl1QM4iiSxTK6JOolWcImNJyHFG/HaNsOTFu0QH"
    "etMY8pQlQb+VpGlzScOtOYlXbsJvBZ8unLJEwVYGO8EqZsYpCQpydrDJjiymjcs5z25XCxtt9eAmk35AZmzW+lntLn1KqLuP"
    "A4PjYBrV3toPZihvnExQXKhgoyGcVvIToUzs6I7IxiJTmkl78+4IavSHBjvfpXR2E9tb4E+tbfCnPa205G/k1ESUE98RINkk"
    "1U7a/tzNLlhfWvvRnBg7dU8rrVPjfNvXUlsJIzKg24orbG1Q+C2kfStN36Ta28j1djpd34PN3R89zO/cSJqEdxvF3U5q79DS"
    "rUT0/dQz0bmVTQ5fxmXv82kvc0Ry5lOMBu1b0hFjtCRPSTBLBEvL15nQKY1k/Uy55dveutA3kcEHVRKXk8UsTTKAcDzIYc7X"
    "cBXJG98cytT+AIf0Oqur9lLqo1vavQ58KODeMw4WgOVmfrCCnyFz2Y1QyZVuVOXEIlwUBdEmUdgnAmlIKTQ735JZjP1gTl1B"
    "qCBeRnW7vCxYOBTjTBIQ5sk8VnyPeCoaLinSC6pf9v1lPeNvpqrqtqqTJba2ZHWSSXLJsikYRvp+nRCRg9H361h+YBuJqsiH"
    "NYs3of/0m1bvqexlxr27RNJskUzjbFkwVsvk+zqBXZWxZLxkrt7lusxur4E0IZHoNKklM+ocwnwxHwh26KQQ0hGXlKWdZY4b"
    "OClVCUio0uwdyRTTZcUUyS1xHBDOJRsGrdQ5XBaTvKT2Kc7nPgdZm03CKvndIn6XShipk5ze5GKsyGBN7FKFWg6OTBapaqZM"
    "VKiiaVKRJLbLE7ls9ZviVg8lrrsGYPd+XaSVyq9ne5okqxVfvzBYvbtVtaZLVR+GuKZiOtezOkvL5LJMJywwxLlXsIF8pKpW"
    "3Z3BLaRKSQgF5FYFqB9pg/miqGpVYM73cnvGpW1pWNVFv7dJxresRZEnt9OEg7WMArVS4pxnEcNzbC29KkqsR61QFl8ROWUF"
    "YVTVguLXuWouS2ABYG1mMxEawLaU0VNYQRxHGHQorEei+8rJPCgJSxsS0R9kHBTWIMAxAwMc14vFUQsG7ARTNeztJLOLWN1b"
    "JvJjmsgTlhAoSIaNXrDQIJmm66Wz9zlJ6uaIBmuOrtblKjNfrcFIggXSkoK6pHM3lw3InMKgzAsOVH5uLRIQxfUELR5RGBBp"
    "WXDBYjKJq1RkB/FvhQJEiBGDPpuKKh5tXPU7LeNLYtvL3uUAt6wHu4qzxAZkissQMGwPAON291fxKr6NoTPEOk/iyWIFKJp5"
    "2GviVhNorODCSVev66nejXp2YVMmMDorPiXebHWrEGtZ3MYKCio4TrJEfdHgVsX5VOe3VgqC1SKhq1kFF4c8pkDGKowGHO2l"
    "tKHSBsgqJ8Bz19gG0DpmtgZfSBawfMyVKJYxCYDsidTo7HrBgiy1oPRbLfkWp6GdA9zoOLiCc3XpB7d44F0WtNzxJYlvKUiS"
    "A62Ipo5f/UWUdzA+I0UdVhpxmQExMglZwzKujFIl0nFEB1FktYgvk5r0ALTKAYWv41sqtISTjz9zqAf558lUnc5UOa12vFpd"
    "F3AIqNYBbiE3YkMqXS6TnPUTYrT5lVYktcTXY6TcTbNr6wXE5DpEfo0+AEdFwsMRFkVg9AZ5cHHepi15HZfTyrrFEsXALSHX"
    "x1b8uIRbLSHuyySfw/iIVuBNoG+VRFpje0xI8GUlm8qPpT1oa/TdsHKXq+OllLpYEpNlOizGXy6JNyqikct1BiDHIaE0OTDj"
    "SeeIpoh1ilEXoyjetNkv3IR+gBCb8toAYKVwVWdGMGqa9GiktIrsvK1jYE9CuraSNah4q+IdnRWnFsnkHQ9+kpYTVuz67R2S"
    "w+mSaSeIAb1cL7Lb3iVqyC4kEQAYzskM9WuTpaShVjTs7NWCwKqpqIZ28Xok5WIOT0+LoCwGp6vOdslOBDlCxIZWJLNU0BK8"
    "jvGX5SqesOoYsm4Z+CEMwD5HxT+lV9amf0ahyrp1yrzwJPZgi6wlmubrYq1ylsw0nxSrW6OyZkKcjfGh0l8D3Fup30WcsgYb"
    "bsjL5EMqCm301kxPxroU3e/J7SSjyUWaTYg/QMBEIeo1k1AP5p8ujB+Skh8ZsBlpHTJXIpor+q1gdMz9ifkuaSeleSOBpRBO"
    "Cg91mlzFeTwHpET04mwGpyIzYeHSNJEfVlrHEIAGXoMIRBppxYqHKa+PKVgTl00FnWjN5clOJQWutcKd3miJgbwkrtQPj05C"
    "MjKKSTBTaomwh1IGVg4RokmWlwm7/aW/cDwVK1ooFbRwczOpFy97tD13PsyTD23JddqjWW794FS0AIJiES+hibhRxPmyp8xy"
    "35dGv3R6sbcE3KX3fir2fdkZp/NlX5m5nW5U6ZJra9lvJkDdi17lDRxLU1488TFAoTLu2ViEU6zMMzhi44pu/4wCbBY14w64"
    "THPWTDQmjUImwwlrWQojZ1YUdV4orcJSnYqiUzlPimWCL8NelbC9pe+QWM5TeUEDRIFIyzEsmF+r/hVMyMzXv8XI6KBguVy/"
    "W6TyXEsU4NaZDuD44W7M/AogMISXRDpxcA7SNSvJVvTwZDqlbbrgYxpPOX5jYx13OixdW6QlYAgiGVWwl5bFghJszvSikr/0"
    "hWhB+GsUaZQ63jxnfQXARS6NphLM8dhIkR6lOVl54TpmhUOoYILOBoNLOUT6ulqlz+j2Cf2hNP20Ph9FBRAkJksksVqe+VoK"
    "gTyncHUpMTKhMPLmMYAEwYRskgJgJoCtUGJHPdIp2HOVpkWY72Ig1qcxher4HS+DCupleJckKyF83i2WNJfvYI7jvCcQoms2"
    "yb/Fe1KtftjPo7K4oL8la+fhb2krGLLCDAEOf6CQupCiHL9YzxcSjUsdsE98TKmUll/KBAuGeZtiSCUWLO/IinmqQusp/Vxz"
    "6/jbI9rcxAz9zAl4kXinY4vkJjaHM6ehxMvkB7i9TuZ2DbDnTWzCh1RG5DiQPGmOUl7mhWdwP8z4Phvn6WqtBWxkS4d/y/RG"
    "Bz5X9++YVQ01CcBpVZbylrGj9QIu8jqNxZvNnE6qXYBupkI84Q9OthW0O5CvZYMtgaImza+CHynilVSrBppdsEzlfSJcr3ny"
    "8CWiuuQsGeEtgdBJhc8gwV9RJPoryQsrk0zzeRvnS4Kh3BwWOXHKaay5RToARFknSl70XAIXEqZM70EIiRj7i9avlAeBudoY"
    "gP97MZt3ppgIffPKaolsEFYckrMtt3tyXVm9LOB6xDzXYsLY1FI7tHuF2vRLKPMCAFHLWlTia1FABax8G9NvsSxY11ArIQqa"
    "klCPmOgiK2EmOYUc+YajTXij5K/C+Zhrtb6pKO3xGjeU+VK4kvSIRU98kIoEFawEiDGDN8zDz1WR3c5ZN888zVyxpmCZKHUV"
    "DMr0kwpfeZX0Pp9arzGJyVItDAQjvgGy28I7GCqI5xJPe2TSRcIoQU2cCG7HlK8aOiOsWD7PjEofBTLFz9dAxAFSndrBfOZb"
    "S+/0t50rEn8iNVAJco94tc2Nq5xf8t+YlAP5gtauJJh8PtXBn3ToZx36hUJ82PKLAJRPGTVFiuh264w0BeVOAgF5MmJtlCqG"
    "bQPrls4oUq+VkhUH9ftjUTCE38+nKvSTCvysAr/Yr9Y1k0ZLrSzNNKOCY29ES+r0vyTVSrKZERpiRHTzkmXqULqUYBG6VbKK"
    "1dQlK2Lc61ldMM8uncZLZv0tV73JInUpESfVogKqVKC7ekfEJP78JL8076gJ5vLN6HxRv6WrwCBpltaCdRq1ZeUPTn4ezpJJ"
    "HvpVb3p0RE0nxpnNWcxqTRlXcBTRpMEBTuwpfp+pbtMSY80PDvP1UkWEc6qGS/pfsdoWHL1M6msBQ4onxIdhSR5qx3B979cx"
    "YTQOWHCiIIA9lHEAEKXAsBY8NlVdGEFX60v+y0/sXS5jdTWno5VFiSseibWFWarIjTYEjL11qrQbtZajmWuJM/NKIooJZEfx"
    "8Rop9XMiXqiIGrMTWTuzkcj4Roetr8uU1V+y9XwtejBKHUbzCVkpr1DKjPLCCoNqu9eLOGWmNV0D4Je6vgB0MiXpnFYEpCTh"
    "GHLEvkJxCotu3CImmgJ8MKc8nRME4G+a3woDwIpZLAmTWrsxO09hNAnhpNjd506qtc93FA1FPqvDhHd17Cc78rMd+UVFyCoL"
    "9hTQXOOezikW+tLKkSyT129w4kz40Wu5adGKr1cri76XmKHvOUHR9xxz6XtOU/Q9x2z6nlMUfU8xoe/X5XStDa5c0Xa0cJNW"
    "dRQQvEqTa9mUpB6TJSb0nDkREnuliSpJeK22NsTXVLm1Sa+ZHLqOr0RpkaDmOs0ZvDhABqh0THpERudJO0wUFeOVdWLf9NQV"
    "76anEOwNcTdvrE/q2zi4jGrv1g9u2JLwJEaDMCoU61ClQ2sdmunQUodufWMN/5otGCkTxmWQW5aujQl8Zen66KhzQjbp7xpm"
    "pMXMdR6Rl7lSLNMNtW0lY2VpvN11qALbpP5RZoxcMNy0+tGgT3eu7cU8MP4RwiJwPCOEWbDrEyGcBE1vCOE0uMcPQrgIXA8I"
    "4SrY9X0QzgPH60F4FTj+DsLLwHh7CO9gGsM2n0aHh2Lr/2GnYRD+OuC1QuNZ7PoDp6Pd4QhADs/V/8DcfGzUO3NnOXwID08d"
    "W0zkQOhTpulAZumkQ/blkTh6UzzLp54ftMIc2oVX0zpondVwaNxJBSY43gadsNNiHQ0XyvaGcEe2eY+OhtqiPhR90FLwwHUb"
    "MO7uMYU//Lgl/HG4JxN1+w/7uk0TcdfRnW0YDBs7AGb7aOpU94Fclvz/IPfPArm/dNohRy3doH3lQgsoPVQFg8N8o82dG+Pl"
    "bPh88xGj4xu2n46wQMT1BvkQ2pw6uihLGeZ/j4eHfwysfZibI2tu1NQMHede90AwAek+CJ7//vPlf+koafGHg4D9rzhhnOmb"
    "0+z96x1LBfb3m2WG/zdSjeOrE8cHmZ0H+i9emP4pjqoCuzfB/k4Edtu/y7uV+LISJ15Dsp027wQnnql9c4kmo3zYe7bvrzEg"
    "IX7YR74EEaA3lucwf3QCqTewu+EHi23QiZvPhR9s3vK6QODB/nqPT/ged0LMOfxiXK46RcYBaeVa3X8LE0E184RYXcUKR+gk"
    "hvpG5apFAlgLcvptRe7tBeUdb8WC493W0LmWpc48Unhp13dtOUzG2jcYmuGEOLkp+S6ZP7tZeZ3RqOp2ukkXAw8j/OP9cTNC"
    "DD98+8dRZ9z1JY6fOuRN0tdGSfMBO208fjjw2S1vcpNMvHz42dgfno3DTsf4Akmds8fqglcPOm+BJun43c75CTWj+nOBQjDb"
    "aUvRoO4PUjhEtC/UPKqH5Ri90MJPNByjFUt0lxYUUWo8pBboIbXo9fz8GC6H+KTGS4cFYGLXc9qiXmZLFvHqaS2DmCc2gymf"
    "JzXlLJXnOtpEWIx8OgL2ItkDns1v4jm71XweTwAhhvHxvk8tZV6h28943lpIvjE98DKtkOkG8W+wP/FxS+oWLRiSH7b46Cg+"
    "ruN5Faw5zNBO5wJaNC+8Oqj8YHJ0VHgTDK31PE+jtZnOKU7nFKazkhr0rCoQXw+nYwbQpJIITNDYurTNoK2CZzaGrmWMwjHx"
    "GOeTDPqiycOT0SX0WLsSnZDp9TW6lh2eX4wq40erdt1QxZFVEQ4apwIGtpvYMP/cYuk+9v3iOM1hPqO42zkwnkYk9egIOnRy"
    "0e4zgWcP0MRw9Bq21gHsHF82jRT3+6p2bRh4EXUuyDOtrunoyD0I9X5wHQaW3S43yduAvLulw1PYISnsTnHHCrOMab42SJzC"
    "7t1uvWo4hUzjYIqbOVg5AL/A5wmphxmCw1N8PaAiZ9h/Wr1oD83JmGpOtJM6rKNZULMDbFqMSCLYWmQ59GoanVbIT88L7Pf8"
    "mHnlnjGdnF70zgaJ8mCVK9BN/TBX9Nz56GTw4IQpv0Y+Q/XV2OfNRkVzHx04QV+WgdVfAd3EGRB6ki6sMa1UjIeLbsyV3Wpv"
    "FWRiMtiz4DPoACpE9MuuMhSoKajp2tABTSfislt/BkA1aHuyvcdctmstO5wFVAObw9YjsKJcnOK6t6EzIjKPjSp0jZaUoWl9"
    "Pllzgo7DyAC1lPKsKW5MbSA9FViS/tY8cqvLdg1Wz0un26bBDJoxyGePgW/dc73qrT7DLW9hh1Y30BkLnHIAfMbfnV58q3Uq"
    "b/df8gx2kzx7brgcuyHHbuVJSTPRYhq9kvGbwgjopgeIsdVn7nq2hf8CPvQcp61EtLReSLA6VO/RJ+v/TY+uybGIxWmvt4PB"
    "/VsPdaXdPVT7gVTqppd+gJlfFVV4SqEn65I3o2TnLxLRHyvyDP06AYDGePv+zJv9sXZjkB9jot0r8xXGqabAdI8LQGhvN3Uh"
    "zNTocdv+S1X/vOQQCDwzps2GDbOnuZfqVlOrdv9cJpGc1FslI6hVlYjsEgpHI1xTIIp0RqpDBhUZVJDKDJkKk+MVtG3XYBqg"
    "o2dlGjL9xVpLq1Y9s43+Sd1Yx8eGT+ep1T40MdBDCJlZruNHRzrfsRgOeYOdqTab/OioUZObw1SKlFLXbi+0IxpnKseJDoFj"
    "+1pUGeicrvhb064+HH92/NMQH9VGWK7eoqO1OH/3AsYRNq9UaVCY80pnI0cMVly6hxSCk6mISieTWku1IsUgDWVSYQUGKU1b"
    "ERZbctz+fwJVWv6uBSPKtML8AYX5Y4nmustnrJCt/dXB9BbH+CWfPlmk2dRTTK1jfPFVJyp/Z5pewUj840kGhx5S9OhIyXSm"
    "h2oyxfxgJ0UJfMNPyizyfvZeavxxALwTsH355uWLCEHc7nGJuzOeTp9gz7wC9eCpLlTUwrMwSM09t2TyImGHHYq0+6ao05kw"
    "QJ6gPhp6FLk/hyfo5p4skfEZ/gxVpFH72CP1safUQev+C8QV3tMKuGIXcIsE6PbwqRaT53RXiaNakoDE5Sn1gyw6PINrJ6ab"
    "O9/EYwcpO7NY+1P2rB3V2ldjJpeTPlR1CiMqlzyL8TELi79Bom5nQu2vx2WCOoO8FGjH/3gGEFTB/BTHejZ1EHJsyaXoOphG"
    "McKlAFj1+FZu0ugmbLWuOz5cnhRGmA68qVUvjQJ2vRqPpATkYrs4ZkM3JDz4Nv8WOg27TBI9n/v1FTaBqwyTPw2kRQcP6FwA"
    "MdJOMEG6Cj98ndx+vzLF3yW3KAZvFqdczeJWGX5mYZPtBU8VFHwK35wIbGpTD8CJ99l/4NUVqnlCZKOMndQpv82fIaf46Ojs"
    "cyuPTzOGb7sIeJNf0e4BEkATnBUnKxxNanKJzesHbvWPs3Upw49R7R4WpmhOIONa8nePWgjTN2RR6+gIWtsCSvTWe9dftG4Q"
    "APjmCBWu6UUU6oFYVB1UZeDtvk6u1Zu2iR+sVQEYuMXfb2zRJ0U+S1H3orlH792ZuGJmc35sfLB1Yf9OaP8G6+jM7OEpDA7I"
    "AK/6Z+3KiR70NoNpVbG+YnDMotP+7DxTDI5ud8bHxyLKhrNx37OBlGZ0sbseJX5KfkXnPNCLp/xaCrEzSr7Qz5GHG2DreylU"
    "KRthoRbGWtVebx1USf0mXSYAVJ71ZX0encJehrUOPjs91btpISDo1NLtrqGx/Qtso2t3lfUaT3iBi8Ba4hSptgb+hTR2FX6I"
    "BJuylDUwwfBPyec2gvbvMlhcQrn03E8NtfD/GYutvdyq/dlcqLp1oRgRIB+T6ClrBZBLSZvl/+Stkvj5SDABqgIavt9krBse"
    "4K4UIDmeZfG86lsuxw6jelCHgLT4YQ3yOwedlNnwkDrPiss4G3TmOkUznwedJSVuoX7oTRmksCnT81ptyrTb9XtnUZQTqX7z"
    "7czTnsNS4sbmxK3SKdrDGfq8TEJLMgCUCylOIo1viwAU8Y7Cgs1olG/w3+hH+P/pZjQcvRVuiipuFY610/cohZMKhmdwC9Lm"
    "OD7YRiV0L0AePxpNJFLd7xfnUdYvul34fIraQvgJmfA3UUxrUzGHlHLDBgF0yXzdipjUEyFg7vDBV5gD+Tfh6QGUU9jx7gTx"
    "nmI9EqcxnAD1r4eQWS5SDwuUxsj8qbH11diW1uDgyh8hDpchrt2xTc6jdd+A0BQ5+uewPw69ycXa708VH3lmjXECiUCO8b0l"
    "G8zCrNsZ5Z3ubFs9jD4L7AnC6RROtkxKRpOy4FpXUXZM3k+802Ahs3JcrbIUyPkRnj/zaIGTYictZSTdlZZEBFfRamiiY80F"
    "dyZ+GVzJlC+7c1MW4FXFBlfduVmDcD6c79SpFmaxtVemUiuj5VGyNSLNkXcBJ2W8rSYloUk5LHxSPZNDuxCwKEyXMFd8oers"
    "lZLfO8w3m/hCtl03t+AIN11UIHtcVXemkG++tRD+79scQHiY3XGBu6PXg++9M17Wibsh1lEFGLoO4vPTwWk4Ub2PWYazsz3W"
    "je0h8e56d3us7UVY79sek/u2RwwDOqNdoXrMw/X1JOOgp2oSZo3RTy+imbV/FrDqi/MMTgJMX6jds7KqR4FZP5bdEw9W4Yp3"
    "T7zNYPfQ2s9hwmLo8ppmaM51LIFaU3tl3rZXrqJ5c6/cRtPuUgYSXEbL4fJjm+Q2uJSJv+1eOZtExQaX3Strk1wNr/Zukrmz"
    "SabiAzenFVJAjDS9lFKngV4b2EPo1rJrOVvUsK9L9VmfMwW6WsuxZAel3eLi4gwWOMcTQeYOyA9rN2WoAarQaD+7KAdFFIdp"
    "FMM+2VpSygRpa5QBkySt0WMtrwOKGo7WEjBuhmqtvBQnoxKOqVE5OPH7SajGNoENKQi5QAibOXi5e9arVC8BRc/6gHMh56mi"
    "eS1k7MvI1iiqywCz4rBgvVR5LjKPVvpQrvDagrnwrJ77YvogOUj6RTQFWnUVzIPM764boDEJ7I8CJTqxWxmg4Ax8jV5GGjFX"
    "LiJbSceXPnQWu6R30RXcNK7OKyNpvoKNhIvl2YfQle8fQsGrsT0CLH7rnFWmGh+2QMbKx9XQJJN09FLDx42atyi68dtnYOnM"
    "gNUCfIcNpKuAbL6zBRb/M3BkIajeWdcAEuKkCWDqtcbULiT11xe9MzgxFtFCT8fa5zvGR2BLH233wtd+gPoIOGlg2lm4le7p"
    "0izckjuGcITzVEQTvZ26Hwet4lNBy2xSBVo2KF22wL0C9cZEWDUJCN22FN6dpuU+QFsJrhXViqqPl8PjuP52wrzASYIXQ05E"
    "M0bP0AnVS0TaOn1awDGO3oUHyTGaeoGbBzp3zmGmT33OggIHHkOJ/Sq3wc61qhhUCJdwx3iOrmk9iAFKJ97ELhe1Hnh8LOIF"
    "D1kP0o5okESWNo6WC3jlYBHOyGMyXH4ruAGGnnXOI8fjEMAQOmGuMZ9S6SSMpVJ/G35KgXWY6QL+9jUN7XhVFnWBozvmp8Dp"
    "h2QA3WtViNU5vM43z592Gv7It0H5acV4AlqzflKFcIVemX7D+sKx8Q16wt4RVh7QtOB3D5ZqG2DoVYmGztbV/blPJfeuRkCk"
    "YE/DXD1QsHZMoKZjdUHbrQ2Ij4524J3UCnIh7gIk6gC40DX9ZAEYEX/OTzEPfZeUyNO9aRCHmw1cg9WehgnH3HBC48/FJxWi"
    "pqAFdB9Nt5ku7O3TQ1R8WPJWC3ZmovSNqk7bfu4zzWQDq0d0755ZQrbQaWSaTGmCgxRnNkidlnCnp0FLo6caE3CTm83hqdxt"
    "crV0OAbrSAp1ok3vAFLpN1tk3FIgbim2ba2fARhhFgvY9FitjM2h0DhRrPy7C9bQjzIhBzGOlsee4koFi09wHGqF2kl6AqSq"
    "79C8oJcGTv8Cq1FowI7i1NpZGYKMomOQDtMdoryLB7dKdvcUAGJ4SidIGy8SoPg1KVY9EQ+MTWUsS7FzpYE/4I8We/NpMfmH"
    "at2t0aqOhScvGeptTqJzK4+G40A2SKN9yKiSJYEN9Pi0f44VEkTVqkPP2jF14fk7Jeui4/sXANB+foymBLw7NjEd8g6DEvha"
    "NeTSW7+fa6RANVXYtYxfM1ZeHpz6/8N66iesSCceN109dGbzys8/URvdbTPYbep3sUwtUbN/p2D9Ocx9pCJvCg4iDvrbOilv"
    "OfqegqSfQnER01OKI6S1jlUWsnL/NxvPTSCV69piRFqH7Q4BhGJdRMjuQe3ye629kbRAcRncaWoLj1WjVhwenm6bCtV4HUd5"
    "QnJspL4DO4I6osEdydlCIK+ackvUdWZZQ4ilCGJl4CKDAHIk9YCcgFOHCCaXJWsNRXAhXHNG3jAv69Fo7J/Mgzatuw7B2gB5"
    "HGGnlHAJ4VrCNYRHI4mMOmFiDzyzueP6Vc8JKuTC32Hc+zB+6D844WPTr8vbu8TWm69R2xVvNvXws7G+U6Oy+qADzaLS+oQq"
    "hVZYZzOJcKRKnWF30aEcLDpMIPGuUdcTZYrRyc1bfHjUwmWsGUzfAEKKgE4QoM1Yz4BFLd8y3Hq1guAAgIEz4iVCw3Xr9O72"
    "0JkBa62Go95oOBqPTkZ3o+3IG/mjh6PuaDA6Ho1Gb0cPRpsxLCEswYOjDpJbnTnKGQBthErOgPslamP8u+IJVU6rfLqiIsNY"
    "rXFvy6OJhJmr9TGPhxa0PDoqedEizquPeIx0o9JctzabM2V+A2ejXw4oTyTlw9p+OAdnp5pfZ6ZJ72NnMUg1Y1Fcy3n1bf5a"
    "2RuhZ0xxnheiCmsixySIIx1flST3KCthX7VtffNt/i9enlLzxqFEMgWvxZJZJmmN+ZgfMGGlHX1QeUDeZgabkuTjIM3ZiyLA"
    "EK8vnE83bwGwJrLMMMKJjAKI0dpCPErsQKh41bh0ad2AHA4nJKUPo8zsCbw8QkczpJoyjfgzhfWtkxoWaAa5Z8f0WudYTChF"
    "cO+kkR7Ta4avk1sbCynt8z4T7uefwzmnNJKoCzwlRUms9/pYvAkcX7N6k5sHjtQdFSPa/zn28jHaBwHYe5Kh+Z7vSDtE0Grv"
    "3y9I7xtG8aTAl3QwMeo1P94cYaY9D2bPbwzt+N9Rt2HbP3TJrd1TgCBCEH/ZjvhtTY7w8CwQDRqbqJ4C4tsGWkUkTD96WsA2"
    "ChYk6g1WDaE3XysSVAEhNQVY/JiX81uqy2NjjtAWaiFn9LZlWIxRnRmKvIxXQyczp3X8MeTpdxSFB8AJSKmj7rJ2FE1VVWhC"
    "tplPf1Al8FWtgVC6heGQUlLQB5yEL3ZjQBsZ0U9QRQcAGPaGWxsmEj1hqlrBLSEndRcY3EQD+kQAVr8SUJPYYergACjgsANT"
    "ahNMsPkOZdfI1mNdAFufgatPPrqPpHmkU22BDMJQgedVa+XMpKeZyYhjEyskNYhVc2HMzfl9wEXEPMh90kxw85Ng3KutGyVp"
    "v1OadfUEUtr3VTX8ZNQmtrEJps8zIs1xudj601d5XfyQJtceX0l1PrhCclbU9yCdBz1LkkP6H3E2UsDZacaZtSmtzf4ZgyMf"
    "qYnaplxlHmq1mgrJRzalQJh0L31gHyOfdu44vZ6ZR4lw8A726GgCBd/48lSiz8WpqaXxk+MTv9ovh/kYaK18bImFPuun53E5"
    "p5KVrX0gOEJ/G6ZjwNO2LuYOcVM0O4uThUorXuGHhVZVKR0uvloKIPwyfMPaAapbqZ06eqSM3XqcCa/Xq0WJVL1szBAQ1Uzp"
    "EwJtQy+T2e4KPzxlr3Lhwdkp2rG8tw0xSpRO93/cGp0LgvxHNUzG5bqG/szo1rWvIPWyw09T66Bz0ME4+3K9k47SO+/w4A9/"
    "/vOfP9JRNJHizIX3PeCskzI5Oahu8zq+QXR1UCZzuNQecBm/49ArK0UJ79kn5sLPKjJwwzY3+L5v6Z4eGt1Tfb4AXmOOTK72"
    "ac77VL0Gw/oUCVxaF5cH3mi6785yUAzr8VYhaKu8s43mXASFQ4l9VqE9wW/RGphv3r41qS9ECwYpoNbtwEzxd9zcQZxlIZHf"
    "jQ8IiJPILLJZ3k+C68plT8iQTXUCMf9EOIcj8H8LDGGEfh+vz5MAFe5s9UIiRvkmhhnunZPfOcWmnz+mNSIO/18yq6zctQs4"
    "19wovka0nwmhJSW43gJpUvsrebHButt4jgknOKUPyS5zDQ/+5vEWoOYL77v+oVdjRG9detjI1fnBzsfNJkb1Vi5LxHkUxfRr"
    "JU8WmAhLyZwaew+pPEEhp3/SfvoX1ulfCA8vaNLTipoWNd2BEyNiKZxIpER6H+6dHs79vwhmZBkHFtgo04F3dr6fk+pjWb4p"
    "PpbjUZZ9LMtrfEfh74M26GYwdMlQoLAyW3tWAdt2jE9sq8hVbVfYteWhRh7m96Fsh782LBFlBxmsTB//bIno0Y8mFHbmWYcR"
    "yuXm8IyY1BOm8lno5XQQ90YwobtRI5uh/lsLBHDNIunZ3mK4F5yiutRHCuLdZbfg6b6C1M5kp7r2StziRFAy/RNN7Q+yLNG8"
    "JRFgyql4LhX/Dxtw+Vexv/9Z3G6LCv+GDEqb1/Anb4e9rjaT4A9sfMzosluGZe/sd4P3b+vl6k2BN6wdBeQyclr5ONvhX818"
    "bkewBgH9FcZyUBcHxDDv+N0/HpzT8XpAwnA+XA/ocI2cw/WA8HG092A9uTg4R8ytyioy5T//8z/vKUskysUfuw0ahTrHplEP"
    "gEThQ+rfhGrx2ZoKNnbRaaDXxuiU7Pms2wk7XVJ0tM92umshIy/3ScGOLb4MR91RbzwYTbto+GUUYppEtBUY36ejVQklUOtp"
    "eDb2AwFJtDPh+9p8xm7N3ugYqxz4o3+DD6ZWIdFJH5CM56IaIVlAW+PV8aGuHxo7OTs99fsO0FO6vMWkgRfdMzrldVeL3hnr"
    "BhCZrno2Cge7I///urvW3raRK/pXRH4wyIhUKLu73oimBceOmn4qsN4+UMctGImyiKVJgaSSYC399865d2Y4fMhxukUL5JNE"
    "cp533veee6YpFfniDdSWE6K5j3VNE3lBz51YIWv/j/Z9ZDdjx/5+fRe6fgtlhxiEL3ygHyjrlkB3LjcHPujYV/4//hX7v334"
    "sAuC68Cn35sf+ecnflzw44IfTxcL/Jydc+Cz8xv+WeBxuqCvpyItn39v6IcDn05/oq/XAT8u3uHxLAimeLw5p7iLN/x1cXNN"
    "jzcLflwsbmzwkBgcSxfO67krBDnOx/a9+HHErz+bBP4bKvDbcypZIAv6I5fsbMEl+0OAoXz/yrUlIrtnupO2TdrqSgO2WFMl"
    "dGT5GCX8D7OWAVyrFawqzaN8rsG1fNr1WvBBnBRN/ZnElnzR8VIxU4gtsBg2SUf51jy1nTBM9pZHlIkcxkE+dFVj8EiAjkE1"
    "dXLSYf/Ju9Y8nJdlzEsy6n3RQJmEUTaJEgLnSQUbjzmKOEoELStbK0Fg+EU1jQT7Kfm+Somy4yAKm2cmviQ/aDFLALWsxgYF"
    "1obES5sS0QBKVgegmhqMKCVzgDcAuoKYxZrllrM24Jg2WCHJX4fQndbrD7faTYYCM1yxHE89g+CLKiJS9vI5scqTah/m1uRh"
    "l8WlfVAB2gj8fu2Wm/lQoS64mv7UnfnTdl2rr9Y1NS1+LPNaGv1S6VFBWfZNfhpkLk2zFPXQ0b6qKpjZJMqTpR7IwnpBIyn3"
    "i3bPVK9rA+ZZh61PHSD6iyV8+Xsk/P/pTR2odAe6o+oMxgA6EMWRnC0ykoLvFHPDWWYWSK+a/d4SKzmGnpJ9SBpAXQ4rSrHD"
    "KbBq6xyrKG9QwhWozny/QrD8rrqPogJ7mCcVJKokazSES0BCq9zvSxlMwX3FHDbDCwat1U7sZaRE0LMeDfyDUhESdIgS6CB7"
    "j8klWitPovR4RbWaUzr1JOzUs1NRMyNqBonIgmQoCKt2Xiii7GUiyroiygwRmYJhUQE9f5AyQqEPAyTca74XlBiKjBNH3siN"
    "l2kspDnnELhKjLHoXCnLIt7vU/psRRxMyYat5EsVzpSZFQuhiU2aKfVMwrAjsQfl7FKq0C7aOKkXk2SViV3MVs6Ol+LKvQzm"
    "rHOqUHl+fZC0OHQIw6GbzP1M9GfiObTNNO7WNUeTp3KFsaK4twK5+/3QhwulfkbVwaQAo6XoxrIrUZVWeLdz2LkLjlAAzJWi"
    "q+dAxCmr/pMaAWZUUUNRTdEBQDx3CBUYRcsRhtUnnA5na7Y9M49QXM/IX9o+zMBEJ4NsRZZMYMdB1xSO/ouA7WQ2TiMi3k15"
    "FYtIJtFkwRhJSP1djsh9scuNWb+j8QbXw9YWoELd29imy13HcADMRN8YjuoReyMLWI0bqk8s65NxKatlnC+K8vq5YspeN5xV"
    "LjtfQF4H3O8AiPxfK10wnEFU69O4/m8qXdop/8dKl4avRTTM+7Ru2Fn4WdtQjdd/rjdJ2QpIb4aCihSibrgeIhFqSxlmHacZ"
    "6CwetEdHOWwnA8INtgpLxMQ1lJhFWB+erBxtaipblv6Un6EPRyM7BI+FydugnqLZS86YhCePjFMGqxwYZh6qxagzjzmsGiI2"
    "UiqmqhpZ4N4W9UYEqtQI4rEJH4+4nhekQJpJko0wJqR9S5SlSKX8FWZeMf9QUWNgrI+o1B9lqURkMo/w2JQzyXCe2bzstpaR"
    "J1v/yfb/sjxnx9o1wCLQQZYmg2GxqCRuT7NH+UCSNlTEumNIFzXgZ+CR8KccPVo0a7EWiwCDjq5wURtdJlcSHRm+fJJd4hqX"
    "SCa2B6MQ3PwBeiCutV4DRn1/IUlQQp+RcH4sx3wwwxIZttWTdTG4QDZohV7nE0fpFkiMThFqNOiWL9HyJbd8KVs+B5KGr5tt"
    "7Eo4IHt8una/HzavATWP2YX5Hla+n6c88sU3b2LNjwV62NW4369Fe2Gur/CzV72eo5GjhQkLUagXfGDukoEId+m9uuSmboC0"
    "X49iVqL8loiyYl2OCyCmtHc6PBYyUcXsolAVyhTOpRKni+zek972WlsPBfOVzsqm3tvrS8uTk+UkL3LyBppXE3ZQkEbTagL/"
    "BHqYVZMEQdRqYDjKvxejK0v+SncN3YK40DHiuWF8Fzc+KFa0A9E0HSTgGey0IRKGP7jV9Qe3puEzJMeIeVeK9EH83cSQf4KD"
    "OyR9MblBzzi8JOIc1HAfBGFxoeoBDhCXAL1N2wJg2Oo1A197HWQgTNMXwoECR/GhS2XiPvFurcTUV/Wn9m43aE3wBv1eFuXN"
    "HJ+HJQERsXEHNAyz+sdESCPRs5maa8X2P4UmcSU+1AngRN1CMzR34AP6dEGTLG6KNVxdGJmeP5On636nHD9dE17b1aTFwZRP"
    "VsXPyaqMPwOYpP5Hw4RUsHXjMxCKYgPQUQxLo5nSHbOl/n2Ce+giBX18a7zEqDGnml4AW6qIJVKQEhetLZ3CZEnl01+2K4Ul"
    "lAHSTzy7dJkgv4H+Uackcc/LqiLwo62u75yN4o9Vke3qJBzRhaazURCO6mJLv7/5jO0fnYcjebEs3cNYV7MR3+nLEiwetyKF"
    "W1wg6vAmNmeSQ2K0sstkXSbVRobmO9h4uixNvEuvWVkk3KxSPMeatV0E7O9OYWafGqxj9iNdmXu1ogvz+kVpB7tGYY4FJN46"
    "Hq8JnSlpRFaSvM5e8qOSDj0N1FeU8QdyZhtw4FPY0tvm5tW+oXbIYcpJImMXDfdl8riSLoOmu+Az3ZZc2g1vbVO6XYRSEslR"
    "5NWRM9xflwTY57T9RLsAiFrJd6evegPOfc2QPiqcmRgXlwORT5LFBdhQ6VouqvxKDGex8rXqs+POZEq0N04T1fJqvjAT4Let"
    "BKhPJNJncWBE1FpOpVlgsdH7KgZYOWkaxVMssaoRsckguaM/QBUsTg7TyQ+vamVkxbBnoQFozdNMxVcrtHiP2Hc3s6RG1H3K"
    "lG604hybvY7URuoB/8xOyA3Fsgoag6wJJq3T8AiIcg0sriafcb8yFiz9V3sgFXQNBdXiMp4zd5r090jUrfbuXTmn+ztntmSy"
    "vZ/VMtIV26cqHXbslPNgptLk0+wuMoHz1MXMLvs3wByaG0A8ZmJUnsThWm1HNxFoE0mP5WzEkYfNcTu32c1uo9V+vxQf6QBs"
    "Be6r0nuIlhQaNyy8Ko2EyboAJsYxLqzQqeGls4Lqlb80SbmXD+PJGzd0kaSD0ozH63u3SRtcSla0VXRKWiXx4G+9M/An5d+w"
    "0ITftMJsv4QjCRexGzqjvpj9qXfqjm0EpyXJHjvbcX+q4BDchgj0iBe298ngPjbX9+Y1WNZWJyefOuDvZpz5uOUYgXBS1Wsp"
    "1MDXRU6wNNtu1lhTXHlnxqDFzZw75WzAu8pnVkjXa4X86iI2EPrZtay/Rqk5TKbxzGpm7C+OsFuq7+73SNtt6JcIlLcpshXE"
    "5wy8PSaggaCNstN4yU4mHZ/rWoGKy2goyrEhuy1xDi67I1YNILHxgxfMOis+z0b61l0VXN8s3D5n69eEo2oGnqnFMMpmUomT"
    "WiNLf03s0ADzq4SNSKLQvS1PTn6Fx3xW6Gqazrj0mh0Icr7FBYiTNK+Ssn5LBy2nHAxCwA9KpKtkBBOnVCm2tTJGdbqbIlAQ"
    "ovVyk6C9+d9Adk1Jke6B7r8ZO+l84BPoSL10jqLAWjjMFjoCAVALKSYGnU3vFIIj6J+gzXZowd4LD4ZbqYIRJ+VMHaCJnlEs"
    "UJVb8DGWiINzZuRW84oNsxK/qD7HW7H5oTe0kS5QHuL0XgA1KISGSzjVwsKbOFtE7vV8ujqxam1VLXMMD58iuLWsqWT1akmo"
    "4S7pFCnMI/uXd3//5ernd1c2GEVy0SZowbllilMZ4a3Xd/8kmNVHjcJ7zgWWFIauueC4h9xoXrjZHZwC2/pU/GgMoSXkXhGp"
    "OeksDME3M7qSPN50RL9e/27ZQ9ldKN/oYvBCg6XR9Zcv7/oH9KkCt5EtmBT75CQnERzc8N+Ukbj4"
)

# JS do Workbench, na ordem em que a página os carrega
_JS_WORKBENCH = {
    "regras-time": r'''/* Regras do time para o SFMC Workbench.
 *
 * Este arquivo é a base de regras de quem abrir a ferramenta a partir desta pasta.
 * Edite os valores abaixo (ou gere um novo na aba Regras > "Baixar como regras-time.js")
 * e substitua o arquivo na pasta compartilhada. Ajustes feitos no painel Regras ficam
 * salvos só no navegador de cada pessoa e têm prioridade sobre este arquivo.
 *
 * niveis: bloq (bloqueador), alerta ou off (desligada).
 * Se este arquivo for apagado, a ferramenta usa o padrão embutido em js/rules.js.
 */
window.WB_REGRAS_TIME = {
  "versao": 1,
  "niveis": {
    "viewEmailUrl": "bloq",
    "redirectTo": "bloq",
    "descadastroAusente": "bloq",
    "descadastroPadrao": "alerta",
    "hrefVazio": "bloq",
    "hrefHash": "alerta",
    "hrefJs": "bloq",
    "linkSemRedirect": "off",
    "linkAninhado": "alerta",
    "imgSemAlt": "alerta",
    "imgRelativa": "alerta",
    "scriptTag": "bloq",
    "ampNaoFechado": "bloq",
    "doctype": "alerta",
    "viewport": "alerta",
    "tamanho": "alerta",
    "dominioTexto": "alerta"
  },
  "parametros": {
    "chamadaRastreamento": "RedirectTo\\(\\s*@Link_Tag\\s*\\)",
    "variaveisDescadastro": [
      "unsub_center_url",
      "unsub_url",
      "profile_center_url",
      "subscription_center_url"
    ],
    "variaveisSistema": [
      "view_email_url",
      "unsub_center_url",
      "unsub_url",
      "profile_center_url",
      "subscription_center_url",
      "emailname_",
      "email_name_",
      "jobid",
      "listid",
      "batchid",
      "memberid",
      "subscriberid",
      "emailaddr",
      "xtmonth",
      "xtmonthnumeric",
      "xtday",
      "xtyear",
      "replyname",
      "replyemailaddress",
      "fromname",
      "fromaddress",
      "member_busname",
      "member_addr",
      "member_city",
      "member_state",
      "member_postalcode",
      "member_country"
    ],
    "dominios": [
      "com.br",
      "gov.br",
      "com",
      "net",
      "org",
      "br",
      "io",
      "app",
      "dev",
      "info",
      "biz",
      "co"
    ],
    "limiteKB": 102,
    "sufixoImagem": "_\\d{2,}\\.(jpe?g|png|gif|webp)$"
  }
};
''',
    "parser": r'''/* parser.js — Leitura de HTML tolerante e ciente de AMPScript.
 *
 * Duas camadas:
 * 1. tokenize(src): percorre o HTML original e devolve tokens com a posição exata
 *    no texto (início/fim, atributos, valores). Entende comentários, <style>/<script>,
 *    aspas com ">" dentro e blocos %%[ ]%% / %%= =%% — inclusive dentro de atributos.
 * 2. dom(src): monta uma cópia "de auditoria" (AMPScript trocado por marcadores e cada
 *    tag marcada com a posição de origem) e entrega ao DOMParser do navegador.
 *    O HTML original nunca é alterado por aqui.
 */
(function (WB) {
  'use strict';

  const RAW = new Set(['script', 'style', 'textarea', 'title', 'xmp']);
  const AMP_RE = /%%\[[\s\S]*?\]%%|%%=[\s\S]*?=%%/g;
  const PH_RE = /\uE000(\d+)\uE001/g;
  const isLetter = c => (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
  const isSpace = c => c === ' ' || c === '\n' || c === '\t' || c === '\r' || c === '\f';

  /** Fim de um trecho AMPScript iniciado em i (ou -1 se não fechar). */
  function ampEnd(src, i) {
    const block = src[i + 2] === '[';
    const k = src.indexOf(block ? ']%%' : '=%%', i + 3);
    return k < 0 ? -1 : k + 3;
  }
  const ampAt = (src, i) => src[i] === '%' && src[i + 1] === '%' && (src[i + 2] === '[' || src[i + 2] === '=');

  function readTag(src, i, errors) {
    const n = src.length;
    let j = i + 1;
    while (j < n && !isSpace(src[j]) && src[j] !== '>' && src[j] !== '/') j++;
    const tag = { t: 'start', s: i, e: n, name: src.slice(i + 1, j).toLowerCase(), ne: j, attrs: [], selfClose: false };
    while (j < n) {
      while (j < n && isSpace(src[j])) j++;
      if (j >= n) break;
      const c = src[j];
      if (c === '>') { tag.e = j + 1; return tag; }
      if (c === '/' && src[j + 1] === '>') { tag.selfClose = true; tag.e = j + 2; return tag; }
      if (c === '/') { j++; continue; }
      if (ampAt(src, j)) { const k = ampEnd(src, j); if (k < 0) { errors.push({ tipo: 'ampAberto', s: j, e: j + 3 }); j += 3; } else j = k; continue; }
      const ns = j;
      while (j < n && !isSpace(src[j]) && src[j] !== '=' && src[j] !== '>' && !(src[j] === '/' && src[j + 1] === '>')) j++;
      if (j === ns) { j++; continue; }
      const a = { name: src.slice(ns, j), lname: src.slice(ns, j).toLowerCase(), ns, ne: j, value: null, vs: -1, ve: -1, ae: j, q: '' };
      let k = j;
      while (k < n && isSpace(src[k])) k++;
      if (src[k] === '=') {
        k++;
        while (k < n && isSpace(src[k])) k++;
        const q = src[k];
        if (q === '"' || q === "'") {
          a.q = q; a.vs = k + 1; k = a.vs;
          while (k < n && src[k] !== q) {
            if (ampAt(src, k)) { const m = ampEnd(src, k); if (m < 0) { errors.push({ tipo: 'ampAberto', s: k, e: k + 3 }); k += 3; } else k = m; } else k++;
          }
          a.ve = Math.min(k, n); a.ae = Math.min(k + 1, n); j = a.ae;
        } else {
          a.vs = k;
          while (k < n && !isSpace(src[k]) && src[k] !== '>') {
            if (ampAt(src, k)) { const m = ampEnd(src, k); if (m < 0) { k += 3; } else k = m; } else k++;
          }
          a.ve = k; a.ae = k; j = k;
        }
        a.value = src.slice(a.vs, a.ve);
      }
      tag.attrs.push(a);
    }
    tag.e = n;
    errors.push({ tipo: 'tagAberta', s: i, e: Math.min(i + 40, n) });
    return tag;
  }

  /**
   * Tokens: text | start | end | comment | decl | amp | raw.
   * Cada token tem s/e (posições no texto original).
   */
  function tokenize(src) {
    const n = src.length, tokens = [], errors = [];
    let i = 0, ts = -1;
    const flush = () => { if (ts >= 0 && ts < i) tokens.push({ t: 'text', s: ts, e: i }); ts = -1; };
    const NEXT = /<|%%[\[=]/g;

    while (i < n) {
      const c = src[i];
      if (ampAt(src, i)) {
        const e = ampEnd(src, i);
        if (e < 0) {
          errors.push({ tipo: 'ampAberto', s: i, e: i + 3 });
        } else {
          const block = src[i + 2] === '[';
          const inner = src.slice(i + 3, e - 3);
          if (inner.includes(block ? '%%[' : '%%=')) errors.push({ tipo: 'ampAberto', s: i, e: i + 3 });
          flush();
          tokens.push({ t: 'amp', s: i, e, block });
          i = e; continue;
        }
      } else if (c === '<') {
        const d = src[i + 1];
        if (src.startsWith('<!--', i)) {
          flush();
          const k = src.indexOf('-->', i + 4), e = k < 0 ? n : k + 3;
          tokens.push({ t: 'comment', s: i, e, cond: /^<!--\[if/i.test(src.slice(i, i + 10)) });
          i = e; continue;
        }
        if (d === '!' || d === '?') {
          flush();
          const k = src.indexOf('>', i), e = k < 0 ? n : k + 1;
          tokens.push({ t: 'decl', s: i, e });
          i = e; continue;
        }
        if (d === '/' && isLetter(src[i + 2] || '')) {
          flush();
          let j = i + 2;
          while (j < n && !isSpace(src[j]) && src[j] !== '>' && src[j] !== '/') j++;
          const k = src.indexOf('>', j), e = k < 0 ? n : k + 1;
          tokens.push({ t: 'end', s: i, e, name: src.slice(i + 2, j).toLowerCase() });
          i = e; continue;
        }
        if (isLetter(d || '')) {
          flush();
          const tag = readTag(src, i, errors);
          tokens.push(tag);
          i = tag.e;
          if (RAW.has(tag.name) && !tag.selfClose && i < n) {
            const re = new RegExp('</' + tag.name + '(?=[\\s/>])', 'ig');
            re.lastIndex = i;
            const m = re.exec(src);
            const rs = i, re_ = m ? m.index : n;
            if (re_ > rs) tokens.push({ t: 'raw', s: rs, e: re_, parent: tag.name });
            i = re_;
            if (m) {
              const k = src.indexOf('>', m.index), e = k < 0 ? n : k + 1;
              tokens.push({ t: 'end', s: m.index, e, name: tag.name });
              i = e;
            }
          }
          continue;
        }
      }
      if (ts < 0) ts = i;
      NEXT.lastIndex = i + 1;
      const m = NEXT.exec(src);
      i = m ? m.index : n;
    }
    flush();
    return { tokens, errors };
  }

  /** Converte posição no texto em linha/coluna (1-based). */
  function lineIndex(src) {
    const starts = [0];
    for (let i = 0; i < src.length; i++) if (src.charCodeAt(i) === 10) starts.push(i + 1);
    const line = off => {
      let lo = 0, hi = starts.length - 1;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= off) lo = mid; else hi = mid - 1; }
      return lo + 1;
    };
    return { line, col: off => off - starts[line(off) - 1] + 1, total: starts.length };
  }

  /**
   * Monta a cópia de auditoria e passa pelo DOMParser.
   * - AMPScript vira \uE000n\uE001 (restaurado com restore()).
   * - Toda tag de abertura ganha data-wbo="posição no original".
   */
  function dom(src, tk) {
    tk = tk || tokenize(src);
    const amps = [];
    const ph = s => { amps.push(s); return '\uE000' + (amps.length - 1) + '\uE001'; };
    let out = '';
    for (const t of tk.tokens) {
      const raw = src.slice(t.s, t.e);
      if (t.t === 'amp') out += ph(raw);
      else if (t.t === 'start') out += '<' + t.name + ' data-wbo="' + t.s + '"' + src.slice(t.ne, t.e).replace(AMP_RE, ph);
      else if (t.t === 'raw' || t.t === 'text') out += raw.replace(AMP_RE, ph);
      else out += raw;
    }
    // Garante que trechos sem token (não deveria haver) não se percam
    const doc = new DOMParser().parseFromString(out, 'text/html');
    const restore = s => s == null ? s : String(s).replace(PH_RE, (m, k) => amps[+k] ?? '');
    const strip = s => String(s).replace(PH_RE, ' ');
    return { doc, amps, restore, strip, tk };
  }

  WB.parser = { tokenize, lineIndex, dom, RAW };
})(window.WB = window.WB || {});
''',
    "rules": r'''/* rules.js — Regras do Quality Gate.
 *
 * Ordem de prioridade:
 *   1. Ajustes salvos neste navegador (painel Regras ou JSON importado)
 *   2. regras-time.js (arquivo compartilhado do time, opcional)
 *   3. Padrão embutido abaixo
 */
(function (WB) {
  'use strict';

  const NIVEIS = ['bloq', 'alerta', 'off'];
  const NOME_NIVEL = { bloq: 'Bloqueador', alerta: 'Alerta', off: 'Desligada' };
  const CHAVE = 'sfmcwb-regras';

  const CATALOGO = [
    { id: 'viewEmailUrl', nome: 'Link “ver no navegador” (%%view_email_url%%)', padrao: 'bloq' },
    { id: 'redirectTo', nome: 'Chamada de rastreamento RedirectTo(@Link_Tag)', padrao: 'bloq' },
    { id: 'descadastroAusente', nome: 'Link de descadastro presente', padrao: 'bloq' },
    { id: 'descadastroPadrao', nome: 'Descadastro só com a variável de sistema', padrao: 'alerta' },
    { id: 'hrefVazio', nome: 'Links com href vazio ou sem href', padrao: 'bloq' },
    { id: 'hrefHash', nome: 'Links apontando só para “#”', padrao: 'alerta' },
    { id: 'hrefJs', nome: 'Links com javascript:', padrao: 'bloq' },
    { id: 'linkSemRedirect', nome: 'Links http(s) diretos, sem a chamada de rastreamento', padrao: 'off' },
    { id: 'linkAninhado', nome: 'Link dentro de outro link', padrao: 'alerta' },
    { id: 'imgSemAlt', nome: 'Imagens sem atributo alt', padrao: 'alerta' },
    { id: 'imgRelativa', nome: 'Imagens com src relativo', padrao: 'alerta' },
    { id: 'scriptTag', nome: 'Tag <script> (exceto AMPScript)', padrao: 'bloq' },
    { id: 'ampNaoFechado', nome: 'Bloco AMPScript sem fechamento', padrao: 'bloq' },
    { id: 'doctype', nome: 'DOCTYPE presente', padrao: 'alerta' },
    { id: 'viewport', nome: 'Meta viewport presente', padrao: 'alerta' },
    { id: 'tamanho', nome: 'Tamanho do HTML (corte do Gmail)', padrao: 'alerta' },
    { id: 'dominioTexto', nome: 'Domínios em texto puro', padrao: 'alerta' }
  ];

  const PADRAO = {
    versao: 1,
    niveis: Object.fromEntries(CATALOGO.map(r => [r.id, r.padrao])),
    parametros: {
      chamadaRastreamento: 'RedirectTo\\(\\s*@Link_Tag\\s*\\)',
      variaveisDescadastro: ['unsub_center_url', 'unsub_url', 'profile_center_url', 'subscription_center_url'],
      variaveisSistema: ['view_email_url', 'unsub_center_url', 'unsub_url', 'profile_center_url', 'subscription_center_url', 'emailname_', 'email_name_', 'jobid', 'listid', 'batchid', 'memberid', 'subscriberid', 'emailaddr', 'xtmonth', 'xtmonthnumeric', 'xtday', 'xtyear', 'replyname', 'replyemailaddress', 'fromname', 'fromaddress', 'member_busname', 'member_addr', 'member_city', 'member_state', 'member_postalcode', 'member_country'],
      dominios: ['com.br', 'gov.br', 'com', 'net', 'org', 'br', 'io', 'app', 'dev', 'info', 'biz', 'co'],
      limiteKB: 102,
      sufixoImagem: '_\\d{2,}\\.(jpe?g|png|gif|webp)$'
    }
  };

  const clone = o => JSON.parse(JSON.stringify(o));
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const lista = v => (Array.isArray(v) ? v : typeof v === 'string' ? v.split(/[\n,;]+/) : [])
    .map(x => String(x).trim()).filter(Boolean);

  /** Base do time: regras-time.js, se existir, senão o padrão embutido. */
  function base() {
    const t = window.WB_REGRAS_TIME;
    return t && typeof t === 'object' ? normalizar(t, clone(PADRAO)).cfg : clone(PADRAO);
  }

  /** Completa e valida uma configuração. Devolve { cfg, erros }. */
  function normalizar(entrada, ref) {
    ref = ref || clone(PADRAO);
    const erros = [];
    const cfg = clone(ref);
    if (!entrada || typeof entrada !== 'object') return { cfg, erros: ['O conteúdo não é um objeto JSON.'] };

    const nv = entrada.niveis || {};
    for (const r of CATALOGO) {
      if (nv[r.id] === undefined) continue;
      if (NIVEIS.includes(nv[r.id])) cfg.niveis[r.id] = nv[r.id];
      else erros.push(`Nível inválido em "${r.id}": use bloq, alerta ou off.`);
    }
    for (const k of Object.keys(nv)) if (!CATALOGO.some(r => r.id === k)) erros.push(`Regra desconhecida ignorada: "${k}".`);

    const p = entrada.parametros || {};
    const pr = cfg.parametros;
    for (const k of ['chamadaRastreamento', 'sufixoImagem']) {
      if (p[k] === undefined) continue;
      try { new RegExp(String(p[k])); pr[k] = String(p[k]); }
      catch (e) { erros.push(`Expressão regular inválida em "${k}": ${e.message}`); }
    }
    for (const k of ['variaveisDescadastro', 'variaveisSistema', 'dominios']) {
      if (p[k] === undefined) continue;
      const v = lista(p[k]);
      if (k === 'dominios' && v.some(d => !/^[a-z0-9-]+(\.[a-z0-9-]+)*$/i.test(d))) erros.push('"dominios": use só letras, números, hífen e ponto (ex.: com.br).');
      else if (k !== 'dominios' && v.some(d => !/^\w+$/.test(d))) erros.push(`"${k}": use só o nome da variável, sem %%.`);
      else pr[k] = v;
    }
    if (p.limiteKB !== undefined) {
      const n = Number(p.limiteKB);
      if (Number.isFinite(n) && n > 0) pr.limiteKB = n; else erros.push('limiteKB deve ser um número maior que zero.');
    }
    return { cfg, erros };
  }

  /** Transforma a configuração em objetos prontos para a auditoria. */
  function compilar(cfg) {
    const p = cfg.parametros;
    const tlds = [...p.dominios].sort((a, b) => b.length - a.length).map(reEsc).join('|') || '(?!)';
    const sys = new Set(p.variaveisSistema.map(s => s.toLowerCase()));
    return {
      cfg,
      nivel: id => cfg.niveis[id] || 'off',
      chamadaRe: new RegExp(p.chamadaRastreamento, 'i'),
      chamadaCompletaRe: new RegExp('%%=\\s*' + p.chamadaRastreamento + '\\s*=%%', 'i'),
      unsubRe: new RegExp('%%(' + (p.variaveisDescadastro.map(reEsc).join('|') || '(?!)') + ')%%', 'i'),
      isSys: n => n[0] === '_' || sys.has(n.toLowerCase()),
      domRe: () => new RegExp('(?:https?:\\/\\/)?(?:www\\.)?(?:[a-z0-9-]+\\.)+(?:' + tlds + ')\\b(?:\\/[^\\s<"\']*)?', 'gi'),
      sufRe: new RegExp(p.sufixoImagem, 'i'),
      limiteKB: p.limiteKB
    };
  }

  function carregar() {
    const b = base();
    try {
      const s = localStorage.getItem(CHAVE);
      if (s) return { cfg: normalizar(JSON.parse(s), b).cfg, personalizada: true };
    } catch (e) { /* armazenamento indisponível */ }
    return { cfg: b, personalizada: false };
  }
  function salvar(cfg) {
    try { localStorage.setItem(CHAVE, JSON.stringify(cfg)); return true; } catch (e) { return false; }
  }
  function limpar() { try { localStorage.removeItem(CHAVE); } catch (e) { /* ok */ } }

  /** Assinatura curta para o relatório (identifica a versão das regras usada). */
  function assinatura(cfg) {
    const s = JSON.stringify(cfg);
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  WB.rules = { CATALOGO, PADRAO, NIVEIS, NOME_NIVEL, base, normalizar, compilar, carregar, salvar, limpar, assinatura, lista, clone };
})(window.WB = window.WB || {});
''',
    "audit": r'''/* audit.js — Quality Gate e geração do código final.
 *
 * analyze(): lê o HTML com o DOMParser (via WB.parser.dom) e devolve as checagens
 *            com a posição de cada problema no HTML original.
 * compile(): gera o código final editando o texto original só nos pontos necessários
 *            (src de imagens, proteção anti-link, variáveis). O AMPScript fica intacto.
 */
(function (WB) {
  'use strict';
  const P = WB.parser;

  const fileOf = s => String(s || '').split(/[?#]/)[0].split('/').pop();
  const ORDEM = { bloq: 0, alerta: 1, ok: 2 };
  const PADRAO_CHAMADA = 'RedirectTo\\(\\s*@Link_Tag\\s*\\)';

  function kbDe(src) {
    try { return new TextEncoder().encode(src).length / 1024; } catch (e) { return new Blob([src]).size / 1024; }
  }

  function analyze(src, R) {
    const tk = P.tokenize(src);
    const L = P.lineIndex(src);
    const { doc, restore, strip } = P.dom(src, tk);

    const byOff = new Map();
    for (const t of tk.tokens) if (t.t === 'start') byOff.set(t.s, t);
    const offOf = el => { const v = el.getAttribute('data-wbo'); return v == null ? null : +v; };
    const tagLoc = el => {
      const o = offOf(el); if (o == null) return null;
      const t = byOff.get(o); return { s: o, e: t ? Math.min(t.e, o + 400) : o + 1 };
    };
    const attrLoc = (el, name) => {
      const o = offOf(el), t = o != null && byOff.get(o);
      const a = t && t.attrs.find(x => x.lname === name && x.vs >= 0);
      return a && a.ve > a.vs ? { s: a.vs, e: a.ve } : tagLoc(el);
    };
    // O parser pode clonar elementos em HTML mal aninhado; o clone carrega o mesmo data-wbo.
    const unicos = sel => {
      const vistos = new Set();
      return [...doc.querySelectorAll(sel)].filter(el => {
        const o = offOf(el); if (o == null) return true;
        if (vistos.has(o)) return false; vistos.add(o); return true;
      });
    };

    // ---------- Links ----------
    const links = unicos('a').map(el => {
      const href = el.hasAttribute('href') ? restore(el.getAttribute('href')).trim() : null;
      const st = !href ? 'vazio' : href.startsWith('#') ? 'hash' : /^javascript:/i.test(href) ? 'js' : 'ok';
      let texto = strip(el.textContent).replace(/\s+/g, ' ').trim();
      if (!texto) { const im = el.querySelector('img'); if (im) texto = '[imagem] ' + (restore(im.getAttribute('alt')) || ''); }
      return { href, st, texto: texto.slice(0, 90), loc: attrLoc(el, 'href') };
    });

    // ---------- Imagens ----------
    const imgs = unicos('img').map(el => {
      const s = restore(el.getAttribute('src') || '').trim();
      return { src: s, file: fileOf(s), alt: el.hasAttribute('alt') ? restore(el.getAttribute('alt')).trim() : null, loc: tagLoc(el) };
    });

    // ---------- Variáveis de personalização ----------
    const vars = {};
    for (const m of src.matchAll(/%%([A-Za-z_]\w*)%%/g)) {
      if (R.isSys(m[1])) continue;
      const v = vars[m[1]] = vars[m[1]] || { n: 0, locs: [] };
      v.n++; v.locs.push({ s: m.index, e: m.index + m[0].length });
    }

    // ---------- Domínios em texto (nós de texto reais do DOM) ----------
    const textos = tk.tokens.filter(t => t.t === 'text');
    const acharTexto = (str, from) => {
      let lo = 0, hi = textos.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (textos[mid].e <= from) lo = mid + 1; else hi = mid; }
      for (let i = lo, lim = Math.min(textos.length, lo + 600); i < lim; i++) {
        const t = textos[i], ini = Math.max(t.s, from);
        const k = src.slice(ini, t.e).indexOf(str);
        if (k >= 0) return { s: ini + k, e: ini + k + str.length };
      }
      return null;
    };
    const dominios = [], cursor = {};
    if (doc.body) {
      const domRe = R.domRe();
      const w = doc.createTreeWalker(doc.body, 4 /* NodeFilter.SHOW_TEXT */);
      for (let nd = w.nextNode(); nd; nd = w.nextNode()) {
        const p = nd.parentElement;
        if (p && p.closest('script,style,textarea,title,template,xmp')) continue;
        for (const m of strip(nd.data).matchAll(domRe)) {
          const anc = p && p.closest('[data-wbo]');
          const from = Math.max(anc ? offOf(anc) : 0, cursor[m[0]] || 0);
          const achado = acharTexto(m[0], from);
          if (achado) cursor[m[0]] = achado.e;
          dominios.push({ txt: m[0], loc: achado || (anc ? tagLoc(anc) : null) });
        }
      }
    }

    // ---------- Estrutura (tokens) ----------
    const aninhados = []; let prof = 0;
    for (const t of tk.tokens) {
      if (t.t === 'start' && t.name === 'a' && !t.selfClose) { if (prof > 0) aninhados.push({ s: t.s, e: t.e }); prof++; }
      else if (t.t === 'end' && t.name === 'a') prof = Math.max(0, prof - 1);
    }
    const scripts = tk.tokens.filter(t => t.t === 'start' && t.name === 'script' &&
      !t.attrs.some(a => a.lname === 'language' && /ampscript/i.test(a.value || ''))).map(t => ({ s: t.s, e: t.e }));
    const ampAbertos = tk.errors.filter(e => e.tipo === 'ampAberto');
    const temDoctype = tk.tokens.some(t => t.t === 'decl' && /^<!doctype/i.test(src.slice(t.s, t.s + 9)));
    const temViewport = [...doc.querySelectorAll('meta')].some(m => /viewport/i.test(m.getAttribute('name') || ''));
    const head = tk.tokens.find(t => t.t === 'start' && t.name === 'head');
    const kb = kbDe(src);

    // ---------- Checagens ----------
    const ck = [];
    const add = (id, ok, t, d, locs) => {
      const nv = R.nivel(id); if (nv === 'off') return;
      ck.push({ id, l: ok ? 'ok' : nv, t, d, locs: (locs || []).filter(Boolean) });
    };

    const vu = /%%view_email_url%%/i.exec(src);
    if (vu) add('viewEmailUrl', true, '%%view_email_url%% presente', 'Link “ver no navegador” encontrado.', [{ s: vu.index, e: vu.index + vu[0].length }]);
    else add('viewEmailUrl', false, '%%view_email_url%% ausente', 'Inclua o link para visualizar o e-mail no navegador.');

    const padraoTime = R.cfg.parametros.chamadaRastreamento === PADRAO_CHAMADA;
    const rd = R.chamadaCompletaRe.exec(src);
    if (rd) add('redirectTo', true, padraoTime ? 'RedirectTo(@Link_Tag) presente' : 'Chamada de rastreamento presente', 'Encontrada: ' + rd[0].slice(0, 80), [{ s: rd.index, e: rd.index + rd[0].length }]);
    else add('redirectTo', false, padraoTime ? 'RedirectTo(@Link_Tag) ausente' : 'Chamada de rastreamento ausente',
      padraoTime ? 'Use exatamente %%=RedirectTo(@Link_Tag)=%% nos links rastreados.' : 'Nenhum trecho segue o padrão configurado na aba Regras.');

    const un = links.filter(l => l.href && R.unsubRe.test(l.href));
    const nomesUnsub = R.cfg.parametros.variaveisDescadastro.map(v => '%%' + v + '%%');
    if (!un.length) add('descadastroAusente', false, 'Link de descadastro ausente', 'Nenhum href usa ' + (nomesUnsub[0] || 'a variável de descadastro') + (nomesUnsub.length > 1 ? ' ou equivalente.' : '.'));
    else {
      const fora = un.filter(l => /RedirectTo/i.test(l.href) || !/^%%\w+%%$/.test(l.href));
      if (R.nivel('descadastroPadrao') === 'off') add('descadastroAusente', true, 'Link de descadastro presente', 'O href usa a variável de sistema.', un.map(l => l.loc));
      else if (fora.length) add('descadastroPadrao', false, 'Descadastro fora do padrão', 'O href deve conter somente a variável de sistema, sem RedirectTo nem texto extra.', fora.map(l => l.loc));
      else add('descadastroPadrao', true, 'Descadastro conforme', 'O href usa somente a variável de sistema.', un.map(l => l.loc));
    }

    const porSt = st => links.filter(l => l.st === st);
    const vz = porSt('vazio'), hs = porSt('hash'), js = porSt('js');
    if (vz.length) add('hrefVazio', false, vz.length + ' link(s) com href vazio ou ausente', 'Defina o destino de cada link antes de publicar.', vz.map(l => l.loc));
    if (hs.length) add('hrefHash', false, hs.length + ' link(s) com href “#”', 'Substitua por destino real antes de publicar.', hs.map(l => l.loc));
    if (js.length) add('hrefJs', false, js.length + ' link(s) com javascript:', 'Não são suportados em e-mail.', js.map(l => l.loc));
    const diretos = links.filter(l => l.st === 'ok' && /^https?:\/\//i.test(l.href) && !R.chamadaRe.test(l.href));
    if (diretos.length) add('linkSemRedirect', false, diretos.length + ' link(s) http(s) sem chamada de rastreamento', 'Esses links não passam pelo RedirectTo e podem ficar fora do rastreamento.', diretos.map(l => l.loc));
    if (aninhados.length) add('linkAninhado', false, aninhados.length + ' link(s) dentro de outro link', 'Feche cada <a> antes de abrir o próximo. Clientes de e-mail desmontam links aninhados de formas diferentes.', aninhados);

    const sa = imgs.filter(i => i.alt === null);
    if (sa.length) add('imgSemAlt', false, sa.length + ' imagem(ns) sem atributo alt', 'Importante para acessibilidade e para quem bloqueia imagens. Em imagem decorativa, use alt="".', sa.map(i => i.loc));
    const rel = imgs.filter(i => i.src && !/^(https?:|%%|data:)/i.test(i.src));
    if (rel.length) add('imgRelativa', false, rel.length + ' imagem(ns) com src relativo', 'Defina a URL base na aba Imagens.', rel.map(i => i.loc));

    if (scripts.length) add('scriptTag', false, 'Tag script encontrada', 'JavaScript não roda em clientes de e-mail e pode barrar a publicação.', scripts);
    if (ampAbertos.length) add('ampNaoFechado', false, ampAbertos.length + ' trecho(s) AMPScript sem fechamento', 'Feche %%[ com ]%% e %%= com =%%. O SFMC recusa o envio com erro de sintaxe.', ampAbertos);
    if (!temDoctype) add('doctype', false, 'DOCTYPE ausente', 'Recomendado para renderização consistente.', [{ s: 0, e: 0 }]);
    if (!temViewport) add('viewport', false, 'Meta viewport ausente', 'Pode quebrar a versão mobile.', head ? [{ s: head.s, e: head.e }] : [{ s: 0, e: 0 }]);
    if (kb > R.limiteKB) add('tamanho', false, 'HTML com ' + kb.toFixed(0) + ' KB', 'Acima de ' + R.limiteKB + ' KB o Gmail corta o e-mail.');
    if (dominios.length) add('dominioTexto', false, dominios.length + ' domínio(s) em texto puro', 'Podem virar link automático. Ative a proteção anti-link na aba Links.', dominios.map(d => d.loc));

    ck.sort((a, b) => ORDEM[a.l] - ORDEM[b.l]);

    // Linha de cada posição (para a interface e o relatório)
    const ln = loc => { if (loc) loc.ln = L.line(loc.s); return loc; };
    ck.forEach(c => c.locs.forEach(ln));
    links.forEach(l => ln(l.loc)); imgs.forEach(i => ln(i.loc));
    Object.values(vars).forEach(v => v.locs.forEach(ln));
    dominios.forEach(d => ln(d.loc));

    const bloq = ck.filter(c => c.l === 'bloq').length, alerta = ck.filter(c => c.l === 'alerta').length;
    return {
      links, imgs, vars, ck, dominios, dn: dominios.length, kb, linhas: L.total,
      bloq, alerta, status: bloq ? 'reprovado' : alerta ? 'alertas' : 'aprovado'
    };
  }

  /** Proteção anti-link: insere &#xFEFF; antes de "://" e de cada ponto do domínio. */
  function anti(texto, R) {
    return texto.replace(R.domRe(), m => m.replace(/:\/\//, '&#xFEFF;://').replace(/\./g, '&#xFEFF;.'));
  }

  /**
   * o = { base, onlySuf, anti, map: { Var: { amp, attr } } }
   */
  function compile(src, o, R) {
    if (!src.trim()) return '';
    const { tokens } = P.tokenize(src);
    const base = (o.base || '').trim(), b = base ? base.replace(/\/?$/, '/') : '';
    let out = '', last = 0;
    for (const t of tokens) {
      if (t.t === 'text' && o.anti) {
        const novo = anti(src.slice(t.s, t.e), R);
        if (novo !== src.slice(t.s, t.e)) { out += src.slice(last, t.s) + novo; last = t.e; }
      } else if (t.t === 'start' && t.name === 'img' && b) {
        const a = t.attrs.find(x => x.lname === 'src' && x.vs >= 0);
        if (!a || /^\s*(%%|data:)/i.test(a.value)) continue;
        const f = fileOf(a.value.trim());
        if (!f || (o.onlySuf && !R.sufRe.test(f))) continue;
        out += src.slice(last, a.vs) + b + f; last = a.ve;
      }
    }
    let h = out + src.slice(last);
    const decl = [];
    for (const n in (o.map || {})) {
      const { amp, attr } = o.map[n];
      if (!amp || !amp.trim()) continue;
      h = h.replace(new RegExp('%%' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '%%', 'g'), '%%=v(' + amp.trim() + ')=%%');
      decl.push('  SET ' + amp.trim() + ' = AttributeValue("' + ((attr || '').trim() || n) + '")');
    }
    return decl.length ? '%%[\n' + decl.join('\n') + '\n]%%\n' + h : h;
  }

  WB.audit = { analyze, compile, anti, fileOf };
})(window.WB = window.WB || {});
''',
    "preview": r'''/* preview.js — Preview mais próximo do que o cliente vai ver.
 *
 * - Dados de teste: resolve %%Var%%, variáveis de sistema e o AMPScript mais comum
 *   (SET com AttributeValue/literais/Concat, v(), RedirectTo). O resto fica visível como está.
 * - Modo escuro: "css" ativa os estilos @media (prefers-color-scheme: dark) e [data-ogsc]
 *   do próprio e-mail; "inv" simula a inversão automática de cores de alguns apps.
 * - Imagens bloqueadas: troca cada <img> por uma caixa com o texto alternativo.
 * Tudo aqui afeta só o preview; o código final não muda.
 */
(function (WB) {
  'use strict';
  const P = WB.parser;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

  /** Valor de exemplo a partir do nome da variável. */
  function amostra(nome) {
    const n = String(nome).toLowerCase();
    const hoje = new Date();
    if (/sobrenome|last_?name/.test(n)) return 'Silva';
    if (/nome|name/.test(n)) return 'Maria';
    if (/e-?mail/.test(n)) return 'maria.silva@exemplo.com.br';
    if (/cpf/.test(n)) return '123.456.789-09';
    if (/cnpj/.test(n)) return '12.345.678/0001-90';
    if (/valor|limite|saldo|preco|preço|parcela|fatura|vlr/.test(n)) return 'R$ 1.234,56';
    if (/data|venc|^dt|_dt/.test(n)) return hoje.toLocaleDateString('pt-BR');
    if (/agencia|agência/.test(n)) return '1234';
    if (/conta/.test(n)) return '12345-6';
    if (/cartao|cartão|final/.test(n)) return '1234';
    if (/cupom|codigo|código|cod/.test(n)) return 'ABC123';
    if (/url|link|site/.test(n)) return 'https://www.exemplo.com.br';
    if (/tel|cel|fone/.test(n)) return '(11) 91234-5678';
    if (/cidade/.test(n)) return 'São Paulo';
    if (/estado|uf/.test(n)) return 'SP';
    return 'Exemplo ' + nome;
  }

  function sistema(nome, td) {
    const n = nome.toLowerCase(), d = new Date();
    if (/url$/.test(n)) return '#';
    if (n === 'emailaddr') return td.get('emailaddr') || 'maria.silva@exemplo.com.br';
    if (n === 'xtday') return String(d.getDate());
    if (n === 'xtmonth') return MESES[d.getMonth()];
    if (n === 'xtmonthnumeric') return String(d.getMonth() + 1);
    if (n === 'xtyear') return String(d.getFullYear());
    if (/^(fromname|replyname)$/.test(n)) return 'Remetente';
    if (/^(fromaddress|replyemailaddress)$/.test(n)) return 'remetente@exemplo.com.br';
    if (/^email_?name_$/.test(n)) return 'E-mail de teste';
    if (/id$/.test(n)) return '123456';
    if (n.startsWith('member_')) return 'Exemplo';
    return '';
  }

  // ---------- Avaliador mínimo de AMPScript ----------
  function lerArgs(s) {
    const args = []; let prof = 0, q = '', ini = 0;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === q) q = ''; continue; }
      if (c === '"' || c === "'") q = c;
      else if (c === '(') prof++;
      else if (c === ')') prof--;
      else if (c === ',' && prof === 0) { args.push(s.slice(ini, i).trim()); ini = i + 1; }
    }
    const ult = s.slice(ini).trim();
    if (ult || args.length) args.push(ult);
    return args;
  }

  function avaliar(ex, ctx) {
    ex = ex.trim();
    let m;
    if ((m = /^"([^"]*)"$/.exec(ex)) || (m = /^'([^']*)'$/.exec(ex))) return m[1];
    if (/^-?\d+(\.\d+)?$/.test(ex)) return ex;
    if (/^@\w+$/.test(ex)) return ctx.vars[ex.toLowerCase()] ?? null;
    if ((m = /^\[(.+)\]$/.exec(ex))) return ctx.td.get(m[1]) ?? amostra(m[1]);
    if ((m = /^([A-Za-z_]\w*)\s*\(([\s\S]*)\)$/.exec(ex))) {
      const fn = m[1].toLowerCase(), args = lerArgs(m[2]);
      const a = i => (args[i] === undefined ? null : avaliar(args[i], ctx));
      switch (fn) {
        case 'v': case 'redirectto': case 'format': case 'formatcurrency': case 'formatnumber': case 'trim': case 'output': case 'outputline':
          return a(0);
        case 'attributevalue': { const k = a(0); return k == null ? null : (ctx.td.get(k) ?? amostra(k)); }
        case 'concat': { const p = args.map((_, i) => a(i)); return p.some(x => x == null) ? null : p.join(''); }
        case 'uppercase': { const x = a(0); return x == null ? null : x.toUpperCase(); }
        case 'lowercase': { const x = a(0); return x == null ? null : x.toLowerCase(); }
        case 'propercase': { const x = a(0); return x == null ? null : x.toLowerCase().replace(/(^|\s)\S/g, c => c.toUpperCase()); }
        case 'now': case 'systemdatetolocaldate': return new Date().toLocaleString('pt-BR');
        default: return null;
      }
    }
    if (/^[A-Za-z_]\w*$/.test(ex)) return ctx.td.get(ex) ?? null;
    return null;
  }

  /** Executa os SETs de um bloco %%[ ]%% (ignora IF/FOR; ambos os ramos aparecem no preview). */
  function executar(bloco, ctx) {
    const s = bloco.replace(/\/\*[\s\S]*?\*\//g, ' ');
    const re = /\bset\s+(@\w+)\s*=\s*/gi;
    let m;
    while ((m = re.exec(s))) {
      let i = re.lastIndex, prof = 0, q = '';
      for (; i < s.length; i++) {
        const c = s[i];
        if (q) { if (c === q) q = ''; continue; }
        if (c === '"' || c === "'") { q = c; continue; }
        if (c === '(') prof++;
        else if (c === ')') prof--;
        else if (prof === 0 && (c === '\n' || c === '\r')) break;
        else if (prof === 0 && /\s/.test(c) && /^\s+(set|var|if|endif|else|elseif|for|next|then)\b/i.test(s.slice(i))) break;
      }
      const v = avaliar(s.slice(re.lastIndex, i), ctx);
      ctx.vars[m[1].toLowerCase()] = v == null ? '[' + m[1] + ']' : v;
      re.lastIndex = i;
    }
  }

  function resolverAmp(h, tdObj, isSys) {
    isSys = isSys || (() => false);
    const td = { get: k => { const v = tdObj[String(k).toLowerCase()]; return v === undefined || v === '' ? null : v; } };
    const ctx = { vars: {}, td };
    let n = 0;
    h = h.replace(/<script\b[^>]*language\s*=\s*["']?ampscript["']?[^>]*>([\s\S]*?)<\/script>/gi, (m, b) => { executar(b, ctx); n++; return ''; });
    h = h.replace(/%%\[([\s\S]*?)\]%%/g, (m, b) => { executar(b, ctx); n++; return ''; });
    h = h.replace(/%%=([\s\S]*?)=%%/g, (m, ex) => { const v = avaliar(ex, ctx); if (v == null) return m; n++; return esc(v); });
    h = h.replace(/%%([A-Za-z_]\w*)%%/g, (m, nome) => {
      n++;
      if (isSys(nome)) return esc(sistema(nome, td));
      return esc(td.get(nome) ?? amostra(nome));
    });
    return { html: h, n };
  }

  // ---------- Imagens bloqueadas ----------
  function bloquearImagens(h) {
    const { tokens } = P.tokenize(h);
    let out = '', last = 0;
    const attr = (t, n) => { const a = t.attrs.find(x => x.lname === n); return a ? (a.value ?? '') : null; };
    const dim = v => v == null ? null : /^\d+(\.\d+)?$/.test(v.trim()) ? v.trim() + 'px' : /^\d+(\.\d+)?(px|%)$/.test(v.trim()) ? v.trim() : null;
    for (const t of tokens) {
      if (t.t === 'raw' && t.parent === 'style') {
        const css = h.slice(t.s, t.e).replace(/(background(?:-image)?\s*:[^;}]*?)url\([^)]*\)/gi, '$1none');
        out += h.slice(last, t.s) + css; last = t.e;
      }
      if (t.t !== 'start') continue;
      if (t.name === 'img') {
        const alt = attr(t, 'alt'), st = attr(t, 'style') || '';
        const w = dim(attr(t, 'width')) || (/(?:^|;)\s*width\s*:\s*([\d.]+(?:px|%))/i.exec(st) || [])[1];
        const hh = dim(attr(t, 'height'));
        const disp = /display\s*:\s*block/i.test(st) ? 'block' : 'inline-block';
        const box = `display:${disp};box-sizing:border-box;${w ? 'width:' + w + ';' : ''}max-width:100%;${hh ? 'height:' + hh + ';' : 'min-height:28px;'}` +
          'border:1px dashed #98a2b3;background:#eef1f5;color:#475467;font:12px/1.35 Arial,Helvetica,sans-serif;padding:6px;overflow:hidden;vertical-align:middle;text-align:center;word-break:break-word';
        const conteudo = alt === null ? '<span style="color:#b8102c;font-weight:bold">Imagem sem alt</span>' : alt.replace(/</g, '&lt;');
        out += h.slice(last, t.s) + `<span role="img" style="${box}">${conteudo}</span>`;
        last = t.e;
        continue;
      }
      const bg = t.attrs.filter(a => a.lname === 'background');
      const sty = t.attrs.find(a => a.lname === 'style' && a.vs >= 0 && /url\(/i.test(a.value));
      if (!bg.length && !sty) continue;
      // reescreve só os atributos afetados, mantendo o resto da tag
      const cortes = [...bg.map(a => ({ s: a.ns, e: a.ae, txt: '' })),
        ...(sty ? [{ s: sty.vs, e: sty.ve, txt: sty.value.replace(/url\([^)]*\)/gi, 'none') }] : [])].sort((a, b) => a.s - b.s);
      for (const c of cortes) { out += h.slice(last, c.s) + c.txt; last = c.e; }
    }
    return out + h.slice(last);
  }

  // ---------- Modo escuro ----------
  function injetarCss(h, css) {
    const tag = '<style data-wb-preview>' + css + '</style>';
    if (/<\/head>/i.test(h)) return h.replace(/<\/head>/i, tag + '</head>');
    if (/<body\b/i.test(h)) return h.replace(/<body\b/i, tag + '$&');
    return tag + h;
  }

  function modoEscuro(h, modo) {
    if (modo === 'inv') {
      const inv = 'filter:invert(1) hue-rotate(180deg)';
      return { html: injetarCss(h, `html{${inv};background:#fff}img,picture,video,[background],[style*="url("]{${inv}}`), dark: true };
    }
    let n = 0;
    h = h.replace(/\(\s*prefers-color-scheme\s*:\s*dark\s*\)/gi, () => { n++; return '(min-width:0px)'; })
      .replace(/\(\s*prefers-color-scheme\s*:\s*light\s*\)/gi, '(max-width:0px)');
    const ogsc = /\[data-ogs[cb]\]/i.test(h);
    if (ogsc) h = /<html\b/i.test(h) ? h.replace(/<html\b/i, '$& data-ogsc data-ogsb') : '<div data-ogsc data-ogsb>' + h + '</div>';
    h = injetarCss(h, ':root{color-scheme:dark}');
    return { html: h, dark: n > 0 || ogsc };
  }

  /**
   * o = { dados: bool, td: { nome-minúsculo: valor }, isSys: fn, imagens: bool, escuro: 'off'|'css'|'inv' }
   * Devolve { html, notas: [] }.
   */
  function gerar(h, o) {
    const notas = [];
    if (!h) return { html: '', notas };
    if (o.dados) {
      const r = resolverAmp(h, o.td || {}, o.isSys);
      h = r.html;
      notas.push(r.n ? 'Variáveis e AMPScript simulados com dados de teste. Blocos IF mostram todos os ramos.' : 'Nenhuma variável para simular.');
    } else notas.push('AMPScript exibido como texto, sem dados de teste.');
    if (o.imagens) { h = bloquearImagens(h); notas.push('Imagens bloqueadas: cada caixa mostra o texto do alt.'); }
    if (o.escuro && o.escuro !== 'off') {
      const r = modoEscuro(h, o.escuro);
      h = r.html;
      if (o.escuro === 'css') notas.push(r.dark ? 'Modo escuro com os estilos do próprio e-mail (Apple Mail, iOS).' : 'O e-mail não define estilos de modo escuro. Clientes podem inverter as cores por conta própria; teste a opção de inversão.');
      else notas.push('Modo escuro por inversão automática (aproximação de Gmail app e Outlook).');
    }
    return { html: h, notas };
  }

  WB.preview = { gerar, amostra, resolverAmp, bloquearImagens, modoEscuro };
})(window.WB = window.WB || {});
''',
    "report": r'''/* report.js — Relatório de homologação (texto e HTML para imprimir em PDF). */
(function (WB) {
  'use strict';
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const NOME = { bloq: 'Bloqueador', alerta: 'Alerta', ok: 'OK' };
  const STATUS = { reprovado: 'REPROVADO', alertas: 'APROVADO COM ALERTAS', aprovado: 'APROVADO' };
  const LINK_ST = { ok: 'OK', vazio: 'Vazio', hash: 'Apenas #', js: 'javascript:' };

  const linhas = locs => {
    const ls = [...new Set((locs || []).filter(l => l && l.ln).map(l => l.ln))];
    return ls.length ? (ls.length > 1 ? 'linhas ' : 'linha ') + ls.slice(0, 40).join(', ') + (ls.length > 40 ? ` e mais ${ls.length - 40}` : '') : '';
  };
  const data = d => d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const kb = A => A.kb.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' KB';
  const resumo = A => STATUS[A.status] + (A.bloq ? ` – ${A.bloq} bloqueador(es)` : '') + (A.alerta ? `${A.bloq ? ',' : ' –'} ${A.alerta} alerta(s)` : '');

  function texto(A, m) {
    const L = [], pad = (k, v) => L.push((k + ':').padEnd(14) + (v || '—'));
    L.push('RELATÓRIO DE HOMOLOGAÇÃO – SFMC WORKBENCH', '='.repeat(48));
    pad('Campanha', m.campanha); pad('Chamado', m.chamado); pad('Responsável', m.responsavel);
    pad('Gerado em', data(m.geradoEm));
    pad('Arquivo', m.arquivo || 'HTML colado na ferramenta');
    pad('Tamanho', `${kb(A)}, ${A.linhas} linhas`);
    pad(m.hashAlg, m.hash);
    pad('Regras', `${m.regras.fonte}${m.regras.personalizada ? ' + ajustes locais' : ''} (assinatura ${m.regras.assinatura})`);
    L.push('', 'RESULTADO: ' + resumo(A), '');
    L.push(`Imagens: ${A.imgs.length}   Links: ${A.links.length}   Variáveis: ${Object.keys(A.vars).length}   Domínios em texto: ${A.dn}`, '');

    for (const nv of ['bloq', 'alerta', 'ok']) {
      const itens = A.ck.filter(c => c.l === nv);
      if (!itens.length) continue;
      L.push({ bloq: 'BLOQUEADORES', alerta: 'ALERTAS', ok: 'APROVADOS' }[nv], '-'.repeat(48));
      itens.forEach(c => {
        L.push(`[${NOME[nv]}] ${c.t}`, `    ${c.d}`);
        const ls = linhas(c.locs); if (ls && nv !== 'ok') L.push(`    Onde: ${ls}`);
      });
      L.push('');
    }
    if (A.links.length) {
      L.push(`LINKS (${A.links.length})`, '-'.repeat(48));
      A.links.forEach((l, i) => L.push(`${String(i + 1).padStart(3)}  L${String(l.loc?.ln ?? '?').padEnd(5)} ${LINK_ST[l.st].padEnd(11)} ${l.href ?? '(sem href)'}`));
      L.push('');
    }
    if (A.imgs.length) {
      L.push(`IMAGENS (${A.imgs.length})`, '-'.repeat(48));
      A.imgs.forEach(i => L.push(`  L${String(i.loc?.ln ?? '?').padEnd(5)} ${i.file || '(sem src)'}  |  alt: ${i.alt === null ? 'AUSENTE' : i.alt || '(vazio)'}`));
      L.push('');
    }
    const vs = Object.keys(A.vars);
    if (vs.length) {
      L.push('VARIÁVEIS', '-'.repeat(48));
      vs.forEach(n => { const mp = (m.map || {})[n]; L.push(`  %%${n}%%  ${A.vars[n].n} uso(s)` + (mp && mp.amp ? `  ->  SET ${mp.amp} = AttributeValue("${mp.attr || n}")` : '  (mantida como %%' + n + '%%)')); });
      L.push('');
    }
    L.push('Relatório gerado automaticamente pelo SFMC Workbench. Confira o resultado no preview antes de publicar.');
    return L.join('\r\n');
  }

  function html(A, m) {
    const cor = { reprovado: '#b8102c', alertas: '#8a5a00', aprovado: '#12703a' }[A.status];
    const linha = (k, v) => `<tr><th>${k}</th><td>${esc(v || '—')}</td></tr>`;
    const itens = A.ck.map(c => `<li class="${c.l}"><b>${NOME[c.l]}: ${esc(c.t)}</b><span>${esc(c.d)}</span>${c.l !== 'ok' && linhas(c.locs) ? `<em>Onde: ${esc(linhas(c.locs))}</em>` : ''}</li>`).join('');
    const lk = A.links.map((l, i) => `<tr><td>${i + 1}</td><td>${l.loc?.ln ?? ''}</td><td class="m">${esc(l.href ?? '(sem href)')}</td><td>${LINK_ST[l.st]}</td></tr>`).join('');
    const im = A.imgs.map(i => `<tr><td>${i.loc?.ln ?? ''}</td><td class="m">${esc(i.file || '(sem src)')}</td><td>${i.alt === null ? '<b style="color:#b8102c">ausente</b>' : esc(i.alt || '(vazio)')}</td></tr>`).join('');
    const titulo = 'Homologacao_' + String(m.campanha || m.arquivo || 'email').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_').slice(0, 50) + '_' + m.geradoEm.toLocaleDateString('pt-BR').split('/').reverse().join('-');
    return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>
@page{size:A4;margin:14mm}
body{font:11pt/1.45 "IBM Plex Sans",Arial,sans-serif;color:#14202e;margin:0}
h1{font-size:16pt;margin:0 0 2mm}h2{font-size:12pt;margin:7mm 0 2mm;border-bottom:1px solid #d6dde7;padding-bottom:1mm}
.st{display:inline-block;padding:2mm 4mm;border:1.5px solid ${cor};color:${cor};font-weight:600;border-radius:2mm;margin:2mm 0 4mm}
table{border-collapse:collapse;width:100%;font-size:9.5pt}th,td{text-align:left;padding:1.2mm 2mm;border-bottom:1px solid #e3e8ef;vertical-align:top}
.meta th{width:32mm;color:#5b6b7e;font-weight:500}.m{font-family:"IBM Plex Mono",Consolas,monospace;font-size:8.5pt;word-break:break-all}
ul{list-style:none;padding:0;margin:0}li{border-left:4px solid;padding:1.5mm 3mm;margin:0 0 2mm;break-inside:avoid}
li b{display:block}li span{display:block;color:#3c4a5b}li em{display:block;font-style:normal;font-size:9pt;color:#5b6b7e}
li.bloq{border-color:#b8102c}li.bloq b{color:#b8102c}li.alerta{border-color:#c48a00}li.alerta b{color:#8a5a00}li.ok{border-color:#12703a}li.ok b{color:#12703a}
.kp{color:#5b6b7e}footer{margin-top:8mm;font-size:8.5pt;color:#5b6b7e}
</style></head><body>
<h1>Relatório de homologação</h1>
<div class="st">${esc(resumo(A))}</div>
<table class="meta">${linha('Campanha', m.campanha)}${linha('Chamado', m.chamado)}${linha('Responsável', m.responsavel)}${linha('Gerado em', data(m.geradoEm))}${linha('Arquivo', m.arquivo || 'HTML colado na ferramenta')}${linha('Tamanho', `${kb(A)}, ${A.linhas} linhas`)}${linha(m.hashAlg, m.hash)}${linha('Regras', `${m.regras.fonte}${m.regras.personalizada ? ' + ajustes locais' : ''} (assinatura ${m.regras.assinatura})`)}</table>
<p class="kp">Imagens: ${A.imgs.length} &nbsp; Links: ${A.links.length} &nbsp; Variáveis: ${Object.keys(A.vars).length} &nbsp; Domínios em texto: ${A.dn}</p>
<h2>Quality Gate</h2><ul>${itens}</ul>
${lk ? `<h2>Links (${A.links.length})</h2><table><thead><tr><th>#</th><th>Linha</th><th>href</th><th>Status</th></tr></thead><tbody>${lk}</tbody></table>` : ''}
${im ? `<h2>Imagens (${A.imgs.length})</h2><table><thead><tr><th>Linha</th><th>Arquivo</th><th>Alt</th></tr></thead><tbody>${im}</tbody></table>` : ''}
<footer>Relatório gerado automaticamente pelo SFMC Workbench. Confira o resultado no preview antes de publicar.</footer>
</body></html>`;
  }

  async function hash(src) {
    try {
      if (window.crypto && crypto.subtle) {
        const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(src));
        return { alg: 'SHA-256', valor: [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('') };
      }
    } catch (e) { /* cai no FNV */ }
    let h = 0x811c9dc5;
    for (let i = 0; i < src.length; i++) { h ^= src.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return { alg: 'FNV-1a', valor: (h >>> 0).toString(16).padStart(8, '0') };
  }

  WB.report = { texto, html, hash, resumo };
})(window.WB = window.WB || {});
''',
    "editor": r'''/* editor.js — Editor de código com CodeMirror 5 (pasta vendor/) e destaque de AMPScript.
 * Se o CodeMirror não carregar, cai para um textarea com numeração de linhas.
 *
 * API: get(), set(texto, {cursor}), ir(s, e), marcar(locs), proximo(dir), refresh(), focus()
 */
(function (WB) {
  'use strict';
  const CM = window.CodeMirror;

  const FRASES = {
    'Search:': 'Buscar:', '(Use /re/ syntax for regexp search)': '(use /regex/ para expressão regular)',
    'Replace:': 'Substituir:', 'Replace all:': 'Substituir todos:', 'Replace with:': 'Substituir por:', 'With:': 'Por:',
    'Replace?': 'Substituir?', 'Yes': 'Sim', 'No': 'Não', 'All': 'Todos', 'Stop': 'Parar',
    'Jump to line:': 'Ir para a linha:', '(Use line:column or scroll% syntax)': '(use linha:coluna)'
  };

  if (CM && !CM.modes['ampscript-html']) {
    const KW = /^(set|var|if|then|else|elseif|endif|for|to|downto|do|next|and|or|not)\b/i;
    CM.defineMode('ampscript-html', config => CM.overlayMode(CM.getMode(config, 'htmlmixed'), {
      startState: () => ({ blk: 0, str: '', cmt: false }),
      copyState: s => ({ blk: s.blk, str: s.str, cmt: s.cmt }),
      token(stream, st) {
        if (!st.blk) {
          if (stream.match('%%[')) { st.blk = 1; return 'amp-delim'; }
          if (stream.match('%%=')) { st.blk = 2; return 'amp-delim'; }
          if (stream.match(/^%%[A-Za-z_]\w*%%/)) return 'amp-pvar';
          stream.next();
          while (!stream.eol() && stream.peek() !== '%') stream.next();
          return null;
        }
        if (st.cmt) { if (stream.skipTo('*/')) { stream.match('*/'); st.cmt = false; } else stream.skipToEnd(); return 'amp-comment'; }
        if (st.str) {
          while (!stream.eol()) { if (stream.next() === st.str) { st.str = ''; break; } }
          return 'amp-string';
        }
        if ((st.blk === 1 && stream.match(']%%')) || (st.blk === 2 && stream.match('=%%'))) { st.blk = 0; return 'amp-delim'; }
        if (stream.eatSpace()) return 'amp';
        if (stream.match('/*')) { st.cmt = true; return 'amp-comment'; }
        const c = stream.peek();
        if (c === '"' || c === "'") { stream.next(); st.str = c; while (!stream.eol()) { if (stream.next() === c) { st.str = ''; break; } } return 'amp-string'; }
        if (stream.match(/^@\w+/)) return 'amp-var';
        if (stream.match(KW)) return 'amp-keyword';
        if (stream.match(/^[A-Za-z_]\w*(?=\s*\()/)) return 'amp-fn';
        if (stream.match(/^-?\d+(\.\d+)?/)) return 'amp-number';
        stream.next();
        return 'amp';
      }
    }, false));
  }

  function criarCM(host, o) {
    const cm = CM(host, {
      value: '', mode: 'ampscript-html', theme: 'wb', lineNumbers: true, lineWrapping: false,
      gutters: ['wb-alertas', 'CodeMirror-linenumbers'], matchTags: { bothTags: true }, styleActiveLine: true,
      indentUnit: 2, tabSize: 2, dragDrop: false, undoDepth: 1, phrases: FRASES,
      readOnly: !!o.readOnly, screenReaderLabel: o.rotulo || 'Editor de código', placeholder: o.placeholder || '',
      extraKeys: Object.assign({
        'Ctrl-F': 'findPersistent', 'Cmd-F': 'findPersistent', 'Alt-G': 'jumpToLine',
        'Ctrl-Z': () => o.desfazer && o.desfazer(), 'Cmd-Z': () => o.desfazer && o.desfazer(),
        'Ctrl-Y': () => o.refazer && o.refazer(), 'Shift-Ctrl-Z': () => o.refazer && o.refazer(), 'Shift-Cmd-Z': () => o.refazer && o.refazer(),
        'F8': () => api.proximo(1), 'Shift-F8': () => api.proximo(-1)
      }, o.teclas || {})
    });
    let interno = false, flash = null, locs = [], sbB = null, sbA = null;
    cm.on('changes', (c, chs) => { if (!interno && chs.some(x => x.origin !== 'wbset')) o.onChange && o.onChange(); });
    cm.on('gutterClick', (c, line, gutter) => {
      if (gutter !== 'wb-alertas') return;
      const l = locs.find(x => cm.posFromIndex(x.s).line === line);
      if (l) api.ir(l.s, l.e);
    });

    const api = {
      cm,
      get: () => cm.getValue(),
      set(texto, op) {
        const atual = cm.getValue();
        if (atual === texto) return;
        let a = 0; const la = atual.length, lb = texto.length;
        while (a < la && a < lb && atual.charCodeAt(a) === texto.charCodeAt(a)) a++;
        let b = 0;
        while (b < la - a && b < lb - a && atual.charCodeAt(la - 1 - b) === texto.charCodeAt(lb - 1 - b)) b++;
        interno = true;
        cm.operation(() => {
          cm.replaceRange(texto.slice(a, lb - b), cm.posFromIndex(a), cm.posFromIndex(la - b), 'wbset');
          if (op && op.cursor) { const p = cm.posFromIndex(a + (lb - b - a)); cm.setCursor(p); cm.scrollIntoView(p, 80); }
          if (op && op.topo) { cm.setCursor({ line: 0, ch: 0 }); cm.scrollTo(0, 0); }
        });
        interno = false;
      },
      ir(s, e) {
        const de = cm.posFromIndex(s), ate = cm.posFromIndex(Math.max(e, s));
        cm.focus();
        cm.setSelection(de, ate);
        cm.scrollIntoView({ from: de, to: ate }, Math.round(cm.getScrollInfo().clientHeight / 3));
        if (flash) flash.clear();
        flash = cm.markText(de, e > s ? ate : { line: de.line, ch: de.ch + 1 }, { className: 'wb-flash' });
        const f = flash; setTimeout(() => { f.clear(); if (flash === f) flash = null; }, 2400);
      },
      /** locs: [{ s, e, nivel, titulo }] */
      marcar(lista) {
        locs = [...lista].sort((a, b) => a.s - b.s);
        cm.operation(() => {
          cm.clearGutter('wb-alertas');
          const porLinha = new Map();
          for (const l of locs) {
            const ln = cm.posFromIndex(l.s).line, cur = porLinha.get(ln);
            if (!cur) porLinha.set(ln, { nivel: l.nivel, titulos: [l.titulo] });
            else { if (l.nivel === 'bloq') cur.nivel = 'bloq'; if (!cur.titulos.includes(l.titulo)) cur.titulos.push(l.titulo); }
          }
          porLinha.forEach((v, ln) => {
            const d = document.createElement('div');
            d.className = 'wb-dot ' + v.nivel;
            d.title = v.titulos.join('\n') + '\n(clique para selecionar)';
            cm.setGutterMarker(ln, 'wb-alertas', d);
          });
        });
        if (cm.annotateScrollbar) {
          sbB = sbB || cm.annotateScrollbar('wb-sb-bloq');
          sbA = sbA || cm.annotateScrollbar('wb-sb-alerta');
          const r = n => locs.filter(l => l.nivel === n).map(l => ({ from: cm.posFromIndex(l.s), to: cm.posFromIndex(Math.max(l.e, l.s)) }));
          sbB.update(r('bloq')); sbA.update(r('alerta'));
        }
      },
      proximo(dir) {
        if (!locs.length) return false;
        const cur = cm.indexFromPos(cm.getCursor(dir > 0 ? 'to' : 'from'));
        let alvo = dir > 0 ? locs.find(l => l.s >= cur && !(l.s === cur && cm.somethingSelected())) : [...locs].reverse().find(l => l.s < cur);
        if (!alvo) alvo = dir > 0 ? locs[0] : locs[locs.length - 1];
        api.ir(alvo.s, alvo.e);
        return true;
      },
      refresh: () => cm.refresh(),
      focus: () => cm.focus()
    };
    return api;
  }

  /** Alternativa sem CodeMirror: textarea com numeração de linhas. */
  function criarTextarea(host, o) {
    host.classList.add('ide');
    host.innerHTML = '<pre class="gut" aria-hidden="true">1</pre><textarea spellcheck="false" wrap="off"></textarea>';
    const ta = host.querySelector('textarea'), gut = host.querySelector('.gut');
    ta.setAttribute('aria-label', o.rotulo || 'Editor de código');
    if (o.readOnly) ta.readOnly = true;
    if (o.placeholder) ta.placeholder = o.placeholder;
    let locs = [];
    const numerar = () => { gut.textContent = Array.from({ length: Math.max(1, ta.value.split('\n').length) }, (_, i) => i + 1).join('\n'); };
    ta.addEventListener('input', () => { numerar(); o.onChange && o.onChange(); });
    ta.addEventListener('scroll', () => { gut.scrollTop = ta.scrollTop; });
    ta.addEventListener('keydown', e => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); o.desfazer && o.desfazer(); }
      else if (mod && (e.key.toLowerCase() === 'y' || (e.key.toLowerCase() === 'z' && e.shiftKey))) { e.preventDefault(); o.refazer && o.refazer(); }
      else if (e.key === 'F8') { e.preventDefault(); api.proximo(e.shiftKey ? -1 : 1); }
    });
    const api = {
      cm: null,
      get: () => ta.value,
      set(t, op) { if (ta.value === t) return; ta.value = t; numerar(); if (op && op.cursor) ta.setSelectionRange(t.length, t.length); if (op && op.topo) { ta.setSelectionRange(0, 0); ta.scrollTop = 0; } },
      ir(s, e) {
        ta.focus(); ta.setSelectionRange(s, Math.max(s, e));
        const linha = ta.value.slice(0, s).split('\n').length - 1;
        ta.scrollTop = Math.max(0, linha * parseFloat(getComputedStyle(ta).lineHeight || 19) - ta.clientHeight / 3);
      },
      marcar(l) { locs = [...l].sort((a, b) => a.s - b.s); },
      proximo(dir) {
        if (!locs.length) return false;
        const cur = dir > 0 ? ta.selectionEnd : ta.selectionStart;
        const alvo = (dir > 0 ? locs.find(l => l.s > cur) : [...locs].reverse().find(l => l.s < cur)) || (dir > 0 ? locs[0] : locs[locs.length - 1]);
        api.ir(alvo.s, alvo.e); return true;
      },
      refresh() {}, focus: () => ta.focus()
    };
    return api;
  }

  WB.editor = {
    disponivel: !!CM,
    criar: (host, o) => (CM ? criarCM : criarTextarea)(host, o || {})
  };
})(window.WB = window.WB || {});
''',
    "app": r'''/* app.js — Interface do SFMC Workbench. */
(function (WB) {
  'use strict';
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const K = { rascunho: 'sfmcwb-rascunho', preview: 'sfmcwb-preview' };
  const ROT_OUT = 'Edição do código final';
  const NOME_NV = { bloq: 'Bloqueador', alerta: 'Alerta', ok: 'OK' };
  const hora = d => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  // ================= Estado =================
  const VAZIO = () => ({ src: '', out: '', outGerado: '', outManual: false, base: '', onlySuf: true, anti: true, map: {}, teste: {}, arquivo: '', meta: { campanha: '', chamado: '', responsavel: '' } });
  let S = VAZIO(), A = null, varKey = '';
  let regras = WB.rules.carregar();
  let R = WB.rules.compilar(regras.cfg);
  const PV = Object.assign({ mobile: false, escuro: 'off', imagens: false, dados: true }, (() => { try { return JSON.parse(localStorage.getItem(K.preview)) || {}; } catch (e) { return {}; } })());

  // ================= Avisos =================
  function toast(msg, o = {}) {
    const d = document.createElement('div');
    d.className = 't' + (o.erro ? ' e' : '');
    const sp = document.createElement('span'); sp.textContent = msg; d.append(sp);
    if (o.acao) { const b = document.createElement('button'); b.textContent = o.acao; b.onclick = () => { d.remove(); o.fn(); }; d.append(b); }
    $('#toasts').append(d);
    setTimeout(() => d.remove(), o.acao ? 7000 : 2800);
  }

  function confirmar({ titulo, texto, ok }) {
    const d = $('#dlg');
    if (typeof d.showModal !== 'function') return Promise.resolve(window.confirm(titulo + '\n\n' + texto));
    $('#dlgT').textContent = titulo; $('#dlgP').textContent = texto; $('#dlgOk').textContent = ok;
    return new Promise(res => {
      const fim = v => { $('#dlgOk').onclick = $('#dlgNo').onclick = d.oncancel = null; d.close(); res(v); };
      $('#dlgOk').onclick = () => fim(true);
      $('#dlgNo').onclick = () => fim(false);
      d.oncancel = e => { e.preventDefault(); fim(false); };
      d.showModal(); $('#dlgNo').focus();
    });
  }

  function baixar(nome, conteudo, tipo) {
    const url = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
    const a = document.createElement('a'); a.href = url; a.download = nome; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  async function copiar(texto) {
    try { await navigator.clipboard.writeText(texto); return true; }
    catch (e) {
      const t = document.createElement('textarea'); t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.append(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok;
    }
  }

  // ================= Desfazer / refazer =================
  const H = {
    pilha: [], i: -1, timer: null, rotuloPend: '',
    registrar(rotulo) {
      clearTimeout(this.timer); this.timer = null;
      garantirRun();
      const f = JSON.stringify(S);
      if (this.pilha[this.i] && this.pilha[this.i].f === f) return;
      this.pilha.splice(this.i + 1);
      this.pilha.push({ f, rotulo });
      if (this.pilha.length > 80) this.pilha.shift();
      this.i = this.pilha.length - 1;
      botoesHist();
    },
    agendar(rotulo) { clearTimeout(this.timer); this.rotuloPend = rotulo; this.timer = setTimeout(() => this.registrar(rotulo), 700); },
    pendente() { if (this.timer) this.registrar(this.rotuloPend); },
    desfazer() {
      this.pendente();
      if (this.i <= 0) { toast('Nada para desfazer'); return; }
      const r = this.pilha[this.i].rotulo; this.i--;
      restaurar(JSON.parse(this.pilha[this.i].f)); botoesHist(); toast('Desfeito: ' + r);
    },
    refazer() {
      this.pendente();
      if (this.i >= this.pilha.length - 1) { toast('Nada para refazer'); return; }
      this.i++;
      restaurar(JSON.parse(this.pilha[this.i].f)); botoesHist(); toast('Refeito: ' + this.pilha[this.i].rotulo);
    }
  };
  function botoesHist() {
    $('#undo').disabled = H.i <= 0 && !H.timer;
    $('#redo').disabled = H.i >= H.pilha.length - 1;
    $('#undo').title = H.i > 0 ? 'Desfazer: ' + H.pilha[H.i].rotulo + ' (Ctrl+Z)' : 'Desfazer (Ctrl+Z)';
    $('#redo').title = H.i < H.pilha.length - 1 ? 'Refazer: ' + H.pilha[H.i + 1].rotulo + ' (Ctrl+Y)' : 'Refazer (Ctrl+Y)';
  }

  /**
   * Toda alteração do projeto passa por aqui.
   * discreto: ação única (carregar, limpar…) vira um passo próprio no histórico.
   * semRun: não reanalisa (ex.: edição do código final, dado de teste).
   */
  function mudar(rotulo, fn, o = {}) {
    if (o.discreto || (H.timer && H.rotuloPend !== rotulo)) H.pendente();
    if (S.outManual && rotulo !== ROT_OUT && !o.semRun) H.registrar(ROT_OUT); // guarda as edições manuais antes de regerar
    fn();
    if (o.semRun) { paint(); salvarRascunho(); }
    else if (o.discreto) run(); else agendarRun();
    if (o.discreto) H.registrar(rotulo); else { H.agendar(rotulo); $('#undo').disabled = false; }
  }

  function restaurar(s) {
    S = Object.assign(VAZIO(), s);
    edSrc.set(S.src, { cursor: true });
    edOut.set(S.out);
    sincronizarCampos();
    varKey = '\u0000';
    run({ manterOut: true });
  }

  function sincronizarCampos() {
    $('#base').value = S.base; $('#onlysuf').checked = S.onlySuf; $('#anti').checked = S.anti;
    $('#mCamp').value = S.meta.campanha; $('#mCham').value = S.meta.chamado; $('#mResp').value = S.meta.responsavel;
  }

  // ================= Rascunho =================
  let draftTimer;
  function salvarRascunho() {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(() => {
      try {
        if (!S.src && !S.out) { localStorage.removeItem(K.rascunho); $('#draftSt').textContent = ''; return; }
        localStorage.setItem(K.rascunho, JSON.stringify({ v: 1, ts: Date.now(), s: S }));
        $('#draftSt').textContent = 'Rascunho salvo às ' + hora(new Date());
      } catch (e) {
        $('#draftSt').textContent = 'Rascunho não salvo: o navegador bloqueou ou encheu o armazenamento local';
      }
    }, 800);
  }

  // ================= Editores =================
  const edSrc = WB.editor.criar($('#edSrc'), {
    rotulo: 'HTML de entrada', placeholder: 'Cole aqui o HTML bruto do e-mail ou arraste um arquivo .html, .htm ou .txt',
    onChange: () => mudar('Edição do HTML', () => { S.src = edSrc.get(); }),
    desfazer: () => H.desfazer(), refazer: () => H.refazer()
  });
  const edOut = WB.editor.criar($('#edOut'), {
    rotulo: 'Código final',
    onChange: () => mudar(ROT_OUT, () => { S.out = edOut.get(); S.outManual = S.out !== S.outGerado; atualizarManual(); }, { semRun: true }),
    desfazer: () => H.desfazer(), refazer: () => H.refazer(),
    teclas: { 'F8': false, 'Shift-F8': false }
  });
  if (!WB.editor.disponivel) toast('Editor avançado indisponível (pasta vendor/ ausente). Usando o editor simples.', { erro: true });

  // ================= Análise =================
  let runTimer = null;
  function agendarRun() { clearTimeout(runTimer); runTimer = setTimeout(run, 150); }
  function garantirRun() { if (runTimer) run(); }

  function run(o = {}) {
    clearTimeout(runTimer); runTimer = null;
    const h = S.src;
    $('#cSrc').textContent = h.length.toLocaleString('pt-BR') + ' caracteres';
    if (!h.trim()) {
      A = null; varKey = ''; S.map = {};
      ['kImg', 'kLink', 'kVar', 'kAl'].forEach(k => { $('#' + k).textContent = 0; });
      $('#st').className = 'pill'; $('#st').textContent = 'Aguardando HTML'; $('#nQ').hidden = true;
      $('#qg').innerHTML = '<li class="alerta"><b>Nenhum HTML para analisar</b>Cole um e-mail ou carregue um arquivo na aba Entrada.</li>';
      ['lkT', 'imT', 'vrT'].forEach(k => { $('#' + k).innerHTML = ''; });
      $('#antiN').textContent = '';
    } else {
      try { A = WB.audit.analyze(h, R); renderStatic(); }
      catch (e) {
        console.error(e); A = null;
        $('#st').className = 'pill bad'; $('#st').textContent = 'Erro na análise';
        toast('A análise falhou: ' + e.message, { erro: true });
      }
    }
    if (!o.manterOut) build();
    marcarEditor();
    paint();
    salvarRascunho();
  }

  function build() {
    const g = WB.audit.compile(S.src, { base: S.base, onlySuf: S.onlySuf, anti: S.anti, map: S.map }, R);
    if (S.outManual && g !== S.out) toast('As edições manuais do código final foram substituídas.', { acao: 'Desfazer', fn: () => H.desfazer() });
    S.out = g; S.outGerado = g; S.outManual = false;
    edOut.set(g);
    atualizarManual();
  }
  function atualizarManual() { $('#manualN').hidden = !S.outManual; }

  function marcarEditor() {
    const locs = [];
    if (A) A.ck.forEach(c => { if (c.l !== 'ok') c.locs.forEach(l => locs.push({ s: l.s, e: l.e, nivel: c.l, titulo: NOME_NV[c.l] + ': ' + c.t })); });
    edSrc.marcar(locs);
  }

  // ================= Renderização =================
  const lnBtn = (attrs, ln) => ln ? `<button class="ln" ${attrs} title="Ir para a linha ${ln}">${ln}</button>` : '';

  function renderStatic() {
    const a = A;
    $('#kImg').textContent = a.imgs.length; $('#kLink').textContent = a.links.length;
    $('#kVar').textContent = Object.keys(a.vars).length; $('#kAl').textContent = a.bloq + a.alerta;
    const st = $('#st');
    st.className = 'pill ' + (a.bloq ? 'bad' : a.alerta ? 'warn' : 'good');
    st.textContent = a.bloq ? 'Reprovado: ' + a.bloq + ' bloqueador(es)' : a.alerta ? 'Aprovado com ' + a.alerta + ' alerta(s)' : 'Aprovado';
    const q = $('#nQ'); q.hidden = !a.bloq; q.textContent = a.bloq;

    $('#qg').innerHTML = a.ck.map((c, ci) => {
      const ls = []; const vistos = new Set();
      c.locs.forEach((l, k) => { if (!vistos.has(l.ln)) { vistos.add(l.ln); ls.push(lnBtn(`data-c="${ci}" data-k="${k}"`, l.ln)); } });
      const extra = ls.length > 30 ? `<span class="mu">e mais ${ls.length - 30}</span>` : '';
      const onde = ls.length ? `<div class="locs"><span class="mu">${c.l === 'ok' ? 'Onde' : ls.length > 1 ? 'Linhas' : 'Linha'}</span>${ls.slice(0, 30).join('')}${extra}</div>` : '';
      return `<li class="${c.l}"><b>${NOME_NV[c.l]}: ${esc(c.t)}</b>${esc(c.d)}${onde}</li>`;
    }).join('') || '<li class="ok"><b>Nenhuma regra ativa</b>Todas as regras estão desligadas na aba Regras.</li>';

    const ls = { ok: ['ok', 'OK'], vazio: ['bloq', 'Vazio'], hash: ['alerta', 'Apenas #'], js: ['bloq', 'javascript:'] };
    $('#lkT').innerHTML = a.links.map((l, i) => `<tr><td>${i + 1}</td><td>${lnBtn(`data-l="${i}"`, l.loc && l.loc.ln)}</td><td class="m">${l.href === null ? '(sem href)' : esc(l.href) || '(vazio)'}</td><td>${esc(l.texto) || '<span class="mu">(sem texto)</span>'}</td><td><span class="b ${ls[l.st][0]}">${ls[l.st][1]}</span></td></tr>`).join('')
      || '<tr><td colspan="5" class="mu">Nenhum link encontrado.</td></tr>';
    $('#antiN').textContent = a.dn ? a.dn + ' domínio(s) em texto puro detectado(s).' : 'Nenhum domínio em texto puro detectado.';
    renderImgs();

    const key = Object.keys(a.vars).map(n => n + ':' + a.vars[n].n).join('|');
    if (key !== varKey) {
      varKey = key;
      const nm = {};
      for (const n in a.vars) nm[n] = S.map[n] || { amp: '@' + n.charAt(0).toLowerCase() + n.slice(1), attr: n };
      S.map = nm;
      $('#vrT').innerHTML = Object.keys(a.vars).map(n => {
        const m = S.map[n], v = a.vars[n];
        return `<tr><td class="m">%%${esc(n)}%%</td><td>${v.n} ${lnBtn(`data-v="${esc(n)}"`, v.locs[0] && v.locs[0].ln)}</td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="amp" value="${esc(m.amp)}" aria-label="Variável AMPScript para ${esc(n)}"${ampValido(m.amp) ? '' : ' aria-invalid="true"'}></td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="attr" value="${esc(m.attr)}" aria-label="Atributo da DE para ${esc(n)}"></td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="teste" value="${esc(S.teste[n] || '')}" placeholder="${esc(WB.preview.amostra(m.attr || n))}" aria-label="Dado de teste para ${esc(n)}"></td></tr>`;
      }).join('') || '<tr><td colspan="5" class="mu">Nenhuma variável de personalização encontrada.</td></tr>';
    }
  }
  const ampValido = v => !v.trim() || /^@[A-Za-z_]\w*$/.test(v.trim());

  function renderImgs() {
    if (!A) return;
    const b = S.base.trim().replace(/\/?$/, '/');
    $('#imT').innerHTML = A.imgs.map((i, k) => {
      const sf = R.sufRe.test(i.file);
      const nw = S.base.trim() && !/^(%%|data:)/i.test(i.src) && (!S.onlySuf || sf) ? b + i.file : '—';
      return `<tr><td>${lnBtn(`data-i="${k}"`, i.loc && i.loc.ln)}</td><td class="m">${esc(i.file || '(sem src)')}</td><td>${sf ? '<span class="b ok">Sim</span>' : 'Não'}</td><td>${i.alt === null ? '<span class="b alerta">Sem alt</span>' : esc(i.alt) || '(vazio)'}</td><td class="m">${esc(nw)}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="mu">Nenhuma imagem encontrada.</td></tr>';
  }

  // ================= Preview =================
  let pvTimer;
  function tdPreview() {
    const td = {};
    for (const n of Object.keys(S.map)) {
      const attr = (S.map[n].attr || n).trim();
      const v = S.teste[n] || WB.preview.amostra(attr || n);
      td[n.toLowerCase()] = v; if (attr) td[attr.toLowerCase()] = v;
    }
    return td;
  }
  function paint() {
    const o = S.out;
    $('#cOut').textContent = o.length.toLocaleString('pt-BR') + ' caracteres, ' + (o ? o.split('\n').length : 0) + ' linhas';
    clearTimeout(pvTimer);
    pvTimer = setTimeout(() => {
      const r = WB.preview.gerar(o, { dados: PV.dados, td: tdPreview(), isSys: R.isSys, imagens: PV.imagens, escuro: PV.escuro });
      const pv = $('#pv');
      let y = 0; try { y = pv.contentWindow.scrollY || 0; } catch (e) { /* sem acesso */ }
      pv.onload = () => { try { pv.contentWindow.scrollTo(0, y); } catch (e) { /* ok */ } };
      pv.srcdoc = r.html;
      $('#pvNota').textContent = o ? r.notas.join(' ') : 'O preview aparece quando houver HTML na entrada.';
    }, 250);
  }
  function aplicarPreview() {
    $('#fr').classList.toggle('m', PV.mobile);
    $('#mb').setAttribute('aria-pressed', PV.mobile); $('#dk').setAttribute('aria-pressed', !PV.mobile);
    $('#pvTema').value = PV.escuro; $('#pvImg').checked = PV.imagens; $('#pvDados').checked = PV.dados;
    $('#fr').classList.toggle('dark', PV.escuro !== 'off');
    try { localStorage.setItem(K.preview, JSON.stringify(PV)); } catch (e) { /* ok */ }
  }

  // ================= Navegação até a linha =================
  function aba(t) {
    $$('#tabs button').forEach(x => x.setAttribute('aria-selected', x.dataset.t === t));
    $$('.pn').forEach(p => { p.hidden = p.id !== 'p-' + t; });
    if (t === 'in') edSrc.refresh();
    if (t === 'cd') edOut.refresh();
  }
  function irPara(loc) {
    if (!loc) return;
    garantirRun();
    aba('in');
    requestAnimationFrame(() => { edSrc.refresh(); edSrc.ir(loc.s, loc.e); });
  }
  function locDe(d) {
    if (!A) return null;
    if (d.c !== undefined) return A.ck[+d.c] && A.ck[+d.c].locs[+d.k];
    if (d.l !== undefined) return A.links[+d.l] && A.links[+d.l].loc;
    if (d.i !== undefined) return A.imgs[+d.i] && A.imgs[+d.i].loc;
    if (d.v !== undefined) return A.vars[d.v] && A.vars[d.v].locs[0];
    return null;
  }
  ['#qg', '#lkT', '#imT', '#vrT'].forEach(sel => $(sel).addEventListener('click', e => {
    const b = e.target.closest('button.ln'); if (b) irPara(locDe(b.dataset));
  }));

  // ================= Relatório =================
  async function metaRelatorio() {
    garantirRun();
    const h = await WB.report.hash(S.src);
    return {
      ...S.meta, arquivo: S.arquivo, geradoEm: new Date(), hash: h.valor, hashAlg: h.alg, map: S.map,
      regras: { fonte: window.WB_REGRAS_TIME ? 'regras do time' : 'padrão embutido', personalizada: regras.personalizada, assinatura: WB.rules.assinatura(regras.cfg) }
    };
  }
  const slug = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 50) || 'email';
  const nomeRel = m => {
    const d = m.geradoEm, p2 = n => String(n).padStart(2, '0');
    return 'homologacao_' + slug(m.campanha || (m.arquivo || 'email').replace(/\.[^.]+$/, '')) + '_' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes());
  };
  function semAnalise() { if (A) return false; toast('Cole um HTML na aba Entrada antes de gerar o relatório', { erro: true }); return true; }

  $('#relTxt').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const m = await metaRelatorio();
    baixar(nomeRel(m) + '.txt', '\uFEFF' + WB.report.texto(A, m), 'text/plain;charset=utf-8');
    toast('Relatório TXT baixado');
  };
  $('#relCopy').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const ok = await copiar(WB.report.texto(A, await metaRelatorio()));
    toast(ok ? 'Relatório copiado. Cole no chamado.' : 'Não foi possível copiar', { erro: !ok });
  };
  $('#relPdf').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const html = WB.report.html(A, await metaRelatorio());
    const f = document.createElement('iframe');
    f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1;
    f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.append(f);
    f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { toast('Não foi possível abrir a impressão', { erro: true }); } setTimeout(() => f.remove(), 60000); };
    f.srcdoc = html;
    toast('Na janela de impressão, escolha “Salvar como PDF”');
  };
  [['#mCamp', 'campanha'], ['#mCham', 'chamado'], ['#mResp', 'responsavel']].forEach(([sel, k]) =>
    $(sel).addEventListener('input', e => mudar('Dados do chamado', () => { S.meta[k] = e.target.value; }, { semRun: true })));

  // ================= Regras =================
  const campos = { chamadaRastreamento: '#rgRedirect', limiteKB: '#rgKB', sufixoImagem: '#rgSuf', variaveisDescadastro: '#rgUnsub', variaveisSistema: '#rgSys', dominios: '#rgTld' };

  function renderRegras() {
    const { CATALOGO, NIVEIS, NOME_NIVEL } = WB.rules;
    $('#rgNiv').innerHTML = CATALOGO.map(r => `<tr><td>${esc(r.nome)}</td><td><select data-r="${r.id}" class="nv-${regras.cfg.niveis[r.id]}" aria-label="Nível da regra: ${esc(r.nome)}">` +
      NIVEIS.map(n => `<option value="${n}"${regras.cfg.niveis[r.id] === n ? ' selected' : ''}>${NOME_NIVEL[n]}</option>`).join('') + '</select></td></tr>').join('');
    const p = regras.cfg.parametros;
    $('#rgRedirect').value = p.chamadaRastreamento; $('#rgKB').value = p.limiteKB; $('#rgSuf').value = p.sufixoImagem;
    $('#rgUnsub').value = p.variaveisDescadastro.join('\n'); $('#rgSys').value = p.variaveisSistema.join('\n'); $('#rgTld').value = p.dominios.join('\n');
    Object.values(campos).forEach(s => $(s).removeAttribute('aria-invalid'));
    $('#rgJson').value = JSON.stringify(regras.cfg, null, 2);
    fonteRegras();
  }
  function fonteRegras() {
    $('#rgFonte').textContent = 'Base: ' + (window.WB_REGRAS_TIME ? 'regras do time (arquivo regras-time.js).' : 'padrão embutido na ferramenta.') +
      (regras.personalizada ? ' Há ajustes salvos neste navegador.' : ' Sem ajustes locais.');
  }
  function mostrarErros(erros) {
    const el = $('#rgErr');
    el.hidden = !erros.length; el.textContent = erros.join(' ');
    for (const [k, s] of Object.entries(campos)) {
      if (erros.some(e => e.includes('"' + k + '"') || e.includes(k))) $(s).setAttribute('aria-invalid', 'true'); else $(s).removeAttribute('aria-invalid');
    }
  }
  function aplicarRegras(cfg, personalizada) {
    regras = { cfg, personalizada };
    if (personalizada && !WB.rules.salvar(cfg)) toast('Regras aplicadas, mas o navegador não deixou salvá-las', { erro: true });
    R = WB.rules.compilar(cfg);
    if (S.outManual) { H.pendente(); H.registrar(ROT_OUT); }
    varKey = '\u0000';
    run();
    $('#rgJson').value = JSON.stringify(cfg, null, 2);
    fonteRegras();
  }

  $('#rgNiv').addEventListener('change', e => {
    const s = e.target.closest('select'); if (!s) return;
    const cfg = WB.rules.clone(regras.cfg); cfg.niveis[s.dataset.r] = s.value; s.className = 'nv-' + s.value;
    aplicarRegras(cfg, true);
    toast('Regra atualizada');
  });
  let rgTimer;
  $$('.rgp [data-k]').forEach(el => el.addEventListener('input', () => {
    clearTimeout(rgTimer);
    rgTimer = setTimeout(() => {
      const k = el.dataset.k;
      const { cfg, erros } = WB.rules.normalizar({ parametros: { [k]: k === 'limiteKB' ? el.value : el.value } }, regras.cfg);
      mostrarErros(erros);
      if (!erros.length) aplicarRegras(cfg, true);
    }, 450);
  }));
  function importar(texto, origem) {
    let obj;
    try { obj = JSON.parse(texto); } catch (e) { mostrarErros(['JSON inválido: ' + e.message]); return; }
    const { cfg, erros } = WB.rules.normalizar(obj, WB.rules.base());
    aplicarRegras(cfg, true); renderRegras(); mostrarErros(erros);
    toast(erros.length ? `Regras ${origem} com ${erros.length} ajuste(s) ignorado(s)` : `Regras ${origem}`, { erro: !!erros.length });
  }
  $('#rgAplicar').onclick = () => importar($('#rgJson').value, 'aplicadas');
  $('#rgImp').onclick = () => $('#rgFile').click();
  $('#rgFile').addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader(); r.onload = () => importar(String(r.result), 'importadas'); r.readAsText(f); e.target.value = '';
  });
  $('#rgExp').onclick = () => { baixar('regras-sfmc-workbench.json', JSON.stringify(regras.cfg, null, 2), 'application/json'); toast('Regras exportadas'); };
  $('#rgExpJs').onclick = () => {
    baixar('regras-time.js', '/* Regras do time para o SFMC Workbench. Substitua o arquivo regras-time.js na pasta da ferramenta. */\nwindow.WB_REGRAS_TIME = ' + JSON.stringify(regras.cfg, null, 2) + ';\n', 'text/javascript');
    toast('regras-time.js baixado');
  };
  $('#rgReset').onclick = async () => {
    if (!regras.personalizada) { toast('Já está usando as regras do time'); return; }
    if (!(await confirmar({ titulo: 'Restaurar regras do time?', texto: 'Os ajustes de regras salvos neste navegador serão apagados.', ok: 'Restaurar regras' }))) return;
    WB.rules.limpar(); aplicarRegras(WB.rules.base(), false); renderRegras(); mostrarErros([]);
    toast('Regras do time restauradas');
  };

  // ================= Ações do projeto =================
  function carregarArquivo(f) {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      const tinha = !!S.src.trim();
      mudar('Carregar ' + f.name, () => { S.src = String(r.result); S.arquivo = f.name; edSrc.set(S.src, { topo: true }); }, { discreto: true });
      aba('in');
      toast('Arquivo ' + f.name + ' carregado', tinha ? { acao: 'Desfazer', fn: () => H.desfazer() } : {});
    };
    r.onerror = () => toast('Não foi possível ler o arquivo', { erro: true });
    r.readAsText(f);
  }

  // Entrada vinda da aba do Validador: o HTML do pacote que acabou de ser conferido.
  // Mesmo tratamento de carregar um arquivo (passo próprio no histórico, com
  // Desfazer), porque substitui o HTML que já estiver no editor.
  function abrirPeca(texto, nome) {
    const tinha = !!S.src.trim();
    mudar('Abrir ' + nome + ' do Validador', () => { S.src = String(texto); S.arquivo = nome; edSrc.set(S.src, { topo: true }); }, { discreto: true });
    aba('in');
    toast('HTML de ' + nome + ' aberto no Workbench', tinha ? { acao: 'Desfazer', fn: () => H.desfazer() } : {});
  }
  WB.abrirPeca = abrirPeca;

  async function limparProjeto(semConfirmar) {
    if (!S.src && !S.out && !S.base && !Object.values(S.meta).some(Boolean)) { toast('O projeto já está vazio'); return; }
    if (!semConfirmar && !(await confirmar({
      titulo: 'Limpar o projeto?',
      texto: 'O HTML, o código final, a URL base, o mapeamento de variáveis, os dados de teste e os dados do chamado serão apagados. Dá para desfazer logo em seguida.',
      ok: 'Limpar projeto'
    }))) return;
    mudar('Limpar projeto', () => { S = VAZIO(); edSrc.set(''); edOut.set(''); sincronizarCampos(); varKey = ''; }, { discreto: true });
    toast('Projeto limpo', { acao: 'Desfazer', fn: () => H.desfazer() });
  }

  $('#fileBtn').onclick = () => $('#file').click();
  $('#file').addEventListener('change', e => { carregarArquivo(e.target.files[0]); e.target.value = ''; });
  const dz = $('#drop');
  ['dragenter', 'dragover'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); dz.classList.add('on'); }, true));
  ['dragleave', 'drop'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); if (v === 'drop' || !dz.contains(e.relatedTarget)) dz.classList.remove('on'); }, true));
  dz.addEventListener('drop', e => {
    const f = e.dataTransfer.files[0];
    if (f && /\.(html?|txt)$/i.test(f.name)) carregarArquivo(f); else toast('Use um arquivo .html, .htm ou .txt', { erro: true });
  }, true);

  $('#base').addEventListener('input', e => mudar('URL base', () => { S.base = e.target.value; }));
  $('#onlysuf').addEventListener('change', e => mudar('Troca só de sufixos', () => { S.onlySuf = e.target.checked; }, { discreto: true }));
  $('#anti').addEventListener('change', e => mudar('Proteção anti-link', () => { S.anti = e.target.checked; }, { discreto: true }));
  $('#vrT').addEventListener('input', e => {
    const t = e.target, n = t.dataset.v, k = t.dataset.k;
    if (!n || !k) return;
    if (k === 'teste') { mudar('Dado de teste', () => { S.teste[n] = t.value; }, { semRun: true }); return; }
    if (k === 'amp') t.toggleAttribute('aria-invalid', !ampValido(t.value));
    mudar('Mapeamento de variáveis', () => { S.map[n] = Object.assign({}, S.map[n], { [k]: t.value }); });
  });

  $('#regen').onclick = () => { mudar('Regerar código', () => { S.outManual = false; }, { discreto: true }); toast('Código regerado a partir do HTML original'); };
  $('#copy').onclick = async () => {
    if (!S.out) { toast('Não há código para copiar', { erro: true }); return; }
    const ok = await copiar(S.out); toast(ok ? 'Código copiado' : 'Não foi possível copiar', { erro: !ok });
  };
  $('#clear').onclick = () => limparProjeto(false);
  $('#undo').onclick = () => H.desfazer();
  $('#redo').onclick = () => H.refazer();
  // O tema é o do Validador (botão do cabeçalho, chave bradesco_validador_emkt_theme).
  $('#tabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) aba(b.dataset.t); });
  $('#tabs').addEventListener('keydown', e => {
    if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    const bs = $$('#tabs button'), i = bs.indexOf(document.activeElement); if (i < 0) return;
    const n = bs[(i + (e.key === 'ArrowRight' ? 1 : -1) + bs.length) % bs.length]; n.focus(); aba(n.dataset.t);
  });

  $('#dk').onclick = () => { PV.mobile = false; aplicarPreview(); };
  $('#mb').onclick = () => { PV.mobile = true; aplicarPreview(); };
  $('#pvTema').addEventListener('change', e => { PV.escuro = e.target.value; aplicarPreview(); paint(); });
  $('#pvImg').addEventListener('change', e => { PV.imagens = e.target.checked; aplicarPreview(); paint(); });
  $('#pvDados').addEventListener('change', e => { PV.dados = e.target.checked; aplicarPreview(); paint(); });

  // A página tem duas abas. Sem esta guarda, Ctrl+Z na aba do Validador desfaria
  // o projeto do Workbench, que está escondido.
  const abaWorkbench = () => document.getElementById('aba-workbench');
  const abaVisivel = () => { const a = abaWorkbench(); return !!a && !a.hidden; };

  document.addEventListener('keydown', e => {
    if (!abaVisivel()) return;
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    if (e.target.closest && e.target.closest('input,textarea,select,.CodeMirror,[contenteditable="true"]')) return;
    const k = e.key.toLowerCase();
    if (k === 'z' && !e.shiftKey) { e.preventDefault(); H.desfazer(); }
    else if (k === 'y' || (k === 'z' && e.shiftKey)) { e.preventDefault(); H.refazer(); }
  });

  // Os editores nascem com a aba escondida (medida zero). Ao mostrar a aba, a
  // página avisa e o CodeMirror recalcula o tamanho do editor da sub-aba aberta.
  document.addEventListener('wb:visivel', () => {
    requestAnimationFrame(() => {
      const atual = $('#tabs button[aria-selected="true"]');
      const t = atual ? atual.dataset.t : 'in';
      if (t === 'in') edSrc.refresh();
      if (t === 'cd') edOut.refresh();
    });
  });

  // ================= Início =================
  function iniciar() {
    aplicarPreview();
    renderRegras();
    let d = null;
    try { d = JSON.parse(localStorage.getItem(K.rascunho)); } catch (e) { /* sem rascunho */ }
    if (d && d.s && ((d.s.src || '').trim() || (d.s.out || '').trim())) {
      S = Object.assign(VAZIO(), d.s, { meta: Object.assign(VAZIO().meta, d.s.meta) });
      edSrc.set(S.src, { topo: true });
      sincronizarCampos();
      if (S.outManual) { edOut.set(S.out); run({ manterOut: true }); } else run();
      const quando = new Date(d.ts);
      toast(`Rascunho de ${quando.toLocaleDateString('pt-BR')} às ${hora(quando)} restaurado`, { acao: 'Começar do zero', fn: () => limparProjeto(true) });
    } else run();
    H.registrar('Início');
  }
  iniciar();
})(window.WB = window.WB || {});
''',
}

# Casos e runner dos testes automáticos do Workbench
_JS_TESTES = {
    "casos": r'''/* casos.js — HTMLs de exemplo e o resultado esperado de cada um.
 *
 * Para criar um caso novo, copie um bloco e ajuste:
 *   html     o e-mail de teste
 *   regras   (opcional) ajustes sobre o padrão embutido, no mesmo formato do JSON de regras
 *   espera   o que o Quality Gate deve devolver:
 *            status: 'aprovado' | 'alertas' | 'reprovado'
 *            tem:    { idDaRegra: 'bloq' | 'alerta' | 'ok' }
 *            naoTem: [ ids que NÃO podem aparecer como bloqueador/alerta ]
 *            links, imgs, vars, dominios: quantidades
 *            hrefs, alts: valores exatos, na ordem do HTML
 *            linhas: { idDaRegra: [linhas esperadas] }
 *   gerar    (opcional) opções da geração do código final; use com contem/naoContem/igual/preservaAmp
 *   preview  (opcional) opções do preview; use com contem/naoContem
 */
(function () {
  'use strict';

  const BASE = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Oferta</title>
<style>a{color:#cc092f}</style>
</head>
<body>
%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%
<table role="presentation" width="600">
  <tr><td><a href="%%view_email_url%%">Ver no navegador</a></td></tr>
  <tr><td><a href="%%=RedirectTo(@Link_Tag)=%%"><img src="https://image.exemplo.com/lib/banner_01.png" alt="Oferta especial" width="600"></a></td></tr>
  <tr><td>Olá, %%Nome%%! Seu limite é %%Limite%%.</td></tr>
  <tr><td><a href="%%unsub_center_url%%">Descadastrar</a></td></tr>
</table>
</body>
</html>`;
  const troca = (de, para) => BASE.replace(de, para);
  const UNSUB = '<tr><td><a href="%%unsub_center_url%%">Descadastrar</a></td></tr>';

  window.WB_CASOS = [
    // ------------------------------------------------------------ aprovados
    {
      nome: 'Aprovado: e-mail completo e dentro do padrão', grupo: 'Aprovados',
      html: BASE,
      espera: { status: 'aprovado', links: 3, imgs: 1, vars: 2, dominios: 0, tem: { viewEmailUrl: 'ok', redirectTo: 'ok', descadastroPadrao: 'ok' } }
    },
    {
      nome: 'Aprovado: imagem decorativa com alt vazio conta como alt presente', grupo: 'Aprovados',
      html: troca('<td>Olá', '<td><img src="https://image.exemplo.com/lib/espaco.gif" alt="" width="1">Olá'),
      espera: { status: 'aprovado', imgs: 2, alts: ['Oferta especial', ''] }
    },

    // ------------------------------------------------------------ reprovados
    {
      nome: 'Reprovado: sem link de descadastro', grupo: 'Reprovados',
      html: troca(UNSUB, ''),
      espera: { status: 'reprovado', tem: { descadastroAusente: 'bloq' }, links: 2 }
    },
    {
      nome: 'Reprovado: sem %%view_email_url%% e sem RedirectTo', grupo: 'Reprovados',
      html: troca('<a href="%%view_email_url%%">Ver no navegador</a>', 'Ver no navegador').replace('%%=RedirectTo(@Link_Tag)=%%', 'https://www.exemplo.com.br/oferta'),
      espera: { status: 'reprovado', tem: { viewEmailUrl: 'bloq', redirectTo: 'bloq' } }
    },
    {
      nome: 'Reprovado: href vazio, link sem href e javascript:', grupo: 'Reprovados',
      html: troca(UNSUB, UNSUB + '\n  <tr><td><a href="">Saiba mais</a> <a name="topo">Topo</a> <a href="javascript:void(0)">Abrir</a></td></tr>'),
      espera: { status: 'reprovado', tem: { hrefVazio: 'bloq', hrefJs: 'bloq' }, links: 6, linhas: { hrefVazio: [16], hrefJs: [16] } }
    },
    {
      nome: 'Reprovado: tag script (AMPScript em <script language="ampscript"> é aceito)', grupo: 'Reprovados',
      html: troca('</body>', '<script runat="server" language="ampscript">SET @x = 1</script>\n<script>alert(1)</script>\n</body>'),
      espera: { status: 'reprovado', tem: { scriptTag: 'bloq' }, linhas: { scriptTag: [18] } }
    },
    {
      nome: 'Reprovado: bloco AMPScript sem fechamento', grupo: 'Reprovados',
      html: troca('%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%', '%%[ SET @Promo = "verao"\n%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta" ]%%'),
      espera: { status: 'reprovado', tem: { ampNaoFechado: 'bloq' }, linhas: { ampNaoFechado: [10] } }
    },

    // ------------------------------------------------------------ alertas
    {
      nome: 'Alertas: href “#” e descadastro com RedirectTo', grupo: 'Alertas',
      html: troca(UNSUB, '<tr><td><a href="#">Regulamento</a> <a href="%%=RedirectTo(%%unsub_center_url%%)=%%">Sair</a></td></tr>'),
      espera: { status: 'alertas', tem: { hrefHash: 'alerta', descadastroPadrao: 'alerta' }, naoTem: ['descadastroAusente'] }
    },
    {
      nome: 'Alertas: imagem sem alt e imagem com src relativo', grupo: 'Alertas',
      html: troca('<td>Olá', '<td><img src="images/selo_02.png"><img src="https://image.exemplo.com/lib/x.png" alt="X">Olá'),
      espera: { status: 'alertas', tem: { imgSemAlt: 'alerta', imgRelativa: 'alerta' }, imgs: 3 }
    },
    {
      nome: 'Alertas: link dentro de outro link', grupo: 'Alertas',
      html: troca('<td>Olá', '<td><a href="%%=RedirectTo(@Link_Tag)=%%">Clique <a href="%%=RedirectTo(@Link_Tag)=%%">aqui</a></a>Olá'),
      espera: { status: 'alertas', tem: { linkAninhado: 'alerta' }, linhas: { linkAninhado: [14] } }
    },
    {
      nome: 'Alertas: HTML acima de 102 KB', grupo: 'Alertas',
      html: troca('</body>', '<!--' + 'x'.repeat(106 * 1024) + '-->\n</body>'),
      espera: { status: 'alertas', tem: { tamanho: 'alerta' } }
    },
    {
      nome: 'Alertas: sem DOCTYPE e sem meta viewport', grupo: 'Alertas',
      html: troca('<!DOCTYPE html>\n', '').replace('<meta name="viewport" content="width=device-width, initial-scale=1">\n', ''),
      espera: { status: 'alertas', tem: { doctype: 'alerta', viewport: 'alerta' } }
    },

    // ------------------------------------------------------------ parser
    {
      nome: 'Parser: aspas com “>”, tags em maiúsculas e atributos sem aspas', grupo: 'Parser de HTML',
      html: troca('<td>Olá', `<td><A HREF='%%=RedirectTo(@Link_Tag)=%%' TITLE="a > b">Ver</A><IMG SRC=foto_02.png ALT=Foto WIDTH=100>Olá`),
      espera: { status: 'alertas', links: 4, imgs: 2, alts: ['Oferta especial', 'Foto'], naoTem: ['hrefVazio', 'imgSemAlt'], tem: { imgRelativa: 'alerta' } }
    },
    {
      nome: 'Parser: AMPScript com aspas duplas dentro do href', grupo: 'Parser de HTML',
      html: troca('<td>Olá', '<td><a href="%%=RedirectTo(Concat("https://www.exemplo.com.br/?id=", @id))=%%">Meu cupom</a>Olá'),
      espera: {
        status: 'aprovado', links: 4, naoTem: ['hrefVazio'],
        hrefs: ['%%view_email_url%%', '%%=RedirectTo(@Link_Tag)=%%', '%%=RedirectTo(Concat("https://www.exemplo.com.br/?id=", @id))=%%', '%%unsub_center_url%%']
      }
    },
    {
      nome: 'Parser: links em comentários, <style> e condicional do Outlook não contam', grupo: 'Parser de HTML',
      html: troca('<style>a{color:#cc092f}</style>', '<style>a[href=""]{color:red} /* <a href=""> */</style>')
        .replace('<td>Olá', '<td><!-- <a href="">antigo</a> --><!--[if mso]><v:roundrect href=""><a href="">x</a></v:roundrect><![endif]-->Olá'),
      espera: { status: 'aprovado', links: 3, naoTem: ['hrefVazio'] }
    },
    {
      nome: 'Parser: domínios em texto puro (inclusive com entidade), ignorando atributos e comentários', grupo: 'Parser de HTML',
      html: troca('<td>Olá', '<td>Acesse bradesco.com.br ou exemplo&#46;com <!-- teste.com.br --><a href="https://www.site.com.br">clique</a> site&#xFEFF;.com Olá'),
      espera: { status: 'alertas', dominios: 2, tem: { dominioTexto: 'alerta' }, linhas: { dominioTexto: [14] } }
    },

    // ------------------------------------------------------------ regras configuráveis
    {
      nome: 'Regras: href “#” elevado a bloqueador', grupo: 'Regras configuráveis',
      html: troca(UNSUB, UNSUB + '<tr><td><a href="#">Regulamento</a></td></tr>'),
      regras: { niveis: { hrefHash: 'bloq' } },
      espera: { status: 'reprovado', tem: { hrefHash: 'bloq' } }
    },
    {
      nome: 'Regras: regras desligadas não aparecem', grupo: 'Regras configuráveis',
      html: troca('<a href="%%view_email_url%%">Ver no navegador</a>', 'Ver no navegador').replace('%%=RedirectTo(@Link_Tag)=%%', 'https://www.exemplo.com.br/oferta'),
      regras: { niveis: { viewEmailUrl: 'off', redirectTo: 'off' } },
      espera: { status: 'aprovado', naoTem: ['viewEmailUrl', 'redirectTo'] }
    },
    {
      nome: 'Regras: nova variável de descadastro aceita', grupo: 'Regras configuráveis',
      html: troca('%%unsub_center_url%%', '%%optout_url%%'),
      regras: { parametros: { variaveisDescadastro: ['optout_url'], variaveisSistema: ['view_email_url', 'optout_url'] } },
      espera: { status: 'aprovado', naoTem: ['descadastroAusente'], vars: 2 }
    },
    {
      nome: 'Regras: lista de domínios monitorados', grupo: 'Regras configuráveis',
      html: troca('<td>Olá', '<td>Veja site.com e loja.com.br Olá'),
      regras: { parametros: { dominios: ['com.br'] } },
      espera: { dominios: 1 }
    },
    {
      nome: 'Regras: links http(s) diretos, sem RedirectTo, quando a regra está ligada', grupo: 'Regras configuráveis',
      html: troca('<td>Olá', '<td><a href="https://www.exemplo.com.br/direto">Direto</a>Olá'),
      regras: { niveis: { linkSemRedirect: 'alerta' } },
      espera: { status: 'alertas', tem: { linkSemRedirect: 'alerta' }, linhas: { linkSemRedirect: [14] } }
    },

    // ------------------------------------------------------------ geração do código final
    {
      nome: 'Geração: sem opções, o código final é idêntico ao original', grupo: 'Geração do código final',
      html: BASE,
      gerar: { anti: false, base: '', onlySuf: true, map: {} },
      igual: true
    },
    {
      nome: 'Geração: anti-link só no texto, AMPScript e href intactos', grupo: 'Geração do código final',
      html: troca('<td>Olá', '<td>Acesse www.exemplo.com.br <a href="https://www.exemplo.com.br">site</a> %%=v(@site)=%% Olá'),
      gerar: { anti: true, base: '', onlySuf: true, map: {} },
      contem: ['www&#xFEFF;.exemplo&#xFEFF;.com&#xFEFF;.br', 'href="https://www.exemplo.com.br"', '%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%', '%%=v(@site)=%%'],
      preservaAmp: true
    },
    {
      nome: 'Geração: URL base troca só imagens com sufixo', grupo: 'Geração do código final',
      html: troca('<td>Olá', '<td><img src="logo.png" alt="Logo"><img src="%%=v(@img)=%%" alt="Dinâmica"><img src=\'images/selo_02.png\' alt="Selo">Olá'),
      gerar: { anti: false, base: 'https://image.s10.exacttarget.com/lib/abc', onlySuf: true, map: {} },
      contem: ['src="https://image.s10.exacttarget.com/lib/abc/banner_01.png"', "src='https://image.s10.exacttarget.com/lib/abc/selo_02.png'", 'src="logo.png"', 'src="%%=v(@img)=%%"'],
      preservaAmp: true
    },
    {
      nome: 'Geração: variáveis viram AttributeValue', grupo: 'Geração do código final',
      html: BASE,
      gerar: { anti: false, base: '', onlySuf: true, map: { Nome: { amp: '@nome', attr: 'PrimeiroNome' }, Limite: { amp: '', attr: 'Limite' } } },
      contem: ['%%[\n  SET @nome = AttributeValue("PrimeiroNome")\n]%%\n<!DOCTYPE html>', 'Olá, %%=v(@nome)=%%!', '%%Limite%%'],
      naoContem: ['%%Nome%%']
    },

    // ------------------------------------------------------------ preview
    {
      nome: 'Preview: dados de teste preenchem AMPScript e variáveis', grupo: 'Preview',
      html: '%%[\n  SET @nome = AttributeValue("PrimeiroNome")\n]%%\n<p>Olá, %%=v(@nome)=%%! Limite: %%Limite%%. <a href="%%view_email_url%%">ver</a></p>',
      preview: { dados: true, td: { primeironome: 'Ana', limite: 'R$ 500,00' } },
      contem: ['Olá, Ana!', 'Limite: R$ 500,00.', 'href="#"'],
      naoContem: ['%%']
    },
    {
      nome: 'Preview: imagens bloqueadas mostram o texto alternativo', grupo: 'Preview',
      html: BASE,
      preview: { dados: true, imagens: true },
      contem: ['Oferta especial</span>'],
      naoContem: ['<img']
    },
    {
      nome: 'Preview: modo escuro ativa o CSS de dark mode do e-mail', grupo: 'Preview',
      html: '<html><head><style>@media (prefers-color-scheme: dark){body{background:#000}}</style></head><body>x</body></html>',
      preview: { escuro: 'css' },
      contem: ['@media (min-width:0px)'],
      naoContem: ['prefers-color-scheme: dark']
    }
  ];
})();
''',
    "runner": r'''/* runner.js — Executa os casos de tests/casos.js com as regras PADRÃO embutidas
 * (não usa regras-time.js nem ajustes do navegador, para o resultado ser reproduzível). */
(function (WB) {
  'use strict';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const AMP = /%%\[[\s\S]*?\]%%|%%=[\s\S]*?=%%/g;
  const igual = (a, b) => JSON.stringify(a) === JSON.stringify(b);

  function rodar(caso) {
    const falhas = [];
    const f = (msg, esperado, obtido) => falhas.push({ msg, esperado, obtido });
    const { cfg, erros } = WB.rules.normalizar(caso.regras || {}, WB.rules.clone(WB.rules.PADRAO));
    if (erros.length) f('Regras do caso inválidas', '[]', erros.join(' '));
    const R = WB.rules.compilar(cfg);

    if (caso.gerar) {
      const out = WB.audit.compile(caso.html, caso.gerar, R);
      if (caso.igual && out !== caso.html) f('Código final deveria ser idêntico ao original', '(idêntico)', '(diferente)');
      (caso.contem || []).forEach(t => { if (!out.includes(t)) f('Código final deveria conter', t, '(ausente)'); });
      (caso.naoContem || []).forEach(t => { if (out.includes(t)) f('Código final não deveria conter', t, '(presente)'); });
      if (caso.preservaAmp) (caso.html.match(AMP) || []).forEach(t => { if (!out.includes(t)) f('AMPScript alterado na geração', t, '(ausente)'); });
      return falhas;
    }
    if (caso.preview) {
      const r = WB.preview.gerar(caso.html, Object.assign({ isSys: R.isSys }, caso.preview));
      (caso.contem || []).forEach(t => { if (!r.html.includes(t)) f('Preview deveria conter', t, '(ausente)'); });
      (caso.naoContem || []).forEach(t => { if (r.html.includes(t)) f('Preview não deveria conter', t, '(presente)'); });
      return falhas;
    }

    const A = WB.audit.analyze(caso.html, R), e = caso.espera || {};
    const falhando = id => A.ck.find(c => c.id === id && c.l !== 'ok');
    if (e.status && A.status !== e.status) f('Status', e.status, A.status + ' (' + A.ck.filter(c => c.l !== 'ok').map(c => c.id + ':' + c.l).join(', ') + ')');
    for (const [id, nv] of Object.entries(e.tem || {})) {
      const c = A.ck.find(x => x.id === id && x.l === nv);
      if (!c) f(`Checagem ${id}`, nv, (A.ck.find(x => x.id === id) || {}).l || '(ausente)');
    }
    (e.naoTem || []).forEach(id => { const c = falhando(id); if (c) f(`Checagem ${id} não deveria falhar`, '(ausente)', c.l + ': ' + c.t); });
    const cont = { links: A.links.length, imgs: A.imgs.length, vars: Object.keys(A.vars).length, dominios: A.dn };
    for (const k of Object.keys(cont)) if (e[k] !== undefined && e[k] !== cont[k]) f('Quantidade de ' + k, e[k], cont[k]);
    if (e.hrefs && !igual(e.hrefs, A.links.map(l => l.href))) f('hrefs lidos', JSON.stringify(e.hrefs), JSON.stringify(A.links.map(l => l.href)));
    if (e.alts && !igual(e.alts, A.imgs.map(i => i.alt))) f('alts lidos', JSON.stringify(e.alts), JSON.stringify(A.imgs.map(i => i.alt)));
    for (const [id, ls] of Object.entries(e.linhas || {})) {
      const c = falhando(id);
      const obt = c ? [...new Set(c.locs.map(l => l.ln))] : [];
      if (!igual(obt, ls)) f(`Linhas de ${id}`, ls.join(', '), obt.join(', ') || '(nenhuma)');
    }
    return falhas;
  }

  function executar() {
    const casos = window.WB_CASOS || [];
    const res = casos.map(c => { let falhas; try { falhas = rodar(c); } catch (err) { falhas = [{ msg: 'Erro ao executar', esperado: '', obtido: err.message }]; console.error(err); } return { c, falhas }; });
    const ok = res.filter(r => !r.falhas.length).length;
    window.WB_RESULTADO = { total: res.length, ok, falhas: res.filter(r => r.falhas.length).map(r => ({ nome: r.c.nome, falhas: r.falhas })) };

    const sum = document.getElementById('sum');
    sum.className = ok === res.length ? 'ok' : 'bad';
    sum.textContent = ok === res.length ? `Todos os ${res.length} testes passaram` : `${res.length - ok} de ${res.length} testes falharam`;
    const grupos = [...new Set(res.map(r => r.c.grupo || 'Outros'))];
    document.getElementById('lista').innerHTML = grupos.map(g => `<h2>${esc(g)}</h2><ul>` + res.filter(r => (r.c.grupo || 'Outros') === g).map(r =>
      `<li class="${r.falhas.length ? 'bad' : 'ok'}"><b>${r.falhas.length ? 'Falhou' : 'Passou'}</b> ${esc(r.c.nome)}` +
      (r.falhas.length ? '<ul class="f">' + r.falhas.map(x => `<li>${esc(x.msg)}: esperado <code>${esc(x.esperado)}</code>, obtido <code>${esc(x.obtido)}</code></li>`).join('') + '</ul>' : '') +
      `<details><summary>Ver HTML do caso</summary><pre>${esc(r.c.html.length > 4000 ? r.c.html.slice(0, 4000) + '\n…' : r.c.html)}</pre></details></li>`).join('') + '</ul>').join('');
  }
  WB.testes = { executar, rodar };
  executar();
})(window.WB = window.WB || {});
''',
}

_HTML_PAGINA = r'''<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validador de pacotes EMKT · Bradesco CRM</title>
  <meta name="description" content="Confere pacotes de campanha: taxonomia e sequencia das imagens, cruzamento com o HTML e o texto do CONTEUDO.docx, incluindo o texto dentro dos banners.">

  <!-- Cor da barra do navegador acompanhando o tema -->
  <meta name="theme-color" content="#cc092f" media="(prefers-color-scheme: light)">
  <meta name="theme-color" content="#14161a" media="(prefers-color-scheme: dark)">

  <!-- Favicon inline (data URI): sem arquivo extra e sem depender de CDN -->
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%23cc092f'/%3E%3Cg fill='none' stroke='white' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='5' y='6' width='14' height='18' rx='2'/%3E%3Cpath d='M9 11h6M9 15h6M9 19h3'/%3E%3Ccircle cx='21' cy='21' r='5' fill='%23cc092f'/%3E%3Cpath d='m19 21 1.5 1.5L23.5 19'/%3E%3C/g%3E%3C/svg%3E">

  <!-- Tipografia do Busca Facil / Pasta-Programa. Se o proxy corporativo
       bloquear o Google Fonts, a pilha do sistema (Segoe UI / Cascadia Mono)
       assume no CSS e a tela continua inteira - so nao fica com a fonte da marca. -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">

  <!-- Aplica o tema salvo ANTES do primeiro paint: o loader ja nasce no tema
       certo e some o "flash" de tela clara ao recarregar no escuro. Usa a
       MESMA chave do script.js. -->
  <script>
    (function () {
      try {
        var salvo = localStorage.getItem("bradesco_validador_emkt_theme");
        var prefereEscuro = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
        document.documentElement.setAttribute("data-theme", salvo || (prefereEscuro ? "dark" : "light"));
      } catch (e) { /* localStorage bloqueado: segue no claro */ }
    })();
  </script>

  <link rel="stylesheet" href="/assets/validador.css">
  <link rel="stylesheet" href="/assets/codemirror.css">
  <link rel="stylesheet" href="/assets/workbench.css">
</head>
<body>

  <!-- ============================================================
       LOADER (tela de abertura). Some no evento `load` (com tempo minimo
       pra nao piscar) ou no teto de 5s. Controle inline no fim do body -
       independente do script.js. -->
  <div class="loader" id="loader" role="status" aria-label="Carregando o validador">
    <div class="loader-icon" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="13" height="17" rx="2"/>
        <path d="M7 8h5M7 11.5h5M7 15h3"/>
        <circle cx="17" cy="16.5" r="4.5"/>
        <path d="m15 16.5 1.5 1.5 3-3.2"/>
      </svg>
      <img src="https://img.icons8.com/color/96/bradesco.png" alt="" width="96" height="96" onerror="this.remove()">
    </div>
    <div class="loader-eyebrow">Bradesco · CRM</div>
    <div class="loader-title">Validador de pacotes EMKT</div>
    <div class="loader-bar" aria-hidden="true"></div>
  </div>

  <!-- ================= Cabecalho ================= -->
  <header class="app-header">
    <div class="brand-accent-bar"></div>
    <div class="header-inner">
      <div class="brand">
        <!-- O quadrado vermelho com o simbolo desenhado fica POR BAIXO da imagem:
             se a rede corporativa bloquear o CDN, o cabecalho continua exibindo a
             marca em vez de um icone quebrado. -->
        <span class="brand-logo" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="13" height="17" rx="2"/>
            <path d="M7 8h5M7 11.5h5M7 15h3"/>
            <circle cx="17" cy="16.5" r="4.5"/>
            <path d="m15 16.5 1.5 1.5 3-3.2"/>
          </svg>
          <img src="https://img.icons8.com/color/96/bradesco.png" alt="" width="40" height="40" onerror="this.remove()">
        </span>
        <div>
          <div class="brand-eyebrow">Bradesco · CRM · Modelo Operacional</div>
          <div class="brand-title">Publicação e Orquestração</div>
        </div>
      </div>

      <div class="header-right">
        <button type="button" class="chip chip-btn theme-toggle" id="btn-theme-toggle"
                aria-label="Alternar modo claro/escuro" title="Alternar modo claro/escuro">
          <svg id="theme-icon-moon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          <svg id="theme-icon-sun" class="hidden" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
          <span id="theme-label">Escuro</span>
        </button>
      </div>
    </div>
  </header>

  <!-- ================= Barra de abas ================= -->
  <nav class="abas-app" id="abas-app" role="tablist" aria-label="Ferramentas">
    <div class="abas-app-inner">
      <button type="button" class="aba-app" role="tab" id="aba-btn-validador" aria-selected="true"
              aria-controls="aba-validador">Validador de pacotes</button>
      <button type="button" class="aba-app" role="tab" id="aba-btn-workbench" aria-selected="false"
              aria-controls="aba-workbench" tabindex="-1">SFMC Workbench</button>
    </div>
  </nav>

  <main class="app-main" id="aba-validador" role="tabpanel" aria-labelledby="aba-btn-validador">

    <div class="page-title">
      <h1>
        <svg class="page-title-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <rect x="3" y="3" width="13" height="17" rx="2"/>
          <path d="M7 8h5M7 11.5h5M7 15h3"/>
          <circle cx="17" cy="16.5" r="4.5"/>
          <path d="m15 16.5 1.5 1.5 3-3.2"/>
        </svg>
        Validador de pacotes EMKT
      </h1>
      <p>
        Confere o pacote que o marketing enviou: se as imagens seguem a
        <b>taxonomia da quebra</b>, se a numeração está sequencial sem furo, se
        toda imagem da pasta é chamada no HTML — e se o <b>CONTEUDO.docx</b> tem
        exatamente as mesmas palavras da peça, na mesma ordem de leitura,
        incluindo o texto que está dentro dos banners. É esse texto que o leitor
        de tela entrega ao cliente com deficiência visual.
      </p>
    </div>

    <div class="painel-fluxo">

      <!-- ================= Consulta ================= -->
      <section class="panel scan-panel">
        <div class="card-header">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M3 10.5V7a1.8 1.8 0 0 1 1.8-1.8h4.4l2 2.2h8A1.8 1.8 0 0 1 21 9.2v9a1.8 1.8 0 0 1-1.8 1.8H4.8A1.8 1.8 0 0 1 3 18.2z"/>
          </svg>
          <h2 class="card-title">Pacote ou lote a conferir</h2>
        </div>

        <div class="solta" id="area-solta" tabindex="0" role="button"
             aria-label="Arraste a pasta do pacote ou clique para escolher">
          <svg class="solta-icone" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M3 10.5V7a1.8 1.8 0 0 1 1.8-1.8h4.4l2 2.2h8A1.8 1.8 0 0 1 21 9.2v9a1.8 1.8 0 0 1-1.8 1.8H4.8A1.8 1.8 0 0 1 3 18.2z"/>
            <path d="M12 16v-5"/><path d="m9.5 13.5 2.5-2.5 2.5 2.5"/>
          </svg>
          <strong>Arraste a pasta aqui</strong>
          <span>Pode ser <b>um pacote</b> — com o HTML, os dois docx e as imagens —
            ou a pasta que <b>guarda vários pacotes</b>. O validador reconhece
            sozinho o que você arrastou.</span>
          <div class="solta-lista" id="solta-lista"></div>
        </div>
        <input type="file" id="seletor" webkitdirectory directory multiple hidden>

        <div class="opcoes">
          <label class="opcao">
            <input type="checkbox" id="usar-ocr" checked>
            Ler o texto de dentro das imagens
          </label>
          <label class="opcao" id="opcao-motor" hidden>
            Motor de leitura
            <select id="motor" class="select-motor"></select>
          </label>
        </div>

        <div class="acoes">
          <button type="button" class="btn-primary" id="btn-conferir">
            <span class="btn-spinner" id="btn-spinner" hidden aria-hidden="true"></span>
            <span id="btn-conferir-rotulo">Conferir</span>
          </button>
        </div>

        <div class="barra-motor" id="barra-motor"></div>
        <p class="nota">Mexeu nas regras do Validador? <a href="/validador/tests/" target="_blank" rel="noopener">Rode os testes automáticos</a>.</p>
      </section>

      <!-- ================= Status e resultados ================= -->
      <div id="status-area"></div>
      <div id="resultados"></div>

    </div>
  </main>


  <!-- ================= SFMC Workbench ================= -->
  <main class="app-main" id="aba-workbench" role="tabpanel" aria-labelledby="aba-btn-workbench" hidden>
    <header class="top">
      <div><h1>Gerador AMPScript EMKT – SFMC Workbench</h1><p>Homologação técnica de e-mail para Salesforce Marketing Cloud</p></div>
      <div class="act">
        <span id="st" class="pill" role="status">Aguardando HTML</span>
        <span class="seg"><button id="undo" title="Desfazer (Ctrl+Z)" disabled>Desfazer</button><button id="redo" title="Refazer (Ctrl+Y)" disabled>Refazer</button></span>
        <button id="clear" class="danger">Limpar projeto</button>
      </div>
    </header>
    <section class="kpis" aria-label="Resumo">
      <div class="kpi"><b id="kImg">0</b><span>Imagens</span></div>
      <div class="kpi"><b id="kLink">0</b><span>Links</span></div>
      <div class="kpi"><b id="kVar">0</b><span>Variáveis</span></div>
      <div class="kpi"><b id="kAl">0</b><span>Bloqueadores e alertas</span></div>
    </section>
    <div class="grid">
      <div class="card">
        <div class="tabs" role="tablist" id="tabs">
          <button role="tab" data-t="in" aria-selected="true">Entrada</button>
          <button role="tab" data-t="qg" aria-selected="false">Quality Gate<i id="nQ" hidden></i></button>
          <button role="tab" data-t="lk" aria-selected="false">Links</button>
          <button role="tab" data-t="im" aria-selected="false">Imagens</button>
          <button role="tab" data-t="vr" aria-selected="false">Variáveis</button>
          <button role="tab" data-t="cd" aria-selected="false">Código final</button>
          <button role="tab" data-t="rg" aria-selected="false">Regras</button>
        </div>

        <section class="pn" id="p-in">
          <div id="drop"><div id="edSrc" class="ed"></div><div class="dzh" aria-hidden="true">Solte o arquivo para carregar</div></div>
          <div class="row">
            <input type="file" id="file" accept=".html,.htm,.txt" hidden>
            <button class="p" id="fileBtn">Carregar arquivo</button>
            <span class="mu" id="cSrc">0 caracteres</span>
            <span class="mu" id="draftSt" aria-live="polite"></span>
            <span class="mu keys"><kbd>Ctrl</kbd>+<kbd>F</kbd> buscar <kbd>Alt</kbd>+<kbd>G</kbd> ir para a linha <kbd>F8</kbd> próximo alerta</span>
          </div>
        </section>

        <section class="pn" id="p-qg" hidden>
          <fieldset class="rel">
            <legend>Relatório de homologação</legend>
            <div class="relf">
              <label>Campanha<input type="text" id="mCamp" autocomplete="off"></label>
              <label>Chamado<input type="text" id="mCham" autocomplete="off"></label>
              <label>Responsável<input type="text" id="mResp" autocomplete="off"></label>
            </div>
            <div class="row"><button class="p" id="relPdf">Gerar PDF</button><button id="relTxt">Baixar TXT</button><button id="relCopy">Copiar relatório</button></div>
          </fieldset>
          <ul class="ck" id="qg"></ul>
        </section>

        <section class="pn" id="p-lk" hidden>
          <div class="row"><label><input type="checkbox" id="anti" checked> Aplicar proteção anti-link (FEFF) em domínios em texto puro</label></div>
          <p class="mu" id="antiN"></p>
          <div class="tw"><table><thead><tr><th>#</th><th>Linha</th><th>href</th><th>Texto do link</th><th>Status</th></tr></thead><tbody id="lkT"></tbody></table></div>
        </section>

        <section class="pn" id="p-im" hidden>
          <label class="mu" for="base">URL base do Content Builder</label>
          <input type="text" id="base" placeholder="https://image.exemplo.com/lib/…/">
          <div class="row"><label><input type="checkbox" id="onlysuf" checked> Trocar só imagens com sufixo _01, _02…</label></div>
          <div class="tw"><table><thead><tr><th>Linha</th><th>Arquivo</th><th>Sufixo</th><th>Alt</th><th>Novo src</th></tr></thead><tbody id="imT"></tbody></table></div>
        </section>

        <section class="pn" id="p-vr" hidden>
          <p class="mu">Variáveis %%VAR%% encontradas (variáveis de sistema ignoradas). Esvazie o campo AMPScript para manter a variável como está. O dado de teste só aparece no preview.</p>
          <div class="tw"><table><thead><tr><th>Variável</th><th>Usos</th><th>Variável AMPScript</th><th>Atributo da DE</th><th>Dado de teste</th></tr></thead><tbody id="vrT"></tbody></table></div>
        </section>

        <section class="pn" id="p-cd" hidden>
          <div class="row"><button class="p" id="copy">Copiar código</button><button id="regen">Regerar do HTML original</button><span class="mu" id="cOut"></span></div>
          <p class="mu manual" id="manualN" hidden>Este código tem edições manuais. Qualquer mudança no HTML de entrada, nas imagens ou nas variáveis gera o código de novo; se isso acontecer, use Desfazer para recuperar as edições.</p>
          <div id="edOut" class="ed"></div>
        </section>

        <section class="pn" id="p-rg" hidden>
          <p class="mu" id="rgFonte"></p>
          <div class="row">
            <button id="rgExp">Exportar JSON</button>
            <button id="rgExpJs">Baixar como regras-time.js</button>
            <input type="file" id="rgFile" accept=".json,application/json" hidden><button id="rgImp">Importar JSON</button>
            <button id="rgReset">Restaurar regras do time</button>
          </div>
          <p class="err" id="rgErr" role="alert" hidden></p>
          <h2 class="sub">Nível de cada regra</h2>
          <div class="tw livre"><table class="rgt"><thead><tr><th>Regra</th><th>Nível</th></tr></thead><tbody id="rgNiv"></tbody></table></div>
          <h2 class="sub">Parâmetros</h2>
          <div class="rgp">
            <label>Chamada de rastreamento (expressão regular)<input type="text" id="rgRedirect" spellcheck="false" data-k="chamadaRastreamento"></label>
            <label>Limite de tamanho do HTML, em KB<input type="number" id="rgKB" min="1" step="1" data-k="limiteKB"></label>
            <label>Sufixo de imagem trocável (expressão regular)<input type="text" id="rgSuf" spellcheck="false" data-k="sufixoImagem"></label>
            <label>Variáveis de descadastro, uma por linha<textarea id="rgUnsub" rows="5" spellcheck="false" data-k="variaveisDescadastro"></textarea></label>
            <label>Variáveis de sistema ignoradas, uma por linha<textarea id="rgSys" rows="5" spellcheck="false" data-k="variaveisSistema"></textarea></label>
            <label>Domínios monitorados em texto, um por linha<textarea id="rgTld" rows="5" spellcheck="false" data-k="dominios"></textarea></label>
          </div>
          <details class="json"><summary>Editar como JSON</summary>
            <textarea id="rgJson" rows="14" spellcheck="false"></textarea>
            <div class="row"><button class="p" id="rgAplicar">Aplicar JSON</button></div>
          </details>
          <p class="mu">Mudou a lógica das regras no código? Abra <a href="/workbench/tests/" target="_blank" rel="noopener">a página de testes</a> para rodar os testes automáticos.</p>
        </section>
      </div>

      <aside class="card pvw">
        <div class="pvh"><strong>Preview ao vivo</strong>
          <div class="seg"><button id="dk" aria-pressed="true">Desktop</button><button id="mb" aria-pressed="false">Mobile</button></div></div>
        <div class="pvo">
          <label>Aparência <select id="pvTema"><option value="off">Claro</option><option value="css">Escuro, CSS do e-mail</option><option value="inv">Escuro, inversão automática</option></select></label>
          <label><input type="checkbox" id="pvDados" checked> Dados de teste</label>
          <label><input type="checkbox" id="pvImg"> Imagens bloqueadas</label>
        </div>
        <div class="stage"><div class="frame" id="fr"><iframe id="pv" sandbox="allow-same-origin" title="Preview do e-mail"></iframe></div>
        <p class="mu" id="pvNota"></p></div>
      </aside>
    </div>
  </main>

  <!-- diálogo e avisos do Workbench ficam fora do painel: aparecem mesmo com a aba fechada -->
  <dialog id="dlg" aria-labelledby="dlgT" aria-describedby="dlgP">
    <h2 id="dlgT"></h2><p id="dlgP"></p>
    <div class="row end"><button id="dlgNo">Cancelar</button><button id="dlgOk" class="danger">Confirmar</button></div>
  </dialog>
  <div id="toasts" aria-live="polite"></div>

  <div class="toast" id="toast" role="status" aria-live="polite"></div>

  <script src="/assets/validador.js"></script>

  <!-- Troca de aba. Fica antes dos scripts do Workbench para funcionar mesmo se algum deles falhar. -->
  <script>
    (function () {
      var abas = [
        { btn: 'aba-btn-validador', painel: 'aba-validador' },
        { btn: 'aba-btn-workbench', painel: 'aba-workbench' }
      ];

      function mostrar(painel, foco) {
        abas.forEach(function (a) {
          var ativo = a.painel === painel;
          var b = document.getElementById(a.btn);
          document.getElementById(a.painel).hidden = !ativo;
          b.setAttribute('aria-selected', ativo ? 'true' : 'false');
          b.tabIndex = ativo ? 0 : -1;
          if (ativo && foco) b.focus();
        });
        // o CodeMirror do Workbench mede o editor ao aparecer
        if (painel === 'aba-workbench') document.dispatchEvent(new CustomEvent('wb:visivel'));
      }

      abas.forEach(function (a, i) {
        var b = document.getElementById(a.btn);
        b.addEventListener('click', function () { mostrar(a.painel, false); });
        b.addEventListener('keydown', function (e) {
          if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
          var prox = abas[(i + (e.key === 'ArrowRight' ? 1 : abas.length - 1)) % abas.length];
          mostrar(prox.painel, true);
        });
      });
    })();
  </script>

  <script src="/assets/wb/regras-time.js"></script>
  <script src="/assets/codemirror.min.js"></script>
  <script src="/assets/wb/parser.js"></script>
  <script src="/assets/wb/rules.js"></script>
  <script src="/assets/wb/audit.js"></script>
  <script src="/assets/wb/preview.js"></script>
  <script src="/assets/wb/report.js"></script>
  <script src="/assets/wb/editor.js"></script>
  <script src="/assets/wb/app.js"></script>

  <!-- Controle do loader: independente do script.js, para a tela nunca ficar
       travada no vermelho se o script principal falhar por qualquer motivo. -->
  <script>
    (function () {
      var loader = document.getElementById("loader");
      if (!loader) return;
      var inicio = Date.now();
      var TEMPO_MINIMO = 650;   // evita piscar quando a página abre instantânea
      var TETO = 5000;          // rede lenta não pode prender a tela

      function esconder() {
        if (loader.classList.contains("hide")) return;
        var espera = Math.max(0, TEMPO_MINIMO - (Date.now() - inicio));
        setTimeout(function () { loader.classList.add("hide"); }, espera);
      }

      if (document.readyState === "complete") esconder();
      else window.addEventListener("load", esconder);
      setTimeout(esconder, TETO);
    })();
  </script>
</body>
</html>
'''

_HTML_TESTES = r'''<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Testes · SFMC Workbench</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<script>
  (function () {
    try {
      var salvo = localStorage.getItem("bradesco_validador_emkt_theme");
      var prefereEscuro = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
      document.documentElement.setAttribute("data-theme", salvo || (prefereEscuro ? "dark" : "light"));
    } catch (e) { /* localStorage bloqueado: segue no claro */ }
  })();
</script>
<link rel="stylesheet" href="/assets/validador.css">
<style>
:root{--sf:var(--card-bg);--ink:var(--text);--mu:var(--text-muted);--ln:var(--border);--er:var(--danger-fg);--ers:var(--danger-bg);--ok:var(--ok-fg);--oks:var(--ok-bg)}
body{padding:var(--space-6);max-width:980px;margin:auto}
h1{font-size:var(--t-lg);font-weight:800;letter-spacing:-.02em;margin:0 0 4px}h2{font-size:var(--t-md);font-weight:800;margin:22px 0 8px}
p{color:var(--mu);margin:0 0 14px}
a.voltar{display:inline-block;margin-bottom:var(--space-4);color:var(--bradesco-red);font-weight:700;font-size:var(--t-sm);text-decoration:none}
a.voltar:hover{text-decoration:underline}
#sum{display:inline-block;padding:6px 14px;border-radius:var(--radius-full);font-weight:700;font-size:var(--t-sm);border:1px solid}
#sum.ok{background:var(--oks);color:var(--ok)}#sum.bad{background:var(--ers);color:var(--er)}
ul{list-style:none;margin:0;padding:0;display:grid;gap:6px}
li{background:var(--sf);border:1px solid var(--ln);border-left:5px solid;border-radius:var(--radius-sm);padding:8px 12px}
li.ok{border-left-color:var(--ok)}li.bad{border-left-color:var(--er)}
li.ok>b{color:var(--ok)}li.bad>b{color:var(--er)}
ul.f{margin:6px 0}ul.f li{border:0;padding:2px 0;background:none}
code{font:12px var(--fonte-mono);background:var(--surface-2);padding:1px 4px;border-radius:3px;word-break:break-all}
details{margin-top:4px;color:var(--mu)}pre{font:12px/1.45 var(--fonte-mono);background:var(--surface-2);padding:8px;overflow:auto;max-height:260px;color:var(--ink)}
button{font:inherit;font-weight:700;font-size:var(--t-sm);padding:7px 13px;border-radius:var(--radius-sm);border:1px solid var(--ln);background:var(--sf);color:var(--ink);cursor:pointer;margin-left:8px}
button:hover{border-color:var(--bradesco-red);color:var(--bradesco-red)}
</style>
</head>
<body>
<a class="voltar" href="/">&larr; Voltar ao validador</a>
<h1>Testes automáticos do Quality Gate</h1>
<p>Cada caso roda o HTML de exemplo pelas regras padrão embutidas e compara com o resultado esperado. Os casos ficam em <code>tests/casos.js</code>.</p>
<div><span id="sum">Rodando…</span><button onclick="WB.testes.executar()">Rodar de novo</button></div>
<div id="lista"></div>
<script src="/assets/wb/parser.js"></script>
<script src="/assets/wb/rules.js"></script>
<script src="/assets/wb/audit.js"></script>
<script src="/assets/wb/preview.js"></script>
<script src="/assets/wb/tests/casos.js"></script>
<script src="/assets/wb/tests/runner.js"></script>
</body>
</html>
'''


_codemirror_cache = []


def _codemirror_js() -> str:
    """Descomprime o CodeMirror na primeira vez e guarda."""
    if not _codemirror_cache:
        _codemirror_cache.append(
            zlib.decompress(base64.b64decode(_CODEMIRROR_MIN_JS_B64)).decode("utf-8"))
    return _codemirror_cache[0]


def _regras_do_time() -> str:
    """
    regras-time.js: o arquivo ao lado do script, se existir; senão o embutido.

    Na ferramenta original o arquivo ficava na pasta compartilhada e quem o
    substituía mudava a base de todos. Este é o mesmo caminho no script único.
    """
    externo = os.path.join(PASTA_DO_SCRIPT, "regras-time.js")
    if os.path.isfile(externo):
        try:
            with open(externo, encoding="utf-8") as arquivo:
                return arquivo.read()
        except OSError:
            pass
    return _JS_WORKBENCH["regras-time"]

# endregion


# region 4. Testes automáticos do Validador
# O equivalente, para o Validador, dos testes do Workbench (/workbench/tests/):
# cada caso monta um pacote pequeno numa pasta temporária, roda a conferência de
# verdade (pacote.validar) e compara o resultado com o esperado.
#
# Dois nomes dão o esperado:
#   PACOTE_APROVADO   nada impede a publicação e não há apontamento
#   PACOTE_ERROS      o pacote reprova, e os apontamentos são os que ele traz de propósito
# O pacote de referência de cada um está nos dois primeiros casos. Os demais
# partem do PACOTE_APROVADO e estragam UMA coisa, para mostrar que cada regra
# pega o seu defeito e não mexe no resto.
#
# A leitura das imagens usa um motor de teste, que devolve o texto combinado para
# cada arquivo. Assim o resultado não depende de haver RapidOCR, Tesseract ou o
# motor do Windows instalado, nem de como cada um lê. Quem exercita o motor de
# verdade são os pacotes reais da pasta "pacotes_de_teste" (se existir).
#
# Rodar:  python validador_emkt_unificado.py --testar
#         ou a página http://127.0.0.1:5000/validador/tests/
# A rodada acontece num processo à parte: o motor de teste não pode trocar o
# motor de uma conferência que esteja em andamento na tela.

import contextlib
import html as html_lib
import json
import subprocess

PACOTE_APROVADO = "aprovado"
PACOTE_ERROS = "reprovado"

# Pacotes reais para conferir com o motor de leitura de verdade. Cada subpasta
# (PACOTE_APROVADO, PACOTE_ERROS) é um pacote como o que o marketing envia.
PASTA_PACOTES_REAIS = os.path.join(PASTA_DO_SCRIPT, "pacotes_de_teste")

_MARCA_DO_RESULTADO = "@@RESULTADO-DOS-TESTES@@"


# ------------------------------------------------------- montagem dos pacotes

def _escrever_imagem(caminho: str, ordem: int, opcoes: dict) -> None:
    """Cria uma imagem. A cor sai do nome: duas imagens iguais teriam a mesma leitura em cache."""
    from PIL import Image

    largura, altura = opcoes.get("tamanho", (600, 200))
    if opcoes.get("ruido"):
        # ruído não comprime: é o jeito de fazer um arquivo pesado sem esperar
        imagem = Image.frombytes("RGB", (largura, altura), os.urandom(largura * altura * 3))
    else:
        semente = zlib.crc32(f"{os.path.basename(caminho)}{ordem}".encode())
        cor = ((semente >> 16) & 255, (semente >> 8) & 255, semente & 255)
        imagem = Image.new("RGB", (largura, altura), cor)
    imagem.save(caminho)


def _adicionar_hyperlink(paragrafo, texto: str, url: str) -> None:
    from docx.opc.constants import RELATIONSHIP_TYPE
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    relacao = paragrafo.part.relate_to(url, RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
    link = OxmlElement("w:hyperlink")
    link.set(qn("r:id"), relacao)
    trecho = OxmlElement("w:r")
    conteudo = OxmlElement("w:t")
    conteudo.text = texto
    trecho.append(conteudo)
    link.append(trecho)
    paragrafo._p.append(link)


def _escrever_docx(caminho: str, paragrafos: list, links: dict | None = None) -> None:
    """links: texto do parágrafo -> endereço. O parágrafo inteiro vira hyperlink."""
    from docx import Document

    documento = Document()
    for texto in paragrafos:
        paragrafo = documento.add_paragraph()
        if links and texto in links:
            _adicionar_hyperlink(paragrafo, texto, links[texto])
        else:
            paragrafo.add_run(texto)
    documento.save(caminho)


class _PacoteDeTeste:
    """
    Descreve um pacote sintético: o que vai no HTML, no docx e na pasta de imagens.

    Nasce como o PACOTE_APROVADO. Cada caso muda o que precisa mudar e o
    escrever() grava tudo. O CONTEUDO.docx sai do próprio HTML (o texto vivo e
    o que o motor de teste lê em cada imagem), então os dois lados batem por
    construção, e só diverge o que o caso fizer divergir.
    """

    def __init__(self):
        # ("img", nome chamado no HTML) | ("txt", texto) | ("cru", html solto)
        self.blocos = [
            ("img", "briefing_01.png"),
            ("txt", "Olá, aproveite esta oferta exclusiva."),
            ("img", "briefing_02.png"),
            ("img", "briefing_03.png"),
            ("txt", "Para não receber mais este e-mail, clique em descadastrar."),
            ("txt", "Esta mensagem foi gerada automaticamente e não pode ser respondida."),
        ]
        # o que o motor de teste lê em cada arquivo; a chave é o nome em minúsculas
        self.leituras = {
            "briefing_01.png": ["Seu crédito está liberado", "Condições especiais para você"],
            "briefing_02.png": ["Simule agora mesmo"],
            "briefing_03.png": ["Contrate pelo aplicativo"],
        }
        # arquivos da pasta de imagens: nome -> opções ("tamanho", "ruido")
        self.imagens = {"briefing_01.png": {}, "briefing_02.png": {}, "briefing_03.png": {}}
        self.redirect = True
        self.assunto = "Crédito liberado para você"
        # palavras que não aparecem no resto da peça: a checagem do pré-header compara palavras soltas
        self.pre_header = "Taxas reduzidas só hoje."
        self.pre_header_no_html = True
        self.conteudo = None                # None: sai do HTML
        self.links_no_conteudo = {}
        self.com_html = True
        self.com_conteudo = True
        self.com_assunto = True
        self.html_em_subpasta = False

    # --- alterações usadas pelos casos -------------------------------------
    def renomear(self, antigo: str, novo: str, no_html: bool = True) -> None:
        """Renomeia o arquivo na pasta (e a chamada no HTML, se no_html)."""
        self.imagens = {(novo if n == antigo else n): o for n, o in self.imagens.items()}
        if antigo.lower() in self.leituras:
            self.leituras[novo.lower()] = self.leituras.pop(antigo.lower())
        if no_html:
            self.blocos = [("img", novo) if b == ("img", antigo) else b for b in self.blocos]

    def remover_da_pasta(self, nome: str) -> None:
        self.imagens.pop(nome, None)

    def adicionar_na_pasta(self, nome: str, **opcoes) -> None:
        self.imagens[nome] = opcoes

    def trocar_texto(self, antigo: str, novo: str) -> None:
        """Troca o texto no HTML; o docx acompanha, porque sai do HTML."""
        self.blocos = [(t, v.replace(antigo, novo)) if t != "img" else (t, v)
                       for t, v in self.blocos]

    def trocar_so_no_docx(self, antigo: str, novo: str) -> None:
        self.conteudo = [p.replace(antigo, novo) for p in self.paragrafos_do_conteudo()]

    # --- saída --------------------------------------------------------------
    def paragrafos_do_conteudo(self) -> list:
        if self.conteudo is not None:
            return list(self.conteudo)
        paragrafos = []
        for tipo, valor in self.blocos:
            if tipo == "img":
                paragrafos.extend(self.leituras.get(valor.lower(), []))
            elif tipo == "txt":
                paragrafos.append(html_lib.unescape(valor).replace("\ufeff", ""))
        return paragrafos

    def html(self) -> str:
        prefixo = "../imagens/" if self.html_em_subpasta else "imagens/"
        linhas = ['<!DOCTYPE html>',
                  '<html lang="pt-BR"><head><meta charset="utf-8"><title>Peça de teste</title></head><body>']
        if self.pre_header and self.pre_header_no_html:
            linhas.append('<div style="display:none;max-height:0;overflow:hidden">'
                          f'{self.pre_header}</div>')
        linhas.append('<table role="presentation" width="600">')
        for posicao, (tipo, valor) in enumerate(self.blocos):
            if tipo == "img":
                destino = (f"%%=RedirectTo(@link{posicao})=%%" if self.redirect
                           else "https://www.exemplo.com.br/oferta")
                linhas.append(f'<tr><td><a href="{destino}"><img src="{prefixo}{valor}" '
                              'alt="" width="600" style="display:block"></a></td></tr>')
            elif tipo == "txt":
                linhas.append(f"<tr><td>{valor}</td></tr>")
            else:
                linhas.append(valor)
        linhas.append("</table></body></html>")
        return "\n".join(linhas)

    def escrever(self, pasta: str) -> None:
        pasta_html = os.path.join(pasta, "html") if self.html_em_subpasta else pasta
        pasta_imagens = os.path.join(pasta, "imagens")
        os.makedirs(pasta_html, exist_ok=True)
        os.makedirs(pasta_imagens, exist_ok=True)
        for ordem, (nome, opcoes) in enumerate(self.imagens.items()):
            _escrever_imagem(os.path.join(pasta_imagens, nome), ordem, opcoes)
        if self.com_html:
            with open(os.path.join(pasta_html, "index.html"), "w", encoding="utf-8") as f:
                f.write(self.html())
        if self.com_conteudo:
            _escrever_docx(os.path.join(pasta, "CONTEUDO.docx"),
                           self.paragrafos_do_conteudo(), self.links_no_conteudo)
        if self.com_assunto:
            linhas = [f"Assunto: {self.assunto}"]
            if self.pre_header:
                linhas.append(f"Pré-header: {self.pre_header}")
            _escrever_docx(os.path.join(pasta, "ASSUNTO.docx"), linhas)


# --------------------------------------------------------------- motor de teste

def _criar_motor_de_teste(leituras: dict):
    """Motor de leitura que devolve o texto combinado para cada arquivo."""
    from validador import ocr

    class MotorDeTeste(ocr.MotorBase):
        nome = "motor-de-teste"
        descricao = "Motor de teste (texto combinado por arquivo)"

        def __init__(self):
            self.chamadas = []

        def disponivel(self):
            return True, "ok"

        def ler(self, caminho, idioma, confianca_minima):
            nome = os.path.basename(caminho)
            self.chamadas.append(nome)
            linhas = list(leituras.get(nome.lower(), []))
            return ocr.ResultadoOCR(
                arquivo=nome, texto=ocr.limpar("\n".join(linhas)), lido=True,
                linhas=linhas, motor=self.nome, confianca_media=99.0,
            )

    return MotorDeTeste()


@contextlib.contextmanager
def _ocr_de_teste(motor):
    """Põe o motor de teste no lugar e manda o cache para uma pasta descartável."""
    from validador import ocr

    guardados = (ocr._ESCOLHIDO, ocr.PASTA_CACHE)
    pasta_cache = tempfile.mkdtemp(prefix="teste_cache_")
    ocr._ESCOLHIDO = motor
    ocr.PASTA_CACHE = pasta_cache
    try:
        yield pasta_cache
    finally:
        ocr._ESCOLHIDO, ocr.PASTA_CACHE = guardados
        shutil.rmtree(pasta_cache, ignore_errors=True)


# ------------------------------------------------------------------ comparação

def _nomes(valor):
    """Lista de apontamentos como lista de nomes: ('a.png', 'motivo') vira 'a.png'."""
    if isinstance(valor, (dict, bool)):
        return valor
    return sorted((v[0] if isinstance(v, (tuple, list)) else v) for v in (valor or []))


def _resumo(resultado) -> str:
    """O que o Validador devolveu, em poucas linhas, para quem for investigar uma falha."""
    linhas = [f"status: {resultado.status} (texto em modo {resultado.modo_texto})"]
    for campo in ("erros", "bloqueios", "alertas", "avisos"):
        for item in getattr(resultado, campo):
            linhas.append(f"{campo[:-1] if campo != 'avisos' else 'aviso'}: {item}")
    ri = resultado.resultado_imagens
    if ri:
        for campo in ("fora_da_taxonomia", "numeros_faltando", "numeros_duplicados",
                      "nao_comeca_em_um", "extensao_invalida", "acima_do_peso",
                      "na_pasta_fora_do_html", "no_html_fora_da_pasta",
                      "divergencia_de_caixa", "material_de_apoio", "repeticoes_no_html"):
            valor = getattr(ri, campo)
            if valor:
                linhas.append(f"imagens.{campo}: {valor}")
    if resultado.resultado_texto:
        divergencias = getattr(resultado.resultado_texto, "divergencias", [])
        linhas.append(f"texto: {resultado.resultado_texto.status}, "
                      f"{len(divergencias)} divergência(s)")
        for d in divergencias[:4]:
            linhas.append(f"  - {d.tipo}: html «{d.trecho_html[:60]}» × docx «{d.trecho_docx[:60]}»")
    if resultado.apontamentos_assunto:
        linhas.append(f"assunto/pré-header: {len(resultado.apontamentos_assunto)} apontamento(s)")
    return "\n".join(linhas)


def _comparar(resultado, espera: dict) -> list:
    """Compara o resultado com o esperado. Devolve [(o que, esperado, obtido)]."""
    falhas = []

    def falha(o_que, esperado, obtido):
        falhas.append((o_que, str(esperado), str(obtido)))

    if "status" in espera and resultado.status != espera["status"]:
        falha("Status", espera["status"], resultado.status)

    for campo in ("erros", "bloqueios", "alertas", "avisos"):
        mensagens = [m.lower() for m in getattr(resultado, campo)]
        for trecho in espera.get(campo, []):
            if not any(trecho.lower() in m for m in mensagens):
                falha(f"{campo}: deveria conter", trecho, getattr(resultado, campo) or "(vazio)")
        for trecho in espera.get("sem_" + campo, []):
            if any(trecho.lower() in m for m in mensagens):
                falha(f"{campo}: não deveria conter", "(ausente)", trecho)
    for campo in espera.get("vazio", []):
        if getattr(resultado, campo):
            falha(f"{campo} deveria estar vazio", "[]", getattr(resultado, campo))

    ri = resultado.resultado_imagens
    if "imagens_ok" in espera:
        obtido = bool(ri and ri.aprovado)
        if obtido != espera["imagens_ok"]:
            falha("Conferência de imagens aprovada", espera["imagens_ok"], obtido)
    for campo, esperado in espera.get("imagens", {}).items():
        obtido = _nomes(getattr(ri, campo)) if ri else "(sem leitura de imagens)"
        if obtido != _nomes(esperado):
            falha(f"imagens.{campo}", esperado, obtido)

    rt = resultado.resultado_texto
    if "texto_status" in espera and (rt.status if rt else None) != espera["texto_status"]:
        falha("Status do texto", espera["texto_status"], rt.status if rt else "(sem leitura)")
    if "divergencias_min" in espera:
        quantas = len(getattr(rt, "divergencias", [])) if rt else 0
        if quantas < espera["divergencias_min"]:
            falha("Divergências de texto (mínimo)", espera["divergencias_min"], quantas)
    if "modo_texto" in espera and resultado.modo_texto != espera["modo_texto"]:
        falha("Modo da comparação de texto", espera["modo_texto"], resultado.modo_texto)
    if "apontamentos_assunto_min" in espera:
        if len(resultado.apontamentos_assunto) < espera["apontamentos_assunto_min"]:
            falha("Apontamentos de assunto/pré-header (mínimo)",
                  espera["apontamentos_assunto_min"], len(resultado.apontamentos_assunto))
    return falhas


# ----------------------------------------------------------------------- casos

class _Pulado(Exception):
    """O caso não se aplica nesta máquina (por exemplo, falta motor de leitura)."""


class _Caso:
    def __init__(self, grupo, nome, alterar=None, espera=None, executar=None,
                 sem_ocr=False, pasta_real=""):
        self.grupo, self.nome = grupo, nome
        self.alterar, self.espera = alterar, espera or {}
        self.executar = executar          # função() -> falhas, para o que não é um pacote
        self.sem_ocr = sem_ocr
        self.pasta_real = pasta_real


def _hoje_mais(dias: int) -> str:
    from datetime import date, timedelta
    return (date.today() + timedelta(days=dias)).strftime("%d/%m/%Y")


def _alterar_pacote_erros(p: _PacoteDeTeste) -> None:
    """Vários defeitos de uma vez, como chega pacote ruim de verdade."""
    p.redirect = False                                  # publicação exige redirect
    p.pre_header = "Taxas reduzidas só hoje"                 # sem ponto final
    p.renomear("briefing_02.png", "briefing_04.png")    # furo na numeração (falta o 02)
    p.adicionar_na_pasta("briefing_05.png")             # imagem que o HTML não chama
    p.trocar_so_no_docx("exclusiva", "especial")        # texto do docx diferente do HTML
    p.links_no_conteudo = {"Olá, aproveite esta oferta especial.": "https://www.exemplo.com.br"}


def _casos_de_pacote() -> list:
    c = []

    def caso(grupo, nome, alterar=None, **espera):
        sem_ocr = espera.pop("sem_ocr", False)
        c.append(_Caso(grupo, nome, alterar=alterar, espera=espera, sem_ocr=sem_ocr))

    G = "Pacotes de referência"
    caso(G, "PACOTE_APROVADO: nada impede a publicação e não há apontamento",
         status=PACOTE_APROVADO, vazio=["erros", "bloqueios", "alertas", "avisos"],
         imagens_ok=True, texto_status="aprovado", modo_texto="sequencia")
    caso(G, "PACOTE_ERROS: reprova, com os apontamentos que ele traz de propósito",
         _alterar_pacote_erros, status=PACOTE_ERROS,
         bloqueios=["Nenhum redirect", "pré-header não termina em ponto final",
                    "hyperlink no CONTEUDO.docx"],
         imagens_ok=False,
         imagens={"numeros_faltando": [2], "na_pasta_fora_do_html": ["briefing_05.png"]},
         divergencias_min=1)

    G = "Imagens: taxonomia e sequência"
    caso(G, "Furo na numeração (01, 03, 04) reprova",
         lambda p: p.renomear("briefing_02.png", "briefing_04.png"),
         status=PACOTE_ERROS, imagens={"numeros_faltando": [2]})
    caso(G, "Numeração que não começa em 01 reprova",
         lambda p: p.renomear("briefing_01.png", "briefing_04.png"),
         status=PACOTE_ERROS, imagens={"nao_comeca_em_um": True, "numeros_faltando": [1]})
    caso(G, "Número repetido na pasta reprova",
         lambda p: p.adicionar_na_pasta("briefing_02.jpg"),
         status=PACOTE_ERROS, imagens={"numeros_duplicados": [2]})
    caso(G, "Prefixo diferente da quebra reprova",
         lambda p: p.renomear("briefing_03.png", "promo_03.png"),
         status=PACOTE_ERROS, imagens={"fora_da_taxonomia": ["promo_03.png"]})
    caso(G, "Imagem chamada no HTML sem número no nome reprova",
         lambda p: p.renomear("briefing_03.png", "banner.png"),
         status=PACOTE_ERROS, imagens={"fora_da_taxonomia": ["banner.png"]})
    caso(G, "Extensão fora do padrão (.bmp) reprova",
         lambda p: p.renomear("briefing_03.png", "briefing_03.bmp"),
         status=PACOTE_ERROS, imagens={"extensao_invalida": ["briefing_03.bmp (extensão .bmp)"]})
    caso(G, "Imagem acima de 1 MB reprova",
         lambda p: p.imagens.update({"briefing_02.png": {"ruido": True, "tamanho": (700, 700)}}),
         status=PACOTE_ERROS, imagens={"acima_do_peso": ["briefing_02.png"]})

    G = "Imagens: pasta x HTML"
    caso(G, "Imagem na pasta que o HTML não chama reprova",
         lambda p: p.adicionar_na_pasta("briefing_04.png"),
         status=PACOTE_ERROS, imagens={"na_pasta_fora_do_html": ["briefing_04.png"]})
    caso(G, "Imagem que o HTML chama e não está na pasta reprova",
         lambda p: p.remover_da_pasta("briefing_03.png"),
         status=PACOTE_ERROS, imagens={"no_html_fora_da_pasta": ["briefing_03.png"]})
    caso(G, "Maiúscula e minúscula diferentes entre a pasta e o HTML reprovam",
         lambda p: p.renomear("briefing_01.png", "Briefing_01.png", no_html=False),
         status=PACOTE_ERROS, imagens={"divergencia_de_caixa": ["Briefing_01.png"]})
    caso(G, "Arte de conferência (preview_final) é material de apoio e não reprova",
         lambda p: p.adicionar_na_pasta("preview_final.png", tamanho=(600, 2000)),
         status=PACOTE_APROVADO, imagens_ok=True,
         imagens={"material_de_apoio": ["preview_final.png"], "na_pasta_fora_do_html": []})
    caso(G, "A mesma imagem repetida no HTML é permitida",
         lambda p: p.blocos.insert(4, ("img", "briefing_01.png")),
         status=PACOTE_APROVADO, imagens_ok=True,
         imagens={"repeticoes_no_html": {"briefing_01.png": 2}})

    G = "Regras de publicação"
    caso(G, "HTML sem redirect reprova",
         lambda p: setattr(p, "redirect", False),
         status=PACOTE_ERROS, bloqueios=["Nenhum redirect"])
    caso(G, "Pré-header sem ponto final reprova",
         lambda p: setattr(p, "pre_header", "Taxas reduzidas só hoje"),
         status=PACOTE_ERROS, bloqueios=["pré-header não termina em ponto final"])
    caso(G, "Pré-header terminado em ! vale como ponto final",
         lambda p: setattr(p, "pre_header", "Taxas reduzidas só hoje!"),
         status=PACOTE_APROVADO, sem_bloqueios=["pré-header"])
    caso(G, "Assunto acima de 35 caracteres é alerta e não reprova",
         lambda p: setattr(p, "assunto", "Seu crédito pré-aprovado já está liberado para contratação"),
         status=PACOTE_APROVADO, alertas=["Assunto com"], vazio=["bloqueios"])
    caso(G, "Pré-header acima de 40 caracteres é alerta e não reprova",
         lambda p: setattr(p, "pre_header", "Simule agora o seu crédito e contrate em poucos minutos."),
         status=PACOTE_APROVADO, alertas=["Pré-header com"], vazio=["bloqueios"])
    caso(G, "Hyperlink no CONTEUDO.docx reprova",
         lambda p: setattr(p, "links_no_conteudo",
                           {"Olá, aproveite esta oferta exclusiva.": "https://www.exemplo.com.br"}),
         status=PACOTE_ERROS, bloqueios=["hyperlink no CONTEUDO.docx"])
    caso(G, "Endereço no disclaimer sem a proteção anti-link reprova",
         lambda p: p.trocar_texto("não pode ser respondida.",
                                  "não pode ser respondida. Veja www.bradesco.com.br/ajuda."),
         status=PACOTE_ERROS, bloqueios=["Endereço sem o código que impede o hyperlink"])
    caso(G, "Endereço no disclaimer com &#xFEFF; está protegido",
         lambda p: p.trocar_texto("não pode ser respondida.",
                                  "não pode ser respondida. Veja www.bradesco&#xFEFF;.com.br/ajuda."),
         status=PACOTE_APROVADO, vazio=["bloqueios"])
    caso(G, "Data vencida no disclaimer vira alerta e não reprova",
         lambda p: p.blocos.append(("txt", f"Oferta válida até {_hoje_mais(-30)}.")),
         status=PACOTE_APROVADO, alertas=["Data vencida"], vazio=["bloqueios"])
    caso(G, "Data futura no disclaimer não gera alerta",
         lambda p: p.blocos.append(("txt", f"Oferta válida até {_hoje_mais(30)}.")),
         status=PACOTE_APROVADO, vazio=["alertas", "bloqueios"])

    G = "Texto: HTML e imagens x CONTEUDO.docx"
    caso(G, "Palavra trocada no docx é divergência",
         lambda p: p.trocar_so_no_docx("exclusiva", "especial"),
         status=PACOTE_ERROS, divergencias_min=1)
    caso(G, "Número trocado no texto da imagem (48x no banner, 60x no docx) reprova",
         lambda p: (p.leituras.update({"briefing_02.png": ["Parcelas em até 48x"]}),
                    p.trocar_so_no_docx("Parcelas em até 48x", "Parcelas em até 60x")),
         status=PACOTE_ERROS, divergencias_min=1)
    caso(G, "Aspas curvas do Word contra aspas retas do HTML não divergem",
         lambda p: (p.trocar_texto("aproveite esta", '"aproveite" esta'),
                    p.trocar_so_no_docx('"aproveite"', "\u201caproveite\u201d")),
         status=PACOTE_APROVADO, texto_status="aprovado", vazio=["bloqueios", "alertas"])

    G = "Assunto e pré-header"
    caso(G, "Pré-header que não está no HTML vira atenção",
         lambda p: setattr(p, "pre_header_no_html", False),
         status="atencao", apontamentos_assunto_min=1, vazio=["bloqueios"])
    caso(G, "Sem o docx de assunto: avisa, e o resto da conferência segue",
         lambda p: (setattr(p, "com_assunto", False), setattr(p, "pre_header_no_html", False)),
         avisos=["Não identifiquei um docx de assunto"], vazio=["erros", "bloqueios"])

    G = "Estrutura do pacote"
    caso(G, "Pacote sem docx dá erro e explica",
         lambda p: (setattr(p, "com_conteudo", False), setattr(p, "com_assunto", False)),
         status="erro", erros=["Nenhum arquivo .docx"])
    caso(G, "Pacote sem HTML dá erro",
         lambda p: setattr(p, "com_html", False),
         status="erro", erros=["nenhum arquivo .html"])
    caso(G, "HTML numa subpasta html/, com as imagens ao lado, é achado e aprovado",
         lambda p: setattr(p, "html_em_subpasta", True),
         status=PACOTE_APROVADO, vazio=["erros", "bloqueios", "alertas"], imagens_ok=True)
    caso(G, "Sem leitura de imagem a conferência nunca aprova (fica em atenção)",
         None, sem_ocr=True, status="atencao", modo_texto="presenca", vazio=["bloqueios"])
    return c


# ------------------------------------- casos que não são um pacote (recursos novos)

def _caso_lote() -> list:
    from validador import pacote

    with tempfile.TemporaryDirectory(prefix="teste_lote_", ignore_cleanup_errors=True) as raiz:
        for nome in ("campanha_a", "campanha_b"):
            _PacoteDeTeste().escrever(os.path.join(raiz, nome))
        pastas = pacote.localizar_pacotes(raiz)
        leituras = _PacoteDeTeste().leituras
        with _ocr_de_teste(_criar_motor_de_teste(leituras)):
            status = [r.status for r in pacote.validar_lote(raiz)]
    falhas = []
    if [os.path.basename(p) for p in pastas] != ["campanha_a", "campanha_b"]:
        falhas.append(("Pacotes encontrados", "campanha_a, campanha_b",
                       [os.path.basename(p) for p in pastas]))
    if status != [PACOTE_APROVADO, PACOTE_APROVADO]:
        falhas.append(("Status de cada pacote do lote", [PACOTE_APROVADO] * 2, status))
    return falhas


def _caso_cache_le_uma_vez() -> list:
    """Conferir o mesmo pacote de novo não relê as imagens: a leitura vem do cache em disco."""
    from validador import pacote

    spec = _PacoteDeTeste()
    motor = _criar_motor_de_teste(spec.leituras)
    with tempfile.TemporaryDirectory(prefix="teste_cache_", ignore_cleanup_errors=True) as pasta:
        spec.escrever(pasta)
        with _ocr_de_teste(motor):
            pacote.validar(pasta)
            primeira = len(motor.chamadas)
            pacote.validar(pasta)
            segunda = len(motor.chamadas) - primeira
    falhas = []
    if primeira != 3:
        falhas.append(("Imagens lidas na primeira conferência", 3, primeira))
    if segunda != 0:
        falhas.append(("Imagens lidas de novo na segunda conferência", 0, segunda))
    return falhas


def _caso_cache_pelo_conteudo() -> list:
    """A impressão do cache vem do conteúdo do arquivo e do motor, não do nome nem da pasta."""
    from validador import ocr

    with tempfile.TemporaryDirectory(prefix="teste_impressao_", ignore_cleanup_errors=True) as pasta:
        a, b, c = (os.path.join(pasta, n) for n in ("a.png", "copia.png", "outra.png"))
        _escrever_imagem(a, 1, {})
        shutil.copyfile(a, b)
        _escrever_imagem(c, 2, {})
        igual_com_outro_nome = ocr._impressao_do_arquivo(a, "m") == ocr._impressao_do_arquivo(b, "m")
        muda_com_o_motor = ocr._impressao_do_arquivo(a, "m") != ocr._impressao_do_arquivo(a, "n")
        muda_com_a_imagem = ocr._impressao_do_arquivo(a, "m") != ocr._impressao_do_arquivo(c, "m")
    falhas = []
    if not igual_com_outro_nome:
        falhas.append(("Mesmo conteúdo com outro nome", "mesma impressão", "impressão diferente"))
    if not muda_com_o_motor:
        falhas.append(("Outro motor", "impressão diferente", "mesma impressão"))
    if not muda_com_a_imagem:
        falhas.append(("Outra imagem", "impressão diferente", "mesma impressão"))
    return falhas


def _caso_versao_da_leitura() -> list:
    """A chave do cache só muda quando muda o código que decide a leitura."""
    from validador import ocr

    original = ocr.__dict__["_FONTES_DO_SCRIPT"]
    base = ocr._versao_da_leitura()

    def versao_com(**mudancas):
        ocr.__dict__["_FONTES_DO_SCRIPT"] = {
            **original, **{k: original[k] + "\n# mudou" for k in mudancas}}
        try:
            return ocr._versao_da_leitura()
        finally:
            ocr.__dict__["_FONTES_DO_SCRIPT"] = original

    falhas = []
    for modulo in ("ocr", "layout", "normalizacao"):
        if versao_com(**{modulo: 1}) == base:
            falhas.append((f"Mudar o módulo {modulo}", "versão diferente", "mesma versão"))
    # o que roda depois da leitura não pode invalidar o cache
    for modulo in ("comparador", "presenca", "correcao_ocr", "html_parser", "regras",
                   "pacote", "relatorio", "serializacao", "imagens", "docx_parser"):
        if versao_com(**{modulo: 1}) != base:
            falhas.append((f"Mudar o módulo {modulo}", "mesma versão", "versão diferente"))
    if ocr.VERSAO_DA_LEITURA != base:
        falhas.append(("Versão calculada na carga do script", base, ocr.VERSAO_DA_LEITURA))
    return falhas


def _caso_limpeza_de_relatorios() -> list:
    falhas = []
    with tempfile.TemporaryDirectory(prefix="teste_relatorios_", ignore_cleanup_errors=True) as pasta:
        def criar(nome, dias_de_idade):
            caminho = os.path.join(pasta, nome)
            with open(caminho, "w", encoding="utf-8") as f:
                f.write("<html></html>")
            instante = time.time() - dias_de_idade * 86400
            os.utime(caminho, (instante, instante))

        criar("a1b2c3d4e5f6.html", 40)        # velho: sai
        criar("0123456789ab.html", 29)        # recente: fica
        criar("ffffffffffff.html", 31)        # velho: sai
        criar("notas-do-time.html", 400)      # nome que não é de relatório: nunca é tocado
        criar("a1b2c3d4e5f6.html.bak", 400)   # idem
        os.makedirs(os.path.join(pasta, "aaaaaaaaaaaa.html"))   # pasta com nome de relatório: fica
        velho = time.time() - 400 * 86400
        os.utime(os.path.join(pasta, "aaaaaaaaaaaa.html"), (velho, velho))

        apagados, liberados = limpar_relatorios_antigos(30, pasta)
        restantes = sorted(os.listdir(pasta))
        esperados = sorted(["0123456789ab.html", "notas-do-time.html",
                            "a1b2c3d4e5f6.html.bak", "aaaaaaaaaaaa.html"])
        if apagados != 2:
            falhas.append(("Relatórios apagados", 2, apagados))
        if liberados != 2 * len("<html></html>"):
            falhas.append(("Bytes liberados", 2 * len("<html></html>"), liberados))
        if restantes != esperados:
            falhas.append(("Arquivos que sobram", esperados, restantes))

        if limpar_relatorios_antigos(0, pasta) != (0, 0):
            falhas.append(("Com 0 dias a limpeza fica desligada", (0, 0), "apagou algo"))
        if limpar_relatorios_antigos(30, os.path.join(pasta, "nao-existe")) != (0, 0):
            falhas.append(("Pasta que não existe", (0, 0), "erro ou apagou algo"))
        criar("bbbbbbbbbbbb.html", 5)
        # sobram o de 29 dias e o de 5: com limite de 3 dias, saem os dois
        if limpar_relatorios_antigos(3, pasta)[0] != 2:
            falhas.append(("Limite configurável (3 dias)", 2, "outro valor"))
    return falhas


def _caso_idioma_aviso() -> list:
    """O aviso de idioma aparece só com Tesseract sem português, e chega no pacote."""
    from validador import ocr, pacote

    class TesseractSemPortugues(ocr.MotorTesseract):
        idiomas_simulados = ["eng", "osd"]

        def disponivel(self):
            return True, "ok"

        def idiomas(self):
            return list(self.idiomas_simulados)

        def ler(self, caminho, idioma, confianca_minima):
            nome = os.path.basename(caminho)
            return ocr.ResultadoOCR(arquivo=nome, lido=True, motor=self.nome, confianca_media=99.0)

    falhas = []
    motor = TesseractSemPortugues()
    with _ocr_de_teste(motor):
        aviso = ocr.aviso_de_idioma()
        if "--instalar-idioma-por" not in aviso:
            falhas.append(("Aviso com Tesseract sem português", "traz o comando de instalação", aviso or "(vazio)"))
        spec = _PacoteDeTeste()
        with tempfile.TemporaryDirectory(prefix="teste_idioma_", ignore_cleanup_errors=True) as pasta:
            spec.escrever(pasta)
            resultado = pacote.validar(pasta)
        if not any("idioma português" in a for a in resultado.avisos):
            falhas.append(("Aviso no resultado do pacote", "menciona o idioma português", resultado.avisos))
        motor.idiomas_simulados = ["eng", "por"]
        if ocr.aviso_de_idioma():
            falhas.append(("Aviso com o português instalado", "(vazio)", ocr.aviso_de_idioma()))
    with _ocr_de_teste(_criar_motor_de_teste({})):
        if ocr.aviso_de_idioma():
            falhas.append(("Aviso com outro motor (RapidOCR, Windows)", "(vazio)", ocr.aviso_de_idioma()))
    return falhas


def _caso_idioma_instalador() -> list:
    """O instalador baixa por e eng para a pasta, recusa download pequeno demais e não deixa arquivo pela metade."""
    import functools
    import threading
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

    from validador import ocr

    falhas = []
    with tempfile.TemporaryDirectory(prefix="teste_servidor_", ignore_cleanup_errors=True) as servido, \
            tempfile.TemporaryDirectory(prefix="teste_destino_", ignore_cleanup_errors=True) as destino_a, \
            tempfile.TemporaryDirectory(prefix="teste_destino_", ignore_cleanup_errors=True) as destino_b:
        for idioma in ("por", "eng"):
            with open(os.path.join(servido, f"{idioma}.traineddata"), "wb") as f:
                f.write(os.urandom(250_000))

        class Silencioso(SimpleHTTPRequestHandler):
            def log_message(self, *args):
                pass

        servidor = ThreadingHTTPServer(
            ("127.0.0.1", 0), functools.partial(Silencioso, directory=servido))
        threading.Thread(target=servidor.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{servidor.server_address[1]}"
        try:
            mensagens = []
            if not ocr.instalar_idioma_por(imprimir=mensagens.append, destino=destino_a, url_base=url):
                falhas.append(("Instalação com o servidor no ar", "True", mensagens[-2:]))
            if sorted(os.listdir(destino_a)) != ["eng.traineddata", "por.traineddata"]:
                falhas.append(("Arquivos instalados", "eng e por", sorted(os.listdir(destino_a))))

            mensagens = []
            if ocr.instalar_idioma_por(imprimir=mensagens.append, destino=destino_b,
                                       url_base=url, minimo_bytes=10_000_000):
                falhas.append(("Download pequeno demais", "recusado", "aceito"))
            if os.listdir(destino_b):
                falhas.append(("Arquivo pela metade", "nenhum", os.listdir(destino_b)))
            if not any("pequeno demais" in m for m in mensagens):
                falhas.append(("Mensagem de download pequeno", "explica o motivo", mensagens))
        finally:
            servidor.shutdown()

        # rede fora do ar: falha com mensagem, sem exceção
        mensagens = []
        with tempfile.TemporaryDirectory(prefix="teste_destino_", ignore_cleanup_errors=True) as destino_c:
            if ocr.instalar_idioma_por(imprimir=mensagens.append, destino=destino_c,
                                       url_base="http://127.0.0.1:1"):
                falhas.append(("Rede fora do ar", "False", "True"))
            if not any("TESSDATA_URL" in m for m in mensagens):
                falhas.append(("Mensagem de rede fora do ar", "cita o espelho TESSDATA_URL", mensagens))
    return falhas


def _caso_ponte_com_o_workbench() -> list:
    """/api/preview/<id>/html entrega o HTML do pacote, qualquer que seja a codificação."""
    falhas = []
    with tempfile.TemporaryDirectory(prefix="teste_ponte_", ignore_cleanup_errors=True) as pasta:
        utf8 = os.path.join(pasta, "utf8.html")
        antigo = os.path.join(pasta, "index.html")
        with open(utf8, "wb") as f:
            f.write("\ufeff<html><body>Ação é crédito</body></html>".encode("utf-8"))
        with open(antigo, "wb") as f:
            f.write("<html><body>Ação é crédito</body></html>".encode("cp1252"))

        identificadores = {"testeponte" + uuid.uuid4().hex[:6]: utf8,
                           "testeponte" + uuid.uuid4().hex[:6]: antigo}
        for identificador, caminho in identificadores.items():
            _previews[identificador] = {"html": caminho, "raiz": pasta, "imagens": pasta,
                                        "paragrafos": [], "leitura": [], "nome": "pacote-teste"}
        try:
            cliente = app.test_client()
            for identificador, caminho in identificadores.items():
                resposta = cliente.get(f"/api/preview/{identificador}/html")
                dados = resposta.get_json(silent=True) or {}
                nome = os.path.basename(caminho)
                if resposta.status_code != 200:
                    falhas.append((f"Resposta para {nome}", 200, resposta.status_code))
                    continue
                if dados.get("html", "").lstrip("\ufeff") != "<html><body>Ação é crédito</body></html>":
                    falhas.append((f"HTML devolvido de {nome}", "texto com acentos, sem BOM", dados.get("html")))
                if dados.get("arquivo") != nome:
                    falhas.append((f"Nome do arquivo de {nome}", nome, dados.get("arquivo")))
            if cliente.get("/api/preview/naoexiste123/html").status_code != 404:
                falhas.append(("Identificador desconhecido", 404, "outro status"))
            if cliente.get("/api/preview/..%2F..%2Fx/html").status_code != 404:
                falhas.append(("Identificador com caminho", 404, "outro status"))
        finally:
            for identificador in identificadores:
                _previews.pop(identificador, None)
    return falhas


def _caso_ponte_na_tela() -> list:
    """O botão do Validador e o carregador do Workbench estão ligados um ao outro."""
    falhas = []
    if "data-workbench" not in _JS_VALIDADOR or "abrirNoWorkbench" not in _JS_VALIDADOR:
        falhas.append(("Botão no resultado do Validador", "presente", "ausente"))
    if "Abrir o HTML deste pacote no Workbench" not in _JS_VALIDADOR:
        falhas.append(("Rótulo do botão", "Abrir o HTML deste pacote no Workbench", "ausente"))
    if "WB.abrirPeca = abrirPeca" not in _JS_WORKBENCH["app"]:
        falhas.append(("WB.abrirPeca no Workbench", "exposto", "ausente"))
    if "WB.abrirPeca(" not in _JS_VALIDADOR:
        falhas.append(("Chamada a WB.abrirPeca no Validador", "presente", "ausente"))
    return falhas


def _casos_de_recursos() -> list:
    c = []
    G = "Estrutura do pacote"
    c.append(_Caso(G, "Pasta com dois pacotes: os dois são achados e conferidos", executar=_caso_lote))
    G = "Cache do OCR"
    c.append(_Caso(G, "Conferir o mesmo pacote de novo não relê as imagens", executar=_caso_cache_le_uma_vez))
    c.append(_Caso(G, "A impressão do cache vem do conteúdo da imagem e do motor, não do nome",
                   executar=_caso_cache_pelo_conteudo))
    c.append(_Caso(G, "A versão da leitura só muda com o código de ocr, layout e normalizacao",
                   executar=_caso_versao_da_leitura))
    G = "Limpeza dos relatórios"
    c.append(_Caso(G, "Apaga só relatórios com mais de X dias e respeita o resto da pasta",
                   executar=_caso_limpeza_de_relatorios))
    G = "Idioma do Tesseract"
    c.append(_Caso(G, "Avisa quando o Tesseract está sem português, e só nesse caso",
                   executar=_caso_idioma_aviso))
    c.append(_Caso(G, "O instalador baixa o idioma, recusa arquivo suspeito e explica falha de rede",
                   executar=_caso_idioma_instalador))
    G = "Ponte Validador → Workbench"
    c.append(_Caso(G, "A rota entrega o HTML do pacote (UTF-8 e Windows-1252) e recusa id inválido",
                   executar=_caso_ponte_com_o_workbench))
    c.append(_Caso(G, "O botão e o carregador do Workbench estão ligados", executar=_caso_ponte_na_tela))
    return c


def _casos_de_pacotes_reais() -> list:
    casos = []
    for nome, esperado in (("PACOTE_APROVADO", PACOTE_APROVADO), ("PACOTE_ERROS", PACOTE_ERROS)):
        pasta = os.path.join(PASTA_PACOTES_REAIS, nome)
        if os.path.isdir(pasta):
            casos.append(_Caso("Pacotes reais (motor de leitura de verdade)",
                               f"{nome}: o status esperado é {esperado}",
                               espera={"status": esperado}, pasta_real=pasta))
    return casos


# -------------------------------------------------------------------- execução

def _rodar_caso(caso: _Caso) -> tuple:
    """Devolve (falhas, resumo). Levanta _Pulado quando o caso não se aplica."""
    from validador import ocr, pacote

    if caso.executar:
        return caso.executar(), ""

    if caso.pasta_real:
        disponivel, motivo = ocr.ocr_disponivel()
        if caso.espera.get("status") == PACOTE_APROVADO and not disponivel:
            raise _Pulado(f"sem motor de leitura de imagem ({motivo})")
        resultado = pacote.validar(caso.pasta_real, usar_ocr=True)
        motor = ocr.motor_ativo()
        return (_comparar(resultado, caso.espera),
                _resumo(resultado) + f"\nmotor de leitura: {motor.descricao if motor else 'nenhum'}")

    spec = _PacoteDeTeste()
    if caso.alterar:
        caso.alterar(spec)
    with _ocr_de_teste(_criar_motor_de_teste(spec.leituras)):
        with tempfile.TemporaryDirectory(prefix="teste_pacote_", ignore_cleanup_errors=True) as pasta:
            spec.escrever(pasta)
            resultado = pacote.validar(pasta, usar_ocr=not caso.sem_ocr)
    return _comparar(resultado, caso.espera), _resumo(resultado)


def executar_testes_do_validador() -> dict:
    """Roda todos os casos neste processo e devolve o relatório (a tela e o terminal usam o mesmo)."""
    casos = _casos_de_pacote() + _casos_de_recursos() + _casos_de_pacotes_reais()
    inicio = time.time()
    saida = []
    for caso in casos:
        item = {"nome": caso.nome, "grupo": caso.grupo, "falhas": [], "resumo": "", "pulado": ""}
        try:
            falhas, resumo = _rodar_caso(caso)
            item["resumo"] = resumo
            item["falhas"] = [{"msg": m, "esperado": e, "obtido": o} for m, e, o in falhas]
        except _Pulado as motivo:
            item["pulado"] = str(motivo)
        except Exception as erro:  # noqa: BLE001 - o caso quebrou: aparece como falha, não derruba a rodada
            item["falhas"] = [{"msg": "Erro ao executar o caso", "esperado": "",
                               "obtido": f"{type(erro).__name__}: {erro}"}]
        saida.append(item)

    pulados = sum(1 for i in saida if i["pulado"])
    falharam = sum(1 for i in saida if i["falhas"])
    return {
        "total": len(saida),
        "passaram": len(saida) - falharam - pulados,
        "falharam": falharam,
        "pulados": pulados,
        "segundos": round(time.time() - inicio, 1),
        "pacotes_reais": {"pasta": PASTA_PACOTES_REAIS,
                          "existe": os.path.isdir(PASTA_PACOTES_REAIS)},
        "casos": saida,
    }


def testar_pelo_terminal(como_json: bool = False) -> int:
    """--testar: imprime a rodada e sai com 1 se algum caso falhou."""
    relatorio = executar_testes_do_validador()
    if como_json:
        # ASCII puro: o terminal do Windows não garante UTF-8 num pipe
        print(_MARCA_DO_RESULTADO + json.dumps(relatorio, ensure_ascii=True))
        return 0
    try:
        sys.stdout.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass
    grupo_atual = None
    for caso in relatorio["casos"]:
        if caso["grupo"] != grupo_atual:
            grupo_atual = caso["grupo"]
            print(f"\n{grupo_atual}")
        marca = "[pulado]" if caso["pulado"] else ("[FALHOU]" if caso["falhas"] else "[ok]    ")
        print(f"  {marca} {caso['nome']}")
        if caso["pulado"]:
            print(f"            {caso['pulado']}")
        for falha in caso["falhas"]:
            print(f"            {falha['msg']}: esperado {falha['esperado']}, obtido {falha['obtido']}")
        if caso["falhas"] and caso["resumo"]:
            for linha in caso["resumo"].splitlines():
                print(f"            | {linha}")
    print(f"\n{relatorio['passaram']} passaram, {relatorio['falharam']} falharam, "
          f"{relatorio['pulados']} pulados, em {relatorio['segundos']} s.")
    if not relatorio["pacotes_reais"]["existe"]:
        print("Pacotes reais: crie pacotes_de_teste/PACOTE_APROVADO e/ou PACOTE_ERROS "
              "ao lado do script para incluí-los.")
    return 1 if relatorio["falharam"] else 0


def rodar_testes_em_processo_separado() -> tuple:
    """
    Roda --testar em outro processo e devolve (relatório, erro).

    Processo à parte porque o motor de teste troca o motor de leitura do
    módulo: no mesmo processo isso atropelaria uma conferência em andamento.
    """
    try:
        processo = subprocess.run(
            [sys.executable, _CAMINHO_DO_SCRIPT, "--testar", "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=900, cwd=PASTA_DO_SCRIPT,
            env={**os.environ, "ABRIR_NAVEGADOR": "0", "PYTHONIOENCODING": "utf-8"},
        )
    except subprocess.TimeoutExpired:
        return None, "Os testes passaram de 15 minutos e foram interrompidos."
    for linha in reversed((processo.stdout or "").splitlines()):
        if linha.startswith(_MARCA_DO_RESULTADO):
            try:
                return json.loads(linha[len(_MARCA_DO_RESULTADO):]), ""
            except ValueError:
                break
    cauda = ((processo.stderr or "").strip().splitlines() or ["sem mensagem"])[-3:]
    return None, "Não consegui rodar os testes: " + " | ".join(cauda)


_HTML_TESTES_VALIDADOR = r'''<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Testes · Validador de pacotes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<script>
  (function () {
    try {
      var salvo = localStorage.getItem("bradesco_validador_emkt_theme");
      var prefereEscuro = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
      document.documentElement.setAttribute("data-theme", salvo || (prefereEscuro ? "dark" : "light"));
    } catch (e) { /* localStorage bloqueado: segue no claro */ }
  })();
</script>
<link rel="stylesheet" href="/assets/validador.css">
<style>
:root{--sf:var(--card-bg);--ink:var(--text);--mu:var(--text-muted);--ln:var(--border);--er:var(--danger-fg);--ers:var(--danger-bg);--ok:var(--ok-fg);--oks:var(--ok-bg)}
body{padding:var(--space-6);max-width:980px;margin:auto}
h1{font-size:var(--t-lg);font-weight:800;letter-spacing:-.02em;margin:0 0 4px}h2{font-size:var(--t-md);font-weight:800;margin:22px 0 8px}
p{color:var(--mu);margin:0 0 14px}
a.voltar{display:inline-block;margin-bottom:var(--space-4);color:var(--bradesco-red);font-weight:700;font-size:var(--t-sm);text-decoration:none}
a.voltar:hover{text-decoration:underline}
#sum{display:inline-block;padding:6px 14px;border-radius:var(--radius-full);font-weight:700;font-size:var(--t-sm);border:1px solid var(--ln)}
#sum.ok{background:var(--oks);color:var(--ok);border-color:var(--ok)}#sum.bad{background:var(--ers);color:var(--er);border-color:var(--er)}
ul{list-style:none;margin:0;padding:0;display:grid;gap:6px}
li{background:var(--sf);border:1px solid var(--ln);border-left:5px solid;border-radius:var(--radius-sm);padding:8px 12px}
li.ok{border-left-color:var(--ok)}li.bad{border-left-color:var(--er)}li.skip{border-left-color:var(--mu)}
li.ok>b{color:var(--ok)}li.bad>b{color:var(--er)}li.skip>b{color:var(--mu)}
ul.f{margin:6px 0}ul.f li{border:0;padding:2px 0;background:none}
code{font:12px var(--fonte-mono);background:var(--surface-2);padding:1px 4px;border-radius:3px;word-break:break-all}
details{margin-top:4px;color:var(--mu)}pre{font:12px/1.45 var(--fonte-mono);background:var(--surface-2);padding:8px;overflow:auto;max-height:260px;color:var(--ink);white-space:pre-wrap}
button{font:inherit;font-weight:700;font-size:var(--t-sm);padding:7px 13px;border-radius:var(--radius-sm);border:1px solid var(--ln);background:var(--sf);color:var(--ink);cursor:pointer;margin-left:8px}
button:hover{border-color:var(--bradesco-red);color:var(--bradesco-red)}
button:disabled{opacity:.5;cursor:progress}
</style>
</head>
<body>
<a class="voltar" href="/">&larr; Voltar ao validador</a>
<h1>Testes automáticos do Validador</h1>
<p>Cada caso monta um pacote pequeno, roda a conferência de verdade e compara com o resultado esperado (<code>PACOTE_APROVADO</code> ou <code>PACOTE_ERROS</code>). A leitura das imagens usa um motor de teste, então o resultado não depende do motor instalado. Os casos ficam na região 4 do script e rodam também com <code>python validador_emkt_unificado.py --testar</code>.</p>
<div><span id="sum">Rodando…</span><button id="rodar" type="button">Rodar de novo</button></div>
<div id="aviso"></div>
<div id="lista"></div>
<script>
(function () {
  var esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  };

  function desenhar(d) {
    var sum = document.getElementById("sum");
    var ok = d.falharam === 0;
    sum.className = ok ? "ok" : "bad";
    sum.textContent = ok
      ? "Todos os " + (d.total - d.pulados) + " testes passaram" + (d.pulados ? " (" + d.pulados + " pulado(s))" : "")
      : d.falharam + " de " + d.total + " testes falharam";
    sum.textContent += " · " + d.segundos + " s";

    var pr = d.pacotes_reais;
    document.getElementById("aviso").innerHTML = pr.existe ? "" :
      "<p>Pacotes reais: crie <code>PACOTE_APROVADO</code> e/ou <code>PACOTE_ERROS</code> dentro de <code>" +
      esc(pr.pasta) + "</code> para conferi-los também, com o motor de leitura de verdade.</p>";

    var grupos = [];
    d.casos.forEach(function (c) { if (grupos.indexOf(c.grupo) < 0) grupos.push(c.grupo); });
    document.getElementById("lista").innerHTML = grupos.map(function (g) {
      return "<h2>" + esc(g) + "</h2><ul>" + d.casos.filter(function (c) { return c.grupo === g; }).map(function (c) {
        var classe = c.pulado ? "skip" : (c.falhas.length ? "bad" : "ok");
        var rotulo = c.pulado ? "Pulado" : (c.falhas.length ? "Falhou" : "Passou");
        return '<li class="' + classe + '"><b>' + rotulo + "</b> " + esc(c.nome) +
          (c.pulado ? '<ul class="f"><li>' + esc(c.pulado) + "</li></ul>" : "") +
          (c.falhas.length ? '<ul class="f">' + c.falhas.map(function (f) {
            return "<li>" + esc(f.msg) + ": esperado <code>" + esc(f.esperado) + "</code>, obtido <code>" + esc(f.obtido) + "</code></li>";
          }).join("") + "</ul>" : "") +
          (c.resumo ? "<details><summary>Ver o que o Validador devolveu</summary><pre>" + esc(c.resumo) + "</pre></details>" : "") +
          "</li>";
      }).join("") + "</ul>";
    }).join("");
  }

  function executar() {
    var sum = document.getElementById("sum");
    var botao = document.getElementById("rodar");
    sum.className = "";
    sum.textContent = "Rodando…";
    botao.disabled = true;
    fetch("/api/validador/testes")
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (x) {
        if (!x.ok) { sum.className = "bad"; sum.textContent = x.j.erro || "Falha ao rodar os testes"; return; }
        desenhar(x.j);
      })
      .catch(function (e) { sum.className = "bad"; sum.textContent = "Não foi possível rodar: " + e.message; })
      .then(function () { botao.disabled = false; });
  }

  document.getElementById("rodar").addEventListener("click", executar);
  executar();
})();
</script>
</body>
</html>
'''

# endregion


# region 5. Aplicação Flask
try:
    from flask import (Flask, Response, abort, jsonify, request, send_file,
                       send_from_directory)
    from validador import pacote, relatorio, serializacao
except ImportError as erro:  # pragma: no cover - caminho de diagnóstico
    _erro_de_dependencia(erro)


def _resposta_estatica(texto: str, tipo: str):
    """Texto embutido como resposta HTTP. no-cache: ao trocar o script, a tela já vem nova."""
    resposta = Response(texto, mimetype=tipo)
    resposta.headers["Cache-Control"] = "no-cache"
    return resposta


app = Flask(__name__, static_folder=None)  # os arquivos do front são servidos por /assets/
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024  # 300 MB por pacote
app.config["JSON_AS_ASCII"] = False

os.makedirs(PASTA_RELATORIOS, exist_ok=True)

# pastas temporárias criadas pelo upload, apagadas quando o programa fecha
_temporarias: list[str] = []

# id do relatório -> caminhos do pacote, para o preview lado a lado.
# Fica em memória de propósito: some quando o programa fecha, junto com as
# pastas temporárias do upload.
_previews: dict[str, dict] = {}


def _conferir(caminho_pasta: str, quebra=None, usar_ocr=True) -> dict:
    resultado = pacote.validar(caminho_pasta, quebra=quebra, usar_ocr=usar_ocr)
    id_relatorio = uuid.uuid4().hex[:12]
    relatorio.gerar(resultado, os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html"))

    if resultado.caminho_html:
        _previews[id_relatorio] = {
            "imagens": os.path.abspath(resultado.pasta_imagens or ""),
            "raiz": os.path.abspath(os.path.dirname(resultado.caminho_html)),
            "html": os.path.abspath(resultado.caminho_html),
            "paragrafos": (resultado.leitura_conteudo.paragrafos
                           if resultado.leitura_conteudo else []),
            "leitura": _leitura_da_peca(resultado),
            "nome": resultado.nome_pasta,
        }

    dados = serializacao.para_json(resultado, id_relatorio)
    dados["tem_preview"] = id_relatorio in _previews
    return dados


@app.route("/")
def pagina_inicial():
    return _resposta_estatica(_HTML_PAGINA, "text/html")


@app.route("/workbench/tests/")
def workbench_testes():
    """Testes automáticos do Quality Gate do Workbench (tests/index.html original)."""
    return _resposta_estatica(_HTML_TESTES, "text/html")


@app.route("/validador/tests/")
def validador_testes():
    """Testes automáticos do Validador (equivalente a /workbench/tests/)."""
    return _resposta_estatica(_HTML_TESTES_VALIDADOR, "text/html")


_trava_testes = threading.Lock()


@app.route("/api/validador/testes")
def validador_testes_resultado():
    """Roda os testes num processo à parte e devolve o relatório em JSON."""
    if not _trava_testes.acquire(blocking=False):
        return jsonify({"erro": "Já há uma rodada de testes em andamento."}), 409
    try:
        relatorio, erro = rodar_testes_em_processo_separado()
    finally:
        _trava_testes.release()
    if relatorio is None:
        return jsonify({"erro": erro}), 500
    return jsonify(relatorio)


@app.route("/assets/<path:nome>")
def arquivo_do_front(nome):
    """CSS e JS embutidos neste script, servidos no lugar da pasta static/."""
    if nome == "validador.css":
        return _resposta_estatica(_CSS_VALIDADOR, "text/css")
    if nome == "workbench.css":
        return _resposta_estatica(_CSS_WORKBENCH, "text/css")
    if nome == "codemirror.css":
        return _resposta_estatica(_CSS_CODEMIRROR, "text/css")
    if nome == "validador.js":
        return _resposta_estatica(_JS_VALIDADOR, "text/javascript")
    if nome == "codemirror.min.js":
        return _resposta_estatica(_codemirror_js(), "text/javascript")
    if nome.startswith("wb/tests/") and nome.endswith(".js"):
        texto = _JS_TESTES.get(nome[len("wb/tests/"):-len(".js")])
        if texto is not None:
            return _resposta_estatica(texto, "text/javascript")
    elif nome.startswith("wb/") and nome.endswith(".js"):
        chave = nome[len("wb/"):-len(".js")]
        if chave == "regras-time":
            return _resposta_estatica(_regras_do_time(), "text/javascript")
        texto = _JS_WORKBENCH.get(chave)
        if texto is not None:
            return _resposta_estatica(texto, "text/javascript")
    abort(404)


@app.route("/api/conferir-upload", methods=["POST"])
def conferir_upload():
    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"erro": "Nenhum arquivo recebido."}), 400

    destino = tempfile.mkdtemp(prefix="pacote_emkt_")
    _temporarias.append(destino)

    for arquivo in arquivos:
        # o navegador manda o caminho relativo no lugar do nome, o que preserva
        # a subpasta de imagens
        relativo = (arquivo.filename or "").replace("\\", "/")
        partes = [p for p in relativo.split("/") if p not in ("", ".", "..")]
        if not partes:
            continue
        caminho = os.path.join(destino, *partes)
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        arquivo.save(caminho)

    # o navegador inclui a pasta raiz; entra nela quando é o único item
    conteudo = os.listdir(destino)
    raiz = destino
    if len(conteudo) == 1 and os.path.isdir(os.path.join(destino, conteudo[0])):
        raiz = os.path.join(destino, conteudo[0])

    usar_ocr = request.form.get("usar_ocr", "true") == "true"
    # o motor escolhido na tela vale para esta conferência
    from validador.ocr import forcar_motor
    forcar_motor(request.form.get("motor", ""))
    nome_arrastado = (arquivos[0].filename or "").replace("\\", "/").split("/")[0]

    # O usuário arrasta o que tem na mão: pode ser um pacote ou a pasta que
    # guarda vários. Quem decide é a estrutura, não uma opção na tela.
    pastas = pacote.localizar_pacotes(raiz)
    if not pastas:
        return jsonify({
            "erro": "Não encontrei nenhum pacote aqui. A pasta precisa conter o "
                    "HTML da peça, os docx e as imagens — ou ser a pasta que "
                    "guarda vários pacotes assim."
        }), 400

    try:
        resultados = [_conferir(p, None, usar_ocr) for p in pastas]
    except Exception as e:  # noqa: BLE001
        return jsonify({"erro": f"Falha ao conferir: {e}"}), 500

    em_lote = len(pastas) > 1
    for item in resultados:
        item["em_lote"] = em_lote
        if not em_lote and nome_arrastado:
            # pacote único: o nome que vale é o da pasta que a pessoa arrastou
            item["nome_pasta"] = item.get("nome_pasta") or nome_arrastado

    return jsonify({
        "modo": "lote" if em_lote else "unico",
        "origem": nome_arrastado or "pacote enviado",
        "total": len(resultados),
        "resultados": resultados,
    })


@app.route("/api/conferir-em-fluxo", methods=["POST"])
def conferir_em_fluxo():
    """
    Mesma conferência, devolvendo cada pacote assim que fica pronto.

    Ler as imagens é quase todo o tempo, e num lote a pessoa ficava olhando uma
    tela parada até o último pacote terminar. Mandando resultado a resultado,
    ela já começa a reportar o primeiro enquanto o resto roda.

    O formato é uma linha de JSON por evento (NDJSON): o navegador consegue ler
    conforme chega, sem esperar o fim da resposta.
    """
    import json

    arquivos = request.files.getlist("arquivos")
    if not arquivos:
        return jsonify({"erro": "Nenhum arquivo recebido."}), 400

    destino = tempfile.mkdtemp(prefix="pacote_emkt_")
    _temporarias.append(destino)
    for arquivo in arquivos:
        relativo = (arquivo.filename or "").replace("\\", "/")
        partes = [p for p in relativo.split("/") if p not in ("", ".", "..")]
        if not partes:
            continue
        caminho = os.path.join(destino, *partes)
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        arquivo.save(caminho)

    conteudo = os.listdir(destino)
    raiz = destino
    if len(conteudo) == 1 and os.path.isdir(os.path.join(destino, conteudo[0])):
        raiz = os.path.join(destino, conteudo[0])

    usar_ocr = request.form.get("usar_ocr", "true") == "true"
    from validador.ocr import forcar_motor
    forcar_motor(request.form.get("motor", ""))
    nome_arrastado = (arquivos[0].filename or "").replace("\\", "/").split("/")[0]

    def eventos():
        pastas = pacote.localizar_pacotes(raiz)
        if not pastas:
            yield json.dumps({"tipo": "erro", "erro":
                "Não encontrei nenhum pacote aqui. A pasta precisa conter o HTML "
                "da peça, os docx e as imagens — ou ser a pasta que guarda vários "
                "pacotes assim."}, ensure_ascii=False) + "\n"
            return

        em_lote = len(pastas) > 1
        yield json.dumps({
            "tipo": "inicio", "total": len(pastas),
            "modo": "lote" if em_lote else "unico",
            "origem": nome_arrastado or "pacote enviado",
            "nomes": [os.path.basename(p) for p in pastas],
        }, ensure_ascii=False) + "\n"

        for posicao, caminho in enumerate(pastas, 1):
            nome = os.path.basename(caminho)
            andamento = []

            def anotar(feitas, total, _lista=andamento):
                _lista.append((feitas, total))

            yield json.dumps({"tipo": "andamento", "posicao": posicao,
                              "nome": nome}, ensure_ascii=False) + "\n"
            try:
                resultado = pacote.validar(caminho, usar_ocr=usar_ocr, ao_avancar=anotar)
                id_relatorio = uuid.uuid4().hex[:12]
                relatorio.gerar(
                    resultado, os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html"))
                if resultado.caminho_html:
                    _previews[id_relatorio] = {
                        "raiz": os.path.abspath(os.path.dirname(resultado.caminho_html)),
                        "html": os.path.abspath(resultado.caminho_html),
                        "paragrafos": (resultado.leitura_conteudo.paragrafos
                                       if resultado.leitura_conteudo else []),
                        "leitura": _leitura_da_peca(resultado),
                        "nome": resultado.nome_pasta,
                    }
                dados = serializacao.para_json(resultado, id_relatorio)
                dados["tem_preview"] = id_relatorio in _previews
                dados["em_lote"] = em_lote
                if not em_lote and nome_arrastado:
                    dados["nome_pasta"] = dados.get("nome_pasta") or nome_arrastado
                yield json.dumps({"tipo": "pacote", "posicao": posicao,
                                  "resultado": dados}, ensure_ascii=False) + "\n"
            except Exception as e:  # noqa: BLE001
                yield json.dumps({"tipo": "falha", "nome": nome,
                                  "erro": str(e)}, ensure_ascii=False) + "\n"

        yield json.dumps({"tipo": "fim"}, ensure_ascii=False) + "\n"

    return Response(eventos(), mimetype="application/x-ndjson")


@app.route("/relatorio/<id_relatorio>")
def abrir_relatorio(id_relatorio):
    # o id é gerado por uuid4().hex, então só letras e números são válidos:
    # isso barra qualquer tentativa de subir de pasta pelo endereço
    if not id_relatorio.isalnum():
        return "Identificador inválido.", 400
    caminho = os.path.join(PASTA_RELATORIOS, f"{id_relatorio}.html")
    if not os.path.exists(caminho):
        return "Relatório não encontrado. Refaça a conferência.", 404
    return send_file(caminho)


# ----------------------------------------------------------------- preview

def _preview_ou_404(id_relatorio: str) -> dict:
    if not id_relatorio.isalnum() or id_relatorio not in _previews:
        abort(404)
    return _previews[id_relatorio]


@app.route("/preview/<id_relatorio>/peca")
def preview_peca(id_relatorio):
    """
    Serve o HTML do pacote para o iframe do preview.

    O arquivo chama as imagens por caminho relativo ("imagens/banner_01.png").
    Servido de outro endereço, esses caminhos apontariam para o lugar errado e
    a peça apareceria sem nenhuma imagem. A tag <base> injetada no topo faz
    todos eles caírem na rota que serve os arquivos do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        with open(preview["html"], "rb") as arquivo:
            codigo = arquivo.read().decode("utf-8", errors="replace")
    except OSError:
        abort(404)

    base = f'<base href="/preview/{id_relatorio}/arquivo/">'
    minusculo = codigo.lower()
    posicao = minusculo.find("<head")
    if posicao >= 0:
        fim = codigo.find(">", posicao)
        codigo = codigo[:fim + 1] + base + codigo[fim + 1:]
    else:
        codigo = base + codigo

    return Response(codigo, mimetype="text/html; charset=utf-8")


@app.route("/preview/<id_relatorio>/arquivo/<path:relativo>")
def preview_arquivo(id_relatorio, relativo):
    """
    Serve as imagens que a peça referencia.

    send_from_directory resolve o caminho dentro da raiz e recusa qualquer
    tentativa de subir de pasta pelo endereço — sem isso, o navegador poderia
    pedir ../../ e ler arquivo fora do pacote.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        return send_from_directory(preview["raiz"], relativo)
    except Exception:
        abort(404)


def _leitura_da_peca(resultado) -> list[dict]:
    """
    O que o sistema entendeu da peça, bloco a bloco.

    É a fita de leitura crua: o texto do código e o texto lido de cada imagem,
    na ordem em que o leitor de tela percorreria. Serve para explicar de onde
    veio cada divergência — quando o apontamento não faz sentido, é aqui que se
    vê se o problema foi a leitura da imagem ou o docx.
    """
    if not resultado.leitura_html:
        return []

    blocos = []
    for bloco in resultado.leitura_html.fita:
        if bloco.oculto:
            continue
        blocos.append({
            "tipo": bloco.tipo,
            "origem": (bloco.referencia if bloco.tipo == "imagem"
                       else "texto do código"),
            "texto": bloco.conteudo,
            "confianca": round(getattr(bloco, "ocr_confianca", 0) or 0),
            "aviso": getattr(bloco, "ocr_aviso", "") or getattr(bloco, "ocr_erro", ""),
            "classificacao": bloco.classificacao,
            "reordenado": bool(getattr(bloco, "reordenado", False)),
        })
    return blocos


@app.route("/preview/<id_relatorio>/imagem/<nome>")
def preview_imagem(id_relatorio, nome):
    """
    Serve uma imagem do pacote pelo nome, para o apontamento mostrar o arquivo.

    Ver o banner ao lado do apontamento é o que permite decidir em um segundo
    se a divergência é da peça ou foi a leitura que errou — e tirar o print
    para anexar no report sem sair da tela.
    """
    preview = _preview_ou_404(id_relatorio)
    pasta = preview.get("imagens") or preview["raiz"]
    if not os.path.isdir(pasta):
        abort(404)
    alvo = os.path.basename(nome).lower()
    for raiz, _, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            if arquivo.lower() == alvo:
                return send_file(os.path.join(raiz, arquivo))
    abort(404)


@app.route("/api/preview/<id_relatorio>/leitura")
def preview_leitura(id_relatorio):
    """A fita de leitura, para a aba 'o que o sistema leu'."""
    return jsonify({"blocos": _preview_ou_404(id_relatorio)["leitura"]})


@app.route("/preview/<id_relatorio>/conteudo-gerado.docx")
def baixar_conteudo_gerado(id_relatorio):
    """
    Gera um CONTEUDO.docx com a leitura desta conferência.

    Serve para montar pacote de teste, não para conferir a peça: os dois lados
    sairiam da mesma leitura e o resultado daria 100% sempre. O aviso está na
    tela, ao lado do botão.
    """
    from io import BytesIO

    from docx import Document

    preview = _preview_ou_404(id_relatorio)
    documento = Document()
    for bloco in preview["leitura"]:
        for linha in (bloco["texto"] or "").splitlines():
            if linha.strip():
                documento.add_paragraph(linha.strip())

    memoria = BytesIO()
    documento.save(memoria)
    memoria.seek(0)
    nome = f"CONTEUDO_GERADO_{preview.get('nome') or id_relatorio}.docx"
    return send_file(
        memoria, as_attachment=True, download_name=nome,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


@app.route("/api/preview/<id_relatorio>/html")
def preview_html(id_relatorio):
    """
    O HTML do pacote como texto, para o botão "Abrir no Workbench".

    Os bytes são decodificados aqui: o arquivo que a agência manda pode estar em
    UTF-8 (com ou sem BOM) ou em Windows-1252, e o editor do Workbench trabalha
    com texto, não com bytes.
    """
    preview = _preview_ou_404(id_relatorio)
    try:
        with open(preview["html"], "rb") as arquivo:
            bruto = arquivo.read()
    except OSError:
        abort(404)
    try:
        texto = bruto.decode("utf-8-sig")
    except UnicodeDecodeError:
        texto = bruto.decode("cp1252", errors="replace")
    resposta = jsonify({
        "nome": preview.get("nome") or "",
        "arquivo": os.path.basename(preview["html"]),
        "html": texto,
    })
    resposta.headers["Cache-Control"] = "no-store"
    return resposta


@app.route("/api/preview/<id_relatorio>/conteudo")
def preview_conteudo(id_relatorio):
    """Parágrafos do docx, na ordem, para a coluna de texto."""
    return jsonify({"paragrafos": _preview_ou_404(id_relatorio)["paragrafos"]})


@app.route("/api/status-ocr")
def status_ocr():
    from validador.ocr import (aviso_de_escolha, aviso_de_idioma, aviso_de_versao,
                               diagnosticar, idiomas_instalados, motor_ativo,
                               ocr_disponivel)

    disponivel, motivo = ocr_disponivel()
    ativo = motor_ativo()
    idiomas = idiomas_instalados()
    return jsonify({
        "disponivel": disponivel,
        "motivo": motivo,
        "motor": ativo.nome if ativo else "",
        "aviso_escolha": aviso_de_escolha(),
        "aviso_versao": aviso_de_versao(),
        "descricao": ativo.descricao if ativo else "",
        "motores": diagnosticar(),
        "disponiveis": [m for m in diagnosticar() if m["disponivel"]],
        "idiomas": idiomas,
        "portugues": "por" in idiomas,
        "dica_idioma": aviso_de_idioma(),
    })


def _porta_livre(porta: int) -> bool:
    # sem SO_REUSEADDR de propósito: o teste precisa falhar exatamente onde o
    # servidor falharia, senão ele diria "livre" numa porta já em uso
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as teste:
        try:
            teste.bind(("127.0.0.1", porta))
            return True
        except OSError:
            return False


def _escolher_porta(preferida: int = 5000) -> int:
    """
    Deixar o programa aberto numa janela e rodar de novo trava a porta 5000.
    Em vez de morrer com "address already in use", sobe na porta seguinte.
    """
    for porta in range(preferida, preferida + 12):
        if _porta_livre(porta):
            return porta
    return preferida


def limpar_temporarias():
    for pasta in _temporarias:
        shutil.rmtree(pasta, ignore_errors=True)


if __name__ == "__main__":
    import atexit

    # comandos que não sobem a tela
    if "--instalar-idioma-por" in sys.argv:
        from validador.ocr import instalar_idioma_por
        sys.exit(0 if instalar_idioma_por() else 1)
    if "--testar" in sys.argv:
        sys.exit(testar_pelo_terminal("--json" in sys.argv))

    atexit.register(limpar_temporarias)

    # relatórios antigos saem ao abrir o programa (ver DIAS_RELATORIOS, no topo)
    _apagados, _liberados = limpar_relatorios_antigos()

    porta = int(os.environ.get("PORTA") or _escolher_porta())
    endereco = f"http://127.0.0.1:{porta}"

    # O navegador só é aberto no processo principal. Com o reloader ligado o
    # Flask sobe dois processos, e sem esta guarda abriam duas abas.
    if not os.environ.get("WERKZEUG_RUN_MAIN") and os.environ.get("ABRIR_NAVEGADOR", "1") != "0":
        import threading
        import webbrowser

        # webbrowser pode falhar em terminal sem sessão gráfica: se falhar, o
        # endereço continua impresso abaixo e dá para abrir na mão.
        threading.Timer(1.2, lambda: webbrowser.open(endereco)).start()

    print("\n" + "=" * 66)
    print("  Validador de pacotes EMKT · Bradesco CRM")
    print(f"  Abra no navegador: {endereco}")
    if porta != 5000:
        print("  (a porta 5000 estava ocupada, então subi nesta aqui)")
    if _apagados:
        print(f"  Limpeza: {_apagados} relatório(s) com mais de {DIAS_RELATORIOS} dias "
              f"apagado(s), {_liberados / 1048576:.1f} MB liberados.")
    print("  Para encerrar: Ctrl+C aqui, ou feche esta janela.")
    print("=" * 66 + "\n")

    # host='127.0.0.1' = acessível apenas nesta máquina (recomendado).
    # debug=False de propósito: o debugger do Flask abre um console Python no
    # navegador, e isso não deve existir numa ferramenta que lê pasta de rede.
    app.run(host="127.0.0.1", port=porta, debug=False)

# endregion
