# Validador de pacotes EMKT + SFMC Workbench

## Para rodar
    python -m pip install flask beautifulsoup4 python-docx pillow rapidocr
    python validador_emkt_unificado.py          # abre em http://127.0.0.1:5000

O programa roda a partir de **um arquivo só**, `validador_emkt_unificado.py`.
As pastas abaixo trazem **as mesmas partes embutidas nele, como arquivos separados**,
para ler e editar com calma. `sincronizar.py` leva as edições de volta para o script.

## Estrutura
    validador_emkt_unificado.py   o programa (Flask, carregador, testes, rotas)
    sincronizar.py                extrair | montar | conferir
    validador/                    16 módulos Python: ocr, pacote, comparador, regras, imagens...
    static/
      validador.css  validador.js           aba do Validador
      workbench.css  codemirror.css  codemirror.min.js
      wb/*.js                               aba SFMC Workbench (app, parser, rules, audit, preview, report, editor, regras-time)
      wb/tests/*.js                         casos e runner dos testes do Workbench
    html/
      index.html                            página principal (as duas abas)
      workbench-tests.html                  /workbench/tests/
      validador-tests.html                  /validador/tests/
    ALTERACOES.md                 o que mudou nesta versão

## Editar
1. Edite o arquivo que quiser (por exemplo `static/validador.js`).
2. `python sincronizar.py montar` grava a mudança no script único (guarda `.bak`).
3. Rode `python validador_emkt_unificado.py`.

`python sincronizar.py conferir` diz se arquivos e script estão iguais.
Se editar o script único direto, rode `python sincronizar.py extrair` para atualizar os arquivos.
Não use `'''` dentro dos arquivos extraídos (fecharia a string do script); o `montar` avisa.

`regras-time.js`: se existir um `regras-time.js` ao lado do script, ele vale no lugar do embutido.

## Fora das pastas
Configuração inicial, carregador dos módulos, testes do Validador (`--testar`) e rotas do Flask
ficam no próprio script único.
