/* preview.js — Preview mais próximo do que o cliente vai ver.
 *
 * - Dados de teste: resolve %%Var%%, variáveis de sistema e o AMPScript mais comum
 *   (SET com AttributeValue/literais/Concat, v(), RedirectTo). O resto fica visível como está.
 * - Modo escuro: "css" ativa os estilos @media (prefers-color-scheme: dark) e [data-ogsc]
 *   do próprio e-mail; "inv" simula a inversão automática de cores de alguns apps.
 * - Imagens bloqueadas: troca cada <img> por uma caixa com o texto alternativo.
 * Tudo aqui afeta só o preview; o código final não muda.
 */
(function (WB) {
  'use strict';
  const P = WB.parser;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

  /** Valor de exemplo a partir do nome da variável. */
  function amostra(nome) {
    const n = String(nome).toLowerCase();
    const hoje = new Date();
    if (/sobrenome|last_?name/.test(n)) return 'Silva';
    if (/nome|name/.test(n)) return 'Maria';
    if (/e-?mail/.test(n)) return 'maria.silva@exemplo.com.br';
    if (/cpf/.test(n)) return '123.456.789-09';
    if (/cnpj/.test(n)) return '12.345.678/0001-90';
    if (/valor|limite|saldo|preco|preço|parcela|fatura|vlr/.test(n)) return 'R$ 1.234,56';
    if (/data|venc|^dt|_dt/.test(n)) return hoje.toLocaleDateString('pt-BR');
    if (/agencia|agência/.test(n)) return '1234';
    if (/conta/.test(n)) return '12345-6';
    if (/cartao|cartão|final/.test(n)) return '1234';
    if (/cupom|codigo|código|cod/.test(n)) return 'ABC123';
    if (/url|link|site/.test(n)) return 'https://www.exemplo.com.br';
    if (/tel|cel|fone/.test(n)) return '(11) 91234-5678';
    if (/cidade/.test(n)) return 'São Paulo';
    if (/estado|uf/.test(n)) return 'SP';
    return 'Exemplo ' + nome;
  }

  function sistema(nome, td) {
    const n = nome.toLowerCase(), d = new Date();
    if (/url$/.test(n)) return '#';
    if (n === 'emailaddr') return td.get('emailaddr') || 'maria.silva@exemplo.com.br';
    if (n === 'xtday') return String(d.getDate());
    if (n === 'xtmonth') return MESES[d.getMonth()];
    if (n === 'xtmonthnumeric') return String(d.getMonth() + 1);
    if (n === 'xtyear') return String(d.getFullYear());
    if (/^(fromname|replyname)$/.test(n)) return 'Remetente';
    if (/^(fromaddress|replyemailaddress)$/.test(n)) return 'remetente@exemplo.com.br';
    if (/^email_?name_$/.test(n)) return 'E-mail de teste';
    if (/id$/.test(n)) return '123456';
    if (n.startsWith('member_')) return 'Exemplo';
    return '';
  }

  // ---------- Avaliador mínimo de AMPScript ----------
  function lerArgs(s) {
    const args = []; let prof = 0, q = '', ini = 0;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === q) q = ''; continue; }
      if (c === '"' || c === "'") q = c;
      else if (c === '(') prof++;
      else if (c === ')') prof--;
      else if (c === ',' && prof === 0) { args.push(s.slice(ini, i).trim()); ini = i + 1; }
    }
    const ult = s.slice(ini).trim();
    if (ult || args.length) args.push(ult);
    return args;
  }

  function avaliar(ex, ctx) {
    ex = ex.trim();
    let m;
    if ((m = /^"([^"]*)"$/.exec(ex)) || (m = /^'([^']*)'$/.exec(ex))) return m[1];
    if (/^-?\d+(\.\d+)?$/.test(ex)) return ex;
    if (/^@\w+$/.test(ex)) return ctx.vars[ex.toLowerCase()] ?? null;
    if ((m = /^\[(.+)\]$/.exec(ex))) return ctx.td.get(m[1]) ?? amostra(m[1]);
    if ((m = /^([A-Za-z_]\w*)\s*\(([\s\S]*)\)$/.exec(ex))) {
      const fn = m[1].toLowerCase(), args = lerArgs(m[2]);
      const a = i => (args[i] === undefined ? null : avaliar(args[i], ctx));
      switch (fn) {
        case 'v': case 'redirectto': case 'format': case 'formatcurrency': case 'formatnumber': case 'trim': case 'output': case 'outputline':
          return a(0);
        case 'attributevalue': { const k = a(0); return k == null ? null : (ctx.td.get(k) ?? amostra(k)); }
        case 'concat': { const p = args.map((_, i) => a(i)); return p.some(x => x == null) ? null : p.join(''); }
        case 'uppercase': { const x = a(0); return x == null ? null : x.toUpperCase(); }
        case 'lowercase': { const x = a(0); return x == null ? null : x.toLowerCase(); }
        case 'propercase': { const x = a(0); return x == null ? null : x.toLowerCase().replace(/(^|\s)\S/g, c => c.toUpperCase()); }
        case 'now': case 'systemdatetolocaldate': return new Date().toLocaleString('pt-BR');
        default: return null;
      }
    }
    if (/^[A-Za-z_]\w*$/.test(ex)) return ctx.td.get(ex) ?? null;
    return null;
  }

  /** Executa os SETs de um bloco %%[ ]%% (ignora IF/FOR; ambos os ramos aparecem no preview). */
  function executar(bloco, ctx) {
    const s = bloco.replace(/\/\*[\s\S]*?\*\//g, ' ');
    const re = /\bset\s+(@\w+)\s*=\s*/gi;
    let m;
    while ((m = re.exec(s))) {
      let i = re.lastIndex, prof = 0, q = '';
      for (; i < s.length; i++) {
        const c = s[i];
        if (q) { if (c === q) q = ''; continue; }
        if (c === '"' || c === "'") { q = c; continue; }
        if (c === '(') prof++;
        else if (c === ')') prof--;
        else if (prof === 0 && (c === '\n' || c === '\r')) break;
        else if (prof === 0 && /\s/.test(c) && /^\s+(set|var|if|endif|else|elseif|for|next|then)\b/i.test(s.slice(i))) break;
      }
      const v = avaliar(s.slice(re.lastIndex, i), ctx);
      ctx.vars[m[1].toLowerCase()] = v == null ? '[' + m[1] + ']' : v;
      re.lastIndex = i;
    }
  }

  function resolverAmp(h, tdObj, isSys) {
    isSys = isSys || (() => false);
    const td = { get: k => { const v = tdObj[String(k).toLowerCase()]; return v === undefined || v === '' ? null : v; } };
    const ctx = { vars: {}, td };
    let n = 0;
    h = h.replace(/<script\b[^>]*language\s*=\s*["']?ampscript["']?[^>]*>([\s\S]*?)<\/script>/gi, (m, b) => { executar(b, ctx); n++; return ''; });
    h = h.replace(/%%\[([\s\S]*?)\]%%/g, (m, b) => { executar(b, ctx); n++; return ''; });
    h = h.replace(/%%=([\s\S]*?)=%%/g, (m, ex) => { const v = avaliar(ex, ctx); if (v == null) return m; n++; return esc(v); });
    h = h.replace(/%%([A-Za-z_]\w*)%%/g, (m, nome) => {
      n++;
      if (isSys(nome)) return esc(sistema(nome, td));
      return esc(td.get(nome) ?? amostra(nome));
    });
    return { html: h, n };
  }

  // ---------- Imagens bloqueadas ----------
  function bloquearImagens(h) {
    const { tokens } = P.tokenize(h);
    let out = '', last = 0;
    const attr = (t, n) => { const a = t.attrs.find(x => x.lname === n); return a ? (a.value ?? '') : null; };
    const dim = v => v == null ? null : /^\d+(\.\d+)?$/.test(v.trim()) ? v.trim() + 'px' : /^\d+(\.\d+)?(px|%)$/.test(v.trim()) ? v.trim() : null;
    for (const t of tokens) {
      if (t.t === 'raw' && t.parent === 'style') {
        const css = h.slice(t.s, t.e).replace(/(background(?:-image)?\s*:[^;}]*?)url\([^)]*\)/gi, '$1none');
        out += h.slice(last, t.s) + css; last = t.e;
      }
      if (t.t !== 'start') continue;
      if (t.name === 'img') {
        const alt = attr(t, 'alt'), st = attr(t, 'style') || '';
        const w = dim(attr(t, 'width')) || (/(?:^|;)\s*width\s*:\s*([\d.]+(?:px|%))/i.exec(st) || [])[1];
        const hh = dim(attr(t, 'height'));
        const disp = /display\s*:\s*block/i.test(st) ? 'block' : 'inline-block';
        const box = `display:${disp};box-sizing:border-box;${w ? 'width:' + w + ';' : ''}max-width:100%;${hh ? 'height:' + hh + ';' : 'min-height:28px;'}` +
          'border:1px dashed #98a2b3;background:#eef1f5;color:#475467;font:12px/1.35 Arial,Helvetica,sans-serif;padding:6px;overflow:hidden;vertical-align:middle;text-align:center;word-break:break-word';
        const conteudo = alt === null ? '<span style="color:#b8102c;font-weight:bold">Imagem sem alt</span>' : alt.replace(/</g, '&lt;');
        out += h.slice(last, t.s) + `<span role="img" style="${box}">${conteudo}</span>`;
        last = t.e;
        continue;
      }
      const bg = t.attrs.filter(a => a.lname === 'background');
      const sty = t.attrs.find(a => a.lname === 'style' && a.vs >= 0 && /url\(/i.test(a.value));
      if (!bg.length && !sty) continue;
      // reescreve só os atributos afetados, mantendo o resto da tag
      const cortes = [...bg.map(a => ({ s: a.ns, e: a.ae, txt: '' })),
        ...(sty ? [{ s: sty.vs, e: sty.ve, txt: sty.value.replace(/url\([^)]*\)/gi, 'none') }] : [])].sort((a, b) => a.s - b.s);
      for (const c of cortes) { out += h.slice(last, c.s) + c.txt; last = c.e; }
    }
    return out + h.slice(last);
  }

  // ---------- Modo escuro ----------
  function injetarCss(h, css) {
    const tag = '<style data-wb-preview>' + css + '</style>';
    if (/<\/head>/i.test(h)) return h.replace(/<\/head>/i, tag + '</head>');
    if (/<body\b/i.test(h)) return h.replace(/<body\b/i, tag + '$&');
    return tag + h;
  }

  function modoEscuro(h, modo) {
    if (modo === 'inv') {
      const inv = 'filter:invert(1) hue-rotate(180deg)';
      return { html: injetarCss(h, `html{${inv};background:#fff}img,picture,video,[background],[style*="url("]{${inv}}`), dark: true };
    }
    let n = 0;
    h = h.replace(/\(\s*prefers-color-scheme\s*:\s*dark\s*\)/gi, () => { n++; return '(min-width:0px)'; })
      .replace(/\(\s*prefers-color-scheme\s*:\s*light\s*\)/gi, '(max-width:0px)');
    const ogsc = /\[data-ogs[cb]\]/i.test(h);
    if (ogsc) h = /<html\b/i.test(h) ? h.replace(/<html\b/i, '$& data-ogsc data-ogsb') : '<div data-ogsc data-ogsb>' + h + '</div>';
    h = injetarCss(h, ':root{color-scheme:dark}');
    return { html: h, dark: n > 0 || ogsc };
  }

  /**
   * o = { dados: bool, td: { nome-minúsculo: valor }, isSys: fn, imagens: bool, escuro: 'off'|'css'|'inv' }
   * Devolve { html, notas: [] }.
   */
  function gerar(h, o) {
    const notas = [];
    if (!h) return { html: '', notas };
    if (o.dados) {
      const r = resolverAmp(h, o.td || {}, o.isSys);
      h = r.html;
      notas.push(r.n ? 'Variáveis e AMPScript simulados com dados de teste. Blocos IF mostram todos os ramos.' : 'Nenhuma variável para simular.');
    } else notas.push('AMPScript exibido como texto, sem dados de teste.');
    if (o.imagens) { h = bloquearImagens(h); notas.push('Imagens bloqueadas: cada caixa mostra o texto do alt.'); }
    if (o.escuro && o.escuro !== 'off') {
      const r = modoEscuro(h, o.escuro);
      h = r.html;
      if (o.escuro === 'css') notas.push(r.dark ? 'Modo escuro com os estilos do próprio e-mail (Apple Mail, iOS).' : 'O e-mail não define estilos de modo escuro. Clientes podem inverter as cores por conta própria; teste a opção de inversão.');
      else notas.push('Modo escuro por inversão automática (aproximação de Gmail app e Outlook).');
    }
    return { html: h, notas };
  }

  WB.preview = { gerar, amostra, resolverAmp, bloquearImagens, modoEscuro };
})(window.WB = window.WB || {});
