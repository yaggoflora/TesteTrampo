/* Regras do time para o SFMC Workbench.
 *
 * Este arquivo é a base de regras de quem abrir a ferramenta a partir desta pasta.
 * Edite os valores abaixo (ou gere um novo na aba Regras > "Baixar como regras-time.js")
 * e substitua o arquivo na pasta compartilhada. Ajustes feitos no painel Regras ficam
 * salvos só no navegador de cada pessoa e têm prioridade sobre este arquivo.
 *
 * niveis: bloq (bloqueador), alerta ou off (desligada).
 * Se este arquivo for apagado, a ferramenta usa o padrão embutido em js/rules.js.
 */
window.WB_REGRAS_TIME = {
  "versao": 1,
  "niveis": {
    "viewEmailUrl": "bloq",
    "redirectTo": "bloq",
    "descadastroAusente": "bloq",
    "descadastroPadrao": "alerta",
    "hrefVazio": "bloq",
    "hrefHash": "alerta",
    "hrefJs": "bloq",
    "linkSemRedirect": "off",
    "linkAninhado": "alerta",
    "imgSemAlt": "alerta",
    "imgRelativa": "alerta",
    "scriptTag": "bloq",
    "ampNaoFechado": "bloq",
    "doctype": "alerta",
    "viewport": "alerta",
    "tamanho": "alerta",
    "dominioTexto": "alerta"
  },
  "parametros": {
    "chamadaRastreamento": "RedirectTo\\(\\s*@Link_Tag\\s*\\)",
    "variaveisDescadastro": [
      "unsub_center_url",
      "unsub_url",
      "profile_center_url",
      "subscription_center_url"
    ],
    "variaveisSistema": [
      "view_email_url",
      "unsub_center_url",
      "unsub_url",
      "profile_center_url",
      "subscription_center_url",
      "emailname_",
      "email_name_",
      "jobid",
      "listid",
      "batchid",
      "memberid",
      "subscriberid",
      "emailaddr",
      "xtmonth",
      "xtmonthnumeric",
      "xtday",
      "xtyear",
      "replyname",
      "replyemailaddress",
      "fromname",
      "fromaddress",
      "member_busname",
      "member_addr",
      "member_city",
      "member_state",
      "member_postalcode",
      "member_country"
    ],
    "dominios": [
      "com.br",
      "gov.br",
      "com",
      "net",
      "org",
      "br",
      "io",
      "app",
      "dev",
      "info",
      "biz",
      "co"
    ],
    "limiteKB": 102,
    "sufixoImagem": "_\\d{2,}\\.(jpe?g|png|gif|webp)$"
  }
};
