/* app.js — Interface do SFMC Workbench. */
(function (WB) {
  'use strict';
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const K = { rascunho: 'sfmcwb-rascunho', preview: 'sfmcwb-preview' };
  const ROT_OUT = 'Edição do código final';
  const NOME_NV = { bloq: 'Bloqueador', alerta: 'Alerta', ok: 'OK' };
  const hora = d => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  // ================= Estado =================
  const VAZIO = () => ({ src: '', out: '', outGerado: '', outManual: false, base: '', onlySuf: true, anti: true, map: {}, teste: {}, arquivo: '', meta: { campanha: '', chamado: '', responsavel: '' } });
  let S = VAZIO(), A = null, varKey = '';
  let regras = WB.rules.carregar();
  let R = WB.rules.compilar(regras.cfg);
  const PV = Object.assign({ mobile: false, escuro: 'off', imagens: false, dados: true }, (() => { try { return JSON.parse(localStorage.getItem(K.preview)) || {}; } catch (e) { return {}; } })());

  // ================= Avisos =================
  function toast(msg, o = {}) {
    const d = document.createElement('div');
    d.className = 't' + (o.erro ? ' e' : '');
    const sp = document.createElement('span'); sp.textContent = msg; d.append(sp);
    if (o.acao) { const b = document.createElement('button'); b.textContent = o.acao; b.onclick = () => { d.remove(); o.fn(); }; d.append(b); }
    $('#toasts').append(d);
    setTimeout(() => d.remove(), o.acao ? 7000 : 2800);
  }

  function confirmar({ titulo, texto, ok }) {
    const d = $('#dlg');
    if (typeof d.showModal !== 'function') return Promise.resolve(window.confirm(titulo + '\n\n' + texto));
    $('#dlgT').textContent = titulo; $('#dlgP').textContent = texto; $('#dlgOk').textContent = ok;
    return new Promise(res => {
      const fim = v => { $('#dlgOk').onclick = $('#dlgNo').onclick = d.oncancel = null; d.close(); res(v); };
      $('#dlgOk').onclick = () => fim(true);
      $('#dlgNo').onclick = () => fim(false);
      d.oncancel = e => { e.preventDefault(); fim(false); };
      d.showModal(); $('#dlgNo').focus();
    });
  }

  function baixar(nome, conteudo, tipo) {
    const url = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
    const a = document.createElement('a'); a.href = url; a.download = nome; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  async function copiar(texto) {
    try { await navigator.clipboard.writeText(texto); return true; }
    catch (e) {
      const t = document.createElement('textarea'); t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.append(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok;
    }
  }

  // ================= Desfazer / refazer =================
  const H = {
    pilha: [], i: -1, timer: null, rotuloPend: '',
    registrar(rotulo) {
      clearTimeout(this.timer); this.timer = null;
      garantirRun();
      const f = JSON.stringify(S);
      if (this.pilha[this.i] && this.pilha[this.i].f === f) return;
      this.pilha.splice(this.i + 1);
      this.pilha.push({ f, rotulo });
      if (this.pilha.length > 80) this.pilha.shift();
      this.i = this.pilha.length - 1;
      botoesHist();
    },
    agendar(rotulo) { clearTimeout(this.timer); this.rotuloPend = rotulo; this.timer = setTimeout(() => this.registrar(rotulo), 700); },
    pendente() { if (this.timer) this.registrar(this.rotuloPend); },
    desfazer() {
      this.pendente();
      if (this.i <= 0) { toast('Nada para desfazer'); return; }
      const r = this.pilha[this.i].rotulo; this.i--;
      restaurar(JSON.parse(this.pilha[this.i].f)); botoesHist(); toast('Desfeito: ' + r);
    },
    refazer() {
      this.pendente();
      if (this.i >= this.pilha.length - 1) { toast('Nada para refazer'); return; }
      this.i++;
      restaurar(JSON.parse(this.pilha[this.i].f)); botoesHist(); toast('Refeito: ' + this.pilha[this.i].rotulo);
    }
  };
  function botoesHist() {
    $('#undo').disabled = H.i <= 0 && !H.timer;
    $('#redo').disabled = H.i >= H.pilha.length - 1;
    $('#undo').title = H.i > 0 ? 'Desfazer: ' + H.pilha[H.i].rotulo + ' (Ctrl+Z)' : 'Desfazer (Ctrl+Z)';
    $('#redo').title = H.i < H.pilha.length - 1 ? 'Refazer: ' + H.pilha[H.i + 1].rotulo + ' (Ctrl+Y)' : 'Refazer (Ctrl+Y)';
  }

  /**
   * Toda alteração do projeto passa por aqui.
   * discreto: ação única (carregar, limpar…) vira um passo próprio no histórico.
   * semRun: não reanalisa (ex.: edição do código final, dado de teste).
   */
  function mudar(rotulo, fn, o = {}) {
    if (o.discreto || (H.timer && H.rotuloPend !== rotulo)) H.pendente();
    if (S.outManual && rotulo !== ROT_OUT && !o.semRun) H.registrar(ROT_OUT); // guarda as edições manuais antes de regerar
    fn();
    if (o.semRun) { paint(); salvarRascunho(); }
    else if (o.discreto) run(); else agendarRun();
    if (o.discreto) H.registrar(rotulo); else { H.agendar(rotulo); $('#undo').disabled = false; }
  }

  function restaurar(s) {
    S = Object.assign(VAZIO(), s);
    edSrc.set(S.src, { cursor: true });
    edOut.set(S.out);
    sincronizarCampos();
    varKey = '\u0000';
    run({ manterOut: true });
  }

  function sincronizarCampos() {
    $('#base').value = S.base; $('#onlysuf').checked = S.onlySuf; $('#anti').checked = S.anti;
    $('#mCamp').value = S.meta.campanha; $('#mCham').value = S.meta.chamado; $('#mResp').value = S.meta.responsavel;
  }

  // ================= Rascunho =================
  let draftTimer;
  function salvarRascunho() {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(() => {
      try {
        if (!S.src && !S.out) { localStorage.removeItem(K.rascunho); $('#draftSt').textContent = ''; return; }
        localStorage.setItem(K.rascunho, JSON.stringify({ v: 1, ts: Date.now(), s: S }));
        $('#draftSt').textContent = 'Rascunho salvo às ' + hora(new Date());
      } catch (e) {
        $('#draftSt').textContent = 'Rascunho não salvo: o navegador bloqueou ou encheu o armazenamento local';
      }
    }, 800);
  }

  // ================= Editores =================
  const edSrc = WB.editor.criar($('#edSrc'), {
    rotulo: 'HTML de entrada', placeholder: 'Cole aqui o HTML bruto do e-mail ou arraste um arquivo .html, .htm ou .txt',
    onChange: () => mudar('Edição do HTML', () => { S.src = edSrc.get(); }),
    desfazer: () => H.desfazer(), refazer: () => H.refazer()
  });
  const edOut = WB.editor.criar($('#edOut'), {
    rotulo: 'Código final',
    onChange: () => mudar(ROT_OUT, () => { S.out = edOut.get(); S.outManual = S.out !== S.outGerado; atualizarManual(); }, { semRun: true }),
    desfazer: () => H.desfazer(), refazer: () => H.refazer(),
    teclas: { 'F8': false, 'Shift-F8': false }
  });
  if (!WB.editor.disponivel) toast('Editor avançado indisponível (pasta vendor/ ausente). Usando o editor simples.', { erro: true });

  // ================= Análise =================
  let runTimer = null;
  function agendarRun() { clearTimeout(runTimer); runTimer = setTimeout(run, 150); }
  function garantirRun() { if (runTimer) run(); }

  function run(o = {}) {
    clearTimeout(runTimer); runTimer = null;
    const h = S.src;
    $('#cSrc').textContent = h.length.toLocaleString('pt-BR') + ' caracteres';
    if (!h.trim()) {
      A = null; varKey = ''; S.map = {};
      ['kImg', 'kLink', 'kVar', 'kAl'].forEach(k => { $('#' + k).textContent = 0; });
      $('#st').className = 'pill'; $('#st').textContent = 'Aguardando HTML'; $('#nQ').hidden = true;
      $('#qg').innerHTML = '<li class="alerta"><b>Nenhum HTML para analisar</b>Cole um e-mail ou carregue um arquivo na aba Entrada.</li>';
      ['lkT', 'imT', 'vrT'].forEach(k => { $('#' + k).innerHTML = ''; });
      $('#antiN').textContent = '';
    } else {
      try { A = WB.audit.analyze(h, R); renderStatic(); }
      catch (e) {
        console.error(e); A = null;
        $('#st').className = 'pill bad'; $('#st').textContent = 'Erro na análise';
        toast('A análise falhou: ' + e.message, { erro: true });
      }
    }
    if (!o.manterOut) build();
    marcarEditor();
    paint();
    salvarRascunho();
  }

  function build() {
    const g = WB.audit.compile(S.src, { base: S.base, onlySuf: S.onlySuf, anti: S.anti, map: S.map }, R);
    if (S.outManual && g !== S.out) toast('As edições manuais do código final foram substituídas.', { acao: 'Desfazer', fn: () => H.desfazer() });
    S.out = g; S.outGerado = g; S.outManual = false;
    edOut.set(g);
    atualizarManual();
  }
  function atualizarManual() { $('#manualN').hidden = !S.outManual; }

  function marcarEditor() {
    const locs = [];
    if (A) A.ck.forEach(c => { if (c.l !== 'ok') c.locs.forEach(l => locs.push({ s: l.s, e: l.e, nivel: c.l, titulo: NOME_NV[c.l] + ': ' + c.t })); });
    edSrc.marcar(locs);
  }

  // ================= Renderização =================
  const lnBtn = (attrs, ln) => ln ? `<button class="ln" ${attrs} title="Ir para a linha ${ln}">${ln}</button>` : '';

  function renderStatic() {
    const a = A;
    $('#kImg').textContent = a.imgs.length; $('#kLink').textContent = a.links.length;
    $('#kVar').textContent = Object.keys(a.vars).length; $('#kAl').textContent = a.bloq + a.alerta;
    const st = $('#st');
    st.className = 'pill ' + (a.bloq ? 'bad' : a.alerta ? 'warn' : 'good');
    st.textContent = a.bloq ? 'Reprovado: ' + a.bloq + ' bloqueador(es)' : a.alerta ? 'Aprovado com ' + a.alerta + ' alerta(s)' : 'Aprovado';
    const q = $('#nQ'); q.hidden = !a.bloq; q.textContent = a.bloq;

    $('#qg').innerHTML = a.ck.map((c, ci) => {
      const ls = []; const vistos = new Set();
      c.locs.forEach((l, k) => { if (!vistos.has(l.ln)) { vistos.add(l.ln); ls.push(lnBtn(`data-c="${ci}" data-k="${k}"`, l.ln)); } });
      const extra = ls.length > 30 ? `<span class="mu">e mais ${ls.length - 30}</span>` : '';
      const onde = ls.length ? `<div class="locs"><span class="mu">${c.l === 'ok' ? 'Onde' : ls.length > 1 ? 'Linhas' : 'Linha'}</span>${ls.slice(0, 30).join('')}${extra}</div>` : '';
      return `<li class="${c.l}"><b>${NOME_NV[c.l]}: ${esc(c.t)}</b>${esc(c.d)}${onde}</li>`;
    }).join('') || '<li class="ok"><b>Nenhuma regra ativa</b>Todas as regras estão desligadas na aba Regras.</li>';

    const ls = { ok: ['ok', 'OK'], vazio: ['bloq', 'Vazio'], hash: ['alerta', 'Apenas #'], js: ['bloq', 'javascript:'] };
    $('#lkT').innerHTML = a.links.map((l, i) => `<tr><td>${i + 1}</td><td>${lnBtn(`data-l="${i}"`, l.loc && l.loc.ln)}</td><td class="m">${l.href === null ? '(sem href)' : esc(l.href) || '(vazio)'}</td><td>${esc(l.texto) || '<span class="mu">(sem texto)</span>'}</td><td><span class="b ${ls[l.st][0]}">${ls[l.st][1]}</span></td></tr>`).join('')
      || '<tr><td colspan="5" class="mu">Nenhum link encontrado.</td></tr>';
    $('#antiN').textContent = a.dn ? a.dn + ' domínio(s) em texto puro detectado(s).' : 'Nenhum domínio em texto puro detectado.';
    renderImgs();

    const key = Object.keys(a.vars).map(n => n + ':' + a.vars[n].n).join('|');
    if (key !== varKey) {
      varKey = key;
      const nm = {};
      for (const n in a.vars) nm[n] = S.map[n] || { amp: '@' + n.charAt(0).toLowerCase() + n.slice(1), attr: n };
      S.map = nm;
      $('#vrT').innerHTML = Object.keys(a.vars).map(n => {
        const m = S.map[n], v = a.vars[n];
        return `<tr><td class="m">%%${esc(n)}%%</td><td>${v.n} ${lnBtn(`data-v="${esc(n)}"`, v.locs[0] && v.locs[0].ln)}</td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="amp" value="${esc(m.amp)}" aria-label="Variável AMPScript para ${esc(n)}"${ampValido(m.amp) ? '' : ' aria-invalid="true"'}></td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="attr" value="${esc(m.attr)}" aria-label="Atributo da DE para ${esc(n)}"></td>` +
          `<td><input type="text" data-v="${esc(n)}" data-k="teste" value="${esc(S.teste[n] || '')}" placeholder="${esc(WB.preview.amostra(m.attr || n))}" aria-label="Dado de teste para ${esc(n)}"></td></tr>`;
      }).join('') || '<tr><td colspan="5" class="mu">Nenhuma variável de personalização encontrada.</td></tr>';
    }
  }
  const ampValido = v => !v.trim() || /^@[A-Za-z_]\w*$/.test(v.trim());

  function renderImgs() {
    if (!A) return;
    const b = S.base.trim().replace(/\/?$/, '/');
    $('#imT').innerHTML = A.imgs.map((i, k) => {
      const sf = R.sufRe.test(i.file);
      const nw = S.base.trim() && !/^(%%|data:)/i.test(i.src) && (!S.onlySuf || sf) ? b + i.file : '—';
      return `<tr><td>${lnBtn(`data-i="${k}"`, i.loc && i.loc.ln)}</td><td class="m">${esc(i.file || '(sem src)')}</td><td>${sf ? '<span class="b ok">Sim</span>' : 'Não'}</td><td>${i.alt === null ? '<span class="b alerta">Sem alt</span>' : esc(i.alt) || '(vazio)'}</td><td class="m">${esc(nw)}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="mu">Nenhuma imagem encontrada.</td></tr>';
  }

  // ================= Preview =================
  let pvTimer;
  function tdPreview() {
    const td = {};
    for (const n of Object.keys(S.map)) {
      const attr = (S.map[n].attr || n).trim();
      const v = S.teste[n] || WB.preview.amostra(attr || n);
      td[n.toLowerCase()] = v; if (attr) td[attr.toLowerCase()] = v;
    }
    return td;
  }
  function paint() {
    const o = S.out;
    $('#cOut').textContent = o.length.toLocaleString('pt-BR') + ' caracteres, ' + (o ? o.split('\n').length : 0) + ' linhas';
    clearTimeout(pvTimer);
    pvTimer = setTimeout(() => {
      const r = WB.preview.gerar(o, { dados: PV.dados, td: tdPreview(), isSys: R.isSys, imagens: PV.imagens, escuro: PV.escuro });
      const pv = $('#pv');
      let y = 0; try { y = pv.contentWindow.scrollY || 0; } catch (e) { /* sem acesso */ }
      pv.onload = () => { try { pv.contentWindow.scrollTo(0, y); } catch (e) { /* ok */ } };
      pv.srcdoc = r.html;
      $('#pvNota').textContent = o ? r.notas.join(' ') : 'O preview aparece quando houver HTML na entrada.';
    }, 250);
  }
  function aplicarPreview() {
    $('#fr').classList.toggle('m', PV.mobile);
    $('#mb').setAttribute('aria-pressed', PV.mobile); $('#dk').setAttribute('aria-pressed', !PV.mobile);
    $('#pvTema').value = PV.escuro; $('#pvImg').checked = PV.imagens; $('#pvDados').checked = PV.dados;
    $('#fr').classList.toggle('dark', PV.escuro !== 'off');
    try { localStorage.setItem(K.preview, JSON.stringify(PV)); } catch (e) { /* ok */ }
  }

  // ================= Navegação até a linha =================
  function aba(t) {
    $$('#tabs button').forEach(x => x.setAttribute('aria-selected', x.dataset.t === t));
    $$('.pn').forEach(p => { p.hidden = p.id !== 'p-' + t; });
    if (t === 'in') edSrc.refresh();
    if (t === 'cd') edOut.refresh();
  }
  function irPara(loc) {
    if (!loc) return;
    garantirRun();
    aba('in');
    requestAnimationFrame(() => { edSrc.refresh(); edSrc.ir(loc.s, loc.e); });
  }
  function locDe(d) {
    if (!A) return null;
    if (d.c !== undefined) return A.ck[+d.c] && A.ck[+d.c].locs[+d.k];
    if (d.l !== undefined) return A.links[+d.l] && A.links[+d.l].loc;
    if (d.i !== undefined) return A.imgs[+d.i] && A.imgs[+d.i].loc;
    if (d.v !== undefined) return A.vars[d.v] && A.vars[d.v].locs[0];
    return null;
  }
  ['#qg', '#lkT', '#imT', '#vrT'].forEach(sel => $(sel).addEventListener('click', e => {
    const b = e.target.closest('button.ln'); if (b) irPara(locDe(b.dataset));
  }));

  // ================= Relatório =================
  async function metaRelatorio() {
    garantirRun();
    const h = await WB.report.hash(S.src);
    return {
      ...S.meta, arquivo: S.arquivo, geradoEm: new Date(), hash: h.valor, hashAlg: h.alg, map: S.map,
      regras: { fonte: window.WB_REGRAS_TIME ? 'regras do time' : 'padrão embutido', personalizada: regras.personalizada, assinatura: WB.rules.assinatura(regras.cfg) }
    };
  }
  const slug = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 50) || 'email';
  const nomeRel = m => {
    const d = m.geradoEm, p2 = n => String(n).padStart(2, '0');
    return 'homologacao_' + slug(m.campanha || (m.arquivo || 'email').replace(/\.[^.]+$/, '')) + '_' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes());
  };
  function semAnalise() { if (A) return false; toast('Cole um HTML na aba Entrada antes de gerar o relatório', { erro: true }); return true; }

  $('#relTxt').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const m = await metaRelatorio();
    baixar(nomeRel(m) + '.txt', '\uFEFF' + WB.report.texto(A, m), 'text/plain;charset=utf-8');
    toast('Relatório TXT baixado');
  };
  $('#relCopy').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const ok = await copiar(WB.report.texto(A, await metaRelatorio()));
    toast(ok ? 'Relatório copiado. Cole no chamado.' : 'Não foi possível copiar', { erro: !ok });
  };
  $('#relPdf').onclick = async () => {
    garantirRun(); if (semAnalise()) return;
    const html = WB.report.html(A, await metaRelatorio());
    const f = document.createElement('iframe');
    f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1;
    f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.append(f);
    f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { toast('Não foi possível abrir a impressão', { erro: true }); } setTimeout(() => f.remove(), 60000); };
    f.srcdoc = html;
    toast('Na janela de impressão, escolha “Salvar como PDF”');
  };
  [['#mCamp', 'campanha'], ['#mCham', 'chamado'], ['#mResp', 'responsavel']].forEach(([sel, k]) =>
    $(sel).addEventListener('input', e => mudar('Dados do chamado', () => { S.meta[k] = e.target.value; }, { semRun: true })));

  // ================= Regras =================
  const campos = { chamadaRastreamento: '#rgRedirect', limiteKB: '#rgKB', sufixoImagem: '#rgSuf', variaveisDescadastro: '#rgUnsub', variaveisSistema: '#rgSys', dominios: '#rgTld' };

  function renderRegras() {
    const { CATALOGO, NIVEIS, NOME_NIVEL } = WB.rules;
    $('#rgNiv').innerHTML = CATALOGO.map(r => `<tr><td>${esc(r.nome)}</td><td><select data-r="${r.id}" class="nv-${regras.cfg.niveis[r.id]}" aria-label="Nível da regra: ${esc(r.nome)}">` +
      NIVEIS.map(n => `<option value="${n}"${regras.cfg.niveis[r.id] === n ? ' selected' : ''}>${NOME_NIVEL[n]}</option>`).join('') + '</select></td></tr>').join('');
    const p = regras.cfg.parametros;
    $('#rgRedirect').value = p.chamadaRastreamento; $('#rgKB').value = p.limiteKB; $('#rgSuf').value = p.sufixoImagem;
    $('#rgUnsub').value = p.variaveisDescadastro.join('\n'); $('#rgSys').value = p.variaveisSistema.join('\n'); $('#rgTld').value = p.dominios.join('\n');
    Object.values(campos).forEach(s => $(s).removeAttribute('aria-invalid'));
    $('#rgJson').value = JSON.stringify(regras.cfg, null, 2);
    fonteRegras();
  }
  function fonteRegras() {
    $('#rgFonte').textContent = 'Base: ' + (window.WB_REGRAS_TIME ? 'regras do time (arquivo regras-time.js).' : 'padrão embutido na ferramenta.') +
      (regras.personalizada ? ' Há ajustes salvos neste navegador.' : ' Sem ajustes locais.');
  }
  function mostrarErros(erros) {
    const el = $('#rgErr');
    el.hidden = !erros.length; el.textContent = erros.join(' ');
    for (const [k, s] of Object.entries(campos)) {
      if (erros.some(e => e.includes('"' + k + '"') || e.includes(k))) $(s).setAttribute('aria-invalid', 'true'); else $(s).removeAttribute('aria-invalid');
    }
  }
  function aplicarRegras(cfg, personalizada) {
    regras = { cfg, personalizada };
    if (personalizada && !WB.rules.salvar(cfg)) toast('Regras aplicadas, mas o navegador não deixou salvá-las', { erro: true });
    R = WB.rules.compilar(cfg);
    if (S.outManual) { H.pendente(); H.registrar(ROT_OUT); }
    varKey = '\u0000';
    run();
    $('#rgJson').value = JSON.stringify(cfg, null, 2);
    fonteRegras();
  }

  $('#rgNiv').addEventListener('change', e => {
    const s = e.target.closest('select'); if (!s) return;
    const cfg = WB.rules.clone(regras.cfg); cfg.niveis[s.dataset.r] = s.value; s.className = 'nv-' + s.value;
    aplicarRegras(cfg, true);
    toast('Regra atualizada');
  });
  let rgTimer;
  $$('.rgp [data-k]').forEach(el => el.addEventListener('input', () => {
    clearTimeout(rgTimer);
    rgTimer = setTimeout(() => {
      const k = el.dataset.k;
      const { cfg, erros } = WB.rules.normalizar({ parametros: { [k]: k === 'limiteKB' ? el.value : el.value } }, regras.cfg);
      mostrarErros(erros);
      if (!erros.length) aplicarRegras(cfg, true);
    }, 450);
  }));
  function importar(texto, origem) {
    let obj;
    try { obj = JSON.parse(texto); } catch (e) { mostrarErros(['JSON inválido: ' + e.message]); return; }
    const { cfg, erros } = WB.rules.normalizar(obj, WB.rules.base());
    aplicarRegras(cfg, true); renderRegras(); mostrarErros(erros);
    toast(erros.length ? `Regras ${origem} com ${erros.length} ajuste(s) ignorado(s)` : `Regras ${origem}`, { erro: !!erros.length });
  }
  $('#rgAplicar').onclick = () => importar($('#rgJson').value, 'aplicadas');
  $('#rgImp').onclick = () => $('#rgFile').click();
  $('#rgFile').addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader(); r.onload = () => importar(String(r.result), 'importadas'); r.readAsText(f); e.target.value = '';
  });
  $('#rgExp').onclick = () => { baixar('regras-sfmc-workbench.json', JSON.stringify(regras.cfg, null, 2), 'application/json'); toast('Regras exportadas'); };
  $('#rgExpJs').onclick = () => {
    baixar('regras-time.js', '/* Regras do time para o SFMC Workbench. Substitua o arquivo regras-time.js na pasta da ferramenta. */\nwindow.WB_REGRAS_TIME = ' + JSON.stringify(regras.cfg, null, 2) + ';\n', 'text/javascript');
    toast('regras-time.js baixado');
  };
  $('#rgReset').onclick = async () => {
    if (!regras.personalizada) { toast('Já está usando as regras do time'); return; }
    if (!(await confirmar({ titulo: 'Restaurar regras do time?', texto: 'Os ajustes de regras salvos neste navegador serão apagados.', ok: 'Restaurar regras' }))) return;
    WB.rules.limpar(); aplicarRegras(WB.rules.base(), false); renderRegras(); mostrarErros([]);
    toast('Regras do time restauradas');
  };

  // ================= Ações do projeto =================
  function carregarArquivo(f) {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      const tinha = !!S.src.trim();
      mudar('Carregar ' + f.name, () => { S.src = String(r.result); S.arquivo = f.name; edSrc.set(S.src, { topo: true }); }, { discreto: true });
      aba('in');
      toast('Arquivo ' + f.name + ' carregado', tinha ? { acao: 'Desfazer', fn: () => H.desfazer() } : {});
    };
    r.onerror = () => toast('Não foi possível ler o arquivo', { erro: true });
    r.readAsText(f);
  }

  // Entrada vinda da aba do Validador: o HTML do pacote que acabou de ser conferido.
  // Mesmo tratamento de carregar um arquivo (passo próprio no histórico, com
  // Desfazer), porque substitui o HTML que já estiver no editor.
  function abrirPeca(texto, nome) {
    const tinha = !!S.src.trim();
    mudar('Abrir ' + nome + ' do Validador', () => { S.src = String(texto); S.arquivo = nome; edSrc.set(S.src, { topo: true }); }, { discreto: true });
    aba('in');
    toast('HTML de ' + nome + ' aberto no Workbench', tinha ? { acao: 'Desfazer', fn: () => H.desfazer() } : {});
  }
  WB.abrirPeca = abrirPeca;

  async function limparProjeto(semConfirmar) {
    if (!S.src && !S.out && !S.base && !Object.values(S.meta).some(Boolean)) { toast('O projeto já está vazio'); return; }
    if (!semConfirmar && !(await confirmar({
      titulo: 'Limpar o projeto?',
      texto: 'O HTML, o código final, a URL base, o mapeamento de variáveis, os dados de teste e os dados do chamado serão apagados. Dá para desfazer logo em seguida.',
      ok: 'Limpar projeto'
    }))) return;
    mudar('Limpar projeto', () => { S = VAZIO(); edSrc.set(''); edOut.set(''); sincronizarCampos(); varKey = ''; }, { discreto: true });
    toast('Projeto limpo', { acao: 'Desfazer', fn: () => H.desfazer() });
  }

  $('#fileBtn').onclick = () => $('#file').click();
  $('#file').addEventListener('change', e => { carregarArquivo(e.target.files[0]); e.target.value = ''; });
  const dz = $('#drop');
  ['dragenter', 'dragover'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); dz.classList.add('on'); }, true));
  ['dragleave', 'drop'].forEach(v => dz.addEventListener(v, e => { e.preventDefault(); if (v === 'drop' || !dz.contains(e.relatedTarget)) dz.classList.remove('on'); }, true));
  dz.addEventListener('drop', e => {
    const f = e.dataTransfer.files[0];
    if (f && /\.(html?|txt)$/i.test(f.name)) carregarArquivo(f); else toast('Use um arquivo .html, .htm ou .txt', { erro: true });
  }, true);

  $('#base').addEventListener('input', e => mudar('URL base', () => { S.base = e.target.value; }));
  $('#onlysuf').addEventListener('change', e => mudar('Troca só de sufixos', () => { S.onlySuf = e.target.checked; }, { discreto: true }));
  $('#anti').addEventListener('change', e => mudar('Proteção anti-link', () => { S.anti = e.target.checked; }, { discreto: true }));
  $('#vrT').addEventListener('input', e => {
    const t = e.target, n = t.dataset.v, k = t.dataset.k;
    if (!n || !k) return;
    if (k === 'teste') { mudar('Dado de teste', () => { S.teste[n] = t.value; }, { semRun: true }); return; }
    if (k === 'amp') t.toggleAttribute('aria-invalid', !ampValido(t.value));
    mudar('Mapeamento de variáveis', () => { S.map[n] = Object.assign({}, S.map[n], { [k]: t.value }); });
  });

  $('#regen').onclick = () => { mudar('Regerar código', () => { S.outManual = false; }, { discreto: true }); toast('Código regerado a partir do HTML original'); };
  $('#copy').onclick = async () => {
    if (!S.out) { toast('Não há código para copiar', { erro: true }); return; }
    const ok = await copiar(S.out); toast(ok ? 'Código copiado' : 'Não foi possível copiar', { erro: !ok });
  };
  $('#clear').onclick = () => limparProjeto(false);
  $('#undo').onclick = () => H.desfazer();
  $('#redo').onclick = () => H.refazer();
  // O tema é o do Validador (botão do cabeçalho, chave bradesco_validador_emkt_theme).
  $('#tabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) aba(b.dataset.t); });
  $('#tabs').addEventListener('keydown', e => {
    if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    const bs = $$('#tabs button'), i = bs.indexOf(document.activeElement); if (i < 0) return;
    const n = bs[(i + (e.key === 'ArrowRight' ? 1 : -1) + bs.length) % bs.length]; n.focus(); aba(n.dataset.t);
  });

  $('#dk').onclick = () => { PV.mobile = false; aplicarPreview(); };
  $('#mb').onclick = () => { PV.mobile = true; aplicarPreview(); };
  $('#pvTema').addEventListener('change', e => { PV.escuro = e.target.value; aplicarPreview(); paint(); });
  $('#pvImg').addEventListener('change', e => { PV.imagens = e.target.checked; aplicarPreview(); paint(); });
  $('#pvDados').addEventListener('change', e => { PV.dados = e.target.checked; aplicarPreview(); paint(); });

  // A página tem duas abas. Sem esta guarda, Ctrl+Z na aba do Validador desfaria
  // o projeto do Workbench, que está escondido.
  const abaWorkbench = () => document.getElementById('aba-workbench');
  const abaVisivel = () => { const a = abaWorkbench(); return !!a && !a.hidden; };

  document.addEventListener('keydown', e => {
    if (!abaVisivel()) return;
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    if (e.target.closest && e.target.closest('input,textarea,select,.CodeMirror,[contenteditable="true"]')) return;
    const k = e.key.toLowerCase();
    if (k === 'z' && !e.shiftKey) { e.preventDefault(); H.desfazer(); }
    else if (k === 'y' || (k === 'z' && e.shiftKey)) { e.preventDefault(); H.refazer(); }
  });

  // Os editores nascem com a aba escondida (medida zero). Ao mostrar a aba, a
  // página avisa e o CodeMirror recalcula o tamanho do editor da sub-aba aberta.
  document.addEventListener('wb:visivel', () => {
    requestAnimationFrame(() => {
      const atual = $('#tabs button[aria-selected="true"]');
      const t = atual ? atual.dataset.t : 'in';
      if (t === 'in') edSrc.refresh();
      if (t === 'cd') edOut.refresh();
    });
  });

  // ================= Início =================
  function iniciar() {
    aplicarPreview();
    renderRegras();
    let d = null;
    try { d = JSON.parse(localStorage.getItem(K.rascunho)); } catch (e) { /* sem rascunho */ }
    if (d && d.s && ((d.s.src || '').trim() || (d.s.out || '').trim())) {
      S = Object.assign(VAZIO(), d.s, { meta: Object.assign(VAZIO().meta, d.s.meta) });
      edSrc.set(S.src, { topo: true });
      sincronizarCampos();
      if (S.outManual) { edOut.set(S.out); run({ manterOut: true }); } else run();
      const quando = new Date(d.ts);
      toast(`Rascunho de ${quando.toLocaleDateString('pt-BR')} às ${hora(quando)} restaurado`, { acao: 'Começar do zero', fn: () => limparProjeto(true) });
    } else run();
    H.registrar('Início');
  }
  iniciar();
})(window.WB = window.WB || {});
