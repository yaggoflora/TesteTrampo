/* runner.js — Executa os casos de tests/casos.js com as regras PADRÃO embutidas
 * (não usa regras-time.js nem ajustes do navegador, para o resultado ser reproduzível). */
(function (WB) {
  'use strict';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const AMP = /%%\[[\s\S]*?\]%%|%%=[\s\S]*?=%%/g;
  const igual = (a, b) => JSON.stringify(a) === JSON.stringify(b);

  function rodar(caso) {
    const falhas = [];
    const f = (msg, esperado, obtido) => falhas.push({ msg, esperado, obtido });
    const { cfg, erros } = WB.rules.normalizar(caso.regras || {}, WB.rules.clone(WB.rules.PADRAO));
    if (erros.length) f('Regras do caso inválidas', '[]', erros.join(' '));
    const R = WB.rules.compilar(cfg);

    if (caso.gerar) {
      const out = WB.audit.compile(caso.html, caso.gerar, R);
      if (caso.igual && out !== caso.html) f('Código final deveria ser idêntico ao original', '(idêntico)', '(diferente)');
      (caso.contem || []).forEach(t => { if (!out.includes(t)) f('Código final deveria conter', t, '(ausente)'); });
      (caso.naoContem || []).forEach(t => { if (out.includes(t)) f('Código final não deveria conter', t, '(presente)'); });
      if (caso.preservaAmp) (caso.html.match(AMP) || []).forEach(t => { if (!out.includes(t)) f('AMPScript alterado na geração', t, '(ausente)'); });
      return falhas;
    }
    if (caso.preview) {
      const r = WB.preview.gerar(caso.html, Object.assign({ isSys: R.isSys }, caso.preview));
      (caso.contem || []).forEach(t => { if (!r.html.includes(t)) f('Preview deveria conter', t, '(ausente)'); });
      (caso.naoContem || []).forEach(t => { if (r.html.includes(t)) f('Preview não deveria conter', t, '(presente)'); });
      return falhas;
    }

    const A = WB.audit.analyze(caso.html, R), e = caso.espera || {};
    const falhando = id => A.ck.find(c => c.id === id && c.l !== 'ok');
    if (e.status && A.status !== e.status) f('Status', e.status, A.status + ' (' + A.ck.filter(c => c.l !== 'ok').map(c => c.id + ':' + c.l).join(', ') + ')');
    for (const [id, nv] of Object.entries(e.tem || {})) {
      const c = A.ck.find(x => x.id === id && x.l === nv);
      if (!c) f(`Checagem ${id}`, nv, (A.ck.find(x => x.id === id) || {}).l || '(ausente)');
    }
    (e.naoTem || []).forEach(id => { const c = falhando(id); if (c) f(`Checagem ${id} não deveria falhar`, '(ausente)', c.l + ': ' + c.t); });
    const cont = { links: A.links.length, imgs: A.imgs.length, vars: Object.keys(A.vars).length, dominios: A.dn };
    for (const k of Object.keys(cont)) if (e[k] !== undefined && e[k] !== cont[k]) f('Quantidade de ' + k, e[k], cont[k]);
    if (e.hrefs && !igual(e.hrefs, A.links.map(l => l.href))) f('hrefs lidos', JSON.stringify(e.hrefs), JSON.stringify(A.links.map(l => l.href)));
    if (e.alts && !igual(e.alts, A.imgs.map(i => i.alt))) f('alts lidos', JSON.stringify(e.alts), JSON.stringify(A.imgs.map(i => i.alt)));
    for (const [id, ls] of Object.entries(e.linhas || {})) {
      const c = falhando(id);
      const obt = c ? [...new Set(c.locs.map(l => l.ln))] : [];
      if (!igual(obt, ls)) f(`Linhas de ${id}`, ls.join(', '), obt.join(', ') || '(nenhuma)');
    }
    return falhas;
  }

  function executar() {
    const casos = window.WB_CASOS || [];
    const res = casos.map(c => { let falhas; try { falhas = rodar(c); } catch (err) { falhas = [{ msg: 'Erro ao executar', esperado: '', obtido: err.message }]; console.error(err); } return { c, falhas }; });
    const ok = res.filter(r => !r.falhas.length).length;
    window.WB_RESULTADO = { total: res.length, ok, falhas: res.filter(r => r.falhas.length).map(r => ({ nome: r.c.nome, falhas: r.falhas })) };

    const sum = document.getElementById('sum');
    sum.className = ok === res.length ? 'ok' : 'bad';
    sum.textContent = ok === res.length ? `Todos os ${res.length} testes passaram` : `${res.length - ok} de ${res.length} testes falharam`;
    const grupos = [...new Set(res.map(r => r.c.grupo || 'Outros'))];
    document.getElementById('lista').innerHTML = grupos.map(g => `<h2>${esc(g)}</h2><ul>` + res.filter(r => (r.c.grupo || 'Outros') === g).map(r =>
      `<li class="${r.falhas.length ? 'bad' : 'ok'}"><b>${r.falhas.length ? 'Falhou' : 'Passou'}</b> ${esc(r.c.nome)}` +
      (r.falhas.length ? '<ul class="f">' + r.falhas.map(x => `<li>${esc(x.msg)}: esperado <code>${esc(x.esperado)}</code>, obtido <code>${esc(x.obtido)}</code></li>`).join('') + '</ul>' : '') +
      `<details><summary>Ver HTML do caso</summary><pre>${esc(r.c.html.length > 4000 ? r.c.html.slice(0, 4000) + '\n…' : r.c.html)}</pre></details></li>`).join('') + '</ul>').join('');
  }
  WB.testes = { executar, rodar };
  executar();
})(window.WB = window.WB || {});
