/* casos.js — HTMLs de exemplo e o resultado esperado de cada um.
 *
 * Para criar um caso novo, copie um bloco e ajuste:
 *   html     o e-mail de teste
 *   regras   (opcional) ajustes sobre o padrão embutido, no mesmo formato do JSON de regras
 *   espera   o que o Quality Gate deve devolver:
 *            status: 'aprovado' | 'alertas' | 'reprovado'
 *            tem:    { idDaRegra: 'bloq' | 'alerta' | 'ok' }
 *            naoTem: [ ids que NÃO podem aparecer como bloqueador/alerta ]
 *            links, imgs, vars, dominios: quantidades
 *            hrefs, alts: valores exatos, na ordem do HTML
 *            linhas: { idDaRegra: [linhas esperadas] }
 *   gerar    (opcional) opções da geração do código final; use com contem/naoContem/igual/preservaAmp
 *   preview  (opcional) opções do preview; use com contem/naoContem
 */
(function () {
  'use strict';

  const BASE = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Oferta</title>
<style>a{color:#cc092f}</style>
</head>
<body>
%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%
<table role="presentation" width="600">
  <tr><td><a href="%%view_email_url%%">Ver no navegador</a></td></tr>
  <tr><td><a href="%%=RedirectTo(@Link_Tag)=%%"><img src="https://image.exemplo.com/lib/banner_01.png" alt="Oferta especial" width="600"></a></td></tr>
  <tr><td>Olá, %%Nome%%! Seu limite é %%Limite%%.</td></tr>
  <tr><td><a href="%%unsub_center_url%%">Descadastrar</a></td></tr>
</table>
</body>
</html>`;
  const troca = (de, para) => BASE.replace(de, para);
  const UNSUB = '<tr><td><a href="%%unsub_center_url%%">Descadastrar</a></td></tr>';

  window.WB_CASOS = [
    // ------------------------------------------------------------ aprovados
    {
      nome: 'Aprovado: e-mail completo e dentro do padrão', grupo: 'Aprovados',
      html: BASE,
      espera: { status: 'aprovado', links: 3, imgs: 1, vars: 2, dominios: 0, tem: { viewEmailUrl: 'ok', redirectTo: 'ok', descadastroPadrao: 'ok' } }
    },
    {
      nome: 'Aprovado: imagem decorativa com alt vazio conta como alt presente', grupo: 'Aprovados',
      html: troca('<td>Olá', '<td><img src="https://image.exemplo.com/lib/espaco.gif" alt="" width="1">Olá'),
      espera: { status: 'aprovado', imgs: 2, alts: ['Oferta especial', ''] }
    },

    // ------------------------------------------------------------ reprovados
    {
      nome: 'Reprovado: sem link de descadastro', grupo: 'Reprovados',
      html: troca(UNSUB, ''),
      espera: { status: 'reprovado', tem: { descadastroAusente: 'bloq' }, links: 2 }
    },
    {
      nome: 'Reprovado: sem %%view_email_url%% e sem RedirectTo', grupo: 'Reprovados',
      html: troca('<a href="%%view_email_url%%">Ver no navegador</a>', 'Ver no navegador').replace('%%=RedirectTo(@Link_Tag)=%%', 'https://www.exemplo.com.br/oferta'),
      espera: { status: 'reprovado', tem: { viewEmailUrl: 'bloq', redirectTo: 'bloq' } }
    },
    {
      nome: 'Reprovado: href vazio, link sem href e javascript:', grupo: 'Reprovados',
      html: troca(UNSUB, UNSUB + '\n  <tr><td><a href="">Saiba mais</a> <a name="topo">Topo</a> <a href="javascript:void(0)">Abrir</a></td></tr>'),
      espera: { status: 'reprovado', tem: { hrefVazio: 'bloq', hrefJs: 'bloq' }, links: 6, linhas: { hrefVazio: [16], hrefJs: [16] } }
    },
    {
      nome: 'Reprovado: tag script (AMPScript em <script language="ampscript"> é aceito)', grupo: 'Reprovados',
      html: troca('</body>', '<script runat="server" language="ampscript">SET @x = 1</script>\n<script>alert(1)</script>\n</body>'),
      espera: { status: 'reprovado', tem: { scriptTag: 'bloq' }, linhas: { scriptTag: [18] } }
    },
    {
      nome: 'Reprovado: bloco AMPScript sem fechamento', grupo: 'Reprovados',
      html: troca('%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%', '%%[ SET @Promo = "verao"\n%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta" ]%%'),
      espera: { status: 'reprovado', tem: { ampNaoFechado: 'bloq' }, linhas: { ampNaoFechado: [10] } }
    },

    // ------------------------------------------------------------ alertas
    {
      nome: 'Alertas: href “#” e descadastro com RedirectTo', grupo: 'Alertas',
      html: troca(UNSUB, '<tr><td><a href="#">Regulamento</a> <a href="%%=RedirectTo(%%unsub_center_url%%)=%%">Sair</a></td></tr>'),
      espera: { status: 'alertas', tem: { hrefHash: 'alerta', descadastroPadrao: 'alerta' }, naoTem: ['descadastroAusente'] }
    },
    {
      nome: 'Alertas: imagem sem alt e imagem com src relativo', grupo: 'Alertas',
      html: troca('<td>Olá', '<td><img src="images/selo_02.png"><img src="https://image.exemplo.com/lib/x.png" alt="X">Olá'),
      espera: { status: 'alertas', tem: { imgSemAlt: 'alerta', imgRelativa: 'alerta' }, imgs: 3 }
    },
    {
      nome: 'Alertas: link dentro de outro link', grupo: 'Alertas',
      html: troca('<td>Olá', '<td><a href="%%=RedirectTo(@Link_Tag)=%%">Clique <a href="%%=RedirectTo(@Link_Tag)=%%">aqui</a></a>Olá'),
      espera: { status: 'alertas', tem: { linkAninhado: 'alerta' }, linhas: { linkAninhado: [14] } }
    },
    {
      nome: 'Alertas: HTML acima de 102 KB', grupo: 'Alertas',
      html: troca('</body>', '<!--' + 'x'.repeat(106 * 1024) + '-->\n</body>'),
      espera: { status: 'alertas', tem: { tamanho: 'alerta' } }
    },
    {
      nome: 'Alertas: sem DOCTYPE e sem meta viewport', grupo: 'Alertas',
      html: troca('<!DOCTYPE html>\n', '').replace('<meta name="viewport" content="width=device-width, initial-scale=1">\n', ''),
      espera: { status: 'alertas', tem: { doctype: 'alerta', viewport: 'alerta' } }
    },

    // ------------------------------------------------------------ parser
    {
      nome: 'Parser: aspas com “>”, tags em maiúsculas e atributos sem aspas', grupo: 'Parser de HTML',
      html: troca('<td>Olá', `<td><A HREF='%%=RedirectTo(@Link_Tag)=%%' TITLE="a > b">Ver</A><IMG SRC=foto_02.png ALT=Foto WIDTH=100>Olá`),
      espera: { status: 'alertas', links: 4, imgs: 2, alts: ['Oferta especial', 'Foto'], naoTem: ['hrefVazio', 'imgSemAlt'], tem: { imgRelativa: 'alerta' } }
    },
    {
      nome: 'Parser: AMPScript com aspas duplas dentro do href', grupo: 'Parser de HTML',
      html: troca('<td>Olá', '<td><a href="%%=RedirectTo(Concat("https://www.exemplo.com.br/?id=", @id))=%%">Meu cupom</a>Olá'),
      espera: {
        status: 'aprovado', links: 4, naoTem: ['hrefVazio'],
        hrefs: ['%%view_email_url%%', '%%=RedirectTo(@Link_Tag)=%%', '%%=RedirectTo(Concat("https://www.exemplo.com.br/?id=", @id))=%%', '%%unsub_center_url%%']
      }
    },
    {
      nome: 'Parser: links em comentários, <style> e condicional do Outlook não contam', grupo: 'Parser de HTML',
      html: troca('<style>a{color:#cc092f}</style>', '<style>a[href=""]{color:red} /* <a href=""> */</style>')
        .replace('<td>Olá', '<td><!-- <a href="">antigo</a> --><!--[if mso]><v:roundrect href=""><a href="">x</a></v:roundrect><![endif]-->Olá'),
      espera: { status: 'aprovado', links: 3, naoTem: ['hrefVazio'] }
    },
    {
      nome: 'Parser: domínios em texto puro (inclusive com entidade), ignorando atributos e comentários', grupo: 'Parser de HTML',
      html: troca('<td>Olá', '<td>Acesse bradesco.com.br ou exemplo&#46;com <!-- teste.com.br --><a href="https://www.site.com.br">clique</a> site&#xFEFF;.com Olá'),
      espera: { status: 'alertas', dominios: 2, tem: { dominioTexto: 'alerta' }, linhas: { dominioTexto: [14] } }
    },

    // ------------------------------------------------------------ regras configuráveis
    {
      nome: 'Regras: href “#” elevado a bloqueador', grupo: 'Regras configuráveis',
      html: troca(UNSUB, UNSUB + '<tr><td><a href="#">Regulamento</a></td></tr>'),
      regras: { niveis: { hrefHash: 'bloq' } },
      espera: { status: 'reprovado', tem: { hrefHash: 'bloq' } }
    },
    {
      nome: 'Regras: regras desligadas não aparecem', grupo: 'Regras configuráveis',
      html: troca('<a href="%%view_email_url%%">Ver no navegador</a>', 'Ver no navegador').replace('%%=RedirectTo(@Link_Tag)=%%', 'https://www.exemplo.com.br/oferta'),
      regras: { niveis: { viewEmailUrl: 'off', redirectTo: 'off' } },
      espera: { status: 'aprovado', naoTem: ['viewEmailUrl', 'redirectTo'] }
    },
    {
      nome: 'Regras: nova variável de descadastro aceita', grupo: 'Regras configuráveis',
      html: troca('%%unsub_center_url%%', '%%optout_url%%'),
      regras: { parametros: { variaveisDescadastro: ['optout_url'], variaveisSistema: ['view_email_url', 'optout_url'] } },
      espera: { status: 'aprovado', naoTem: ['descadastroAusente'], vars: 2 }
    },
    {
      nome: 'Regras: lista de domínios monitorados', grupo: 'Regras configuráveis',
      html: troca('<td>Olá', '<td>Veja site.com e loja.com.br Olá'),
      regras: { parametros: { dominios: ['com.br'] } },
      espera: { dominios: 1 }
    },
    {
      nome: 'Regras: links http(s) diretos, sem RedirectTo, quando a regra está ligada', grupo: 'Regras configuráveis',
      html: troca('<td>Olá', '<td><a href="https://www.exemplo.com.br/direto">Direto</a>Olá'),
      regras: { niveis: { linkSemRedirect: 'alerta' } },
      espera: { status: 'alertas', tem: { linkSemRedirect: 'alerta' }, linhas: { linkSemRedirect: [14] } }
    },

    // ------------------------------------------------------------ geração do código final
    {
      nome: 'Geração: sem opções, o código final é idêntico ao original', grupo: 'Geração do código final',
      html: BASE,
      gerar: { anti: false, base: '', onlySuf: true, map: {} },
      igual: true
    },
    {
      nome: 'Geração: anti-link só no texto, AMPScript e href intactos', grupo: 'Geração do código final',
      html: troca('<td>Olá', '<td>Acesse www.exemplo.com.br <a href="https://www.exemplo.com.br">site</a> %%=v(@site)=%% Olá'),
      gerar: { anti: true, base: '', onlySuf: true, map: {} },
      contem: ['www&#xFEFF;.exemplo&#xFEFF;.com&#xFEFF;.br', 'href="https://www.exemplo.com.br"', '%%[ SET @Link_Tag = "https://www.exemplo.com.br/oferta?utm=emkt" ]%%', '%%=v(@site)=%%'],
      preservaAmp: true
    },
    {
      nome: 'Geração: URL base troca só imagens com sufixo', grupo: 'Geração do código final',
      html: troca('<td>Olá', '<td><img src="logo.png" alt="Logo"><img src="%%=v(@img)=%%" alt="Dinâmica"><img src=\'images/selo_02.png\' alt="Selo">Olá'),
      gerar: { anti: false, base: 'https://image.s10.exacttarget.com/lib/abc', onlySuf: true, map: {} },
      contem: ['src="https://image.s10.exacttarget.com/lib/abc/banner_01.png"', "src='https://image.s10.exacttarget.com/lib/abc/selo_02.png'", 'src="logo.png"', 'src="%%=v(@img)=%%"'],
      preservaAmp: true
    },
    {
      nome: 'Geração: variáveis viram AttributeValue', grupo: 'Geração do código final',
      html: BASE,
      gerar: { anti: false, base: '', onlySuf: true, map: { Nome: { amp: '@nome', attr: 'PrimeiroNome' }, Limite: { amp: '', attr: 'Limite' } } },
      contem: ['%%[\n  SET @nome = AttributeValue("PrimeiroNome")\n]%%\n<!DOCTYPE html>', 'Olá, %%=v(@nome)=%%!', '%%Limite%%'],
      naoContem: ['%%Nome%%']
    },

    // ------------------------------------------------------------ preview
    {
      nome: 'Preview: dados de teste preenchem AMPScript e variáveis', grupo: 'Preview',
      html: '%%[\n  SET @nome = AttributeValue("PrimeiroNome")\n]%%\n<p>Olá, %%=v(@nome)=%%! Limite: %%Limite%%. <a href="%%view_email_url%%">ver</a></p>',
      preview: { dados: true, td: { primeironome: 'Ana', limite: 'R$ 500,00' } },
      contem: ['Olá, Ana!', 'Limite: R$ 500,00.', 'href="#"'],
      naoContem: ['%%']
    },
    {
      nome: 'Preview: imagens bloqueadas mostram o texto alternativo', grupo: 'Preview',
      html: BASE,
      preview: { dados: true, imagens: true },
      contem: ['Oferta especial</span>'],
      naoContem: ['<img']
    },
    {
      nome: 'Preview: modo escuro ativa o CSS de dark mode do e-mail', grupo: 'Preview',
      html: '<html><head><style>@media (prefers-color-scheme: dark){body{background:#000}}</style></head><body>x</body></html>',
      preview: { escuro: 'css' },
      contem: ['@media (min-width:0px)'],
      naoContem: ['prefers-color-scheme: dark']
    }
  ];
})();
