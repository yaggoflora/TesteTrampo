/* audit.js — Quality Gate e geração do código final.
 *
 * analyze(): lê o HTML com o DOMParser (via WB.parser.dom) e devolve as checagens
 *            com a posição de cada problema no HTML original.
 * compile(): gera o código final editando o texto original só nos pontos necessários
 *            (src de imagens, proteção anti-link, variáveis). O AMPScript fica intacto.
 */
(function (WB) {
  'use strict';
  const P = WB.parser;

  const fileOf = s => String(s || '').split(/[?#]/)[0].split('/').pop();
  const ORDEM = { bloq: 0, alerta: 1, ok: 2 };
  const PADRAO_CHAMADA = 'RedirectTo\\(\\s*@Link_Tag\\s*\\)';

  function kbDe(src) {
    try { return new TextEncoder().encode(src).length / 1024; } catch (e) { return new Blob([src]).size / 1024; }
  }

  function analyze(src, R) {
    const tk = P.tokenize(src);
    const L = P.lineIndex(src);
    const { doc, restore, strip } = P.dom(src, tk);

    const byOff = new Map();
    for (const t of tk.tokens) if (t.t === 'start') byOff.set(t.s, t);
    const offOf = el => { const v = el.getAttribute('data-wbo'); return v == null ? null : +v; };
    const tagLoc = el => {
      const o = offOf(el); if (o == null) return null;
      const t = byOff.get(o); return { s: o, e: t ? Math.min(t.e, o + 400) : o + 1 };
    };
    const attrLoc = (el, name) => {
      const o = offOf(el), t = o != null && byOff.get(o);
      const a = t && t.attrs.find(x => x.lname === name && x.vs >= 0);
      return a && a.ve > a.vs ? { s: a.vs, e: a.ve } : tagLoc(el);
    };
    // O parser pode clonar elementos em HTML mal aninhado; o clone carrega o mesmo data-wbo.
    const unicos = sel => {
      const vistos = new Set();
      return [...doc.querySelectorAll(sel)].filter(el => {
        const o = offOf(el); if (o == null) return true;
        if (vistos.has(o)) return false; vistos.add(o); return true;
      });
    };

    // ---------- Links ----------
    const links = unicos('a').map(el => {
      const href = el.hasAttribute('href') ? restore(el.getAttribute('href')).trim() : null;
      const st = !href ? 'vazio' : href.startsWith('#') ? 'hash' : /^javascript:/i.test(href) ? 'js' : 'ok';
      let texto = strip(el.textContent).replace(/\s+/g, ' ').trim();
      if (!texto) { const im = el.querySelector('img'); if (im) texto = '[imagem] ' + (restore(im.getAttribute('alt')) || ''); }
      return { href, st, texto: texto.slice(0, 90), loc: attrLoc(el, 'href') };
    });

    // ---------- Imagens ----------
    const imgs = unicos('img').map(el => {
      const s = restore(el.getAttribute('src') || '').trim();
      return { src: s, file: fileOf(s), alt: el.hasAttribute('alt') ? restore(el.getAttribute('alt')).trim() : null, loc: tagLoc(el) };
    });

    // ---------- Variáveis de personalização ----------
    const vars = {};
    for (const m of src.matchAll(/%%([A-Za-z_]\w*)%%/g)) {
      if (R.isSys(m[1])) continue;
      const v = vars[m[1]] = vars[m[1]] || { n: 0, locs: [] };
      v.n++; v.locs.push({ s: m.index, e: m.index + m[0].length });
    }

    // ---------- Domínios em texto (nós de texto reais do DOM) ----------
    const textos = tk.tokens.filter(t => t.t === 'text');
    const acharTexto = (str, from) => {
      let lo = 0, hi = textos.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (textos[mid].e <= from) lo = mid + 1; else hi = mid; }
      for (let i = lo, lim = Math.min(textos.length, lo + 600); i < lim; i++) {
        const t = textos[i], ini = Math.max(t.s, from);
        const k = src.slice(ini, t.e).indexOf(str);
        if (k >= 0) return { s: ini + k, e: ini + k + str.length };
      }
      return null;
    };
    const dominios = [], cursor = {};
    if (doc.body) {
      const domRe = R.domRe();
      const w = doc.createTreeWalker(doc.body, 4 /* NodeFilter.SHOW_TEXT */);
      for (let nd = w.nextNode(); nd; nd = w.nextNode()) {
        const p = nd.parentElement;
        if (p && p.closest('script,style,textarea,title,template,xmp')) continue;
        for (const m of strip(nd.data).matchAll(domRe)) {
          const anc = p && p.closest('[data-wbo]');
          const from = Math.max(anc ? offOf(anc) : 0, cursor[m[0]] || 0);
          const achado = acharTexto(m[0], from);
          if (achado) cursor[m[0]] = achado.e;
          dominios.push({ txt: m[0], loc: achado || (anc ? tagLoc(anc) : null) });
        }
      }
    }

    // ---------- Estrutura (tokens) ----------
    const aninhados = []; let prof = 0;
    for (const t of tk.tokens) {
      if (t.t === 'start' && t.name === 'a' && !t.selfClose) { if (prof > 0) aninhados.push({ s: t.s, e: t.e }); prof++; }
      else if (t.t === 'end' && t.name === 'a') prof = Math.max(0, prof - 1);
    }
    const scripts = tk.tokens.filter(t => t.t === 'start' && t.name === 'script' &&
      !t.attrs.some(a => a.lname === 'language' && /ampscript/i.test(a.value || ''))).map(t => ({ s: t.s, e: t.e }));
    const ampAbertos = tk.errors.filter(e => e.tipo === 'ampAberto');
    const temDoctype = tk.tokens.some(t => t.t === 'decl' && /^<!doctype/i.test(src.slice(t.s, t.s + 9)));
    const temViewport = [...doc.querySelectorAll('meta')].some(m => /viewport/i.test(m.getAttribute('name') || ''));
    const head = tk.tokens.find(t => t.t === 'start' && t.name === 'head');
    const kb = kbDe(src);

    // ---------- Checagens ----------
    const ck = [];
    const add = (id, ok, t, d, locs) => {
      const nv = R.nivel(id); if (nv === 'off') return;
      ck.push({ id, l: ok ? 'ok' : nv, t, d, locs: (locs || []).filter(Boolean) });
    };

    const vu = /%%view_email_url%%/i.exec(src);
    if (vu) add('viewEmailUrl', true, '%%view_email_url%% presente', 'Link “ver no navegador” encontrado.', [{ s: vu.index, e: vu.index + vu[0].length }]);
    else add('viewEmailUrl', false, '%%view_email_url%% ausente', 'Inclua o link para visualizar o e-mail no navegador.');

    const padraoTime = R.cfg.parametros.chamadaRastreamento === PADRAO_CHAMADA;
    const rd = R.chamadaCompletaRe.exec(src);
    if (rd) add('redirectTo', true, padraoTime ? 'RedirectTo(@Link_Tag) presente' : 'Chamada de rastreamento presente', 'Encontrada: ' + rd[0].slice(0, 80), [{ s: rd.index, e: rd.index + rd[0].length }]);
    else add('redirectTo', false, padraoTime ? 'RedirectTo(@Link_Tag) ausente' : 'Chamada de rastreamento ausente',
      padraoTime ? 'Use exatamente %%=RedirectTo(@Link_Tag)=%% nos links rastreados.' : 'Nenhum trecho segue o padrão configurado na aba Regras.');

    const un = links.filter(l => l.href && R.unsubRe.test(l.href));
    const nomesUnsub = R.cfg.parametros.variaveisDescadastro.map(v => '%%' + v + '%%');
    if (!un.length) add('descadastroAusente', false, 'Link de descadastro ausente', 'Nenhum href usa ' + (nomesUnsub[0] || 'a variável de descadastro') + (nomesUnsub.length > 1 ? ' ou equivalente.' : '.'));
    else {
      const fora = un.filter(l => /RedirectTo/i.test(l.href) || !/^%%\w+%%$/.test(l.href));
      if (R.nivel('descadastroPadrao') === 'off') add('descadastroAusente', true, 'Link de descadastro presente', 'O href usa a variável de sistema.', un.map(l => l.loc));
      else if (fora.length) add('descadastroPadrao', false, 'Descadastro fora do padrão', 'O href deve conter somente a variável de sistema, sem RedirectTo nem texto extra.', fora.map(l => l.loc));
      else add('descadastroPadrao', true, 'Descadastro conforme', 'O href usa somente a variável de sistema.', un.map(l => l.loc));
    }

    const porSt = st => links.filter(l => l.st === st);
    const vz = porSt('vazio'), hs = porSt('hash'), js = porSt('js');
    if (vz.length) add('hrefVazio', false, vz.length + ' link(s) com href vazio ou ausente', 'Defina o destino de cada link antes de publicar.', vz.map(l => l.loc));
    if (hs.length) add('hrefHash', false, hs.length + ' link(s) com href “#”', 'Substitua por destino real antes de publicar.', hs.map(l => l.loc));
    if (js.length) add('hrefJs', false, js.length + ' link(s) com javascript:', 'Não são suportados em e-mail.', js.map(l => l.loc));
    const diretos = links.filter(l => l.st === 'ok' && /^https?:\/\//i.test(l.href) && !R.chamadaRe.test(l.href));
    if (diretos.length) add('linkSemRedirect', false, diretos.length + ' link(s) http(s) sem chamada de rastreamento', 'Esses links não passam pelo RedirectTo e podem ficar fora do rastreamento.', diretos.map(l => l.loc));
    if (aninhados.length) add('linkAninhado', false, aninhados.length + ' link(s) dentro de outro link', 'Feche cada <a> antes de abrir o próximo. Clientes de e-mail desmontam links aninhados de formas diferentes.', aninhados);

    const sa = imgs.filter(i => i.alt === null);
    if (sa.length) add('imgSemAlt', false, sa.length + ' imagem(ns) sem atributo alt', 'Importante para acessibilidade e para quem bloqueia imagens. Em imagem decorativa, use alt="".', sa.map(i => i.loc));
    const rel = imgs.filter(i => i.src && !/^(https?:|%%|data:)/i.test(i.src));
    if (rel.length) add('imgRelativa', false, rel.length + ' imagem(ns) com src relativo', 'Defina a URL base na aba Imagens.', rel.map(i => i.loc));

    if (scripts.length) add('scriptTag', false, 'Tag script encontrada', 'JavaScript não roda em clientes de e-mail e pode barrar a publicação.', scripts);
    if (ampAbertos.length) add('ampNaoFechado', false, ampAbertos.length + ' trecho(s) AMPScript sem fechamento', 'Feche %%[ com ]%% e %%= com =%%. O SFMC recusa o envio com erro de sintaxe.', ampAbertos);
    if (!temDoctype) add('doctype', false, 'DOCTYPE ausente', 'Recomendado para renderização consistente.', [{ s: 0, e: 0 }]);
    if (!temViewport) add('viewport', false, 'Meta viewport ausente', 'Pode quebrar a versão mobile.', head ? [{ s: head.s, e: head.e }] : [{ s: 0, e: 0 }]);
    if (kb > R.limiteKB) add('tamanho', false, 'HTML com ' + kb.toFixed(0) + ' KB', 'Acima de ' + R.limiteKB + ' KB o Gmail corta o e-mail.');
    if (dominios.length) add('dominioTexto', false, dominios.length + ' domínio(s) em texto puro', 'Podem virar link automático. Ative a proteção anti-link na aba Links.', dominios.map(d => d.loc));

    ck.sort((a, b) => ORDEM[a.l] - ORDEM[b.l]);

    // Linha de cada posição (para a interface e o relatório)
    const ln = loc => { if (loc) loc.ln = L.line(loc.s); return loc; };
    ck.forEach(c => c.locs.forEach(ln));
    links.forEach(l => ln(l.loc)); imgs.forEach(i => ln(i.loc));
    Object.values(vars).forEach(v => v.locs.forEach(ln));
    dominios.forEach(d => ln(d.loc));

    const bloq = ck.filter(c => c.l === 'bloq').length, alerta = ck.filter(c => c.l === 'alerta').length;
    return {
      links, imgs, vars, ck, dominios, dn: dominios.length, kb, linhas: L.total,
      bloq, alerta, status: bloq ? 'reprovado' : alerta ? 'alertas' : 'aprovado'
    };
  }

  /** Proteção anti-link: insere &#xFEFF; antes de "://" e de cada ponto do domínio. */
  function anti(texto, R) {
    return texto.replace(R.domRe(), m => m.replace(/:\/\//, '&#xFEFF;://').replace(/\./g, '&#xFEFF;.'));
  }

  /**
   * o = { base, onlySuf, anti, map: { Var: { amp, attr } } }
   */
  function compile(src, o, R) {
    if (!src.trim()) return '';
    const { tokens } = P.tokenize(src);
    const base = (o.base || '').trim(), b = base ? base.replace(/\/?$/, '/') : '';
    let out = '', last = 0;
    for (const t of tokens) {
      if (t.t === 'text' && o.anti) {
        const novo = anti(src.slice(t.s, t.e), R);
        if (novo !== src.slice(t.s, t.e)) { out += src.slice(last, t.s) + novo; last = t.e; }
      } else if (t.t === 'start' && t.name === 'img' && b) {
        const a = t.attrs.find(x => x.lname === 'src' && x.vs >= 0);
        if (!a || /^\s*(%%|data:)/i.test(a.value)) continue;
        const f = fileOf(a.value.trim());
        if (!f || (o.onlySuf && !R.sufRe.test(f))) continue;
        out += src.slice(last, a.vs) + b + f; last = a.ve;
      }
    }
    let h = out + src.slice(last);
    const decl = [];
    for (const n in (o.map || {})) {
      const { amp, attr } = o.map[n];
      if (!amp || !amp.trim()) continue;
      h = h.replace(new RegExp('%%' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '%%', 'g'), '%%=v(' + amp.trim() + ')=%%');
      decl.push('  SET ' + amp.trim() + ' = AttributeValue("' + ((attr || '').trim() || n) + '")');
    }
    return decl.length ? '%%[\n' + decl.join('\n') + '\n]%%\n' + h : h;
  }

  WB.audit = { analyze, compile, anti, fileOf };
})(window.WB = window.WB || {});
