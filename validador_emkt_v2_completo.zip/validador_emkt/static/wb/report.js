/* report.js — Relatório de homologação (texto e HTML para imprimir em PDF). */
(function (WB) {
  'use strict';
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const NOME = { bloq: 'Bloqueador', alerta: 'Alerta', ok: 'OK' };
  const STATUS = { reprovado: 'REPROVADO', alertas: 'APROVADO COM ALERTAS', aprovado: 'APROVADO' };
  const LINK_ST = { ok: 'OK', vazio: 'Vazio', hash: 'Apenas #', js: 'javascript:' };

  const linhas = locs => {
    const ls = [...new Set((locs || []).filter(l => l && l.ln).map(l => l.ln))];
    return ls.length ? (ls.length > 1 ? 'linhas ' : 'linha ') + ls.slice(0, 40).join(', ') + (ls.length > 40 ? ` e mais ${ls.length - 40}` : '') : '';
  };
  const data = d => d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const kb = A => A.kb.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' KB';
  const resumo = A => STATUS[A.status] + (A.bloq ? ` – ${A.bloq} bloqueador(es)` : '') + (A.alerta ? `${A.bloq ? ',' : ' –'} ${A.alerta} alerta(s)` : '');

  function texto(A, m) {
    const L = [], pad = (k, v) => L.push((k + ':').padEnd(14) + (v || '—'));
    L.push('RELATÓRIO DE HOMOLOGAÇÃO – SFMC WORKBENCH', '='.repeat(48));
    pad('Campanha', m.campanha); pad('Chamado', m.chamado); pad('Responsável', m.responsavel);
    pad('Gerado em', data(m.geradoEm));
    pad('Arquivo', m.arquivo || 'HTML colado na ferramenta');
    pad('Tamanho', `${kb(A)}, ${A.linhas} linhas`);
    pad(m.hashAlg, m.hash);
    pad('Regras', `${m.regras.fonte}${m.regras.personalizada ? ' + ajustes locais' : ''} (assinatura ${m.regras.assinatura})`);
    L.push('', 'RESULTADO: ' + resumo(A), '');
    L.push(`Imagens: ${A.imgs.length}   Links: ${A.links.length}   Variáveis: ${Object.keys(A.vars).length}   Domínios em texto: ${A.dn}`, '');

    for (const nv of ['bloq', 'alerta', 'ok']) {
      const itens = A.ck.filter(c => c.l === nv);
      if (!itens.length) continue;
      L.push({ bloq: 'BLOQUEADORES', alerta: 'ALERTAS', ok: 'APROVADOS' }[nv], '-'.repeat(48));
      itens.forEach(c => {
        L.push(`[${NOME[nv]}] ${c.t}`, `    ${c.d}`);
        const ls = linhas(c.locs); if (ls && nv !== 'ok') L.push(`    Onde: ${ls}`);
      });
      L.push('');
    }
    if (A.links.length) {
      L.push(`LINKS (${A.links.length})`, '-'.repeat(48));
      A.links.forEach((l, i) => L.push(`${String(i + 1).padStart(3)}  L${String(l.loc?.ln ?? '?').padEnd(5)} ${LINK_ST[l.st].padEnd(11)} ${l.href ?? '(sem href)'}`));
      L.push('');
    }
    if (A.imgs.length) {
      L.push(`IMAGENS (${A.imgs.length})`, '-'.repeat(48));
      A.imgs.forEach(i => L.push(`  L${String(i.loc?.ln ?? '?').padEnd(5)} ${i.file || '(sem src)'}  |  alt: ${i.alt === null ? 'AUSENTE' : i.alt || '(vazio)'}`));
      L.push('');
    }
    const vs = Object.keys(A.vars);
    if (vs.length) {
      L.push('VARIÁVEIS', '-'.repeat(48));
      vs.forEach(n => { const mp = (m.map || {})[n]; L.push(`  %%${n}%%  ${A.vars[n].n} uso(s)` + (mp && mp.amp ? `  ->  SET ${mp.amp} = AttributeValue("${mp.attr || n}")` : '  (mantida como %%' + n + '%%)')); });
      L.push('');
    }
    L.push('Relatório gerado automaticamente pelo SFMC Workbench. Confira o resultado no preview antes de publicar.');
    return L.join('\r\n');
  }

  function html(A, m) {
    const cor = { reprovado: '#b8102c', alertas: '#8a5a00', aprovado: '#12703a' }[A.status];
    const linha = (k, v) => `<tr><th>${k}</th><td>${esc(v || '—')}</td></tr>`;
    const itens = A.ck.map(c => `<li class="${c.l}"><b>${NOME[c.l]}: ${esc(c.t)}</b><span>${esc(c.d)}</span>${c.l !== 'ok' && linhas(c.locs) ? `<em>Onde: ${esc(linhas(c.locs))}</em>` : ''}</li>`).join('');
    const lk = A.links.map((l, i) => `<tr><td>${i + 1}</td><td>${l.loc?.ln ?? ''}</td><td class="m">${esc(l.href ?? '(sem href)')}</td><td>${LINK_ST[l.st]}</td></tr>`).join('');
    const im = A.imgs.map(i => `<tr><td>${i.loc?.ln ?? ''}</td><td class="m">${esc(i.file || '(sem src)')}</td><td>${i.alt === null ? '<b style="color:#b8102c">ausente</b>' : esc(i.alt || '(vazio)')}</td></tr>`).join('');
    const titulo = 'Homologacao_' + String(m.campanha || m.arquivo || 'email').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_').slice(0, 50) + '_' + m.geradoEm.toLocaleDateString('pt-BR').split('/').reverse().join('-');
    return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>
@page{size:A4;margin:14mm}
body{font:11pt/1.45 "IBM Plex Sans",Arial,sans-serif;color:#14202e;margin:0}
h1{font-size:16pt;margin:0 0 2mm}h2{font-size:12pt;margin:7mm 0 2mm;border-bottom:1px solid #d6dde7;padding-bottom:1mm}
.st{display:inline-block;padding:2mm 4mm;border:1.5px solid ${cor};color:${cor};font-weight:600;border-radius:2mm;margin:2mm 0 4mm}
table{border-collapse:collapse;width:100%;font-size:9.5pt}th,td{text-align:left;padding:1.2mm 2mm;border-bottom:1px solid #e3e8ef;vertical-align:top}
.meta th{width:32mm;color:#5b6b7e;font-weight:500}.m{font-family:"IBM Plex Mono",Consolas,monospace;font-size:8.5pt;word-break:break-all}
ul{list-style:none;padding:0;margin:0}li{border-left:4px solid;padding:1.5mm 3mm;margin:0 0 2mm;break-inside:avoid}
li b{display:block}li span{display:block;color:#3c4a5b}li em{display:block;font-style:normal;font-size:9pt;color:#5b6b7e}
li.bloq{border-color:#b8102c}li.bloq b{color:#b8102c}li.alerta{border-color:#c48a00}li.alerta b{color:#8a5a00}li.ok{border-color:#12703a}li.ok b{color:#12703a}
.kp{color:#5b6b7e}footer{margin-top:8mm;font-size:8.5pt;color:#5b6b7e}
</style></head><body>
<h1>Relatório de homologação</h1>
<div class="st">${esc(resumo(A))}</div>
<table class="meta">${linha('Campanha', m.campanha)}${linha('Chamado', m.chamado)}${linha('Responsável', m.responsavel)}${linha('Gerado em', data(m.geradoEm))}${linha('Arquivo', m.arquivo || 'HTML colado na ferramenta')}${linha('Tamanho', `${kb(A)}, ${A.linhas} linhas`)}${linha(m.hashAlg, m.hash)}${linha('Regras', `${m.regras.fonte}${m.regras.personalizada ? ' + ajustes locais' : ''} (assinatura ${m.regras.assinatura})`)}</table>
<p class="kp">Imagens: ${A.imgs.length} &nbsp; Links: ${A.links.length} &nbsp; Variáveis: ${Object.keys(A.vars).length} &nbsp; Domínios em texto: ${A.dn}</p>
<h2>Quality Gate</h2><ul>${itens}</ul>
${lk ? `<h2>Links (${A.links.length})</h2><table><thead><tr><th>#</th><th>Linha</th><th>href</th><th>Status</th></tr></thead><tbody>${lk}</tbody></table>` : ''}
${im ? `<h2>Imagens (${A.imgs.length})</h2><table><thead><tr><th>Linha</th><th>Arquivo</th><th>Alt</th></tr></thead><tbody>${im}</tbody></table>` : ''}
<footer>Relatório gerado automaticamente pelo SFMC Workbench. Confira o resultado no preview antes de publicar.</footer>
</body></html>`;
  }

  async function hash(src) {
    try {
      if (window.crypto && crypto.subtle) {
        const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(src));
        return { alg: 'SHA-256', valor: [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('') };
      }
    } catch (e) { /* cai no FNV */ }
    let h = 0x811c9dc5;
    for (let i = 0; i < src.length; i++) { h ^= src.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return { alg: 'FNV-1a', valor: (h >>> 0).toString(16).padStart(8, '0') };
  }

  WB.report = { texto, html, hash, resumo };
})(window.WB = window.WB || {});
