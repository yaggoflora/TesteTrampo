/* rules.js — Regras do Quality Gate.
 *
 * Ordem de prioridade:
 *   1. Ajustes salvos neste navegador (painel Regras ou JSON importado)
 *   2. regras-time.js (arquivo compartilhado do time, opcional)
 *   3. Padrão embutido abaixo
 */
(function (WB) {
  'use strict';

  const NIVEIS = ['bloq', 'alerta', 'off'];
  const NOME_NIVEL = { bloq: 'Bloqueador', alerta: 'Alerta', off: 'Desligada' };
  const CHAVE = 'sfmcwb-regras';

  const CATALOGO = [
    { id: 'viewEmailUrl', nome: 'Link “ver no navegador” (%%view_email_url%%)', padrao: 'bloq' },
    { id: 'redirectTo', nome: 'Chamada de rastreamento RedirectTo(@Link_Tag)', padrao: 'bloq' },
    { id: 'descadastroAusente', nome: 'Link de descadastro presente', padrao: 'bloq' },
    { id: 'descadastroPadrao', nome: 'Descadastro só com a variável de sistema', padrao: 'alerta' },
    { id: 'hrefVazio', nome: 'Links com href vazio ou sem href', padrao: 'bloq' },
    { id: 'hrefHash', nome: 'Links apontando só para “#”', padrao: 'alerta' },
    { id: 'hrefJs', nome: 'Links com javascript:', padrao: 'bloq' },
    { id: 'linkSemRedirect', nome: 'Links http(s) diretos, sem a chamada de rastreamento', padrao: 'off' },
    { id: 'linkAninhado', nome: 'Link dentro de outro link', padrao: 'alerta' },
    { id: 'imgSemAlt', nome: 'Imagens sem atributo alt', padrao: 'alerta' },
    { id: 'imgRelativa', nome: 'Imagens com src relativo', padrao: 'alerta' },
    { id: 'scriptTag', nome: 'Tag <script> (exceto AMPScript)', padrao: 'bloq' },
    { id: 'ampNaoFechado', nome: 'Bloco AMPScript sem fechamento', padrao: 'bloq' },
    { id: 'doctype', nome: 'DOCTYPE presente', padrao: 'alerta' },
    { id: 'viewport', nome: 'Meta viewport presente', padrao: 'alerta' },
    { id: 'tamanho', nome: 'Tamanho do HTML (corte do Gmail)', padrao: 'alerta' },
    { id: 'dominioTexto', nome: 'Domínios em texto puro', padrao: 'alerta' }
  ];

  const PADRAO = {
    versao: 1,
    niveis: Object.fromEntries(CATALOGO.map(r => [r.id, r.padrao])),
    parametros: {
      chamadaRastreamento: 'RedirectTo\\(\\s*@Link_Tag\\s*\\)',
      variaveisDescadastro: ['unsub_center_url', 'unsub_url', 'profile_center_url', 'subscription_center_url'],
      variaveisSistema: ['view_email_url', 'unsub_center_url', 'unsub_url', 'profile_center_url', 'subscription_center_url', 'emailname_', 'email_name_', 'jobid', 'listid', 'batchid', 'memberid', 'subscriberid', 'emailaddr', 'xtmonth', 'xtmonthnumeric', 'xtday', 'xtyear', 'replyname', 'replyemailaddress', 'fromname', 'fromaddress', 'member_busname', 'member_addr', 'member_city', 'member_state', 'member_postalcode', 'member_country'],
      dominios: ['com.br', 'gov.br', 'com', 'net', 'org', 'br', 'io', 'app', 'dev', 'info', 'biz', 'co'],
      limiteKB: 102,
      sufixoImagem: '_\\d{2,}\\.(jpe?g|png|gif|webp)$'
    }
  };

  const clone = o => JSON.parse(JSON.stringify(o));
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const lista = v => (Array.isArray(v) ? v : typeof v === 'string' ? v.split(/[\n,;]+/) : [])
    .map(x => String(x).trim()).filter(Boolean);

  /** Base do time: regras-time.js, se existir, senão o padrão embutido. */
  function base() {
    const t = window.WB_REGRAS_TIME;
    return t && typeof t === 'object' ? normalizar(t, clone(PADRAO)).cfg : clone(PADRAO);
  }

  /** Completa e valida uma configuração. Devolve { cfg, erros }. */
  function normalizar(entrada, ref) {
    ref = ref || clone(PADRAO);
    const erros = [];
    const cfg = clone(ref);
    if (!entrada || typeof entrada !== 'object') return { cfg, erros: ['O conteúdo não é um objeto JSON.'] };

    const nv = entrada.niveis || {};
    for (const r of CATALOGO) {
      if (nv[r.id] === undefined) continue;
      if (NIVEIS.includes(nv[r.id])) cfg.niveis[r.id] = nv[r.id];
      else erros.push(`Nível inválido em "${r.id}": use bloq, alerta ou off.`);
    }
    for (const k of Object.keys(nv)) if (!CATALOGO.some(r => r.id === k)) erros.push(`Regra desconhecida ignorada: "${k}".`);

    const p = entrada.parametros || {};
    const pr = cfg.parametros;
    for (const k of ['chamadaRastreamento', 'sufixoImagem']) {
      if (p[k] === undefined) continue;
      try { new RegExp(String(p[k])); pr[k] = String(p[k]); }
      catch (e) { erros.push(`Expressão regular inválida em "${k}": ${e.message}`); }
    }
    for (const k of ['variaveisDescadastro', 'variaveisSistema', 'dominios']) {
      if (p[k] === undefined) continue;
      const v = lista(p[k]);
      if (k === 'dominios' && v.some(d => !/^[a-z0-9-]+(\.[a-z0-9-]+)*$/i.test(d))) erros.push('"dominios": use só letras, números, hífen e ponto (ex.: com.br).');
      else if (k !== 'dominios' && v.some(d => !/^\w+$/.test(d))) erros.push(`"${k}": use só o nome da variável, sem %%.`);
      else pr[k] = v;
    }
    if (p.limiteKB !== undefined) {
      const n = Number(p.limiteKB);
      if (Number.isFinite(n) && n > 0) pr.limiteKB = n; else erros.push('limiteKB deve ser um número maior que zero.');
    }
    return { cfg, erros };
  }

  /** Transforma a configuração em objetos prontos para a auditoria. */
  function compilar(cfg) {
    const p = cfg.parametros;
    const tlds = [...p.dominios].sort((a, b) => b.length - a.length).map(reEsc).join('|') || '(?!)';
    const sys = new Set(p.variaveisSistema.map(s => s.toLowerCase()));
    return {
      cfg,
      nivel: id => cfg.niveis[id] || 'off',
      chamadaRe: new RegExp(p.chamadaRastreamento, 'i'),
      chamadaCompletaRe: new RegExp('%%=\\s*' + p.chamadaRastreamento + '\\s*=%%', 'i'),
      unsubRe: new RegExp('%%(' + (p.variaveisDescadastro.map(reEsc).join('|') || '(?!)') + ')%%', 'i'),
      isSys: n => n[0] === '_' || sys.has(n.toLowerCase()),
      domRe: () => new RegExp('(?:https?:\\/\\/)?(?:www\\.)?(?:[a-z0-9-]+\\.)+(?:' + tlds + ')\\b(?:\\/[^\\s<"\']*)?', 'gi'),
      sufRe: new RegExp(p.sufixoImagem, 'i'),
      limiteKB: p.limiteKB
    };
  }

  function carregar() {
    const b = base();
    try {
      const s = localStorage.getItem(CHAVE);
      if (s) return { cfg: normalizar(JSON.parse(s), b).cfg, personalizada: true };
    } catch (e) { /* armazenamento indisponível */ }
    return { cfg: b, personalizada: false };
  }
  function salvar(cfg) {
    try { localStorage.setItem(CHAVE, JSON.stringify(cfg)); return true; } catch (e) { return false; }
  }
  function limpar() { try { localStorage.removeItem(CHAVE); } catch (e) { /* ok */ } }

  /** Assinatura curta para o relatório (identifica a versão das regras usada). */
  function assinatura(cfg) {
    const s = JSON.stringify(cfg);
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  WB.rules = { CATALOGO, PADRAO, NIVEIS, NOME_NIVEL, base, normalizar, compilar, carregar, salvar, limpar, assinatura, lista, clone };
})(window.WB = window.WB || {});
