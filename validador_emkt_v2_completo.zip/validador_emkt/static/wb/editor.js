/* editor.js — Editor de código com CodeMirror 5 (pasta vendor/) e destaque de AMPScript.
 * Se o CodeMirror não carregar, cai para um textarea com numeração de linhas.
 *
 * API: get(), set(texto, {cursor}), ir(s, e), marcar(locs), proximo(dir), refresh(), focus()
 */
(function (WB) {
  'use strict';
  const CM = window.CodeMirror;

  const FRASES = {
    'Search:': 'Buscar:', '(Use /re/ syntax for regexp search)': '(use /regex/ para expressão regular)',
    'Replace:': 'Substituir:', 'Replace all:': 'Substituir todos:', 'Replace with:': 'Substituir por:', 'With:': 'Por:',
    'Replace?': 'Substituir?', 'Yes': 'Sim', 'No': 'Não', 'All': 'Todos', 'Stop': 'Parar',
    'Jump to line:': 'Ir para a linha:', '(Use line:column or scroll% syntax)': '(use linha:coluna)'
  };

  if (CM && !CM.modes['ampscript-html']) {
    const KW = /^(set|var|if|then|else|elseif|endif|for|to|downto|do|next|and|or|not)\b/i;
    CM.defineMode('ampscript-html', config => CM.overlayMode(CM.getMode(config, 'htmlmixed'), {
      startState: () => ({ blk: 0, str: '', cmt: false }),
      copyState: s => ({ blk: s.blk, str: s.str, cmt: s.cmt }),
      token(stream, st) {
        if (!st.blk) {
          if (stream.match('%%[')) { st.blk = 1; return 'amp-delim'; }
          if (stream.match('%%=')) { st.blk = 2; return 'amp-delim'; }
          if (stream.match(/^%%[A-Za-z_]\w*%%/)) return 'amp-pvar';
          stream.next();
          while (!stream.eol() && stream.peek() !== '%') stream.next();
          return null;
        }
        if (st.cmt) { if (stream.skipTo('*/')) { stream.match('*/'); st.cmt = false; } else stream.skipToEnd(); return 'amp-comment'; }
        if (st.str) {
          while (!stream.eol()) { if (stream.next() === st.str) { st.str = ''; break; } }
          return 'amp-string';
        }
        if ((st.blk === 1 && stream.match(']%%')) || (st.blk === 2 && stream.match('=%%'))) { st.blk = 0; return 'amp-delim'; }
        if (stream.eatSpace()) return 'amp';
        if (stream.match('/*')) { st.cmt = true; return 'amp-comment'; }
        const c = stream.peek();
        if (c === '"' || c === "'") { stream.next(); st.str = c; while (!stream.eol()) { if (stream.next() === c) { st.str = ''; break; } } return 'amp-string'; }
        if (stream.match(/^@\w+/)) return 'amp-var';
        if (stream.match(KW)) return 'amp-keyword';
        if (stream.match(/^[A-Za-z_]\w*(?=\s*\()/)) return 'amp-fn';
        if (stream.match(/^-?\d+(\.\d+)?/)) return 'amp-number';
        stream.next();
        return 'amp';
      }
    }, false));
  }

  function criarCM(host, o) {
    const cm = CM(host, {
      value: '', mode: 'ampscript-html', theme: 'wb', lineNumbers: true, lineWrapping: false,
      gutters: ['wb-alertas', 'CodeMirror-linenumbers'], matchTags: { bothTags: true }, styleActiveLine: true,
      indentUnit: 2, tabSize: 2, dragDrop: false, undoDepth: 1, phrases: FRASES,
      readOnly: !!o.readOnly, screenReaderLabel: o.rotulo || 'Editor de código', placeholder: o.placeholder || '',
      extraKeys: Object.assign({
        'Ctrl-F': 'findPersistent', 'Cmd-F': 'findPersistent', 'Alt-G': 'jumpToLine',
        'Ctrl-Z': () => o.desfazer && o.desfazer(), 'Cmd-Z': () => o.desfazer && o.desfazer(),
        'Ctrl-Y': () => o.refazer && o.refazer(), 'Shift-Ctrl-Z': () => o.refazer && o.refazer(), 'Shift-Cmd-Z': () => o.refazer && o.refazer(),
        'F8': () => api.proximo(1), 'Shift-F8': () => api.proximo(-1)
      }, o.teclas || {})
    });
    let interno = false, flash = null, locs = [], sbB = null, sbA = null;
    cm.on('changes', (c, chs) => { if (!interno && chs.some(x => x.origin !== 'wbset')) o.onChange && o.onChange(); });
    cm.on('gutterClick', (c, line, gutter) => {
      if (gutter !== 'wb-alertas') return;
      const l = locs.find(x => cm.posFromIndex(x.s).line === line);
      if (l) api.ir(l.s, l.e);
    });

    const api = {
      cm,
      get: () => cm.getValue(),
      set(texto, op) {
        const atual = cm.getValue();
        if (atual === texto) return;
        let a = 0; const la = atual.length, lb = texto.length;
        while (a < la && a < lb && atual.charCodeAt(a) === texto.charCodeAt(a)) a++;
        let b = 0;
        while (b < la - a && b < lb - a && atual.charCodeAt(la - 1 - b) === texto.charCodeAt(lb - 1 - b)) b++;
        interno = true;
        cm.operation(() => {
          cm.replaceRange(texto.slice(a, lb - b), cm.posFromIndex(a), cm.posFromIndex(la - b), 'wbset');
          if (op && op.cursor) { const p = cm.posFromIndex(a + (lb - b - a)); cm.setCursor(p); cm.scrollIntoView(p, 80); }
          if (op && op.topo) { cm.setCursor({ line: 0, ch: 0 }); cm.scrollTo(0, 0); }
        });
        interno = false;
      },
      ir(s, e) {
        const de = cm.posFromIndex(s), ate = cm.posFromIndex(Math.max(e, s));
        cm.focus();
        cm.setSelection(de, ate);
        cm.scrollIntoView({ from: de, to: ate }, Math.round(cm.getScrollInfo().clientHeight / 3));
        if (flash) flash.clear();
        flash = cm.markText(de, e > s ? ate : { line: de.line, ch: de.ch + 1 }, { className: 'wb-flash' });
        const f = flash; setTimeout(() => { f.clear(); if (flash === f) flash = null; }, 2400);
      },
      /** locs: [{ s, e, nivel, titulo }] */
      marcar(lista) {
        locs = [...lista].sort((a, b) => a.s - b.s);
        cm.operation(() => {
          cm.clearGutter('wb-alertas');
          const porLinha = new Map();
          for (const l of locs) {
            const ln = cm.posFromIndex(l.s).line, cur = porLinha.get(ln);
            if (!cur) porLinha.set(ln, { nivel: l.nivel, titulos: [l.titulo] });
            else { if (l.nivel === 'bloq') cur.nivel = 'bloq'; if (!cur.titulos.includes(l.titulo)) cur.titulos.push(l.titulo); }
          }
          porLinha.forEach((v, ln) => {
            const d = document.createElement('div');
            d.className = 'wb-dot ' + v.nivel;
            d.title = v.titulos.join('\n') + '\n(clique para selecionar)';
            cm.setGutterMarker(ln, 'wb-alertas', d);
          });
        });
        if (cm.annotateScrollbar) {
          sbB = sbB || cm.annotateScrollbar('wb-sb-bloq');
          sbA = sbA || cm.annotateScrollbar('wb-sb-alerta');
          const r = n => locs.filter(l => l.nivel === n).map(l => ({ from: cm.posFromIndex(l.s), to: cm.posFromIndex(Math.max(l.e, l.s)) }));
          sbB.update(r('bloq')); sbA.update(r('alerta'));
        }
      },
      proximo(dir) {
        if (!locs.length) return false;
        const cur = cm.indexFromPos(cm.getCursor(dir > 0 ? 'to' : 'from'));
        let alvo = dir > 0 ? locs.find(l => l.s >= cur && !(l.s === cur && cm.somethingSelected())) : [...locs].reverse().find(l => l.s < cur);
        if (!alvo) alvo = dir > 0 ? locs[0] : locs[locs.length - 1];
        api.ir(alvo.s, alvo.e);
        return true;
      },
      refresh: () => cm.refresh(),
      focus: () => cm.focus()
    };
    return api;
  }

  /** Alternativa sem CodeMirror: textarea com numeração de linhas. */
  function criarTextarea(host, o) {
    host.classList.add('ide');
    host.innerHTML = '<pre class="gut" aria-hidden="true">1</pre><textarea spellcheck="false" wrap="off"></textarea>';
    const ta = host.querySelector('textarea'), gut = host.querySelector('.gut');
    ta.setAttribute('aria-label', o.rotulo || 'Editor de código');
    if (o.readOnly) ta.readOnly = true;
    if (o.placeholder) ta.placeholder = o.placeholder;
    let locs = [];
    const numerar = () => { gut.textContent = Array.from({ length: Math.max(1, ta.value.split('\n').length) }, (_, i) => i + 1).join('\n'); };
    ta.addEventListener('input', () => { numerar(); o.onChange && o.onChange(); });
    ta.addEventListener('scroll', () => { gut.scrollTop = ta.scrollTop; });
    ta.addEventListener('keydown', e => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); o.desfazer && o.desfazer(); }
      else if (mod && (e.key.toLowerCase() === 'y' || (e.key.toLowerCase() === 'z' && e.shiftKey))) { e.preventDefault(); o.refazer && o.refazer(); }
      else if (e.key === 'F8') { e.preventDefault(); api.proximo(e.shiftKey ? -1 : 1); }
    });
    const api = {
      cm: null,
      get: () => ta.value,
      set(t, op) { if (ta.value === t) return; ta.value = t; numerar(); if (op && op.cursor) ta.setSelectionRange(t.length, t.length); if (op && op.topo) { ta.setSelectionRange(0, 0); ta.scrollTop = 0; } },
      ir(s, e) {
        ta.focus(); ta.setSelectionRange(s, Math.max(s, e));
        const linha = ta.value.slice(0, s).split('\n').length - 1;
        ta.scrollTop = Math.max(0, linha * parseFloat(getComputedStyle(ta).lineHeight || 19) - ta.clientHeight / 3);
      },
      marcar(l) { locs = [...l].sort((a, b) => a.s - b.s); },
      proximo(dir) {
        if (!locs.length) return false;
        const cur = dir > 0 ? ta.selectionEnd : ta.selectionStart;
        const alvo = (dir > 0 ? locs.find(l => l.s > cur) : [...locs].reverse().find(l => l.s < cur)) || (dir > 0 ? locs[0] : locs[locs.length - 1]);
        api.ir(alvo.s, alvo.e); return true;
      },
      refresh() {}, focus: () => ta.focus()
    };
    return api;
  }

  WB.editor = {
    disponivel: !!CM,
    criar: (host, o) => (CM ? criarCM : criarTextarea)(host, o || {})
  };
})(window.WB = window.WB || {});
