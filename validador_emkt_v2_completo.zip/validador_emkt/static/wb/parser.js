/* parser.js — Leitura de HTML tolerante e ciente de AMPScript.
 *
 * Duas camadas:
 * 1. tokenize(src): percorre o HTML original e devolve tokens com a posição exata
 *    no texto (início/fim, atributos, valores). Entende comentários, <style>/<script>,
 *    aspas com ">" dentro e blocos %%[ ]%% / %%= =%% — inclusive dentro de atributos.
 * 2. dom(src): monta uma cópia "de auditoria" (AMPScript trocado por marcadores e cada
 *    tag marcada com a posição de origem) e entrega ao DOMParser do navegador.
 *    O HTML original nunca é alterado por aqui.
 */
(function (WB) {
  'use strict';

  const RAW = new Set(['script', 'style', 'textarea', 'title', 'xmp']);
  const AMP_RE = /%%\[[\s\S]*?\]%%|%%=[\s\S]*?=%%/g;
  const PH_RE = /\uE000(\d+)\uE001/g;
  const isLetter = c => (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
  const isSpace = c => c === ' ' || c === '\n' || c === '\t' || c === '\r' || c === '\f';

  /** Fim de um trecho AMPScript iniciado em i (ou -1 se não fechar). */
  function ampEnd(src, i) {
    const block = src[i + 2] === '[';
    const k = src.indexOf(block ? ']%%' : '=%%', i + 3);
    return k < 0 ? -1 : k + 3;
  }
  const ampAt = (src, i) => src[i] === '%' && src[i + 1] === '%' && (src[i + 2] === '[' || src[i + 2] === '=');

  function readTag(src, i, errors) {
    const n = src.length;
    let j = i + 1;
    while (j < n && !isSpace(src[j]) && src[j] !== '>' && src[j] !== '/') j++;
    const tag = { t: 'start', s: i, e: n, name: src.slice(i + 1, j).toLowerCase(), ne: j, attrs: [], selfClose: false };
    while (j < n) {
      while (j < n && isSpace(src[j])) j++;
      if (j >= n) break;
      const c = src[j];
      if (c === '>') { tag.e = j + 1; return tag; }
      if (c === '/' && src[j + 1] === '>') { tag.selfClose = true; tag.e = j + 2; return tag; }
      if (c === '/') { j++; continue; }
      if (ampAt(src, j)) { const k = ampEnd(src, j); if (k < 0) { errors.push({ tipo: 'ampAberto', s: j, e: j + 3 }); j += 3; } else j = k; continue; }
      const ns = j;
      while (j < n && !isSpace(src[j]) && src[j] !== '=' && src[j] !== '>' && !(src[j] === '/' && src[j + 1] === '>')) j++;
      if (j === ns) { j++; continue; }
      const a = { name: src.slice(ns, j), lname: src.slice(ns, j).toLowerCase(), ns, ne: j, value: null, vs: -1, ve: -1, ae: j, q: '' };
      let k = j;
      while (k < n && isSpace(src[k])) k++;
      if (src[k] === '=') {
        k++;
        while (k < n && isSpace(src[k])) k++;
        const q = src[k];
        if (q === '"' || q === "'") {
          a.q = q; a.vs = k + 1; k = a.vs;
          while (k < n && src[k] !== q) {
            if (ampAt(src, k)) { const m = ampEnd(src, k); if (m < 0) { errors.push({ tipo: 'ampAberto', s: k, e: k + 3 }); k += 3; } else k = m; } else k++;
          }
          a.ve = Math.min(k, n); a.ae = Math.min(k + 1, n); j = a.ae;
        } else {
          a.vs = k;
          while (k < n && !isSpace(src[k]) && src[k] !== '>') {
            if (ampAt(src, k)) { const m = ampEnd(src, k); if (m < 0) { k += 3; } else k = m; } else k++;
          }
          a.ve = k; a.ae = k; j = k;
        }
        a.value = src.slice(a.vs, a.ve);
      }
      tag.attrs.push(a);
    }
    tag.e = n;
    errors.push({ tipo: 'tagAberta', s: i, e: Math.min(i + 40, n) });
    return tag;
  }

  /**
   * Tokens: text | start | end | comment | decl | amp | raw.
   * Cada token tem s/e (posições no texto original).
   */
  function tokenize(src) {
    const n = src.length, tokens = [], errors = [];
    let i = 0, ts = -1;
    const flush = () => { if (ts >= 0 && ts < i) tokens.push({ t: 'text', s: ts, e: i }); ts = -1; };
    const NEXT = /<|%%[\[=]/g;

    while (i < n) {
      const c = src[i];
      if (ampAt(src, i)) {
        const e = ampEnd(src, i);
        if (e < 0) {
          errors.push({ tipo: 'ampAberto', s: i, e: i + 3 });
        } else {
          const block = src[i + 2] === '[';
          const inner = src.slice(i + 3, e - 3);
          if (inner.includes(block ? '%%[' : '%%=')) errors.push({ tipo: 'ampAberto', s: i, e: i + 3 });
          flush();
          tokens.push({ t: 'amp', s: i, e, block });
          i = e; continue;
        }
      } else if (c === '<') {
        const d = src[i + 1];
        if (src.startsWith('<!--', i)) {
          flush();
          const k = src.indexOf('-->', i + 4), e = k < 0 ? n : k + 3;
          tokens.push({ t: 'comment', s: i, e, cond: /^<!--\[if/i.test(src.slice(i, i + 10)) });
          i = e; continue;
        }
        if (d === '!' || d === '?') {
          flush();
          const k = src.indexOf('>', i), e = k < 0 ? n : k + 1;
          tokens.push({ t: 'decl', s: i, e });
          i = e; continue;
        }
        if (d === '/' && isLetter(src[i + 2] || '')) {
          flush();
          let j = i + 2;
          while (j < n && !isSpace(src[j]) && src[j] !== '>' && src[j] !== '/') j++;
          const k = src.indexOf('>', j), e = k < 0 ? n : k + 1;
          tokens.push({ t: 'end', s: i, e, name: src.slice(i + 2, j).toLowerCase() });
          i = e; continue;
        }
        if (isLetter(d || '')) {
          flush();
          const tag = readTag(src, i, errors);
          tokens.push(tag);
          i = tag.e;
          if (RAW.has(tag.name) && !tag.selfClose && i < n) {
            const re = new RegExp('</' + tag.name + '(?=[\\s/>])', 'ig');
            re.lastIndex = i;
            const m = re.exec(src);
            const rs = i, re_ = m ? m.index : n;
            if (re_ > rs) tokens.push({ t: 'raw', s: rs, e: re_, parent: tag.name });
            i = re_;
            if (m) {
              const k = src.indexOf('>', m.index), e = k < 0 ? n : k + 1;
              tokens.push({ t: 'end', s: m.index, e, name: tag.name });
              i = e;
            }
          }
          continue;
        }
      }
      if (ts < 0) ts = i;
      NEXT.lastIndex = i + 1;
      const m = NEXT.exec(src);
      i = m ? m.index : n;
    }
    flush();
    return { tokens, errors };
  }

  /** Converte posição no texto em linha/coluna (1-based). */
  function lineIndex(src) {
    const starts = [0];
    for (let i = 0; i < src.length; i++) if (src.charCodeAt(i) === 10) starts.push(i + 1);
    const line = off => {
      let lo = 0, hi = starts.length - 1;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= off) lo = mid; else hi = mid - 1; }
      return lo + 1;
    };
    return { line, col: off => off - starts[line(off) - 1] + 1, total: starts.length };
  }

  /**
   * Monta a cópia de auditoria e passa pelo DOMParser.
   * - AMPScript vira \uE000n\uE001 (restaurado com restore()).
   * - Toda tag de abertura ganha data-wbo="posição no original".
   */
  function dom(src, tk) {
    tk = tk || tokenize(src);
    const amps = [];
    const ph = s => { amps.push(s); return '\uE000' + (amps.length - 1) + '\uE001'; };
    let out = '';
    for (const t of tk.tokens) {
      const raw = src.slice(t.s, t.e);
      if (t.t === 'amp') out += ph(raw);
      else if (t.t === 'start') out += '<' + t.name + ' data-wbo="' + t.s + '"' + src.slice(t.ne, t.e).replace(AMP_RE, ph);
      else if (t.t === 'raw' || t.t === 'text') out += raw.replace(AMP_RE, ph);
      else out += raw;
    }
    // Garante que trechos sem token (não deveria haver) não se percam
    const doc = new DOMParser().parseFromString(out, 'text/html');
    const restore = s => s == null ? s : String(s).replace(PH_RE, (m, k) => amps[+k] ?? '');
    const strip = s => String(s).replace(PH_RE, ' ');
    return { doc, amps, restore, strip, tk };
  }

  WB.parser = { tokenize, lineIndex, dom, RAW };
})(window.WB = window.WB || {});
