'use strict';
/**
 * Aplicação web (região 5 do script único em Python: as rotas do Flask), com o `http` nativo do Node.
 *
 * Mesmas rotas, mesmas respostas:
 *   GET  /                                       página (as duas abas)
 *   GET  /workbench/tests/  /validador/tests/    páginas de testes
 *   GET  /api/validador/testes                   roda os testes num processo à parte
 *   GET  /assets/<arquivo>                       CSS e JS do front (public/static)
 *   POST /api/conferir-upload                    confere o pacote enviado (JSON)
 *   POST /api/conferir-em-fluxo                  idem, um resultado por linha (NDJSON)
 *   GET  /relatorio/<id>                         relatório em HTML
 *   GET  /preview/<id>/peca | /arquivo/<...> | /imagem/<nome> | /conteudo-gerado.docx
 *   GET  /api/preview/<id>/leitura | /html | /conteudo
 *   GET  /api/status-ocr
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const cfg = require('./config');
const U = require('./lib/pyutil');
const { lerMultipart, ErroDeUpload } = require('./lib/multipart');
const { gerarDocx } = require('./lib/docxwriter');
const pacote = require('./validador/pacote');
const relatorio = require('./validador/relatorio');
const serializacao = require('./validador/serializacao');
const ocr = require('./validador/ocr');

const LIMITE_DO_ENVIO = (Number(process.env.MAX_UPLOAD_MB) > 0
  ? Number(process.env.MAX_UPLOAD_MB) : 300) * 1024 * 1024; // 300 MB por pacote

try { fs.mkdirSync(cfg.PASTA_RELATORIOS, { recursive: true }); } catch (e) { /* sem permissão: o erro aparece ao gravar */ }

// pastas temporárias criadas pelo upload, apagadas quando o programa fecha
// (e, no servidor, depois de HORAS_TEMPORARIAS horas; 0 desliga)
const _temporarias = [];

// id do relatório -> caminhos do pacote, para o preview lado a lado.
// Fica em memória de propósito: some quando o programa fecha, junto com as pastas temporárias do upload.
const _previews = {};

// ---------------------------------------------------------------- utilidades

const TIPOS = {
  '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.bmp': 'image/bmp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
};
const tipoDe = (caminho) => TIPOS[path.extname(caminho).toLowerCase()] || 'application/octet-stream';

function responder(res, status, corpo, tipo = 'text/plain; charset=utf-8', extras = {}) {
  if (res.headersSent) return;
  const dados = Buffer.isBuffer(corpo) ? corpo : Buffer.from(String(corpo), 'utf8');
  res.writeHead(status, { 'Content-Type': tipo, 'Content-Length': dados.length, ...extras });
  res.end(dados);
}

/** jsonify do Flask. */
function json(res, status, objeto, extras = {}) {
  responder(res, status, JSON.stringify(objeto), 'application/json; charset=utf-8', extras);
}

/** Texto como resposta HTTP. no-cache: ao trocar o arquivo, a tela já vem nova. */
function estatica(res, texto, tipo) {
  responder(res, 200, texto, tipo, { 'Cache-Control': 'no-cache' });
}

function naoEncontrado(res) { responder(res, 404, 'Não encontrado.'); }

function enviarArquivo(res, caminho, extras = {}) {
  let st;
  try { st = fs.statSync(caminho); } catch (e) { return naoEncontrado(res); }
  if (!st.isFile()) return naoEncontrado(res);
  res.writeHead(200, { 'Content-Type': tipoDe(caminho), 'Content-Length': st.size, ...extras });
  const leitura = fs.createReadStream(caminho);
  leitura.on('error', () => res.destroy());
  leitura.pipe(res);
}

/** str.isalnum() de um id: só letras e números (barra qualquer subida de pasta pelo endereço). */
const idValido = (id) => id.length > 0 && /^[\p{L}\p{N}]+$/u.test(id);

function lerPublico(...partes) {
  return fs.readFileSync(path.join(cfg.PASTA_PUBLICA, ...partes), 'utf8');
}

function regras_do_time() {
  // regras-time.js: o arquivo ao lado do programa, se existir; senão o embutido.
  const externo = path.join(cfg.PASTA_DO_SCRIPT, 'regras-time.js');
  try {
    if (fs.statSync(externo).isFile()) return fs.readFileSync(externo, 'utf8');
  } catch (e) { /* usa o embutido */ }
  return lerPublico('static', 'wb', 'regras-time.js');
}

// ------------------------------------------------------------- conferência

function nova_id() { return crypto.randomBytes(6).toString('hex'); } // uuid4().hex[:12]

function _leitura_da_peca(resultado) {
  /*
   * O que o sistema entendeu da peça, bloco a bloco: a fita de leitura crua, o texto do código e
   * o texto lido de cada imagem, na ordem em que o leitor de tela percorreria.
   */
  if (!resultado.leitura_html) return [];
  const blocos = [];
  for (const bloco of resultado.leitura_html.fita) {
    if (bloco.oculto) continue;
    blocos.push({
      tipo: bloco.tipo,
      origem: bloco.tipo === 'imagem' ? bloco.referencia : 'texto do código',
      texto: bloco.conteudo,
      confianca: U.pyRound(bloco.ocr_confianca || 0),
      aviso: bloco.ocr_aviso || bloco.ocr_erro || '',
      classificacao: bloco.classificacao,
      reordenado: Boolean(bloco.reordenado),
    });
  }
  return blocos;
}

function _registrar_preview(id_relatorio, resultado, comImagens) {
  if (!resultado.caminho_html) return;
  const p = {
    raiz: path.resolve(path.dirname(resultado.caminho_html)),
    html: path.resolve(resultado.caminho_html),
    paragrafos: resultado.leitura_conteudo ? resultado.leitura_conteudo.paragrafos : [],
    leitura: _leitura_da_peca(resultado),
    nome: resultado.nome_pasta,
  };
  if (comImagens) p.imagens = path.resolve(resultado.pasta_imagens || '');
  _previews[id_relatorio] = p;
}

async function _conferir(caminho_pasta, quebra = null, usar_ocr = true) {
  const resultado = await pacote.validar(caminho_pasta, { quebra, usar_ocr });
  const id_relatorio = nova_id();
  relatorio.gerar(resultado, path.join(cfg.PASTA_RELATORIOS, `${id_relatorio}.html`));
  _registrar_preview(id_relatorio, resultado, true);
  const dados = serializacao.para_json(resultado, id_relatorio);
  dados.tem_preview = id_relatorio in _previews;
  return dados;
}

// ---------------------------------------------------------------- upload

const MSG_SEM_PACOTE = 'Não encontrei nenhum pacote aqui. A pasta precisa conter o HTML da peça, '
  + 'os docx e as imagens — ou ser a pasta que guarda vários pacotes assim.';

/**
 * Recebe o multipart, grava os arquivos numa pasta temporária (preservando as subpastas que o
 * navegador manda no nome) e devolve onde está o pacote.
 */
async function receberPacote(req) {
  const destino = fs.mkdtempSync(path.join(os.tmpdir(), 'pacote_emkt_'));
  _temporarias.push({ pasta: destino, criado: Date.now() });
  let quantos = 0;
  let nome_arrastado = null;
  const base = path.resolve(destino);

  const { campos } = await lerMultipart(req, {
    limite: LIMITE_DO_ENVIO,
    destinoDoArquivo: (campo, nome) => {
      if (campo !== 'arquivos' || !nome) return null;
      quantos += 1;
      if (nome_arrastado === null) nome_arrastado = nome.replace(/\\/g, '/').split('/')[0];
      // o navegador manda o caminho relativo no lugar do nome, o que preserva a subpasta de imagens
      const partes = nome.replace(/\\/g, '/').split('/').filter((p) => !['', '.', '..'].includes(p));
      if (!partes.length) return null;
      const caminho = path.resolve(base, ...partes);
      if (!caminho.startsWith(base + path.sep)) return null;
      fs.mkdirSync(path.dirname(caminho), { recursive: true });
      return caminho;
    },
  });
  if (!quantos) return { vazio: true };

  // o navegador inclui a pasta raiz; entra nela quando é o único item
  const conteudo = fs.readdirSync(destino);
  let raiz = destino;
  if (conteudo.length === 1 && fs.statSync(path.join(destino, conteudo[0])).isDirectory()) {
    raiz = path.join(destino, conteudo[0]);
  }
  const usar_ocr = (campos.usar_ocr === undefined ? 'true' : campos.usar_ocr) === 'true';
  // o motor escolhido na tela vale para esta conferência
  ocr.forcar_motor(campos.motor || '');
  return { vazio: false, raiz, usar_ocr, nome_arrastado: nome_arrastado || '' };
}

async function conferir_upload(req, res) {
  let envio;
  try { envio = await receberPacote(req); } catch (e) {
    if (e instanceof ErroDeUpload) return json(res, e.status, { erro: e.message });
    throw e;
  }
  if (envio.vazio) return json(res, 400, { erro: 'Nenhum arquivo recebido.' });

  // O usuário arrasta o que tem na mão: pode ser um pacote ou a pasta que guarda vários.
  // Quem decide é a estrutura, não uma opção na tela.
  const pastas = pacote.localizar_pacotes(envio.raiz);
  if (!pastas.length) return json(res, 400, { erro: MSG_SEM_PACOTE });

  let resultados;
  try {
    resultados = [];
    for (const p of pastas) resultados.push(await _conferir(p, null, envio.usar_ocr));
  } catch (e) {
    return json(res, 500, { erro: `Falha ao conferir: ${e.message}` });
  }

  const em_lote = pastas.length > 1;
  for (const item of resultados) {
    item.em_lote = em_lote;
    if (!em_lote && envio.nome_arrastado) {
      // pacote único: o nome que vale é o da pasta que a pessoa arrastou
      item.nome_pasta = item.nome_pasta || envio.nome_arrastado;
    }
  }
  json(res, 200, {
    modo: em_lote ? 'lote' : 'unico',
    origem: envio.nome_arrastado || 'pacote enviado',
    total: resultados.length,
    resultados,
  });
}

/**
 * Mesma conferência, devolvendo cada pacote assim que fica pronto: uma linha de JSON por evento
 * (NDJSON), que o navegador lê conforme chega.
 */
async function conferir_em_fluxo(req, res) {
  let envio;
  try { envio = await receberPacote(req); } catch (e) {
    if (e instanceof ErroDeUpload) return json(res, e.status, { erro: e.message });
    throw e;
  }
  if (envio.vazio) return json(res, 400, { erro: 'Nenhum arquivo recebido.' });

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no', // nginx: não segurar a resposta até o fim
  });
  const enviar = (obj) => { if (!res.destroyed && !res.writableEnded) res.write(JSON.stringify(obj) + '\n'); };

  const pastas = pacote.localizar_pacotes(envio.raiz);
  if (!pastas.length) {
    enviar({ tipo: 'erro', erro: MSG_SEM_PACOTE });
    return res.end();
  }
  const em_lote = pastas.length > 1;
  enviar({
    tipo: 'inicio', total: pastas.length, modo: em_lote ? 'lote' : 'unico',
    origem: envio.nome_arrastado || 'pacote enviado',
    nomes: pastas.map((p) => path.basename(p)),
  });

  let posicao = 0;
  for (const caminho of pastas) {
    posicao += 1;
    if (res.destroyed) return; // a pessoa fechou a aba: não gasta OCR à toa
    const nome = path.basename(caminho);
    enviar({ tipo: 'andamento', posicao, nome });
    try {
      const resultado = await pacote.validar(caminho, { usar_ocr: envio.usar_ocr, ao_avancar: () => {} });
      const id_relatorio = nova_id();
      relatorio.gerar(resultado, path.join(cfg.PASTA_RELATORIOS, `${id_relatorio}.html`));
      _registrar_preview(id_relatorio, resultado, false);
      const dados = serializacao.para_json(resultado, id_relatorio);
      dados.tem_preview = id_relatorio in _previews;
      dados.em_lote = em_lote;
      if (!em_lote && envio.nome_arrastado) dados.nome_pasta = dados.nome_pasta || envio.nome_arrastado;
      enviar({ tipo: 'pacote', posicao, resultado: dados });
    } catch (e) {
      enviar({ tipo: 'falha', nome, erro: String(e && e.message || e) });
    }
  }
  enviar({ tipo: 'fim' });
  res.end();
}

// ---------------------------------------------------------------- testes

let _testes_em_andamento = false;
const MARCA_DO_RESULTADO = '@@RESULTADO-DOS-TESTES@@';

/**
 * Roda --testar em outro processo e devolve [relatório, erro].
 * Processo à parte porque o motor de teste troca o motor de leitura do módulo: no mesmo
 * processo isso atropelaria uma conferência em andamento.
 */
function rodar_testes_em_processo_separado() {
  return new Promise((resolver) => {
    const filho = spawn(process.execPath, [path.join(cfg.PASTA_DO_PROGRAMA, 'servidor.js'), '--testar', '--json'], {
      cwd: cfg.PASTA_DO_PROGRAMA,
      env: { ...process.env, ABRIR_NAVEGADOR: '0' },
    });
    let saida = ''; let erro = '';
    filho.stdout.setEncoding('utf8').on('data', (d) => { saida += d; });
    filho.stderr.setEncoding('utf8').on('data', (d) => { erro += d; });
    const limite = setTimeout(() => {
      filho.kill();
      resolver([null, 'Os testes passaram de 15 minutos e foram interrompidos.']);
    }, 900 * 1000);
    filho.on('close', () => {
      clearTimeout(limite);
      const linhas = saida.split(/\r?\n/).reverse();
      for (const linha of linhas) {
        if (linha.startsWith(MARCA_DO_RESULTADO)) {
          try { return resolver([JSON.parse(linha.slice(MARCA_DO_RESULTADO.length)), '']); } catch (e) { break; }
        }
      }
      const cauda = (erro.trim().split('\n').filter(Boolean).slice(-3));
      resolver([null, 'Não consegui rodar os testes: ' + (cauda.length ? cauda : ['sem mensagem']).join(' | ')]);
    });
    filho.on('error', (e) => { clearTimeout(limite); resolver([null, 'Não consegui rodar os testes: ' + e.message]); });
  });
}

// ---------------------------------------------------------------- preview

function _preview_ou_404(res, id) {
  if (!idValido(id) || !Object.prototype.hasOwnProperty.call(_previews, id)) { naoEncontrado(res); return null; }
  return _previews[id];
}

const _CP1252_INDEFINIDOS = new Set([0x81, 0x8d, 0x8f, 0x90, 0x9d]);
function decodificar_cp1252(bruto) {
  // bytes.decode("cp1252", errors="replace"): os 5 bytes sem uso viram U+FFFD
  let texto = new TextDecoder('windows-1252').decode(bruto);
  if (bruto.some((b) => _CP1252_INDEFINIDOS.has(b))) {
    texto = Array.from(bruto).map((b) => (_CP1252_INDEFINIDOS.has(b) ? '\ufffd'
      : new TextDecoder('windows-1252').decode(Uint8Array.of(b)))).join('');
  }
  return texto;
}

function preview_peca(res, id) {
  /*
   * Serve o HTML do pacote para o iframe do preview. O arquivo chama as imagens por caminho
   * relativo; a tag <base> injetada no topo faz todos caírem na rota que serve os arquivos.
   */
  const preview = _preview_ou_404(res, id); if (!preview) return;
  let codigo;
  try { codigo = fs.readFileSync(preview.html).toString('utf8'); } catch (e) { return naoEncontrado(res); }
  const base = `<base href="/preview/${id}/arquivo/">`;
  const posicao = codigo.toLowerCase().indexOf('<head');
  if (posicao >= 0) {
    const fim = codigo.indexOf('>', posicao);
    codigo = codigo.slice(0, fim + 1) + base + codigo.slice(fim + 1);
  } else {
    codigo = base + codigo;
  }
  responder(res, 200, codigo, 'text/html; charset=utf-8');
}

function preview_arquivo(res, id, relativo) {
  /*
   * Serve as imagens que a peça referencia, só de dentro da pasta do pacote:
   * qualquer tentativa de subir de pasta pelo endereço dá 404.
   */
  const preview = _preview_ou_404(res, id); if (!preview) return;
  const raiz = path.resolve(preview.raiz);
  const alvo = path.resolve(raiz, relativo);
  if (!alvo.startsWith(raiz + path.sep)) return naoEncontrado(res);
  enviarArquivo(res, alvo);
}

function preview_imagem(res, id, nome) {
  /* Serve uma imagem do pacote pelo nome, para o apontamento mostrar o arquivo. */
  const preview = _preview_ou_404(res, id); if (!preview) return;
  const pasta = preview.imagens || preview.raiz;
  try { if (!fs.statSync(pasta).isDirectory()) return naoEncontrado(res); } catch (e) { return naoEncontrado(res); }
  const alvo = path.basename(nome.replace(/\\/g, '/')).toLowerCase();
  const pilha = [pasta];
  while (pilha.length) {
    const dir = pilha.shift();
    let entradas;
    try { entradas = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { continue; }
    for (const e of entradas) {
      if (e.isDirectory()) pilha.push(path.join(dir, e.name));
      else if (e.name.toLowerCase() === alvo) return enviarArquivo(res, path.join(dir, e.name));
    }
  }
  naoEncontrado(res);
}

function conteudo_gerado(res, id) {
  /*
   * CONTEUDO.docx com a leitura desta conferência. Serve para montar pacote de teste, não para
   * conferir a peça: os dois lados sairiam da mesma leitura e o resultado daria 100% sempre.
   */
  const preview = _preview_ou_404(res, id); if (!preview) return;
  const paragrafos = [];
  for (const bloco of preview.leitura) {
    for (const linha of (bloco.texto || '').split(/\r\n|\r|\n/)) {
      if (linha.trim()) paragrafos.push(linha.trim());
    }
  }
  const nome = `CONTEUDO_GERADO_${preview.nome || id}.docx`;
  const ascii = nome.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  responder(res, 200, gerarDocx(paragrafos),
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    { 'Content-Disposition': `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(nome)}` });
}

function preview_html(res, id) {
  /*
   * O HTML do pacote como texto, para o botão "Abrir no Workbench". O arquivo da agência pode estar
   * em UTF-8 (com ou sem BOM) ou em Windows-1252; o editor trabalha com texto, não com bytes.
   */
  const preview = _preview_ou_404(res, id); if (!preview) return;
  let bruto;
  try { bruto = fs.readFileSync(preview.html); } catch (e) { return naoEncontrado(res); }
  let texto;
  try {
    texto = new TextDecoder('utf-8', { fatal: true, ignoreBOM: false }).decode(bruto); // utf-8-sig: tira o BOM
  } catch (e) {
    texto = decodificar_cp1252(bruto);
  }
  json(res, 200, { nome: preview.nome || '', arquivo: path.basename(preview.html), html: texto },
    { 'Cache-Control': 'no-store' });
}

function status_ocr(res) {
  const { aviso_de_escolha, aviso_de_idioma, aviso_de_versao, diagnosticar, idiomas_instalados,
    motor_ativo, ocr_disponivel } = ocr;
  const [disponivel, motivo] = ocr_disponivel();
  const ativo = motor_ativo();
  const idiomas = idiomas_instalados();
  json(res, 200, {
    disponivel,
    motivo,
    motor: ativo ? ativo.nome : '',
    aviso_escolha: aviso_de_escolha(),
    aviso_versao: aviso_de_versao(),
    descricao: ativo ? ativo.descricao : '',
    motores: diagnosticar(),
    disponiveis: diagnosticar().filter((m) => m.disponivel),
    idiomas,
    portugues: idiomas.includes('por'),
    dica_idioma: aviso_de_idioma(),
  });
}

function arquivo_do_front(res, nome) {
  /* CSS e JS do front, servidos de public/static (só .css e .js, só de dentro da pasta). */
  if (!/\.(css|js)$/.test(nome)) return naoEncontrado(res);
  if (nome === 'wb/regras-time.js') return estatica(res, regras_do_time(), 'text/javascript; charset=utf-8');
  const raiz = path.join(cfg.PASTA_PUBLICA, 'static');
  const alvo = path.resolve(raiz, nome);
  if (!alvo.startsWith(raiz + path.sep)) return naoEncontrado(res);
  let texto;
  try { texto = fs.readFileSync(alvo); } catch (e) { return naoEncontrado(res); }
  responder(res, 200, texto, tipoDe(alvo), { 'Cache-Control': 'no-cache' });
}

// ------------------------------------------------------------ roteamento

async function rotear(req, res) {
  const url = new URL(req.url, 'http://local');
  const caminho = url.pathname;
  const metodo = req.method;
  const decod = (s) => { try { return decodeURIComponent(s); } catch (e) { return s; } };
  let m;

  if (metodo === 'POST') {
    if (caminho === '/api/conferir-upload') return conferir_upload(req, res);
    if (caminho === '/api/conferir-em-fluxo') return conferir_em_fluxo(req, res);
    return responder(res, 405, 'Método não permitido.');
  }
  if (metodo !== 'GET' && metodo !== 'HEAD') return responder(res, 405, 'Método não permitido.');

  if (caminho === '/') return estatica(res, lerPublico('html', 'index.html'), 'text/html; charset=utf-8');
  if (caminho === '/workbench/tests/') return estatica(res, lerPublico('html', 'workbench-tests.html'), 'text/html; charset=utf-8');
  if (caminho === '/validador/tests/') return estatica(res, lerPublico('html', 'validador-tests.html'), 'text/html; charset=utf-8');

  if (caminho === '/api/validador/testes') {
    if (_testes_em_andamento) return json(res, 409, { erro: 'Já há uma rodada de testes em andamento.' });
    _testes_em_andamento = true;
    try {
      const [rel, erro] = await rodar_testes_em_processo_separado();
      if (rel === null) return json(res, 500, { erro });
      return json(res, 200, rel);
    } finally { _testes_em_andamento = false; }
  }

  if ((m = /^\/assets\/(.+)$/.exec(caminho))) return arquivo_do_front(res, decod(m[1]));

  if ((m = /^\/relatorio\/([^/]+)$/.exec(caminho))) {
    const id = decod(m[1]);
    // o id é gerado por uuid4().hex, então só letras e números são válidos
    if (!idValido(id)) return responder(res, 400, 'Identificador inválido.');
    const arquivo = path.join(cfg.PASTA_RELATORIOS, `${id}.html`);
    if (!fs.existsSync(arquivo)) return responder(res, 404, 'Relatório não encontrado. Refaça a conferência.');
    return enviarArquivo(res, arquivo);
  }

  if ((m = /^\/preview\/([^/]+)\/peca$/.exec(caminho))) return preview_peca(res, decod(m[1]));
  if ((m = /^\/preview\/([^/]+)\/arquivo\/(.+)$/.exec(caminho))) return preview_arquivo(res, decod(m[1]), decod(m[2]));
  if ((m = /^\/preview\/([^/]+)\/imagem\/([^/]+)$/.exec(caminho))) return preview_imagem(res, decod(m[1]), decod(m[2]));
  if ((m = /^\/preview\/([^/]+)\/conteudo-gerado\.docx$/.exec(caminho))) return conteudo_gerado(res, decod(m[1]));
  if ((m = /^\/api\/preview\/([^/]+)\/leitura$/.exec(caminho))) {
    const p = _preview_ou_404(res, decod(m[1])); return p && json(res, 200, { blocos: p.leitura });
  }
  if ((m = /^\/api\/preview\/([^/]+)\/html$/.exec(caminho))) return preview_html(res, decod(m[1]));
  if ((m = /^\/api\/preview\/([^/]+)\/conteudo$/.exec(caminho))) {
    const p = _preview_ou_404(res, decod(m[1])); return p && json(res, 200, { paragrafos: p.paragrafos });
  }
  if (caminho === '/api/status-ocr') return status_ocr(res);

  return naoEncontrado(res);
}

/** Servidor HTTP já configurado (quem chama faz o listen). */
function handler(req, res) {
  rotear(req, res).catch((erro) => {
    console.error(`[erro] ${req.method} ${req.url}:`, erro && erro.stack || erro);
    if (res.headersSent) return res.destroy();
    if (String(req.url).startsWith('/api/')) json(res, 500, { erro: String(erro && erro.message || erro) });
    else responder(res, 500, 'Erro interno.');
  });
}

// ----------------------------------------------------------- temporárias

function _apagar_pasta(pasta) { try { fs.rmSync(pasta, { recursive: true, force: true }); } catch (e) { /* segue */ } }

function limpar_temporarias() {
  for (const t of _temporarias) _apagar_pasta(t.pasta);
  _temporarias.length = 0;
}

/**
 * No servidor o programa fica semanas no ar: as pastas dos uploads e os previews não podem crescer
 * para sempre. Passadas HORAS_TEMPORARIAS (padrão 24; 0 desliga) elas saem, junto com o preview.
 */
function limpar_temporarias_antigas(agora = Date.now()) {
  const horas = process.env.HORAS_TEMPORARIAS === undefined ? 24 : Number(process.env.HORAS_TEMPORARIAS);
  if (!(horas > 0)) return 0;
  let apagadas = 0;
  for (let i = _temporarias.length - 1; i >= 0; i--) {
    const t = _temporarias[i];
    if (agora - t.criado < horas * 3600 * 1000) continue;
    _apagar_pasta(t.pasta);
    for (const [id, p] of Object.entries(_previews)) {
      if (path.resolve(p.raiz).startsWith(path.resolve(t.pasta))) delete _previews[id];
    }
    _temporarias.splice(i, 1);
    apagadas += 1;
  }
  return apagadas;
}

function agendar_limpeza() {
  const t = setInterval(() => limpar_temporarias_antigas(), 30 * 60 * 1000);
  t.unref();
  return t;
}

module.exports = {
  handler, _previews, _temporarias, _conferir, _leitura_da_peca, regras_do_time,
  rodar_testes_em_processo_separado, MARCA_DO_RESULTADO,
  limpar_temporarias, limpar_temporarias_antigas, agendar_limpeza, LIMITE_DO_ENVIO,
};
