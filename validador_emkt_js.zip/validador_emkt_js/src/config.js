'use strict';
/**
 * Configuração e caminhos (região 1 do script único em Python).
 *
 * Ancorar tudo no arquivo, e não no diretório de trabalho, faz o programa subir igual
 * pelo duplo clique, pelo terminal aberto em qualquer lugar e por um gerenciador de processos.
 *
 * DADOS_DIR (opcional): onde ficam relatorios/, regras-time.js e pacotes_de_teste/. Útil em
 * servidor, quando a pasta do programa é somente leitura. Padrão: a pasta do programa.
 */
const fs = require('fs');
const path = require('path');
const net = require('net');

const PASTA_DO_PROGRAMA = path.resolve(__dirname, '..');
const PASTA_DO_SCRIPT = process.env.DADOS_DIR
  ? path.resolve(process.env.DADOS_DIR)
  : PASTA_DO_PROGRAMA;
const PASTA_PUBLICA = path.join(PASTA_DO_PROGRAMA, 'public');
const PASTA_RELATORIOS = path.join(PASTA_DO_SCRIPT, 'relatorios');
const PASTA_PACOTES_REAIS = path.join(PASTA_DO_SCRIPT, 'pacotes_de_teste');

// Cada conferência grava um relatório em "relatorios", e ninguém apaga depois.
// Ao abrir o programa, os relatórios com mais de DIAS_RELATORIOS dias saem.
// O padrão é 30; defina a variável de ambiente DIAS_RELATORIOS para mudar (0 desliga).
const DIAS_PADRAO_DOS_RELATORIOS = 30;

function _dias_dos_relatorios() {
  const bruto = process.env.DIAS_RELATORIOS;
  if (bruto === undefined) return DIAS_PADRAO_DOS_RELATORIOS;
  // int() do Python aceita espaços e sinal; rejeita decimal e texto
  if (!/^\s*[+-]?\d+\s*$/.test(bruto)) return DIAS_PADRAO_DOS_RELATORIOS;
  return Math.max(0, parseInt(bruto, 10));
}

const DIAS_RELATORIOS = _dias_dos_relatorios();

// O nome do relatório é sempre uuid4().hex[:12] + ".html". Só o que tem exatamente esse
// formato é candidato a apagar: qualquer outro arquivo guardado na pasta fica intocado.
const _RE_NOME_DE_RELATORIO = /^[0-9a-f]{12}\.html$/;

/**
 * Apaga os relatórios com mais de `dias` dias e devolve [apagados, bytes liberados].
 *
 * A idade vem da data de modificação do arquivo. Arquivo que não dá para apagar (aberto
 * no navegador, no Windows, por exemplo) é pulado e fica para a próxima abertura.
 * `agora` é em segundos desde a época, como time.time() do Python.
 */
function limpar_relatorios_antigos(dias = null, pasta = null, agora = null) {
  dias = dias === null || dias === undefined ? DIAS_RELATORIOS : dias;
  pasta = pasta || PASTA_RELATORIOS;
  let ehPasta = false;
  try { ehPasta = fs.statSync(pasta).isDirectory(); } catch (e) { ehPasta = false; }
  if (dias <= 0 || !ehPasta) return [0, 0];

  const limite = (agora === null || agora === undefined ? Date.now() / 1000 : agora) - dias * 86400;
  let apagados = 0;
  let liberados = 0;
  for (const nome of fs.readdirSync(pasta)) {
    if (!_RE_NOME_DE_RELATORIO.test(nome)) continue;
    const caminho = path.join(pasta, nome);
    try {
      const st = fs.statSync(caminho);
      if (!st.isFile() || st.mtimeMs / 1000 >= limite) continue;
      const tamanho = st.size;
      fs.unlinkSync(caminho);
      apagados += 1;
      liberados += tamanho;
    } catch (e) {
      continue;
    }
  }
  return [apagados, liberados];
}

function _porta_livre(porta, host = '127.0.0.1') {
  // sem reuso de endereço de propósito: o teste precisa falhar exatamente onde o
  // servidor falharia, senão ele diria "livre" numa porta já em uso
  return new Promise((resolver) => {
    const teste = net.createServer();
    teste.once('error', () => resolver(false));
    teste.once('listening', () => teste.close(() => resolver(true)));
    teste.listen({ port: porta, host, exclusive: true });
  });
}

/**
 * Deixar o programa aberto numa janela e rodar de novo trava a porta 5000.
 * Em vez de morrer com "address already in use", sobe na porta seguinte.
 */
async function _escolher_porta(preferida = 5000, host = '127.0.0.1') {
  for (let porta = preferida; porta < preferida + 12; porta++) {
    if (await _porta_livre(porta, host)) return porta;
  }
  return preferida;
}

module.exports = {
  PASTA_DO_PROGRAMA, PASTA_DO_SCRIPT, PASTA_PUBLICA, PASTA_RELATORIOS, PASTA_PACOTES_REAIS,
  DIAS_PADRAO_DOS_RELATORIOS, DIAS_RELATORIOS, _dias_dos_relatorios,
  limpar_relatorios_antigos, _porta_livre, _escolher_porta,
};
