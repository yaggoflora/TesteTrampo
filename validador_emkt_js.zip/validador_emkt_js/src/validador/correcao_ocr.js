'use strict';
/*
 * Correção dos erros típicos de OCR, antes de comparar.
 *
 * Motor de OCR erra de dois jeitos previsíveis em peça de e-mail:
 *
 *   1. cola palavras vizinhas      "SemconsultaaoSPCeSerasa"
 *   2. troca caractere parecido    "ate l dia" (leu 1 como L), "a0 mes"
 *
 * Se comparar sem tratar isso, quase toda imagem vira apontamento falso e o
 * sistema perde a serventia — você voltaria a conferir tudo no olho.
 *
 * A saída aqui é usar o próprio CONTEUDO.docx como dicionário. Ele tem a grafia
 * correta do que deveria estar na peça: quando um pedaço colado se decompõe
 * exatamente em palavras do docx, foi erro de leitura, não divergência real.
 *
 * O que NÃO é corrigido: número que existe de verdade. "48" contra "60" continua
 * divergência, porque a correção só aceita reescrita que case com o docx, e
 * nenhuma confusão conhecida transforma 4 em 6 ou 8 em 0.
 */

const { tokenizar } = require('./normalizacao');

// caracteres que os motores confundem com frequência
const CONFUSOES = {
  '0': 'o', '1': 'l', '5': 's', '8': 'b',
  '|': 'l', '¦': 'l', '!': 'l',
};

const TAMANHO_MINIMO_PARA_SEGMENTAR = 6;
// Uma linha inteira de banner pode vir colada ("dinheironacontaemateldiautil"
// são oito palavras). O teto existe só para evitar decomposições absurdas; a
// exigência de que TODO pedaço exista no docx já é a trava de verdade.
const MAXIMO_DE_PEDACOS = 12;

/**
 * Forma usada só para decidir se dois tokens são o mesmo.
 *
 * Nunca é exibida no relatório: o que aparece na tela continua sendo o texto
 * original, para você conseguir localizar o trecho na peça.
 */
function canonizar(token) {
  let saida = '';
  for (const c of token) saida += Object.prototype.hasOwnProperty.call(CONFUSOES, c) ? CONFUSOES[c] : c;
  return saida;
}

/**
 * Tenta quebrar um token colado em palavras que existam no docx.
 *
 * Programação dinâmica simples: para cada posição, guarda a menor quantidade
 * de pedaços que chega até ali. Preferir menos pedaços evita decompor uma
 * palavra legítima em partículas ("consulta" virando "con" + "sul" + "ta").
 */
function _segmentar(colado, vocabulario) {
  const cs = Array.from(colado);
  const n = cs.length;
  const melhor = new Array(n + 1).fill(null);
  melhor[0] = [];

  for (let fim = 1; fim <= n; fim++) {
    for (let inicio = fim - 1; inicio >= 0; inicio--) {
      if (melhor[inicio] === null) continue;
      const pedaco = cs.slice(inicio, fim).join('');
      if (!vocabulario.has(pedaco)) continue;
      const candidato = melhor[inicio].concat([pedaco]);
      if (candidato.length > MAXIMO_DE_PEDACOS) continue;
      if (melhor[fim] === null || candidato.length < melhor[fim].length) melhor[fim] = candidato;
    }
  }

  const resultado = melhor[n];
  return resultado && resultado.length > 1 ? resultado : null;
}

/** Todas as palavras do docx, em forma canônica. */
function construir_vocabulario(paragrafos) {
  const vocabulario = new Set();
  for (const paragrafo of paragrafos) {
    for (const palavra of tokenizar(paragrafo)) vocabulario.add(canonizar(palavra));
  }
  return vocabulario;
}

/**
 * Devolve [tokens corrigidos, lista do que foi separado].
 *
 * Só mexe no token que não existe no docx e que se decompõe inteiramente em
 * palavras do docx. Qualquer outro caso passa intacto — na dúvida, o sistema
 * deixa a divergência aparecer em vez de escondê-la com uma correção criativa.
 */
function corrigir(tokens, vocabulario) {
  const saida = [];
  const separados = [];
  for (const token of tokens) {
    const canonico = canonizar(token);
    if (vocabulario.has(canonico)) {
      saida.push(token);
      continue;
    }
    const tamanho = Array.from(canonico).length;
    // caractere solto que não existe no docx é sujeira de leitura: uma borda
    // lida como parêntese, um pingo lido como ponto. Manter só produz
    // apontamento falso.
    if (tamanho === 1) {
      separados.push(`${token} → removido (ruído de leitura)`);
      continue;
    }
    if (tamanho < TAMANHO_MINIMO_PARA_SEGMENTAR) {
      saida.push(token);
      continue;
    }
    const pedacos = _segmentar(canonico, vocabulario);
    if (pedacos && pedacos.length) {
      saida.push(...pedacos);
      separados.push(`${token} → ${pedacos.join(' ')}`);
    } else {
      saida.push(token);
    }
  }
  return [saida, separados];
}

function tokens_iguais(a, b) {
  return canonizar(a) === canonizar(b);
}

module.exports = {
  CONFUSOES, TAMANHO_MINIMO_PARA_SEGMENTAR, MAXIMO_DE_PEDACOS, canonizar, _segmentar,
  construir_vocabulario, corrigir, tokens_iguais,
};
