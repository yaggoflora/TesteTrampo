'use strict';
/**
 * Orquestração da conferência de um pacote.
 *
 * Recebe a pasta que o analista de marketing enviou, descobre sozinho onde está o
 * HTML, os dois docx e as imagens, e roda as três verificações.
 */

const fs = require('fs');
const pyos = require('../lib/pyos');
const { sorted, maxPor } = require('../lib/pyutil');

const comparador = require('./comparador');
const docx_parser = require('./docx_parser');
const html_parser = require('./html_parser');
const mod_imagens = require('./imagens');
const presenca = require('./presenca');
const regras = require('./regras');
const { CacheOCR, aviso_de_idioma, ocr_disponivel } = require('./ocr');

const NOMES_PASTA_IMAGENS = ['imagens', 'images', 'img', 'imgs', 'assets', 'peças', 'pecas'];

/** os.path.normpath (posix) */
function _normpath(p) {
  if (p === '') return '.';
  const abs = p.startsWith('/');
  const duplas = p.startsWith('//') && !p.startsWith('///');
  const partes = [];
  for (const c of p.split('/')) {
    if (c === '' || c === '.') continue;
    if (c !== '..' || (!abs && !partes.length) || (partes.length && partes[partes.length - 1] === '..')) partes.push(c);
    else if (partes.length) partes.pop();
  }
  let r = partes.join('/');
  if (abs) r = '/' + r;
  if (duplas) r = '/' + r;
  return r || '.';
}

class ResultadoPacote {
  constructor(campos = {}) {
    Object.assign(this, {
      pasta: '',
      quebra: '',
      caminho_html: '',
      caminho_conteudo: '',
      caminho_assunto: '',
      pasta_imagens: '',
      leitura_html: null,
      leitura_conteudo: null,
      leitura_assunto: null,
      resultado_imagens: null,
      resultado_texto: null,
      apontamentos_assunto: [],
      bloqueios: [],      // impedem a publicação
      alertas: [],        // o analista precisa saber
      avisos: [],
      erros: [],
      ocr_ativo: false,
      motivo_ocr: '',
      modo_texto: 'sequencia',   // "sequencia" (com OCR) | "presenca" (sem OCR)
      nome_pasta: '',            // como o pacote chegou: briefing+CPI+ação
    }, campos);
  }

  get status() {
    if (this.erros.length) return 'erro';
    if (this.bloqueios.length) return 'reprovado';
    const problemas_imagem = this.resultado_imagens && !this.resultado_imagens.aprovado;
    const status_texto = this.resultado_texto ? this.resultado_texto.status : 'erro';
    if (problemas_imagem || status_texto === 'reprovado') return 'reprovado';
    if (status_texto === 'atencao' || status_texto === 'parcial' || this.apontamentos_assunto.length) return 'atencao';
    return 'aprovado';
  }
}

/**
 * Varre o pacote inteiro atrás do HTML da peça.
 *
 * O arquivo pode estar na raiz ou dentro de uma pasta "html" — depende da
 * agência. Entre vários, ganha o que tem mais cara de peça: index primeiro,
 * depois o maior, porque HTML de e-mail é pesado e um arquivo pequeno
 * costuma ser um fragmento ou um teste.
 */
function _localizar_html(pasta) {
  const encontrados = [];
  for (const [raiz, , arquivos] of pyos.walk(pasta)) {
    for (const arquivo of arquivos) {
      if (arquivo.startsWith('~') || arquivo.startsWith('.')) continue;
      const a = arquivo.toLowerCase();
      if (a.endsWith('.html') || a.endsWith('.htm')) encontrados.push(pyos.join(raiz, arquivo));
    }
  }
  return sorted(encontrados, (c) => [
    pyos.basename(c).toLowerCase().startsWith('index') ? 0 : 1,
    -fs.statSync(c).size,
  ]);
}

const EXTENSOES_IMAGEM = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
const _eImagem = (a) => EXTENSOES_IMAGEM.some((e) => a.toLowerCase().endsWith(e));

/**
 * Descobre onde estão as imagens do pacote.
 *
 * A estrutura muda conforme a agência que desenvolveu: às vezes o HTML fica
 * solto na raiz com uma pasta "imagens" ao lado, às vezes vem uma pasta
 * "html" com o arquivo dentro e a pasta de imagens dentro dela. Em vez de
 * apostar num layout, a busca vai do critério mais confiável para o mais
 * genérico.
 */
function _localizar_pasta_imagens(pasta, caminho_html, referenciadas = null) {
  const candidatas = new Map();
  for (const [raiz, , arquivos] of pyos.walk(pasta)) {
    const imagens = arquivos.filter(_eImagem);
    if (imagens.length) candidatas.set(raiz, imagens);
  }
  if (!candidatas.size) return caminho_html ? require('path').dirname(caminho_html) : pasta;

  // 1. a pasta que mais cobre os arquivos que o HTML realmente chama.
  //    É o critério mais forte: liga o que está no disco ao que está no código.
  if (referenciadas && referenciadas.length) {
    const alvo = new Set(referenciadas.map((n) => n.toLowerCase()));
    let melhor = null; let melhor_cobertura = 0;
    for (const [caminho, arquivos] of candidatas) {
      const nomes = new Set(arquivos.map((a) => a.toLowerCase()));
      let cobertura = 0;
      for (const n of nomes) if (alvo.has(n)) cobertura++;
      if (cobertura > melhor_cobertura) { melhor = caminho; melhor_cobertura = cobertura; }
    }
    if (melhor && melhor_cobertura) return melhor;
  }

  // 2. pasta com nome conhecido
  for (const caminho of candidatas.keys()) {
    if (NOMES_PASTA_IMAGENS.includes(pyos.basename(caminho).toLowerCase())) return caminho;
  }

  // 3. a que tem mais imagens
  return maxPor([...candidatas.entries()], (item) => item[1].length)[0];
}

/**
 * validar(pasta, quebra, usar_ocr, idioma_ocr, ao_avancar)  — async (OCR).
 * Também aceita um objeto de opções no segundo argumento:
 *   validar(pasta, { quebra, usar_ocr, idioma_ocr, ao_avancar })
 */
async function validar(pasta, quebra = null, usar_ocr = true, idioma_ocr = 'por', ao_avancar = null) {
  if (quebra !== null && typeof quebra === 'object') {
    ({ quebra = null, usar_ocr = true, idioma_ocr = 'por', ao_avancar = null } = quebra);
  }
  const resultado = new ResultadoPacote({ pasta });
  resultado.nome_pasta = pyos.basename(_normpath(pasta));

  let ehPasta = false;
  try { ehPasta = fs.statSync(pasta).isDirectory(); } catch (e) { ehPasta = false; }
  if (!ehPasta) {
    resultado.erros.push(`pasta não encontrada: ${pasta}`);
    return resultado;
  }

  // --- localizar arquivos ---
  const htmls = _localizar_html(pasta);
  if (!htmls.length) {
    resultado.erros.push('nenhum arquivo .html encontrado no pacote');
    return resultado;
  }
  resultado.caminho_html = htmls[0];
  if (htmls.length > 1) {
    const outros = htmls.slice(1).map((h) => pyos.basename(h)).join(', ');
    resultado.avisos.push(
      `mais de um HTML no pacote; usando '${pyos.basename(htmls[0])}'. Outros: ${outros}`,
    );
  }

  const documentos = docx_parser.localizar_docx(pasta);
  if (!documentos.length) {
    // lista o que existe: quase sempre o motivo é .doc antigo, arquivo
    // ainda dentro de um zip, ou o pacote apontado um nível acima
    const outros = [];
    for (const [, , arquivos] of pyos.walk(pasta)) {
      for (const arquivo of arquivos) {
        const a = arquivo.toLowerCase();
        if (['.doc', '.zip', '.rar', '.7z', '.pdf'].some((e) => a.endsWith(e))) outros.push(arquivo);
      }
    }
    let pista = '';
    if (outros.length) {
      pista = ' Encontrei no pacote: ' + sorted(new Set(outros)).slice(0, 6).join(', ')
        + '. Arquivos .doc antigos precisam ser salvos como .docx, '
        + 'e compactados precisam ser extraídos antes.';
    }
    resultado.erros.push('Nenhum arquivo .docx encontrado neste pacote.' + pista);
    return resultado;
  }

  const [conteudo, assunto] = docx_parser.identificar_papeis(documentos);
  resultado.leitura_conteudo = conteudo;
  resultado.leitura_assunto = assunto;
  resultado.caminho_conteudo = conteudo ? conteudo.caminho : '';
  resultado.caminho_assunto = assunto ? assunto.caminho : '';

  if (!resultado.leitura_conteudo) {
    const nomes = documentos.map((d) => pyos.basename(d)).join(', ');
    resultado.erros.push(
      'Encontrei .docx no pacote, mas nenhum com corpo de texto para comparar '
      + `com o HTML. Arquivos vistos: ${nomes}.`,
    );
    return resultado;
  }
  if (!resultado.leitura_assunto) {
    resultado.avisos.push(
      'Não identifiquei um docx de assunto/pré-header. As regras de '
      + 'publicação que dependem dele não foram conferidas.',
    );
  }

  // --- OCR ---
  let cache = null;
  if (usar_ocr) {
    const [disponivel, motivo] = ocr_disponivel();
    resultado.ocr_ativo = disponivel;
    resultado.motivo_ocr = motivo;
    if (disponivel) {
      cache = new CacheOCR(idioma_ocr);
      if (cache.aviso_idioma) resultado.avisos.push(cache.aviso_idioma);
      const sem_portugues = aviso_de_idioma();
      if (sem_portugues) resultado.avisos.push(sem_portugues);
    } else {
      resultado.avisos.push(
        `OCR indisponível (${motivo}). O texto dentro das imagens não foi `
        + 'conferido; as demais verificações rodaram normalmente.',
      );
    }
  } else {
    resultado.motivo_ocr = 'desativado por parâmetro';
  }

  // --- leitura do HTML e montagem da fita ---
  // Primeira passada sem OCR só para descobrir quais arquivos o código chama;
  // com essa lista dá para achar a pasta de imagens certa mesmo em estrutura
  // que não conhecemos.
  const referencias = (await html_parser.ler_html(resultado.caminho_html, pasta)).imagens_referenciadas;
  resultado.pasta_imagens = _localizar_pasta_imagens(pasta, resultado.caminho_html, referencias);

  // Lê as imagens em paralelo ANTES de montar a fita. O percurso do DOM é
  // sequencial por natureza — precisa respeitar a ordem de leitura — mas a
  // leitura em si não: adiantar tudo aqui encurta a espera sem mudar o
  // resultado, porque o percurso depois só consulta o que já está pronto.
  if (cache !== null) {
    const caminhos = [];
    for (const nome of new Set(referencias)) {
      const achado = html_parser._localizar_arquivo(resultado.pasta_imagens, nome);
      if (achado) caminhos.push(achado);
    }
    await cache.pre_carregar(caminhos, 3, ao_avancar);
  }

  resultado.leitura_html = await html_parser.ler_html(
    resultado.caminho_html, resultado.pasta_imagens, cache,
  );
  resultado.erros.push(...resultado.leitura_html.erros);
  if (resultado.erros.length) return resultado;

  const remotas = resultado.leitura_html.imagens_remotas || [];
  if (remotas.length) {
    resultado.avisos.push(
      `${remotas.length} imagem(ns) chamada(s) por URL, não pelo pacote — `
      + 'é o caso da peça já hospedada. Elas não entram na conferência de '
      + 'pasta nem têm o texto lido: ' + remotas.slice(0, 5).join(', '),
    );
  }

  // --- verificação 1: imagens ---
  resultado.resultado_imagens = mod_imagens.verificar(
    resultado.pasta_imagens,
    resultado.leitura_html.imagens_referenciadas,
    quebra,
  );
  resultado.quebra = resultado.resultado_imagens.quebra;

  // --- verificação 2 e 3: texto ---
  // Com OCR, a fita está completa e vale comparar sequência. Sem OCR, o texto
  // das imagens falta na fita mas sobra no docx: comparar sequência aí inventa
  // divergência. Nesse caso só perguntamos se o texto vivo consta no docx.
  const imagens_sem_leitura = resultado.leitura_html.fita.some(
    (b) => b.tipo === 'imagem' && !b.ocr_lido && !b.oculto,
  );
  resultado.modo_texto = imagens_sem_leitura ? 'presenca' : 'sequencia';
  if (imagens_sem_leitura) {
    resultado.resultado_texto = presenca.comparar(
      resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos,
    );
  } else {
    resultado.resultado_texto = comparador.comparar(
      resultado.leitura_html.fita, resultado.leitura_conteudo.paragrafos,
    );
  }

  // --- verificação 4: pré-header ---
  if (resultado.leitura_assunto) {
    resultado.apontamentos_assunto = comparador.comparar_assunto(
      resultado.leitura_assunto, resultado.leitura_html,
    );
  }

  // --- verificação 5: regras de publicação ---
  _aplicar_regras(resultado);

  return resultado;
}

/**
 * Endereço no disclaimer precisa vir com o código que impede o link.
 *
 * O cliente de e-mail transforma sozinho qualquer coisa com cara de endereço
 * em link clicável. No disclaimer isso não pode acontecer, então a peça
 * separa os caracteres com um invisível (&#xFEFF;) no ponto onde o cliente
 * procuraria o padrão de domínio. Sem esse código, o link é gerado.
 */
function _conferir_disclaimer(resultado) {
  if (!resultado.leitura_html) return;

  for (const bloco of resultado.leitura_html.fita) {
    if (!bloco.classificacao.startsWith('obrigatorio:disclaimer')) continue;

    // Link com texto de frase — "Saiba mais", "Cancele aqui", "Fale
    // Conosco" — é intencional e existe em quase todo disclaimer. O que a
    // regra proíbe é o ENDEREÇO virar link: é isso que precisa da proteção.
    for (const texto_do_link of bloco.textos_de_link) {
      if (regras.enderecos_sem_protecao(texto_do_link).length) {
        resultado.bloqueios.push(
          'Endereço dentro de um link clicável no disclaimer: '
          + `“${_fatia(texto_do_link.trim(), 90)}”`,
        );
      }
    }

    const desprotegidos = regras.enderecos_sem_protecao(bloco.bruto);
    for (const endereco of desprotegidos) {
      resultado.bloqueios.push(
        'Endereço sem o código que impede o hyperlink no disclaimer: '
        + `“${endereco}”. Separe os caracteres com &#xFEFF; `
        + 'como nas demais peças.',
      );
    }
  }
}

/** s[:n] do Python (por code point). */
function _fatia(s, n) {
  const a = Array.from(s);
  return a.length <= n ? s : a.slice(0, n).join('');
}

/**
 * O CONTEUDO.docx não pode ter hyperlink.
 *
 * Ele é a transcrição do que a peça mostra, e vai para o cadastro como texto.
 * Link ali veio de cópia com formatação, e o endereço costuma viajar junto
 * para o Content Builder.
 */
function _conferir_links_no_docx(resultado) {
  const leitura = resultado.leitura_conteudo;
  if (!leitura || !(leitura.links && leitura.links.length)) return;

  for (const [visivel, endereco] of leitura.links.slice(0, 5)) {
    const rotulo = visivel ? `“${visivel}” → ${endereco}` : endereco;
    resultado.bloqueios.push(
      `Há hyperlink no CONTEUDO.docx: ${_fatia(rotulo, 120)}. `
      + 'O documento deve conter só o texto da peça.',
    );
  }
}

/**
 * Aponta datas já passadas na peça.
 *
 * Peça reaproveitada de mês anterior costuma trazer a data antiga junto, e o
 * disclaimer é onde isso mais escapa. Fica como aviso: às vezes a data
 * passada é proposital — início de vigência, data de contrato — e quem
 * decide isso é o analista.
 */
function _conferir_datas(resultado) {
  if (!resultado.leitura_html) return;

  const achadas = new Map();
  for (const bloco of resultado.leitura_html.fita) {
    for (const data of regras.datas_vencidas(bloco.conteudo)) {
      if (achadas.has(data)) continue;
      const onde = bloco.tipo === 'imagem' ? bloco.referencia : 'texto do HTML';
      achadas.set(data, onde);
    }
  }

  if (resultado.leitura_conteudo) {
    for (const paragrafo of resultado.leitura_conteudo.paragrafos) {
      for (const data of regras.datas_vencidas(paragrafo)) {
        if (!achadas.has(data)) achadas.set(data, 'CONTEUDO.docx');
      }
    }
  }

  for (const [data, onde] of [...achadas.entries()].slice(0, 6)) {
    resultado.alertas.push(`Data vencida: ${data} (em ${onde}) — verificar.`);
  }
}

/**
 * Regras do banco, separadas do restante da conferência.
 *
 * O que impede a publicação vira bloqueio e reprova o pacote. O que só merece
 * atenção vira alerta e não muda o veredito — assunto longo não é erro, é
 * informação para o analista decidir.
 */
function _aplicar_regras(resultado) {
  // Redirect: sem nenhum no código, a peça não sobe.
  if (resultado.leitura_html && resultado.leitura_html.redirects === 0) {
    resultado.bloqueios.push(
      'Nenhum redirect encontrado no HTML. A publicação exige pelo menos um.',
    );
  }

  _conferir_disclaimer(resultado);
  _conferir_links_no_docx(resultado);
  _conferir_datas(resultado);

  const leitura = resultado.leitura_assunto;
  if (!leitura) return;

  // Pré-header sem ponto final não passa na publicação.
  if (leitura.pre_header) {
    if (!regras.pre_header_tem_ponto_final(leitura.pre_header)) {
      resultado.bloqueios.push(
        'O pré-header não termina em ponto final: '
        + `“${leitura.pre_header}”`,
      );
    }
    const excedente = regras.excedeu(leitura.pre_header, regras.LIMITE_PRE_HEADER);
    if (excedente) {
      resultado.alertas.push(
        `Pré-header com ${Array.from(leitura.pre_header.trim()).length} caracteres, `
        + `${excedente} acima dos ${regras.LIMITE_PRE_HEADER} de referência.`,
      );
    }
  }

  if (leitura.assunto) {
    const excedente = regras.excedeu(leitura.assunto, regras.LIMITE_ASSUNTO);
    if (excedente) {
      resultado.alertas.push(
        `Assunto com ${Array.from(leitura.assunto.trim()).length} caracteres, `
        + `${excedente} acima dos ${regras.LIMITE_ASSUNTO} de referência.`,
      );
    }
  }
}

/** Arquivo com essa extensão solto na própria pasta, sem descer níveis. */
function _tem_direto(pasta, extensoes) {
  try {
    return fs.readdirSync(pasta).some((item) => {
      const i = item.toLowerCase();
      if (!extensoes.some((e) => i.endsWith(e))) return false;
      if (item.startsWith('~') || item.startsWith('.')) return false;
      try { return fs.statSync(pyos.join(pasta, item)).isFile(); } catch (e) { return false; }
    });
  } catch (e) {
    return false;
  }
}

function _tem_em_algum_lugar(pasta, extensoes) {
  for (const [, , arquivos] of pyos.walk(pasta)) {
    if (arquivos.some((a) => extensoes.some((e) => a.toLowerCase().endsWith(e))
        && !a.startsWith('~') && !a.startsWith('.'))) return true;
  }
  return false;
}

/**
 * Um pacote tem HTML e docx dentro dele, em qualquer nível.
 *
 * Exigir os dois é o que separa o pacote de verdade de uma subpasta "html".
 * A pasta html tem o arquivo da peça, mas os docx ficam um nível acima — se
 * o critério fosse só "tem HTML", ela seria confundida com um pacote e a
 * conferência rodaria sem o texto para comparar.
 */
function _e_pacote(pasta) {
  return _tem_em_algum_lugar(pasta, ['.html', '.htm']) && _tem_em_algum_lugar(pasta, ['.docx']);
}

/**
 * Descobre se o que foi arrastado é UM pacote ou uma caixa com vários.
 *
 * Não dá para exigir que a pessoa escolha o modo certo antes de arrastar: ela
 * tem a pasta na mão, não a estrutura na cabeça. E a estrutura varia com a
 * agência que desenvolveu — o HTML tanto vem solto na raiz quanto dentro de
 * uma pasta "html", com as imagens ao lado dele.
 */
function localizar_pacotes(raiz) {
  let ehPasta = false;
  try { ehPasta = fs.statSync(raiz).isDirectory(); } catch (e) { ehPasta = false; }
  if (!ehPasta) return [];

  // Arquivo de pacote solto na raiz significa que a raiz é o próprio pacote:
  // os docx ficam ali e o HTML pode estar numa subpasta.
  if (_tem_direto(raiz, ['.html', '.htm', '.docx'])) return [raiz];

  const filhos = [];
  let itens;
  try {
    itens = sorted(fs.readdirSync(raiz));
  } catch (e) {
    return [];
  }
  for (const item of itens) {
    const caminho = pyos.join(raiz, item);
    let d = false;
    try { d = fs.statSync(caminho).isDirectory(); } catch (e) { d = false; }
    if (d && _e_pacote(caminho)) filhos.push(caminho);
  }

  if (filhos.length) return filhos;
  if (_e_pacote(raiz) || _tem_em_algum_lugar(raiz, ['.html', '.htm'])) return [raiz];
  return [];
}

/** Confere cada pacote encontrado dentro da pasta. (async) */
async function validar_lote(pasta_raiz, kwargs = {}) {
  const resultados = [];
  for (const caminho of localizar_pacotes(pasta_raiz)) {
    resultados.push(await validar(caminho, kwargs));
  }
  return resultados;
}

module.exports = {
  NOMES_PASTA_IMAGENS, ResultadoPacote, _localizar_html, EXTENSOES_IMAGEM, _localizar_pasta_imagens,
  validar, _conferir_disclaimer, _conferir_links_no_docx, _conferir_datas, _aplicar_regras,
  _tem_direto, _tem_em_algum_lugar, _e_pacote, localizar_pacotes, validar_lote,
};
