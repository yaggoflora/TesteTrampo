'use strict';
/**
 * Conferência do pacote de imagens.
 *
 * Substitui o CTRL+F. Responde três perguntas:
 *   1. Os nomes seguem a taxonomia da quebra?
 *   2. A numeração é sequencial, sem furo (01, 02, 08, 03 reprova)?
 *   3. Toda imagem da pasta está no HTML, e todo src do HTML existe na pasta?
 *
 * Repetição da mesma imagem dentro do HTML é permitida e não gera apontamento.
 */

const fs = require('fs');
const path = require('path');

const R = require('./_pyre');
const regras = require('./regras');
const U = require('../lib/pyutil');
const I = require('../lib/imgutil');
const PYOS = require('../lib/pyos');

const EXTENSOES_VALIDAS = new Set(['.jpg', '.jpeg', '.png', '.gif']);

// Nomes que denunciam material de apoio: a arte do e-mail inteiro que a agência
// manda junto para conferência visual.
const RE_APOIO = R.compilar(
  'preview|layout|mockup|arte|final|completo|full|montagem|aprova[cç][aã]o|' +
  'refer[eê]ncia|amostra', 'i');

// Uma peça inteira em imagem única é muito mais alta que larga. Banner de
// seção raramente passa disso.
const PROPORCAO_DE_PECA_INTEIRA = 2.5;

// quebra + separador opcional + número + extensão
const RE_PADRAO = R.compilar(String.raw`^(?P<quebra>.+?)[_\-\s]?(?P<numero>\d{1,3})$`);

class ImagemPasta {
  constructor(campos = {}) {
    Object.assign(this, {
      nome: '', caminho: '', quebra_detectada: '', numero: null, extensao: '',
      tamanho_kb: 0.0, largura: 0, altura: 0, apoio: false,
    }, campos);
  }
}

class ResultadoImagens {
  constructor(campos = {}) {
    Object.assign(this, {
      quebra: '', quebra_inferida: false, arquivos: [], fora_da_taxonomia: [],
      numeros_faltando: [], numeros_duplicados: [], nao_comeca_em_um: false,
      sem_numeracao_zero_a_esquerda: [], extensao_invalida: [], acima_do_peso: [],
      na_pasta_fora_do_html: [], no_html_fora_da_pasta: [], divergencia_de_caixa: [],
      material_de_apoio: [], repeticoes_no_html: {}, total_referencias_html: 0,
    }, campos);
  }

  get aprovado() {
    return !(
      this.acima_do_peso.length
      || this.fora_da_taxonomia.length
      || this.numeros_faltando.length
      || this.numeros_duplicados.length
      || this.extensao_invalida.length
      || this.na_pasta_fora_do_html.length
      || this.no_html_fora_da_pasta.length
      || this.divergencia_de_caixa.length
      || this.nao_comeca_em_um
    );
  }
}

/**
 * Deduz a quebra pelo prefixo mais comum quando ela não é informada.
 * Usar a moda em vez do prefixo comum a todos evita que um arquivo com nome
 * errado — justamente o que queremos flagrar — contamine a referência.
 */
function _inferir_quebra(nomes) {
  const candidatos = [];
  for (const nome of nomes) {
    const base = PYOS.splitext(nome)[0];
    const m = R.casar(RE_PADRAO, base);
    if (m) candidatos.push(R.pyStrip(m.groups.quebra));
  }
  if (!candidatos.length) return '';
  return new U.Counter(candidatos).most_common(1)[0][0];
}

function listar_pasta(pasta_imagens) {
  const itens = [];
  let ehPasta = false;
  try { ehPasta = fs.statSync(pasta_imagens).isDirectory(); } catch { /* não existe */ }
  if (!ehPasta) return itens;
  for (const [raiz, , arquivos] of PYOS.walk(pasta_imagens)) {
    for (const arquivo of U.sorted(arquivos)) {
      if (arquivo.startsWith('~$') || arquivo.startsWith('.')) continue;
      const extensao = PYOS.splitext(arquivo)[1].toLowerCase();
      if (!EXTENSOES_VALIDAS.has(extensao) && !['.webp', '.bmp', '.svg'].includes(extensao)) continue;
      const caminho = path.join(raiz, arquivo);
      itens.push(new ImagemPasta({
        nome: arquivo,
        caminho,
        extensao,
        tamanho_kb: U.pyRound(fs.statSync(caminho).size / 1024, 1),
      }));
    }
  }
  return itens;
}

function _dimensoes(caminho) {
  return I.dimensoes(caminho);
}

/**
 * Diz se o arquivo é a arte de conferência do e-mail inteiro, e por quê.
 *
 * Vem junto no pacote com frequência e não faz parte da peça publicada: não
 * é chamada no código nem entra no Content Builder. Tratar como "imagem não
 * utilizada" encheria o report de apontamento que ninguém precisa resolver.
 *
 * Só entra aqui o que NÃO é chamado no HTML — arquivo que o código usa é
 * parte da peça, custe o nome que custar.
 */
function _e_material_de_apoio(imagem, referenciadas, quebra) {
  if (referenciadas.has(imagem.nome.toLowerCase())) return '';

  if (R.buscar(RE_APOIO, PYOS.splitext(imagem.nome)[0])) return 'nome indica arte de conferência';

  if (!imagem.altura || !imagem.largura) {
    [imagem.largura, imagem.altura] = _dimensoes(imagem.caminho);
  }
  if (imagem.largura && imagem.altura / imagem.largura >= PROPORCAO_DE_PECA_INTEIRA) {
    return `proporção de peça inteira (${imagem.largura}x${imagem.altura})`;
  }

  // nome sem a quebra e sem numeração, e ninguém chama: não é peça de montagem
  if (quebra && !imagem.nome.toLowerCase().includes(quebra.toLowerCase())) {
    const base = PYOS.splitext(imagem.nome)[0];
    if (!R.casar(RE_PADRAO, base)) return 'fora da taxonomia e não usado no código';
  }
  return '';
}

function verificar(pasta_imagens, imagens_no_html, quebra = null) {
  const resultado = new ResultadoImagens();
  resultado.arquivos = listar_pasta(pasta_imagens);
  let nomes_pasta = resultado.arquivos.map((i) => i.nome);

  if (quebra) {
    resultado.quebra = R.pyStrip(quebra);
  } else {
    resultado.quebra = _inferir_quebra(nomes_pasta);
    resultado.quebra_inferida = true;
  }

  const referencia = resultado.quebra.toLowerCase();

  // --- material de apoio ---
  // Sai da conferência antes de tudo: não é peça publicada, então não entra
  // em taxonomia, sequência, peso nem cruzamento com o HTML.
  const referenciadas = new Set(imagens_no_html.map((n) => n.toLowerCase()));
  for (const imagem of resultado.arquivos) {
    const motivo = _e_material_de_apoio(imagem, referenciadas, resultado.quebra);
    if (motivo) {
      imagem.apoio = true;
      resultado.material_de_apoio.push([imagem.nome, motivo]);
    }
  }
  resultado.arquivos = resultado.arquivos.filter((i) => !i.apoio);
  nomes_pasta = resultado.arquivos.map((i) => i.nome);

  // --- peso dos arquivos ---
  // Vale para toda imagem da pasta, mesmo a que estiver fora da taxonomia:
  // peso é característica do arquivo, não depende de o nome estar certo.
  for (const imagem of resultado.arquivos) {
    if (imagem.tamanho_kb > regras.LIMITE_IMAGEM_KB) {
      resultado.acima_do_peso.push([imagem.nome, imagem.tamanho_kb]);
    }
  }

  // --- taxonomia e numeração ---
  const numeros = [];
  for (const imagem of resultado.arquivos) {
    const base = PYOS.splitext(imagem.nome)[0];
    const m = R.casar(RE_PADRAO, base);
    if (!m) {
      resultado.fora_da_taxonomia.push([imagem.nome, 'não termina em número sequencial']);
      continue;
    }
    const detectada = R.pyStrip(m.groups.quebra);
    imagem.quebra_detectada = detectada;
    imagem.numero = R.pyInt(m.groups.numero);

    if (referencia && detectada.toLowerCase() !== referencia) {
      resultado.fora_da_taxonomia.push(
        [imagem.nome, `prefixo '${detectada}' difere da quebra '${resultado.quebra}'`]);
      continue;
    }

    if (Array.from(m.groups.numero).length < 2) {
      resultado.sem_numeracao_zero_a_esquerda.push(imagem.nome);
    }

    if (!EXTENSOES_VALIDAS.has(imagem.extensao)) {
      resultado.extensao_invalida.push(`${imagem.nome} (extensão ${imagem.extensao})`);
    }

    numeros.push(imagem.numero);
  }

  if (numeros.length) {
    const contagem = new U.Counter(numeros);
    resultado.numeros_duplicados = U.sorted(contagem.entries().filter(([, c]) => c > 1).map(([n]) => n));
    const maior = Math.max(...numeros);
    const presentes = new Set(numeros);
    resultado.numeros_faltando = [];
    for (let n = 1; n <= maior; n++) if (!presentes.has(n)) resultado.numeros_faltando.push(n);
    resultado.nao_comeca_em_um = !presentes.has(1);
  }

  // --- cruzamento pasta x HTML ---
  resultado.total_referencias_html = imagens_no_html.length;
  const contagem_html = new U.Counter(imagens_no_html.map((n) => n.toLowerCase()));
  resultado.repeticoes_no_html = {};
  for (const [nome, qtd] of contagem_html.entries()) if (qtd > 1) resultado.repeticoes_no_html[nome] = qtd;

  const mapa_pasta = new Map();
  for (const n of nomes_pasta) mapa_pasta.set(n.toLowerCase(), n);
  const mapa_html = new Map();
  for (const nome of imagens_no_html) if (!mapa_html.has(nome.toLowerCase())) mapa_html.set(nome.toLowerCase(), nome);

  for (const [chave, nome_original] of mapa_pasta) {
    if (!mapa_html.has(chave)) resultado.na_pasta_fora_do_html.push(nome_original);
  }

  for (const [chave, nome_original] of mapa_html) {
    if (!mapa_pasta.has(chave)) {
      resultado.no_html_fora_da_pasta.push(nome_original);
    } else if (mapa_pasta.get(chave) !== nome_original) {
      resultado.divergencia_de_caixa.push([mapa_pasta.get(chave), nome_original]);
    }
  }

  return resultado;
}

module.exports = {
  EXTENSOES_VALIDAS, RE_APOIO, PROPORCAO_DE_PECA_INTEIRA, RE_PADRAO, ImagemPasta, ResultadoImagens,
  _inferir_quebra, listar_pasta, _dimensoes, _e_material_de_apoio, verificar,
};
