'use strict';
/**
 * Leitura dos .docx do pacote.
 *
 * Dois papéis diferentes:
 *   CONTEUDO.docx  -> todo o texto legível da peça, na ordem de leitura
 *   ASSUNTO.docx   -> assunto e pré-header
 *
 * A identificação é por nome de arquivo, com heurística por conteúdo quando o
 * analista nomeia fora do padrão.
 */

const R = require('./_pyre');
const { SequenceMatcher } = require('../lib/difflib');
const { lerDocx } = require('../lib/docxreader');
const { sorted, maxPor, pyIsDigit } = require('../lib/pyutil');
const pyos = require('../lib/pyos');
const { limpar, sem_acento } = require('./normalizacao');

const RE_ASSUNTO = R.compilar('assunto|subject|pre.?header|preheader', 'i');
const RE_CONTEUDO = R.compilar('conte.?do|content|texto|alt', 'i');

class LeituraDocx {
  constructor(campos = {}) {
    Object.assign(this, {
      caminho: '',
      papel: 'indefinido',       // "conteudo" | "assunto" | "indefinido"
      paragrafos: [],
      assunto: '',
      pre_header: '',
      links: [],                 // (texto visível, endereço)
      erros: [],
    }, campos);
  }

  texto_completo() {
    return this.paragrafos.join('\n');
  }
}

const DIGITOS_SOBRESCRITOS = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
};

const NS_WORD = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';

/**
 * Monta o texto do parágrafo, com duas coisas que o caminho simples perde.
 *
 * A primeira é a chamada de nota: o Word guarda o "1" de "18x¹" como
 * formatação, não como caractere. Lido direto vira "18x1" e a peça aparece
 * errada no preview, justamente onde se confere se a nota está certa.
 *
 * A segunda é mais grave. O texto dentro de um hyperlink não aparece em
 * paragraph.runs — e some da comparação. Um trecho da peça que o redator
 * colou como link simplesmente não era conferido, sem nenhum aviso. Aqui os
 * dois casos são percorridos no XML, que traz tudo.
 *
 * `paragrafo` é o objeto do docxreader: { text, partes }.
 */
function _texto_com_sobrescrito(paragrafo) {
  const partes = [];
  for (const no of paragrafo.partes) {
    // Shift+Enter e tabulação também precisam sair no texto: é por eles que
    // "Assunto" e "Pré-header" escritos no mesmo bloco continuam separados.
    if (no.tipo === 'br') { partes.push('\n'); continue; }
    if (no.tipo === 'tab') { partes.push(' '); continue; }
    let texto = no.texto || '';
    if (!texto) continue;
    if (no.superscript && pyIsDigit(R.pyStrip(texto))) {
      texto = Array.from(texto).map((c) => (Object.prototype.hasOwnProperty.call(DIGITOS_SOBRESCRITOS, c) ? DIGITOS_SOBRESCRITOS[c] : c)).join('');
    }
    partes.push(texto);
  }
  const montado = partes.join('');
  return R.pyStrip(montado) ? montado : paragrafo.text;
}

/** Lê parágrafos e também o texto dentro de tabelas, que o Word esconde do iterador padrão. */
function _extrair_paragrafos(caminho) {
  const erros = [];
  let documento;
  try {
    documento = lerDocx(caminho);
  } catch (e) {
    // python-docx diz só "Package not found at '<caminho>'", sem o motivo
    let msg = e.message;
    const corte = msg.startsWith("Package not found at '") ? msg.lastIndexOf("': ") : -1;
    if (corte >= 0) msg = msg.slice(0, corte + 1);
    return [[], [`não foi possível abrir: ${msg}`]];
  }

  const linhas = [];
  for (const paragrafo of documento.paragraphs) {
    const texto_do_paragrafo = _texto_com_sobrescrito(paragrafo);
    // Quebra de linha manual (Shift+Enter) fica DENTRO do parágrafo e volta
    // como \n. Sem dividir aqui, "Assunto: X" e "Pré-header: Y" escritos no
    // mesmo bloco viram uma linha só, e o assunto engole o pré-header
    // inteiro. Isso acontece muito quando o pessoal formata em negrito.
    for (const pedaco of texto_do_paragrafo.split('\n')) {
      const texto = limpar(pedaco);
      if (texto) linhas.push(texto);
    }
  }

  for (const tabela of documento.tables) {
    for (const linha of tabela.rows) {
      for (const celula of linha.cells) {
        const texto = limpar(celula.text);
        if (texto && !linhas.slice(-3).includes(texto)) linhas.push(texto);
      }
    }
  }

  return [linhas, erros];
}

/**
 * Acha os hyperlinks do documento.
 *
 * O CONTEUDO.docx é transcrição do que a peça mostra, não um documento
 * navegável. Link ali significa que alguém colou de outro lugar sem limpar a
 * formatação, e o endereço colado costuma ir parar no cadastro junto com o
 * texto.
 */
function _extrair_links(caminho) {
  let documento;
  try {
    documento = lerDocx(caminho);
  } catch (e) {
    return [];
  }

  const achados = [];
  for (const endereco of documento.hyperlinks) {
    if (endereco) achados.push(['', String(endereco)]);
  }

  // o texto visível de cada link, para mostrar no apontamento
  const textos = documento.hyperlinkTexts;

  const completos = [];
  achados.forEach(([_, endereco], indice) => {
    const visivel = indice < textos.length ? textos[indice] : '';
    completos.push([visivel, endereco]);
  });
  return completos;
}

/** Lê o arquivo. O papel, quando não informado, é decidido em identificar_papeis(). */
function ler_docx(caminho, papel = null) {
  const leitura = new LeituraDocx({ caminho });
  [leitura.paragrafos, leitura.erros] = _extrair_paragrafos(caminho);
  leitura.links = _extrair_links(caminho);
  if (papel) {
    leitura.papel = papel;
    if (papel === 'assunto') {
      [leitura.assunto, leitura.pre_header] = _separar_assunto(leitura.paragrafos);
    }
  }
  return leitura;
}

/**
 * O quanto este arquivo se parece com o docx de assunto e pré-header.
 *
 * O nome do arquivo não serve de critério: em pacote real ele costuma ser a
 * quebra, o CPI ou a ação, e não "ASSUNTO" ou "CONTEUDO". O que distingue os
 * dois é o conteúdo — o de assunto é curto e traz os rótulos; o de conteúdo é
 * a peça inteira transcrita.
 */
const RE_P_ASSUNTO = R.compilar('\\bassunto\\b');
const RE_P_PREHEADER = R.compilar('pr[eé].?header|preheader');

function _pontuar_como_assunto(leitura) {
  const corpo = leitura.paragrafos.join(' ').toLowerCase();
  const palavras = R.pySplit(corpo).length;
  let pontos = 0;

  if (R.buscar(RE_ASSUNTO, pyos.basename(leitura.caminho))) pontos += 3;
  if (R.buscar(RE_P_ASSUNTO, corpo)) pontos += 4;
  if (R.buscar(RE_P_PREHEADER, corpo)) pontos += 4;
  if (palavras <= 40) pontos += 3;
  else if (palavras <= 80) pontos += 1;
  if (leitura.paragrafos.length <= 6) pontos += 2;
  if (palavras > 150) pontos -= 5;
  return pontos;
}

/**
 * Decide qual docx é o de conteúdo e qual é o de assunto.
 *
 * Devolve [conteudo, assunto]. Regra, na ordem:
 *   - lê todos e pontua cada um pela cara de "assunto"
 *   - o melhor pontuado vira assunto, desde que passe do limiar
 *   - entre os restantes, o de maior corpo vira o conteúdo
 *   - com um arquivo só, ele é conteúdo, a menos que seja claramente assunto
 */
function identificar_papeis(caminhos) {
  let leituras = caminhos.map((caminho) => ler_docx(caminho));
  leituras = leituras.filter((l) => l.paragrafos.length || !l.erros.length);
  if (!leituras.length) return [null, null];

  const pontuados = sorted(
    leituras.map((l) => [_pontuar_como_assunto(l), -l.paragrafos.join(' ').length, l]),
    (t) => [-t[0], t[1]],
  );

  let assunto = null;
  const [melhor_pontos, , melhor] = pontuados[0];
  // limiar 6: exige pelo menos dois sinais fortes (um rótulo + ser curto),
  // para não promover a assunto um conteúdo que por acaso é pequeno
  if (melhor_pontos >= 6) {
    assunto = melhor;
    assunto.papel = 'assunto';
    [assunto.assunto, assunto.pre_header] = _separar_assunto(assunto.paragrafos);
  }

  const candidatos = leituras.filter((l) => l !== assunto);
  let conteudo = null;
  if (candidatos.length) {
    conteudo = maxPor(candidatos, (l) => l.paragrafos.join(' ').length);
    conteudo.papel = 'conteudo';
  } else if (assunto !== null && leituras.length === 1) {
    // arquivo único com cara de assunto: sem material para comparar o texto
    conteudo = null;
  }

  return [conteudo, assunto];
}

// Rótulos de referência, já sem acento e sem separador. A comparação é por
// similaridade, não por igualdade: em pacote real aparece "Pré-header",
// "Pre header", "Preheader", "Prehead" e uma boa variedade de digitação
// apressada, e nenhuma delas deveria quebrar a leitura.
const ROTULOS_DE_REFERENCIA = {
  assunto: ['assunto', 'subject', 'titulo'],
  pre_header: ['preheader', 'previewtext', 'preview', 'prechamada'],
};

const SIMILARIDADE_MINIMA = 0.72;

const RE_NAO_LETRA = R.compilar('[^a-z]');

/** Deixa só as letras minúsculas sem acento, para comparar grafias. */
function _achatar_rotulo(texto) {
  return R.substituir(RE_NAO_LETRA, sem_acento(texto.toLowerCase()), '');
}

function _classificar_rotulo(candidato) {
  const achatado = _achatar_rotulo(candidato);
  if (achatado.length < 4) return null;
  let melhor_papel = null; let melhor_nota = 0.0;
  for (const [papel, referencias] of Object.entries(ROTULOS_DE_REFERENCIA)) {
    for (const referencia of referencias) {
      const nota = new SequenceMatcher(null, achatado, referencia).ratio();
      if (nota > melhor_nota) { melhor_papel = papel; melhor_nota = nota; }
    }
  }
  return melhor_nota >= SIMILARIDADE_MINIMA ? melhor_papel : null;
}

const RE_ROTULO_DOIS_PONTOS = R.compilar('^([^\\n]{2,28}?)\\s*:\\s*(.+)$');
const RE_ROTULO_TRACO = R.compilar('^([^\\n]{2,28}?)\\s*[-–—]\\s*(.+)$');

/**
 * Devolve [papel, valor] de uma linha do docx de assunto.
 *
 * A ordem das tentativas importa. Os dois-pontos vêm primeiro porque o hífen
 * também faz parte do próprio rótulo — cortar "Pré-header: X" no hífen daria
 * "Pré" como candidato, que é curto demais para reconhecer.
 */
function _identificar_rotulo(linha) {
  linha = R.pyStrip(linha);
  if (!linha) return [null, ''];

  // a linha inteira é o rótulo; o valor vem na linha de baixo
  let papel = _classificar_rotulo(linha);
  if (papel && R.pySplit(linha).length <= 3) return [papel, ''];

  for (const re of [RE_ROTULO_DOIS_PONTOS, RE_ROTULO_TRACO]) {
    const achado = R.casar(re, linha);
    if (achado) {
      papel = _classificar_rotulo(achado[1]);
      if (papel) return [papel, R.pyStrip(achado[2])];
    }
  }

  // sem separador nenhum: "Assunto Seu crédito está liberado"
  const palavras = R.pySplit(linha);
  for (const quantidade of [2, 1]) {
    if (palavras.length > quantidade) {
      const candidato = palavras.slice(0, quantidade).join(' ');
      // o candidato não pode ser bem maior que o rótulo que representa,
      // senão "Pré-header: Simule" casaria e comeria a primeira palavra
      if (_achatar_rotulo(candidato).length <= 14) {
        papel = _classificar_rotulo(candidato);
        if (papel) return [papel, R.pyStrip(palavras.slice(quantidade).join(' '))];
      }
    }
  }
  return [null, linha];
}

/** Separa assunto e pré-header, aceitando tanto 'Assunto: x' quanto linhas soltas. */
function _separar_assunto(paragrafos) {
  let assunto = ''; let pre_header = '';
  let pendente = null;

  for (const linha of paragrafos) {
    const [papel, valor] = _identificar_rotulo(linha);
    if (papel) {
      if (valor) {
        // rótulo e valor na mesma linha
        if (papel === 'assunto' && !assunto) assunto = valor;
        else if (papel === 'pre_header' && !pre_header) pre_header = valor;
        pendente = null;
      } else {
        // rótulo sozinho: o valor vem na linha de baixo
        pendente = papel;
      }
      continue;
    }
    if (pendente === 'assunto' && !assunto) { assunto = linha; pendente = null; }
    else if (pendente === 'pre_header' && !pre_header) { pre_header = linha; pendente = null; }
  }

  // Sem rótulo nenhum, vale a ordem em que costumam ser escritos.
  const restantes = paragrafos.filter((l) => !_identificar_rotulo(l)[0]);
  if (!assunto && restantes.length) assunto = restantes[0];
  if (!pre_header && restantes.length > 1) pre_header = restantes[1];
  return [assunto, pre_header];
}

function localizar_docx(pasta) {
  const encontrados = [];
  for (const [raiz, , arquivos] of pyos.walk(pasta)) {
    for (const arquivo of arquivos) {
      if (arquivo.toLowerCase().endsWith('.docx') && !arquivo.startsWith('~$')) {
        encontrados.push(pyos.join(raiz, arquivo));
      }
    }
  }
  return sorted(encontrados);
}

module.exports = {
  RE_ASSUNTO, RE_CONTEUDO, LeituraDocx, DIGITOS_SOBRESCRITOS, NS_WORD,
  _texto_com_sobrescrito, _extrair_paragrafos, _extrair_links, ler_docx,
  _pontuar_como_assunto, identificar_papeis, ROTULOS_DE_REFERENCIA, SIMILARIDADE_MINIMA,
  _achatar_rotulo, _classificar_rotulo, _identificar_rotulo, _separar_assunto, localizar_docx,
};
