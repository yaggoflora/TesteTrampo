'use strict';
/*
 * Normalização de texto.
 *
 * Tudo que vem de HTML, docx e OCR passa por aqui antes de qualquer comparação.
 * Sem isso, aspas curvas do Word contra aspas retas do HTML viram divergência falsa
 * e o relatório fica cheio de erro que não é erro.
 */

const R = require('./_pyre');

// Substituições de caracteres que o Word, o HTML e o OCR escrevem de formas diferentes
const SUBSTITUICOES = {
  ' ': ' ', // espaço não-quebrável (&nbsp;)
  ' ': ' ',
  ' ': ' ',
  '​': '', // zero-width space
  '﻿': '', // BOM
  '‘': "'", // aspas simples curvas
  '’': "'",
  '‚': "'",
  '“': '"', // aspas duplas curvas
  '”': '"',
  '„': '"',
  '–': '-', // en dash
  '—': '-', // em dash
  '−': '-', // sinal de menos
  '…': '...', // reticências
  '­': '', // hífen suave
  '•': ' ', // bullet
  '·': ' ',
};

// Chamada de nota de rodapé. Vem de três jeitos diferentes na mesma campanha:
// caractere Unicode na peça (¹), <sup> no HTML e sobrescrito de formatação no
// Word — que o python-docx entrega como dígito comum colado na palavra. Sem
// uniformizar, "CDB¹" e "CDB1" viram divergência de texto onde não há nenhuma.
const SOBRESCRITOS = {
  '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4',
  '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9',
  '⁺': '+', '⁻': '-', '⁽': '(', '⁾': ')',
  // subscritos aparecem menos, mas pelo mesmo motivo
  '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
  '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9',
  // asterisco e daga também marcam nota
  '∗': '*', '†': '*', '‡': '*',
};

// NÃO entram em SUBSTITUICOES: limpar() serve também ao texto que aparece no
// relatório e no preview lado a lado, e ali "18x¹" precisa continuar sendo
// "18x¹". A conversão para dígito comum acontece só nas formas de comparação.
function _traduzir(texto, tabela) {
  let saida = '';
  for (const c of texto) saida += Object.prototype.hasOwnProperty.call(tabela, c) ? tabela[c] : c;
  return saida;
}

/** Converte ¹ ² ³ em 1 2 3, para comparar com o que o Word entrega colado. */
function normalizar_sobrescritos(texto) {
  return texto ? _traduzir(texto, SOBRESCRITOS) : texto;
}

// Erros clássicos do OCR em fonte de peça de e-mail
const CORRECOES_OCR = {
  '|': 'l',
  '¦': 'l',
};

function _substituirTudo(texto, de, para) {
  return texto.split(de).join(para);
}

/** Aplica substituições de caracteres e colapsa espaços. Preserva o caso. */
function limpar(texto) {
  if (!texto) return '';
  texto = String(texto).normalize('NFC');
  for (const [de, para] of Object.entries(SUBSTITUICOES)) texto = _substituirTudo(texto, de, para);
  texto = texto.replace(/[ \t\r\f\v]+/g, ' ');
  texto = texto.replace(/\n{2,}/g, '\n');
  return R.pyStrip(texto);
}

const RE_MARCA = /^\p{Mn}$/u;
function sem_acento(texto) {
  const decomposto = String(texto).normalize('NFD');
  let saida = '';
  for (const c of decomposto) if (!RE_MARCA.test(c)) saida += c;
  return saida;
}

const RE_NAO_PALAVRA = R.compilar('[^\\w\\s%$&]');

/**
 * Quebra o texto em palavras comparáveis.
 *
 * A comparação de sequência trabalha em cima desta lista. Manter tokens em vez
 * de caracteres deixa o diff legível: o relatório aponta "palavra X virou Y",
 * não "caractere 4.871 divergente".
 */
function tokenizar(texto, ignorar_acentos = true, ignorar_pontuacao = true) {
  texto = normalizar_sobrescritos(limpar(texto).toLowerCase());
  for (const [de, para] of Object.entries(CORRECOES_OCR)) texto = _substituirTudo(texto, de, para);
  if (ignorar_acentos) texto = sem_acento(texto);
  if (ignorar_pontuacao) {
    // mantém R$, %, dígitos e letras — o resto vira separador
    // & entra junto com % e $: em peça de banco ele carrega sentido
    // ("Crédito & Financiamento"), não é pontuação descartável
    texto = R.substituir(RE_NAO_PALAVRA, texto, ' ');
  }
  return R.pySplit(texto).filter((t) => t);
}

// O CONTEUDO.docx costuma marcar botão entre colchetes — "[Simular crédito]".
// É convenção de escrita do documento, não pontuação da peça: comparar isso
// geraria um apontamento em todo botão de toda campanha.
const RE_MARCACAO_DE_BOTAO = R.compilar('^[\\[\\](){}<>]+|[\\[\\](){}<>]+$');

/**
 * Uma palavra em três formas, porque cada uma serve a um propósito.
 *
 *   chave    -> compara: sem acento, sem pontuação, minúscula.
 *   sensivel -> compara acento e pontuação: minúscula, mas com acento e com
 *               a pontuação que vem colada. Separa "Olá," de "Ola".
 *   texto    -> aparece no relatório: exatamente como está no arquivo.
 */
class Par {
  constructor(campos = {}) {
    Object.assign(this, { chave: undefined, sensivel: undefined, texto: undefined, inicio: 0, fim: 0 }, campos);
  }
}

// um token é uma sequência de letras, dígitos, % ou $; a pontuação colada nele
// é capturada à parte, para conseguirmos apontar vírgula divergente
const RE_TOKEN = R.compilar('[\\w%$&]+');
const RE_PONTUACAO_COLADA = R.compilar('^[.,;:!?)\\]}\\"\'…]+');

/**
 * Mesma segmentação de tokenizar(), mas devolve as três formas de cada palavra.
 *
 * Manter as três juntas é o que permite dizer "a palavra confere, só o acento
 * que não" em vez de tratar tudo como divergência de conteúdo.
 */
function tokenizar_pares(texto, ignorar_acentos = true) {
  const base = limpar(texto);
  // a forma de comparação normaliza o sobrescrito; `base` guarda o original,
  // que é o que aparece no relatório
  let minuscula = normalizar_sobrescritos(base.toLowerCase());
  for (const [de, para] of Object.entries(CORRECOES_OCR)) minuscula = _substituirTudo(minuscula, de, para);

  // Índices em code points, como no Python (o regex do JS conta unidades UTF-16).
  const baseCP = Array.from(base);
  const pares = [];
  let unidades = 0; // posição UTF-16 já convertida
  let codePoints = 0; // code points correspondentes
  const paraCP = (idx) => {
    codePoints += Array.from(minuscula.slice(unidades, idx)).length;
    unidades = idx;
    return codePoints;
  };
  for (const achado of R.todos(RE_TOKEN, minuscula)) {
    const bruto = achado[0];
    const inicio = paraCP(achado.index);
    const fimBruto = inicio + Array.from(bruto).length;
    const chave = ignorar_acentos ? sem_acento(bruto) : bruto;
    if (!chave) continue;
    // pontuação imediatamente depois da palavra, ainda sem espaço no meio
    const depois = Array.from(minuscula.slice(achado.index + bruto.length)).slice(0, 4).join('');
    let sufixo = '';
    const encontrado = R.casar(RE_PONTUACAO_COLADA, depois);
    if (encontrado) sufixo = encontrado[0];
    const nSufixo = Array.from(sufixo).length;
    pares.push(new Par({
      chave,
      sensivel: R.substituir(RE_MARCACAO_DE_BOTAO, bruto + sufixo, ''),
      texto: baseCP.slice(inicio, fimBruto + nSufixo).join(''),
      inicio,
      fim: fimBruto + nSufixo,
    }));
  }
  return pares;
}

/** Versão limpa mas legível, usada no relatório (preserva caso e acento). */
function texto_para_exibicao(texto) {
  return limpar(texto);
}

module.exports = {
  SUBSTITUICOES, SOBRESCRITOS, CORRECOES_OCR, limpar, sem_acento, tokenizar,
  normalizar_sobrescritos, RE_MARCACAO_DE_BOTAO, Par, RE_TOKEN, RE_PONTUACAO_COLADA,
  tokenizar_pares, texto_para_exibicao,
};
