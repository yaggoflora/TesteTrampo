'use strict';
/*
 * Comparação entre a fita de leitura do HTML e o CONTEUDO.docx.
 *
 * Trabalha com sequência, não com conjunto: além de acusar palavra faltando ou
 * trocada, detecta trecho fora de ordem — o caso de a imagem 03 aparecer antes da
 * 02 no HTML, ou de o redator ter digitado os blocos na ordem errada no docx.
 *
 * Cada token carrega a origem (texto vivo ou nome do arquivo de imagem), então o
 * apontamento diz onde olhar em vez de só dizer que não bateu.
 */

const R = require('./_pyre');
const { SequenceMatcher } = require('../lib/difflib');
const { pyRound, sorted, maxPor, pyIsDigit } = require('../lib/pyutil');
const correcao_ocr = require('./correcao_ocr');
const excecoes = require('./excecoes');
const ordenacao = require('./ordenacao');
const regras = require('./regras');
const { tokenizar, tokenizar_pares, Par } = require('./normalizacao');

class Token {
  constructor(campos = {}) {
    Object.assign(this, {
      valor: undefined, // forma de comparação: sem acento nem pontuação
      origem: undefined, // "texto vivo" ou nome do arquivo
      indice_bloco: undefined,
      classificacao: '', // "dispensavel" | "obrigatorio:<rótulo>" | ""
      sensivel: '', // minúscula, com acento e pontuação colada
      texto: '', // exatamente como está no arquivo
    }, campos);
  }
}

class Divergencia {
  constructor(campos = {}) {
    Object.assign(this, {
      tipo: undefined, // "faltando" | "sobrando" | "trocado" | "fora_de_ordem"
      origem: undefined,
      trecho_html: '',
      trecho_docx: '',
      contexto_antes: '',
      contexto_depois: '',
      posicao: 0,
      obrigatorio: '', // rótulo do bloco: disclaimer, opt-out, atendimento
      tolerado: false, // bloco onde a diferença é esperada (redes sociais)
      citacao_html: '', // trecho literal, como está na peça
      citacao_docx: '', // trecho literal, como está no docx
      // só para tipo "acento_pontuacao"
      natureza: '', // "acento" | "pontuacao" | "letras"
      palavras_acento: 0,
      palavras_pontuacao: 0,
      grotesca: false, // passou do limite de regras: reprova
      motivo_grotesca: '',
      // diferença que só avisa (palavra repetida, texto de imagem em parte no docx)
      aviso_leve: false,
      motivo_leve: '',
    }, campos);
  }

  /**
   * "alta" reprova o pacote. "media" pede decisão do analista (atenção).
   * "baixa" é só aviso de diferença: não reprova e não trava.
   *
   * Acento, pontuação e espaçamento só reprovam quando estão grotescos
   * (limites em regras). Abaixo disso são avisos, em qualquer trecho,
   * inclusive nos blocos de disclaimer, opt-out e atendimento.
   */
  get gravidade() {
    if (this.aviso_leve) return 'baixa';
    if (this.tipo === 'acento_pontuacao') return this.grotesca ? 'alta' : 'baixa';
    if (this.tolerado) {
      // bloco de redes sociais: a peça traz o ícone, o docx traz a frase.
      return 'baixa';
    }
    if (this.tipo === 'espacamento') return 'baixa';
    if (this.tipo === 'fora_de_ordem') return 'media';
    if (this.tipo === 'faltando' || this.tipo === 'trocado' || this.tipo === 'sobrando') return 'alta';
    return 'baixa';
  }
}

class ResultadoComparacao {
  constructor(campos = {}) {
    Object.assign(this, {
      similaridade: 0.0,
      total_tokens_html: 0,
      total_tokens_docx: 0,
      tokens_iguais: 0,
      divergencias: [],
      blocos_sem_ocr: [],
      comparacao_parcial: false,
      trechos_dispensados: [],
      obrigatorios_ausentes: [],
      correcoes_ocr: [],
      imagens_reordenadas: [],
    }, campos);
  }

  get aprovado() {
    return this.status === 'aprovado';
  }

  get status() {
    // gravidade vem antes de completude: uma divergência alta reprova mesmo
    // quando parte das imagens não pôde ser lida
    if (this.divergencias.some((d) => d.gravidade === 'alta')) return 'reprovado';
    if (this.comparacao_parcial) return 'parcial';
    if (this.divergencias.some((d) => d.gravidade === 'media')) return 'atencao';
    // sobrou só aviso de diferença (acento, pontuação, espaço): vale como
    // aprovado, e os avisos continuam na tela
    return 'aprovado';
  }

  get avisos_de_diferenca() {
    return this.divergencias.filter((d) => d.gravidade === 'baixa');
  }

  por_gravidade(nivel) {
    return this.divergencias.filter((d) => d.gravidade === nivel);
  }
}

/**
 * Põe a leitura de cada imagem na ordem em que o docx escreveu.
 *
 * Dentro de um banner com layout em blocos não existe ordem de leitura única,
 * e qualquer critério automático erra em alguma peça. A ordem que vale é a de
 * quem escreveu, e ela está no docx.
 *
 * Só acontece quando todas as linhas da imagem foram encontradas lá: assim a
 * reordenação silencia ruído de diagramação sem silenciar erro de conteúdo.
 */
function _alinhar_imagens(fita, paragrafos_docx) {
  const ajustadas = [];
  for (const bloco of fita) {
    if (bloco.tipo !== 'imagem' || !bloco.conteudo || !bloco.ocr_lido) continue;
    const resultado = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx);
    if (resultado.reordenou) {
      bloco.conteudo = resultado.linhas.join('\n');
      bloco.reordenado = true;
      ajustadas.push(bloco.referencia || 'imagem');
    }
  }
  return ajustadas;
}

/**
 * Tira da comparação o texto de template que não precisa constar no docx.
 *
 * O link de fallback do topo — "se não conseguir abrir esse e-mail, clique
 * aqui" — é obrigatório no HTML e opcional no docx. Marcá-lo e deixar na fita
 * não bastava: o alinhamento juntava esses tokens com os da frase seguinte
 * num apontamento só, e a dispensa deixava de valer justamente ali.
 *
 * A remoção só acontece quando o trecho REALMENTE não está no docx. Se o
 * analista escreveu o fallback lá, ele fica e é comparado como qualquer outro
 * texto.
 */
function _remover_dispensaveis(fita, vocabulario) {
  const limpa = [];
  const removidos = [];
  for (const bloco of fita) {
    if (bloco.classificacao !== 'dispensavel') {
      limpa.push(bloco);
      continue;
    }
    const palavras = tokenizar(bloco.conteudo);
    if (!palavras.length) continue;
    const presentes = palavras.filter((p) => vocabulario.has(correcao_ocr.canonizar(p))).length;
    if (presentes / palavras.length >= 0.6) {
      limpa.push(bloco); // está nos dois: compara normalmente
    } else {
      removidos.push(bloco.conteudo);
    }
  }
  return [limpa, removidos];
}

function _tokens_da_fita(fita, vocabulario = null) {
  const tokens = [];
  const sem_ocr = [];
  const corrigidos = [];
  fita.forEach((bloco, indice) => {
    if (bloco.oculto) return;
    let origem;
    if (bloco.tipo === 'imagem') {
      origem = bloco.referencia || 'imagem';
      if (!bloco.ocr_lido) {
        if (bloco.ocr_erro || !bloco.conteudo) {
          // a mesma imagem pode aparecer várias vezes; avisa uma só
          const aviso = `${origem}: ${bloco.ocr_erro || 'sem leitura'}`;
          if (!sem_ocr.includes(aviso)) sem_ocr.push(aviso);
          return;
        }
      }
    } else {
      origem = 'texto vivo';
    }
    let pares = tokenizar_pares(bloco.conteudo);
    // texto vindo de OCR passa pela correção; texto do código, não
    if (bloco.tipo === 'imagem' && vocabulario && vocabulario.size) {
      const chaves = pares.map((p) => p.chave);
      const [corrigidas, separados] = correcao_ocr.corrigir(chaves, vocabulario);
      corrigidos.push(...separados);
      const mudou = corrigidas.length !== chaves.length || corrigidas.some((c, i) => c !== chaves[i]);
      if (mudou) {
        // a correção quebra ou remove tokens, então o vínculo 1 para 1
        // com o texto original se perde; nesse caso o bloco inteiro vira
        // a citação e cada token guarda só a forma de comparação
        pares = pares.length ? corrigidas.map((c) => new Par({ chave: c, sensivel: c, texto: c })) : [];
      }
    }
    for (const par of pares) {
      tokens.push(new Token({
        valor: par.chave, origem, indice_bloco: indice,
        classificacao: bloco.classificacao,
        sensivel: par.sensivel, texto: par.texto,
      }));
    }
  });
  return [tokens, sem_ocr, corrigidos];
}

function _tokens_do_docx(paragrafos) {
  const tokens = [];
  paragrafos.forEach((paragrafo, indice) => {
    // o docx também é classificado: o bloco de redes sociais costuma vir
    // completo só deste lado, e é por aqui que ele é reconhecido
    const classificacao = excecoes.classificar(paragrafo);
    for (const par of tokenizar_pares(paragrafo)) {
      tokens.push(new Token({
        valor: par.chave, origem: 'docx', indice_bloco: indice,
        sensivel: par.sensivel, texto: par.texto,
        classificacao,
      }));
    }
  });
  return tokens;
}

const _terminaEmQuebra = (s) => s.endsWith('\n');

/**
 * Monta a citação literal do trecho, com o texto exatamente como está no
 * arquivo — acento, pontuação e maiúscula preservados.
 *
 * Cita com uma folga de palavras em volta: um apontamento isolado ("prazo")
 * não diz nada a quem vai ler o report. A frase em volta diz.
 */
function _citar(tokens, inicio, fim, origens, folga = 6, limite = 60) {
  if (!origens || !origens.length) return '';
  const inicio_folga = Math.max(0, inicio - folga);
  const fim_folga = Math.min(tokens.length, fim + folga);
  const fatia = tokens.slice(inicio_folga, fim_folga);
  if (!fatia.length) return '';

  const partes = [];
  let bloco_atual = null;
  for (const token of fatia.slice(0, limite)) {
    const palavra = token.texto || token.valor;
    if (bloco_atual === null) {
      bloco_atual = token.indice_bloco;
    } else if (token.indice_bloco !== bloco_atual) {
      partes.push('\n');
      bloco_atual = token.indice_bloco;
    }
    partes.push(palavra);
  }

  let texto = '';
  for (const parte of partes) {
    if (parte === '\n') {
      texto = texto.replace(/[ \t\n\r\f\v\x1c-\x1f\x85\xa0  - \u2028\u2029  　]+$/u, '') + '\n';
    } else {
      texto += (_terminaEmQuebra(texto) || !texto ? '' : ' ') + parte;
    }
  }
  const reticencia_inicio = inicio_folga > 0 ? '… ' : '';
  const reticencia_fim = fim_folga < tokens.length ? ' …' : '';
  return R.pyStrip(reticencia_inicio + R.pyStrip(texto) + reticencia_fim);
}

function _texto(tokens, inicio, fim, limite = 25) {
  let trecho = tokens.slice(inicio, fim).map((t) => t.texto || t.valor);
  if (trecho.length > limite) trecho = trecho.slice(0, limite).concat(['...']);
  return trecho.join(' ');
}

function _origem_dominante(tokens, inicio, fim) {
  const fatia = tokens.slice(inicio, fim);
  if (!fatia.length) return '—';
  const contagem = new Map();
  for (const token of fatia) contagem.set(token.origem, (contagem.get(token.origem) || 0) + 1);
  return maxPor(contagem.keys(), (k) => contagem.get(k));
}

/**
 * Diz se os dois trechos têm exatamente o mesmo conteúdo, só quebrado em
 * palavras de forma diferente.
 *
 * Comparar sem os espaços é o teste: se as sequências de caracteres coincidem,
 * o que mudou foi onde o espaço caiu, não o que está escrito.
 */
function _so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2) {
  const lado_html = tokens_html.slice(i1, i2).map((t) => t.valor).join('');
  const lado_docx = tokens_docx.slice(j1, j2).map((t) => t.valor).join('');
  return !!lado_html && lado_html === lado_docx;
}

const _RE_PONTUACAO = R.compilar('[.,;:!?)\\]}\\"\'\\u2026(\\[{]+');

/** Por imagem: quantas palavras com texto de verdade o OCR leu e quantas estão no docx. */
function _presenca_por_imagem(tokens_html, conjunto_docx) {
  const quadro = Object.create(null);
  for (const token of tokens_html) {
    if (token.origem === 'texto vivo') continue;
    const significativo = Array.from(token.valor).length >= regras.TAMANHO_MINIMO_PALAVRA_IMAGEM;
    if (!significativo) {
      if (!(token.origem in quadro)) quadro[token.origem] = [0, 0];
      continue;
    }
    if (!(token.origem in quadro)) quadro[token.origem] = [0, 0];
    const contagem = quadro[token.origem];
    contagem[0] += 1;
    if (conjunto_docx.has(correcao_ocr.canonizar(token.valor))) contagem[1] += 1;
  }
  return quadro;
}

const _temDigito = (valor) => Array.from(valor).some((c) => pyIsDigit(c));

/**
 * Diz por que um trecho que está no HTML e não no docx vale só como aviso.
 * Devolve "" quando continua sendo erro.
 */
function _motivo_de_aviso(tokens_html, i1, i2, operacao, conjunto_docx, quadro_imagens) {
  const trecho = tokens_html.slice(i1, i2);
  if (!trecho.length) return '';
  // número, taxa, prazo ou valor errado nunca é só aviso
  if (trecho.some((t) => _temDigito(t.valor))) return '';

  // 1. palavra repetida: "Livelo Livelo" no HTML, "Livelo" no docx
  if (operacao === 'delete' && trecho.length <= regras.LIMITE_REPETICAO_PALAVRAS
      && trecho.every((t) => conjunto_docx.has(correcao_ocr.canonizar(t.valor)))
      && !trecho.some((t) => regras.PALAVRAS_QUE_MUDAM_O_SENTIDO.includes(t.valor))) {
    return 'palavra repetida no HTML: ela já aparece no docx';
  }

  // 2. imagem: reprova só se nada do que está escrito nela consta no docx
  const origens = new Set(trecho.map((t) => t.origem));
  if (origens.size === 1) {
    const origem = origens.values().next().value;
    if (origem !== 'texto vivo' && origem in quadro_imagens) {
      const [significativas, presentes] = quadro_imagens[origem];
      if (significativas === 0) return 'a leitura da imagem só tem ruído (ícone ou logotipo)';
      if (presentes >= 1) return 'o texto da imagem aparece só em parte no docx';
    }
  }
  return '';
}

/**
 * O que mudou numa palavra que já casou: "pontuacao" (digitais: x digitais),
 * "acento" (ação x acao) ou "letras" (c0nta x conta: a comparação absorveu a
 * troca por ser confusão típica de OCR, mas em texto escrito no código é erro
 * de escrita de verdade).
 */
function _natureza_da_diferenca(alvo_html, alvo_docx) {
  if (alvo_html.valor !== alvo_docx.valor) return 'letras';
  if (R.substituir(_RE_PONTUACAO, alvo_html.sensivel, '') !== R.substituir(_RE_PONTUACAO, alvo_docx.sensivel, '')) {
    return 'acento';
  }
  return 'pontuacao';
}

/**
 * Decide quais diferenças de acento/pontuação estão grotescas.
 *
 * Cada uma, sozinha, é só aviso. Passa a reprovar quando se acumulam além dos
 * limites de regras, ou quando há letra errada no texto escrito no código.
 */
function _avaliar_forma(divergencias) {
  const formas = divergencias.filter((d) => d.tipo === 'acento_pontuacao');
  const total_acentos = formas.reduce((a, d) => a + d.palavras_acento, 0);
  const total_pontuacao = formas.reduce((a, d) => a + d.palavras_pontuacao, 0);

  for (const d of formas) {
    let motivo = '';
    if (d.natureza === 'letras') {
      motivo = 'letras diferentes no texto do código (escrita errada)';
    } else if (d.palavras_acento >= regras.LIMITE_ACENTOS_NO_TRECHO) {
      motivo = `${d.palavras_acento} palavras com acento diferente no mesmo trecho`;
    } else if (d.palavras_acento && total_acentos >= regras.LIMITE_ACENTOS_NA_PECA) {
      motivo = `${total_acentos} palavras com acento diferente na peça (limite ${regras.LIMITE_ACENTOS_NA_PECA})`;
    } else if (d.palavras_pontuacao && total_pontuacao >= regras.LIMITE_PONTUACAO_NA_PECA) {
      motivo = `${total_pontuacao} palavras com pontuação diferente na peça (limite ${regras.LIMITE_PONTUACAO_NA_PECA})`;
    }
    if (motivo) {
      d.grotesca = true;
      d.motivo_grotesca = motivo;
    }
  }
}

/**
 * Compara acento e pontuação dentro de um trecho que já casou palavra a palavra.
 *
 * Agrupa diferenças vizinhas num apontamento só: uma frase com quatro acentos
 * trocados é um problema, não quatro.
 */
function _diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2) {
  const achados = [];
  let atual = null;
  for (let deslocamento = 0; deslocamento < i2 - i1; deslocamento++) {
    const alvo_html = tokens_html[i1 + deslocamento];
    const alvo_docx = tokens_docx[j1 + deslocamento];
    // Só texto escrito no código entra aqui. OCR erra acento e pontuação
    // por natureza — lê 0 como o, come vírgula, junta ponto de milhar.
    // Cobrar acento de uma leitura de imagem seria inventar divergência.
    if (alvo_html.origem !== 'texto vivo') {
      atual = null;
      continue;
    }
    if (alvo_html.sensivel === alvo_docx.sensivel) {
      atual = null;
      continue;
    }
    if (atual !== null && deslocamento - atual.ultimo <= 3) {
      atual.ultimo = deslocamento;
      atual.pares.push([alvo_html, alvo_docx]);
      continue;
    }
    atual = { inicio: deslocamento, ultimo: deslocamento, pares: [[alvo_html, alvo_docx]] };
    achados.push(atual);
  }

  const divergencias = [];
  for (const achado of achados) {
    const inicio = i1 + achado.inicio;
    const fim = i1 + achado.ultimo + 1;
    const desloc_j = j1 + achado.inicio;
    const fim_j = j1 + achado.ultimo + 1;
    const naturezas = achado.pares.map(([h, d]) => _natureza_da_diferenca(h, d));
    let natureza;
    if (naturezas.includes('letras')) natureza = 'letras';
    else if (naturezas.includes('acento')) natureza = 'acento';
    else natureza = 'pontuacao';
    divergencias.push(new Divergencia({
      tipo: 'acento_pontuacao',
      natureza,
      palavras_acento: naturezas.filter((n) => n === 'acento').length,
      palavras_pontuacao: naturezas.filter((n) => n === 'pontuacao').length,
      origem: _origem_dominante(tokens_html, inicio, fim),
      trecho_html: achado.pares.map(([h]) => h.texto).join(' '),
      trecho_docx: achado.pares.map(([, d]) => d.texto).join(' '),
      posicao: inicio,
      citacao_html: _citar(tokens_html, inicio, fim, tokens_html),
      citacao_docx: _citar(tokens_docx, desloc_j, fim_j, tokens_docx),
    }));
  }
  return divergencias;
}

function comparar(fita, paragrafos_docx, janela_contexto = 6) {
  const resultado = new ResultadoComparacao();

  const vocabulario = correcao_ocr.construir_vocabulario(paragrafos_docx);
  const reordenadas = _alinhar_imagens(fita, paragrafos_docx);
  let dispensados;
  [fita, dispensados] = _remover_dispensaveis(fita, vocabulario);
  const [tokens_html, sem_ocr, corrigidos] = _tokens_da_fita(fita, vocabulario);
  const tokens_docx = _tokens_do_docx(paragrafos_docx);

  resultado.blocos_sem_ocr = sem_ocr;
  resultado.correcoes_ocr = corrigidos;
  resultado.trechos_dispensados = dispensados;
  resultado.imagens_reordenadas = reordenadas;
  resultado.comparacao_parcial = sem_ocr.length > 0;
  resultado.total_tokens_html = tokens_html.length;
  resultado.total_tokens_docx = tokens_docx.length;

  // a comparação usa a forma canônica, que trata confusões de caractere do
  // OCR; o relatório continua exibindo o texto original
  const valores_html = tokens_html.map((t) => correcao_ocr.canonizar(t.valor));
  const valores_docx = tokens_docx.map((t) => correcao_ocr.canonizar(t.valor));

  const matcher = new SequenceMatcher(null, valores_html, valores_docx, false);
  resultado.similaridade = pyRound(matcher.ratio() * 100, 1);

  const faltando = [];
  const sobrando = [];
  const conjunto_docx = new Set(valores_docx);
  const quadro_imagens = _presenca_por_imagem(tokens_html, conjunto_docx);

  for (const [operacao, i1, i2, j1, j2] of matcher.get_opcodes()) {
    if (operacao === 'equal') {
      resultado.tokens_iguais += i2 - i1;
      // A palavra confere, mas pode diferir no acento ou na vírgula.
      // Vira apontamento próprio, de gravidade média: aqui existe margem
      // de tolerância e quem decide é o analista, não a ferramenta.
      resultado.divergencias.push(..._diferencas_de_forma(tokens_html, tokens_docx, i1, i2, j1, j2));
      continue;
    }

    const divergencia = new Divergencia({
      tipo: '',
      origem: i2 > i1 ? _origem_dominante(tokens_html, i1, i2) : 'docx',
      trecho_html: _texto(tokens_html, i1, i2),
      trecho_docx: _texto(tokens_docx, j1, j2),
      contexto_antes: _texto(tokens_html, Math.max(0, i1 - janela_contexto), i1, 10),
      contexto_depois: _texto(tokens_html, i2, i2 + janela_contexto, 10),
      posicao: i1,
      citacao_html: _citar(tokens_html, i1, i2, tokens_html),
      citacao_docx: _citar(tokens_docx, j1, j2, tokens_docx),
    });

    // conjuntos na ordem de inserção (o Python itera set; com mais de um rótulo
    // obrigatório no mesmo trecho a escolha lá depende do hash da execução)
    const classificacoes = new Set(tokens_html.slice(i1, i2).filter((t) => t.classificacao).map((t) => t.classificacao));
    const classificacoes_docx = new Set(tokens_docx.slice(j1, j2).filter((t) => t.classificacao).map((t) => t.classificacao));
    let obrigatorio = '';
    for (const c of classificacoes) {
      if (c.startsWith('obrigatorio')) { obrigatorio = c.split(':').slice(1).join(':'); break; }
    }
    divergencia.obrigatorio = obrigatorio;
    // o bloco tolerado pode estar de qualquer um dos lados: no HTML é só o
    // rótulo com os ícones, no docx é a frase inteira
    divergencia.tolerado = classificacoes.has('tolerado') || classificacoes_docx.has('tolerado');

    // Rede de segurança: o grosso do texto de template já saiu da fita em
    // _remover_dispensaveis; aqui pega o que tenha escapado.
    if (operacao === 'delete' && !obrigatorio && classificacoes.size === 1 && classificacoes.has('dispensavel')) {
      resultado.trechos_dispensados.push(divergencia.trecho_html);
      continue;
    }

    if (operacao === 'delete' && obrigatorio) {
      resultado.obrigatorios_ausentes.push(`${obrigatorio}: ${divergencia.trecho_html}`);
    }

    if (operacao === 'delete') {
      divergencia.tipo = 'faltando'; // está no HTML, não está no docx
      if (!obrigatorio) {
        divergencia.motivo_leve = _motivo_de_aviso(tokens_html, i1, i2, operacao, conjunto_docx, quadro_imagens);
        divergencia.aviso_leve = !!divergencia.motivo_leve;
      }
      faltando.push(divergencia);
    } else if (operacao === 'insert') {
      divergencia.tipo = 'sobrando'; // está no docx, não está no HTML
      sobrando.push(divergencia);
    } else if (_so_muda_espacamento(tokens_html, tokens_docx, i1, i2, j1, j2)) {
      // "36x" contra "36 x", "R$50,00" contra "R$ 50,00": as mesmas
      // letras e dígitos, só o espaço em lugar diferente. Notifica, mas
      // não reprova — espaço a mais ou a menos não muda o que o cliente
      // com deficiência visual escuta.
      divergencia.tipo = 'espacamento';
      resultado.divergencias.push(divergencia);
    } else {
      divergencia.tipo = 'trocado';
      if (!obrigatorio) {
        divergencia.motivo_leve = _motivo_de_aviso(tokens_html, i1, i2, operacao, conjunto_docx, quadro_imagens);
        divergencia.aviso_leve = !!divergencia.motivo_leve;
      }
      resultado.divergencias.push(divergencia);
    }
  }

  // Um mesmo trecho que some de um ponto e reapareça em outro é inversão de
  // ordem, não falta de conteúdo. Reclassificar evita dois apontamentos graves
  // para um problema que é só de posição.
  const chaveOrdenada = (s) => sorted(R.pySplit(s)).join(' ');
  const consumidos_sobrando = new Set();
  for (const ausente of faltando) {
    const chave = chaveOrdenada(ausente.trecho_html);
    for (let indice = 0; indice < sobrando.length; indice++) {
      const excedente = sobrando[indice];
      if (consumidos_sobrando.has(indice)) continue;
      if (chaveOrdenada(excedente.trecho_docx) === chave && chave) {
        ausente.tipo = 'fora_de_ordem';
        ausente.trecho_docx = excedente.trecho_docx;
        consumidos_sobrando.add(indice);
        break;
      }
    }
    resultado.divergencias.push(ausente);
  }

  sobrando.forEach((excedente, indice) => {
    if (!consumidos_sobrando.has(indice)) resultado.divergencias.push(excedente);
  });

  resultado.divergencias = sorted(resultado.divergencias, (d) => d.posicao);
  _avaliar_forma(resultado.divergencias);
  return resultado;
}

/**
 * Confere se o pré-header do docx aparece no HTML — normalmente em div oculta.
 * Diferente do conteúdo, aqui basta conter, porque a ordem não importa.
 */
function comparar_assunto(leitura_assunto, leitura_html) {
  const apontamentos = [];
  if (!leitura_assunto || !leitura_assunto.pre_header) return apontamentos;

  const alvo = new Set(tokenizar(leitura_assunto.pre_header));
  if (!alvo.size) return apontamentos;

  const universo = new Set();
  for (const texto of leitura_html.texto_oculto) for (const t of tokenizar(texto)) universo.add(t);
  for (const bloco of leitura_html.fita) for (const t of tokenizar(bloco.conteudo)) universo.add(t);

  let faltantes = 0;
  for (const t of alvo) if (!universo.has(t)) faltantes++;
  if (faltantes > alvo.size * 0.3) {
    apontamentos.push(new Divergencia({
      tipo: 'faltando',
      origem: 'pré-header',
      trecho_docx: leitura_assunto.pre_header,
      trecho_html: 'não localizado no HTML',
    }));
  }
  return apontamentos;
}

module.exports = {
  Token, Divergencia, ResultadoComparacao, _alinhar_imagens, _remover_dispensaveis,
  _tokens_da_fita, _tokens_do_docx, _citar, _texto, _origem_dominante, _so_muda_espacamento,
  _presenca_por_imagem, _motivo_de_aviso, _natureza_da_diferenca, _avaliar_forma,
  _diferencas_de_forma, comparar, comparar_assunto,
};
