'use strict';
/**
 * Tradutor de padrões do `re` do Python para RegExp do JavaScript (flag u).
 *
 * O que muda de um para o outro e que este arquivo corrige:
 *   \b \B \w \W \d \D \s \S  -> Unicode como no Python (no JS são ASCII, mesmo com u)
 *   $ (sem MULTILINE)        -> casa também antes de um \n final
 *   .                        -> só o \n é excluído (no JS também \r, \u2028, \u2029)
 *   (?P<n>..) (?P=n) \Z \A   -> sintaxe do JS
 *   escapes de identidade    -> o modo u do JS não aceita \" \' \  etc.
 *   re.VERBOSE               -> espaços e comentários removidos
 */

// espaço em branco do Python (str.isspace): igual ao \s do JS, menos o ﻿
const WS_INTERNO = '\\t-\\r\\x1c-\\x20\\x85\\xa0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000';
const PALAVRA = '\\p{L}\\p{N}_';
const FRONTEIRA_PALAVRA = `(?:(?<=[${PALAVRA}])(?![${PALAVRA}])|(?<![${PALAVRA}])(?=[${PALAVRA}]))`;
const NAO_FRONTEIRA = `(?:(?<=[${PALAVRA}])(?=[${PALAVRA}])|(?<![${PALAVRA}])(?![${PALAVRA}]))`;
const SINTAXE = '^$\\.*+?()[]{}|/';

function traduzir(fonte, { ignorecase = false, multiline = false, dotall = false, verbose = false } = {}) {
  fonte = fonte.split('[^\\W\\d_]').join('[\\p{L}\\p{Nl}\\p{No}]');
  let saida = '';
  let emClasse = false;
  for (let i = 0; i < fonte.length; i++) {
    const c = fonte[i];
    if (c === '\\') {
      const n = fonte[++i];
      if (n === undefined) throw new Error('padrão termina em barra');
      if (emClasse) {
        if (n === 'w') saida += PALAVRA;
        else if (n === 'd') saida += '\\p{Nd}';
        else if (n === 's') saida += WS_INTERNO;
        else if (n === 'b') saida += '\\x08';
        else if (n === 'W' || n === 'D' || n === 'S') throw new Error('\\' + n + ' dentro de classe não suportado');
        else if (/[A-Za-z0-9]/.test(n)) saida += '\\' + n;
        else if (n === '-' || n === ']' || n === '\\' || n === '^' || n === '[' || SINTAXE.includes(n)) saida += '\\' + n;
        else saida += n;
      } else {
        if (n === 'b') saida += FRONTEIRA_PALAVRA;
        else if (n === 'B') saida += NAO_FRONTEIRA;
        else if (n === 'w') saida += `[${PALAVRA}]`;
        else if (n === 'W') saida += `[^${PALAVRA}]`;
        else if (n === 'd') saida += '\\p{Nd}';
        else if (n === 'D') saida += '\\P{Nd}';
        else if (n === 's') saida += `[${WS_INTERNO}]`;
        else if (n === 'S') saida += `[^${WS_INTERNO}]`;
        else if (n === 'Z') saida += '(?![\\s\\S])';
        else if (n === 'A') saida += '(?<![\\s\\S])';
        else if (/[A-Za-z0-9]/.test(n)) saida += '\\' + n;
        else if (SINTAXE.includes(n)) saida += '\\' + n;
        else if (n === ' ') saida += '\\x20';
        else if (n === '#') saida += '#';
        else saida += n === '-' ? '\\x2d' : n;
      }
      continue;
    }
    if (emClasse) {
      if (c === ']') emClasse = false;
      saida += c;
      continue;
    }
    if (c === '[') {
      emClasse = true;
      saida += c;
      if (fonte[i + 1] === '^') { saida += '^'; i++; }
      if (fonte[i + 1] === ']') { saida += '\\]'; i++; }
      continue;
    }
    if (verbose) {
      if (/\s/.test(c)) continue;
      if (c === '#') { while (i < fonte.length && fonte[i] !== '\n') i++; continue; }
    }
    if (c === '(' && fonte.startsWith('(?P<', i)) { saida += '(?<'; i += 3; continue; }
    if (c === '(' && fonte.startsWith('(?P=', i)) {
      const fim = fonte.indexOf(')', i);
      saida += '\\k<' + fonte.slice(i + 4, fim) + '>';
      i = fim;
      continue;
    }
    if (c === '$' && !multiline) { saida += '(?=\\n?(?![\\s\\S]))'; continue; }
    if (c === '.') { saida += dotall ? '[\\s\\S]' : '[^\\n]'; continue; }
    saida += c;
  }
  return saida;
}

/** Compila um padrão Python. `flags` aceita 'i', 'm', 's', 'x' (verbose). */
function compilar(fonte, flags = '') {
  const js = traduzir(fonte, {
    ignorecase: flags.includes('i'), multiline: flags.includes('m'),
    dotall: flags.includes('s'), verbose: flags.includes('x'),
  });
  return new RegExp(js, 'u' + (flags.includes('i') ? 'i' : '') + (flags.includes('m') ? 'm' : ''));
}

const _cache = new WeakMap();
function _variante(re, extra) {
  let m = _cache.get(re);
  if (!m) { m = {}; _cache.set(re, m); }
  if (!m[extra]) m[extra] = new RegExp(re.source, re.flags.replace(/[gy]/g, '') + extra);
  return m[extra];
}

/** re.search */
function buscar(re, s) { return _variante(re, '').exec(s); }
/** re.match (ancorado no início) */
function casar(re, s) { const r = _variante(re, 'y'); r.lastIndex = 0; return r.exec(s); }
/** re.finditer -> array de matches (com .index, [0], grupos) */
function todos(re, s) { return Array.from(s.matchAll(_variante(re, 'g'))); }
/** re.sub com texto ou função (recebe o match) */
function substituir(re, s, repl) {
  const g = _variante(re, 'g');
  return s.replace(g, typeof repl === 'function' ? (...a) => repl(a) : () => repl);
}

// ---- utilidades de texto do Python que o JS não tem igual -----------------

const RE_WS_PY = new RegExp(`[${WS_INTERNO}]+`, 'u');
const RE_WS_BORDAS = new RegExp(`^[${WS_INTERNO}]+|[${WS_INTERNO}]+$`, 'gu');
/** str.strip() */
function pyStrip(s) { return String(s).replace(RE_WS_BORDAS, ''); }
/** str.split() sem argumento */
function pySplit(s) { return String(s).split(RE_WS_PY).filter((p) => p !== ''); }
/** str.splitlines() */
function pySplitlines(s) {
  const out = [];
  const re = /\r\n|[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]/gu;
  let ult = 0, m;
  s = String(s);
  while ((m = re.exec(s)) !== null) { out.push(s.slice(ult, m.index)); ult = m.index + m[0].length; }
  if (ult < s.length) out.push(s.slice(ult));
  return out;
}
/** int(str) para dígitos Unicode (Nd) */
function pyInt(s) {
  let v = 0;
  for (const ch of Array.from(s)) {
    const cp = ch.codePointAt(0);
    let d;
    if (cp >= 48 && cp <= 57) d = cp - 48;
    else {
      let ini = cp;
      while (/^\p{Nd}$/u.test(String.fromCodePoint(ini - 1))) ini--;
      d = (cp - ini) % 10;
    }
    v = v * 10 + d;
  }
  return v;
}

module.exports = { traduzir, compilar, buscar, casar, todos, substituir, pyStrip, pySplit, pySplitlines, pyInt, WS_INTERNO };
