'use strict';
/**
 * Leitura do HTML da peça.
 *
 * A ideia central do sistema está aqui: percorrer o DOM na ordem do código e montar
 * uma "fita" única de leitura, intercalando o texto vivo com o texto das imagens na
 * posição exata em que cada imagem aparece. Essa fita é a ordem que o leitor de tela
 * entrega ao cliente — e é contra ela que o CONTEUDO.docx precisa bater.
 */

const fs = require('fs');
const R = require('./_pyre');
const pyos = require('../lib/pyos');
const {
  BeautifulSoup, Tag, NavigableString, Comment, Doctype, Declaration, CData, ProcessingInstruction,
} = require('../lib/pyhtml');

// nós que o parser entrega como texto mas não são conteúdo lido pelo cliente
const NAO_E_TEXTO = [Comment, Doctype, Declaration, CData, ProcessingInstruction];
const _naoETexto = (no) => NAO_E_TEXTO.some((c) => no instanceof c);

const excecoes = require('./excecoes');
const regras = require('./regras');
const { limpar } = require('./normalizacao');

const TAGS_IGNORADAS = new Set(['script', 'style', 'head', 'meta', 'title', 'link', 'noscript']);

// formatos que valem a pena tentar ler
const EXTENSOES_IMAGEM = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']);

const RE_URL_CSS = R.compilar('url\\(\\s*[\'"]?(.*?)[\'"]?\\s*\\)', 'i');

// Pixel de rastreio: não é peça, é medição. Entra no HTML da versão publicada
// (abertura, remarketing, parceiro de mídia) e não tem nada a conferir — nem
// nome de taxonomia, nem texto, nem arquivo na pasta.
const RE_PIXEL_DE_RASTREIO = R.compilar(
  'open\\.aspx|1x1|beacon|pixel|impression|usermatch|/track|utm_|\\.aspx\\b', 'i',
);

/** int(str) do Python; null quando levantaria ValueError. */
function _int_py(texto) {
  const t = R.pyStrip(texto);
  if (!/^[+-]?\p{Nd}+(?:_\p{Nd}+)*$/u.test(t)) return null;
  const negativo = t.startsWith('-');
  const v = R.pyInt(t.replace(/^[+-]/, '').replace(/_/g, ''));
  return negativo ? -v : v;
}

function _e_pixel_de_rastreio(url, elemento) {
  if (R.buscar(RE_PIXEL_DE_RASTREIO, url || '')) return true;
  // imagem declarada com 1 pixel também é medição
  const l = _int_py(String(elemento.get('width', '')) || '0');
  const a = _int_py(String(elemento.get('height', '')) || '0');
  if (l === null || a === null) return false;
  return l > 0 && l <= 2 && a > 0 && a <= 2;
}
// Elementos que separam um parágrafo do outro. Texto dentro de <b>, <span>,
// <a> e afins continua sendo a MESMA frase e precisa ser lido junto.
// Chamada de nota: no HTML vem em <sup>, e o Word entrega o sobrescrito colado
// na palavra. Colar dos dois lados é o que faz "CDB<sup>2</sup>" bater com o
// "CDB2" do docx em vez de virar divergência em toda peça com nota de rodapé.
const TAGS_COLADAS = new Set(['sup', 'sub']);

const TAGS_DE_BLOCO = new Set([
  'p', 'div', 'td', 'th', 'tr', 'table', 'li', 'ul', 'ol',
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'article', 'body',
]);

// <br> quebra a linha, mas NÃO encerra o parágrafo.
//
// Disclaimer real vem num <td> só, com <br> a cada linha visual. Tratando cada
// <br> como bloco novo, o disclaimer virava 45 pedaços soltos: nenhum deles
// casava com os padrões de disclaimer, e a regra do hyperlink deixava de rodar
// justamente onde ela existe para rodar.
const TAGS_DE_QUEBRA = new Set(['br']);

// Espaço duplicado entre palavras na MESMA linha, e espaço solto antes de
// pontuação. Precisa ser na mesma linha: quebra de linha seguida de indentação
// é como o HTML é escrito, não sobra de digitação.
// (escritos à mão: o `[^\S\n\r]` do Python não tem tradução automática)
const _ESP = pyos.ESP;
const _ESP_SEM_QUEBRA = _ESP.replace('\\n', '').replace('\\r', '');
const RE_ESPACO_DUPLO = new RegExp(`[^${_ESP}][${_ESP_SEM_QUEBRA}]{2,}[^${_ESP}]`, 'u');
const RE_ESPACO_ANTES_PONTUACAO = new RegExp(`[^${_ESP}][${_ESP_SEM_QUEBRA}]+[,.;:!?](?:[${_ESP}]|$)`, 'u');
const RE_ESPACOS_MULTIPLOS = new RegExp(`[${_ESP_SEM_QUEBRA}]{2,}`, 'u');

const RE_OCULTO = R.compilar(
  'display\\s*:\\s*none|visibility\\s*:\\s*hidden|max-height\\s*:\\s*0|font-size\\s*:\\s*0', 'i',
);

/** s[:n] do Python (por code point). */
function _fatia(s, n) {
  const a = Array.from(s);
  return a.length <= n ? s : a.slice(0, n).join('');
}

/** Um pedaço da leitura da peça, na ordem em que aparece. */
class BlocoFita {
  constructor(campos = {}) {
    Object.assign(this, {
      tipo: '',                 // "texto" | "imagem"
      conteudo: '',             // texto vivo, ou texto lido da imagem
      referencia: '',           // nome do arquivo, quando for imagem
      alt: '',
      origem: '',               // "src", "background", "style", "srcset"
      oculto: false,
      bruto: '',                // texto sem limpeza: preserva os invisíveis anti-link
      tem_link: false,
      textos_de_link: [],
      remota: false,            // imagem servida por URL, não pelo pacote
      ocr_lido: false,
      ocr_confianca: 0.0,
      ocr_erro: '',
      ocr_aviso: '',
      reordenado: false,
      classificacao: '',        // "dispensavel" | "obrigatorio:<rótulo>" | ""
    }, campos);
  }
}

class LeituraHTML {
  constructor(campos = {}) {
    Object.assign(this, {
      caminho: '',
      fita: [],
      imagens_referenciadas: [],   // com repetição
      imagens_remotas: [],
      pixels_de_rastreio: [],
      texto_oculto: [],
      alts_vazios: [],
      erros: [],
      redirects: 0,
      pagina_de_email: false,
      ruido_de_cliente: [],
      espacos_irregulares: [],
    }, campos);
  }

  get imagens_unicas() {
    const vistos = new Set(); const saida = [];
    for (const nome of this.imagens_referenciadas) {
      const chave = nome.toLowerCase();
      if (!vistos.has(chave)) { vistos.add(chave); saida.push(nome); }
    }
    return saida;
  }

  texto_completo() {
    return this.fita.filter((b) => b.conteudo && !b.oculto).map((b) => b.conteudo).join('\n');
  }
}

// Marcas de página salva de cliente de e-mail. Quem recebe a peça por e-mail e
// usa "salvar como" leva junto a interface inteira do Gmail ou do Outlook — e
// o que interessa, a peça, fica enterrado no meio.
const MARCAS_DE_CLIENTE = [
  'class="[^"]*\\ba3s\\b',          // corpo da mensagem no Gmail
  'gmail_quote|gmail_attr',
  'cb=gapi\\.loaded|cleardot\\.gif',
  'In[íi]cio da mensagem encaminhada',
  'class="[^"]*\\bWordSection1\\b',   // Outlook
];

const RE_MARCAS_DE_CLIENTE = MARCAS_DE_CLIENTE.map((p) => R.compilar(p, 'i'));

// Sobras da interface e do encaminhamento. Vêm junto no "salvar como" e não
// fazem parte da peça: cabeçalho de quem encaminhou, assinatura do celular e
// os botões que o próprio Gmail desenha sobre as imagens.
// Estes não existem em peça nenhuma: são controle do webmail ou cabeçalho de
// encaminhamento. Saem sempre, mesmo quando a página não foi reconhecida como
// salva do Gmail — o corpo extraído continua trazendo esses botões junto.
const RUIDO_SEMPRE = [
  '^fazer o download$',
  '^enviado do meu\\b',
  '^in[íi]cio da mensagem encaminhada',
  '^mensagem encaminhada$',
  '^(de|para|data|cc|cco|enviada em)\\s*:',
];

// Estes são ambíguos. "Baixar" pode ser o botão do Gmail ou o CTA da peça
// ("Baixe o app"), então só saem quando o arquivo é reconhecidamente uma
// página salva de webmail.
const RUIDO_SO_EM_WEBMAIL = [
  '^baixar$|^salvar no drive$|^adicionar ao drive$',
  '^\\d+ anexos?$',
  '^assunto\\s*:',
];

const RE_RUIDO_SEMPRE = RUIDO_SEMPRE.map((p) => R.compilar(p, 'i'));
const RE_RUIDO_SO_EM_WEBMAIL = RUIDO_SO_EM_WEBMAIL.map((p) => R.compilar(p, 'i'));

function e_ruido_de_cliente(texto, webmail = false) {
  const limpo = R.pyStrip(texto || '');
  if (!limpo) return false;
  let padroes = [...RE_RUIDO_SEMPRE];
  if (webmail) padroes = padroes.concat(RE_RUIDO_SO_EM_WEBMAIL);
  for (const linha of R.pySplitlines(limpo)) {
    const l = R.pyStrip(linha);
    if (padroes.some((p) => R.buscar(p, l))) return true;
  }
  return false;
}

/** Diz se o arquivo é a tela do webmail em vez do código da peça. */
function parece_pagina_de_email(codigo) {
  const encontradas = RE_MARCAS_DE_CLIENTE.filter((p) => R.buscar(p, codigo || '')).length;
  return encontradas >= 2;
}

/**
 * Recorta só o corpo da mensagem dentro da página do webmail.
 *
 * Sem isso, o validador leria menu, barra lateral e assinatura do Gmail como
 * se fossem parte da peça. Pega o maior bloco de corpo: numa conversa com
 * resposta ou encaminhamento existe mais de um, e a peça é o mais longo.
 */
function isolar_corpo_da_mensagem(soup) {
  const candidatos = soup.select('div[class*="a3s"], div.WordSection1, div[class*="ii gt"]');
  if (!candidatos.length) return null;
  let melhor = null; let melhorLen = -1;
  for (const e of candidatos) {
    const n = Array.from(e.get_text()).length;
    if (n > melhorLen) { melhor = e; melhorLen = n; }   // max(): o primeiro máximo
  }
  return melhor;
}

/**
 * Diz se a imagem é servida por URL em vez de vir no pacote.
 *
 * Peça já hospedada — o link de teste que o time abre no navegador — aponta
 * para o servidor, não para a pasta. Cobrar esses arquivos na pasta encheria
 * o relatório de "chamada sem arquivo" para a peça inteira.
 */
function _e_remota(url) {
  if (!url) return false;
  const u = R.pyStrip(url).toLowerCase();
  return u.startsWith('http://') || u.startsWith('https://') || u.startsWith('//');
}

/** Extrai só o nome do arquivo de um src, ignorando querystring e caminho. */
function _nome_arquivo_da_url(url) {
  if (!url) return '';
  url = R.pyStrip(url);
  if (url.startsWith('data:')) return '';
  const caminho = pyos.urlparsePath(url) || url;
  const nome = pyos.basename(pyos.unquote(caminho));
  return R.pyStrip(nome);
}

function _esta_oculto(no) {
  let atual = no;
  while (atual instanceof Tag) {
    const estilo = atual.get('style') || '';
    if (R.buscar(RE_OCULTO, String(estilo))) return true;
    if (atual.get('hidden') !== null && atual.get('hidden') !== undefined) return true;
    atual = atual.parent;
  }
  return false;
}

/** Devolve [[url, origem]] de um elemento — cobre src, background e CSS inline. */
function _urls_de_imagem(no) {
  const achados = [];
  if (no.name === 'img') {
    const src = no.get('src') || no.get('data-src') || '';
    if (src) achados.push([src, 'src']);
    const srcset = no.get('srcset') || '';
    for (const parte of String(srcset).split(',')) {
      const url = R.pyStrip(parte).split(' ')[0];
      if (url) achados.push([url, 'srcset']);
    }
  }
  // e-mail usa muito background em <td> e <table>
  const bg = no.get('background');
  if (bg) achados.push([bg, 'background']);
  const estilo = no.get('style') || '';
  for (const m of R.todos(RE_URL_CSS, String(estilo))) achados.push([m[1], 'style']);
  // fallback do Outlook (VML)
  if (no.name && no.name.toLowerCase().endsWith('image')) {
    const src = no.get('src');
    if (src) achados.push([src, 'vml']);
  }
  return achados;
}

function _erro_de_arquivo(e, caminho) {
  const nomes = { ENOENT: [2, 'No such file or directory'], EACCES: [13, 'Permission denied'], EISDIR: [21, 'Is a directory'], ENOTDIR: [20, 'Not a directory'] };
  const [n, msg] = nomes[e.code] || [e.errno ? Math.abs(e.errno) : 5, e.message];
  return `[Errno ${n}] ${msg}: '${caminho}'`;
}

/**
 * Monta a fita de leitura.
 *
 * pasta_imagens: onde procurar o arquivo físico para rodar o OCR.
 * cache_ocr:     instância de CacheOCR; se null, as imagens entram sem texto.
 * (async: a leitura de imagem pelo CacheOCR é assíncrona.)
 */
async function ler_html(caminho_html, pasta_imagens = null, cache_ocr = null, incluir_ocultos = false) {
  const leitura = new LeituraHTML({ caminho: caminho_html });

  let texto_html;
  try {
    const bruto = fs.readFileSync(caminho_html);
    texto_html = bruto.toString('utf8');
  } catch (e) {
    leitura.erros.push(`não foi possível abrir o HTML: ${_erro_de_arquivo(e, caminho_html)}`);
    return leitura;
  }

  // A contagem roda no código bruto, antes de qualquer limpeza: o redirect
  // aparece tanto em href quanto dentro de AMPScript ou atributo de rastreio.
  leitura.redirects = regras.contar_redirects(texto_html);

  let soup = new BeautifulSoup(texto_html, 'html.parser');

  // arquivo salvo do webmail: trabalha só com o corpo da mensagem
  if (parece_pagina_de_email(texto_html)) {
    leitura.pagina_de_email = true;
    const corpo = isolar_corpo_da_mensagem(soup);
    if (corpo !== null) soup = corpo;
  }

  for (const comentario of soup.descendants.filter((s) => s instanceof Comment)) {
    comentario.extract();
  }

  const base = pasta_imagens || pyos.dirnameAbs(caminho_html);
  const ja_registrado = new Set();

  // Acumulador de texto do parágrafo em curso.
  //
  // Sem isto, "<b>nova taxa</b>, confira" vira três nós separados e a vírgula
  // fica sozinha num deles — como pontuação solta não forma palavra, ela some
  // da leitura e o sistema acusa vírgula divergente contra o docx, que tem a
  // frase inteira. Negrito, link e span são formatação, não fim de frase.
  let acumulado = [];   // [texto, cola na palavra anterior]
  let acumulado_bruto = [];
  let acumulado_oculto = false;
  let acumulado_com_link = false;
  let acumulado_links = [];

  const _e_chamada_de_nota = (no_texto) => {
    let atual = no_texto.parent;
    while (atual instanceof Tag) {
      if (TAGS_COLADAS.has(atual.name)) return true;
      if (TAGS_DE_BLOCO.has(atual.name)) return false;
      atual = atual.parent;
    }
    return false;
  };

  const _dentro_de_link = (no_texto) => {
    let atual = no_texto.parent;
    while (atual instanceof Tag) {
      if (atual.name === 'a' && atual.get('href')) return true;
      if (TAGS_DE_BLOCO.has(atual.name)) return false;
      atual = atual.parent;
    }
    return false;
  };

  const _ancestral_de_bloco = (no_texto) => {
    let atual = no_texto.parent;
    while (atual instanceof Tag) {
      if (TAGS_DE_BLOCO.has(atual.name)) return atual;
      atual = atual.parent;
    }
    return null;
  };

  /** Fecha o parágrafo acumulado e o coloca na fita. */
  const fechar_paragrafo = () => {
    if (!acumulado.length) return;
    let texto = '';
    for (const [pedaco, colado] of acumulado) {
      if (!texto) {
        texto = pedaco;
      } else if (pedaco === '\n' || texto.endsWith('\n')) {
        texto = pedaco === '\n' ? texto.replace(/ +$/, '') + pedaco : texto + pedaco;
      } else if (colado || '.,;:!?)]}%'.includes(pedaco[0]) || '([{'.includes(texto[texto.length - 1])) {
        texto += pedaco;          // nota de rodapé e pontuação colam
      } else {
        texto += ' ' + pedaco;
      }
    }
    texto = limpar(texto);
    // cabeçalho de encaminhamento e botão do webmail não são peça
    if (texto && e_ruido_de_cliente(texto, leitura.pagina_de_email)) {
      leitura.ruido_de_cliente.push(_fatia(texto, 90));
      texto = '';
    }
    if (texto) {
      if (acumulado_oculto) leitura.texto_oculto.push(texto);
      if (!acumulado_oculto || incluir_ocultos) {
        leitura.fita.push(new BlocoFita({
          tipo: 'texto', conteudo: texto, oculto: acumulado_oculto,
          classificacao: excecoes.classificar(texto),
          bruto: acumulado_bruto.join(''),
          tem_link: acumulado_com_link,
          textos_de_link: [...acumulado_links],
        }));
      }
    }
    acumulado = [];
    acumulado_bruto = [];
    acumulado_oculto = false;
    acumulado_com_link = false;
    acumulado_links = [];
  };

  let bloco_corrente = null;

  for (const no of soup.descendants) {
    // --- texto vivo ---
    if (no instanceof NavigableString) {
      if (_naoETexto(no)) continue;
      if (no.parent && TAGS_IGNORADAS.has(no.parent.name)) continue;
      const bruto = String(no);
      const conteudo = limpar(bruto);
      if (!conteudo) continue;
      _registrar_espacos(leitura, bruto);
      const oculto = no.parent ? _esta_oculto(no.parent) : false;
      const ancestral = _ancestral_de_bloco(no);
      if ((bloco_corrente !== null && ancestral !== bloco_corrente)
          || (acumulado.length && oculto !== acumulado_oculto)) {
        fechar_paragrafo();
      }
      bloco_corrente = ancestral;
      acumulado_oculto = oculto;
      acumulado.push([conteudo, _e_chamada_de_nota(no)]);
      // o bruto guarda os invisíveis (&#xFEFF;) que impedem o cliente de
      // e-mail de criar link sozinho — limpar() os remove
      acumulado_bruto.push(String(no));
      if (_dentro_de_link(no)) {
        acumulado_com_link = true;
        acumulado_links.push(conteudo);
      }
      continue;
    }

    if (!(no instanceof Tag) || TAGS_IGNORADAS.has(no.name)) continue;

    if (TAGS_DE_QUEBRA.has(no.name)) {
      if (acumulado.length) {
        acumulado.push(['\n', true]);
        acumulado_bruto.push('\n');
      }
      continue;
    }

    // --- imagens ---
    const urls = _urls_de_imagem(no);
    if (!urls.length) continue;

    // a imagem encerra o parágrafo em curso: o que vier depois dela é lido
    // depois pelo leitor de tela
    fechar_paragrafo();
    bloco_corrente = null;
    if (ja_registrado.has(no)) continue;
    ja_registrado.add(no);

    const vistas_no_elemento = new Set();
    for (const [url, origem] of urls) {
      const nome = _nome_arquivo_da_url(url);
      if (!nome || vistas_no_elemento.has(nome.toLowerCase())) continue;
      vistas_no_elemento.add(nome.toLowerCase());
      if (_e_pixel_de_rastreio(url, no)) {
        leitura.pixels_de_rastreio.push(nome);
        continue;
      }
      const remota = _e_remota(url);
      if (remota) {
        if (!leitura.imagens_remotas.includes(nome)) leitura.imagens_remotas.push(nome);
      } else {
        leitura.imagens_referenciadas.push(nome);
      }

      const alt = limpar(no.get('alt') || '');
      if (no.name === 'img' && !alt) leitura.alts_vazios.push(nome);

      const bloco = new BlocoFita({
        tipo: 'imagem', referencia: nome, alt, origem,
        oculto: _esta_oculto(no), remota,
      });

      const extensao = pyos.splitext(nome)[1].toLowerCase();
      if (cache_ocr !== null && cache_ocr !== undefined && EXTENSOES_IMAGEM.has(extensao)) {
        const caminho_fisico = _localizar_arquivo(base, nome);
        if (caminho_fisico) {
          const resultado = await cache_ocr.ler(caminho_fisico);
          bloco.conteudo = resultado.texto;
          bloco.ocr_lido = resultado.lido;
          bloco.ocr_confianca = resultado.confianca_media;
          bloco.ocr_erro = resultado.erro;
          bloco.ocr_aviso = resultado.aviso;
        } else {
          bloco.ocr_erro = 'arquivo não encontrado na pasta de imagens';
        }
      }

      bloco.classificacao = excecoes.classificar(bloco.conteudo || bloco.alt);
      leitura.fita.push(bloco);
    }
  }

  fechar_paragrafo();
  return leitura;
}

/**
 * Anota espaço duplicado ou espaço antes de pontuação no texto da peça.
 *
 * Não vira divergência: a comparação já ignora espaçamento, e isso não muda
 * o que o leitor de tela entrega. Fica como observação porque é o tipo de
 * detalhe que passa batido na revisão e aparece feio na caixa de entrada.
 */
function _registrar_espacos(leitura, bruto) {
  for (const linha of R.pySplitlines(bruto)) {
    if (leitura.espacos_irregulares.length >= 8) return;
    const trecho = R.pyStrip(linha);
    if (Array.from(trecho).length < 4) continue;
    if (R.buscar(RE_ESPACO_DUPLO, trecho) || R.buscar(RE_ESPACO_ANTES_PONTUACAO, trecho)) {
      const amostra = _fatia(R.substituir(RE_ESPACOS_MULTIPLOS, trecho, ' ␣ '), 90);
      if (!leitura.espacos_irregulares.includes(amostra)) leitura.espacos_irregulares.push(amostra);
    }
  }
}

/** Procura o arquivo na pasta ignorando maiúscula/minúscula e subpastas. */
function _localizar_arquivo(pasta, nome) {
  const alvo = nome.toLowerCase();
  for (const [raiz, , arquivos] of pyos.walk(pasta)) {
    for (const arquivo of arquivos) {
      if (arquivo.toLowerCase() === alvo) return pyos.join(raiz, arquivo);
    }
  }
  return null;
}

module.exports = {
  NAO_E_TEXTO, TAGS_IGNORADAS, EXTENSOES_IMAGEM, RE_URL_CSS, RE_PIXEL_DE_RASTREIO,
  _e_pixel_de_rastreio, TAGS_COLADAS, TAGS_DE_BLOCO, TAGS_DE_QUEBRA, RE_ESPACO_DUPLO,
  RE_ESPACO_ANTES_PONTUACAO, RE_OCULTO, BlocoFita, LeituraHTML, MARCAS_DE_CLIENTE,
  RE_MARCAS_DE_CLIENTE, RUIDO_SEMPRE, RUIDO_SO_EM_WEBMAIL, RE_RUIDO_SEMPRE,
  RE_RUIDO_SO_EM_WEBMAIL, e_ruido_de_cliente, parece_pagina_de_email,
  isolar_corpo_da_mensagem, _e_remota, _nome_arquivo_da_url, _esta_oculto, _urls_de_imagem,
  ler_html, _registrar_espacos, _localizar_arquivo,
};
