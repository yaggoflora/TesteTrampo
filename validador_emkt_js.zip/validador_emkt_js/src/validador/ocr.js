'use strict';
/**
 * Leitura do texto contido nas imagens.
 *
 * Motores, testados em cascata. O sistema usa o primeiro que estiver
 * disponível na máquina, sem você precisar configurar nada:
 *
 *   1. rapidocr      — modelos PP-OCR (os mesmos do RapidOCR) rodando em onnxruntime, pelo
 *                      pacote opcional `@gutenye/ocr-node` (npm install @gutenye/ocr-node).
 *                      NÃO TESTADO neste ambiente (sem rede para instalar o pacote).
 *   2. windows       — OCR nativo do Windows 10/11, chamado pelo PowerShell (WinRT).
 *                      NÃO TESTADO neste ambiente (não é Windows).
 *   3. tesseract     — o programa `tesseract` instalado na máquina (TESSERACT_CMD aponta
 *                      para versão portátil). É o motor testado de ponta a ponta.
 *   4. tesseract-js  — Tesseract em WebAssembly, pelo pacote opcional `tesseract.js`
 *                      (npm install tesseract.js). Funciona em servidor SEM instalar programa.
 *                      NÃO TESTADO neste ambiente.
 *
 * Para forçar um motor específico, defina a variável de ambiente OCR_MOTOR com "rapidocr",
 * "windows", "tesseract" ou "tesseract-js".
 *
 * Diferenças em relação ao Python (de propósito):
 *   - PIL/numpy foram trocados por src/lib/imgutil.js (reamostragem, cinza e contraste puros e
 *     idênticos ao Pillow; decodificação com `sharp`, que é opcional e carregado sob demanda).
 *   - O estado do módulo (_ESCOLHIDO, PASTA_CACHE, _FONTES_DO_SCRIPT, VERSAO_DA_LEITURA ...) vive
 *     em `module.exports`, para os testes poderem trocá-lo como faziam no Python (`ocr.PASTA_CACHE = x`).
 *   - O RapidOCR antigo (`rapidocr-antigo`) não existe mais; o nome "rapidocr" cobre o motor PP-OCR.
 *   - `instalar_idioma_por` é assíncrono (rede).
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync, execFile } = require('child_process');

const R = require('./_pyre');
const { limpar } = require('./normalizacao');
const U = require('../lib/pyutil');
const I = require('../lib/imgutil');

const M = module.exports;

// Pasta do projeto: cache de leitura e tessdata ficam aqui (ou em VALIDADOR_PASTA_DE_DADOS).
const PASTA_DO_PROJETO = process.env.VALIDADOR_PASTA_DE_DADOS
  ? path.resolve(process.env.VALIDADOR_PASTA_DE_DADOS)
  : path.resolve(__dirname, '..', '..');

class ResultadoOCR {
  constructor(campos = {}) {
    Object.assign(this, {
      arquivo: '', texto: '', lido: false, erro: '', aviso: '', motor: '', confianca_media: 0.0, linhas: [],
    }, campos);
    if (campos.linhas === undefined) this.linhas = [];
  }
}
const CAMPOS_RESULTADO = ['arquivo', 'texto', 'lido', 'erro', 'aviso', 'motor', 'confianca_media', 'linhas'];

// ---------------------------------------------------------------- utilidades

/**
 * Abre a imagem e corrige orientação.
 *
 * O aumento de escala NÃO acontece aqui: quem amplia é o fatiamento, já com
 * a faixa recortada. Ampliar duas vezes só borra a letra.
 */
async function _preparar(caminho, largura_minima = 0) {
  let img = await I.abrir(caminho);
  if (largura_minima && img.width < largura_minima) {
    const fator = largura_minima / img.width;
    // LANCZOS de propósito: o padrão do resize borra a borda das letras e o
    // motor passa a inventar caractere — "Simular agora" virava "Simular a
    // agora" num upscale de apenas 1,1x.
    img = I.redimensionar(img, Math.trunc(img.width * fator), Math.trunc(img.height * fator), 'LANCZOS');
  }
  return img;
}

const MAXIMO_FRAMES_LIDOS = 10;
// Fração mínima de pixels que precisa mudar para o frame contar como cena nova.
// Média de diferença não serve aqui: em banner de fundo claro, trocar a frase
// inteira mexe em poucos por cento dos pixels e a média mal se move.
const MUDANCA_MINIMA_ENTRE_FRAMES = 0.01; // 1% dos pixels
const DIFERENCA_POR_PIXEL = 40;           // 0-255: o quanto um pixel precisa mudar

/** Miniatura em cinza usada só para comparar frames entre si. */
function _assinatura(imagem) {
  return Array.from(I.redimensionar(I.cinza(imagem), 64, 64, 'BILINEAR').data);
}

/**
 * Escolhe quais frames de um GIF vale a pena ler.
 *
 * Um GIF de peça costuma ter dezenas de frames para poucas cenas de texto:
 * ler todos custaria mais de um minuto por imagem sem acrescentar nada. Aqui
 * só entram os frames que mudaram de verdade em relação ao último lido, e no
 * máximo dez — o suficiente para pegar todas as cenas de uma peça de e-mail.
 */
async function _frames_relevantes(caminho) {
  const total = I.numFramesGif(caminho);
  if (total <= 1) return [await I.abrir(caminho)];

  const paginas = Math.max(total, await I.contarPaginas(caminho));
  const escolhidos = [];
  let ultima = null;
  for (let i = 0; i < paginas; i++) {
    const atual = await I.abrirFrame(caminho, i);
    const assinatura = _assinatura(atual);
    if (ultima !== null) {
      let mudados = 0;
      const n = Math.min(assinatura.length, ultima.length);
      for (let k = 0; k < n; k++) if (Math.abs(assinatura[k] - ultima[k]) > DIFERENCA_POR_PIXEL) mudados++;
      if (mudados / assinatura.length < MUDANCA_MINIMA_ENTRE_FRAMES) continue;
    }
    escolhidos.push(atual.copy());
    ultima = assinatura;
    if (escolhidos.length >= MAXIMO_FRAMES_LIDOS) break;
  }
  return escolhidos.length ? escolhidos : [await I.abrir(caminho)];
}

/**
 * Junta o texto das cenas do GIF sem repetir o que já apareceu.
 *
 * Dois tipos de repetição acontecem aqui. A primeira é a frase que se repete
 * em frames vizinhos — basta descartar a igual. A segunda é a animação de
 * digitação, em que a mesma frase entra aos pedaços: "COMPROMISSO", depois
 * "e TRANSPA", depois "e TRANSPARENCIA com sua empresa". Guardar todos os
 * pedaços encheria a fita de fragmentos que não existem no docx, então fica
 * só a versão mais completa de cada frase.
 */
function _juntar_textos(blocos) {
  const { tokenizar } = require('./normalizacao');
  const R_ = require('./_pyre');

  const candidatos = [];
  for (const bloco of blocos) {
    for (const linha of R_.pySplitlines(bloco)) {
      const limpa = R_.pyStrip(linha);
      const chave = tokenizar(limpa).join(''); // sem espaços: o OCR varia neles
      if (!chave) continue;
      candidatos.push([chave, limpa]);
    }
  }

  // descarta o que está contido em outra linha — o pedaço da animação
  const finais = [];
  for (const [chave, texto] of candidatos) {
    const contido_em_outro = candidatos.some(([outra]) => chave !== outra && outra.includes(chave));
    if (contido_em_outro) continue;
    if (finais.some(([vista]) => chave === vista)) continue;
    finais.push([chave, texto]);
  }
  return finais.map(([, texto]) => texto).join('\n');
}

// O detector do motor encolhe a imagem inteira para caber em cerca de 960 px no
// lado maior. Peça de e-mail é uma tira alta e estreita: uma fatia de 900x2600
// é reduzida a 900x960 e o texto de 20 px vira 7 px — ilegível. Ler em faixas
// preserva a resolução do texto.
const ALTURA_MAXIMA_POR_FATIA = 900;
const SOBREPOSICAO_ENTRE_FATIAS = 120; // px repetidos, para não cortar linha no meio
const ALTURA_MINIMA_DO_TEXTO = 26;     // abaixo disso o reconhecimento erra caractere
const CONFIANCA_PARA_ALERTAR = 80;     // abaixo disso a imagem entra em Observações

// Peça de e-mail é cheia de ícone e pictograma — calendário, cadeado, cifrão,
// selo. O detector não sabe distinguir desenho de letra: ele acha uma forma
// parecida com texto e o reconhecedor devolve o palpite mais próximo. O
// calendário desta campanha virava "口" numa escala e "D000 000" na outra.
// Formatos que aparecem de verdade em peça e que NÃO têm letra nenhuma. Eles
// costumam ser o dado mais importante da imagem — o percentual da oferta, a
// data da estreia, o telefone da central — e não podem ser descartados por
// falta de letra.
const RE_CONTEUDO_SEM_LETRA = R.compilar(String.raw`
      ^\d{1,3}\s?%$                                   # 50%   20 %
    | ^\d{1,2}[/.\-]\d{1,2}([/.\-]\d{2,4})?[:.]?$     # 10/09:  03/09/2026
    | ^R?\$?\s?\d{1,3}([.\s]\d{3})*([,]\d{2})?$      # R$ 50.000,00
    | ^\d{3,5}[\s-]?\d{3,4}$                          # 4002 0022 · 0800 570
    | ^\d{1,3}\s?[xX]$                                # 36x
    | ^\d{1,2}[hH]$                                    # 22h
    | ^[+\-]?\d{1,4}[.,]\d{1,2}$                      # 1,29
`, 'x');

// Dígito ou símbolo repetido é assinatura de contorno de ícone lido como texto:
// "000", "0 0000 000", "...."
// ^([\W\d_])[\s]*(\1[\s]*)+$ do Python, escrito à mão (\W dentro de classe o tradutor não faz)
const RE_REPETICAO_BOBA = new RegExp(
  `^([^\\p{L}\\p{N}_]|[\\p{Nd}_])[${R.WS_INTERNO}]*(\\1[${R.WS_INTERNO}]*)+(?=\\n?(?![\\s\\S]))`, 'u');

const CONFIANCA_MINIMA_SEM_LETRA = 88;

/**
 * Converte para número o que o motor devolveu como confiança.
 *
 * Versões diferentes do RapidOCR entregam esse campo de jeitos diferentes:
 * umas como float, outras como string ("0.98"). Comparar string com número
 * quebra a leitura inteira da imagem, e o erro aparece como "sem texto lido"
 * — parecendo falha do OCR quando é só um tipo diferente.
 */
function _como_numero(valor, padrao = 0.0) {
  if (typeof valor === 'number') return valor;
  if (typeof valor === 'boolean') return valor ? 1 : 0;
  let s = R.pyStrip(String(valor)).replace(',', '.');
  // float() aceita dígitos Unicode (٣ = 3)
  s = s.replace(/\p{Nd}/gu, (d) => String(R.pyInt(d)));
  // float() do Python: aceita "0.98", "1e3", "inf", "nan", "1_0"; recusa vazio e lixo
  if (/^[+-]?(inf|infinity)$/i.test(s)) return s[0] === '-' ? -Infinity : Infinity;
  if (/^[+-]?nan$/i.test(s)) return NaN;
  if (/^[+-]?(\d+(_\d+)*)?\.?(\d+(_\d+)*)?([eE][+-]?\d+(_\d+)*)?$/.test(s) && /\d/.test(s)) {
    return Number(s.replace(/_/g, ''));
  }
  return padrao;
}

const _RE_LETRA = /\p{L}/u;
function _tem_letra(texto) {
  return _RE_LETRA.test(texto);
}

// unicodedata.name(c).startswith("LATIN"): letras do alfabeto latino, SEM as de nome
// diferente (ª º, letras modificadoras, K de Kelvin, formas de largura total...).
const _RE_SCRIPT_LATIN = /\p{Script=Latin}/u;
// (tabela gerada comparando com o unicodedata do Python 3.13 / Unicode 15.1)
const _NOME_NAO_LATIN = [
  [0xaa, 0xaa], [0xba, 0xba], [0x2b0, 0x2b8], [0x2e0, 0x2e4], [0x1d2c, 0x1d5c], [0x1d9b, 0x1dbe], [0x2071, 0x2071],
  [0x207f, 0x207f], [0x212a, 0x212b], [0x2132, 0x2132], [0x214e, 0x214e], [0x2183, 0x2183], [0x2c7d, 0x2c7d],
  [0xa770, 0xa770], [0xa7f2, 0xa7f4], [0xa7f8, 0xa7f9], [0xab5c, 0xab5f], [0xab69, 0xab69], [0xff21, 0xff3a],
  [0xff41, 0xff5a], [0x10780, 0x10785], [0x10787, 0x107b0], [0x107b2, 0x107ba],
];
function _nome_comeca_com_latin(c) {
  if (!_RE_SCRIPT_LATIN.test(c)) return false;
  const cp = c.codePointAt(0);
  return !_NOME_NAO_LATIN.some(([a, b]) => cp >= a && cp <= b);
}

/** Caractere que não existe em peça escrita em português. */
function _fora_do_alfabeto(texto) {
  for (const caractere of texto) {
    if (_RE_LETRA.test(caractere)) {
      const baixo = caractere.toLowerCase();
      if (!('a' <= baixo && baixo <= 'z')) {
        // letra acentuada é latina; CJK, cirílico e afins não são
        if (_nome_comeca_com_latin(caractere)) continue;
        return true;
      }
    }
    if (/\p{So}/u.test(caractere)) return true; // símbolo/pictograma
  }
  return false;
}

/**
 * Diz se a caixa é desenho lido como texto.
 *
 * Descartar é mais seguro do que manter: um ícone fantasma entra na
 * comparação como palavra inventada e vira apontamento que ninguém consegue
 * resolver, porque não existe nada para corrigir na peça.
 */
function _e_ruido_de_icone(texto, confianca) {
  const limpo = R.pyStrip(String((texto === null || texto === undefined || texto === '' || texto === 0 || texto === false) ? '' : texto));
  confianca = _como_numero(confianca);
  if (!limpo) return true;
  if (_fora_do_alfabeto(limpo)) return true;

  // Repetição do mesmo caractere vem antes de tudo: "000" casaria como valor
  // monetário e escaparia do filtro, mas é contorno de ícone.
  if (!_tem_letra(limpo) && R.casar(RE_REPETICAO_BOBA, limpo)) return true;

  // Percentual, data, valor e telefone ficam, custe o que custar: é o dado
  // mais importante da imagem. Descartá-los por confiança apagava justamente
  // o "50%" da oferta e o "10/09:" da estreia.
  if (R.casar(RE_CONTEUDO_SEM_LETRA, limpo.split('  ').join(' '))) return false;

  if (_tem_letra(limpo)) return Array.from(limpo).length <= 2 && confianca < CONFIANCA_MINIMA_SEM_LETRA;

  // sem letra e sem formato reconhecível: só passa com confiança alta
  return confianca < CONFIANCA_MINIMA_SEM_LETRA;
}

// ----------------------------------------------- leitura em várias variantes
//
// O pipeline clássico de OCR (aquisição, pré-processamento, detecção, extração,
// classificação, pós-processamento) trata o pré-processamento como etapa
// própria — e é justamente a que estava faltando aqui. Peça de e-mail varia
// demais: texto branco sobre foto, título fino sobre fundo claro, bloco
// pequeno em cima de gradiente. Nenhum preparo único serve para todos.
//
// Em vez de escolher um, lê-se a mesma fatia em algumas variantes e funde-se o
// resultado, ficando com a melhor leitura de cada região. É o mesmo princípio
// de combinar classificadores: cada variante erra em lugares diferentes.

const LIMIAR_ESCURA = 110; // abaixo disso a imagem é escura e vale inverter
const SOBREPOSICAO_MESMA_CAIXA = 0.55;

function _luminancia_media(imagem) {
  return I.luminanciaMedia(imagem);
}

/**
 * Versões da mesma fatia para ler em paralelo.
 *
 * Na leitura rápida vai só o original. Quando ele vem fraco — pouca coisa
 * lida ou confiança baixa — entram as outras, que custam tempo mas resgatam
 * texto que o preparo padrão perde.
 */
function _variantes_de_leitura(imagem, completa) {
  const saida = [['original', imagem]];
  if (!completa) return saida;

  // Texto claro sobre fundo escuro: o detector foi treinado sobretudo em
  // texto escuro sobre claro, e inverter devolve a polaridade esperada.
  if (_luminancia_media(imagem) < LIMIAR_ESCURA) {
    const invertida = I.paraRgb(I.inverter(I.cinza(imagem)));
    saida.push(['invertida', invertida]);
  }

  saida.push(['contraste', I.autocontraste(imagem, 1)]);
  saida.push(['nitidez', I.nitidez(imagem, 2, 140, 3)]);
  return saida;
}

/**
 * Decide se a fatia merece uma segunda passada com pré-processamento.
 *
 * O limiar é baixo de propósito. Medindo contra o gabarito, as variantes de
 * pré-processamento NÃO reduziram o erro das peças testadas e dobraram o
 * tempo: o que restava de divergência era acento, que o reconhecedor não
 * emite e a comparação já ignora dos dois lados. Então elas ficam como
 * resgate — fatia que não devolveu nada, ou devolveu com confiança baixa
 * demais para merecer crédito.
 */
function _leitura_fraca(caixas, fatia) {
  if (!caixas.length) return true;
  const confianca = caixas.reduce((s, c) => s + c.confianca, 0) / caixas.length;
  return confianca < 78;
}

/** Diz se duas caixas cobrem o mesmo pedaço da imagem. */
function _mesma_regiao(a, b) {
  const largura = Math.min(a.direita, b.direita) - Math.max(a.esquerda, b.esquerda);
  const altura = Math.min(a.base, b.base) - Math.max(a.topo, b.topo);
  if (largura <= 0 || altura <= 0) return false;
  const intersecao = largura * altura;
  const area_a = Math.max(1.0, (a.direita - a.esquerda) * (a.base - a.topo));
  const area_b = Math.max(1.0, (b.direita - b.esquerda) * (b.base - b.topo));
  return intersecao / Math.min(area_a, area_b) >= SOBREPOSICAO_MESMA_CAIXA;
}

/**
 * Junta as caixas das variantes, ficando com a melhor leitura de cada região.
 *
 * Região que só uma variante enxergou entra assim mesmo — é texto que as
 * outras perderam. Região vista por várias fica com a de maior confiança;
 * empatando, com a que leu mais caracteres, porque o erro típico do motor é
 * cortar o fim da frase, não inventar.
 */
function _fundir_leituras(leituras) {
  const final = [];
  for (const caixas of leituras) {
    for (const caixa of caixas) {
      let achou = false;
      for (let indice = 0; indice < final.length; indice++) {
        const escolhida = final[indice];
        if (!_mesma_regiao(caixa, escolhida)) continue;
        const atual = [escolhida.confianca, Array.from(escolhida.texto).length];
        const nova = [caixa.confianca, Array.from(caixa.texto).length];
        if (U.compararPy(nova, atual) > 0) final[indice] = caixa;
        achou = true;
        break;
      }
      if (!achou) final.push(caixa);
    }
  }
  return final;
}

/**
 * Realça a faixa para uma segunda tentativa.
 *
 * Texto branco sobre área clara da foto — céu, parede, fachada — tem contraste
 * baixo e o detector simplesmente não acha a caixa. Esticar o histograma e
 * reforçar a borda das letras costuma resolver, e só roda quando a primeira
 * leitura não achou nada, então não pesa no caso comum.
 */
function _realcar(imagem) {
  let realcada = I.autocontraste(I.paraRgb(imagem), 1);
  realcada = I.contraste(realcada, 1.6);
  return I.nitidez(realcada, 2, 140, 2);
}

/** Divide a imagem em faixas horizontais com sobreposição. */
function _fatias_da_imagem(imagem) {
  const largura = imagem.width, altura = imagem.height;
  const limite = Math.max(ALTURA_MAXIMA_POR_FATIA, largura);
  if (altura <= limite) return [[imagem, 0]];

  const passo = limite - SOBREPOSICAO_ENTRE_FATIAS;
  const fatias = [];
  let topo = 0;
  while (topo < altura) {
    const base = Math.min(altura, topo + limite);
    fatias.push([I.recortar(imagem, 0, topo, largura, base), topo]);
    if (base >= altura) break;
    topo += passo;
  }
  return fatias;
}

/**
 * Lê a imagem em faixas e devolve as caixas já com a posição real.
 *
 * A sobreposição faz a mesma linha aparecer em duas faixas; a deduplicação
 * compara texto e posição para não repetir o trecho na leitura final.
 */
async function _caixas_em_fatias(motor, imagem, idioma, confianca_minima) {
  const todas = [];
  // Fatiar resolve o encolhimento do detector antigo. O detector novo lê a
  // peça alta inteira e, em fatia, junta colunas vizinhas numa caixa só —
  // aí a análise de layout fica sem corredor para separar.
  let fatias;
  if (motor.prefere_imagem_inteira) fatias = [[imagem, 0]];
  else fatias = _fatias_da_imagem(imagem);

  for (let [fatia, deslocamento] of fatias) {
    // o reconhecimento erra caractere quando a letra fica pequena demais;
    // ampliar a faixa antes de ler recupera "50%" que virava "SOVO"
    let escala = 1.0;
    if (fatia.width < 1400) {
      escala = Math.min(2.5, 1400 / fatia.width);
      fatia = I.redimensionar(fatia, Math.trunc(fatia.width * escala), Math.trunc(fatia.height * escala), 'LANCZOS');
    }
    const ler = async (variantes) => {
      const leituras = [];
      for (const [, variante] of variantes) {
        let caixas;
        try {
          caixas = await motor.caixas(variante, idioma, confianca_minima);
        } catch (e) {
          continue;
        }
        for (const caixa of caixas) {
          for (const campo of ['topo', 'base', 'esquerda', 'direita', 'confianca']) {
            caixa[campo] = _como_numero(campo in caixa ? caixa[campo] : 0);
          }
        }
        leituras.push(caixas.filter((c) => !_e_ruido_de_icone(c.texto, 'confianca' in c ? c.confianca : 0)));
      }
      return _fundir_leituras(leituras);
    };

    let achadas = await ler(_variantes_de_leitura(fatia, false));

    // Só vale pagar o preço das variantes quando a leitura simples veio
    // fraca — em peça bem comportada elas não acrescentam nada e triplicam
    // o tempo.
    if (_leitura_fraca(achadas, fatia)) {
      achadas = await ler(_variantes_de_leitura(fatia, true));
    }
    if (!achadas.length) {
      let tentativa;
      try {
        tentativa = await motor.caixas(_realcar(fatia), idioma, confianca_minima);
      } catch (e) {
        tentativa = [];
      }
      tentativa = tentativa.filter((c) => !_e_ruido_de_icone(c.texto, 'confianca' in c ? c.confianca : 0));
      // o realce força o detector a achar forma onde não há texto: só
      // vale a tentativa se ela trouxer palavra de verdade
      if (tentativa.some((c) => /[\p{L}\p{Nl}\p{No}]{3,}/u.test(c.texto))) achadas = tentativa;
    }
    for (const caixa of achadas) {
      caixa.topo = caixa.topo / escala + deslocamento;
      caixa.base = caixa.base / escala + deslocamento;
      caixa.esquerda = caixa.esquerda / escala;
      caixa.direita = caixa.direita / escala;
      todas.push(caixa);
    }
  }
  return [_remover_repetidas(todas), fatias.length];
}

/** Descarta caixas duplicadas pela sobreposição entre faixas vizinhas. */
function _remover_repetidas(itens) {
  const limpos = [];
  for (const item of U.sorted(itens, (i) => [i.topo, i.esquerda])) {
    const texto = R.pyStrip(item.texto);
    if (!texto) continue;
    let repetida = false;
    for (const anterior of limpos) {
      if (R.pyStrip(anterior.texto) !== texto) continue;
      if (Math.abs(anterior.topo - item.topo) < 24 && Math.abs(anterior.esquerda - item.esquerda) < 24) {
        // fica a leitura de maior confiança
        if ((item.confianca || 0) > (anterior.confianca || 0)) Object.assign(anterior, item);
        repetida = true;
        break;
      }
    }
    if (!repetida) limpos.push(item);
  }
  return limpos;
}

/**
 * Reconstrói a ordem visual de leitura: de cima para baixo, da esquerda para
 * a direita.
 *
 * Os motores devolvem caixas soltas, e duas palavras da mesma linha vêm
 * separadas. Agrupar por faixa de altura fixa não funciona — título grande e
 * rodapé miúdo precisam de tolerâncias diferentes. Aqui duas caixas entram na
 * mesma linha quando se sobrepõem verticalmente em mais da metade da altura
 * da menor delas, que é o critério que uma pessoa usaria olhando a peça.
 */
function _ordenar_linhas(itens) {
  const validos = itens.filter((i) => R.pyStrip(i.texto));
  if (!validos.length) return [];

  for (const item of validos) {
    if (!('base' in item)) item.base = item.topo + (('altura' in item) ? item.altura : 10);
    if (!('direita' in item)) item.direita = item.esquerda;
  }

  // Separa a peça em blocos pelo desenho dela e monta as linhas DENTRO de
  // cada bloco. Agrupar por faixa de altura na peça inteira junta dois
  // cartões lado a lado numa linha só — "03/09: 24/09:" — e cada data perde
  // o filme a que pertence.
  const { descrever_blocos } = require('./layout');

  const saida = [];
  for (const bloco of descrever_blocos(validos)) {
    if (bloco.caixas && bloco.caixas.length) saida.push(..._linhas_de_um_bloco(bloco.caixas));
  }
  return saida;
}

/** Monta as linhas de texto dentro de um bloco já isolado. */
function _linhas_de_um_bloco(validos) {
  validos = U.sorted(validos, (r) => [r.topo, r.esquerda]);

  const linhas = [];
  for (const item of validos) {
    let encaixou = false;
    // Chamada de nota é uma caixa minúscula e assentada acima da linha:
    // ela mal encosta no texto ao lado. Com o mesmo critério das palavras
    // normais ela virava uma linha só dela, e o "2" de "36x²" acabava
    // solto, longe da palavra a que pertence.
    const curta = Array.from(R.pyStrip(item.texto)).length <= 2;
    for (const linha of linhas) {
      const topo_linha = Math.min(...linha.map((c) => c.topo));
      const base_linha = Math.max(...linha.map((c) => c.base));
      const sobreposicao = Math.min(base_linha, item.base) - Math.max(topo_linha, item.topo);
      const menor_altura = Math.min(base_linha - topo_linha, item.base - item.topo);
      // A ordenação é por topo, e a chamada de nota fica ACIMA da linha:
      // ela chega primeiro e vira âncora. Por isso o limiar reduzido vale
      // também quando é a linha existente que é só a marca de nota.
      const linha_curta = linha.every((c) => Array.from(R.pyStrip(c.texto)).length <= 2);
      const limiar = (curta || linha_curta) ? 0.15 : 0.5;
      if (menor_altura > 0 && sobreposicao > menor_altura * limiar) {
        linha.push(item);
        encaixou = true;
        break;
      }
    }
    if (!encaixou) linhas.push([item]);
  }

  const ordenadas = U.sorted(linhas, (l) => Math.min(...l.map((c) => c.topo)));
  const saida = [];
  for (const linha of ordenadas) {
    const porEsquerda = U.sorted(linha, (c) => c.esquerda);
    saida.push(_montar_linha(porEsquerda));
  }
  return saida;
}

const RE_CHAMADA_DE_NOTA = R.compilar(String.raw`^[0-9]{1,2}$|^\*{1,3}$`);

/**
 * Junta as caixas de uma linha, colando a chamada de nota na palavra anterior.
 *
 * O motor devolve o "2" de "CDB²" como uma caixa separada, e juntar tudo com
 * espaço produziria "CDB 2". O docx traz "CDB2", porque o Word cola o
 * sobrescrito — a diferença viraria apontamento em toda peça com nota de
 * rodapé, que em banco é praticamente toda peça.
 *
 * O que identifica a chamada: texto de um ou dois dígitos (ou asterisco),
 * caixa visivelmente menor que a anterior e assentada mais alto que ela.
 */
function _montar_linha(caixas) {
  const partes = [];
  let anterior = null;
  const vistos_na_linha = [];
  for (const caixa of caixas) {
    const texto = R.pyStrip(caixa.texto);
    if (!texto) continue;
    let colar = false;
    if (anterior !== null && R.casar(RE_CHAMADA_DE_NOTA, texto)) {
      const altura = caixa.base - caixa.topo;
      const altura_anterior = anterior.base - anterior.topo;
      const distancia = caixa.esquerda - ('direita' in anterior ? anterior.direita : anterior.esquerda);
      const mais_alta = caixa.topo < anterior.topo;
      const menor = altura_anterior > 0 && altura < altura_anterior * 0.8;
      const perto = distancia < altura_anterior * 0.8;
      colar = menor && mais_alta && perto;
    }
    // A sobreposição entre faixas faz a mesma frase ser lida duas vezes, e
    // o acento muda entre as leituras ("Seducäo" e "Seducao"), então o
    // descarte por texto idêntico não pega. Comparar sem acento pega.
    let assinatura = texto.toLowerCase().normalize('NFD');
    assinatura = Array.from(assinatura).filter((c) => U.categoria(c) !== 'Mn' && U.pyIsAlnum(c)).join('');
    if (assinatura && vistos_na_linha.includes(assinatura)) continue;
    if (assinatura) vistos_na_linha.push(assinatura);

    partes.push(partes.length ? (colar ? '' : ' ') + texto : texto);
    anterior = caixa;
  }
  return partes.join('');
}

// ------------------------------------------------------------------- motores

class MotorBase {
  // Fatiar a peça em faixas resolve o encolhimento do detector antigo, mas o
  // detector novo lê a imagem alta inteira e, em fatia, mistura colunas
  // vizinhas numa caixa só. Cada motor diz o que funciona para ele.
  get prefere_imagem_inteira() { return false; }
  get nome() { return ''; }
  get descricao() { return ''; }

  disponivel() { throw new Error('NotImplementedError'); }

  /** Devolve as caixas de texto detectadas, com posição e confiança. */
  async caixas(imagem, idioma, confianca_minima) { throw new Error('NotImplementedError'); }

  async ler(caminho, idioma, confianca_minima) {
    const nome_arquivo = path.basename(caminho);
    let imagem;
    try {
      imagem = await _preparar(caminho);
    } catch (e) {
      return new ResultadoOCR({ arquivo: nome_arquivo, erro: String(e && e.message || e), motor: this.nome });
    }

    let itens, fatias;
    try {
      [itens, fatias] = await _caixas_em_fatias(this, imagem, idioma, confianca_minima);
    } catch (e) {
      return new ResultadoOCR({ arquivo: nome_arquivo, erro: String(e && e.message || e), motor: this.nome });
    }

    const linhas = _ordenar_linhas(itens);
    const confiancas = itens.filter((i) => i.confianca).map((i) => i.confianca);
    const media = confiancas.length ? U.pyRound(confiancas.reduce((a, b) => a + b, 0) / confiancas.length, 1) : 0.0;

    const avisos = [];
    if (fatias > 1) avisos.push(`lida em ${fatias} faixas`);
    if (!linhas.length) {
      avisos.push('nenhum texto encontrado nesta imagem');
    } else if (media && media < CONFIANCA_PARA_ALERTAR) {
      // transparência sobre o que a máquina não teve certeza de ler:
      // é melhor apontar a dúvida do que deixar passar como certo
      avisos.push(`leitura incerta (${U.fmtFixed(media, 0)}% de confiança), vale conferir no olho`);
    }
    return new ResultadoOCR({
      arquivo: nome_arquivo, texto: limpar(linhas.join('\n')),
      lido: true, linhas, motor: this.nome, aviso: avisos.join('; '),
      confianca_media: media,
    });
  }
}

// Grava a imagem preparada num PNG temporário (para motores que leem arquivo).
async function _comPngTemporario(imagem, usar) {
  const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'ocr_'));
  const arquivo = path.join(pasta, 'imagem.png');
  try {
    I.salvarPng(imagem, arquivo);
    return await usar(arquivo);
  } finally {
    fs.rmSync(pasta, { recursive: true, force: true });
  }
}

function _executar(comando, args, opcoes = {}) {
  return new Promise((resolve, reject) => {
    execFile(comando, args, { maxBuffer: 256 * 1024 * 1024, encoding: 'utf8', ...opcoes }, (erro, stdout, stderr) => {
      if (erro) { erro.stderr = stderr; reject(erro); } else resolve({ stdout, stderr });
    });
  });
}

function _onde(comando) {
  // shutil.which
  if (comando.includes('/') || comando.includes(path.sep)) return fs.existsSync(comando) ? comando : null;
  const exts = process.platform === 'win32' ? (process.env.PATHEXT || '.EXE;.CMD;.BAT').split(';').concat(['']) : [''];
  for (const pasta of (process.env.PATH || '').split(path.delimiter)) {
    for (const ext of exts) {
      const c = path.join(pasta, comando + ext);
      try { if (fs.statSync(c).isFile()) return c; } catch { /* segue */ }
    }
  }
  return null;
}

/** OCR embutido no Windows. Nenhum programa novo para instalar (chama o WinRT pelo PowerShell). NÃO TESTADO fora do Windows. */
const _SCRIPT_WINDOWS = String.raw`
param([string]$Caminho, [string]$Tag)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation` + '`' + String.raw`1' })[0]
function Await($op, $tipo) {
  $t = $asTask.MakeGenericMethod($tipo).Invoke($null, @($op))
  $null = $t.Wait(-1)
  $t.Result
}
$arq = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Caminho)) ([Windows.Storage.StorageFile])
$fluxo = Await ($arq.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($fluxo)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$motor = $null
try {
  $lang = New-Object Windows.Globalization.Language($Tag)
  if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)) { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang) }
} catch { }
if ($null -eq $motor) { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
$res = Await ($motor.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$saida = @()
foreach ($l in $res.Lines) {
  $p = @($l.Words)
  $r0 = $p[0].BoundingRect; $r1 = $p[$p.Count - 1].BoundingRect
  $saida += [pscustomobject]@{ text = $l.Text; x = $r0.X; y = $r0.Y; width = $r0.Width; height = $r0.Height; ult_x = $r1.X; ult_width = $r1.Width }
}
ConvertTo-Json -InputObject @($saida) -Compress
`;

class MotorWindows extends MotorBase {
  get nome() { return 'windows'; }
  get descricao() { return 'OCR nativo do Windows'; }

  disponivel() {
    if (process.platform !== 'win32') return [false, 'só funciona no Windows'];
    const r = spawnSync('powershell', ['-NoProfile', '-Command', 'exit 0'], { timeout: 20000 });
    if (r.error || r.status !== 0) return [false, 'o PowerShell não foi encontrado'];
    return [true, 'ok'];
  }

  async caixas(imagem, idioma = 'por', confianca_minima = 40) {
    const tag = { por: 'pt-BR', eng: 'en-US' }[idioma] || idioma;
    return _comPngTemporario(imagem, async (arquivo) => {
      const pasta = path.dirname(arquivo);
      const script = path.join(pasta, 'ocr.ps1');
      fs.writeFileSync(script, '﻿' + _SCRIPT_WINDOWS, 'utf8');
      const { stdout } = await _executar('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, arquivo, tag]);
      const linhas = JSON.parse(stdout.trim() || '[]');
      const itens = [];
      for (const linha of linhas) {
        const texto = linha.text || '';
        const topo = linha.y || 0, esquerda = linha.x || 0;
        const altura = linha.height || 10;
        let largura = linha.width || 10;
        largura = Math.max(largura, (linha.ult_x || 0) + (linha.ult_width || 0) - esquerda);
        if (!R.pyStrip(texto)) continue;
        itens.push({
          texto, topo, base: topo + altura, esquerda, direita: esquerda + largura,
          confianca: 0.0, // o Windows não devolve confiança por linha
        });
      }
      return itens;
    });
  }
}

// O ThreadPoolExecutor do Python chamava _obter() de várias threads; aqui várias promessas
// podem pedir o leitor ao mesmo tempo. Guarda-se a PROMESSA da inicialização para iniciar uma vez só.
function _pacoteResolvivel(nome) {
  try { require.resolve(nome); return true; } catch { return false; }
}

/**
 * Modelos PP-OCR (os do RapidOCR) em onnxruntime, pelo pacote `@gutenye/ocr-node`.
 * NÃO TESTADO neste ambiente. O nome continua "rapidocr" para o OCR_MOTOR antigo funcionar.
 */
class MotorPPOCR extends MotorBase {
  constructor() { super(); this._leitor = null; }
  get nome() { return 'rapidocr'; }
  get descricao() { return 'RapidOCR / PP-OCR (modelos embutidos, sem instalar programa)'; }
  get prefere_imagem_inteira() { return true; }

  disponivel() {
    if (!_pacoteResolvivel('@gutenye/ocr-node')) {
      return [false, 'falta o pacote do Node: npm install @gutenye/ocr-node'];
    }
    return [true, 'pronto'];
  }

  _obter() {
    if (this._leitor === null) {
      this._leitor = (async () => {
        let Ocr;
        try {
          const modulo = require('@gutenye/ocr-node');
          Ocr = modulo.default || modulo;
        } catch (e) {
          const modulo = await import('@gutenye/ocr-node');
          Ocr = modulo.default || modulo;
        }
        return Ocr.create();
      })();
    }
    return this._leitor;
  }

  async caixas(imagem, idioma = 'por', confianca_minima = 40) {
    const leitor = await this._obter();
    const linhas = await _comPngTemporario(I.paraRgb(imagem), (arquivo) => leitor.detect(arquivo));
    const limite = confianca_minima / 100;
    const itens = [];
    for (const linha of (linhas || [])) {
      const confianca = _como_numero(linha.mean !== undefined ? linha.mean : linha.score);
      if (confianca < limite) continue;
      const pontos = (linha.box || linha.frame || []).map((p) => [_como_numero(p[0]), _como_numero(p[1])]);
      if (!pontos.length) continue;
      itens.push({
        texto: String(linha.text || ''),
        topo: Math.min(...pontos.map((p) => p[1])),
        base: Math.max(...pontos.map((p) => p[1])),
        esquerda: Math.min(...pontos.map((p) => p[0])),
        direita: Math.max(...pontos.map((p) => p[0])),
        confianca: confianca * 100,
      });
    }
    return itens;
  }
}

/** Pasta tessdata ao lado do programa, onde --instalar-idioma-por guarda o idioma. */
function pasta_de_idiomas_local() {
  return path.join(M.PASTA_DO_PROJETO, 'tessdata');
}

/**
 * Aponta o Tesseract para a pasta tessdata ao lado do programa, se ela tiver o português.
 *
 * Gravar na pasta de instalação do Tesseract pede administrador no Windows; a
 * pasta local não pede. TESSDATA_PREFIX definido pela própria pessoa sempre vence.
 */
function _usar_pasta_de_idiomas_local() {
  if (process.env.TESSDATA_PREFIX) return;
  const pasta = pasta_de_idiomas_local();
  if (fs.existsSync(path.join(pasta, 'por.traineddata'))) process.env.TESSDATA_PREFIX = pasta;
}

function _comando_do_tesseract() {
  return process.env.TESSERACT_CMD || 'tesseract';
}

/** Pasta onde o Tesseract procura os idiomas, lida da saída dele. Vazio se não achar. */
function _pasta_de_idiomas_do_tesseract() {
  const comando = _comando_do_tesseract();
  try {
    const saida = spawnSync(comando, ['--list-langs'], { encoding: 'utf8', timeout: 20000 });
    const texto = (saida.stdout || '') + '\n' + (saida.stderr || '');
    const achado = /languages\s+in\s+"([^"]+)"/u.exec(texto);
    if (achado) {
      try { if (fs.statSync(achado[1]).isDirectory()) return achado[1]; } catch { /* segue */ }
    }
  } catch { /* segue */ }

  // o Tesseract 4 não diz a pasta: tenta a que fica ao lado do executável
  const caminho = _onde(comando) || comando;
  const ao_lado = path.join(path.dirname(path.resolve(caminho)), 'tessdata');
  try { return fs.statSync(ao_lado).isDirectory() ? ao_lado : ''; } catch { return ''; }
}

/** Tesseract. Aceita instalação normal ou versão portátil via TESSERACT_CMD. */
class MotorTesseract extends MotorBase {
  get nome() { return 'tesseract'; }
  get descricao() { return 'Tesseract'; }

  disponivel() {
    const [ok, motivo] = I.sharpDisponivel();
    if (!ok) return [false, motivo];
    _usar_pasta_de_idiomas_local();
    const r = spawnSync(_comando_do_tesseract(), ['--version'], { encoding: 'utf8', timeout: 20000 });
    if (r.error || r.status !== 0) return [false, 'o programa Tesseract não foi encontrado na máquina'];
    return [true, 'ok'];
  }

  idiomas() {
    // pytesseract.get_languages: roda `tesseract --list-langs` e descarta a primeira linha
    try {
      const chave = `${_comando_do_tesseract()}|${process.env.TESSDATA_PREFIX || ''}`;
      const agora = Date.now();
      const guardado = MotorTesseract._memo;
      if (guardado && guardado.chave === chave && agora - guardado.quando < 30000) return guardado.lista.slice();
      const r = spawnSync(_comando_do_tesseract(), ['--list-langs'], { encoding: 'utf8', timeout: 20000 });
      if (r.error) return [];
      const texto = ((r.stdout || '') + '\n' + (r.stderr || '')).replace(/\r/g, '');
      const linhas = texto.split('\n').map((l) => l.trim()).filter(Boolean);
      const lista = linhas.slice(1);
      MotorTesseract._memo = { chave, quando: agora, lista };
      return lista.slice();
    } catch {
      return [];
    }
  }

  async caixas(imagem, idioma = 'por', confianca_minima = 40) {
    const disponiveis = this.idiomas();
    if (disponiveis.length && !disponiveis.includes(idioma)) {
      idioma = disponiveis.includes('eng') ? 'eng' : disponiveis[0];
    }

    const preparada = I.autocontraste(I.cinza(imagem));
    const dados = await _image_to_data(preparada, idioma, '--psm 6');

    const agrupadas = new Map();
    for (let i = 0; i < dados.text.length; i++) {
      const palavra = R.pyStrip(dados.text[i]);
      if (!palavra) continue;
      let confianca = _como_numero(dados.conf[i], NaN);
      if (Number.isNaN(confianca) && !/^nan$/i.test(String(dados.conf[i]).trim())) confianca = -1;
      if (Number.isNaN(confianca)) confianca = -1;
      if (confianca < confianca_minima) continue;
      const chave = `${dados.block_num[i]}|${dados.par_num[i]}|${dados.line_num[i]}`;
      if (!agrupadas.has(chave)) {
        agrupadas.set(chave, {
          texto: '', topo: dados.top[i], esquerda: dados.left[i],
          base: dados.top[i] + dados.height[i],
          direita: dados.left[i] + dados.width[i],
          confianca, soma: 0.0, quantidade: 0,
        });
      }
      const registro = agrupadas.get(chave);
      registro.texto = R.pyStrip(registro.texto + ' ' + palavra);
      registro.esquerda = Math.min(registro.esquerda, dados.left[i]);
      registro.base = Math.max(registro.base, dados.top[i] + dados.height[i]);
      registro.direita = Math.max(registro.direita, dados.left[i] + dados.width[i]);
      registro.soma += confianca;
      registro.quantidade += 1;
    }

    for (const registro of agrupadas.values()) {
      if (registro.quantidade) registro.confianca = registro.soma / registro.quantidade;
    }
    return Array.from(agrupadas.values());
  }
}

/**
 * pytesseract.image_to_data(..., output_type=DICT): grava a imagem em PNG, roda o
 * tesseract em modo tsv e devolve colunas. As colunas numéricas viram int(float(x)),
 * como no pytesseract (a confiança chega TRUNCADA).
 */
async function _image_to_data(imagem, idioma, config) {
  return _comPngTemporario(imagem, async (arquivo) => {
    const args = [arquivo, 'stdout', '-l', idioma, ...config.split(/\s+/).filter(Boolean), 'tsv'];
    const { stdout } = await _executar(_comando_do_tesseract(), args);
    return _tsv_para_colunas(stdout);
  });
}

function _tsv_para_colunas(tsv) {
  const resultado = {};
  const linhas = tsv.trim().split('\n').map((l) => l.replace(/\r$/, '').split('\t'));
  if (linhas.length < 2) return { text: [], conf: [], block_num: [], par_num: [], line_num: [], top: [], left: [], width: [], height: [] };
  const cabecalho = linhas.shift();
  const tamanho = cabecalho.length;
  if (linhas[linhas.length - 1].length < tamanho) linhas[linhas.length - 1].push('');
  const idx_texto = tamanho - 1;
  cabecalho.forEach((nome, i) => {
    resultado[nome] = [];
    for (const linha of linhas) {
      if (linha.length <= i) continue;
      if (i !== idx_texto) {
        const n = Number(linha[i]);
        resultado[nome].push(linha[i] !== '' && Number.isFinite(n) ? Math.trunc(n) : linha[i]);
      } else resultado[nome].push(linha[i]);
    }
  });
  return resultado;
}

/**
 * Tesseract em WebAssembly (pacote opcional `tesseract.js`). Funciona em servidor sem programa instalado.
 * NÃO TESTADO neste ambiente. Os idiomas vêm de `langPath` (TESSDATA_PREFIX/tessdata local) ou da CDN padrão.
 */
class MotorTesseractJs extends MotorBase {
  constructor() { super(); this._trabalhadores = {}; }
  get nome() { return 'tesseract-js'; }
  get descricao() { return 'Tesseract.js (WebAssembly, sem instalar programa)'; }

  disponivel() {
    const [ok, motivo] = I.sharpDisponivel();
    if (!ok) return [false, motivo];
    if (!_pacoteResolvivel('tesseract.js')) return [false, 'falta o pacote do Node: npm install tesseract.js'];
    return [true, 'ok'];
  }

  idiomas() { return ['por', 'eng']; }

  _obter(idioma) {
    if (!this._trabalhadores[idioma]) {
      this._trabalhadores[idioma] = (async () => {
        const { createWorker } = require('tesseract.js');
        const opcoes = {};
        const local = process.env.TESSDATA_PREFIX || (fs.existsSync(path.join(pasta_de_idiomas_local(), `${idioma}.traineddata`)) ? pasta_de_idiomas_local() : '');
        if (local) { opcoes.langPath = local; opcoes.gzip = false; }
        const trabalhador = await createWorker(idioma, 1, opcoes);
        await trabalhador.setParameters({ tessedit_pageseg_mode: '6' });
        return trabalhador;
      })();
    }
    return this._trabalhadores[idioma];
  }

  async caixas(imagem, idioma = 'por', confianca_minima = 40) {
    const trabalhador = await this._obter(idioma);
    const preparada = I.autocontraste(I.cinza(imagem));
    const png = I.codificarPng(preparada);
    // v6 só devolve a árvore (blocks) quando pedida; v5 já traz data.lines
    const { data } = await trabalhador.recognize(png, {}, { blocks: true, text: true });
    let linhas = data.lines;
    if (!linhas && data.blocks) {
      linhas = [];
      for (const b of data.blocks) for (const p of (b.paragraphs || [])) for (const l of (p.lines || [])) linhas.push(l);
    }
    const itens = [];
    for (const linha of (linhas || [])) {
      let registro = null;
      for (const w of (linha.words || [])) {
        const palavra = R.pyStrip(w.text || '');
        if (!palavra) continue;
        const confianca = Math.trunc(_como_numero(w.confidence, -1));
        if (confianca < confianca_minima) continue;
        const { x0, y0, x1, y1 } = w.bbox;
        if (!registro) registro = { texto: '', topo: y0, esquerda: x0, base: y1, direita: x1, confianca, soma: 0, quantidade: 0 };
        registro.texto = R.pyStrip(registro.texto + ' ' + palavra);
        registro.esquerda = Math.min(registro.esquerda, x0);
        registro.base = Math.max(registro.base, y1);
        registro.direita = Math.max(registro.direita, x1);
        registro.soma += confianca; registro.quantidade += 1;
      }
      if (registro) { registro.confianca = registro.soma / registro.quantidade; itens.push(registro); }
    }
    return itens;
  }
}

// A ordem é a preferência quando nenhum motor foi escolhido à mão.
//
// O PP-OCR (nome "rapidocr") vem primeiro por dois motivos. Ele reporta a confiança de cada
// leitura — sem isso o sistema não consegue avisar "leitura duvidosa" nem
// descartar ruído de ícone, que são duas defesas importantes. E, nas peças
// testadas, errou menos: onde o motor do Windows devolveu "Estreias
// deseeerpbro", ele leu "Estreias de setembro".
//
// O do Windows continua disponível e tem uma vantagem real: acentua certo,
// porque tem português nativo. Vale testar os dois nas suas peças e fixar o
// melhor com a variável OCR_MOTOR.
//
// No servidor (Linux) o Windows nunca entra; entre o `tesseract` instalado e o `tesseract-js`
// (WASM), o programa instalado vem primeiro por ser bem mais rápido.
const MOTORES = [new MotorPPOCR(), new MotorWindows(), new MotorTesseract(), new MotorTesseractJs()];

/** Alerta quando o motor instalado é velho demais. Só existia para o rapidocr-antigo, que acabou. */
function aviso_de_versao() { return ''; }

/** Estado de cada motor, para a tela mostrar o que falta instalar. */
function diagnosticar() {
  if (M._DIAGNOSTICO === null) {
    M._DIAGNOSTICO = [];
    for (const motor of M.MOTORES) {
      const [ok, motivo] = motor.disponivel();
      M._DIAGNOSTICO.push({ nome: motor.nome, descricao: motor.descricao, disponivel: ok, motivo });
    }
  }
  return M._DIAGNOSTICO;
}

/** Explica por que o motor em uso não é o que foi pedido. */
function aviso_de_escolha() { return M._AVISO_DE_ESCOLHA; }

/** Fixa o motor para as próximas leituras. Vazio volta à preferência padrão. */
function forcar_motor(nome) {
  nome = R.pyStrip(nome || '').toLowerCase();
  if (nome !== M._FORCADO_NA_TELA) {
    M._FORCADO_NA_TELA = nome;
    M._ESCOLHIDO = null; // refaz a escolha na próxima leitura
  }
}

function motores_disponiveis() { return diagnosticar().filter((d) => d.disponivel); }

/** Escolhe o motor: o forçado à mão, ou o primeiro disponível da lista. */
function motor_ativo() {
  if (M._ESCOLHIDO !== null) return M._ESCOLHIDO || null;

  M._AVISO_DE_ESCOLHA = '';

  const forcado = M._FORCADO_NA_TELA || R.pyStrip(process.env.OCR_MOTOR || '').toLowerCase();

  if (forcado) {
    const pedido = M.MOTORES.find((m) => m.nome === forcado) || null;
    if (pedido === null) {
      M._AVISO_DE_ESCOLHA = (
        `O motor “${forcado}” não existe. ` +
        `Use um destes: ${M.MOTORES.map((m) => m.nome).join(', ')}.`
      );
    } else {
      const [ok, motivo] = pedido.disponivel();
      if (ok) { M._ESCOLHIDO = pedido; return pedido; }
      // Pedir um motor que não está instalado não pode desligar a leitura
      // inteira: o certo é usar o que existe e dizer por que não foi o
      // escolhido. Desligar em silêncio faz parecer defeito do sistema.
      M._AVISO_DE_ESCOLHA = (
        `Você pediu o motor “${forcado}”, mas ele não está ` +
        `disponível (${motivo}).`
      );
    }
  }

  for (const motor of M.MOTORES) {
    const [ok] = motor.disponivel();
    if (ok) { M._ESCOLHIDO = motor; return motor; }
  }
  M._ESCOLHIDO = false;
  return null;
}

function ocr_disponivel() {
  const motor = motor_ativo();
  if (motor) {
    const aviso = aviso_de_escolha();
    if (aviso) return [true, `${aviso} Usando ${motor.descricao}.`];
    return [true, `${motor.descricao} ativo`];
  }
  const faltas = diagnosticar().map((d) => `${d.nome}: ${d.motivo}`).join('; ');
  return [false, `nenhum motor de leitura disponível (${faltas})`];
}

function idiomas_instalados() {
  const motor = motor_ativo();
  if (motor instanceof MotorTesseract) return motor.idiomas();
  if (motor) return ['por']; // Windows e RapidOCR cobrem o alfabeto latino
  return [];
}

const COMANDO_IDIOMA_POR = 'node servidor.js --instalar-idioma-por';

/**
 * Aviso para quando o motor em uso é o Tesseract e falta o português.
 *
 * Sem o idioma, o Tesseract cai para o inglês e perde os acentos, e cada
 * palavra acentuada vira divergência falsa contra o docx. Vazio quando não
 * há o que avisar (outro motor, ou Tesseract com o idioma).
 */
function aviso_de_idioma() {
  const motor = motor_ativo();
  if (!(motor instanceof MotorTesseract)) return '';
  if (motor.idiomas().includes('por')) return '';
  return (
    'O Tesseract está sem o idioma português, então os acentos saem errados ' +
    'na leitura das imagens. Para instalar, feche o programa e rode: ' +
    `${COMANDO_IDIOMA_POR}. Outra saída é o RapidOCR (npm install ` +
    '@gutenye/ocr-node), que não precisa de pacote de idioma.'
  );
}

// Idiomas "fast" do projeto oficial do Tesseract: pequenos (cerca de 1 MB o
// português) e suficientes para texto de peça. TESSDATA_URL aponta para um
// espelho interno quando a rede da empresa bloqueia o github.com.
const URL_IDIOMAS_TESSERACT = 'https://github.com/tesseract-ocr/tessdata_fast/raw/main';
const TAMANHO_MINIMO_DE_IDIOMA = 200_000; // abaixo disso o download veio uma página de erro

function _baixar_bytes(url, restantes = 8) {
  return new Promise((resolve, reject) => {
    const cliente = url.startsWith('https:') ? require('https') : require('http');
    const req = cliente.get(url, { headers: { 'User-Agent': 'validador-emkt' }, timeout: 90000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && restantes > 0) {
        res.resume();
        resolve(_baixar_bytes(new URL(res.headers.location, url).toString(), restantes - 1));
        return;
      }
      if (res.statusCode !== 200) { res.resume(); reject(new Error(`HTTP Error ${res.statusCode}`)); return; }
      const pedacos = [];
      res.on('data', (p) => pedacos.push(p));
      res.on('end', () => resolve(Buffer.concat(pedacos)));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('tempo esgotado')));
    req.on('error', reject);
  });
}

async function _baixar_idioma(url_base, idioma, pasta, minimo_bytes) {
  const destino = path.join(pasta, `${idioma}.traineddata`);
  const parcial = destino + '.parte';
  try {
    const dados = await _baixar_bytes(`${url_base.replace(/\/+$/, '')}/${idioma}.traineddata`);
    fs.writeFileSync(parcial, dados);
    if (fs.statSync(parcial).size < minimo_bytes) {
      throw new Error(`o arquivo de ${idioma} veio pequeno demais, provavelmente não é o idioma`);
    }
    fs.renameSync(parcial, destino);
  } finally {
    if (fs.existsSync(parcial)) fs.rmSync(parcial, { force: true });
  }
}

/**
 * Instala o idioma português (por.traineddata) do Tesseract. true se deu certo.
 *
 * Primeiro tenta a pasta de idiomas do próprio Tesseract. Sem permissão de
 * escrita (comum no Windows, em Arquivos de Programas), guarda numa pasta
 * tessdata ao lado do programa e passa a usá-la sozinho nas próximas aberturas.
 * A pasta local vira a única que o Tesseract enxerga, por isso leva junto o
 * inglês.
 *
 * `destino` e `url_base` existem para os testes.   (ASSÍNCRONA: usa rede.)
 */
async function instalar_idioma_por(imprimir = console.log, destino = null, url_base = null,
  minimo_bytes = TAMANHO_MINIMO_DE_IDIOMA) {
  url_base = url_base || process.env.TESSDATA_URL || URL_IDIOMAS_TESSERACT;
  let idiomas;

  if (destino === null) {
    const motor = new MotorTesseract();
    const [disponivel, motivo] = motor.disponivel();
    if (!disponivel) {
      imprimir(`Não dá para instalar o idioma: ${motivo}.`);
      imprimir('O idioma só importa para o Tesseract. Com o RapidOCR ' +
        '(npm install @gutenye/ocr-node) não é preciso.');
      return false;
    }
    if (motor.idiomas().includes('por')) {
      imprimir('O Tesseract já tem o idioma português. Nada a fazer.');
      return true;
    }

    const sistema = _pasta_de_idiomas_do_tesseract();
    let gravavel = false;
    if (sistema) { try { fs.accessSync(sistema, fs.constants.W_OK); gravavel = true; } catch { /* sem permissão */ } }
    if (sistema && gravavel) {
      destino = sistema; idiomas = ['por'];
    } else {
      destino = pasta_de_idiomas_local(); idiomas = ['por', 'eng'];
      if (sistema) imprimir(`Sem permissão para gravar em ${sistema}.`);
      imprimir(`O idioma vai para ${destino}, ao lado do programa.`);
    }
  } else {
    idiomas = ['por', 'eng'];
  }

  fs.mkdirSync(destino, { recursive: true });
  for (const idioma of idiomas) {
    if (fs.existsSync(path.join(destino, `${idioma}.traineddata`))) continue;
    imprimir(`Baixando ${idioma}.traineddata...`);
    try {
      await _baixar_idioma(url_base, idioma, destino, minimo_bytes);
    } catch (erro) {
      imprimir(`Falhou: ${erro && erro.message || erro}`);
      imprimir('Se a rede bloqueia o github.com, baixe o arquivo ' +
        `${idioma}.traineddata (projeto tessdata_fast) em outra ` +
        `máquina e copie para ${destino}, ou aponte a variável ` +
        'TESSDATA_URL para um espelho interno.');
      return false;
    }
  }

  imprimir(`Pronto: o idioma português está em ${destino}. Abra o programa de novo.`);
  return true;
}

// Ícone de rede social, marcador de lista, pixel espaçador. Não cabe texto
// legível num quadrado de 20 px, e cada um desses custa meio segundo de
// leitura à toa — num pacote com dez ícones, são cinco segundos de espera.
const LADO_MINIMO_PARA_LER = 60;
const AREA_MINIMA_PARA_LER = 2500;

function _pequena_demais(caminho) {
  const [largura, altura] = I.dimensoes(caminho);
  if (!largura && !altura && !fs.existsSync(caminho)) return [false, ''];
  if (!largura && !altura) return [false, ''];
  if (largura * altura < AREA_MINIMA_PARA_LER) {
    return [true, `${largura}x${altura}: pequena demais para conter texto`];
  }
  if (largura < LADO_MINIMO_PARA_LER && altura < LADO_MINIMO_PARA_LER) {
    return [true, `${largura}x${altura}: tamanho de ícone`];
  }
  return [false, ''];
}

function _e_gif_animado(caminho) {
  if (!caminho.toLowerCase().endsWith('.gif')) return false;
  try { return I.numFramesGif(caminho) > 1; } catch { return false; }
}

async function ler_imagem(caminho, idioma = 'por', confianca_minima = 40) {
  const motor = motor_ativo();
  const nome = path.basename(caminho);
  if (!motor) return new ResultadoOCR({ arquivo: nome, erro: ocr_disponivel()[1] });

  const [pequena, motivo] = _pequena_demais(caminho);
  if (pequena) return new ResultadoOCR({ arquivo: nome, lido: true, motor: motor.nome, aviso: motivo });

  if (!_e_gif_animado(caminho)) return motor.ler(caminho, idioma, confianca_minima);

  // GIF animado: cada cena pode trazer texto próprio, e é comum a oferta
  // inteira estar espalhada entre os frames.
  const textos = [], confiancas = [];
  let frames_lidos = 0, quadros;
  try {
    quadros = await _frames_relevantes(caminho);
  } catch (e) {
    return new ResultadoOCR({ arquivo: nome, erro: `não consegui abrir o GIF: ${e && e.message || e}`, motor: motor.nome });
  }

  const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'frames_'));
  try {
    for (let indice = 0; indice < quadros.length; indice++) {
      const destino = path.join(pasta, `frame_${String(indice).padStart(2, '0')}.png`);
      try {
        I.salvarPng(quadros[indice], destino);
      } catch (e) {
        continue;
      }
      const parcial = await motor.ler(destino, idioma, confianca_minima);
      if (parcial.texto) { textos.push(parcial.texto); frames_lidos += 1; }
      if (parcial.confianca_media) confiancas.push(parcial.confianca_media);
    }
  } finally {
    fs.rmSync(pasta, { recursive: true, force: true });
  }

  const texto = _juntar_textos(textos);
  return new ResultadoOCR({
    arquivo: nome, texto, lido: true, motor: motor.nome,
    linhas: R.pySplitlines(texto),
    confianca_media: confiancas.length ? U.pyRound(confiancas.reduce((a, b) => a + b, 0) / confiancas.length, 1) : 0.0,
    aviso: `GIF animado: ${frames_lidos} cena(s) lida(s) de ${quadros.length} frame(s) distintos`,
  });
}

// ------------------------------------------------------- cache entre execuções

// Módulos cujo código decide o texto que sai de uma imagem: o próprio ocr
// (motores, fatiamento, filtros), o layout (separa a peça em blocos antes de
// montar as linhas) e a normalização (limpar). Só o texto destes entra na chave
// do cache. A correção de OCR, o comparador, o parser de HTML, as regras e a
// tela rodam DEPOIS da leitura e não mudam o que o cache guarda: mexer neles
// não pode jogar fora leituras que levaram minutos.
const MODULOS_DA_LEITURA = ['ocr', 'layout', 'normalizacao'];

/** Texto de cada módulo da leitura, na ordem fixa de MODULOS_DA_LEITURA. */
function _fontes_da_leitura() {
  const embutidas = M._FONTES_DO_SCRIPT || {};
  const fontes = [];
  for (const nome of MODULOS_DA_LEITURA) {
    let texto = embutidas[nome];
    if (texto === undefined || texto === null) {
      // lê o arquivo ao lado
      try {
        texto = fs.readFileSync(path.join(__dirname, nome + '.js'), 'utf8');
      } catch {
        texto = ''; // sem acesso ao código: a chave cai no nome do módulo
      }
    }
    fontes.push([nome, texto]);
  }
  return fontes;
}

/**
 * Identidade do código que produz a leitura.
 *
 * Isto já foi um número escrito à mão, e o número ficou para trás três vezes
 * seguidas enquanto o comportamento da leitura mudava. O efeito é pior do que
 * parece: a correção entra no código, a pessoa atualiza, roda o mesmo pacote
 * e continua vendo o erro antigo, porque o cache devolve a leitura de antes.
 * Depurar isso custa caro, e o sintoma aponta para o lugar errado.
 *
 * A chave é o resumo do texto dos módulos de MODULOS_DA_LEITURA. Mudou o
 * código que decide a leitura, o cache antigo deixa de valer sozinho. Mudou
 * qualquer outra parte do programa (a tela, por exemplo), o cache sobrevive.
 *
 * `fontes` existe para os testes: lista de [nome, texto] no lugar da real.
 */
function _versao_da_leitura(fontes = null) {
  const digestor = crypto.createHash('sha1');
  for (const [nome, texto] of (fontes === null ? _fontes_da_leitura() : fontes)) {
    digestor.update(Buffer.concat([Buffer.from(nome, 'utf8'), Buffer.from([0])]));
    digestor.update(Buffer.concat([Buffer.from(texto, 'utf8'), Buffer.from([0])]));
  }
  return digestor.digest('hex').slice(0, 12);
}

/**
 * Identidade da leitura: conteúdo do arquivo + motor + versão.
 *
 * Pelo conteúdo, e não pelo caminho: o mesmo banner reaparece em campanhas
 * diferentes com nomes diferentes, e conferir de novo o que já foi lido é
 * desperdício. Muda uma vírgula na imagem, muda a impressão.
 */
function _impressao_do_arquivo(caminho, motor) {
  try {
    const digestor = crypto.createHash('sha1');
    digestor.update(fs.readFileSync(caminho));
    digestor.update(Buffer.from(`|${motor}|${M.VERSAO_DA_LEITURA}`, 'utf8'));
    return digestor.digest('hex');
  } catch {
    return null;
  }
}

function _ler_do_cache(impressao) {
  if (!impressao) return null;
  const caminho = path.join(M.PASTA_CACHE, `${impressao}.json`);
  try {
    const dados = JSON.parse(fs.readFileSync(caminho, 'utf8'));
    // ResultadoOCR(**dados) do Python recusa campo desconhecido ou sem "arquivo"
    if (dados === null || typeof dados !== 'object' || Array.isArray(dados)) return null;
    if (!('arquivo' in dados)) return null;
    if (Object.keys(dados).some((k) => !CAMPOS_RESULTADO.includes(k))) return null;
    return new ResultadoOCR(dados);
  } catch {
    return null;
  }
}

function _gravar_no_cache(impressao, resultado) {
  if (!impressao || resultado.erro) return; // falha não entra no cache: a próxima tentativa pode dar certo
  try {
    fs.mkdirSync(M.PASTA_CACHE, { recursive: true });
    const caminho = path.join(M.PASTA_CACHE, `${impressao}.json`);
    const dados = {};
    for (const k of CAMPOS_RESULTADO) dados[k] = resultado[k];
    fs.writeFileSync(caminho, JSON.stringify(dados), 'utf8');
  } catch {
    // sem permissão de escrita: segue sem cache
  }
}

function _normcase_abspath(caminho) {
  const p = path.resolve(caminho);
  return process.platform === 'win32' ? p.toLowerCase().replace(/\//g, '\\') : p;
}

/**
 * Guarda a leitura de cada imagem, dentro da execução e entre execuções.
 *
 * Ler imagem é praticamente todo o tempo da conferência. Na prática o mesmo
 * pacote é conferido várias vezes — ajusta o docx, confere de novo — e as
 * imagens não mudaram. Reler tudo a cada vez é o desperdício mais caro aqui.
 */
class CacheOCR {
  constructor(idioma = 'por', confianca_minima = 40, usar_disco = true) {
    this.idioma = idioma;
    this.confianca_minima = confianca_minima;
    this.usar_disco = usar_disco;
    this.aviso_idioma = '';
    this.reaproveitadas = 0;
    this._cache = new Map();
  }

  _nome_do_motor() {
    const motor = motor_ativo();
    return motor ? motor.nome : 'nenhum';
  }

  async ler(caminho) {
    const chave = _normcase_abspath(caminho);
    if (this._cache.has(chave)) return this._cache.get(chave);

    const impressao = this.usar_disco ? _impressao_do_arquivo(caminho, this._nome_do_motor()) : null;
    const guardado = impressao ? _ler_do_cache(impressao) : null;
    if (guardado !== null) {
      this.reaproveitadas += 1;
      this._cache.set(chave, guardado);
      return guardado;
    }

    const resultado = await ler_imagem(caminho, this.idioma, this.confianca_minima);
    if (resultado.aviso && !this.aviso_idioma) this.aviso_idioma = resultado.aviso;
    if (impressao) _gravar_no_cache(impressao, resultado);
    this._cache.set(chave, resultado);
    return resultado;
  }

  /**
   * Lê várias imagens ao mesmo tempo.
   *
   * O reconhecimento roda fora do Node (processo do tesseract, sharp), então a espera de uma
   * imagem não impede a leitura da outra — ler três em paralelo aproveita a máquina
   * em vez de ficar na fila.
   */
  async pre_carregar(caminhos, trabalhadores = 3, ao_avancar = null) {
    const pendentes = [];
    for (const caminho of caminhos) {
      const chave = _normcase_abspath(caminho);
      if (!this._cache.has(chave) && fs.existsSync(caminho)) pendentes.push(caminho);
    }
    const total = pendentes.length;
    if (total < 2) {
      for (const caminho of pendentes) {
        await this.ler(caminho);
        if (ao_avancar) ao_avancar(1, total);
      }
      return;
    }

    let concluidas = 0, proximo = 0;
    const trabalhador = async () => {
      while (proximo < total) {
        const caminho = pendentes[proximo++];
        await this.ler(caminho);
        concluidas += 1;
        if (ao_avancar) ao_avancar(concluidas, total);
      }
    };
    const n = Math.min(trabalhadores, total);
    await Promise.all(Array.from({ length: n }, trabalhador));
  }

  get lidas() {
    let n = 0;
    for (const r of this._cache.values()) if (r.lido) n++;
    return n;
  }
}

Object.assign(M, {
  ResultadoOCR, limpar, PASTA_DO_PROJETO,
  _preparar, MAXIMO_FRAMES_LIDOS, MUDANCA_MINIMA_ENTRE_FRAMES, DIFERENCA_POR_PIXEL,
  _assinatura, _frames_relevantes, _juntar_textos,
  ALTURA_MAXIMA_POR_FATIA, SOBREPOSICAO_ENTRE_FATIAS, ALTURA_MINIMA_DO_TEXTO, CONFIANCA_PARA_ALERTAR,
  RE_CONTEUDO_SEM_LETRA, RE_REPETICAO_BOBA, CONFIANCA_MINIMA_SEM_LETRA,
  _como_numero, _tem_letra, _fora_do_alfabeto, _e_ruido_de_icone,
  LIMIAR_ESCURA, SOBREPOSICAO_MESMA_CAIXA, _luminancia_media, _variantes_de_leitura, _leitura_fraca,
  _mesma_regiao, _fundir_leituras, _realcar, _fatias_da_imagem, _caixas_em_fatias, _remover_repetidas,
  _ordenar_linhas, _linhas_de_um_bloco, RE_CHAMADA_DE_NOTA, _montar_linha,
  MotorBase, MotorWindows, MotorPPOCR, MotorRapidOCRNovo: MotorPPOCR, MotorTesseract, MotorTesseractJs,
  pasta_de_idiomas_local, _usar_pasta_de_idiomas_local, _pasta_de_idiomas_do_tesseract,
  MOTORES, aviso_de_versao, diagnosticar, aviso_de_escolha, forcar_motor, motores_disponiveis, motor_ativo,
  ocr_disponivel, idiomas_instalados, aviso_de_idioma, COMANDO_IDIOMA_POR, URL_IDIOMAS_TESSERACT, TAMANHO_MINIMO_DE_IDIOMA,
  _baixar_idioma, instalar_idioma_por, LADO_MINIMO_PARA_LER, AREA_MINIMA_PARA_LER, _pequena_demais,
  _e_gif_animado, ler_imagem, MODULOS_DA_LEITURA, _fontes_da_leitura, _versao_da_leitura,
  _impressao_do_arquivo, _ler_do_cache, _gravar_no_cache, CacheOCR,
  _image_to_data, _tsv_para_colunas,
});

// estado mutável do módulo (os testes trocam estes valores, como no Python)
M._ESCOLHIDO = null;
M._DIAGNOSTICO = null;
M._FORCADO_NA_TELA = '';
M._AVISO_DE_ESCOLHA = '';
M._FONTES_DO_SCRIPT = null;
M.PASTA_CACHE = path.join(PASTA_DO_PROJETO, '.cache-leitura');
M.VERSAO_DA_LEITURA = _versao_da_leitura();
