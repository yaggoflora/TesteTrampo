'use strict';
/*
 * Regras de publicação de EMKT.
 *
 * Ficam separadas do resto de propósito: são as regras do banco, mudam por
 * decisão de processo e não por mudança técnica. Quando o padrão do time mudar,
 * é aqui que se mexe — sem tocar em parser, comparador ou tela.
 *
 * Três níveis:
 *   BLOQUEIO  — impede a publicação. Ex.: HTML sem nenhum redirect.
 *   ALERTA    — não impede, mas o analista precisa saber. Ex.: assunto longo.
 *   LIMITE    — número usado nas contas acima.
 */

const R = require('./_pyre');

// ------------------------------------------------------------------ limites

// Assunto e pré-header: passar do limite não proíbe a publicação, mas corta na
// caixa de entrada de vários clientes. Vira alerta discreto, não apontamento.
const LIMITE_ASSUNTO = 35;
const LIMITE_PRE_HEADER = 40;

// Peso de imagem: acima disso a peça fica pesada para abrir no e-mail.
const LIMITE_IMAGEM_KB = 1024; // 1 MB

// ------------------------------------------- acento e pontuação: o que reprova

// Diferença de acento ou de pontuação entre o HTML e o CONTEUDO.docx é, na
// maioria das vezes, só o redator escrevendo de um jeito e a peça de outro
// ("Cartões Digitais:" na peça, "Cartões Digitais" no docx). Isso vira AVISO DE
// DIFERENÇA: aparece na tela, não reprova e não impede de anexar no sistema.
//
// Só reprova quando está grotesco, isto é, quando passa de um dos limites
// abaixo. Para ser mais ou menos rigoroso, mexa só nestes três números.
//
// Palavras com ACENTO diferente (ação x acao) na peça inteira.
const LIMITE_ACENTOS_NA_PECA = 6;
// Palavras com acento diferente dentro de um mesmo trecho (uma frase sem nenhum
// acento, por exemplo, é sinal de texto digitado errado).
const LIMITE_ACENTOS_NO_TRECHO = 4;
// Palavras com PONTUAÇÃO diferente (dois pontos, vírgula, ponto) na peça
// inteira. É bem mais folgado: redator que tira os dois pontos de todos os
// títulos não está errando a peça.
const LIMITE_PONTUACAO_NA_PECA = 15;

// ------------------------------------------ repetição e texto de imagem

// Palavra repetida: o HTML (texto vivo + texto lido da imagem) pode trazer
// "Livelo Livelo" onde o docx tem um "Livelo" só. Se o trecho que sobrou no HTML
// tem até este número de palavras e todas já aparecem no docx, é aviso, não erro.
const LIMITE_REPETICAO_PALAVRAS = 3;

// Imagem: se qualquer palavra que o OCR leu na imagem aparece no CONTEUDO.docx,
// o que faltar é aviso. Só reprova quando NADA do que está escrito na imagem
// consta no docx. Palavras com menos letras que isto (ruído de ícone: "f", "in",
// "o") não contam como texto da imagem.
const TAMANHO_MINIMO_PALAVRA_IMAGEM = 3;

// Número, taxa, prazo ou valor diferente (qualquer palavra com dígito) também
// nunca vira só aviso, nem em imagem, nem em repetição.
//
// Repetição nunca é perdoada quando o trecho tem uma destas palavras: "não"
// a mais ou a menos muda o sentido da frase.
const PALAVRAS_QUE_MUDAM_O_SENTIDO = ['nao', 'sem', 'nunca', 'nenhum', 'nenhuma'];

// ----------------------------------------------------------------- redirect

// Pelo menos um redirect é obrigatório no HTML. Os padrões abaixo cobrem as
// formas mais comuns de escrever a chamada; acrescente aqui se o time usar
// outra. A busca é feita no código inteiro, não só nos links, porque o redirect
// às vezes aparece dentro de AMPScript ou de atributo de rastreio.
const PADROES_REDIRECT = [
  'redirect',
  '\\bredir\\b',
  'redirecionamento',
];

const _RE_REDIRECT = PADROES_REDIRECT.map((p) => R.compilar(p, 'i'));

/** Quantas ocorrências de redirect existem no código. */
function contar_redirects(codigo_html) {
  if (!codigo_html) return 0;
  let total = 0;
  for (const padrao of _RE_REDIRECT) total += R.todos(padrao, codigo_html).length;
  return total;
}

// ------------------------------------------------------- assunto e pré-header

// O pré-header precisa terminar em pontuação final — qualquer uma delas. Ponto,
// exclamação e interrogação são igualmente válidos, e na prática "!" aparece
// mais que o ponto nas chamadas. Reticências contam, e fechamento de aspas ou
// parêntese depois da pontuação também.
const PONTUACAO_FINAL = '.!?…';

const RE_TERMINA_EM_PONTO = R.compilar(
  '[.!?\\u2026](?:[\\"\'\\u201d\\u2019\\u00bb)\\]]*)\\s*$'
);

function pre_header_tem_ponto_final(texto) {
  if (!texto || !R.pyStrip(texto)) return false;
  return !!R.buscar(RE_TERMINA_EM_PONTO, R.pyStrip(texto));
}

const _len = (s) => Array.from(s).length;

/** Quantos caracteres passaram do limite. Zero quando está dentro. */
function excedeu(texto, limite) {
  if (!texto) return 0;
  return Math.max(0, _len(R.pyStrip(texto)) - limite);
}

// ------------------------------------------- hyperlink automático no disclaimer

// Cliente de e-mail transforma sozinho qualquer coisa com cara de endereço em
// link clicável. No disclaimer isso não pode acontecer, então a peça separa os
// caracteres com um invisível — normalmente &#xFEFF; (zero-width no-break
// space), às vezes &zwnj; ou &#8203; — bem no ponto onde o cliente procuraria o
// padrão de domínio. Sem esse código, o link é gerado e a peça não sobe.
const INVISIVEIS_ANTI_LINK = ['﻿', '​', '‌', '‍', '⁠'];

const RE_ENDERECO = R.compilar(
  '(?:https?://|www\\.)[^\\s<>\\"\']{4,}' + // URL explícita
  '|[a-z0-9][a-z0-9\\-]{1,}\\.(?:com|br|net|org|gov)\\b[^\\s<>\\"\']*' + // domínio
  '|[a-z0-9][a-z0-9\\-]{1,}\\.[a-z]{2,}/[^\\s<>\\"\']+' + // banco.bradesco/algo
  '|[\\w.\\-]+@[\\w\\-]+\\.[a-z]{2,}', // e-mail
  'i'
);

/**
 * Acha endereços dentro de um trecho que virariam link clicável.
 *
 * Recebe o texto BRUTO, com os invisíveis preservados: é justamente a
 * presença deles que diz se a proteção foi aplicada. Depois da limpeza eles
 * somem e não há mais como saber.
 */
function enderecos_sem_protecao(texto_bruto) {
  if (!texto_bruto) return [];

  // o invisível fica no meio do endereço; para achar o padrão é preciso
  // olhar o texto sem ele, e depois conferir o trecho original
  let sem_invisiveis = texto_bruto;
  for (const marca of INVISIVEIS_ANTI_LINK) sem_invisiveis = sem_invisiveis.split(marca).join('');

  const desprotegidos = [];
  for (const achado of R.todos(RE_ENDERECO, sem_invisiveis)) {
    const endereco = achado[0].replace(/[.,;:)]+$/u, '');
    if (_len(endereco) < 6) continue;
    // o endereço está protegido se o original traz algum invisível entre
    // os caracteres dele
    const trecho_original = _trecho_original(texto_bruto, endereco);
    if (!INVISIVEIS_ANTI_LINK.some((marca) => trecho_original.includes(marca))) {
      desprotegidos.push(endereco);
    }
  }
  return desprotegidos;
}

/** Recorta no texto bruto a região que corresponde ao endereço encontrado. */
function _trecho_original(texto_bruto, endereco) {
  const letras = Array.from(endereco);
  const bruto = Array.from(texto_bruto);
  let posicao = 0;
  let inicio = null;
  for (let indice = 0; indice < bruto.length; indice++) {
    const caractere = bruto[indice];
    if (INVISIVEIS_ANTI_LINK.includes(caractere)) continue;
    if (posicao < letras.length && caractere === letras[posicao]) {
      if (inicio === null) inicio = indice;
      posicao += 1;
      if (posicao === letras.length) return bruto.slice(inicio, indice + 1).join('');
    } else {
      posicao = 0;
      inicio = null;
      if (caractere === letras[0]) {
        inicio = indice;
        posicao = 1;
      }
    }
  }
  return '';
}

// ------------------------------------------------------------ datas vencidas

const MESES = {
  janeiro: 1, fevereiro: 2, marco: 3, 'março': 3, abril: 4,
  maio: 5, junho: 6, julho: 7, agosto: 8, setembro: 9,
  outubro: 10, novembro: 11, dezembro: 12,
};

const RE_DATA_NUMERICA = R.compilar('\\b(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4})\\b');
const RE_DATA_POR_EXTENSO = R.compilar('\\b(\\d{1,2})\\s+de\\s+([a-zç]+)\\s+de\\s+(\\d{4})\\b', 'i');

const _MS_DIA = 86400000;

/** date(ano, mes, dia) do Python: devolve dias desde uma época fixa ou null (ValueError). */
function _data(ano, mes, dia) {
  if (ano < 1 || ano > 9999 || mes < 1 || mes > 12 || dia < 1) return null;
  const d = new Date(0);
  d.setUTCFullYear(ano, mes - 1, dia);
  d.setUTCHours(0, 0, 0, 0);
  if (d.getUTCFullYear() !== ano || d.getUTCMonth() !== mes - 1 || d.getUTCDate() !== dia) return null;
  return Math.round(d.getTime() / _MS_DIA);
}

/** `hoje` pode ser Date (usa a data LOCAL), {ano, mes, dia} ou undefined (hoje, hora local). */
function _hojeEmDias(hoje) {
  if (hoje && typeof hoje === 'object' && 'ano' in hoje) return _data(hoje.ano, hoje.mes, hoje.dia);
  const d = hoje instanceof Date ? hoje : new Date();
  return _data(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

const _dois = (n) => String(n).padStart(2, '0');

/**
 * Devolve as datas do texto que já passaram.
 *
 * Prazo de campanha aparece no disclaimer, no banner e no texto do código, e
 * peça reaproveitada de mês anterior costuma trazer a data antiga junto. Vira
 * aviso, não bloqueio: às vezes a data passada é proposital (início de
 * vigência, data de contrato), e quem decide isso é o analista.
 */
function datas_vencidas(texto, hoje = null) {
  const hojeDias = _hojeEmDias(hoje);
  const vencidas = [];
  const { pyInt } = R;

  for (const m of R.todos(RE_DATA_NUMERICA, texto || '')) {
    const [, dia, mes, ano] = m;
    let ano_cheio = pyInt(ano);
    if (ano_cheio < 100) ano_cheio += 2000;
    const achada = _data(ano_cheio, pyInt(mes), pyInt(dia));
    if (achada === null) continue;
    // datas muito antigas são ano de fundação, CNPJ, número solto
    if (achada < hojeDias && hojeDias - achada < 900) {
      const texto_data = `${_dois(pyInt(dia))}/${_dois(pyInt(mes))}/${ano_cheio}`;
      if (!vencidas.includes(texto_data)) vencidas.push(texto_data);
    }
  }

  for (const m of R.todos(RE_DATA_POR_EXTENSO, texto || '')) {
    const [, dia, nome_mes, ano] = m;
    const chave = nome_mes.toLowerCase();
    const numero = Object.prototype.hasOwnProperty.call(MESES, chave) ? MESES[chave] : 0;
    if (!numero) continue;
    const achada = _data(pyInt(ano), numero, pyInt(dia));
    if (achada === null) continue;
    if (achada < hojeDias && hojeDias - achada < 900) {
      const texto_data = `${dia} de ${nome_mes} de ${ano}`;
      if (!vencidas.includes(texto_data)) vencidas.push(texto_data);
    }
  }

  return vencidas;
}

module.exports = {
  LIMITE_ASSUNTO, LIMITE_PRE_HEADER, LIMITE_IMAGEM_KB,
  LIMITE_ACENTOS_NA_PECA, LIMITE_ACENTOS_NO_TRECHO, LIMITE_PONTUACAO_NA_PECA,
  LIMITE_REPETICAO_PALAVRAS, TAMANHO_MINIMO_PALAVRA_IMAGEM, PALAVRAS_QUE_MUDAM_O_SENTIDO,
  PADROES_REDIRECT, contar_redirects, PONTUACAO_FINAL, RE_TERMINA_EM_PONTO,
  pre_header_tem_ponto_final, excedeu, INVISIVEIS_ANTI_LINK, RE_ENDERECO,
  enderecos_sem_protecao, _trecho_original, MESES, RE_DATA_NUMERICA, RE_DATA_POR_EXTENSO,
  datas_vencidas,
};
