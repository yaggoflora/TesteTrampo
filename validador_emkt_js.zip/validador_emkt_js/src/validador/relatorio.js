'use strict';
/**
 * Relatório de conferência em HTML — arquivo único, abre em qualquer navegador,
 * sem servidor e sem dependência externa. Serve como evidência da conferência.
 */

const fs = require('fs');
const path = require('path');
const pyos = require('../lib/pyos');
const { sorted } = require('../lib/pyutil');

const CSS = `
:root{
  --tinta:#1c1f23; --tinta-fraca:#5b6570; --linha:#dfe3e8;
  --fundo:#f6f7f9; --papel:#ffffff;
  --marca:#cc092f; --ok:#12734f; --atencao:#a86400; --erro:#b3122c;
  --ok-fundo:#e8f4ee; --atencao-fundo:#fdf3e0; --erro-fundo:#fdeaed;
}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px 72px;background:var(--fundo);color:var(--tinta);
  font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.55}
.folha{max-width:960px;margin:0 auto}
header{border-left:5px solid var(--marca);padding:4px 0 4px 18px;margin-bottom:28px}
header h1{margin:0;font-size:25px;font-weight:650;letter-spacing:-.2px}
header .quebra{font-size:15px;color:var(--tinta-fraca);margin-top:2px}
header .meta{font-size:13px;color:var(--tinta-fraca);margin-top:8px}

.veredito{display:flex;align-items:center;gap:16px;background:var(--papel);
  border:1px solid var(--linha);border-radius:10px;padding:20px 22px;margin-bottom:26px}
.veredito .selo{font-size:19px;font-weight:700;padding:7px 16px;border-radius:6px;white-space:nowrap}
.selo.aprovado{background:var(--ok-fundo);color:var(--ok)}
.selo.atencao{background:var(--atencao-fundo);color:var(--atencao)}
.selo.reprovado,.selo.erro{background:var(--erro-fundo);color:var(--erro)}
.veredito p{margin:0;color:var(--tinta-fraca);font-size:14px}

.numeros{display:flex;gap:28px;flex-wrap:wrap;margin-top:14px;padding-top:14px;
  border-top:1px solid var(--linha)}
.numeros div{min-width:92px}
.numeros b{display:block;font-size:21px;font-weight:650;font-variant-numeric:tabular-nums}
.numeros span{font-size:12.5px;color:var(--tinta-fraca)}

section{background:var(--papel);border:1px solid var(--linha);border-radius:10px;
  padding:22px 24px;margin-bottom:18px}
section h2{margin:0 0 4px;font-size:17px;font-weight:650}
section h2 .contagem{font-weight:400;color:var(--tinta-fraca);font-size:14px}
section .resumo{margin:0 0 16px;color:var(--tinta-fraca);font-size:13.5px}

ul.itens{list-style:none;margin:0;padding:0}
ul.itens li{padding:9px 0 9px 14px;border-left:3px solid var(--linha);margin-bottom:7px;
  background:#fbfcfd;border-radius:0 5px 5px 0;font-size:14px}
li.alta{border-left-color:var(--erro)}
li.media{border-left-color:var(--atencao)}
li.baixa{border-left-color:#8a8f98}
.observacao-manual{margin:14px 0;padding:10px 14px;border-left:4px solid #e3b341;background:#fff8e1;color:#5c4a00;font-size:13px}
li.baixa{border-left-color:var(--tinta-fraca)}
li.ok{border-left-color:var(--ok)}
li .rotulo{font-weight:650;margin-right:7px}
.obrigatorio{background:#eef1f4;color:var(--tinta-fraca);font-size:11.5px;
  padding:2px 8px;border-radius:4px;margin-left:8px;font-weight:600}
.citacoes{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:11px}
.citacao{display:flex;flex-direction:column;gap:4px;min-width:0}
.citacao-fonte{font-size:11px;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;color:var(--tinta-fraca)}
.citacao blockquote{margin:0;padding:10px 13px;border:1px solid var(--linha);
  border-radius:6px;background:#fff;font-family:Consolas,"Courier New",monospace;
  font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-word}
.citacao blockquote::before,.citacao blockquote::after{content:'"';color:var(--tinta-fraca)}
@media(max-width:700px){.citacoes{grid-template-columns:1fr}}
li .arquivo{font-family:Consolas,"Courier New",monospace;font-size:13px;
  background:#eef1f4;padding:1px 6px;border-radius:4px}

.diff{margin-top:8px;border:1px solid var(--linha);border-radius:6px;overflow:hidden}
.diff div{padding:8px 12px;font-size:13.5px}
.diff .lado{display:flex;gap:10px;border-bottom:1px solid var(--linha)}
.diff .lado:last-child{border-bottom:none}
.diff .tag{flex:0 0 74px;color:var(--tinta-fraca);font-size:12px;padding-top:1px}
.diff .html{background:#fff}
.diff .docx{background:#fafbfc}
.contexto{font-size:12.5px;color:var(--tinta-fraca);margin-top:6px}
.contexto code{background:#eef1f4;padding:1px 5px;border-radius:3px;font-size:12px}

.vazio{color:var(--ok);font-size:14px;margin:0}
.aviso{background:var(--atencao-fundo);border-left:3px solid var(--atencao);
  padding:11px 14px;border-radius:0 5px 5px 0;margin-bottom:9px;font-size:14px}
footer{margin-top:26px;font-size:12.5px;color:var(--tinta-fraca);text-align:center}
@media print{body{background:#fff;padding:0}section,.veredito{break-inside:avoid}}
`;

// Descritivo, não prescritivo: a ferramenta relata a divergência entre os dois
// arquivos e não opina sobre o que a peça deveria conter.
const FRASES_STATUS = {
  aprovado: 'Válida: pode ser anexada no sistema. Sem divergência de conteúdo entre o HTML e o CONTEUDO.docx.',
  atencao: 'Pontos para o analista avaliar.',
  reprovado: 'Divergências encontradas entre o HTML e o CONTEUDO.docx.',
  erro: 'Não foi possível concluir a conferência.',
};

const _tem = (obj, k) => Object.prototype.hasOwnProperty.call(obj, k);
const _doisDigitos = (n) => String(n).padStart(2, '0');

function _e(texto) {
  return pyos.escaparHtml(texto);
}

function _secao_imagens(r) {
  if (!r) return '';
  const itens = [];

  for (const [nome, motivo] of r.fora_da_taxonomia) {
    itens.push(['alta', 'Fora da taxonomia',
      `<span class="arquivo">${_e(nome)}</span> — ${_e(motivo)}`]);
  }
  if (r.numeros_faltando.length) {
    const numeros = r.numeros_faltando.map(_doisDigitos).join(', ');
    itens.push(['alta', 'Sequência com furo', `faltam os números ${numeros} na pasta`]);
  }
  if (r.nao_comeca_em_um) {
    itens.push(['media', 'Sequência não inicia em 01', 'primeiro número da pasta não é 01']);
  }
  if (r.numeros_duplicados.length) {
    const numeros = r.numeros_duplicados.map(_doisDigitos).join(', ');
    itens.push(['alta', 'Número repetido', `o número ${numeros} aparece em mais de um arquivo`]);
  }
  for (const nome of r.extensao_invalida) {
    itens.push(['media', 'Extensão fora do padrão', _e(nome)]);
  }
  for (const nome of r.no_html_fora_da_pasta) {
    itens.push(['alta', 'Chamada sem arquivo',
      `o HTML chama <span class="arquivo">${_e(nome)}</span>, que não existe na pasta`]);
  }
  for (const nome of r.na_pasta_fora_do_html) {
    itens.push(['alta', 'Imagem não utilizada',
      `<span class="arquivo">${_e(nome)}</span> está na pasta, mas não é chamada no HTML`]);
  }
  for (const [na_pasta, no_html] of r.divergencia_de_caixa) {
    itens.push(['alta', 'Caixa divergente',
      `pasta: <span class="arquivo">${_e(na_pasta)}</span> · `
      + `HTML: <span class="arquivo">${_e(no_html)}</span>`]);
  }
  for (const nome of r.sem_numeracao_zero_a_esquerda) {
    itens.push(['baixa', 'Numeração sem zero à esquerda',
      `<span class="arquivo">${_e(nome)}</span> — o padrão é 01, 02, 03`]);
  }

  let corpo = itens.map(([classe, rotulo, texto]) => (
    `<li class="${classe}"><span class="rotulo">${_e(rotulo)}</span>${texto}</li>`
  )).join('');
  if (!corpo) {
    corpo = '<p class="vazio">Nomes seguem a quebra, sequência sem furo e todas as imagens aparecem no HTML.</p>';
  } else {
    corpo = `<ul class="itens">${corpo}</ul>`;
  }

  let repetidas = '';
  const rep = r.repeticoes_no_html instanceof Map
    ? [...r.repeticoes_no_html.entries()] : Object.entries(r.repeticoes_no_html || {});
  if (rep.length) {
    const lista = sorted(rep, (p) => p).map(([n, q]) => `${_e(n)} (${q}x)`).join(', ');
    repetidas = `<p class='contexto'>Reaproveitadas no HTML (permitido): ${lista}</p>`;
  }

  return `
    <section>
      <h2>Imagens <span class="contagem">· ${r.arquivos.length} na pasta · ${r.total_referencias_html} chamadas no HTML</span></h2>
      <p class="resumo">Taxonomia, sequência numérica e cruzamento entre a pasta e o código.</p>
      ${corpo}${repetidas}
    </section>`;
}

function _secao_texto(r, modo = 'sequencia') {
  if (!r) return '';
  const blocos = [];
  for (const d of r.divergencias) {
    const rotulos = {
      faltando: 'Está no HTML, não está no CONTEUDO',
      trocado: 'Escrito de forma diferente nos dois',
      sobrando: 'Está no CONTEUDO, não está no HTML',
      fora_de_ordem: 'Mesmas palavras, ordem diferente',
      acento_pontuacao: 'Acento ou pontuação diferente',
      espacamento: 'Mesmo texto, espaçamento diferente',
    };
    const nomes_de_bloco = {
      disclaimer: 'no bloco de disclaimer',
      'opt-out': 'no bloco de descadastro',
      atendimento: 'no bloco de atendimento',
    };
    const classe = d.gravidade;
    let rotulo = _tem(rotulos, d.tipo) ? rotulos[d.tipo] : d.tipo;
    if (d.tipo === 'acento_pontuacao') {
      if (d.grotesca) {
        rotulo = 'Acento/pontuação diferente em excesso';
      } else {
        const m = {
          acento: 'Pequena diferença de acento',
          pontuacao: 'Pequena diferença de pontuação',
        };
        rotulo = _tem(m, d.natureza) ? m[d.natureza] : 'Pequena diferença de acento e pontuação';
        rotulo += ' (aviso, não reprova)';
      }
    } else if (d.aviso_leve) {
      rotulo += ` (aviso, não reprova: ${d.motivo_leve})`;
    }
    let marca = '';
    if (d.obrigatorio) {
      marca = ('<span class="obrigatorio">'
        + `${_e(_tem(nomes_de_bloco, d.obrigatorio) ? nomes_de_bloco[d.obrigatorio] : '')}</span>`);
    }
    let diff = '';
    if (d.trecho_html || d.trecho_docx) {
      diff = `<div class="diff">
              <div class="lado html"><span class="tag">HTML</span><span>${_e(d.trecho_html) || '—'}</span></div>
              <div class="lado docx"><span class="tag">CONTEUDO</span><span>${_e(d.trecho_docx) || '—'}</span></div>
            </div>`;
    }
    let contexto = '';
    if (d.contexto_antes.startsWith('palavras ausentes:')) {
      contexto = ('<p class="contexto"><b>Palavras que faltam no docx:</b> '
        + `<code>${_e(d.contexto_antes.split('palavras ausentes: ').join(''))}</code></p>`);
    } else if (d.contexto_antes || d.contexto_depois) {
      contexto = ('<p class="contexto">Contexto: '
        + `<code>${_e(d.contexto_antes)}</code> … `
        + `<code>${_e(d.contexto_depois)}</code></p>`);
    }
    let citacoes = '';
    if (d.citacao_html || d.citacao_docx) {
      citacoes = (
        '<div class="citacoes">'
        + '<div class="citacao"><span class="citacao-fonte">Como está no HTML</span>'
        + `<blockquote>${_e(d.citacao_html) || '—'}</blockquote></div>`
        + '<div class="citacao">'
        + '<span class="citacao-fonte">Como está no CONTEUDO.docx</span>'
        + `<blockquote>${_e(d.citacao_docx) || '—'}</blockquote></div>`
        + '</div>'
      );
    }
    blocos.push(
      `<li class="${classe}"><span class="rotulo">${rotulo}</span>`
      + `em <span class="arquivo">${_e(d.origem)}</span>${marca}${diff}${contexto}`
      + `${citacoes}</li>`,
    );
  }

  const corpo = blocos.length ? `<ul class="itens">${blocos.join('')}</ul>` : (
    '<p class="vazio">O CONTEUDO.docx e a leitura do HTML têm as mesmas palavras, na mesma ordem.</p>'
  );

  let dispensados = '';
  if (r.trechos_dispensados.length) {
    const lista = r.trechos_dispensados.slice(0, 4).map((t) => _e(t)).join('; ');
    dispensados = ('<p class="contexto">Ignorado por ser texto de template: '
      + `${lista}</p>`);
  }

  let parcial = '';
  if (r.blocos_sem_ocr.length) {
    const lista = r.blocos_sem_ocr.map((i) => `<span class="arquivo">${_e(i)}</span>`).join(' ');
    parcial = ('<div class="aviso" style="margin-top:16px">O texto dentro destas '
      + `imagens não foi conferido. Confira no olho: ${lista}</div>`);
  }

  let descricao;
  if (modo === 'presenca') {
    descricao = ('Conferência parcial: sem a leitura de imagens, comparei apenas o '
      + 'texto escrito no código do HTML contra o CONTEUDO.docx, palavra a '
      + 'palavra. O que está dentro dos banners não entrou na conta.');
  } else {
    descricao = ('Comparação palavra a palavra entre a ordem de leitura do HTML '
      + '(texto vivo + texto dentro das imagens) e o CONTEUDO.docx.');
  }

  return `
    <section>
      <h2>Texto <span class="contagem">· ${pyos.floatStr(r.similaridade)}%</span></h2>
      <p class="resumo">${descricao}</p>
      ${corpo}${dispensados}${parcial}
    </section>`;
}

/** Regras de publicação que a peça não cumpre. Abre o relatório. */
function _secao_bloqueios(resultado) {
  const bloqueios = [...(resultado.bloqueios || [])];
  const alertas = [...(resultado.alertas || [])];
  if (!bloqueios.length && !alertas.length) return '';

  let partes = '';
  if (bloqueios.length) {
    const itens = bloqueios.map((b) => (
      `<li class="alta"><span class="rotulo">Impede a publicação</span>${_e(b)}</li>`
    )).join('');
    partes += `<ul class="itens">${itens}</ul>`;
  }
  if (alertas.length) {
    partes += ('<p class="contexto" style="margin-top:12px">'
      + alertas.map((a) => _e(a)).join(' · ') + '</p>');
  }

  return `
    <section>
      <h2>Regras de publicação</h2>
      <p class="resumo">Requisitos do banco para a peça subir.</p>
      ${partes}
    </section>`;
}

function _secao_avisos(resultado) {
  const itens = [...resultado.avisos];
  for (const a of resultado.apontamentos_assunto) {
    itens.push(`Pré-header do docx não localizado no HTML: “${a.trecho_docx}”`);
  }
  if (resultado.leitura_html && resultado.leitura_html.alts_vazios.length) {
    const nomes = resultado.leitura_html.alts_vazios.slice(0, 8).join(', ');
    itens.push(`Imagens sem atributo alt no HTML: ${nomes}`);
  }
  if (!itens.length) return '';
  const corpo = itens.map((i) => `<div class="aviso">${_e(i)}</div>`).join('');
  return `<section><h2>Observações</h2>${corpo}</section>`;
}

const _d2 = (n) => String(n).padStart(2, '0');

/** `agora` (opcional) existe só para os testes fixarem a hora. */
function gerar(resultado, caminho_saida, agora = null) {
  const status = resultado.status;
  const rt = resultado.resultado_texto;
  const ri = resultado.resultado_imagens;

  let corpo; let numeros;
  if (resultado.erros.length) {
    const conteudo = resultado.erros.map((e) => `<div class="aviso">${_e(e)}</div>`).join('');
    corpo = `<section><h2>Erros</h2>${conteudo}</section>`;
    numeros = '';
  } else {
    corpo = (_secao_bloqueios(resultado) + _secao_imagens(ri)
      + _secao_texto(rt, _ou(resultado.modo_texto, 'sequencia'))
      + _secao_avisos(resultado));
    numeros = `
        <div class="numeros">
          <div><b>${ri ? ri.arquivos.length : 0}</b><span>imagens</span></div>
          <div><b>${rt ? pyos.floatStr(rt.similaridade) : 0}%</b><span>aderência</span></div>
          <div><b>${rt ? rt.divergencias.length : 0}</b><span>divergências</span></div>
          <div><b>${resultado.ocr_ativo ? 'sim' : 'não'}</b><span>leitura de imagem</span></div>
        </div>`;
  }

  const dt = agora || new Date();
  const horario = `${_d2(dt.getDate())}/${_d2(dt.getMonth() + 1)}/${dt.getFullYear()} às ${_d2(dt.getHours())}:${_d2(dt.getMinutes())}`;
  const titulo = resultado.quebra || pyos.basename(resultado.pasta);
  const documento = `<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Conferência · ${_e(titulo)}</title>
<style>${CSS}</style></head><body><div class="folha">
  <header>
    <h1>Conferência de pacote</h1>
    <div class="quebra">${_e(titulo)}</div>
    <div class="meta">${_e(resultado.pasta)} · ${horario}</div>
  </header>
  <div class="veredito">
    <div>
      <div style="display:flex;align-items:center;gap:14px">
        <span class="selo ${status}">${status.toUpperCase()}</span>
        <p>${_tem(FRASES_STATUS, status) ? FRASES_STATUS[status] : ''}</p>
      </div>
      ${numeros}
    </div>
  </div>
  <p class="observacao-manual"><strong>Observação:</strong> Confira também a peça manualmente. O validador é automático e, como qualquer IA ou leitura de imagem (OCR), pode errar ou &quot;alucinar&quot;: ele ajuda, mas não substitui o seu olhar.</p>
  ${corpo}
  <footer>Validador de pacotes · Orquestração e Ativação de Campanhas</footer>
</div></body></html>`;

  fs.mkdirSync(path.dirname(path.resolve(caminho_saida)), { recursive: true });
  fs.writeFileSync(caminho_saida, documento, 'utf8');
  return caminho_saida;
}

const _ou = (v, padrao) => (v === undefined || v === null ? padrao : v);

module.exports = {
  CSS, FRASES_STATUS, _e, _secao_imagens, _secao_texto, _secao_bloqueios, _secao_avisos, gerar,
};
