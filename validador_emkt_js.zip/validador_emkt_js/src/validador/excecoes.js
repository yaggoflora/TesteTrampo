'use strict';
/*
 * Trechos com tratamento especial na comparação.
 *
 * Dois grupos, com efeitos opostos:
 *
 * DISPENSÁVEIS — texto de template que não precisa constar no CONTEUDO.docx.
 *   Hoje: o link de fallback do topo ("se não conseguiu visualizar, clique aqui").
 *   Estar no HTML e faltar no docx não é erro. Se o analista incluir no docx,
 *   também não é erro — a comparação continua casando normalmente.
 *
 * OBRIGATÓRIOS — disclaimer, opt-out e canais de atendimento.
 *   Faltar no docx é apontamento de gravidade alta e sinalizado como obrigatório
 *   no relatório, porque é conteúdo que o cliente com deficiência visual tem
 *   direito de receber.
 *
 * Ajuste as listas conforme o padrão das peças. Um trecho que case com as duas
 * listas é tratado como obrigatório — na dúvida, o sistema cobra.
 */

const R = require('./_pyre');

// --- texto de template, dispensável no CONTEUDO.docx ---
const DISPENSAVEIS = [
  // o verbo aparece em todas as conjugações que já vimos em pacote real:
  // conseguiu, consegue, conseguir, conseguindo, consiga
  'n[ãa]o\\s+(est[áa]\\s+)?conseg(uiu|ue|uir|uindo)',
  'n[ãa]o\\s+(consiga|conseguiu|consegue|conseguir)',
  '(problemas?|dificuldade)\\s+(para|ao|em)\\s+(visualizar|ver|abrir)',
  'caso\\s+n[ãa]o\\s+(consiga|esteja|visualize)',
  'visualiz(e|ar|ando)\\s+(no|em seu|pelo)\\s+navegador',
  'vers[ãa]o\\s+(online|web)\\s+(deste|do|desta)',
  'clique\\s+aqui\\s+para\\s+(visualizar|ver|abrir|acessar)',
  'abrir\\s+ess[ea]\\s+e-?\\s?mail',
  'n[ãa]o\\s+(está|esta)\\s+(vendo|visualizando)',
];

// --- conteúdo que precisa estar no docx ---
const OBRIGATORIOS = {
  'opt-out': [
    'descadastr',
    'cancelar\\s+(o\\s+)?(recebimento|inscri)',
    'n[ãa]o\\s+(desejo|quero|deseja)\\s+(mais\\s+)?receber',
    'sair\\s+da\\s+lista',
    'opt.?out',
    'deixar\\s+de\\s+receber',
  ],
  disclaimer: [
    'sujeito\\s+[àa]\\s+(an[áa]lise|aprova[çc][ãa]o)',
    'consulte\\s+(as\\s+)?condi[çc][õo]es',
    'cet\\b|custo\\s+efetivo\\s+total',
    'taxa\\s+de\\s+juros',
    'v[áa]lid[ao]\\s+(at[ée]|para)',
    'imagens?\\s+meramente\\s+ilustrativ',
    'regulamento',
    'cnpj',
    // rodapé padrão das peças do banco — é onde o endereço aparece e onde
    // a proteção contra hyperlink precisa estar
    'mensagem\\s+foi\\s+gerada\\s+automaticamente',
    'n[ãa]o\\s+pode\\s+ser\\s+respondida',
    'remetentes\\s+confi[áa]veis',
    'n[ãa]o\\s+insere\\s+anexos',
    'mantenha\\s+seus\\s+dados\\s+atualizados',
    'dados\\s+banc[áa]rios\\s+ou\\s+pessoais',
    'hor[áa]rio\\s+de\\s+bras[íi]lia',
    'acesso\\s+do\\s+exterior',
  ],
  atendimento: [
    'ouvidoria',
    'central\\s+de\\s+(atendimento|relacionamento)',
    'fale\\s+conosco',
    'sac\\b',
    'deficiente\\s+auditiv|fala\\s+e\\s+audi[çc][ãa]o',
    'procon',
  ],
};

// --- trechos em que a divergência notifica, mas não reprova ---------------
//
// O bloco de redes sociais é o caso clássico: na peça vem só a palavra
// "ACOMPANHE:" seguida dos ícones, e no docx o redator escreve a frase inteira
// ("Acompanhe o Bradesco nas Redes Sociais!"). Os dois estão certos, cada um no
// seu suporte — cobrar igualdade aí reprovaria praticamente toda campanha.
const TOLERADOS = [
  'acompanhe',
  'redes\\s+sociais',
  '\\b(siga|curta)\\b.{0,20}(bradesco|nas\\s+redes)',
  '\\b(facebook|instagram|linkedin|youtube|twitter|tiktok|whatsapp)\\b',
];

const _RE_TOLERADOS = TOLERADOS.map((p) => R.compilar(p, 'i'));
const _RE_DISPENSAVEIS = DISPENSAVEIS.map((p) => R.compilar(p, 'i'));
const _RE_OBRIGATORIOS = {};
for (const [rotulo, padroes] of Object.entries(OBRIGATORIOS)) {
  _RE_OBRIGATORIOS[rotulo] = padroes.map((p) => R.compilar(p, 'i'));
}

/**
 * Devolve "obrigatorio:<rótulo>", "dispensavel", "tolerado" ou "".
 * Obrigatório vence os demais quando mais de um casa.
 */
function classificar(texto) {
  if (!texto) return '';
  for (const [rotulo, padroes] of Object.entries(_RE_OBRIGATORIOS)) {
    if (padroes.some((p) => R.buscar(p, texto))) return `obrigatorio:${rotulo}`;
  }
  if (_RE_DISPENSAVEIS.some((p) => R.buscar(p, texto))) return 'dispensavel';
  if (_RE_TOLERADOS.some((p) => R.buscar(p, texto))) return 'tolerado';
  return '';
}

module.exports = { DISPENSAVEIS, OBRIGATORIOS, TOLERADOS, classificar, _RE_TOLERADOS, _RE_DISPENSAVEIS, _RE_OBRIGATORIOS };
