'use strict';
/**
 * Converte o resultado da conferência em JSON, para a interface web desenhar.
 */

const pyos = require('../lib/pyos');
const { fmtFixed } = require('../lib/pyutil');
const R = require('./_pyre');
const regras = require('./regras');

const _tem = (obj, k) => Object.prototype.hasOwnProperty.call(obj, k);

// Rótulos descritivos de propósito. A ferramenta reporta o que está diferente
// entre os dois arquivos; ela não diz qual dos dois está certo nem o que a peça
// deveria conter. Essa decisão é de quem produziu a campanha.
const ROTULOS = {
  faltando: 'Está no HTML, não está no CONTEUDO',
  trocado: 'Escrito de forma diferente nos dois',
  sobrando: 'Está no CONTEUDO, não está no HTML',
  fora_de_ordem: 'Mesmas palavras, ordem diferente',
  acento_pontuacao: 'Acento ou pontuação diferente',
  espacamento: 'Mesmo texto, espaçamento diferente',
};

// Nome do bloco onde a divergência caiu — é localização, não julgamento de
// conteúdo: ajuda quem lê o report a achar o trecho na peça.
const BLOCOS = {
  disclaimer: 'no bloco de disclaimer',
  'opt-out': 'no bloco de descadastro',
  atendimento: 'no bloco de atendimento',
};

/**
 * Qual motor leu as imagens nesta conferência.
 *
 * Vai junto no resultado porque cada motor escreve diferente: um devolve
 * "você" com acento, outro "voce". Comparar um docx gerado num motor contra
 * uma peça lida noutro acusa divergência em cada acento, e sem essa
 * informação na tela não há como desconfiar disso.
 */
function _descricao_do_motor() {
  const { motor_ativo } = require('./ocr');
  const motor = motor_ativo();
  return motor ? motor.descricao : '';
}

function _rotulo_divergencia(d) {
  if (d.tipo !== 'acento_pontuacao') return _tem(ROTULOS, d.tipo) ? ROTULOS[d.tipo] : d.tipo;
  if (d.grotesca) return 'Acento/pontuação diferente em excesso';
  const m = {
    acento: 'Pequena diferença de acento',
    pontuacao: 'Pequena diferença de pontuação',
  };
  return _tem(m, d.natureza) ? m[d.natureza] : 'Pequena diferença de acento e pontuação';
}

const _ou = (v, padrao) => (v === undefined || v === null ? padrao : v);

function _divergencia(d) {
  const rotulo = _rotulo_divergencia(d);
  return {
    natureza: _ou(d.natureza, ''),
    motivo_grotesca: _ou(d.motivo_grotesca, ''),
    motivo_leve: _ou(d.motivo_leve, ''),
    tipo: d.tipo,
    rotulo,
    gravidade: d.gravidade,
    bloco: _tem(BLOCOS, d.obrigatorio) ? BLOCOS[d.obrigatorio] : '',
    tolerado: _ou(d.tolerado, false),
    obrigatorio: d.obrigatorio,
    citacao_html: _ou(d.citacao_html, ''),
    citacao_docx: _ou(d.citacao_docx, ''),
    origem: d.origem,
    trecho_html: d.trecho_html,
    trecho_docx: d.trecho_docx,
    contexto_antes: d.contexto_antes,
    palavras_ausentes: d.contexto_antes.startsWith('palavras ausentes:')
      ? d.contexto_antes.split('palavras ausentes: ').join('') : '',
    contexto_depois: d.contexto_depois,
  };
}

// ------------------------------------------------- e-mail de devolução ao marketing

const RODAPE_EMAIL = (
  'Atenciosamente,\n\n'
  + '{{nome}}\n'
  + '4832 | CRM\n'
  + '{{email}}\n\n'
  + 'BANCO BRADESCO S.A.\n'
  + 'Cidade de Deus, Osasco, SP - Prédio Cinza, 1º andar\n\n'
  + 'Classificação: INTERNA'
);

// {{saudacao}}, {{nome}}, {{email}} e {{validade}} são preenchidos na hora, por
// renderizar_email() aqui ou pelo mesmo trecho em static/validador.js.
const MODELO_APROVADO = (
  'Prezados, {{saudacao}}!\n\n'
  + 'Tudo bem?\n\n'
  + 'As peças abaixo foram recebidas, verificadas e arquivadas em nosso controle.\n\n'
  + 'EMKT\n\n'
  + '{{validade}}\n\n' + RODAPE_EMAIL
);

const MODELO_AJUSTES = (
  'Prezados, {{saudacao}}!\n\n'
  + 'As peças abaixo necessitam de ajustes:\n\n'
  + 'EMKT\n'
  + '{{acao}}\n\n'
  + '{{validade}}\n\n' + RODAPE_EMAIL
);

const RE_VALIDADE = R.compilar('val[\\s_\\-]*at[eé][\\s_\\-]*(\\d{1,2})[._\\-/](\\d{2,4})', 'i');

/** Antes das 12h, bom dia; das 12h às 18h, boa tarde; depois, boa noite. */
function saudacao_do_horario(agora = null) {
  const hora = (agora || new Date()).getHours();
  if (hora < 12) return 'bom dia';
  if (hora < 18) return 'boa tarde';
  return 'boa noite';
}

/** VAL_ATE_MM.AA tirado do nome da pasta; vazio quando o nome não traz. */
function validade_da_pasta(nome_pasta) {
  const achado = R.buscar(RE_VALIDADE, nome_pasta || '');
  if (!achado) return '';
  const mes = String(R.pyInt(achado[1])).padStart(2, '0');
  return `VAL_ATE_${mes}.${Array.from(achado[2]).slice(-2).join('')}`;
}

function renderizar_email(modelo, nome = '', email = '', validade = '', acao = '', agora = null) {
  let texto = modelo;
  const trocas = [
    ['{{saudacao}}', saudacao_do_horario(agora)],
    ['{{nome}}', nome || '[Nome Funcionário]'],
    ['{{email}}', email || '[Email corporativo]'],
    ['{{validade}}', validade || 'VAL_ATE_[MM.AA]'],
    ['{{acao}}', acao],
  ];
  for (const [chave, valor] of trocas) texto = texto.split(chave).join(valor);
  return texto;
}

const _rstripBarras = (s) => String(s).replace(/[/\\]+$/, '');

function _email_retorno(r, status) {
  const nome_acao = r.nome_pasta || pyos.basename(_rstripBarras(r.pasta));
  const sug = { aprovado: 'aprovado', reprovado: 'ajustes' };
  return {
    // qual e-mail faz sentido: aprovado → arquivadas; reprovado → ajustes;
    // atenção e erro ficam sem sugestão, quem decide é o analista
    sugerido: _tem(sug, status) ? sug[status] : '',
    pode_anexar: status === 'aprovado',
    acao: nome_acao,
    validade: validade_da_pasta(nome_acao),
    modelo_aprovado: MODELO_APROVADO.split('{{acao}}').join(nome_acao),
    modelo_ajustes: MODELO_AJUSTES.split('{{acao}}').join(nome_acao),
  };
}

const _doisDigitos = (n) => String(n).padStart(2, '0');

function _imagens(ri) {
  if (!ri) return [];
  const itens = [];
  const add = (g, r, t) => itens.push({ gravidade: g, rotulo: r, texto: t });

  for (const [nome, motivo] of ri.fora_da_taxonomia) {
    add('alta', 'Nome fora do padrão da quebra', `${nome} — ${motivo}`);
  }
  if (ri.numeros_faltando.length) {
    add('alta', 'Numeração com furo',
      'faltam os números ' + ri.numeros_faltando.map(_doisDigitos).join(', '));
  }
  if (ri.nao_comeca_em_um) {
    add('media', 'Não começa em 01', 'o primeiro número da pasta não é 01');
  }
  if (ri.numeros_duplicados.length) {
    add('alta', 'Número repetido',
      'o número ' + ri.numeros_duplicados.map(_doisDigitos).join(', ')
      + ' aparece em mais de um arquivo');
  }
  for (const nome of ri.extensao_invalida) add('media', 'Extensão fora do padrão', nome);
  for (const nome of ri.no_html_fora_da_pasta) {
    add('alta', 'Chamada no HTML sem arquivo na pasta',
      `o HTML chama ${nome}, que não está na pasta de imagens`);
  }
  for (const nome of ri.na_pasta_fora_do_html) {
    add('alta', 'Arquivo na pasta sem chamada no HTML',
      `${nome} está na pasta, mas não aparece no código`);
  }
  for (const [na_pasta, no_html] of ri.divergencia_de_caixa) {
    add('alta', 'Maiúscula/minúscula diferente', `pasta: ${na_pasta} · HTML: ${no_html}`);
  }
  for (const [nome, kb] of ri.acima_do_peso) {
    add('alta', 'Acima de 1 MB',
      `${nome} tem ${fmtFixed(kb / 1024, 1)} MB — o limite para publicação é 1 MB`);
  }
  for (const nome of ri.sem_numeracao_zero_a_esquerda) {
    add('baixa', 'Sem zero à esquerda', `${nome} — o padrão é 01, 02, 03`);
  }
  return itens;
}

/** dict do Python -> objeto JSON (aceita Map ou objeto). */
function _comoObjeto(x) {
  if (x instanceof Map) return Object.fromEntries(x.entries());
  return x;
}

function para_json(r, id_relatorio = '') {
  const ri = r.resultado_imagens; const rt = r.resultado_texto;

  const observacoes = [...r.avisos];
  for (const a of r.apontamentos_assunto) {
    observacoes.push(`Pré-header do docx não localizado no HTML: ${a.trecho_docx}`);
  }
  // Leitura de imagem com confiança baixa: o texto entrou na comparação, mas
  // pode ter caractere errado. Melhor dizer onde a máquina teve dúvida do que
  // deixar passar como se fosse certeza.
  if (r.leitura_html) {
    const incertas = [];
    // falha técnica na leitura vem primeiro: é defeito a corrigir, não
    // dúvida sobre o conteúdo da peça
    const falhas = [];
    for (const bloco of r.leitura_html.fita) {
      if (bloco.tipo !== 'imagem') continue;
      if (bloco.ocr_erro) {
        const marca = `${bloco.referencia}: ${bloco.ocr_erro}`;
        if (!falhas.includes(marca)) falhas.push(marca);
        continue;
      }
      if (bloco.ocr_aviso) {
        if (bloco.ocr_aviso.includes('incerta') || bloco.ocr_aviso.includes('nenhum texto')) {
          const marca = `${bloco.referencia} (${bloco.ocr_aviso})`;
          if (!incertas.includes(marca)) incertas.push(marca);
        }
      }
    }
    if (falhas.length) {
      observacoes.push(
        'Falha ao ler estas imagens (é defeito do sistema, não da peça): '
        + falhas.slice(0, 4).join('; '),
      );
    }
    if (incertas.length) {
      observacoes.push('Imagens com leitura duvidosa: ' + incertas.slice(0, 5).join('; '));
    }
  }

  if (r.leitura_html && (r.leitura_html.espacos_irregulares || []).length) {
    const amostras = r.leitura_html.espacos_irregulares.slice(0, 4).join('; ');
    observacoes.push(
      'Espaço duplicado ou espaço antes de pontuação no texto do HTML '
      + `(não reprova, mas vale revisar): ${amostras}`,
    );
  }
  if (r.leitura_html && r.leitura_html.alts_vazios.length) {
    const nomes = r.leitura_html.alts_vazios.slice(0, 8).join(', ');
    observacoes.push(`Imagens sem atributo alt no HTML: ${nomes}`);
  }

  const apontamentos_imagem = _imagens(ri);
  const divergencias = rt ? rt.divergencias.map(_divergencia) : [];
  const bloqueios = _ou(r.bloqueios, []);
  const total_apontamentos = apontamentos_imagem.length + divergencias.length + bloqueios.length;
  let graves = apontamentos_imagem.filter((a) => a.gravidade === 'alta').length;
  graves += divergencias.filter((d) => d.gravidade === 'alta').length;
  graves += bloqueios.length;

  const status = r.status;
  const nome_da_pasta = r.nome_pasta || pyos.basename(_rstripBarras(r.pasta));
  return {
    id: id_relatorio,
    total_apontamentos,
    apontamentos_graves: graves,
    status,
    email_retorno: _email_retorno(r, status),
    nome_pasta: nome_da_pasta,
    quebra: r.quebra || '',
    pasta: r.pasta,
    arquivo_html: r.caminho_html ? pyos.basename(r.caminho_html) : '',
    arquivo_conteudo: r.caminho_conteudo ? pyos.basename(r.caminho_conteudo) : '',
    arquivo_assunto: r.caminho_assunto ? pyos.basename(r.caminho_assunto) : '',
    erros: r.erros,
    bloqueios: [...bloqueios],
    alertas: [..._ou(r.alertas, [])],
    redirects: r.leitura_html ? _ou(r.leitura_html.redirects, 0) : 0,
    assunto: r.leitura_assunto ? _ou(r.leitura_assunto.assunto, '') : '',
    pre_header: r.leitura_assunto ? _ou(r.leitura_assunto.pre_header, '') : '',
    limite_assunto: regras.LIMITE_ASSUNTO,
    limite_pre_header: regras.LIMITE_PRE_HEADER,
    observacoes,
    ocr_ativo: r.ocr_ativo,
    motor_ocr: r.ocr_ativo ? _descricao_do_motor() : '',
    modo_texto: _ou(r.modo_texto, 'sequencia'),
    motivo_ocr: r.motivo_ocr,
    imagens: {
      material_de_apoio: ri ? ri.material_de_apoio : [],
      total_pasta: ri ? ri.arquivos.length : 0,
      total_chamadas_html: ri ? ri.total_referencias_html : 0,
      reaproveitadas: ri ? _comoObjeto(ri.repeticoes_no_html) : {},
      apontamentos: apontamentos_imagem,
    },
    texto: {
      similaridade: rt ? rt.similaridade : 0,
      avisos_de_diferenca: divergencias.filter((d) => d.gravidade === 'baixa').length,
      divergencias,
      dispensados: rt ? rt.trechos_dispensados : [],
      sem_leitura: rt ? rt.blocos_sem_ocr : [],
      blocos_conferidos: rt ? _ou(rt.blocos_conferidos, 0) : 0,
      correcoes_ocr: rt ? _ou(rt.correcoes_ocr, []) : [],
      imagens_reordenadas: rt ? _ou(rt.imagens_reordenadas, []) : [],
    },
  };
}

module.exports = {
  ROTULOS, BLOCOS, _descricao_do_motor, _rotulo_divergencia, _divergencia,
  RODAPE_EMAIL, MODELO_APROVADO, MODELO_AJUSTES, RE_VALIDADE, saudacao_do_horario,
  validade_da_pasta, renderizar_email, _email_retorno, _imagens, para_json,
};
