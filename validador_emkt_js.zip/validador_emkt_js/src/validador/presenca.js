'use strict';
/*
 * Comparação por presença, usada quando o texto das imagens não pôde ser lido.
 *
 * Sem OCR, a fita do HTML fica incompleta: o texto dos banners some, mas continua
 * no CONTEUDO.docx. Comparar sequência nessa condição alinha trecho errado com
 * trecho errado e produz apontamento que não existe.
 *
 * Aqui a pergunta é outra e mais honesta: cada trecho de texto vivo do HTML
 * aparece no docx? Sobra no docx não é cobrada, porque quase sempre é o texto das
 * imagens que não conseguimos ler.
 *
 * Espaçamento, quebra de linha e divisão de parágrafo não contam — a comparação é
 * palavra a palavra.
 */

const R = require('./_pyre');
const { SequenceMatcher } = require('../lib/difflib');
const { pyRound, pyIsDigit } = require('../lib/pyutil');
const correcao_ocr = require('./correcao_ocr');
const ordenacao = require('./ordenacao');
const regras = require('./regras');
const { Divergencia } = require('./comparador');
const { tokenizar } = require('./normalizacao');

// trechos muito curtos geram ruído; abaixo disso só checamos presença das palavras
const MINIMO_PARA_SEQUENCIA = 3;

class ResultadoPresenca {
  constructor(campos = {}) {
    Object.assign(this, {
      similaridade: 0.0,
      divergencias: [],
      trechos_dispensados: [],
      obrigatorios_ausentes: [],
      blocos_sem_ocr: [],
      blocos_conferidos: 0,
      correcoes_ocr: [],
      imagens_reordenadas: [],
      comparacao_parcial: true,
      total_tokens_html: 0,
      total_tokens_docx: 0,
      tokens_iguais: 0,
    }, campos);
  }

  get status() {
    if (this.divergencias.some((d) => d.gravidade === 'alta')) return 'reprovado';
    return 'parcial';
  }

  get aprovado() {
    return false; // nunca aprova: parte da peça não foi conferida
  }

  por_gravidade(nivel) {
    return this.divergencias.filter((d) => d.gravidade === nivel);
  }
}

function _igual(a, i, sub) {
  for (let k = 0; k < sub.length; k++) if (a[i + k] !== sub[k]) return false;
  return true;
}

/** Procura a sequência exata de palavras dentro do docx. */
function _indice_da_subsequencia(sub, universo) {
  if (!sub.length || sub.length > universo.length) return -1;
  const primeiro = sub[0];
  const limite = universo.length - sub.length + 1;
  for (let i = 0; i < limite; i++) {
    if (universo[i] === primeiro && _igual(universo, i, sub)) return i;
  }
  return -1;
}

/**
 * Acha o parágrafo do docx que mais se parece com o trecho da peça.
 *
 * A citação precisa ser o parágrafo inteiro, do jeito que está no arquivo:
 * é isso que a pessoa vai colar no report para mostrar a divergência sem
 * precisar dizer qual dos dois está certo.
 */
function _paragrafo_mais_proximo(tokens, paragrafos) {
  const alvo = new Set(tokens);
  if (!alvo.size) return '';

  const notas = [];
  paragrafos.forEach((paragrafo, indice) => {
    const palavras = new Set(tokenizar(paragrafo));
    if (!palavras.size) return;
    // cobertura: quanto do parágrafo do docx está no trecho da peça.
    // Usar cobertura em vez de similaridade evita descartar um parágrafo
    // curto ("Banco Exemplo") só por ser menor que o bloco da peça.
    let comum = 0;
    for (const p of palavras) if (alvo.has(p)) comum++;
    const cobertura = comum / palavras.size;
    if (cobertura >= 0.5) notas.push([indice, paragrafo]);
  });

  if (!notas.length) return '';

  // Cita a faixa contínua entre o primeiro e o último parágrafo que casaram.
  // Quando algo entrou no meio — o caso de ordem trocada — é justamente essa
  // linha intrusa que explica o apontamento, e ela só aparece se a citação
  // não pular buracos.
  const indices = notas.map(([i]) => i);
  const inicio = Math.min(...indices);
  const fim = Math.max(...indices);
  if (fim - inicio > 6) {
    return indices.slice().sort((a, b) => a - b).slice(0, 5).map((i) => paragrafos[i]).join('\n');
  }
  return paragrafos.slice(inicio, fim + 1).join('\n');
}

function comparar(fita, paragrafos_docx) {
  const resultado = new ResultadoPresenca();

  let tokens_docx = [];
  for (const paragrafo of paragrafos_docx) tokens_docx.push(...tokenizar(paragrafo));
  // a busca compara em forma canônica, que absorve as confusões de caractere
  // do OCR (0/o, 1/l); o relatório continua exibindo o texto original
  tokens_docx = tokens_docx.map((t) => correcao_ocr.canonizar(t));
  const conjunto_docx = new Set(tokens_docx);
  const vocabulario = conjunto_docx;
  resultado.total_tokens_docx = tokens_docx.length;

  // mesma ideia do modo completo: dentro da imagem, a ordem que vale é a do
  // docx, não a que o OCR inferiu do layout
  for (const bloco of fita) {
    if (bloco.tipo === 'imagem' && bloco.conteudo && bloco.ocr_lido) {
      const ajuste = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx);
      if (ajuste.reordenou) {
        bloco.conteudo = ajuste.linhas.join('\n');
        bloco.reordenado = true;
        resultado.imagens_reordenadas.push(bloco.referencia || 'imagem');
      }
    }
  }

  const vistos_sem_leitura = new Set();
  let tokens_html_total = 0;
  let tokens_encontrados = 0;

  for (const bloco of fita) {
    if (bloco.oculto) continue;

    if (bloco.tipo === 'imagem' && !bloco.ocr_lido) {
      const nome = bloco.referencia || 'imagem';
      if (!vistos_sem_leitura.has(nome)) {
        vistos_sem_leitura.add(nome);
        resultado.blocos_sem_ocr.push(nome);
      }
      continue;
    }

    let tokens = tokenizar(bloco.conteudo);
    // Mesmo com imagens faltando, as que FORAM lidas passam pela correção:
    // sem isto, "nasuaconta" e "a0" viram apontamento falso justamente no
    // modo em que o sistema já está conferindo menos.
    if (bloco.tipo === 'imagem' && bloco.ocr_lido) {
      const [corrigidos, separados] = correcao_ocr.corrigir(tokens, vocabulario);
      tokens = corrigidos;
      resultado.correcoes_ocr.push(...separados);
    }
    if (!tokens.length) continue;
    // duas versões: a canônica busca, a original aparece no relatório.
    // Sem isso o diff mostraria "R$ so ooo oo" no lugar de "R$ 50 000 00".
    const exibicao = tokens.slice();
    tokens = tokens.map((t) => correcao_ocr.canonizar(t));

    tokens_html_total += tokens.length;
    const origem = bloco.tipo === 'imagem' ? bloco.referencia : 'texto vivo';
    let obrigatorio = '';
    if (bloco.classificacao.startsWith('obrigatorio')) {
      obrigatorio = bloco.classificacao.split(':').slice(1).join(':');
    }
    const tolerado = bloco.classificacao === 'tolerado';

    // texto de template: só é cobrado se o analista tiver escrito no docx
    if (bloco.classificacao === 'dispensavel') {
      resultado.trechos_dispensados.push(bloco.conteudo);
      tokens_encontrados += tokens.length;
      continue;
    }

    resultado.blocos_conferidos += 1;

    // 1. sequência exata no docx: caso perfeito
    if (tokens.length >= MINIMO_PARA_SEQUENCIA && _indice_da_subsequencia(tokens, tokens_docx) >= 0) {
      tokens_encontrados += tokens.length;
      continue;
    }

    // 2. todas as palavras existem, mas não juntas nessa ordem
    const ausentes = [];
    tokens.forEach((t, i) => { if (!conjunto_docx.has(t)) ausentes.push(exibicao[i]); });
    if (!ausentes.length) {
      tokens_encontrados += tokens.length;
      if (tokens.length >= MINIMO_PARA_SEQUENCIA) {
        resultado.divergencias.push(new Divergencia({
          tipo: 'fora_de_ordem',
          origem,
          trecho_html: exibicao.slice(0, 25).join(' '),
          trecho_docx: 'as mesmas palavras aparecem no docx, em outra ordem',
          obrigatorio,
          tolerado,
          citacao_html: bloco.conteudo,
          citacao_docx: _paragrafo_mais_proximo(tokens, paragrafos_docx),
        }));
      }
      continue;
    }

    // 3. faltam palavras: apontamento real
    tokens_encontrados += tokens.length - ausentes.length;
    let motivo_leve = '';
    const tem_numero = ausentes.some((t) => Array.from(t).some((c) => pyIsDigit(c)));
    if (bloco.tipo === 'imagem' && !obrigatorio && !tem_numero) {
      const significativas = tokens.filter((t) => Array.from(t).length >= regras.TAMANHO_MINIMO_PALAVRA_IMAGEM);
      if (!significativas.length) {
        motivo_leve = 'a leitura da imagem só tem ruído (ícone ou logotipo)';
      } else if (significativas.some((t) => conjunto_docx.has(t))) {
        motivo_leve = 'o texto da imagem aparece só em parte no docx';
      }
    }
    const melhor = _trecho_mais_parecido(tokens, tokens_docx);
    const divergencia = new Divergencia({
      tipo: 'faltando',
      origem,
      trecho_html: exibicao.slice(0, 25).join(' '),
      trecho_docx: melhor,
      contexto_antes: 'palavras ausentes: ' + ausentes.slice(0, 12).join(', '),
      obrigatorio,
      tolerado,
      citacao_html: bloco.conteudo,
      citacao_docx: _paragrafo_mais_proximo(tokens, paragrafos_docx),
      aviso_leve: !!motivo_leve,
      motivo_leve,
    });
    resultado.divergencias.push(divergencia);
    if (obrigatorio) {
      resultado.obrigatorios_ausentes.push(`${obrigatorio}: ${divergencia.trecho_html}`);
    }
  }

  resultado.total_tokens_html = tokens_html_total;
  resultado.tokens_iguais = tokens_encontrados;
  resultado.similaridade = tokens_html_total ? pyRound(tokens_encontrados / tokens_html_total * 100, 1) : 0.0;
  return resultado;
}

/** Acha no docx o trecho mais próximo, para mostrar lado a lado no relatório. */
function _trecho_mais_parecido(tokens, universo) {
  if (!universo.length) return '—';
  const matcher = new SequenceMatcher(null, universo, tokens, false);
  const bloco = matcher.find_longest_match(0, universo.length, 0, tokens.length);
  if (bloco.size === 0) return 'trecho não localizado no docx';
  const inicio = Math.max(0, bloco.a - 3);
  const fim = Math.min(universo.length, bloco.a + bloco.size + 3);
  return universo.slice(inicio, fim).join(' ');
}

module.exports = {
  MINIMO_PARA_SEQUENCIA, ResultadoPresenca, _indice_da_subsequencia, _paragrafo_mais_proximo,
  comparar, _trecho_mais_parecido,
};
