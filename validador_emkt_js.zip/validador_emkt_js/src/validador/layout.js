'use strict';
/*
 * Ordem de leitura derivada do desenho da peça.
 *
 * O reconhecedor devolve caixas soltas com posição. Transformar isso em texto
 * exige decidir a ordem — e é aí que a peça de banco quebra o critério ingênuo.
 * Ler por faixa horizontal junta o "50%" de um cartão com o item que estiver na
 * mesma altura, à direita. Ler por coluna separa o número do que ele qualifica.
 *
 * A técnica clássica para isso é análise de layout por projeção: somar a
 * ocupação das caixas ao longo de um eixo e procurar os vales — faixas vazias
 * que separam blocos. Aplicada alternadamente nos dois eixos (o chamado XY-cut),
 * ela devolve a árvore de blocos da página e, percorrendo essa árvore, a ordem
 * em que uma pessoa leria.
 *
 * O primeiro corte é vertical e com folga larga: ele separa as SEÇÕES da peça
 * (um cartão, outro cartão, a faixa de filmes). Dentro de cada seção vem o corte
 * horizontal, que encontra as colunas, e só então o corte vertical fino, que
 * encontra as linhas. Essa ordem importa: cortando fino logo de início, o cartão
 * "50% de desconto | três itens" era picotado linha a linha e o número acabava
 * solto no meio da lista.
 *
 * A diferença para o que já existe em ordenacao.js: lá a ordem vem do
 * CONTEUDO.docx, aqui vem da própria imagem. Uma não substitui a outra — esta
 * funciona mesmo quando o docx está errado, que é justamente quando a
 * conferência importa.
 */

const R = require('./_pyre');
const { pyRound, sorted } = require('../lib/pyutil');

// Um vale só separa blocos se for largo o bastante. Medido em relação à altura
// média das linhas: espaço menor que isso é entrelinha, não separação.
//
// O vale horizontal é mais estreito de propósito. O corte em X só acontece
// quando existe um corredor vazio atravessando o bloco inteiro de cima a
// baixo — em texto corrido isso não existe, porque as linhas ocupam toda a
// largura. Então pode ser generoso: o cartão "50% de desconto | três itens"
// tem apenas 22 px de corredor com um detector, e 14 px com outro — a caixa
// de cada motor é um pouco mais larga ou mais justa. Exigir mais que isso
// deixava o número colado no item errado, e o valor precisa caber nos dois.
const VALE_MINIMO_VERTICAL = 0.9;
const VALE_MINIMO_HORIZONTAL = 0.42;

// No primeiro corte a folga vertical é bem maior: ali o que se procura são as
// SEÇÕES da peça (um cartão, outro cartão, a faixa de filmes), não as linhas.
// Com a folga normal, o espaço entre itens de uma lista — que é maior que a
// entrelinha — separava cada item num bloco, e o número da oferta ficava solto
// no meio deles antes que alguém notasse que ali havia duas colunas.
const VALE_DE_SECAO = 2.0;

// Bloco de uma linha só não tem coluna para separar: cortar em X ali apenas
// picotaria a frase.
const MINIMO_DE_LINHAS_PARA_CORTAR_EM_X = 2;

// Abaixo deste número de caixas não vale analisar: é texto corrido.
const MINIMO_PARA_ANALISAR = 4;

// Equivalentes dos erros que o Python captura em ordenar_por_layout
class ChaveAusente extends Error {}

/** c["chave"] do Python: ausente vira KeyError; valor não numérico vira ValueError (TypeError). */
function K(c, chave) {
  if (c === null || typeof c !== 'object' || !(chave in c)) throw new ChaveAusente(chave);
  return c[chave];
}

class Bloco {
  constructor(campos = {}) {
    Object.assign(this, { caixas: [], topo: 0.0, esquerda: 0.0, base: 0.0 }, campos);
  }

  get texto() {
    return this.caixas.map((c) => c.texto).join('\n');
  }
}

function _altura_media(caixas) {
  const alturas = caixas.map((c) => Math.max(1.0, K(c, 'base') - K(c, 'topo')));
  return alturas.reduce((a, b) => a + b, 0) / alturas.length;
}

/**
 * Separa as caixas nos vales de um eixo.
 *
 * Devolve a lista de grupos. Um grupo só é um grupo quando existe uma faixa
 * vazia maior que `folga` entre ele e o próximo — assim entrelinha não vira
 * separação de bloco.
 */
function _cortar(caixas, eixo, folga) {
  let inicio, fim;
  if (eixo === 'y') { inicio = 'topo'; fim = 'base'; } else { inicio = 'esquerda'; fim = 'direita'; }

  const ordenadas = sorted(caixas, (c) => K(c, inicio));
  const grupos = [];
  let atual = [ordenadas[0]];
  let limite = K(ordenadas[0], fim);

  for (const caixa of ordenadas.slice(1)) {
    if (K(caixa, inicio) - limite > folga) {
      grupos.push(atual);
      atual = [caixa];
      limite = K(caixa, fim);
    } else {
      atual.push(caixa);
      limite = Math.max(limite, K(caixa, fim));
    }
  }
  grupos.push(atual);
  return grupos;
}

function _montar(caixas) {
  return new Bloco({
    caixas: sorted(caixas, (c) => [K(c, 'topo'), K(c, 'esquerda')]),
    topo: Math.min(...caixas.map((c) => K(c, 'topo'))),
    esquerda: Math.min(...caixas.map((c) => K(c, 'esquerda'))),
    base: Math.max(...caixas.map((c) => K(c, 'base'))),
  });
}

/** Quantas faixas horizontais diferentes o bloco ocupa. */
function _linhas_distintas(caixas, altura) {
  const faixas = new Set(caixas.map((c) => pyRound(K(c, 'topo') / Math.max(1.0, altura * 0.7))));
  return faixas.size;
}

/**
 * XY-cut: corta num eixo, e cada pedaço é cortado no outro, recursivamente.
 *
 * A recursão para quando o corte não divide mais nada — aí aquele pedaço é
 * um bloco de texto, e suas caixas são lidas de cima para baixo.
 */
function _percorrer(caixas, altura, cortar_em_y, profundidade) {
  if (caixas.length <= 1 || profundidade > 6) return [_montar(caixas)];

  const eixo = cortar_em_y ? 'y' : 'x';
  let folga;
  if (cortar_em_y) folga = altura * (profundidade === 0 ? VALE_DE_SECAO : VALE_MINIMO_VERTICAL);
  else folga = altura * VALE_MINIMO_HORIZONTAL;

  let grupos;
  if (!cortar_em_y && _linhas_distintas(caixas, altura) < MINIMO_DE_LINHAS_PARA_CORTAR_EM_X) {
    grupos = [caixas];
  } else {
    grupos = _cortar(caixas, eixo, folga);
  }

  if (grupos.length === 1) {
    // não dividiu neste eixo: tenta o outro
    if (profundidade === 0 || cortar_em_y) return _percorrer(caixas, altura, !cortar_em_y, profundidade + 1);
    return [_montar(caixas)];
  }

  const blocos = [];
  for (const grupo of grupos) blocos.push(..._percorrer(grupo, altura, !cortar_em_y, profundidade + 1));
  return blocos;
}

const _temTexto = (c) => R.pyStrip(c && c.texto !== undefined && c.texto !== null ? c.texto : '') !== '';

/**
 * Devolve as caixas na ordem de leitura que o desenho da peça sugere.
 *
 * Caixas sem posição ou em número pequeno voltam como vieram: analisar
 * layout de três linhas soltas só adiciona risco.
 */
function ordenar_por_layout(caixas) {
  const uteis = caixas.filter(_temTexto);
  if (uteis.length < MINIMO_PARA_ANALISAR) return caixas;

  let blocos;
  try {
    const altura = _altura_media(uteis);
    blocos = _percorrer(uteis, altura, true, 0);
  } catch (e) {
    if (e instanceof ChaveAusente) return caixas;
    throw e;
  }

  // A recursão já devolve na ordem certa: ao cortar em X os grupos saem da
  // esquerda para a direita, ao cortar em Y de cima para baixo. Reordenar o
  // resultado achatado desfaz isso — os pedaços da coluna da direita passam a
  // competir um a um com a coluna da esquerda, e o número da oferta cai no
  // meio da lista.
  const ordenadas = [];
  for (const bloco of blocos) ordenadas.push(...bloco.caixas);
  return ordenadas;
}

/** Os blocos detectados, para inspeção e teste. */
function descrever_blocos(caixas) {
  const uteis = caixas.filter(_temTexto);
  if (uteis.length < MINIMO_PARA_ANALISAR) return [new Bloco({ caixas: uteis })];
  const altura = _altura_media(uteis);
  return _percorrer(uteis, altura, true, 0);
}

module.exports = {
  VALE_MINIMO_VERTICAL, VALE_MINIMO_HORIZONTAL, VALE_DE_SECAO,
  MINIMO_DE_LINHAS_PARA_CORTAR_EM_X, MINIMO_PARA_ANALISAR, Bloco,
  _altura_media, _cortar, _montar, _linhas_distintas, _percorrer, ordenar_por_layout, descrever_blocos,
};
