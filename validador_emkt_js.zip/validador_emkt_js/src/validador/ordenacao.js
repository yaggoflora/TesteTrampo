'use strict';
/*
 * Ordem de leitura dentro de uma imagem, usando o CONTEUDO.docx como referência.
 *
 * O problema: peça de banco usa layout em blocos. "50%" fica num cartão à
 * esquerda, "de desconto" embaixo dele, e três itens numa lista à direita. Não
 * existe uma ordem de leitura única aí — ler por linha horizontal junta o "50%"
 * com o item que estiver na mesma altura; ler por coluna separa o número do
 * desconto do que ele qualifica. Qualquer critério que a máquina escolha é um
 * chute, e o chute vira apontamento de "ordem diferente" em quase toda peça.
 *
 * Quem sabe a ordem certa é quem escreveu a peça, e isso está no docx.
 *
 * A regra aqui é conservadora de propósito: a reordenação só acontece quando
 * TODAS as linhas lidas da imagem são encontradas no docx. Se uma linha não
 * aparece lá — porque tem palavra trocada, porque o docx esqueceu um trecho —
 * nada é reordenado e a divergência aparece normalmente. Ou seja: isso silencia
 * ruído de diagramação, não silencia erro de conteúdo.
 *
 * Vale só DENTRO de cada imagem. A ordem entre os blocos da peça (o banner 01
 * vem antes do 02, o texto do código vem onde está no HTML) continua sendo
 * conferida como sempre.
 */

const R = require('./_pyre');
const { SequenceMatcher } = require('../lib/difflib');
const { sorted } = require('../lib/pyutil');
const correcao_ocr = require('./correcao_ocr');
const { limpar, tokenizar, tokenizar_pares } = require('./normalizacao');

// Quanto de uma linha precisa ser encontrado no docx para considerarmos que ela
// está lá. Abaixo disso é coincidência de palavra comum ("de", "no", "em").
const COBERTURA_MINIMA = 0.6;

class ResultadoOrdenacao {
  constructor(campos = {}) {
    Object.assign(this, { linhas: [], reordenou: false, motivo: '' }, campos);
  }
}

/**
 * Onde esta linha aparece no docx.
 *
 * Devolve o índice do trecho correspondente, ou null se a linha não estiver
 * lá. Usa o maior bloco em comum em vez de igualdade: leitura de imagem erra
 * caractere, e exigir texto idêntico faria a busca falhar justamente nas
 * imagens que mais precisam de ajuda.
 */
function _posicao_no_docx(tokens_linha, tokens_docx) {
  if (!tokens_linha.length || !tokens_docx.length) return null;

  const matcher = new SequenceMatcher(null, tokens_docx, tokens_linha, false);
  const bloco = matcher.find_longest_match(0, tokens_docx.length, 0, tokens_linha.length);
  if (bloco.size === 0) return null;
  if (bloco.size / tokens_linha.length < COBERTURA_MINIMA) return null;
  return bloco.a;
}

/**
 * Quebra a linha nos pedaços que existem no docx, cada um com sua posição.
 *
 * O motor agrupa por faixa horizontal, então dois cartões lado a lado viram
 * uma linha só: "03/09: 24/09:" e "Minha Melhor Amiga A Ilha Esquecida" são
 * quatro trechos de dois cartões diferentes. Exigir que a linha inteira
 * exista no docx faria o alinhamento desistir justamente nas peças de layout
 * mais complexo, que são as que mais precisam dele.
 *
 * Devolve null quando sobra algum pedaço sem correspondência — aí existe
 * divergência de conteúdo e nada deve ser reordenado.
 */
function _partir_linha(linha, paragrafos_docx, usadas = null) {
  // os pares mantêm o texto como está na peça ao lado da forma de comparação:
  // a busca usa a canônica, o resultado exibe a original
  const pares = tokenizar_pares(linha);
  if (!pares.length) return null;
  const tokens = pares.map((p) => correcao_ocr.canonizar(p.chave));
  const base = Array.from(limpar(linha)); // índices dos pares são em code points

  usadas = usadas !== null && usadas !== undefined ? usadas : new Set();
  const pedacos = [];
  let inicio = 0;
  while (inicio < tokens.length) {
    let melhor_tamanho = 0;
    let melhor_posicao = null;
    // procura o maior pedaço, a partir daqui, que exista no docx
    for (let fim = tokens.length; fim > inicio; fim--) {
      const posicao = _posicao_exata(tokens.slice(inicio, fim), paragrafos_docx, usadas);
      if (posicao !== null) {
        melhor_tamanho = fim - inicio;
        melhor_posicao = posicao;
        break;
      }
    }
    if (!melhor_tamanho) return null;
    // marca as posições consumidas por este pedaço
    for (let deslocamento = 0; deslocamento < melhor_tamanho; deslocamento++) {
      usadas.add(melhor_posicao + deslocamento);
    }
    // recorta direto do texto original em vez de juntar os tokens: assim a
    // barra de "03/09:" e os parênteses de "(pipoca...)" sobrevivem
    const primeiro = pares[inicio];
    const ultimo = pares[inicio + melhor_tamanho - 1];
    pedacos.push([melhor_posicao, R.pyStrip(base.slice(primeiro.inicio, ultimo.fim).join(''))]);
    inicio += melhor_tamanho;
  }
  return pedacos;
}

function _igual(a, i, sub) {
  for (let k = 0; k < sub.length; k++) if (a[i + k] !== sub[k]) return false;
  return true;
}

/**
 * Posição da sequência no docx, respeitando a fronteira dos parágrafos.
 *
 * Procurar num texto corrido deixava o trecho casar atravessando o fim de um
 * parágrafo e o começo do outro: "de desconto no" casava com o fim de "50% de
 * desconto" somado ao início de "no ingresso", e o alinhamento saía torto.
 * Cada parágrafo é uma unidade — o redator quebrou ali de propósito.
 *
 * A posição devolvida é global (parágrafo e deslocamento juntos), só para
 * ordenar.
 */
function _posicao_exata(sub, paragrafos, usadas = null) {
  if (!sub.length) return null;
  usadas = usadas && usadas.size ? usadas : new Set();
  for (let indice = 0; indice < paragrafos.length; indice++) {
    const tokens = paragrafos[indice];
    if (sub.length > tokens.length) continue;
    const primeiro = sub[0];
    for (let i = 0; i < tokens.length - sub.length + 1; i++) {
      if (tokens[i] !== primeiro || !_igual(tokens, i, sub)) continue;
      const posicao = indice * 10000 + i;
      // Cada pedaço do docx vale uma vez só. "de desconto" aparece em
      // "50% de desconto" e de novo em "20% de desconto": sem marcar o
      // que já foi usado, as duas leituras casam com a primeira
      // ocorrência e os dois acabam empilhados no mesmo cartão, deixando
      // o segundo número sem o seu rótulo.
      if (usadas.has(posicao)) continue;
      return posicao;
    }
  }
  return null;
}

/** Reordena o que foi lido da imagem na ordem em que o docx escreveu. */
function alinhar_por_referencia(texto_da_imagem, paragrafos_docx) {
  const linhas = R.pySplitlines(texto_da_imagem || '').filter((l) => R.pyStrip(l));
  if (linhas.length < 2) return new ResultadoOrdenacao({ linhas });

  const por_paragrafo = [];
  for (const paragrafo of paragrafos_docx) {
    const tokens = tokenizar(paragrafo).map((t) => correcao_ocr.canonizar(t));
    if (tokens.length) por_paragrafo.push(tokens);
  }
  if (!por_paragrafo.length) return new ResultadoOrdenacao({ linhas });

  const trechos = [];
  const usadas = new Set();
  for (let indice = 0; indice < linhas.length; indice++) {
    const linha = linhas[indice];
    const pedacos = _partir_linha(linha, por_paragrafo, usadas);
    if (pedacos === null) {
      // trecho fora do docx significa divergência de conteúdo:
      // reordenar aqui esconderia justamente o que precisa aparecer
      return new ResultadoOrdenacao({
        linhas,
        motivo: `trecho não encontrado no docx: ${Array.from(linha).slice(0, 60).join('')}`,
      });
    }
    pedacos.forEach(([posicao, texto], ordem_interna) => {
      trechos.push([posicao, indice, ordem_interna, texto]);
    });
  }

  const ordenados = sorted(trechos, (x) => [x[0], x[1], x[2]]).map((t) => t[3]);
  if (ordenados.length === linhas.length && ordenados.every((t, i) => t === linhas[i])) {
    return new ResultadoOrdenacao({ linhas });
  }

  return new ResultadoOrdenacao({
    linhas: ordenados,
    reordenou: true,
    motivo: 'ordem ajustada pela sequência do CONTEUDO.docx',
  });
}

module.exports = {
  COBERTURA_MINIMA, ResultadoOrdenacao, _posicao_no_docx, _partir_linha, _posicao_exata,
  alinhar_por_referencia,
};
