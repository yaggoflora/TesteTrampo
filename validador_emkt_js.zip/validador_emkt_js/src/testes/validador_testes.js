'use strict';
/**
 * Testes automáticos do Validador (região 4 do script único em Python).
 *
 * O equivalente, para o Validador, dos testes do Workbench (/workbench/tests/): cada caso monta um
 * pacote pequeno numa pasta temporária, roda a conferência de verdade (pacote.validar) e compara o
 * resultado com o esperado.
 *
 * Dois nomes dão o esperado:
 *   PACOTE_APROVADO   nada impede a publicação e não há apontamento
 *   PACOTE_ERROS      o pacote reprova, e os apontamentos são os que ele traz de propósito
 * O pacote de referência de cada um está nos dois primeiros casos. Os demais partem do
 * PACOTE_APROVADO e estragam UMA coisa, para mostrar que cada regra pega o seu defeito e não mexe
 * no resto.
 *
 * A leitura das imagens usa um motor de teste, que devolve o texto combinado para cada arquivo.
 * Assim o resultado não depende de haver Tesseract ou RapidOCR instalado, nem de como cada um lê.
 * Quem exercita o motor de verdade são os pacotes reais da pasta "pacotes_de_teste" (se existir).
 *
 * Rodar:  node servidor.js --testar
 *         ou a página http://127.0.0.1:5000/validador/tests/
 * A rodada acontece num processo à parte: o motor de teste não pode trocar o motor de uma
 * conferência que esteja em andamento na tela.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { isDeepStrictEqual } = require('util');

const cfg = require('../config');
const U = require('../lib/pyutil');
const { escreverDocx } = require('../lib/docxwriter');
const { codificarPng, crc32 } = require('../lib/pngwriter');
const { pyUnescape } = require('../lib/pyhtml');

const PACOTE_APROVADO = 'aprovado';
const PACOTE_ERROS = 'reprovado';

// Pacotes reais para conferir com o motor de leitura de verdade. Cada subpasta
// (PACOTE_APROVADO, PACOTE_ERROS) é um pacote como o que o marketing envia.
const PASTA_PACOTES_REAIS = cfg.PASTA_PACOTES_REAIS;

const _MARCA_DO_RESULTADO = '@@RESULTADO-DOS-TESTES@@';

// carregamento tardio: os módulos só entram quando a rodada começa
const ocr = () => require('../validador/ocr');
const pacote = () => require('../validador/pacote');
const serializacao = () => require('../validador/serializacao');

function tempdir(prefixo) { return fs.mkdtempSync(path.join(os.tmpdir(), prefixo)); }
function apagar(pasta) { try { fs.rmSync(pasta, { recursive: true, force: true }); } catch (e) { /* segue */ } }
async function comPasta(prefixo, fn) {
  const pasta = tempdir(prefixo);
  try { return await fn(pasta); } finally { apagar(pasta); }
}

/** repr() aproximado do Python, só para mensagens de falha. */
function repr(v) {
  if (v === null || v === undefined) return 'None';
  if (typeof v === 'string') return v;
  if (v instanceof Map) return JSON.stringify(Object.fromEntries(v));
  try { return JSON.stringify(v); } catch (e) { return String(v); }
}

// ------------------------------------------------------- montagem dos pacotes

/** Cria uma imagem. A cor sai do nome: duas imagens iguais teriam a mesma leitura em cache. */
function _escrever_imagem(caminho, ordem, opcoes) {
  const [largura, altura] = opcoes.tamanho || [600, 200];
  let png;
  if (opcoes.ruido) {
    // ruído não comprime: é o jeito de fazer um arquivo pesado sem esperar
    png = codificarPng(largura, altura, crypto.randomBytes(largura * altura * 3));
  } else {
    const semente = crc32(Buffer.from(`${path.basename(caminho)}${ordem}`, 'utf8'));
    png = codificarPng(largura, altura, { cor: [(semente >>> 16) & 255, (semente >>> 8) & 255, semente & 255] });
  }
  fs.writeFileSync(caminho, png);
}

/** links: texto do parágrafo -> endereço. O parágrafo inteiro vira hyperlink. */
function _escrever_docx(caminho, paragrafos, links = null) {
  escreverDocx(caminho, paragrafos, links);
}

/**
 * Descreve um pacote sintético: o que vai no HTML, no docx e na pasta de imagens.
 *
 * Nasce como o PACOTE_APROVADO. Cada caso muda o que precisa mudar e o escrever() grava tudo.
 * O CONTEUDO.docx sai do próprio HTML (o texto vivo e o que o motor de teste lê em cada imagem),
 * então os dois lados batem por construção, e só diverge o que o caso fizer divergir.
 */
class _PacoteDeTeste {
  constructor() {
    // ["img", nome chamado no HTML] | ["txt", texto] | ["cru", html solto]
    this.blocos = [
      ['img', 'briefing_01.png'],
      ['txt', 'Olá, aproveite esta oferta exclusiva.'],
      ['img', 'briefing_02.png'],
      ['img', 'briefing_03.png'],
      ['txt', 'Para não receber mais este e-mail, clique em descadastrar.'],
      ['txt', 'Esta mensagem foi gerada automaticamente e não pode ser respondida.'],
    ];
    // o que o motor de teste lê em cada arquivo; a chave é o nome em minúsculas
    this.leituras = {
      'briefing_01.png': ['Seu crédito está liberado', 'Condições especiais para você'],
      'briefing_02.png': ['Simule agora mesmo'],
      'briefing_03.png': ['Contrate pelo aplicativo'],
    };
    // arquivos da pasta de imagens: nome -> opções ("tamanho", "ruido")
    this.imagens = new Map([['briefing_01.png', {}], ['briefing_02.png', {}], ['briefing_03.png', {}]]);
    this.redirect = true;
    this.assunto = 'Crédito liberado para você';
    // palavras que não aparecem no resto da peça: a checagem do pré-header compara palavras soltas
    this.pre_header = 'Taxas reduzidas só hoje.';
    this.pre_header_no_html = true;
    this.conteudo = null; // null: sai do HTML
    this.links_no_conteudo = {};
    this.com_html = true;
    this.com_conteudo = true;
    this.com_assunto = true;
    this.html_em_subpasta = false;
  }

  // --- alterações usadas pelos casos -------------------------------------
  /** Renomeia o arquivo na pasta (e a chamada no HTML, se no_html). */
  renomear(antigo, novo, no_html = true) {
    this.imagens = new Map([...this.imagens].map(([n, o]) => [n === antigo ? novo : n, o]));
    if (antigo.toLowerCase() in this.leituras) {
      this.leituras[novo.toLowerCase()] = this.leituras[antigo.toLowerCase()];
      delete this.leituras[antigo.toLowerCase()];
    }
    if (no_html) {
      this.blocos = this.blocos.map((b) => (b[0] === 'img' && b[1] === antigo ? ['img', novo] : b));
    }
  }

  remover_da_pasta(nome) { this.imagens.delete(nome); }

  adicionar_na_pasta(nome, opcoes = {}) { this.imagens.set(nome, opcoes); }

  /** Troca o texto no HTML; o docx acompanha, porque sai do HTML. */
  trocar_texto(antigo, novo) {
    this.blocos = this.blocos.map(([t, v]) => (t !== 'img' ? [t, v.split(antigo).join(novo)] : [t, v]));
  }

  /** Acrescenta um parágrafo só no docx (o que o HTML não tem). */
  conteudo_extra(paragrafo) { this.conteudo = [...this.paragrafos_do_conteudo(), paragrafo]; }

  trocar_so_no_docx(antigo, novo) {
    this.conteudo = this.paragrafos_do_conteudo().map((p) => p.split(antigo).join(novo));
  }

  // --- saída --------------------------------------------------------------
  paragrafos_do_conteudo() {
    if (this.conteudo !== null) return [...this.conteudo];
    const paragrafos = [];
    for (const [tipo, valor] of this.blocos) {
      if (tipo === 'img') paragrafos.push(...(this.leituras[valor.toLowerCase()] || []));
      else if (tipo === 'txt') paragrafos.push(pyUnescape(valor).split('﻿').join(''));
    }
    return paragrafos;
  }

  html() {
    const prefixo = this.html_em_subpasta ? '../imagens/' : 'imagens/';
    const linhas = ['<!DOCTYPE html>',
      '<html lang="pt-BR"><head><meta charset="utf-8"><title>Peça de teste</title></head><body>'];
    if (this.pre_header && this.pre_header_no_html) {
      linhas.push('<div style="display:none;max-height:0;overflow:hidden">' + `${this.pre_header}</div>`);
    }
    linhas.push('<table role="presentation" width="600">');
    this.blocos.forEach(([tipo, valor], posicao) => {
      if (tipo === 'img') {
        const destino = this.redirect ? `%%=RedirectTo(@link${posicao})=%%` : 'https://www.exemplo.com.br/oferta';
        linhas.push(`<tr><td><a href="${destino}"><img src="${prefixo}${valor}" `
          + 'alt="" width="600" style="display:block"></a></td></tr>');
      } else if (tipo === 'txt') {
        linhas.push(`<tr><td>${valor}</td></tr>`);
      } else {
        linhas.push(valor);
      }
    });
    linhas.push('</table></body></html>');
    return linhas.join('\n');
  }

  escrever(pasta) {
    const pasta_html = this.html_em_subpasta ? path.join(pasta, 'html') : pasta;
    const pasta_imagens = path.join(pasta, 'imagens');
    fs.mkdirSync(pasta_html, { recursive: true });
    fs.mkdirSync(pasta_imagens, { recursive: true });
    let ordem = 0;
    for (const [nome, opcoes] of this.imagens) {
      _escrever_imagem(path.join(pasta_imagens, nome), ordem, opcoes);
      ordem += 1;
    }
    if (this.com_html) fs.writeFileSync(path.join(pasta_html, 'index.html'), this.html(), 'utf8');
    if (this.com_conteudo) {
      _escrever_docx(path.join(pasta, 'CONTEUDO.docx'), this.paragrafos_do_conteudo(), this.links_no_conteudo);
    }
    if (this.com_assunto) {
      const linhas = [`Assunto: ${this.assunto}`];
      if (this.pre_header) linhas.push(`Pré-header: ${this.pre_header}`);
      _escrever_docx(path.join(pasta, 'ASSUNTO.docx'), linhas);
    }
  }
}

// --------------------------------------------------------------- motor de teste

/** Motor de leitura que devolve o texto combinado para cada arquivo. */
function _criar_motor_de_teste(leituras) {
  const o = ocr();
  class MotorDeTeste extends o.MotorBase {
    get nome() { return 'motor-de-teste'; }

    get descricao() { return 'Motor de teste (texto combinado por arquivo)'; }

    constructor() { super(); this.chamadas = []; }

    disponivel() { return [true, 'ok']; }

    async ler(caminho, idioma, confianca_minima) {
      const nome = path.basename(caminho);
      this.chamadas.push(nome);
      const linhas = [...(leituras[nome.toLowerCase()] || [])];
      return new o.ResultadoOCR({
        arquivo: nome, texto: o.limpar(linhas.join('\n')), lido: true,
        linhas, motor: this.nome, confianca_media: 99.0,
      });
    }
  }
  return new MotorDeTeste();
}

/** Põe o motor de teste no lugar e manda o cache para uma pasta descartável. */
async function _ocr_de_teste(motor, fn) {
  const o = ocr();
  const guardados = [o._ESCOLHIDO, o.PASTA_CACHE];
  const pasta_cache = tempdir('teste_cache_');
  o._ESCOLHIDO = motor;
  o.PASTA_CACHE = pasta_cache;
  try {
    return await fn(pasta_cache);
  } finally {
    [o._ESCOLHIDO, o.PASTA_CACHE] = guardados;
    apagar(pasta_cache);
  }
}

// ------------------------------------------------------------------ comparação

/** Dicionário/Counter do Python -> objeto simples (para comparar por valor). */
function _plano(v) {
  if (v instanceof Map) return Object.fromEntries([...v.entries()].map(([k, x]) => [k, _plano(x)]));
  if (Array.isArray(v)) return v.map(_plano);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, _plano(x)]));
  return v;
}

/** Lista de apontamentos como lista de nomes: ['a.png', 'motivo'] vira 'a.png'. */
function _nomes(valor) {
  if ((valor && typeof valor === 'object' && !Array.isArray(valor)) || typeof valor === 'boolean') return _plano(valor);
  return U.sorted((valor || []).map((v) => (Array.isArray(v) ? v[0] : v)));
}

/** O que o Validador devolveu, em poucas linhas, para quem for investigar uma falha. */
function _resumo(resultado) {
  const linhas = [`status: ${resultado.status} (texto em modo ${resultado.modo_texto})`];
  for (const campo of ['erros', 'bloqueios', 'alertas', 'avisos']) {
    for (const item of resultado[campo]) {
      linhas.push(`${campo !== 'avisos' ? campo.slice(0, -1) : 'aviso'}: ${item}`);
    }
  }
  const ri = resultado.resultado_imagens;
  if (ri) {
    for (const campo of ['fora_da_taxonomia', 'numeros_faltando', 'numeros_duplicados',
      'nao_comeca_em_um', 'extensao_invalida', 'acima_do_peso',
      'na_pasta_fora_do_html', 'no_html_fora_da_pasta',
      'divergencia_de_caixa', 'material_de_apoio', 'repeticoes_no_html']) {
      const valor = ri[campo];
      const vazio = !valor || (Array.isArray(valor) && !valor.length)
        || (typeof valor === 'object' && !Array.isArray(valor) && !Object.keys(_plano(valor)).length);
      if (!vazio) linhas.push(`imagens.${campo}: ${repr(valor)}`);
    }
  }
  if (resultado.resultado_texto) {
    const divergencias = resultado.resultado_texto.divergencias || [];
    linhas.push(`texto: ${resultado.resultado_texto.status}, ${divergencias.length} divergência(s)`);
    for (const d of divergencias.slice(0, 4)) {
      linhas.push(`  - ${d.tipo}: html «${d.trecho_html.slice(0, 60)}» × docx «${d.trecho_docx.slice(0, 60)}»`);
    }
  }
  if (resultado.apontamentos_assunto.length) {
    linhas.push(`assunto/pré-header: ${resultado.apontamentos_assunto.length} apontamento(s)`);
  }
  return linhas.join('\n');
}

/** Compara o resultado com o esperado. Devolve [[o que, esperado, obtido]]. */
function _comparar(resultado, espera) {
  const falhas = [];
  const falha = (o_que, esperado, obtido) => falhas.push([o_que, repr(esperado), repr(obtido)]);

  if ('status' in espera && resultado.status !== espera.status) falha('Status', espera.status, resultado.status);

  for (const campo of ['erros', 'bloqueios', 'alertas', 'avisos']) {
    const mensagens = resultado[campo].map((m) => String(m).toLowerCase());
    for (const trecho of (espera[campo] || [])) {
      if (!mensagens.some((m) => m.includes(trecho.toLowerCase()))) {
        falha(`${campo}: deveria conter`, trecho, resultado[campo].length ? resultado[campo] : '(vazio)');
      }
    }
    for (const trecho of (espera['sem_' + campo] || [])) {
      if (mensagens.some((m) => m.includes(trecho.toLowerCase()))) {
        falha(`${campo}: não deveria conter`, '(ausente)', trecho);
      }
    }
  }
  for (const campo of (espera.vazio || [])) {
    if (resultado[campo].length) falha(`${campo} deveria estar vazio`, '[]', resultado[campo]);
  }

  const ri = resultado.resultado_imagens;
  if ('imagens_ok' in espera) {
    const obtido = Boolean(ri && ri.aprovado);
    if (obtido !== espera.imagens_ok) falha('Conferência de imagens aprovada', espera.imagens_ok, obtido);
  }
  for (const [campo, esperado] of Object.entries(espera.imagens || {})) {
    const obtido = ri ? _nomes(ri[campo]) : '(sem leitura de imagens)';
    if (!isDeepStrictEqual(obtido, _nomes(esperado))) falha(`imagens.${campo}`, esperado, obtido);
  }

  const rt = resultado.resultado_texto;
  if ('texto_status' in espera && (rt ? rt.status : null) !== espera.texto_status) {
    falha('Status do texto', espera.texto_status, rt ? rt.status : '(sem leitura)');
  }
  if ('divergencias_min' in espera) {
    const quantas = rt ? (rt.divergencias || []).length : 0;
    if (quantas < espera.divergencias_min) falha('Divergências de texto (mínimo)', espera.divergencias_min, quantas);
  }
  if ('modo_texto' in espera && resultado.modo_texto !== espera.modo_texto) {
    falha('Modo da comparação de texto', espera.modo_texto, resultado.modo_texto);
  }
  if ('apontamentos_assunto_min' in espera) {
    if (resultado.apontamentos_assunto.length < espera.apontamentos_assunto_min) {
      falha('Apontamentos de assunto/pré-header (mínimo)', espera.apontamentos_assunto_min,
        resultado.apontamentos_assunto.length);
    }
  }
  return falhas;
}

// ----------------------------------------------------------------------- casos

/** O caso não se aplica nesta máquina (por exemplo, falta motor de leitura). */
class _Pulado extends Error {}

class _Caso {
  constructor(grupo, nome, { alterar = null, espera = null, executar = null, sem_ocr = false, pasta_real = '' } = {}) {
    this.grupo = grupo; this.nome = nome;
    this.alterar = alterar; this.espera = espera || {};
    this.executar = executar; // função() -> falhas, para o que não é um pacote
    this.sem_ocr = sem_ocr;
    this.pasta_real = pasta_real;
  }
}

function _hoje_mais(dias) {
  const d = new Date();
  d.setDate(d.getDate() + dias);
  const dois = (n) => String(n).padStart(2, '0');
  return `${dois(d.getDate())}/${dois(d.getMonth() + 1)}/${d.getFullYear()}`;
}

/** Vários defeitos de uma vez, como chega pacote ruim de verdade. */
function _alterar_pacote_erros(p) {
  p.redirect = false; // publicação exige redirect
  p.pre_header = 'Taxas reduzidas só hoje'; // sem ponto final
  p.renomear('briefing_02.png', 'briefing_04.png'); // furo na numeração (falta o 02)
  p.adicionar_na_pasta('briefing_05.png'); // imagem que o HTML não chama
  p.trocar_so_no_docx('exclusiva', 'especial'); // texto do docx diferente do HTML
  p.links_no_conteudo = { 'Olá, aproveite esta oferta especial.': 'https://www.exemplo.com.br' };
}

function _casos_de_pacote() {
  const c = [];

  function caso(grupo, nome, alterar = null, espera = {}) {
    const sem_ocr = Boolean(espera.sem_ocr);
    const { sem_ocr: _descartado, ...resto } = espera;
    c.push(new _Caso(grupo, nome, { alterar, espera: resto, sem_ocr }));
  }

  let G = 'Pacotes de referência';
  caso(G, 'PACOTE_APROVADO: nada impede a publicação e não há apontamento', null, {
    status: PACOTE_APROVADO, vazio: ['erros', 'bloqueios', 'alertas', 'avisos'],
    imagens_ok: true, texto_status: 'aprovado', modo_texto: 'sequencia',
  });
  caso(G, 'PACOTE_ERROS: reprova, com os apontamentos que ele traz de propósito', _alterar_pacote_erros, {
    status: PACOTE_ERROS,
    bloqueios: ['Nenhum redirect', 'pré-header não termina em ponto final', 'hyperlink no CONTEUDO.docx'],
    imagens_ok: false,
    imagens: { numeros_faltando: [2], na_pasta_fora_do_html: ['briefing_05.png'] },
    divergencias_min: 1,
  });

  G = 'Imagens: taxonomia e sequência';
  caso(G, 'Furo na numeração (01, 03, 04) reprova',
    (p) => p.renomear('briefing_02.png', 'briefing_04.png'),
    { status: PACOTE_ERROS, imagens: { numeros_faltando: [2] } });
  caso(G, 'Numeração que não começa em 01 reprova',
    (p) => p.renomear('briefing_01.png', 'briefing_04.png'),
    { status: PACOTE_ERROS, imagens: { nao_comeca_em_um: true, numeros_faltando: [1] } });
  caso(G, 'Número repetido na pasta reprova',
    (p) => p.adicionar_na_pasta('briefing_02.jpg'),
    { status: PACOTE_ERROS, imagens: { numeros_duplicados: [2] } });
  caso(G, 'Prefixo diferente da quebra reprova',
    (p) => p.renomear('briefing_03.png', 'promo_03.png'),
    { status: PACOTE_ERROS, imagens: { fora_da_taxonomia: ['promo_03.png'] } });
  caso(G, 'Imagem chamada no HTML sem número no nome reprova',
    (p) => p.renomear('briefing_03.png', 'banner.png'),
    { status: PACOTE_ERROS, imagens: { fora_da_taxonomia: ['banner.png'] } });
  caso(G, 'Extensão fora do padrão (.bmp) reprova',
    (p) => p.renomear('briefing_03.png', 'briefing_03.bmp'),
    { status: PACOTE_ERROS, imagens: { extensao_invalida: ['briefing_03.bmp (extensão .bmp)'] } });
  caso(G, 'Imagem acima de 1 MB reprova',
    (p) => p.imagens.set('briefing_02.png', { ruido: true, tamanho: [700, 700] }),
    { status: PACOTE_ERROS, imagens: { acima_do_peso: ['briefing_02.png'] } });

  G = 'Imagens: pasta x HTML';
  caso(G, 'Imagem na pasta que o HTML não chama reprova',
    (p) => p.adicionar_na_pasta('briefing_04.png'),
    { status: PACOTE_ERROS, imagens: { na_pasta_fora_do_html: ['briefing_04.png'] } });
  caso(G, 'Imagem que o HTML chama e não está na pasta reprova',
    (p) => p.remover_da_pasta('briefing_03.png'),
    { status: PACOTE_ERROS, imagens: { no_html_fora_da_pasta: ['briefing_03.png'] } });
  caso(G, 'Maiúscula e minúscula diferentes entre a pasta e o HTML reprovam',
    (p) => p.renomear('briefing_01.png', 'Briefing_01.png', false),
    { status: PACOTE_ERROS, imagens: { divergencia_de_caixa: ['Briefing_01.png'] } });
  caso(G, 'Arte de conferência (preview_final) é material de apoio e não reprova',
    (p) => p.adicionar_na_pasta('preview_final.png', { tamanho: [600, 2000] }),
    {
      status: PACOTE_APROVADO, imagens_ok: true,
      imagens: { material_de_apoio: ['preview_final.png'], na_pasta_fora_do_html: [] },
    });
  caso(G, 'A mesma imagem repetida no HTML é permitida',
    (p) => p.blocos.splice(4, 0, ['img', 'briefing_01.png']),
    { status: PACOTE_APROVADO, imagens_ok: true, imagens: { repeticoes_no_html: { 'briefing_01.png': 2 } } });

  G = 'Regras de publicação';
  caso(G, 'HTML sem redirect reprova',
    (p) => { p.redirect = false; },
    { status: PACOTE_ERROS, bloqueios: ['Nenhum redirect'] });
  caso(G, 'Pré-header sem ponto final reprova',
    (p) => { p.pre_header = 'Taxas reduzidas só hoje'; },
    { status: PACOTE_ERROS, bloqueios: ['pré-header não termina em ponto final'] });
  caso(G, 'Pré-header terminado em ! vale como ponto final',
    (p) => { p.pre_header = 'Taxas reduzidas só hoje!'; },
    { status: PACOTE_APROVADO, sem_bloqueios: ['pré-header'] });
  caso(G, 'Assunto acima de 35 caracteres é alerta e não reprova',
    (p) => { p.assunto = 'Seu crédito pré-aprovado já está liberado para contratação'; },
    { status: PACOTE_APROVADO, alertas: ['Assunto com'], vazio: ['bloqueios'] });
  caso(G, 'Pré-header acima de 40 caracteres é alerta e não reprova',
    (p) => { p.pre_header = 'Simule agora o seu crédito e contrate em poucos minutos.'; },
    { status: PACOTE_APROVADO, alertas: ['Pré-header com'], vazio: ['bloqueios'] });
  caso(G, 'Hyperlink no CONTEUDO.docx reprova',
    (p) => { p.links_no_conteudo = { 'Olá, aproveite esta oferta exclusiva.': 'https://www.exemplo.com.br' }; },
    { status: PACOTE_ERROS, bloqueios: ['hyperlink no CONTEUDO.docx'] });
  caso(G, 'Endereço no disclaimer sem a proteção anti-link reprova',
    (p) => p.trocar_texto('não pode ser respondida.',
      'não pode ser respondida. Veja www.bradesco.com.br/ajuda.'),
    { status: PACOTE_ERROS, bloqueios: ['Endereço sem o código que impede o hyperlink'] });
  caso(G, 'Endereço no disclaimer com &#xFEFF; está protegido',
    (p) => p.trocar_texto('não pode ser respondida.',
      'não pode ser respondida. Veja www.bradesco&#xFEFF;.com.br/ajuda.'),
    { status: PACOTE_APROVADO, vazio: ['bloqueios'] });
  caso(G, 'Data vencida no disclaimer vira alerta e não reprova',
    (p) => p.blocos.push(['txt', `Oferta válida até ${_hoje_mais(-30)}.`]),
    { status: PACOTE_APROVADO, alertas: ['Data vencida'], vazio: ['bloqueios'] });
  caso(G, 'Data futura no disclaimer não gera alerta',
    (p) => p.blocos.push(['txt', `Oferta válida até ${_hoje_mais(30)}.`]),
    { status: PACOTE_APROVADO, vazio: ['alertas', 'bloqueios'] });

  G = 'Texto: HTML e imagens x CONTEUDO.docx';
  caso(G, 'Palavra trocada no docx é divergência',
    (p) => p.trocar_so_no_docx('exclusiva', 'especial'),
    { status: PACOTE_ERROS, divergencias_min: 1 });
  caso(G, 'Número trocado no texto da imagem (48x no banner, 60x no docx) reprova',
    (p) => {
      p.leituras['briefing_02.png'] = ['Parcelas em até 48x'];
      p.trocar_so_no_docx('Parcelas em até 48x', 'Parcelas em até 60x');
    },
    { status: PACOTE_ERROS, divergencias_min: 1 });
  caso(G, 'Aspas curvas do Word contra aspas retas do HTML não divergem',
    (p) => {
      p.trocar_texto('aproveite esta', '"aproveite" esta');
      p.trocar_so_no_docx('"aproveite"', '“aproveite”');
    },
    { status: PACOTE_APROVADO, texto_status: 'aprovado', vazio: ['bloqueios', 'alertas'] });

  G = 'Acento e pontuação: só reprova se for grotesco';
  caso(G, 'Dois pontos no HTML e não no docx (Cartões Digitais:) é só aviso e aprova',
    (p) => {
      p.blocos.push(['txt', 'Cartões Digitais:']);
      p.trocar_so_no_docx('Cartões Digitais:', 'Cartões Digitais');
    },
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });
  caso(G, 'Uma vírgula a menos no docx é só aviso e aprova',
    (p) => p.trocar_so_no_docx('Olá,', 'Olá'),
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });
  caso(G, 'Um acento a menos no docx é só aviso e aprova',
    (p) => p.trocar_so_no_docx('Olá', 'Ola'),
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });
  caso(G, 'Texto todo sem acento no docx (grotesco) reprova',
    (p) => {
      p.blocos.push(['txt', 'Você já tem crédito pré-aprovado, não perca a ação.']);
      p.trocar_so_no_docx('Você já tem crédito pré-aprovado, não perca a ação.',
        'Voce ja tem credito pre-aprovado, nao perca a acao.');
    },
    { status: PACOTE_ERROS, texto_status: 'reprovado', divergencias_min: 1 });
  caso(G, 'Letra errada no texto do código (0ferta x oferta) reprova',
    (p) => p.trocar_so_no_docx('oferta', '0ferta'),
    { status: PACOTE_ERROS, texto_status: 'reprovado', divergencias_min: 1 });

  G = 'Repetição e texto de imagem: avisa, só reprova se não houver nada no docx';
  caso(G, 'Livelo repetido no HTML e uma vez só no docx é só aviso e aprova',
    (p) => {
      p.blocos.push(['txt', 'Livelo Livelo pontos em dobro']);
      p.trocar_so_no_docx('Livelo Livelo pontos em dobro', 'Livelo pontos em dobro');
    },
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });
  caso(G, 'Imagem com o texto só em parte no docx é só aviso e aprova',
    (p) => p.trocar_so_no_docx('Condições especiais para você', 'Condições especiais'),
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });
  caso(G, 'Imagem com nada do que está escrito no docx reprova',
    (p) => p.trocar_so_no_docx('Simule agora mesmo', 'Texto totalmente diferente'),
    { status: PACOTE_ERROS, texto_status: 'reprovado', divergencias_min: 1 });
  caso(G, "Palavra repetida com 'não' no meio continua reprovando",
    (p) => {
      p.blocos.push(['txt', 'Você não não pode perder']);
      p.trocar_so_no_docx('Você não não pode perder', 'Você não pode perder');
    },
    { status: PACOTE_ERROS, texto_status: 'reprovado', divergencias_min: 1 });
  caso(G, 'Bloco de redes sociais só no docx não reprova',
    (p) => p.conteudo_extra('Acompanhe o Bradesco nas Redes Sociais!'),
    { status: PACOTE_APROVADO, texto_status: 'aprovado', divergencias_min: 1, vazio: ['erros', 'bloqueios'] });

  G = 'Assunto e pré-header';
  caso(G, 'Pré-header que não está no HTML vira atenção',
    (p) => { p.pre_header_no_html = false; },
    { status: 'atencao', apontamentos_assunto_min: 1, vazio: ['bloqueios'] });
  caso(G, 'Sem o docx de assunto: avisa, e o resto da conferência segue',
    (p) => { p.com_assunto = false; p.pre_header_no_html = false; },
    { avisos: ['Não identifiquei um docx de assunto'], vazio: ['erros', 'bloqueios'] });

  G = 'Estrutura do pacote';
  caso(G, 'Pacote sem docx dá erro e explica',
    (p) => { p.com_conteudo = false; p.com_assunto = false; },
    { status: 'erro', erros: ['Nenhum arquivo .docx'] });
  caso(G, 'Pacote sem HTML dá erro',
    (p) => { p.com_html = false; },
    { status: 'erro', erros: ['nenhum arquivo .html'] });
  caso(G, 'HTML numa subpasta html/, com as imagens ao lado, é achado e aprovado',
    (p) => { p.html_em_subpasta = true; },
    { status: PACOTE_APROVADO, vazio: ['erros', 'bloqueios', 'alertas'], imagens_ok: true });
  caso(G, 'Sem leitura de imagem a conferência nunca aprova (fica em atenção)',
    null, { sem_ocr: true, status: 'atencao', modo_texto: 'presenca', vazio: ['bloqueios'] });
  return c;
}

// ------------------------------------- casos que não são um pacote (recursos novos)

async function _caso_lote() {
  const P = pacote();
  const leituras = new _PacoteDeTeste().leituras;
  let pastas; let status;
  await comPasta('teste_lote_', async (raiz) => {
    for (const nome of ['campanha_a', 'campanha_b']) new _PacoteDeTeste().escrever(path.join(raiz, nome));
    pastas = P.localizar_pacotes(raiz);
    await _ocr_de_teste(_criar_motor_de_teste(leituras), async () => {
      status = (await P.validar_lote(raiz)).map((r) => r.status);
    });
  });
  const falhas = [];
  const nomes = pastas.map((p) => path.basename(p));
  if (!isDeepStrictEqual(nomes, ['campanha_a', 'campanha_b'])) {
    falhas.push(['Pacotes encontrados', 'campanha_a, campanha_b', nomes]);
  }
  if (!isDeepStrictEqual(status, [PACOTE_APROVADO, PACOTE_APROVADO])) {
    falhas.push(['Status de cada pacote do lote', [PACOTE_APROVADO, PACOTE_APROVADO], status]);
  }
  return falhas;
}

/** Conferir o mesmo pacote de novo não relê as imagens: a leitura vem do cache em disco. */
async function _caso_cache_le_uma_vez() {
  const P = pacote();
  const spec = new _PacoteDeTeste();
  const motor = _criar_motor_de_teste(spec.leituras);
  let primeira; let segunda;
  await comPasta('teste_cache_', async (pasta) => {
    spec.escrever(pasta);
    await _ocr_de_teste(motor, async () => {
      await P.validar(pasta);
      primeira = motor.chamadas.length;
      await P.validar(pasta);
      segunda = motor.chamadas.length - primeira;
    });
  });
  const falhas = [];
  if (primeira !== 3) falhas.push(['Imagens lidas na primeira conferência', 3, primeira]);
  if (segunda !== 0) falhas.push(['Imagens lidas de novo na segunda conferência', 0, segunda]);
  return falhas;
}

/** A impressão do cache vem do conteúdo do arquivo e do motor, não do nome nem da pasta. */
async function _caso_cache_pelo_conteudo() {
  const o = ocr();
  let igual_com_outro_nome; let muda_com_o_motor; let muda_com_a_imagem;
  await comPasta('teste_impressao_', async (pasta) => {
    const [a, b, c] = ['a.png', 'copia.png', 'outra.png'].map((n) => path.join(pasta, n));
    _escrever_imagem(a, 1, {});
    fs.copyFileSync(a, b);
    _escrever_imagem(c, 2, {});
    igual_com_outro_nome = o._impressao_do_arquivo(a, 'm') === o._impressao_do_arquivo(b, 'm');
    muda_com_o_motor = o._impressao_do_arquivo(a, 'm') !== o._impressao_do_arquivo(a, 'n');
    muda_com_a_imagem = o._impressao_do_arquivo(a, 'm') !== o._impressao_do_arquivo(c, 'm');
  });
  const falhas = [];
  if (!igual_com_outro_nome) falhas.push(['Mesmo conteúdo com outro nome', 'mesma impressão', 'impressão diferente']);
  if (!muda_com_o_motor) falhas.push(['Outro motor', 'impressão diferente', 'mesma impressão']);
  if (!muda_com_a_imagem) falhas.push(['Outra imagem', 'impressão diferente', 'mesma impressão']);
  return falhas;
}

/** A chave do cache só muda quando muda o código que decide a leitura. */
async function _caso_versao_da_leitura() {
  const o = ocr();
  const original = o._FONTES_DO_SCRIPT;
  const textos = Object.fromEntries(o._fontes_da_leitura());
  const base = o._versao_da_leitura();

  function versao_com(modulo) {
    o._FONTES_DO_SCRIPT = { ...textos, [modulo]: (textos[modulo] || '') + '\n// mudou' };
    try { return o._versao_da_leitura(); } finally { o._FONTES_DO_SCRIPT = original; }
  }

  const falhas = [];
  for (const modulo of ['ocr', 'layout', 'normalizacao']) {
    if (versao_com(modulo) === base) falhas.push([`Mudar o módulo ${modulo}`, 'versão diferente', 'mesma versão']);
  }
  // o que roda depois da leitura não pode invalidar o cache
  for (const modulo of ['comparador', 'presenca', 'correcao_ocr', 'html_parser', 'regras',
    'pacote', 'relatorio', 'serializacao', 'imagens', 'docx_parser']) {
    if (versao_com(modulo) !== base) falhas.push([`Mudar o módulo ${modulo}`, 'mesma versão', 'versão diferente']);
  }
  if (o.VERSAO_DA_LEITURA !== base) falhas.push(['Versão calculada na carga do programa', base, o.VERSAO_DA_LEITURA]);
  return falhas;
}

async function _caso_limpeza_de_relatorios() {
  const falhas = [];
  await comPasta('teste_relatorios_', async (pasta) => {
    const criar = (nome, dias_de_idade) => {
      const caminho = path.join(pasta, nome);
      fs.writeFileSync(caminho, '<html></html>', 'utf8');
      const instante = Date.now() / 1000 - dias_de_idade * 86400;
      fs.utimesSync(caminho, instante, instante);
    };
    criar('a1b2c3d4e5f6.html', 40); // velho: sai
    criar('0123456789ab.html', 29); // recente: fica
    criar('ffffffffffff.html', 31); // velho: sai
    criar('notas-do-time.html', 400); // nome que não é de relatório: nunca é tocado
    criar('a1b2c3d4e5f6.html.bak', 400); // idem
    fs.mkdirSync(path.join(pasta, 'aaaaaaaaaaaa.html')); // pasta com nome de relatório: fica
    const velho = Date.now() / 1000 - 400 * 86400;
    fs.utimesSync(path.join(pasta, 'aaaaaaaaaaaa.html'), velho, velho);

    const [apagados, liberados] = cfg.limpar_relatorios_antigos(30, pasta);
    const restantes = fs.readdirSync(pasta).sort();
    const esperados = ['0123456789ab.html', 'notas-do-time.html', 'a1b2c3d4e5f6.html.bak', 'aaaaaaaaaaaa.html'].sort();
    if (apagados !== 2) falhas.push(['Relatórios apagados', 2, apagados]);
    if (liberados !== 2 * '<html></html>'.length) falhas.push(['Bytes liberados', 2 * '<html></html>'.length, liberados]);
    if (!isDeepStrictEqual(restantes, esperados)) falhas.push(['Arquivos que sobram', esperados, restantes]);

    if (!isDeepStrictEqual(cfg.limpar_relatorios_antigos(0, pasta), [0, 0])) {
      falhas.push(['Com 0 dias a limpeza fica desligada', [0, 0], 'apagou algo']);
    }
    if (!isDeepStrictEqual(cfg.limpar_relatorios_antigos(30, path.join(pasta, 'nao-existe')), [0, 0])) {
      falhas.push(['Pasta que não existe', [0, 0], 'erro ou apagou algo']);
    }
    criar('bbbbbbbbbbbb.html', 5);
    // sobram o de 29 dias e o de 5: com limite de 3 dias, saem os dois
    if (cfg.limpar_relatorios_antigos(3, pasta)[0] !== 2) falhas.push(['Limite configurável (3 dias)', 2, 'outro valor']);
  });
  return falhas;
}

/** O aviso de idioma aparece só com Tesseract sem português, e chega no pacote. */
async function _caso_idioma_aviso() {
  const o = ocr();
  const P = pacote();

  class TesseractSemPortugues extends o.MotorTesseract {
    constructor() { super(); this.idiomas_simulados = ['eng', 'osd']; }

    disponivel() { return [true, 'ok']; }

    idiomas() { return [...this.idiomas_simulados]; }

    async ler(caminho) {
      return new o.ResultadoOCR({ arquivo: path.basename(caminho), lido: true, motor: this.nome, confianca_media: 99.0 });
    }
  }

  const falhas = [];
  const motor = new TesseractSemPortugues();
  await _ocr_de_teste(motor, async () => {
    const aviso = o.aviso_de_idioma();
    if (!aviso.includes('--instalar-idioma-por')) {
      falhas.push(['Aviso com Tesseract sem português', 'traz o comando de instalação', aviso || '(vazio)']);
    }
    const spec = new _PacoteDeTeste();
    const resultado = await comPasta('teste_idioma_', async (pasta) => {
      spec.escrever(pasta);
      return P.validar(pasta);
    });
    if (!resultado.avisos.some((a) => a.includes('idioma português'))) {
      falhas.push(['Aviso no resultado do pacote', 'menciona o idioma português', resultado.avisos]);
    }
    motor.idiomas_simulados = ['eng', 'por'];
    if (o.aviso_de_idioma()) falhas.push(['Aviso com o português instalado', '(vazio)', o.aviso_de_idioma()]);
  });
  await _ocr_de_teste(_criar_motor_de_teste({}), async () => {
    if (o.aviso_de_idioma()) falhas.push(['Aviso com outro motor (RapidOCR, Windows)', '(vazio)', o.aviso_de_idioma()]);
  });
  return falhas;
}

/** O instalador baixa por e eng para a pasta, recusa download pequeno demais e não deixa arquivo pela metade. */
async function _caso_idioma_instalador() {
  const o = ocr();
  const falhas = [];
  const servido = tempdir('teste_servidor_');
  const destino_a = tempdir('teste_destino_');
  const destino_b = tempdir('teste_destino_');
  const destino_c = tempdir('teste_destino_');
  let servidor;
  try {
    for (const idioma of ['por', 'eng']) {
      fs.writeFileSync(path.join(servido, `${idioma}.traineddata`), crypto.randomBytes(250_000));
    }
    servidor = http.createServer((req, res) => {
      const alvo = path.join(servido, path.basename(decodeURIComponent(req.url.split('?')[0])));
      fs.readFile(alvo, (erro, dados) => {
        if (erro) { res.writeHead(404); return res.end(); }
        res.writeHead(200, { 'Content-Length': dados.length }); res.end(dados);
      });
    });
    await new Promise((r) => servidor.listen(0, '127.0.0.1', r));
    const url = `http://127.0.0.1:${servidor.address().port}`;

    let mensagens = [];
    if (!(await o.instalar_idioma_por((m) => mensagens.push(m), destino_a, url))) {
      falhas.push(['Instalação com o servidor no ar', 'True', mensagens.slice(-2)]);
    }
    const instalados = fs.readdirSync(destino_a).sort();
    if (!isDeepStrictEqual(instalados, ['eng.traineddata', 'por.traineddata'])) {
      falhas.push(['Arquivos instalados', 'eng e por', instalados]);
    }

    mensagens = [];
    if (await o.instalar_idioma_por((m) => mensagens.push(m), destino_b, url, 10_000_000)) {
      falhas.push(['Download pequeno demais', 'recusado', 'aceito']);
    }
    if (fs.readdirSync(destino_b).length) falhas.push(['Arquivo pela metade', 'nenhum', fs.readdirSync(destino_b)]);
    if (!mensagens.some((m) => m.includes('pequeno demais'))) {
      falhas.push(['Mensagem de download pequeno', 'explica o motivo', mensagens]);
    }
    await new Promise((r) => servidor.close(r));
    servidor = null;

    // rede fora do ar: falha com mensagem, sem exceção
    mensagens = [];
    if (await o.instalar_idioma_por((m) => mensagens.push(m), destino_c, 'http://127.0.0.1:1')) {
      falhas.push(['Rede fora do ar', 'False', 'True']);
    }
    if (!mensagens.some((m) => m.includes('TESSDATA_URL'))) {
      falhas.push(['Mensagem de rede fora do ar', 'cita o espelho TESSDATA_URL', mensagens]);
    }
  } finally {
    if (servidor) servidor.close();
    [servido, destino_a, destino_b, destino_c].forEach(apagar);
  }
  return falhas;
}

/** /api/preview/<id>/html entrega o HTML do pacote, qualquer que seja a codificação. */
async function _caso_ponte_com_o_workbench() {
  const app = require('../app');
  const falhas = [];
  const pasta = tempdir('teste_ponte_');
  const ids = [];
  let servidor;
  try {
    const utf8 = path.join(pasta, 'utf8.html');
    const antigo = path.join(pasta, 'index.html');
    fs.writeFileSync(utf8, Buffer.from('﻿<html><body>Ação é crédito</body></html>', 'utf8'));
    fs.writeFileSync(antigo, Buffer.from([...'<html><body>A'].map((c) => c.charCodeAt(0)))); // preenchido abaixo
    // "Ação é crédito" em cp1252: ç=E7 ã=E3 é=E9
    const cp = [0x3c, 0x68, 0x74, 0x6d, 0x6c, 0x3e, 0x3c, 0x62, 0x6f, 0x64, 0x79, 0x3e,
      0x41, 0xe7, 0xe3, 0x6f, 0x20, 0xe9, 0x20, 0x63, 0x72, 0xe9, 0x64, 0x69, 0x74, 0x6f,
      0x3c, 0x2f, 0x62, 0x6f, 0x64, 0x79, 0x3e, 0x3c, 0x2f, 0x68, 0x74, 0x6d, 0x6c, 0x3e];
    fs.writeFileSync(antigo, Buffer.from(cp));

    const arquivos = {};
    arquivos['testeponte' + crypto.randomBytes(3).toString('hex')] = utf8;
    arquivos['testeponte' + crypto.randomBytes(3).toString('hex')] = antigo;
    for (const [id, caminho] of Object.entries(arquivos)) {
      app._previews[id] = { html: caminho, raiz: pasta, imagens: pasta, paragrafos: [], leitura: [], nome: 'pacote-teste' };
      ids.push(id);
    }
    servidor = http.createServer(app.handler);
    await new Promise((r) => servidor.listen(0, '127.0.0.1', r));
    const base = `http://127.0.0.1:${servidor.address().port}`;

    for (const [id, caminho] of Object.entries(arquivos)) {
      const resposta = await fetch(`${base}/api/preview/${id}/html`);
      const nome = path.basename(caminho);
      if (resposta.status !== 200) { falhas.push([`Resposta para ${nome}`, 200, resposta.status]); continue; }
      const dados = await resposta.json().catch(() => ({}));
      if ((dados.html || '').replace(/^﻿+/, '') !== '<html><body>Ação é crédito</body></html>') {
        falhas.push([`HTML devolvido de ${nome}`, 'texto com acentos, sem BOM', dados.html]);
      }
      if (dados.arquivo !== nome) falhas.push([`Nome do arquivo de ${nome}`, nome, dados.arquivo]);
    }
    if ((await fetch(`${base}/api/preview/naoexiste123/html`)).status !== 404) {
      falhas.push(['Identificador desconhecido', 404, 'outro status']);
    }
    if ((await fetch(`${base}/api/preview/..%2F..%2Fx/html`)).status !== 404) {
      falhas.push(['Identificador com caminho', 404, 'outro status']);
    }
  } finally {
    for (const id of ids) delete require('../app')._previews[id];
    if (servidor) await new Promise((r) => servidor.close(r));
    apagar(pasta);
  }
  return falhas;
}

/** O botão do Validador e o carregador do Workbench estão ligados um ao outro. */
async function _caso_ponte_na_tela() {
  const lerStatic = (...p) => fs.readFileSync(path.join(cfg.PASTA_PUBLICA, 'static', ...p), 'utf8');
  const js_validador = lerStatic('validador.js');
  const js_workbench_app = lerStatic('wb', 'app.js');
  const falhas = [];
  if (!js_validador.includes('data-workbench') || !js_validador.includes('abrirNoWorkbench')) {
    falhas.push(['Botão no resultado do Validador', 'presente', 'ausente']);
  }
  if (!js_validador.includes('Abrir o HTML deste pacote no Workbench')) {
    falhas.push(['Rótulo do botão', 'Abrir o HTML deste pacote no Workbench', 'ausente']);
  }
  if (!js_workbench_app.includes('WB.abrirPeca = abrirPeca')) {
    falhas.push(['WB.abrirPeca no Workbench', 'exposto', 'ausente']);
  }
  if (!js_validador.includes('WB.abrirPeca(')) {
    falhas.push(['Chamada a WB.abrirPeca no Validador', 'presente', 'ausente']);
  }
  return falhas;
}

/** O e-mail de devolução ao marketing: saudação, validade e os dois modelos. */
async function _caso_email_de_retorno() {
  const P = pacote();
  const ser = serializacao();
  const falhas = [];
  const confere = (nome, esperado, obtido) => {
    if (!isDeepStrictEqual(esperado, obtido)) falhas.push([nome, esperado, obtido]);
  };

  for (const [hora, esperado] of [[0, 'bom dia'], [11, 'bom dia'], [12, 'boa tarde'],
    [17, 'boa tarde'], [18, 'boa noite'], [23, 'boa noite']]) {
    confere(`Saudação às ${hora}h`, esperado, ser.saudacao_do_horario(new Date(2026, 10, 3, hora, 30)));
  }
  confere('Validade lida do nome da pasta', 'VAL_ATE_11.26', ser.validade_da_pasta('Briefing_CPI_Acao_Val_ate_11.26'));
  confere('Pasta sem validade no nome', '', ser.validade_da_pasta('Briefing_CPI_Acao'));

  let resultados = {};
  await comPasta('teste_email_', async (raiz) => {
    new _PacoteDeTeste().escrever(path.join(raiz, 'Campanha_Val_ate_11.26'));
    const ruim = new _PacoteDeTeste();
    ruim.redirect = false;
    ruim.escrever(path.join(raiz, 'Campanha_ruim'));
    await _ocr_de_teste(_criar_motor_de_teste(new _PacoteDeTeste().leituras), async () => {
      for (const r of await P.validar_lote(raiz)) resultados[path.basename(r.pasta)] = r;
    });
  });

  const bom = ser.para_json(resultados['Campanha_Val_ate_11.26']).email_retorno;
  confere('Pacote válido: sugere o e-mail de arquivada', 'aprovado', bom.sugerido);
  confere('Pacote válido: pode anexar', true, bom.pode_anexar);
  confere('Validade do pacote', 'VAL_ATE_11.26', bom.validade);
  let texto = ser.renderizar_email(bom.modelo_aprovado, 'Ana', 'ana@banco.com.br', bom.validade, '', new Date(2026, 10, 3, 9));
  for (const trecho of ['Prezados, bom dia!', 'Tudo bem?', 'verificadas e arquivadas em nosso controle',
    'EMKT', 'VAL_ATE_11.26', 'Ana', '4832 | CRM', 'ana@banco.com.br',
    'BANCO BRADESCO S.A.', 'Prédio Cinza, 1º andar', 'Classificação: INTERNA']) {
    if (!texto.includes(trecho)) falhas.push(['E-mail de arquivada traz', trecho, 'ausente']);
  }
  if (texto.includes('necessitam de ajustes')) falhas.push(['E-mail de arquivada não pede ajuste', 'ausente', 'presente']);

  const ruim_json = ser.para_json(resultados['Campanha_ruim']).email_retorno;
  confere('Pacote com bloqueio: sugere o e-mail de ajustes', 'ajustes', ruim_json.sugerido);
  confere('Pacote com bloqueio: não pode anexar', false, ruim_json.pode_anexar);
  texto = ser.renderizar_email(ruim_json.modelo_ajustes, '', '', '', '', new Date(2026, 10, 3, 15));
  for (const trecho of ['Prezados, boa tarde!', 'As peças abaixo necessitam de ajustes:',
    'Campanha_ruim', '[Nome Funcionário]', '[Email corporativo]']) {
    if (!texto.includes(trecho)) falhas.push(['E-mail de ajustes traz', trecho, 'ausente']);
  }
  return falhas;
}

function _casos_de_recursos() {
  const c = [];
  c.push(new _Caso('Acento e pontuação: só reprova se for grotesco',
    'E-mail de devolução ao marketing (saudação, validade, modelos)', { executar: _caso_email_de_retorno }));
  let G = 'Estrutura do pacote';
  c.push(new _Caso(G, 'Pasta com dois pacotes: os dois são achados e conferidos', { executar: _caso_lote }));
  G = 'Cache do OCR';
  c.push(new _Caso(G, 'Conferir o mesmo pacote de novo não relê as imagens', { executar: _caso_cache_le_uma_vez }));
  c.push(new _Caso(G, 'A impressão do cache vem do conteúdo da imagem e do motor, não do nome',
    { executar: _caso_cache_pelo_conteudo }));
  c.push(new _Caso(G, 'A versão da leitura só muda com o código de ocr, layout e normalizacao',
    { executar: _caso_versao_da_leitura }));
  G = 'Limpeza dos relatórios';
  c.push(new _Caso(G, 'Apaga só relatórios com mais de X dias e respeita o resto da pasta',
    { executar: _caso_limpeza_de_relatorios }));
  G = 'Idioma do Tesseract';
  c.push(new _Caso(G, 'Avisa quando o Tesseract está sem português, e só nesse caso', { executar: _caso_idioma_aviso }));
  c.push(new _Caso(G, 'O instalador baixa o idioma, recusa arquivo suspeito e explica falha de rede',
    { executar: _caso_idioma_instalador }));
  G = 'Ponte Validador → Workbench';
  c.push(new _Caso(G, 'A rota entrega o HTML do pacote (UTF-8 e Windows-1252) e recusa id inválido',
    { executar: _caso_ponte_com_o_workbench }));
  c.push(new _Caso(G, 'O botão e o carregador do Workbench estão ligados', { executar: _caso_ponte_na_tela }));
  return c;
}

function _casos_de_pacotes_reais() {
  const casos = [];
  for (const [nome, esperado] of [['PACOTE_APROVADO', PACOTE_APROVADO], ['PACOTE_ERROS', PACOTE_ERROS]]) {
    const pasta = path.join(PASTA_PACOTES_REAIS, nome);
    let existe = false;
    try { existe = fs.statSync(pasta).isDirectory(); } catch (e) { existe = false; }
    if (existe) {
      casos.push(new _Caso('Pacotes reais (motor de leitura de verdade)',
        `${nome}: o status esperado é ${esperado}`, { espera: { status: esperado }, pasta_real: pasta }));
    }
  }
  return casos;
}

// -------------------------------------------------------------------- execução

/** Devolve [falhas, resumo]. Levanta _Pulado quando o caso não se aplica. */
async function _rodar_caso(caso) {
  const o = ocr();
  const P = pacote();

  if (caso.executar) return [await caso.executar(), ''];

  if (caso.pasta_real) {
    const [disponivel, motivo] = o.ocr_disponivel();
    if (caso.espera.status === PACOTE_APROVADO && !disponivel) {
      throw new _Pulado(`sem motor de leitura de imagem (${motivo})`);
    }
    const resultado = await P.validar(caso.pasta_real, { usar_ocr: true });
    const motor = o.motor_ativo();
    return [_comparar(resultado, caso.espera),
      _resumo(resultado) + `\nmotor de leitura: ${motor ? motor.descricao : 'nenhum'}`];
  }

  const spec = new _PacoteDeTeste();
  if (caso.alterar) caso.alterar(spec);
  let resultado;
  await _ocr_de_teste(_criar_motor_de_teste(spec.leituras), async () => {
    await comPasta('teste_pacote_', async (pasta) => {
      spec.escrever(pasta);
      resultado = await P.validar(pasta, { usar_ocr: !caso.sem_ocr });
    });
  });
  return [_comparar(resultado, caso.espera), _resumo(resultado)];
}

/** Roda todos os casos neste processo e devolve o relatório (a tela e o terminal usam o mesmo). */
async function executar_testes_do_validador() {
  const casos = [..._casos_de_pacote(), ..._casos_de_recursos(), ..._casos_de_pacotes_reais()];
  const inicio = Date.now();
  const saida = [];
  for (const caso of casos) {
    const item = { nome: caso.nome, grupo: caso.grupo, falhas: [], resumo: '', pulado: '' };
    try {
      const [falhas, resumo] = await _rodar_caso(caso);
      item.resumo = resumo;
      item.falhas = falhas.map(([msg, esperado, obtido]) => ({ msg, esperado, obtido }));
    } catch (erro) {
      if (erro instanceof _Pulado) {
        item.pulado = erro.message;
      } else {
        // o caso quebrou: aparece como falha, não derruba a rodada
        item.falhas = [{ msg: 'Erro ao executar o caso', esperado: '', obtido: `${erro.name}: ${erro.message}` }];
      }
    }
    saida.push(item);
  }

  const pulados = saida.filter((i) => i.pulado).length;
  const falharam = saida.filter((i) => i.falhas.length).length;
  let existe = false;
  try { existe = fs.statSync(PASTA_PACOTES_REAIS).isDirectory(); } catch (e) { existe = false; }
  return {
    total: saida.length,
    passaram: saida.length - falharam - pulados,
    falharam,
    pulados,
    segundos: U.pyRound((Date.now() - inicio) / 1000, 1),
    pacotes_reais: { pasta: PASTA_PACOTES_REAIS, existe },
    casos: saida,
  };
}

/** --testar: imprime a rodada e sai com 1 se algum caso falhou. */
async function testar_pelo_terminal(como_json = false) {
  const relatorio = await executar_testes_do_validador();
  if (como_json) {
    // ASCII puro: o terminal do Windows não garante UTF-8 num pipe
    const ascii = JSON.stringify(relatorio).replace(/[\u007f-￿]/g,
      (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
    process.stdout.write(_MARCA_DO_RESULTADO + ascii + '\n');
    return 0;
  }
  let grupo_atual = null;
  for (const caso of relatorio.casos) {
    if (caso.grupo !== grupo_atual) {
      grupo_atual = caso.grupo;
      console.log(`\n${grupo_atual}`);
    }
    const marca = caso.pulado ? '[pulado]' : (caso.falhas.length ? '[FALHOU]' : '[ok]    ');
    console.log(`  ${marca} ${caso.nome}`);
    if (caso.pulado) console.log(`            ${caso.pulado}`);
    for (const f of caso.falhas) console.log(`            ${f.msg}: esperado ${f.esperado}, obtido ${f.obtido}`);
    if (caso.falhas.length && caso.resumo) {
      for (const linha of caso.resumo.split('\n')) console.log(`            | ${linha}`);
    }
  }
  console.log(`\n${relatorio.passaram} passaram, ${relatorio.falharam} falharam, `
    + `${relatorio.pulados} pulados, em ${relatorio.segundos.toFixed(1)} s.`);
  if (!relatorio.pacotes_reais.existe) {
    console.log('Pacotes reais: crie pacotes_de_teste/PACOTE_APROVADO e/ou PACOTE_ERROS '
      + 'ao lado do programa para incluí-los.');
  }
  return relatorio.falharam ? 1 : 0;
}

module.exports = {
  PACOTE_APROVADO, PACOTE_ERROS, PASTA_PACOTES_REAIS, _MARCA_DO_RESULTADO,
  _PacoteDeTeste, _criar_motor_de_teste, _ocr_de_teste, _nomes, _resumo, _comparar,
  _Caso, _Pulado, _casos_de_pacote, _casos_de_recursos, _casos_de_pacotes_reais,
  _rodar_caso, executar_testes_do_validador, testar_pelo_terminal,
};
