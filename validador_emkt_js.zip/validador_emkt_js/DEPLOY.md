# Subir em servidor

Só precisa de Node.js 20+. Não há Python em lugar nenhum.

    npm install --omit=dev
    HOST=0.0.0.0 PORT=8080 node servidor.js

- **PORT / HOST**: porta e endereço de escuta. Padrão: `127.0.0.1` e a primeira porta livre a partir
  da 5000. Em servidor, `HOST=0.0.0.0` com `PORT` fixa. O navegador não é aberto nesse modo.
- **Proxy reverso** (nginx, IIS...): deixe a ferramenta atrás dele com HTTPS e autenticação — o
  programa não tem login. No nginx, `client_max_body_size 300m;` e, na rota
  `/api/conferir-em-fluxo`, `proxy_buffering off;` (o programa já manda `X-Accel-Buffering: no`) e
  `proxy_read_timeout` alto: a resposta sai pacote a pacote, e ler imagens demora.
- **Pasta gravável**: `relatorios/` (e `.cache-leitura/`) ficam na pasta do programa. Se ela for
  somente leitura, aponte `DADOS_DIR` para uma pasta gravável (`relatorios/`, `regras-time.js`,
  `pacotes_de_teste/`); o cache e o `tessdata` seguem `VALIDADOR_PASTA_DE_DADOS`.
- **Limpeza**: `DIAS_RELATORIOS` (padrão 30) apaga relatórios antigos ao abrir; `HORAS_TEMPORARIAS`
  (padrão 24) apaga os pacotes enviados e seus previews; `MAX_UPLOAD_MB` (padrão 300) limita cada envio.
- **OCR**: um destes, na máquina do servidor:
  - `tesseract` instalado (apt install tesseract-ocr tesseract-ocr-por) — depois confira em
    `/api/status-ocr`; ou
  - `npm install tesseract.js` (WebAssembly, não instala programa; coloque `por.traineddata` na pasta
    `tessdata/` ou rode `node servidor.js --instalar-idioma-por`); ou
  - `npm install @gutenye/ocr-node` (modelos PP-OCR, os mesmos do RapidOCR).
  `sharp` (em `optionalDependencies`) abre as imagens; o `npm install` o traz.
- **Processo**: rode sob pm2/systemd (`Restart=always`). Saúde: `GET /api/status-ocr`.
- Testes no servidor: `node servidor.js --testar` (ou `/validador/tests/`).
