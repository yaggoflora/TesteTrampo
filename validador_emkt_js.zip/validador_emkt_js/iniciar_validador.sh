#!/usr/bin/env bash
# Validador EMKT + SFMC Workbench (Linux, macOS ou Git Bash no Windows).
# Uso: ./iniciar_validador.sh   (na primeira vez instala as bibliotecas opcionais; precisa de internet)
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js nao encontrado. Instale em https://nodejs.org/ (versao 20 ou mais nova)."
  echo "Sem Node na maquina? Use o pacote portatil gerado por ./gerar_executavel.sh."
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo "Preparando o ambiente pela primeira vez, aguarde..."
  npm install --omit=dev --no-audit --no-fund || echo "Aviso: npm install falhou; o programa abre, mas a leitura de imagens pode ficar indisponivel."
fi

echo "Abrindo o Validador EMKT. Ctrl+C encerra."
exec node servidor.js "$@"
