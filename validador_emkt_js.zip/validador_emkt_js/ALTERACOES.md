# Alterações

## v5 — migração para JavaScript (Node.js)

O programa inteiro passou a ser HTML, CSS e JavaScript. Nada de Python: o servidor roda em Node.js
e pode subir em qualquer servidor que rode Node.
- A lógica dos 16 módulos (`validador/*.py`) foi portada para `src/validador/*.js` com os mesmos nomes,
  as mesmas regras e as mesmas mensagens; as rotas do Flask viraram `src/app.js` (http nativo).
- Bibliotecas que o Python trazia ganharam equivalente em `src/lib`: `difflib`, leitor/gerador de docx
  e zip, parser de HTML no estilo do BeautifulSoup, leitor de multipart (upload em fluxo, direto para o disco).
- Os 53 testes do `--testar` foram portados e passam (`node servidor.js --testar`).
- `iniciar_validador.*` e `gerar_executavel.sh` / `gerar_exe.bat` agora usam Node. O pacote para quem
  não tem Node leva o Node dentro (`runtime/`) e pode ser gerado para outro sistema (`ALVO=...`).
- Para servidor: `HOST`, `PORT`, `DADOS_DIR`, `MAX_UPLOAD_MB`, `HORAS_TEMPORARIAS`; os pacotes enviados
  deixam de acumular (apagam depois de 24 h).
- Removidos: `sincronizar.py` e `requirements.txt` (não há mais script único nem pip). O motor `rapidocr-antigo` saiu;
  `rapidocr` agora é o PP-OCR via `@gutenye/ocr-node`; `tesseract-js` é novo.

---

# Alterações (v4): repetição, texto de imagem, aviso de conferência e executável

1. **Palavra repetida não reprova.** "Livelo Livelo" no HTML e um "Livelo" no docx vira aviso
   (até 3 palavras, todas já presentes no docx). Fora disso: se o trecho tiver "não", "sem",
   "nunca", "nenhum(a)", continua reprovando. Código: `comparador._motivo_de_aviso`.
2. **Texto de imagem só reprova se NADA dele estiver no docx.** Se pelo menos uma palavra lida
   na imagem consta no docx, o que faltou é aviso. Palavras de 1 a 2 letras (ruído de ícone) não contam.
3. **Continuam reprovando** (de propósito): número, taxa, prazo ou valor diferente (qualquer
   palavra com dígito) e trechos obrigatórios (disclaimer, opt-out, atendimento) ausentes do docx.
4. **Redes sociais** ("Acompanhe o Bradesco nas Redes Sociais") só no docx: é só aviso, e agora
   a peça fica válida (antes ficava em "atenção").
5. **Observação de conferência manual** na tela de cada pacote e no relatório.
6. **Arquivos para executar**: `iniciar_validador.bat` (duplo clique, Windows), `iniciar_validador.sh`
   (bash) e `gerar_exe.bat` (gera `dist\ValidadorEMKT\ValidadorEMKT.exe` no seu computador).
7. 5 testes novos (`--testar`): 53 passam.

---

# Alterações nesta versão (ajuste de rigor + e-mail de devolução)

1. **Só reprova se a peça for realmente diferente.** Acento, vírgula, dois pontos ou
   espaço diferentes entre HTML e CONTEUDO.docx (ex.: `Cartões Digitais:` x `Cartões Digitais`)
   viram **aviso de diferença**: aparecem na tela, não reprovam, não pedem "atenção" e o
   pacote continua **válido para anexar**. Reprova: palavra faltando, trocada ou sobrando,
   imagem errada, letra errada no texto do código, e acento/pontuação **grotescos**.
   Limites em `validador/regras.py` (`LIMITE_ACENTOS_NA_PECA`, `LIMITE_ACENTOS_NO_TRECHO`,
   `LIMITE_PONTUACAO_NA_PECA`). Código: `validador/comparador.py`.
2. **Caixa de console com o e-mail de devolução** em cada pacote (`static/validador.js`,
   `validador/serializacao.py`): válido → e-mail "arquivadas em nosso controle";
   reprovado → e-mail "necessitam de ajustes" com o nome da ação. Saudação pelo horário
   (antes das 12h bom dia, até 18h boa tarde, depois boa noite). Nome e e-mail corporativo
   ficam salvos no navegador; a validade (VAL_ATE_MM.AA) vem do nome da pasta e pode ser editada.
3. 6 testes novos (`--testar`): 48 passam.

---

# Alterações nesta versão

1. **Ponte Validador → Workbench**: botão "Abrir o HTML deste pacote no Workbench" no resultado.
   Rota nova `/api/preview/<id>/html`; no Workbench, `WB.abrirPeca()` (com Desfazer).
   Arquivos: static/validador.js, static/wb/app.js, static/validador.css.
2. **Acentos no OCR**: aviso na tela e no relatório quando o Tesseract está sem `por`.
   Instalador: `python validador_emkt_unificado.py --instalar-idioma-por`
   (usa a pasta do Tesseract; sem permissão, cria `tessdata/` ao lado do script).
   `TESSDATA_URL` aponta para um espelho interno. Com RapidOCR não é preciso. (validador/ocr.py, validador/pacote.py)
3. **Limpeza de relatórios**: ao abrir, apaga os com mais de 30 dias (`DIAS_RELATORIOS=15` muda; `0` desliga).
4. **Cache do OCR**: a versão da leitura é o hash só de `ocr`, `layout` e `normalizacao`. (validador/ocr.py)
5. **Testes do Validador**: 42 casos em `/validador/tests/` e `python validador_emkt_unificado.py --testar`.
   Pacotes reais opcionais em `pacotes_de_teste/PACOTE_APROVADO` e `PACOTE_ERROS`.
