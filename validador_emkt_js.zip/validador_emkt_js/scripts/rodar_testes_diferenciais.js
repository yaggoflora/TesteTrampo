'use strict';
// Roda test/*.teste.js. Os diferenciais usam o Python original como oráculo (só para quem está
// desenvolvendo; o programa em si não usa Python). Defina VALIDADOR_REF para a pasta do original.
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const pasta = path.join(__dirname, '..', 'test');
let falhou = 0;
for (const arq of fs.readdirSync(pasta).filter((f) => f.endsWith('.teste.js')).sort()) {
  const r = spawnSync(process.execPath, [path.join(pasta, arq)], { stdio: 'inherit' });
  if (r.status !== 0) { falhou += 1; console.error(`FALHOU: ${arq}`); }
}
process.exit(falhou ? 1 : 0);
