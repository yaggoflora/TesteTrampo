'use strict';
/**
 * Gera o pacote portátil para quem NÃO tem Node.js: uma pasta com o programa, o Node dentro
 * (runtime/) e um lançador de duplo clique, mais o .zip para mandar ao time.
 *
 * Quem GERA precisa de Node 20+ e npm, e de internet (baixa o Node do alvo e as bibliotecas).
 * Quem RECEBE não precisa de nada. Diferente de um .exe de PyInstaller, dá para gerar para
 * outro sistema: ALVO=win-x64 (padrão) | win-arm64 | linux-x64 | linux-arm64 | darwin-x64 | darwin-arm64.
 *
 * Variáveis (para uso offline ou sem rede liberada):
 *   NODE_VERSION   versão do Node a embutir (padrão: a do Node que está rodando este script)
 *   NODE_ZIP       arquivo do Node já baixado (.zip do Windows ou .tar.xz/.tar.gz de Linux e macOS)
 *   NODE_DIST_DIR  pasta do Node já extraído (com node.exe, node ou bin/node)
 *   SKIP_NPM=1     não roda o npm install: copia ./node_modules, se existir
 *   SAIDA          pasta de saída (padrão: dist)
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const { spawnSync } = require('child_process');
const { ZipLeitor, escreverZip } = require('../src/lib/zip');

const RAIZ = path.resolve(__dirname, '..');
const NOME = 'ValidadorEMKT';
const SAIDA = path.resolve(process.env.SAIDA || path.join(RAIZ, 'dist'));
const PALCO = path.join(SAIDA, NOME);

const sistemaAtual = `${{ win32: 'win', linux: 'linux', darwin: 'darwin' }[process.platform]}-${process.arch}`;
const ALVO = process.env.ALVO || 'win-x64';
const [alvoSo, alvoCpu] = ALVO.split('-');
if (!['win', 'linux', 'darwin'].includes(alvoSo) || !['x64', 'arm64'].includes(alvoCpu)) {
  console.error(`ALVO inválido: ${ALVO}`); process.exit(1);
}
const VERSAO = (process.env.NODE_VERSION || process.versions.node).replace(/^v/, '');
const ehWin = alvoSo === 'win';

const passo = (t) => console.log(`>> ${t}`);
const falha = (t) => { console.error(`\nERRO: ${t}`); process.exit(1); };

function baixar(url, destino, redirecionamentos = 5) {
  return new Promise((resolver, rejeitar) => {
    https.get(url, { headers: { 'User-Agent': 'validador-emkt' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirecionamentos > 0) {
        res.resume(); return resolver(baixar(new URL(res.headers.location, url).href, destino, redirecionamentos - 1));
      }
      if (res.statusCode !== 200) { res.resume(); return rejeitar(new Error(`HTTP ${res.statusCode} em ${url}`)); }
      const saida = fs.createWriteStream(destino);
      res.pipe(saida);
      saida.on('finish', () => saida.close(resolver));
      saida.on('error', rejeitar);
    }).on('error', rejeitar);
  });
}

function copiar(origem, destino) {
  fs.cpSync(origem, destino, { recursive: true, filter: (s) => !/(^|[\\/])(\.git|\.cache-leitura|relatorios|dist|node_modules|test|tessdata)([\\/]|$)/.test(path.relative(RAIZ, s)) });
}

async function obterNode() {
  const destino = path.join(PALCO, 'runtime');
  fs.mkdirSync(destino, { recursive: true });
  const exe = ehWin ? 'node.exe' : 'node';

  if (process.env.NODE_DIST_DIR) {
    const base = path.resolve(process.env.NODE_DIST_DIR);
    const achado = [path.join(base, exe), path.join(base, 'bin', exe)].find((p) => fs.existsSync(p));
    if (!achado) falha(`NODE_DIST_DIR sem ${exe} (nem bin/${exe}): ${base}`);
    fs.copyFileSync(achado, path.join(destino, exe));
    return;
  }

  const prefixo = `node-v${VERSAO}-${ALVO}`;
  let arquivo = process.env.NODE_ZIP && path.resolve(process.env.NODE_ZIP);
  if (!arquivo) {
    const extensao = ehWin ? 'zip' : 'tar.xz';
    arquivo = path.join(os.tmpdir(), `${prefixo}.${extensao}`);
    if (!fs.existsSync(arquivo)) {
      const url = `https://nodejs.org/dist/v${VERSAO}/${prefixo}.${extensao}`;
      passo(`Baixando o Node ${VERSAO} para ${ALVO}...`);
      try { await baixar(url, arquivo); } catch (e) {
        try { fs.unlinkSync(arquivo); } catch (x) { /* nada */ }
        falha(`não consegui baixar ${url} (${e.message}).\n  Sem internet liberada? Baixe o arquivo em outra máquina e rode de novo com NODE_ZIP=<arquivo>.`);
      }
    }
  }
  if (/\.zip$/i.test(arquivo)) {
    const zip = new ZipLeitor(arquivo);
    const nome = zip.nomes().find((n) => /(^|\/)node\.exe$/.test(n));
    if (!nome) falha(`node.exe não está em ${arquivo}`);
    fs.writeFileSync(path.join(destino, 'node.exe'), zip.ler(nome));
  } else {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nodeext_'));
    const r = spawnSync('tar', ['-xf', arquivo, '-C', tmp, '--wildcards', '*/bin/node'], { stdio: 'inherit' });
    if (r.status !== 0) falha('o "tar" não conseguiu abrir o arquivo do Node (precisa de suporte a .xz).');
    const achado = fs.readdirSync(tmp).map((d) => path.join(tmp, d, 'bin', 'node')).find((p) => fs.existsSync(p));
    if (!achado) falha(`bin/node não está em ${arquivo}`);
    fs.copyFileSync(achado, path.join(destino, 'node'));
    fs.chmodSync(path.join(destino, 'node'), 0o755);
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

function instalarBibliotecas() {
  if (process.env.SKIP_NPM === '1') {
    const nm = path.join(RAIZ, 'node_modules');
    if (fs.existsSync(nm)) { passo('SKIP_NPM=1: copiando node_modules existente.'); fs.cpSync(nm, path.join(PALCO, 'node_modules'), { recursive: true }); }
    else passo('SKIP_NPM=1 e sem node_modules: o pacote sai sem sharp (a leitura de imagens não funcionará).');
    return;
  }
  passo('Instalando as bibliotecas para o alvo (precisa de internet)...');
  const so = { win: 'win32', linux: 'linux', darwin: 'darwin' }[alvoSo];
  const r = spawnSync('npm', ['install', '--omit=dev', '--no-audit', '--no-fund', `--os=${so}`, `--cpu=${alvoCpu}`],
    { cwd: PALCO, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) falha('o npm install falhou.');
}

function lancadores() {
  const ler = (...p) => fs.readFileSync(path.join(RAIZ, ...p), 'utf8');
  fs.writeFileSync(path.join(PALCO, 'LEIA-ME.txt'), ler('LEIA-ME-USUARIO.txt').replace(/\r?\n/g, ehWin ? '\r\n' : '\n'));
  if (ehWin) {
    fs.writeFileSync(path.join(PALCO, `${NOME}.bat`), [
      '@echo off', 'chcp 65001 >nul', `title Validador EMKT`, 'cd /d "%~dp0"',
      '"%~dp0runtime\\node.exe" "%~dp0servidor.js"',
      'if errorlevel 1 (', '  echo.', '  echo O programa parou. Veja a mensagem acima.', '  pause', ')', '',
    ].join('\r\n'));
  } else {
    const sh = path.join(PALCO, `${NOME}.sh`);
    fs.writeFileSync(sh, ['#!/usr/bin/env bash', 'cd "$(dirname "$0")"', 'exec ./runtime/node servidor.js "$@"', ''].join('\n'));
    fs.chmodSync(sh, 0o755);
  }
}

function listar(pasta, base = pasta) {
  const itens = [];
  for (const e of fs.readdirSync(pasta, { withFileTypes: true })) {
    const p = path.join(pasta, e.name);
    if (e.isDirectory()) itens.push(...listar(p, base));
    else if (e.isFile()) itens.push({ nome: path.relative(base, p).split(path.sep).join('/'), dados: fs.readFileSync(p) });
  }
  return itens;
}

(async () => {
  if (parseInt(process.versions.node, 10) < 20) falha('é preciso o Node.js 20 ou mais novo.');
  fs.rmSync(PALCO, { recursive: true, force: true });
  fs.mkdirSync(PALCO, { recursive: true });

  passo(`Copiando o programa (alvo ${ALVO}, Node ${VERSAO})...`);
  for (const item of ['servidor.js', 'package.json', 'package-lock.json', 'src', 'public', 'LEIA-ME.md', 'DEPLOY.md', 'ALTERACOES.md']) {
    if (fs.existsSync(path.join(RAIZ, item))) copiar(path.join(RAIZ, item), path.join(PALCO, item));
  }
  await obterNode();
  instalarBibliotecas();
  lancadores();

  if (ALVO === sistemaAtual) {
    passo('Testando o pacote gerado (--testar)...');
    const exe = path.join(PALCO, 'runtime', ehWin ? 'node.exe' : 'node');
    const r = spawnSync(exe, ['servidor.js', '--testar'], { cwd: PALCO, encoding: 'utf8', env: { ...process.env, ABRIR_NAVEGADOR: '0' } });
    fs.writeFileSync(path.join(SAIDA, 'teste-do-pacote.txt'), (r.stdout || '') + (r.stderr || ''));
    if (r.status !== 0) falha('os testes do pacote falharam. Veja dist/teste-do-pacote.txt');
    console.log('   Testes OK.');
    for (const d of ['relatorios', '.cache-leitura']) fs.rmSync(path.join(PALCO, d), { recursive: true, force: true });
  } else {
    passo(`Alvo ${ALVO} difere desta máquina (${sistemaAtual}): o pacote não foi executado aqui. Rode --testar no sistema de destino.`);
  }

  passo('Gerando o .zip...');
  const zip = path.join(SAIDA, `${NOME}.zip`);
  fs.writeFileSync(zip, escreverZip(listar(PALCO, SAIDA)));
  console.log(`\nPronto!\n  Pasta : ${PALCO}   (copie a pasta INTEIRA)\n  ZIP   : ${zip}   (mande este arquivo para o time)`);
})().catch((e) => falha(e && e.stack || e));
