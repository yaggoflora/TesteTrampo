#!/usr/bin/env node
'use strict';
/**
 * Validador de pacotes EMKT + SFMC Workbench — Bradesco · CRM · Publicação e Orquestração
 *
 * Duas ferramentas na mesma tela, no mesmo tema (vermelho Bradesco, Manrope, claro/escuro):
 *
 *   Aba "Validador de pacotes"  confere o pacote que o marketing envia: taxonomia e sequência das
 *                               imagens, cruzamento HTML x imagens x CONTEUDO.docx, incluindo o
 *                               texto dentro dos banners. SOMENTE LEITURA: nada do pacote é
 *                               alterado, movido ou apagado. Os relatórios vão para a subpasta
 *                               "relatorios".
 *   Aba "SFMC Workbench"        homologação técnica do HTML de e-mail para o Salesforce Marketing
 *                               Cloud. Roda no navegador; o rascunho fica salvo só no navegador
 *                               de cada pessoa. Testes: /workbench/tests/
 *
 * Como executar:
 *     npm install          (uma vez; só instala o que é opcional: sharp e tesseract.js)
 *     node servidor.js     (abre em http://127.0.0.1:5000; se a porta estiver ocupada, sobe na seguinte)
 *
 * Outros comandos:
 *     node servidor.js --testar [--json]     roda os testes automáticos no terminal (sai com 1 se falhar)
 *     node servidor.js --instalar-idioma-por instala o idioma português do Tesseract
 *
 * Variáveis de ambiente:
 *     PORT / PORTA        porta fixa (sem isso, procura a partir da 5000)
 *     HOST                endereço de escuta; padrão 127.0.0.1 (só esta máquina). Em servidor: 0.0.0.0
 *     ABRIR_NAVEGADOR=0   não abre o navegador ao iniciar
 *     DIAS_RELATORIOS     relatórios com mais de tantos dias são apagados ao abrir (padrão 30; 0 desliga)
 *     MAX_UPLOAD_MB       limite de cada envio (padrão 300)
 *     DADOS_DIR           onde ficam relatorios/, regras-time.js e pacotes_de_teste/ (padrão: pasta do programa)
 *     HORAS_TEMPORARIAS   por quanto tempo guardar os pacotes enviados (padrão 24; 0 = até fechar)
 *     OCR_MOTOR           força o motor de leitura de imagem
 */
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const cfg = require('./src/config');

const MIN_NODE = 20;
if (parseInt(process.versions.node.split('.')[0], 10) < MIN_NODE) {
  console.error(`É preciso o Node.js ${MIN_NODE} ou mais novo (esta máquina tem ${process.versions.node}).`);
  process.exit(1);
}

function abrirNavegador(endereco) {
  // webbrowser pode falhar em terminal sem sessão gráfica: se falhar, o endereço continua
  // impresso e dá para abrir na mão.
  try {
    let comando; let args;
    if (process.platform === 'win32') { comando = 'cmd'; args = ['/c', 'start', '', endereco]; }
    else if (process.platform === 'darwin') { comando = 'open'; args = [endereco]; }
    else if (process.env.DISPLAY || process.env.WAYLAND_DISPLAY) { comando = 'xdg-open'; args = [endereco]; }
    else return;
    const filho = spawn(comando, args, { stdio: 'ignore', detached: true });
    filho.on('error', () => {});
    filho.unref();
  } catch (e) { /* segue */ }
}

async function principal(argv) {
  // comandos que não sobem a tela
  if (argv.includes('--instalar-idioma-por')) {
    const { instalar_idioma_por } = require('./src/validador/ocr');
    process.exit((await instalar_idioma_por()) ? 0 : 1);
  }
  if (argv.includes('--testar')) {
    const { testar_pelo_terminal } = require('./src/testes/validador_testes');
    process.exit(await testar_pelo_terminal(argv.includes('--json')));
  }

  const app = require('./src/app');
  process.on('exit', app.limpar_temporarias);
  for (const sinal of ['SIGINT', 'SIGTERM']) process.on(sinal, () => process.exit(0));

  // relatórios antigos saem ao abrir o programa (ver DIAS_RELATORIOS, em src/config.js)
  const [apagados, liberados] = cfg.limpar_relatorios_antigos();

  const host = process.env.HOST || '127.0.0.1';
  const fixa = process.env.PORT || process.env.PORTA;
  const porta = fixa ? parseInt(fixa, 10) : await cfg._escolher_porta(5000, host);
  const publico = ['0.0.0.0', '::'].includes(host);
  const endereco = `http://${host === '0.0.0.0' || host === '::' ? 'localhost' : host}:${porta}`;

  const servidor = http.createServer(app.handler);
  // o upload de um pacote grande demora: sem tempo limite por requisição, só pela inatividade
  servidor.requestTimeout = 0;
  servidor.headersTimeout = 60 * 1000;
  servidor.keepAliveTimeout = 65 * 1000;

  servidor.on('error', (erro) => {
    if (erro.code === 'EADDRINUSE') console.error(`\nA porta ${porta} já está em uso. Escolha outra com PORT=<número>.`);
    else console.error('\nO servidor parou:', erro.message);
    process.exit(1);
  });

  servidor.listen(porta, host, () => {
    console.log('\n' + '='.repeat(66));
    console.log('  Validador de pacotes EMKT · Bradesco CRM');
    console.log(`  Abra no navegador: ${endereco}`);
    if (!fixa && porta !== 5000) console.log('  (a porta 5000 estava ocupada, então subi nesta aqui)');
    if (publico) console.log(`  Escutando em todas as interfaces (HOST=${host}), porta ${porta}.`);
    if (apagados) {
      console.log(`  Limpeza: ${apagados} relatório(s) com mais de ${cfg.DIAS_RELATORIOS} dias `
        + `apagado(s), ${(liberados / 1048576).toFixed(1)} MB liberados.`);
    }
    console.log('  Para encerrar: Ctrl+C aqui, ou feche esta janela.');
    console.log('='.repeat(66) + '\n');
    app.agendar_limpeza();
    if ((process.env.ABRIR_NAVEGADOR || '1') !== '0' && !publico && !process.env.PORT) {
      setTimeout(() => abrirNavegador(endereco), 1200);
    }
  });
}

principal(process.argv.slice(2)).catch((erro) => {
  console.error(erro && erro.stack || erro);
  process.exit(1);
});
