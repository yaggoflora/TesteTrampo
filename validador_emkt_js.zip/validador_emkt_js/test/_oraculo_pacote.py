"""Oráculo da frente E: cria pacotes de teste no disco e roda o Python original sobre eles.

Uso: python3 _oraculo_pacote.py <pasta de trabalho>
Escreve <pasta>/_python.json com os resultados de cada caso. Os pacotes ficam em <pasta>/casos/.
"""
import asyncio  # noqa: F401
import dataclasses
import datetime
import json
import os
import shutil
import sys
import tempfile
import zlib

REF = os.environ["VALIDADOR_REF"]
sys.path.insert(0, REF)

from docx import Document  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.opc.constants import RELATIONSHIP_TYPE  # noqa: E402
from docx.shared import Pt  # noqa: E402
from PIL import Image  # noqa: E402

from validador import (docx_parser, html_parser, ocr, pacote, relatorio,  # noqa: E402
                       serializacao)

RAIZ = sys.argv[1]
CASOS = os.path.join(RAIZ, "casos")


# ---------------------------------------------------------------- fixtures

def imagem(caminho, ordem=0, tamanho=(600, 200)):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    semente = zlib.crc32(f"{os.path.basename(caminho)}{ordem}".encode())
    cor = ((semente >> 16) & 255, (semente >> 8) & 255, semente & 255)
    Image.new("RGB", tamanho, cor).save(caminho)


def link(par, texto, url):
    rel = par.part.relate_to(url, RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
    h = OxmlElement("w:hyperlink")
    h.set(qn("r:id"), rel)
    r = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = texto
    r.append(t)
    h.append(r)
    par._p.append(h)


def docx(caminho, paragrafos, tabela=None, links=None, sup=None, quebra=None):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    d = Document()
    for texto in paragrafos:
        p = d.add_paragraph()
        if links and texto in links:
            link(p, texto, links[texto])
        elif sup and texto in sup:
            base, nota = sup[texto]
            p.add_run(base)
            r = p.add_run(nota)
            r.font.superscript = True
        elif quebra and texto in quebra:
            r = p.add_run(texto)
            r.add_break()
            p.add_run(quebra[texto])
        else:
            p.add_run(texto)
    if tabela:
        t = d.add_table(rows=len(tabela), cols=len(tabela[0]))
        for i, linha in enumerate(tabela):
            for j, c in enumerate(linha):
                t.cell(i, j).text = c
        if len(tabela[0]) >= 2:
            t.cell(0, 0).merge(t.cell(0, 1))
    d.save(caminho)


HTML_BASE = """<!DOCTYPE html>
<html><head><title>Peça</title><style>.x{color:red}</style></head>
<body>
<!-- comentário que não conta -->
<table><tr><td><img src="imagens/EMKT_01.png" alt="Banner principal" width="600"></td></tr>
<tr><td><p>Olá, <b>cliente</b>, confira a nova taxa de <b>CDB</b><sup>2</sup>.</p>
<p>Simule agora&nbsp;mesmo    sua oferta .</p></td></tr>
<tr><td><a href="https://www.bradesco.com.br/r?x=1&utm_source=a">Saiba mais</a></td></tr>
<tr><td><img src="imagens/EMKT_02.png" alt=""></td></tr>
<tr><td style="display:none">Texto escondido do preheader</td></tr>
<tr><td background="imagens/EMKT_03.png">Rodapé com fundo</td></tr>
<tr><td style="background-image:url('imagens/EMKT_04.png')"></td></tr>
<tr><td><img src="http://cdn.exemplo.com/remota.png" alt="Remota"><img src="https://x.com/open.aspx?id=1" width="1" height="1"></td></tr>
<tr><td>Disclaimer: consulte condições em www.bradesco.com.br/regras ou ligue 4002 0022.<br>Cancele aqui: <a href="https://x.com/c">www.bradesco.com.br/cancelar</a></td></tr>
<tr><td>Prazo até 10/01/2020 &#xFEFF;</td></tr>
</table>
<img src="imagens/EMKT_05.png" srcset="imagens/EMKT_05.png 1x, imagens/EMKT_06.png 2x">
</body></html>"""

HTML_PERFEITO = """<html><body>
<img src="EMKT_01.png" alt="Banner">
<p>Simule sua oferta agora.</p>
<a href="https://www.bradesco.com.br/redirect?x=1">Quero</a>
<p>Atendimento: 4002 0022.</p>
</body></html>"""

HTML_WEBMAIL = """<html><head></head><body>
<div class="gmail_quote">Início da mensagem encaminhada:</div>
<div>De: marketing@x.com</div><div class="a3s aiL">
<div class="WordSection1"><p>Corpo da peça aqui.</p><img src="EMKT_01.png" alt="x">
<p>Baixar</p><p>Fazer o download</p><p><a href="https://www.bradesco.com.br/r">Oferta</a></p></div></div>
<div>Enviado do meu iPhone</div></body></html>"""


def montar():
    shutil.rmtree(CASOS, ignore_errors=True)
    os.makedirs(CASOS)
    leituras = {}

    # A: pacote variado, estrutura html/ + imagens/ + docx na raiz
    a = os.path.join(CASOS, "A_ACAO_01_VAL_ATE_03.27")
    os.makedirs(os.path.join(a, "html"))
    with open(os.path.join(a, "html", "index.html"), "w", encoding="utf-8") as f:
        f.write(HTML_BASE)
    with open(os.path.join(a, "html", "teste_pequeno.html"), "w", encoding="utf-8") as f:
        f.write("<p>x</p>")
    for i in range(1, 7):
        imagem(os.path.join(a, "html", "imagens", f"EMKT_{i:02d}.png"), i)
    imagem(os.path.join(a, "html", "imagens", "extra.png"), 9)
    docx(os.path.join(a, "CONTEUDO.docx"),
         ["Olá, cliente, confira a nova taxa de CDB2.", "Simule agora mesmo sua oferta.",
          "Saiba mais", "Banner principal", "Rodapé com fundo",
          "Disclaimer: consulte condições em www.bradesco.com.br/regras ou ligue 4002 0022.",
          "Linha com tab", "Prazo até 10/01/2020"],
         tabela=[["Célula A", "Célula B"], ["Célula A", "Outra"]],
         links={"Saiba mais": "https://exemplo.com/x"},
         sup={"Linha com tab": ("Linha com tab", "1")})
    docx(os.path.join(a, "ASSUNTO.docx"),
         ["Assunto: Seu crédito está liberado", "Pré-header: Simule agora sem sair de casa"])
    leituras[a] = {
        "emkt_01.png": ["Banner principal", "Simule agora", "36x²"],
        "emkt_02.png": ["Aviso 10/01/2020", "50%"],
        "emkt_03.png": [],
        "emkt_05.png": ["Texto da imagem cinco"],
    }

    # B: perfeito e simples (OCR lendo igual)
    b = os.path.join(CASOS, "B_PERFEITO")
    os.makedirs(b)
    with open(os.path.join(b, "peca.html"), "w", encoding="utf-8") as f:
        f.write(HTML_PERFEITO)
    imagem(os.path.join(b, "EMKT_01.png"), 1)
    docx(os.path.join(b, "CONTEUDO.docx"),
         ["Banner", "Simule sua oferta agora.", "Quero", "Atendimento: 4002 0022."])
    docx(os.path.join(b, "ASSUNTO.docx"), ["Assunto", "Oferta para você", "Pré-header", "Veja a oferta."])
    leituras[b] = {"emkt_01.png": ["Banner"]}

    # C: sem docx, só .doc
    c = os.path.join(CASOS, "C_SEM_DOCX")
    os.makedirs(c)
    with open(os.path.join(c, "p.html"), "w", encoding="utf-8") as f:
        f.write(HTML_PERFEITO)
    open(os.path.join(c, "antigo.doc"), "wb").write(b"x")
    open(os.path.join(c, "pacote.zip"), "wb").write(b"x")

    # D: sem html
    d = os.path.join(CASOS, "D_SEM_HTML")
    os.makedirs(d)
    docx(os.path.join(d, "CONTEUDO.docx"), ["a b c"])

    # E: docx corrompido + docx de verdade
    e = os.path.join(CASOS, "E_DOCX_RUIM")
    os.makedirs(e)
    with open(os.path.join(e, "p.html"), "w", encoding="utf-8") as f:
        f.write(HTML_PERFEITO)
    open(os.path.join(e, "quebrado.docx"), "wb").write(b"isto nao e um zip")

    # F: webmail
    f_ = os.path.join(CASOS, "F_WEBMAIL")
    os.makedirs(f_)
    with open(os.path.join(f_, "salvo.html"), "w", encoding="utf-8") as fh:
        fh.write(HTML_WEBMAIL)
    imagem(os.path.join(f_, "EMKT_01.png"), 1)
    docx(os.path.join(f_, "CONTEUDO.docx"), ["Corpo da peça aqui.", "Texto da imagem", "Oferta"])
    leituras[f_] = {"emkt_01.png": ["Texto da imagem"]}

    # H: sequência com divergências (palavra trocada, faltando, acento, ordem) e data vencida no docx
    h = os.path.join(CASOS, "H_DIVERGENTE")
    os.makedirs(h)
    with open(os.path.join(h, "peca.html"), "w", encoding="utf-8") as fh:
        fh.write("""<html><body><img src="EMKT_01.png" alt="Banner"><p>Você ganhou uma oferta exclusiva para crédito consignado.</p>
<p>Taxa de 1,99% ao mês em até 36x.</p><a href="https://www.bradesco.com.br/redirect?x=1">Contrate</a>
<p>Cancele: 0800 570 0022. Para cancelar o recebimento, responda SAIR.</p></body></html>""")
    imagem(os.path.join(h, "EMKT_01.png"), 1)
    docx(os.path.join(h, "CONTEUDO.docx"),
         ["Banner promocional", "Voce ganhou uma oferta especial para credito consignado.",
          "Taxa de 2,99% ao mes em ate 36x.", "Contrate", "Valido ate 01/01/2021."])
    docx(os.path.join(h, "assunto.docx"), ["Assunto: Oferta exclusiva", "Pré-header: Contrate hoje."])
    leituras[h] = {"emkt_01.png": ["Banner promocional", "Oferta"]}

    # G: lote com dois pacotes + um intruso
    g = os.path.join(CASOS, "G_LOTE")
    for nome, extra in (("pac1", "um"), ("pac2", "dois")):
        p = os.path.join(g, nome)
        os.makedirs(p)
        with open(os.path.join(p, "x.html"), "w", encoding="utf-8") as fh:
            fh.write(HTML_PERFEITO.replace("oferta", extra))
        imagem(os.path.join(p, "EMKT_01.png"), 1)
        docx(os.path.join(p, "CONTEUDO.docx"), ["Banner", f"Simule sua {extra} agora.", "Quero",
                                                 "Atendimento: 4002 0022."])
        leituras[p] = {"emkt_01.png": ["Banner"]}
    os.makedirs(os.path.join(g, "vazia"))
    open(os.path.join(g, "vazia", "nota.txt"), "w").write("x")
    return leituras


# ---------------------------------------------------------------- serialização

def ser(v):
    if dataclasses.is_dataclass(v) and not isinstance(v, type):
        out = {f.name: ser(getattr(v, f.name)) for f in dataclasses.fields(v)}
        if hasattr(type(v), "status") and isinstance(getattr(type(v), "status"), property):
            out["__status"] = v.status
        if hasattr(type(v), "aprovado") and isinstance(getattr(type(v), "aprovado"), property):
            out["__aprovado"] = v.aprovado
        if hasattr(type(v), "gravidade") and isinstance(getattr(type(v), "gravidade"), property):
            out["__gravidade"] = v.gravidade
        return out
    if isinstance(v, dict):
        return {str(k): ser(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [ser(x) for x in v]
    if isinstance(v, (set, frozenset)):
        return sorted(ser(x) for x in v)
    return v


class FakeDT(datetime.datetime):
    @classmethod
    def now(cls, tz=None):
        return cls(2026, 11, 13, 10, 5)


def motor(leituras_do_pacote):
    class MotorDeTeste(ocr.MotorBase):
        nome = "motor-de-teste"
        descricao = "Motor de teste (texto combinado por arquivo)"

        def disponivel(self):
            return True, "ok"

        def ler(self, caminho, idioma, confianca_minima):
            nome = os.path.basename(caminho)
            linhas = list(leituras_do_pacote.get(nome.lower(), []))
            return ocr.ResultadoOCR(arquivo=nome, texto=ocr.limpar("\n".join(linhas)), lido=True,
                                    linhas=linhas, motor=self.nome, confianca_media=99.0)
    return MotorDeTeste()


def rodar(pasta, leituras, usar_ocr=True, quebra=None):
    ocr._ESCOLHIDO = motor(leituras.get(pasta, {})) if usar_ocr else motor({})
    ocr.PASTA_CACHE = tempfile.mkdtemp(prefix="cache_py_")
    try:
        r = pacote.validar(pasta, quebra=quebra, usar_ocr=usar_ocr)
    finally:
        shutil.rmtree(ocr.PASTA_CACHE, ignore_errors=True)
    saida = relatorio.__dict__
    relatorio.datetime = FakeDT
    arq = os.path.join(RAIZ, "relatorios_py", os.path.basename(pasta) + ".html")
    relatorio.gerar(r, arq)
    return {
        "status": r.status,
        "resultado": ser(r),
        "json": serializacao.para_json(r, "ID1"),
        "html": open(arq, encoding="utf-8").read(),
    }


def main():
    leituras = montar()
    saida = {"casos": {}}
    for nome in sorted(os.listdir(CASOS)):
        pasta = os.path.join(CASOS, nome)
        if nome.startswith("G_"):
            continue
        quebra = "EMKT" if nome.startswith("A_") else None
        saida["casos"][nome] = rodar(pasta, leituras, True, quebra)
    # sem OCR
    for nome in ("A_ACAO_01_VAL_ATE_03.27", "B_PERFEITO"):
        saida["casos"][nome + "|sem_ocr"] = rodar(os.path.join(CASOS, nome), leituras, False, None)
    # localizar / lote
    g = os.path.join(CASOS, "G_LOTE")
    saida["localizar"] = {
        "G_LOTE": pacote.localizar_pacotes(g),
        "A": pacote.localizar_pacotes(os.path.join(CASOS, "A_ACAO_01_VAL_ATE_03.27")),
        "inexistente": pacote.localizar_pacotes(os.path.join(CASOS, "nada")),
        "G_vazia": pacote.localizar_pacotes(os.path.join(g, "vazia")),
    }
    lote = []
    for p in pacote.localizar_pacotes(g):
        lote.append(rodar(p, leituras, True, None)["json"])
    saida["lote"] = lote
    saida["docx"] = {}
    for nome in ("A_ACAO_01_VAL_ATE_03.27", "B_PERFEITO", "E_DOCX_RUIM"):
        docs = docx_parser.localizar_docx(os.path.join(CASOS, nome))
        saida["docx"][nome] = {
            "localizar": docs,
            "leituras": [ser(docx_parser.ler_docx(d)) for d in docs],
            "papeis": [ser(x) for x in docx_parser.identificar_papeis(docs)],
        }
    # funções puras do docx_parser / html_parser
    linhas = ["Assunto: Olá", "Pre header - Teste", "Prehead Outro", "Título", "Só texto", "Assunto", "Seu assunto aqui",
              "Subject: Hello", "Pré-header", "x: y", "Preview text: abc", "Pre-chamada Algo"]
    saida["rotulos"] = [list(docx_parser._identificar_rotulo(l)) for l in linhas]
    saida["separar"] = [list(docx_parser._separar_assunto(x)) for x in (
        linhas, ["a", "b", "c"], ["Assunto", "Linha A", "Pré-header", "Linha B"], [])]
    saida["ruido"] = [html_parser.e_ruido_de_cliente(t, w) for t in (
        "Baixar", "De: fulano", "Assunto: x", "3 anexos", "Fazer o download", "Oferta", "Enviado do meu Android")
        for w in (False, True)]
    saida["nomes_url"] = [html_parser._nome_arquivo_da_url(u) for u in (
        "a/b/c.png?x=1", "http://x.com/p%20q/R%C3%A9.png#f", "data:image/png;base64,AA", "", "  img/x.gif ",
        "//cdn/x.jpg;v=1", "pasta/")]
    saida["emails"] = {
        "validade": [serializacao.validade_da_pasta(n) for n in (
            "A_VAL_ATE_3.27", "x val-ate-11/2027", "sem", "VAL ATÉ 03.2026", "")],
        "saudacao": [serializacao.saudacao_do_horario(datetime.datetime(2026, 1, 1, h)) for h in (0, 11, 12, 17, 18, 23)],
        "render": serializacao.renderizar_email(serializacao.MODELO_AJUSTES, "Ana", "a@b.c", "VAL_ATE_03.27", "ACAO",
                                                datetime.datetime(2026, 1, 1, 9)),
    }
    json.dump(saida, open(os.path.join(RAIZ, "_python.json"), "w", encoding="utf-8"),
              ensure_ascii=False, default=str)


main()
