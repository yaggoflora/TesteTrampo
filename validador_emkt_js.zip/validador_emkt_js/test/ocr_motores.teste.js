'use strict';
// Seleção de motor, avisos e instalador de idioma (servidor HTTP local), sem depender do Python.
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const ocr = require('../src/validador/ocr');

(async () => {
  // motor forçado inexistente / indisponível
  ocr.forcar_motor('nada');
  assert.strictEqual(ocr.motor_ativo().nome, 'tesseract');
  assert.match(ocr.aviso_de_escolha(), /não existe/);
  ocr.forcar_motor('windows');
  assert.strictEqual(ocr.motor_ativo().nome, 'tesseract');
  assert.match(ocr.aviso_de_escolha(), /não está disponível \(só funciona no Windows\)/);
  assert.match(ocr.ocr_disponivel()[1], /Usando Tesseract\./);
  ocr.forcar_motor('');
  assert.strictEqual(ocr.motor_ativo().nome, 'tesseract');
  assert.strictEqual(ocr.aviso_de_escolha(), '');
  console.log('ok  escolha e forçar motor');

  // aviso de idioma: Tesseract sem "por"
  class SemPortugues extends ocr.MotorTesseract { idiomas() { return ['eng']; } }
  const guard = ocr._ESCOLHIDO;
  ocr._ESCOLHIDO = new SemPortugues();
  assert.ok(ocr.aviso_de_idioma().includes(ocr.COMANDO_IDIOMA_POR));
  ocr._ESCOLHIDO = guard;
  assert.strictEqual(ocr.aviso_de_idioma(), '');
  console.log('ok  aviso de idioma');

  // instalador com espelho local
  const grande = Buffer.alloc(300000, 7);
  const srv = http.createServer((req, res) => {
    if (req.url === '/redir/por.traineddata') { res.writeHead(302, { Location: '/ok/por.traineddata' }); res.end(); return; }
    if (req.url.startsWith('/ok/')) { res.writeHead(200); res.end(grande); return; }
    if (req.url.startsWith('/pequeno/')) { res.writeHead(200); res.end('x'); return; }
    res.writeHead(404); res.end();
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${srv.address().port}`;
  const msgs = [];
  const d1 = fs.mkdtempSync(path.join(os.tmpdir(), 'tess_'));
  assert.strictEqual(await ocr.instalar_idioma_por((m) => msgs.push(m), d1, base + '/ok'), true);
  assert.ok(fs.existsSync(path.join(d1, 'por.traineddata')) && fs.existsSync(path.join(d1, 'eng.traineddata')));
  const d2 = fs.mkdtempSync(path.join(os.tmpdir(), 'tess_'));
  assert.strictEqual(await ocr.instalar_idioma_por(() => {}, d2, base + '/redir'.replace('/redir', '/redir'), 1), false); // eng não tem redirecionamento: 404
  const d3 = fs.mkdtempSync(path.join(os.tmpdir(), 'tess_'));
  const m3 = [];
  assert.strictEqual(await ocr.instalar_idioma_por((m) => m3.push(m), d3, base + '/pequeno'), false);
  assert.ok(m3.some((m) => /pequeno demais/.test(m)));
  assert.ok(!fs.readdirSync(d3).some((n) => n.endsWith('.parte')));
  srv.close();
  console.log('ok  instalar_idioma_por (download, tamanho mínimo, sem sobra .parte)');
})();
