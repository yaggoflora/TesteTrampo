'use strict';
// Teste diferencial do clone do BeautifulSoup (src/lib/pyhtml.js) contra o bs4 do Python.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { BeautifulSoup, Tag, Comment } = require('../src/lib/pyhtml');

const SELETORES = [
  'div[class*="a3s"], div.WordSection1, div[class*="ii gt"]', 'a', 'td', 'table td', 'table > tr', 'tr > td', 'div.a', 'div.a.b',
  '.b', '#x', 'a[href]', 'a[href^="http"]', 'a[href$=".br"]', 'img[alt=""]', 'img[width="600"]', 'p + p', 'p ~ p', 'li:first-child',
  'li:last-child', 'li:nth-child(2)', 'li:nth-child(odd)', 'li:nth-of-type(2n+1)', 'td:not([width])', 'div:empty',
  'p:contains("x")', 'td:has(img)', 'td:has(> a)', '[class~="b"]', '[lang|="pt"]', 'IMG', '*', 'span[style*="display:none"]',
  'body > table:first-of-type td:last-child', 'a:is(.a, .b)', 'input[TYPE="HIDDEN"]', 'div[class="a b"]',
];

const BASE = [
  '<!DOCTYPE html>\n<html lang="pt-BR"><head><meta charset="utf-8"><title>Peça de teste &amp; mais</title></head><body>\n' +
  '<div style="display:none;max-height:0;overflow:hidden">Taxas reduzidas só hoje.</div>\n' +
  '<table role="presentation" width="600"><tr><td><a href="%%=RedirectTo(@link0)=%%"><img src="imagens/briefing_01.png" alt="" width="600" style="display:block"></a></td></tr>\n' +
  '<tr><td>Olá, aproveite esta oferta exclusiva.</td></tr><tr><td class="a b">CDB&sup1; &#185; &#x00B2; &nbsp;&copy; 36x²</td></tr></table></body></html>',
  '<div class="WordSection1"><p class=MsoNormal>Texto <b>negrito</b><o:p></o:p></p><p>Outro<br>com quebra<br/>e outra</p></div>' +
  '<!--[if mso]><table><tr><td><![endif]--><span>dentro</span><!--[if mso]></td></tr></table><![endif]-->',
  '<ul><li>um<li>dois<li>três</ul><p>a<p>b</p></p></p><div>solto</div></span>',
  '<script>if (a < b && c > d) { document.write("<p>x</p>"); }</script><style>td > a { color: red } /* </p> */</style><p>ok</p>',
  '<TABLE WIDTH="100%"><TR><TD ALIGN=center BGCOLOR=#fff>MAIÚSCULAS &amp; "aspas" &quot;x&quot;</TD></TR></TABLE>',
  '<a href="http://x.com/?a=1&b=2&amp;c=3&copy=4&lt;" rel="noopener noreferrer" class="  a   b  ">link</a>',
  '<input type=hidden value=\'a"b\' disabled><img src=x.png alt=y><IMG SRC="Y.PNG"/><input type="HIDDEN">',
  '<textarea>  <b>não é tag</b> &amp; \n\n </textarea><pre>  \n  linha\n   </pre><title>a &lt;b&gt; <i>c</title>',
  '<div>   </div><div>\n\n</div><div> \t </div><span> </span><p>a</p>\n\n<p>b</p>',
  '<![CDATA[x < y]]><?php echo 1 ?><!-- c1 --><!---->< p>texto<!-- sem fim',
  '<p>fim sem fechar <b>negrito <i>itálico',
  '<div class="ii gt"><div class="a3s aXjCH">msg <blockquote>cit</blockquote></div></div>',
  '<p>1 &lt; 2 &amp&amp; 3 &#65 &#x41; &#0; &#128; &#xD800; &#1114112; &bogus; &amp &#x', 
  '<p a=1 a=2 b c="3" d=\'4\' e = "5" f=>x</p><br/><br /><br></br><br>',
  '<a href=x>1</a></a><b>2</b></i></p>3',
  '<template><p>t</p><!--c--></template><rt>r</rt><rp>(</rp><script>&amp;</script>',
  '<svg><image href="a.png"/><path d="M0"/></svg><center><font color="red">x</font></center>',
  '<p>emoji 😀 e acentos áéíóú ç ñ <b>😀</b></p>',
  '',
  ' ',
  '<',
  '<>',
  '</>',
  '</ x>',
  '<a',
  '<a href="x',
  '<!DOCTYPE',
  '<!doctype html',
  '<!x>texto',
  '&',
  '&#',
  'só texto',
  '<p/>',
  '<script/>x</script>',
  '<style>a{}</style',
  '<title>a</title',
  '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><meta charset=latin1>',
  '<table><tr><td>a<td>b<tr><td>c</table>',
  '<div\n  class="x"\n  id=y\n>t</div\n>',
  '<a href="a" / >x</a><a href=a/b>y</a><a href=a/>z</a>',
  '<p title="a&amp;b&nbsp;c &notit; &amp= &#65;">x</p>',
  '<ul>\n  <li>1</li>\n  <li>2</li>\n</ul>',
  '<td width="600"><img width="600"></td><td><img></td>',
];

function mutar(base, rnd) {
  let s = base;
  const n = 1 + Math.floor(rnd() * 4);
  const trechos = ['<', '>', '/', '"', "'", '&', '&#', '<!--', '-->', '<![CDATA[', ']]>', '<p>', '</p>', '<br>', '<script>', '</script>',
    '=', ' ', '\n', '<a href=', '&amp;', '<!', '<?', '</', '<textarea>', '</textarea>', '<title>', '--!>', '<td>', '</td>'];
  for (let k = 0; k < n; k++) {
    const pos = Math.floor(rnd() * (s.length + 1));
    const tipo = Math.floor(rnd() * 4);
    if (tipo === 0) s = s.slice(0, pos) + trechos[Math.floor(rnd() * trechos.length)] + s.slice(pos);
    else if (tipo === 1) s = s.slice(0, pos) + s.slice(pos + 1 + Math.floor(rnd() * 5));
    else if (tipo === 2) s = s.slice(0, pos);
    else s = s.slice(0, pos) + s.slice(Math.floor(rnd() * (s.length + 1)));
  }
  return s;
}

function dump(n) {
  if (n instanceof Tag) {
    return { t: 'Tag', n: n.name, a: [...n.attrs.keys()].map((k) => [k, n.get(k)]).map(([k, v]) => [k, Array.isArray(v) ? v.slice() : String(v)]), c: n.contents.map(dump) };
  }
  return { t: n.constructor.name, v: n.valor };
}

function rodaJs(doc) {
  const r = {};
  try {
    const soup = new BeautifulSoup(doc, 'html.parser');
    r.tree = dump(soup);
    r.str = soup.decode();
    r.text = soup.get_text();
    r.text_strip = soup.get_text(' ', true);
    const desc = soup.descendants;
    const pos = new Map(desc.map((d, i) => [d, i]));
    r.desc_types = desc.map((d) => d.constructor.name);
    r.find_a = soup.find_all('a').map((t) => pos.get(t));
    r.find_true = soup.find_all(true).map((t) => pos.get(t));
    r.find_img_attr = soup.find_all(['img', 'td'], { attrs: { width: true } }).map((t) => pos.get(t));
    r.comments = soup.find_all({ string: (s) => s instanceof Comment }).map((t) => pos.get(t));
    r.sel = {};
    for (const s of SELETORES) r.sel[s] = soup.select(s).map((t) => pos.get(t));
    r.tagtext = soup.find_all(['p', 'div', 'td', 'title', 'script', 'style']).map((t) => [t.name, t.get_text(), t.string === null ? null : String(t.string)]);
    r.strs = soup.find_all(true).map((t) => t.get('style') || '').slice(0, 50);
    for (const c of soup.find_all({ string: (s) => s instanceof Comment })) c.extract();
    r.pos_extract = soup.descendants.map((d) => d.constructor.name + ':' + (d instanceof Tag ? d.name : String(d)));
    r.str2 = soup.decode();
  } catch (e) {
    return { erro: e.constructor.name, msg: e.message };
  }
  return r;
}

// gerador pseudoaleatório determinístico
let semente = Number(process.env.SEMENTE || 12345);
const rnd = () => { semente = (semente * 1664525 + 1013904223) >>> 0; return semente / 4294967296; };

const docs = [...BASE];
// fixtures reais de e-mail (se existirem na pasta de testes) e as do script único
const extra = path.join(__dirname, 'fixtures_html');
if (fs.existsSync(extra)) for (const f of fs.readdirSync(extra)) docs.push(fs.readFileSync(path.join(extra, f), 'utf8'));
const N = Number(process.env.N_FUZZ || 3000);
const reais = docs.slice();
for (let i = 0; i < N; i++) docs.push(mutar(reais[Math.floor(rnd() * reais.length)], rnd).toWellFormed());

const oraculo = JSON.parse(execFileSync('python3', ['-I', path.join(__dirname, '_oraculo_pyhtml.py')], {
  input: JSON.stringify({ docs, seletores: SELETORES }), maxBuffer: 1 << 29,
}).toString());

let falhas = 0; let erros = 0;
docs.forEach((doc, i) => {
  const esp = oraculo[i];
  const obt = rodaJs(doc);
  if (esp.erro) { erros++; if (!obt.erro) { falhas++; if (falhas <= 5) console.log('Python deu erro e JS não:', JSON.stringify(doc).slice(0, 200)); } return; }
  try {
    assert.deepStrictEqual(JSON.parse(JSON.stringify(obt)), esp);
  } catch (e) {
    falhas++;
    if (falhas <= 5) {
      const chaves = Object.keys(esp).filter((k) => JSON.stringify(esp[k]) !== JSON.stringify(JSON.parse(JSON.stringify(obt))[k]));
      console.log('DIFERENÇA no doc', i, JSON.stringify(doc).slice(0, 300), 'campos:', chaves.join(','));
      for (const k of chaves.slice(0, 2)) {
        console.log(' esperado', k, JSON.stringify(esp[k]).slice(0, 500));
        console.log(' obtido  ', k, JSON.stringify(obt[k]).slice(0, 500));
      }
    }
  }
});
console.log(`pyhtml: ${docs.length - falhas - erros}/${docs.length - erros} documentos idênticos ao bs4 (${erros} rejeitados pelo Python)`);
process.exit(falhas ? 1 : 0);
