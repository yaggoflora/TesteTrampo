'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Readable } = require('stream');
const { lerMultipart } = require('../src/lib/multipart');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp_'));
  const b = '----X' + 'a'.repeat(20);
  const conteudo = Buffer.concat([Buffer.from('linha\r\n--' + b.slice(0, 10) + 'quase\r\n'), Buffer.alloc(70000, 7), Buffer.from('\r\n--')]);
  const corpo = Buffer.concat([
    Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="usar_ocr"\r\n\r\ntrue\r\n`),
    Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="arquivos"; filename="Pasta/áção \\"x\\".bin"\r\nContent-Type: application/octet-stream\r\n\r\n`),
    conteudo,
    Buffer.from(`\r\n--${b}\r\nContent-Disposition: form-data; name="arquivos"; filename="Pasta/vazio.txt"\r\n\r\n\r\n--${b}--\r\n`),
  ]);
  for (const passo of [1, 7, 1000, corpo.length]) {
    const chunks = []; for (let i = 0; i < corpo.length; i += passo) chunks.push(corpo.subarray(i, i + passo));
    const req = Readable.from(chunks); req.headers = { 'content-type': `multipart/form-data; boundary=${b}` };
    let n = 0;
    const r = await lerMultipart(req, { destinoDoArquivo: (c, nome) => path.join(dir, 'f' + (n++)) });
    assert.strictEqual(r.campos.usar_ocr, 'true');
    assert.strictEqual(r.arquivos.length, 2);
    assert.strictEqual(r.arquivos[0].nome, 'Pasta/áção "x".bin');
    assert.ok(fs.readFileSync(r.arquivos[0].caminho).equals(conteudo), 'conteúdo, passo ' + passo);
    assert.strictEqual(fs.readFileSync(r.arquivos[1].caminho).length, 0);
  }
  await assert.rejects(lerMultipart(Object.assign(Readable.from([Buffer.alloc(100)]), { headers: { 'content-type': `multipart/form-data; boundary=${b}` } }), { limite: 10 }), /limite/);
  fs.rmSync(dir, { recursive: true, force: true });
  console.log('multipart OK');
})().catch((e) => { console.error(e); process.exit(1); });
