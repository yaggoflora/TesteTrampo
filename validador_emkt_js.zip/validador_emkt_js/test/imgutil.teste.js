'use strict';
// Compara src/lib/imgutil.js com o Pillow (oráculo Python). Precisa do sharp (NODE_PATH).
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { execFileSync } = require('child_process');
const I = require('../src/lib/imgutil');
const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'imgutil_'));
execFileSync('python3', [path.join(__dirname, '_oraculo_imgutil.py'), pasta]);
const meta = JSON.parse(fs.readFileSync(path.join(pasta, 'meta.json')));

(async () => {
  const falhas = [];
  const comparar = async (rotulo, obtido, arquivo, tolerancia = 0) => {
    const esperado = await I.abrir(path.join(pasta, arquivo));
    const o = obtido.canais === 1 ? I.paraRgb(obtido) : obtido;
    if (esperado.width !== o.width || esperado.height !== o.height) { falhas.push(`${rotulo}: tamanho ${o.width}x${o.height} != ${esperado.width}x${esperado.height}`); return; }
    let maior = 0, difs = 0;
    for (let i = 0; i < o.data.length; i++) { const d = Math.abs(o.data[i] - esperado.data[i]); if (d) difs++; if (d > maior) maior = d; }
    const ok = maior <= tolerancia;
    console.log(`${ok ? 'ok ' : 'XX '} ${rotulo.padEnd(34)} difs=${difs}/${o.data.length} maior=${maior}`);
    if (!ok) falhas.push(`${rotulo}: maior diferença ${maior} > ${tolerancia}`);
  };
  for (const nome of ['ruido', 'gradiente', 'texto', 'baixo_contraste']) {
    const im = await I.abrir(path.join(pasta, nome + '.png'));
    const { width: w, height: h } = im;
    await comparar(`${nome}/lanczos_up`, I.redimensionar(im, Math.trunc(w * 1.7), Math.trunc(h * 2.3), 'LANCZOS'), `${nome}__lanczos_up.png`);
    await comparar(`${nome}/lanczos_down`, I.redimensionar(im, Math.max(1, Math.floor(w / 3)), Math.max(1, Math.floor(h / 2)), 'LANCZOS'), `${nome}__lanczos_down.png`);
    await comparar(`${nome}/bilinear64`, I.redimensionar(I.paraRgb(I.cinza(im)), 64, 64, 'BILINEAR'), `${nome}__bilinear64.png`);
    await comparar(`${nome}/cinza`, I.cinza(im), `${nome}__cinza.png`);
    await comparar(`${nome}/inverter`, I.inverter(im), `${nome}__inverter.png`);
    await comparar(`${nome}/autocontraste0`, I.autocontraste(I.cinza(im)), `${nome}__autocontraste0.png`);
    await comparar(`${nome}/autocontraste1`, I.autocontraste(im, 1), `${nome}__autocontraste1.png`);
    await comparar(`${nome}/contraste1.6`, I.contraste(im, 1.6), `${nome}__contraste16.png`);
    await comparar(`${nome}/recorte`, I.recortar(im, 3, 2, w - 4, h - 1), `${nome}__recorte.png`);
    await comparar(`${nome}/nitidez (aproximada)`, I.nitidez(im, 2, 140, 3), `${nome}__nitidez.png`, 255);
    assert.ok(Math.abs(I.luminanciaMedia(im) - meta[nome].lum) < 1e-9, 'luminância ' + nome);
  }
  for (const [arq, esperado] of [['dim.jpg', [123, 45]], ['dim.webp', [123, 45]], ['dim.bmp', [123, 45]], ['dim.gif', [123, 45]], ['texto.png', [300, 80]]]) {
    assert.deepStrictEqual(I.dimensoes(path.join(pasta, arq)), esperado, 'dimensões ' + arq);
  }
  assert.strictEqual(I.numFramesGif(path.join(pasta, 'anim.gif')), 3);
  assert.strictEqual(I.numFramesGif(path.join(pasta, 'dim.gif')), 1);
  assert.strictEqual(await I.contarPaginas(path.join(pasta, 'anim.gif')), 3);
  const f1 = await I.abrirFrame(path.join(pasta, 'anim.gif'), 1);
  assert.strictEqual(f1.data[0], 0, 'frame 1 deveria ser preto');
  fs.rmSync(pasta, { recursive: true, force: true });
  if (falhas.length) { console.error('FALHAS:\n' + falhas.join('\n')); process.exit(1); }
  console.log('imgutil OK');
})();
