'use strict';
const assert = require('assert');
const { execFileSync } = require('child_process');
const u = require('../src/lib/pyutil');
// compara com o Python em muitos valores
const casos = [];
for (const x of [0.5, 1.5, 2.5, 0.125, 0.375, 2.675, 1.005, 0.15, 0.25, 79.95, 1234.5678, -0.5, -1.5, -2.675, 0, 1e-7, 123456.785, 0.045, 99.95, 85.25, 33.333333333333336]) for (const n of [0, 1, 2, 3]) casos.push([x, n]);
for (let i = 0; i < 300; i++) casos.push([Math.round(Math.random() * 1e5) / 1000 + (i % 7) / 8, i % 4]);
const py = execFileSync('python3', ['-c', `
import json,sys
c=json.loads(sys.stdin.read())
print(json.dumps([[format(x,'.%df'%n), round(x,n)] for x,n in c]))`], { input: JSON.stringify(casos) }).toString();
const esperado = JSON.parse(py);
casos.forEach(([x, n], i) => {
  assert.strictEqual(u.fmtFixed(x, n), esperado[i][0], `fmtFixed(${x},${n})`);
  assert.strictEqual(u.pyRound(x, n), esperado[i][1], `pyRound(${x},${n})`);
});
assert.deepStrictEqual(u.split('  a\tb\n c '), ['a', 'b', 'c']);
assert.deepStrictEqual(u.sorted([[2, 'a'], [1, 'b'], [1, 'a']], (x) => x), [[1, 'a'], [1, 'b'], [2, 'a']]);
assert.strictEqual(u.categoria('é'), 'Ll'); assert.strictEqual(u.categoria('́'), 'Mn');
console.log('pyutil OK (' + casos.length + ' casos contra o Python)');
