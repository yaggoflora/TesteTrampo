'use strict';
/*
 * Teste diferencial da frente C: normalizacao, excecoes, regras, correcao_ocr,
 * ordenacao, layout, comparador, presenca. Cada caso roda no Python original
 * (oráculo) e no JS; o JSON dos resultados tem de ser idêntico.
 *   node test/comparacao.teste.js
 */
const path = require('path');
const { execFileSync } = require('child_process');

const REF = process.env.VALIDADOR_REF
  || '/tmp/claude-0/-home-claude/eb36be0e-6bcb-5b08-a75c-97a697a03e9e/scratchpad/src/validador_emkt';
const V = path.join(__dirname, '..', 'src', 'validador');
const MODS = {};
for (const m of ['comparador', 'correcao_ocr', 'excecoes', 'layout', 'normalizacao', 'ordenacao', 'presenca', 'regras']) {
  MODS[m] = require(path.join(V, m));
}

// ---------- gerador pseudoaleatório determinístico
function rng(semente) {
  let a = semente >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = rng(Number(process.env.SEMENTE || 12345));
const sorteia = (l) => l[Math.floor(rand() * l.length)];
const inteiro = (a, b) => a + Math.floor(rand() * (b - a + 1));

// ---------- corpus
const FRASES = [
  'Olá, Maria! Seu crédito de R$ 50.000,00 está liberado — simule agora.',
  'CDB¹ rende 12,5% a.a.² com liquidez diária',
  '“Aspas curvas” e ‘simples’ também contam',
  'Cartões Digitais:',
  'café|bar ¦ teste',
  'Preço: R$50,00 em 36x sem juros',
  'Promoção 🎉 de verão 🌞 só hoje',
  'Acompanhe o Bradesco nas Redes Sociais!',
  'Se não conseguir visualizar este e-mail, clique aqui para visualizar',
  '[Simular crédito]',
  '(texto entre parênteses)',
  'SemconsultaaoSPCeSerasa',
  'ate l dia útil',
  'İstanbul ΣΊΣΥΦΟΣ straße ǅ',
  '  múltiplos   espaços\t\ttabs\n\n\nlinhas  ',
  'zero​width e﻿bom e­virtual e nbsp',
  'Consulte as condições no regulamento. CNPJ 60.746.948/0001-12',
  'Para deixar de receber, clique em descadastrar.',
  'Fale conosco: Ouvidoria 0800 727 9933 · SAC 0800 704 8383',
  'Válido até 30/11/2026 ou 5 de dezembro de 2026',
  'Taxa de juros de 1,99% a.m. CET de 25,3% a.a.',
  'Oferta sujeita à análise de crédito.',
  'Esta mensagem foi gerada automaticamente e não pode ser respondida.',
  'a0 mes e 1000 reais b8 s5 l1',
  '50% de desconto',
  'Visite www.bradesco.com.br ou contato@bradesco.com.br agora',
  '', ' ', '\n', 'x', 'é', '...', '¿Qué?', 'Ação e Reação: São João',
  'Mesmo-texto com—hífens e – travessões',
  'ǆ ﬁ ﬃ Å Å',
];

const ARGS_TEXTO = FRASES;

// ---------- encode / decode para o oráculo e para o JS
const CAMPOS_BLOCO = {
  tipo: 'texto', conteudo: '', referencia: '', alt: '', origem: '', oculto: false, bruto: '', tem_link: false,
  textos_de_link: [], remota: false, ocr_lido: false, ocr_confianca: 0.0, ocr_erro: '', ocr_aviso: '',
  reordenado: false, classificacao: '',
};
function bloco(o) {
  const b = { ...CAMPOS_BLOCO, textos_de_link: [] };
  Object.assign(b, o);
  return b;
}
const fita = (blocos) => ({ $fita: blocos.map(bloco) });

function decodificar(v) {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    if ('$set' in v) return new Set(v.$set);
    if ('$fita' in v) return v.$fita.map((b) => ({ ...b, textos_de_link: [...b.textos_de_link] }));
    if ('$data' in v) return { ano: v.$data[0], mes: v.$data[1], dia: v.$data[2] };
    if ('$assunto' in v) {
      const a = v.$assunto;
      return { pre_header: a.pre_header, texto_oculto: a.texto_oculto || [], fita: (a.fita || []).map(bloco) };
    }
    const o = {};
    for (const [k, x] of Object.entries(v)) o[k] = decodificar(x);
    return o;
  }
  if (Array.isArray(v)) return v.map(decodificar);
  return v;
}

const EXTRAS = ['gravidade', 'status', 'aprovado', 'texto'];
function serializar(v) {
  if (v instanceof Set) return [...v].map(serializar).sort();
  if (Array.isArray(v)) return v.map(serializar);
  if (v && typeof v === 'object') {
    const ctor = v.constructor && v.constructor.name;
    const o = {};
    for (const [k, x] of Object.entries(v)) o[k] = serializar(x);
    if (ctor !== 'Object') {
      for (const e of EXTRAS) {
        const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(v), e);
        if (d && d.get) o[e] = serializar(v[e]);
      }
    }
    return o;
  }
  return v;
}

function rodarJS(caso) {
  const [mod, nome] = caso.fn.split('.');
  const fn = MODS[mod][nome];
  let args = (caso.args || []).map(decodificar);
  const kw = {};
  for (const [k, a] of Object.entries(caso.kw || {})) kw[k] = decodificar(a);
  if (nome === 'comparar_assunto') { const a = decodificar(caso.args[0]); args = [a, a]; }
  // palavras nomeadas: só `hoje` e `janela_contexto` são usadas
  if ('hoje' in kw) args.push(kw.hoje);
  if ('janela_contexto' in kw) args.push(kw.janela_contexto);
  let saida;
  try {
    saida = { ok: serializar(fn(...args)) };
  } catch (e) {
    saida = { erro: e.constructor.name + ':' + e.message };
  }
  for (const a of args) {
    if (Array.isArray(a) && a.length && a[0] && typeof a[0] === 'object' && 'ocr_lido' in a[0]) saida.fita_depois = a.map((b) => ({ ...b }));
  }
  return saida;
}

// ---------- casos
const casos = [];
const add = (fn, args = [], kw = undefined) => casos.push({ fn, args, ...(kw ? { kw } : {}) });

for (const t of ARGS_TEXTO) {
  add('normalizacao.limpar', [t]);
  add('normalizacao.sem_acento', [t]);
  add('normalizacao.normalizar_sobrescritos', [t]);
  add('normalizacao.tokenizar', [t]);
  add('normalizacao.tokenizar', [t, false]);
  add('normalizacao.tokenizar', [t, true, false]);
  add('normalizacao.tokenizar', [t, false, false]);
  add('normalizacao.tokenizar_pares', [t]);
  add('normalizacao.tokenizar_pares', [t, false]);
  add('normalizacao.texto_para_exibicao', [t]);
  add('excecoes.classificar', [t]);
  add('regras.contar_redirects', [t]);
  add('regras.pre_header_tem_ponto_final', [t]);
  add('regras.excedeu', [t, 10]);
  add('regras.enderecos_sem_protecao', [t]);
  add('regras.datas_vencidas', [t], { hoje: { $data: [2026, 11, 12] } });
  add('correcao_ocr.canonizar', [t]);
}
// classificar: frases dirigidas aos padrões
for (const t of [
  'não conseguiu visualizar', 'Caso não consiga ver o e-mail', 'Visualize no navegador', 'versão online deste e-mail',
  'clique aqui para abrir', 'Abrir esse e-mail', 'ABRIR ESSE  E MAIL', 'Não está vendo?', 'não esta visualizando',
  'descadastre-se', 'Cancelar o recebimento', 'não desejo mais receber', 'opt-out', 'OPT OUT', 'cet', 'CET:',
  'cetim', 'sac', 'SAC,', 'sacola', 'Sacé', 'cetá', 'é cet', 'çcet', 'procon', 'Fale  Conosco', 'siga o Bradesco',
  'curta nas redes', 'FACEBOOK', 'facebooks', 'Instagram!', 'Central de Atendimento', 'deficiente auditivo',
  'Válido até', 'válida para', 'Horário de Brasília', 'Acesso do exterior', 'Remetentes confiáveis',
  'Siga a gente no Instagram e curta nas redes sociais', 'acompanhe', 'mantenha seus dados atualizados',
]) add('excecoes.classificar', [t]);
add('regras.contar_redirects', ['<a href="https://x/redirect?u=1">REDIRECT</a> redir Redir redirecionamento \\bredir\\b']);
add('regras.contar_redirects', ['']);
add('regras.pre_header_tem_ponto_final', ['Aproveite!"']);
add('regras.pre_header_tem_ponto_final', ['Aproveite… »']);
add('regras.pre_header_tem_ponto_final', ['Aproveite!\n']);
add('regras.pre_header_tem_ponto_final', ['Aproveite) ']);
add('regras.pre_header_tem_ponto_final', ['Aproveite.”']);
add('regras.excedeu', ['  abcdefghij 🎉🎉🎉 ', 8]);
add('regras.excedeu', ['abc', 35]);
add('regras.excedeu', [null, 35]);

// endereços com e sem proteção
const FEFF = '﻿';
for (const t of [
  'Acesse bradesco.com.br/promo agora', `Acesse brad${FEFF}esco.com.br agora`, `www.${FEFF}bradesco.com.br/x`,
  'http://exemplo.org/a?b=c. Fim', 'banco.bradesco/algo e www.site.net.', 'fale@bradesco.com.br, ok',
  `mail${'​'}@bradesco.com.br`, 'a.com.br', 'xx.br', 'veja (www.bradesco.com.br) e https://a.b/c;',
  `Visite www.bradesco.com.br ou b${'‍'}radesco.com.br`, 'sem endereço nenhum', 'BRADESCO.COM.BR/ABC',
  'texto 🎉 www.bradesco.com.br 🎉', `🎉 brad${FEFF}esco.com.br`,
]) {
  add('regras.enderecos_sem_protecao', [t]);
}
add('regras._trecho_original', [`ab${FEFF}cd ef`, 'abcd']);
add('regras._trecho_original', ['xyz', 'abc']);
add('regras._trecho_original', [`🎉ab${FEFF}c`, 'abc']);

// datas
for (const hoje of [[2026, 11, 12], [2024, 2, 29], [2026, 1, 1], [2028, 12, 31]]) {
  for (const t of [
    'vale até 10/11/2026 e 05.10.26 e 1-1-2026', '31/02/2026 inválida 29/02/2024 29/02/2025', '5 de outubro de 2026 e 5 DE OUTUBRO DE 2026',
    '1 de março de 2026 / 1 de marco de 2026 / 1 de Março de 2026', '15 de abril de 2020 e 01/01/2000', '32/01/2026 0/1/2026 1/13/2026',
    '10/11/26 10/11/026 10/11/0026 10/11/00', '12/11/2026 11/11/2026 03/05/2026 10/11/2026 10/11/2026',
    '30 de fevereiro de 2026 e 29 de fevereiro de 2024', 'sem datas', '10/11/2026a 10/11/2026é é10/11/2026',
    '1 de janeiro de 0001 31 de dezembro de 2025', '١٠/١١/٢٠٢٦',
  ]) add('regras.datas_vencidas', [t], { hoje: { $data: hoje } });
}

// correcao_ocr
const VOC = ['sem', 'consulta', 'ao', 'spc', 'e', 'serasa', 'ate', 'dia', 'util', 'dinheiro', 'na', 'conta', 'em', 'a', 'mes', 'credito', '50', 'livelo'];
for (const t of [
  'semconsultaaospceserasa', 'dinheironacontaemateldiautil', 'sem', 'xx', 'a0', 'ate', 'at3', 'semconsulta', 'consultaconsultaconsulta',
  'aaaaaaaa', 'livelolivelo', 'lívelo', '!', '|', '5o', 'creditoconta', 'contaconta', '',
]) {
  add('correcao_ocr._segmentar', [t, { $set: VOC }]);
  add('correcao_ocr.tokens_iguais', [t, 'sem']);
}
add('correcao_ocr.corrigir', [['semconsultaaospceserasa', '.', 'dia', 'a', 'xyzxyz', 'u', 'ate', 'l', 'a0', 'mes', 'dinheironacontaemateldiautil'], { $set: VOC }]);
add('correcao_ocr.corrigir', [[], { $set: VOC }]);
add('correcao_ocr.corrigir', [['qualquercoisa'], { $set: [] }]);
add('correcao_ocr.construir_vocabulario', [FRASES]);
add('correcao_ocr.construir_vocabulario', [[]]);

// ordenacao
const DOCX_CARTOES = [
  'Estreias de setembro', '03/09: Minha Melhor Amiga', '24/09: A Ilha Esquecida', '50% de desconto no ingresso', '20% de desconto na pipoca',
  'Compre agora no app do Bradesco',
];
add('ordenacao.alinhar_por_referencia', ['03/09: 24/09:\nMinha Melhor Amiga A Ilha Esquecida\nEstreias de setembro', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['Estreias de setembro\n03/09: Minha Melhor Amiga\n24/09: A Ilha Esquecida', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['20% de desconto na pipoca\n50% de desconto no ingresso', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['de desconto\nde desconto\n50%\n20%', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['Compre agora no app\ntexto inexistente aqui', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['uma linha só', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['a\nb', []]);
add('ordenacao.alinhar_por_referencia', ['', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', [null, DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['Compre agora\nEstreias de setembro\n\n  \nCompre agora no app do Bradesco', DOCX_CARTOES]);
add('ordenacao.alinhar_por_referencia', ['Compre   agora no app do Bradesco Estreias de setembro\rA Ilha Esquecida', DOCX_CARTOES]);
add('ordenacao._posicao_no_docx', [['de', 'desconto'], ['50', 'de', 'desconto', 'no']]);
add('ordenacao._posicao_no_docx', [['x', 'y'], ['50', 'de']]);
add('ordenacao._posicao_no_docx', [['50', 'zzz', 'qqq'], ['50', 'de']]);
add('ordenacao._posicao_no_docx', [[], ['50']]);
add('ordenacao._posicao_exata', [['de', 'desconto'], [['50', 'de', 'desconto'], ['20', 'de', 'desconto']], { $set: [1] }]);
add('ordenacao._posicao_exata', [['de', 'desconto'], [['50', 'de', 'desconto'], ['20', 'de', 'desconto']], { $set: [1, 10001] }]);
add('ordenacao._posicao_exata', [[], [['a']]]);
add('ordenacao._partir_linha', ['03/09: 24/09:', [['03', '09', 'minha'], ['24', '09', 'ilha']], { $set: [] }]);
add('ordenacao._partir_linha', ['(pipoca) “aspas”', [['pipoca', 'aspas']], { $set: [] }]);

// layout: caixas
function caixa(texto, esquerda, topo, largura, altura, conf = 90) {
  return { texto, esquerda, topo, direita: esquerda + largura, base: topo + altura, confianca: conf };
}
const CARTAO = [
  caixa('50%', 20, 40, 120, 60), caixa('de desconto', 20, 110, 150, 24),
  caixa('Item um da lista', 330, 40, 220, 24), caixa('Item dois da lista', 330, 76, 240, 24), caixa('Item três', 330, 112, 140, 24),
  caixa('Estreias de setembro', 20, 220, 300, 30), caixa('03/09:', 20, 270, 70, 22), caixa('24/09:', 400, 270, 70, 22),
  caixa('Minha Melhor Amiga', 20, 300, 200, 22), caixa('A Ilha Esquecida', 400, 300, 190, 22),
];
add('layout.ordenar_por_layout', [CARTAO]);
add('layout.descrever_blocos', [CARTAO]);
add('layout.ordenar_por_layout', [CARTAO.slice(0, 3)]);
add('layout.descrever_blocos', [CARTAO.slice(0, 3)]);
add('layout.ordenar_por_layout', [[...CARTAO, caixa('  ', 1, 1, 1, 1)]]);
add('layout.ordenar_por_layout', [[{ texto: 'a' }, { texto: 'b' }, { texto: 'c' }, { texto: 'd' }]]);
add('layout.descrever_blocos', [[]]);
for (let n = 0; n < 60; n++) {
  const k = inteiro(4, 22);
  const caixas = [];
  for (let i = 0; i < k; i++) {
    const altura = inteiro(8, 40) + (rand() < 0.3 ? 0.5 : 0);
    const largura = inteiro(10, 260) + (rand() < 0.3 ? 0.25 : 0);
    caixas.push(caixa(sorteia(['Texto', 'banco', '50%', 'R$ 10,00', 'de desconto', 'Item', '03/09:', 'ä']) + i,
      inteiro(0, 600) + (rand() < 0.2 ? 0.5 : 0), inteiro(0, 800) + (rand() < 0.2 ? 0.1 : 0), largura, altura, inteiro(30, 99)));
  }
  add('layout.ordenar_por_layout', [caixas]);
  add('layout.descrever_blocos', [caixas]);
}

// ---------- comparar / presenca
const BASE_DOCX = [
  'Olá, Maria!', 'Seu crédito de R$ 50.000,00 está liberado.', 'Taxa de juros de 1,99% a.m. e CET de 25,3% a.a.',
  'Simular crédito', 'Cartões Digitais', 'Livelo', 'Sem consulta ao SPC e Serasa',
  'Dinheiro na conta em até 1 dia útil', '50% de desconto', 'Acompanhe o Bradesco nas Redes Sociais!',
  'Oferta sujeita à análise de crédito.', 'Para deixar de receber, clique em descadastrar.',
  'Fale conosco: Ouvidoria 0800 727 9933', 'CNPJ 60.746.948/0001-12',
];

function fitaDosParagrafos(paragrafos, opcoes = {}) {
  const blocos = [];
  paragrafos.forEach((p, i) => {
    if (i % 4 === 2 && !opcoes.semImagem) {
      blocos.push({ tipo: 'imagem', referencia: `banner_0${i}.png`, conteudo: p.replace(/ /g, opcoes.espacosColados ? '' : ' '), ocr_lido: true, ocr_confianca: 90 });
    } else {
      blocos.push({ tipo: 'texto', conteudo: p });
    }
  });
  return blocos;
}

function classificarBlocos(blocos) {
  const { classificar } = MODS.excecoes;
  return blocos.map((b) => ({ ...b, classificacao: classificar(b.conteudo) }));
}

function mutar(blocos, docx) {
  const b = blocos.map((x) => ({ ...x }));
  const n = inteiro(0, 4);
  for (let i = 0; i < n; i++) {
    const alvo = b[inteiro(0, b.length - 1)];
    const palavras = alvo.conteudo.split(' ');
    switch (inteiro(0, 12)) {
      case 0: palavras.splice(inteiro(0, palavras.length - 1), 1); break; // tira palavra
      case 1: palavras.splice(inteiro(0, palavras.length), 0, sorteia(['extra', 'não', 'Livelo', 'sem', 'rede', 'xyz'])); break;
      case 2: { const j = inteiro(0, palavras.length - 1); palavras[j] = palavras[j].replace(/[ãáâéêíóôõúç]/g, (c) => ({ ã: 'a', á: 'a', â: 'a', é: 'e', ê: 'e', í: 'i', ó: 'o', ô: 'o', õ: 'o', ú: 'u', ç: 'c' }[c])); break; }
      case 3: { const j = inteiro(0, palavras.length - 1); palavras[j] = palavras[j].replace(/[.,:!]/g, ''); break; }
      case 4: { const j = inteiro(0, palavras.length - 1); palavras[j] += sorteia([',', '.', ':', '!', ')']); break; }
      case 5: { const j = inteiro(0, palavras.length - 1); palavras[j] = palavras[j].replace(/\d/, (d) => String((Number(d) + 3) % 10)); break; }
      case 6: { const j = inteiro(0, palavras.length - 1); palavras[j] = palavras[j].replace('o', '0'); break; }
      case 7: palavras.reverse(); break;
      case 8: { const j = inteiro(0, palavras.length - 1); palavras[j] = palavras[j] + palavras[Math.min(j + 1, palavras.length - 1)]; break; }
      case 9: { const j = inteiro(0, palavras.length - 1); palavras.splice(j, 1, ...palavras[j].split('')); break; }
      case 10: palavras.splice(inteiro(0, palavras.length - 1), 0, palavras[0]); break; // repete
      case 11: alvo.tipo === 'imagem' ? (alvo.ocr_lido = rand() < 0.5, alvo.ocr_erro = alvo.ocr_lido ? '' : 'falhou') : null; break;
      case 12: alvo.oculto = rand() < 0.5; break;
      default:
    }
    alvo.conteudo = palavras.join(' ');
  }
  // às vezes troca blocos de lugar
  if (rand() < 0.3 && b.length > 3) { const i = inteiro(0, b.length - 2); [b[i], b[i + 1]] = [b[i + 1], b[i]]; }
  if (rand() < 0.15) b.splice(inteiro(0, b.length - 1), 1);
  if (rand() < 0.15) b.push({ ...b[0] });
  return b;
}

// cenários fixos
const fixos = [
  [classificarBlocos(fitaDosParagrafos(BASE_DOCX)), BASE_DOCX],
  [classificarBlocos(fitaDosParagrafos(BASE_DOCX, { espacosColados: true })), BASE_DOCX],
  [classificarBlocos(fitaDosParagrafos(BASE_DOCX, { semImagem: true })), BASE_DOCX],
  [classificarBlocos([{ tipo: 'texto', conteudo: 'Se não conseguir visualizar este e-mail, clique aqui para visualizar' }, ...fitaDosParagrafos(BASE_DOCX)]), BASE_DOCX],
  [classificarBlocos([{ tipo: 'texto', conteudo: 'Livelo Livelo' }, { tipo: 'texto', conteudo: 'Cartões Digitais:' }, { tipo: 'texto', conteudo: 'só ruído' },
    { tipo: 'imagem', referencia: 'icone.png', conteudo: 'f in o', ocr_lido: true }, { tipo: 'imagem', referencia: 'x.png', conteudo: 'Cartões foo bar baz', ocr_lido: true },
    { tipo: 'texto', conteudo: 'Taxa 36 x e R$50,00 contra R$ 50,00' }]), ['Livelo', 'Cartões Digitais', 'Cartões', 'Taxa 36x e R$ 50,00 contra R$50,00']],
  [[], BASE_DOCX],
  [classificarBlocos(fitaDosParagrafos(BASE_DOCX)), []],
  [[], []],
  [classificarBlocos([{ tipo: 'imagem', referencia: 'a.png', conteudo: '', ocr_lido: false, ocr_erro: 'sem OCR' }, { tipo: 'imagem', referencia: 'a.png', conteudo: '', ocr_lido: false },
    { tipo: 'texto', conteudo: 'Olá Maria' }]), ['Olá, Maria!']],
  [classificarBlocos([{ tipo: 'imagem', referencia: 'b.png', conteudo: 'a0 mes semconsultaaospceserasa 1 !', ocr_lido: true }]), ['Sem consulta ao SPC e Serasa', 'a o mês']],
];
for (const [blocos, docx] of fixos) {
  add('comparador.comparar', [fita(blocos), docx]);
  add('presenca.comparar', [fita(blocos), docx]);
}
// aleatórios
for (let n = 0; n < 250; n++) {
  const docx = BASE_DOCX.filter(() => rand() < 0.85);
  if (rand() < 0.3) docx.splice(inteiro(0, docx.length), 0, sorteia(['Texto novo do redator', 'Livelo Livelo', '[Simular crédito]', '"Cartões" Digitais']));
  const blocos = classificarBlocos(mutar(fitaDosParagrafos(BASE_DOCX, { espacosColados: rand() < 0.2 }), docx));
  add('comparador.comparar', [fita(blocos), docx]);
  add('comparador.comparar', [fita(blocos), docx], { janela_contexto: inteiro(0, 9) });
  add('presenca.comparar', [fita(blocos), docx]);
}
// pré-header
for (const [pre, texto, oculto] of [
  ['Aproveite o crédito liberado agora.', 'Aproveite o crédito', []],
  ['Aproveite o crédito liberado agora.', 'nada a ver', ['Aproveite', 'crédito liberado']],
  ['', 'x', []], ['...', 'x', []], ['Taxa de juros menor', 'Taxa', ['de']],
]) {
  add('comparador.comparar_assunto', [{ $assunto: { pre_header: pre, texto_oculto: oculto, fita: [{ tipo: 'texto', conteudo: texto }] } }]);
}
add('comparador.comparar_assunto', [{ $assunto: { pre_header: '', fita: [] } }]);

// ---------- executa
const oraculo = path.join(__dirname, 'oraculo_comparacao.py');
const bruto = execFileSync('python3', [oraculo], {
  input: JSON.stringify(casos), maxBuffer: 1 << 30,
  env: { ...process.env, VALIDADOR_REF: REF, PYTHONHASHSEED: '0' },
}).toString();
const esperado = JSON.parse(bruto);

function igual(a, b) { return JSON.stringify(ordenaChaves(a)) === JSON.stringify(ordenaChaves(b)); }
function ordenaChaves(v) {
  if (Array.isArray(v)) return v.map(ordenaChaves);
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v).sort()) o[k] = ordenaChaves(v[k]); return o; }
  return v;
}

function caminhosDiferentes(a, b, p = '') {
  if (JSON.stringify(a) === JSON.stringify(b)) return [];
  if (a && b && typeof a === 'object' && typeof b === 'object') {
    const out = [];
    for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) out.push(...caminhosDiferentes(a[k], b[k], p + '.' + k));
    return out;
  }
  return [p + ` (py=${JSON.stringify(a)} js=${JSON.stringify(b)})`.slice(0, 200)];
}
let ordemDeSet = 0;
let falhas = 0;
const porFuncao = {};
casos.forEach((caso, i) => {
  const js = JSON.parse(JSON.stringify(rodarJS(caso)));
  const py = esperado[i];
  porFuncao[caso.fn] = porFuncao[caso.fn] || [0, 0];
  porFuncao[caso.fn][0]++;
  // exceções: só importa que ambos falhem (o nome do erro muda de linguagem)
  const ok = ('erro' in py && 'erro' in js) || igual(js, py);
  if (ok) { porFuncao[caso.fn][1]++; return; }
  // Único desvio aceito: o Python escolhe o rótulo obrigatório pela ordem de um `set`
  // (depende do hash da execução) quando um mesmo trecho casa com mais de um rótulo;
  // o JS usa a ordem de inserção. Só vale se TODA diferença for esse rótulo.
  const difs = caminhosDiferentes(py, js);
  const soRotulo = difs.length > 0 && difs.every((d) => /^\.ok\.divergencias\.\d+\.obrigatorio |^\.ok\.obrigatorios_ausentes\.\d+ /.test(d));
  if (soRotulo && caso.fn === 'comparador.comparar') { porFuncao[caso.fn][1]++; ordemDeSet++; return; }
  falhas++;
  if (falhas <= 8) {
    console.log('\nDIVERGE', caso.fn, JSON.stringify(caso.args).slice(0, 400), JSON.stringify(caso.kw || {}));
    console.log(' py:', JSON.stringify(py).slice(0, 1500));
    console.log(' js:', JSON.stringify(js).slice(0, 1500));
  }
});
for (const [fn, [t, ok]] of Object.entries(porFuncao)) console.log(`${ok === t ? 'OK ' : 'XX '} ${fn}: ${ok}/${t}`);
if (ordemDeSet) console.log(`(${ordemDeSet} caso(s) com mais de um rótulo obrigatório no mesmo trecho: o Python escolhe pela ordem do set, o JS pela inserção)`);
console.log(falhas ? `\n${falhas} caso(s) divergem de ${casos.length}` : `\ncomparacao OK: ${casos.length} casos idênticos ao Python`);
process.exit(falhas ? 1 : 0);
