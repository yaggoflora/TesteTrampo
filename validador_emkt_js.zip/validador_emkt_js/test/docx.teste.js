'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { lerDocx } = require('../src/lib/docxreader');
const { gerarDocx } = require('../src/lib/docxwriter');
const { ZipLeitor, escreverZip } = require('../src/lib/zip');
const { parseXml } = require('../src/lib/xml');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'docxteste-'));
const PY_GERA = `
import sys, json
from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
d = Document()
p = d.add_paragraph(); p.add_run("Assunto: Seu crédito está liberado ")
r = p.add_run("18x"); r.font.superscript = True
p.add_run("1").font.superscript = True
p = d.add_paragraph("linha um"); p.add_run().add_break(); p.add_run("linha dois\\ttab")
p = d.add_paragraph("Pré-header: ‘aspas’ — emoji 😀 e nbsp\\u00a0aqui")
rel = d.part.relate_to("https://exemplo.com/a?b=1&c=2", RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
p = d.add_paragraph("antes ")
h = OxmlElement("w:hyperlink"); h.set(qn("r:id"), rel); rr = OxmlElement("w:r"); t = OxmlElement("w:t"); t.text = "Clique aqui"; rr.append(t); h.append(rr); p._p.append(h)
p.add_run(" depois")
d.add_paragraph("")
d.add_paragraph("   espaços   ")
t = d.add_table(rows=3, cols=3)
t.cell(0,0).text = "A1"; t.cell(0,1).text = "B1\\nsegunda linha"; t.cell(0,2).text = "C1"
t.cell(1,0).text = "A2"; t.cell(1,1).text = "B2"; t.cell(1,2).text = "C2"
t.cell(2,0).text = "A3"; t.cell(2,1).text = "B3"; t.cell(2,2).text = "C3"
t.cell(0,0).merge(t.cell(0,1))
t.cell(1,2).merge(t.cell(2,2))
t2 = d.add_table(rows=1, cols=1); t2.cell(0,0).text = "outra tabela"
t2.cell(0,0).add_paragraph("segundo parágrafo da célula")
d.add_paragraph("fim")
d.save(sys.argv[1])
`;
const PY_LE = `
import sys, json
from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as TIPO
d = Document(sys.argv[1])
ns="{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
out = {"paragraphs":[p.text for p in d.paragraphs],
       "tables":[[[c.text for c in row.cells] for row in t.rows] for t in d.tables],
       "hyperlinks":[str(r.target_ref) for r in d.part.rels.values() if r.reltype==TIPO.HYPERLINK],
       "hyperlinkTexts":[x for x in ("".join(n.text or "" for n in l.iter(ns+"t")).strip() for l in d.element.body.iter(ns+"hyperlink")) if x],
       "partes":[[ (("br" if n.tag==ns+"br" else "tab" if n.tag==ns+"tab" else "t"), (n.text or "") ) for n in p._p.iter() if n.tag in (ns+"br", ns+"tab") or (isinstance(n.tag,str) and n.tag.endswith("}t") and (n.text or ""))] for p in d.paragraphs]}
print(json.dumps(out))
`;

function py(codigo, ...args) { return execFileSync('python3', ['-c', codigo, ...args], { maxBuffer: 1 << 26 }).toString(); }

// 1) docx feito pelo python-docx, lido pelo JS == lido pelo python-docx
const a = path.join(tmp, 'a.docx');
py(PY_GERA, a);
const esperado = JSON.parse(py(PY_LE, a));
const lido = lerDocx(a);
assert.deepStrictEqual(lido.paragraphs.map((p) => p.text), esperado.paragraphs, 'texto dos parágrafos');
assert.deepStrictEqual(lido.tables.map((t) => t.rows.map((r) => r.cells.map((c) => c.text))), esperado.tables, 'tabelas');
assert.deepStrictEqual(lido.hyperlinks, esperado.hyperlinks, 'hyperlinks');
assert.deepStrictEqual(lido.hyperlinkTexts, esperado.hyperlinkTexts, 'textos de link');
assert.deepStrictEqual(lido.paragraphs.map((p) => p.partes.map((x) => [x.tipo, x.tipo === 't' ? x.texto : ''])),
  esperado.partes.map((ps) => ps.map(([t, x]) => [t, t === 't' ? x : ''])), 'partes');
// sobrescrito detectado
const sup = lido.paragraphs[0].partes.filter((x) => x.superscript).map((x) => x.texto);
assert.deepStrictEqual(sup, ['18x', '1']);
assert.ok(lido.paragraphs.some((p) => p.partes.some((x) => x.tipo === 'br')));

// 2) docx feito pelo JS, lido pelo python-docx
const paragrafos = ['Assunto: Olá', 'Linha com “aspas” e emoji 😀', 'Tab\taqui', 'duas\nlinhas', 'Clique aqui', 'Texto & <tags> "q"', ''];
const links = { 'Clique aqui': 'https://exemplo.com/x?a=1&b=2' };
const b = path.join(tmp, 'b.docx');
fs.writeFileSync(b, gerarDocx(paragrafos, links));
const lidoPy = JSON.parse(py(PY_LE, b));
assert.deepStrictEqual(lidoPy.paragraphs, paragrafos, 'python-docx lê o docx do JS');
assert.deepStrictEqual(lidoPy.hyperlinks, ['https://exemplo.com/x?a=1&b=2']);
assert.deepStrictEqual(lidoPy.hyperlinkTexts, ['Clique aqui']);
const lidoJs = lerDocx(b);
assert.deepStrictEqual(lidoJs.paragraphs.map((p) => p.text), paragrafos);
assert.deepStrictEqual(lidoJs.hyperlinks, ['https://exemplo.com/x?a=1&b=2']);

// 3) zip: ida e volta + zip do Python (deflate e stored) + CRC
const z = escreverZip([{ nome: 'a/b.txt', dados: 'olá mundo '.repeat(100) }, { nome: 'vazio', dados: '' }, { nome: 'c', dados: Buffer.from([1, 2, 3]), comprimir: false }]);
const zl = new ZipLeitor(z);
assert.deepStrictEqual(zl.nomes(), ['a/b.txt', 'vazio', 'c']);
assert.strictEqual(zl.ler_texto('a/b.txt'), 'olá mundo '.repeat(100));
assert.strictEqual(zl.ler('vazio').length, 0);
fs.writeFileSync(path.join(tmp, 'z.zip'), z);
assert.strictEqual(py("import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1]);assert z.testzip() is None;print(z.read('a/b.txt').decode()==('olá mundo '*100), z.namelist())", path.join(tmp, 'z.zip')).trim(), "True ['a/b.txt', 'vazio', 'c']");
const pz = path.join(tmp, 'p.zip');
py("import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1],'w');z.writestr('x/ç.txt','conteúdo '*50,zipfile.ZIP_DEFLATED);z.writestr('s.txt','stored',zipfile.ZIP_STORED);z.close()", pz);
const pzl = new ZipLeitor(pz);
assert.strictEqual(pzl.ler_texto('x/ç.txt'), 'conteúdo '.repeat(50));
assert.strictEqual(pzl.ler_texto('s.txt'), 'stored');

// 4) xml
const x = parseXml('<?xml version="1.0"?><r xmlns="urn:d" xmlns:q="urn:q" q:k="v&lt;1"><a>  </a>\n  <b>x&amp;y&#233;&#x1F600;</b><c/></r>');
assert.strictEqual(x.uri, 'urn:d');
assert.strictEqual(x.attr('urn:q', 'k'), 'v<1');
assert.strictEqual(x.elementos().length, 3);
assert.strictEqual(x.achar('urn:d', 'a').filhos[0], '  ');   // único conteúdo: mantido
assert.strictEqual(x.achar('urn:d', 'b').text, 'x&yé😀');
assert.strictEqual(x.filhos.filter((f) => typeof f === 'string').length, 0); // branco entre elementos: removido

fs.rmSync(tmp, { recursive: true, force: true });
console.log('docx/zip/xml OK');
