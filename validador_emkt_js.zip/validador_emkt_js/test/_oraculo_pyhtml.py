# Oráculo: lê JSON {docs:[...], seletores:[...]} em stdin e devolve o resultado do bs4 para cada documento.
import json, re, sys, warnings
warnings.filterwarnings("ignore")
from bs4 import BeautifulSoup, Tag, NavigableString, Comment

def dump(n):
    if isinstance(n, Tag):
        return {"t": "Tag", "n": n.name, "a": [[k, list(v) if isinstance(v, list) else str(v)] for k, v in n.attrs.items()],
                "c": [dump(c) for c in n.contents]}
    return {"t": type(n).__name__, "v": str(n)}

def idx(soup):
    return {id(d): i for i, d in enumerate(soup.descendants)}

entrada = json.load(sys.stdin)
saida = []
for doc in entrada["docs"]:
    r = {}
    try:
        soup = BeautifulSoup(doc, "html.parser")
        r["tree"] = dump(soup)
        r["str"] = str(soup)
        r["text"] = soup.get_text()
        r["text_strip"] = soup.get_text(" ", strip=True)
        pos = idx(soup)
        r["desc_types"] = [type(d).__name__ for d in soup.descendants]
        r["find_a"] = [pos[id(t)] for t in soup.find_all("a")]
        r["find_true"] = [pos[id(t)] for t in soup.find_all(True)]
        r["find_img_attr"] = [pos[id(t)] for t in soup.find_all(["img", "td"], attrs={"width": True})]
        r["comments"] = [pos[id(t)] for t in soup.find_all(string=lambda s: isinstance(s, Comment))]
        r["sel"] = {s: [pos[id(t)] for t in soup.select(s)] for s in entrada["seletores"]}
        r["tagtext"] = [[t.name, t.get_text(), t.string if t.string is None else str(t.string)] for t in soup.find_all(["p", "div", "td", "title", "script", "style"])]
        r["strs"] = [t.get("style") or "" for t in soup.find_all(True)][:50]
        # extract de comentários e nova descendants
        for c in soup.find_all(string=lambda s: isinstance(s, Comment)):
            c.extract()
        r["pos_extract"] = [type(d).__name__ + ":" + (d.name if isinstance(d, Tag) else str(d)) for d in soup.descendants]
        r["str2"] = str(soup)
    except Exception as e:
        r = {"erro": type(e).__name__}
    saida.append(r)
json.dump(saida, sys.stdout, ensure_ascii=False)
