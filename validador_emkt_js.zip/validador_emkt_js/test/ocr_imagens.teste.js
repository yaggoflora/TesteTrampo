'use strict';
// Teste diferencial de ocr.js e imagens.js contra o Python. Rode com NODE_PATH apontando para o sharp.
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { execFileSync } = require('child_process');
const ocr = require('../src/validador/ocr');
const imagens = require('../src/validador/imagens');
const I = require('../src/lib/imgutil');

function oraculo(entrada) {
  const r = execFileSync('python3', [path.join(__dirname, '_oraculo_ocr.py')], { input: JSON.stringify(entrada), maxBuffer: 1 << 28 });
  return JSON.parse(r.toString());
}
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const rnd = mulberry(12345);
const pick = (xs) => xs[Math.floor(rnd() * xs.length)];
// normaliza números (1.0 == 1) e remove undefined
const norm = (x) => JSON.parse(JSON.stringify(x, (k, v) => (typeof v === 'number' && !Number.isFinite(v) ? String(v) : v)));
let total = 0;
function igual(rotulo, obtido, esperado) {
  total++;
  try { assert.deepStrictEqual(norm(obtido), norm(esperado)); console.log('ok ', rotulo); }
  catch (e) {
    console.log('XX ', rotulo);
    const o = norm(obtido), x = norm(esperado);
    if (Array.isArray(o) && Array.isArray(x)) {
      for (let i = 0; i < Math.max(o.length, x.length); i++) {
        try { assert.deepStrictEqual(o[i], x[i]); } catch { console.log('   caso', i, '\n   JS :', JSON.stringify(o[i]), '\n   PY :', JSON.stringify(x[i])); process.exitCode = 1; return; }
      }
    }
    process.exitCode = 1;
  }
}

(async () => {
  // ---- _e_ruido_de_icone / _como_numero / _fora_do_alfabeto
  const textos = ['50%', '20 %', '10/09:', '03/09/2026', 'R$ 50.000,00', 'R$ 50', '4002 0022', '0800 570', '36x', '22h', '1,29', '+1.5',
    '000', '0 0000 000', '....', '口', '☎', '✓', 'Livelo', 'ok', 'a', 'ab', 'Simule agora', 'Cartões', 'ação', 'Ünï', 'Привет', '日本', 'ª', 'º', 'Ａ', 'K', '²', '36x²',
    '', ' ', '  ', 'R$', '12', '123', '1234', '12345', '٣٤', '٣٤٥ ٣٤٥', 'x1', '100%', '1000%', 'é', 'ß', 'İ', '😀', 'ok😀', '*', '**', '_', '__', '--', '- -', '12:30', '5 x', '0,5', '10.5', '10.555', 'e', '1/2', '12/12/12', 'R$ 1.000', 'R$1.000,00', '3x', '2h'];
  const confs = [0, 10, 40, 77.9, 87.9, 88, 90, 99.9, '95', '88,5', 'abc', null, '', 100];
  const casosRuido = [];
  for (const t of textos) for (const c of confs) casosRuido.push([t, c]);
  igual(`_e_ruido_de_icone (${casosRuido.length} casos)`, casosRuido.map(([t, c]) => ocr._e_ruido_de_icone(t, c)), oraculo({ op: 'ruido', casos: casosRuido }));

  const valores = [0, 1, 1.5, -2, '0.98', '1,5', ' 7 ', '1e3', '1_0', 'inf', '-inf', 'nan', 'abc', '', null, true, '1.', '.5', '--1', '1e', '+3', '٣'];
  igual('_como_numero', valores.map((v) => { const x = ocr._como_numero(v, -7.0); return Number.isNaN(x) ? 'nan' : x === Infinity ? 'inf' : x === -Infinity ? '-inf' : x; }), oraculo({ op: 'numero', valores }));

  const ruins = [];
  for (let cp = 0; cp < 0x110000; cp++) { if (cp >= 0xd800 && cp < 0xe000) continue; if (ocr._fora_do_alfabeto(String.fromCodePoint(cp))) ruins.push(cp); }
  const esperadoRuins = oraculo({ op: 'alfabeto' });
  const conjRuins = new Set(ruins), conjPy = new Set(esperadoRuins);
  // Python 3.13 usa Unicode 15.1 e o Node 22 usa 17: caracteres criados depois não existem para o Python
  const naoAtribuidosNoPython = new Set(oraculo({ op: 'cn' }));
  const _novo = (c) => naoAtribuidosNoPython.has(c);
  const dif = [...new Set([...ruins, ...esperadoRuins])].filter((c) => conjRuins.has(c) !== conjPy.has(c)).filter((c) => !_novo(c));
  total++;
  if (dif.length) {
    console.log(`XX _fora_do_alfabeto exaustivo: ${dif.length} code points diferentes`, dif.slice(0, 20).map((c) => 'U+' + c.toString(16)).join(' '), '...');
    console.log('   (diferenças de versão do Unicode entre Node e Python podem explicar casos novos)');
    process.exitCode = 1;
  } else console.log(`ok  _fora_do_alfabeto exaustivo (${ruins.length} de 1114112 code points)`);

  // ---- caixas sintéticas
  const palavras = ['Simule', 'agora', 'CDB', '2', '36x', 'Livelo', 'Cartões', '50%', '03/09:', 'de', 'desconto', '*', 'Bradesco', 'Seducao', 'Seducäo', 'ok', 'R$', '1.000,00', '1', 'na', 'poltrona', 'D-BOX'];
  function caixasAleatorias(n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const topo = Math.round(rnd() * 400), alt = 10 + Math.round(rnd() * 30), esq = Math.round(rnd() * 800);
      const c = { texto: pick(palavras), topo, base: topo + alt, esquerda: esq, direita: esq + 10 + Math.round(rnd() * 120), confianca: 60 + Math.round(rnd() * 40) };
      if (rnd() < 0.15) { c.altura = alt; delete c.base; delete c.direita; }
      out.push(c);
    }
    return out;
  }
  // linhas bem formadas (mesma altura, palavras alinhadas), com chamadas de nota
  function peca() {
    const out = []; let y = 10;
    for (let l = 0; l < 2 + Math.floor(rnd() * 6); l++) {
      let x = 20 + Math.round(rnd() * 100); const alt = 14 + Math.round(rnd() * 30);
      for (let w = 0; w < 1 + Math.floor(rnd() * 5); w++) {
        const t = pick(palavras); const larg = 20 + t.length * 8;
        out.push({ texto: t, topo: y + Math.round(rnd() * 3), base: y + alt, esquerda: x, direita: x + larg, confianca: 70 + Math.round(rnd() * 30) });
        if (rnd() < 0.25) out.push({ texto: pick(['2', '1', '*']), topo: y - 4, base: y + alt * 0.55, esquerda: x + larg + 1, direita: x + larg + 8, confianca: 80 });
        x += larg + 10 + Math.round(rnd() * 30);
      }
      y += alt + 8 + Math.round(rnd() * 25);
    }
    return out;
  }
  const casos = [];
  for (let i = 0; i < 120; i++) casos.push(rnd() < 0.5 ? caixasAleatorias(1 + Math.floor(rnd() * 12)) : peca());
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const completar = (c) => c.map((x) => ({ base: x.base ?? x.topo + 10, direita: x.direita ?? x.esquerda, ...x }));
  igual('_montar_linha', clone(casos).map((c) => ocr._montar_linha(completar(c))), oraculo({ op: 'montar_linha', casos: clone(casos).map((c) => c.map((x) => ({ base: x.base ?? x.topo + 10, direita: x.direita ?? x.esquerda, ...x }))) }));
  igual('_linhas_de_um_bloco', clone(casos).map((c) => ocr._linhas_de_um_bloco(c.map((x) => ({ base: x.base ?? x.topo + 10, direita: x.direita ?? x.esquerda, ...x })))), oraculo({ op: 'linhas_bloco', casos: clone(casos).map((c) => c.map((x) => ({ base: x.base ?? x.topo + 10, direita: x.direita ?? x.esquerda, ...x }))) }));
  igual('_ordenar_linhas (layout + linhas)', clone(casos).map((c) => ocr._ordenar_linhas(c)), oraculo({ op: 'ordenar_linhas', casos: clone(casos) }));

  const blocos = [];
  for (let i = 0; i < 40; i++) blocos.push(Array.from({ length: 1 + Math.floor(rnd() * 4) }, () => Array.from({ length: Math.floor(rnd() * 5) }, () => pick(['COMPROMISSO', 'e TRANSPA', 'e TRANSPARENCIA com sua empresa', 'Livelo', 'livelo ', '50% OFF', '', '  ', 'Cartões Digitais', 'cartoes digitais']) ).join('\n')));
  igual('_juntar_textos', blocos.map((b) => ocr._juntar_textos(b)), oraculo({ op: 'juntar', casos: blocos }));

  const leituras = [];
  for (let i = 0; i < 60; i++) leituras.push(Array.from({ length: 1 + Math.floor(rnd() * 4) }, () => caixasAleatorias(Math.floor(rnd() * 6)).map((c) => ({ base: c.base ?? c.topo + 10, direita: c.direita ?? c.esquerda + 10, ...c }))));
  igual('_fundir_leituras', clone(leituras).map((l) => ocr._fundir_leituras(l)), oraculo({ op: 'fundir', casos: clone(leituras) }));
  const reps = [];
  for (let i = 0; i < 60; i++) { const c = caixasAleatorias(2 + Math.floor(rnd() * 10)).map((x) => ({ base: x.base ?? x.topo + 10, direita: x.direita ?? x.esquerda + 10, ...x })); c.push(...c.slice(0, 3).map((x) => ({ ...x, topo: x.topo + Math.round(rnd() * 30), confianca: Math.round(rnd() * 100) }))); reps.push(c); }
  igual('_remover_repetidas', clone(reps).map((c) => ocr._remover_repetidas(c)), oraculo({ op: 'repetidas', casos: clone(reps) }));

  const tamanhos = [[100, 100], [600, 900], [600, 901], [600, 2600], [900, 1800], [1000, 950], [1200, 5000], [50, 3000]];
  igual('_fatias_da_imagem', tamanhos.map(([w, h]) => ocr._fatias_da_imagem(new I.Imagem(Buffer.alloc(w * h * 3), w, h)).map(([f, t]) => [[f.width, f.height], t])), oraculo({ op: 'fatias', tamanhos }));

  // _caixas_em_fatias com motor falso (sem depender de pixels); respostas variam por chamada
  class MotorFake extends ocr.MotorBase {
    constructor(respostas, inteira) { super(); this.respostas = respostas; this.i = 0; this.tamanhos = []; this._inteira = inteira; }
    get nome() { return 'fake'; }
    get prefere_imagem_inteira() { return this._inteira; }
    async caixas(imagem) { this.tamanhos.push([imagem.width, imagem.height]); const r = this.respostas[this.i % this.respostas.length]; this.i++; return clone(r); }
  }
  const respostasPossiveis = () => Array.from({ length: 1 + Math.floor(rnd() * 3) }, () => caixasAleatorias(Math.floor(rnd() * 5)).map((c) => ({ base: c.base ?? c.topo + 10, direita: c.direita ?? c.esquerda + 10, ...c, texto: pick(['Simule agora', 'Cartões', '50%', '口', '000', 'ok']) })));
  const casosFatia = [];
  for (let i = 0; i < 30; i++) casosFatia.push({ tamanho: pick([[300, 200], [600, 2000], [1500, 3000], [800, 900], [1400, 1000], [1000, 2500]]), respostas: respostasPossiveis(), inteira: rnd() < 0.3 });
  const obtidoFatias = [];
  for (const c of casosFatia) {
    const m = new MotorFake(clone(c.respostas), c.inteira);
    const [caixas, n] = await ocr._caixas_em_fatias(m, new I.Imagem(Buffer.alloc(c.tamanho[0] * c.tamanho[1] * 3, 200), c.tamanho[0], c.tamanho[1], 3), 'por', 40);
    obtidoFatias.push({ caixas, n, tamanhos: m.tamanhos });
  }
  igual('_caixas_em_fatias (motor falso)', obtidoFatias, oraculo({ op: 'caixas_em_fatias', casos: casosFatia }));

  // ---- imagens.py
  const raiz = fs.mkdtempSync(path.join(os.tmpdir(), 'imgs_'));
  const mk = (pasta, nomes, tamanho) => { fs.mkdirSync(pasta, { recursive: true }); for (const n of nomes) fs.writeFileSync(path.join(pasta, n), Buffer.alloc(tamanho ?? 100, 1)); return pasta; };
  const pngReal = (p, w, h) => I.salvarPng(new I.Imagem(Buffer.alloc(w * h * 3, 120), w, h, 3), p);
  const cenarios = [];
  const p1 = mk(path.join(raiz, 'c1'), ['LIVELO_01.png', 'LIVELO_02.png', 'LIVELO_03.jpg', 'LIVELO_05.png']);
  cenarios.push({ pasta: p1, html: ['LIVELO_01.png', 'livelo_02.png', 'LIVELO_03.jpg', 'LIVELO_05.png', 'LIVELO_05.png', 'LIVELO_04.png'] });
  const p2 = mk(path.join(raiz, 'c2'), ['promo_1.png', 'promo_02.png', 'promo_02.gif', 'outra.png', 'promo-07.PNG', 'preview_final.png', '~$lock.png', '.oculto.png', 'x.txt', 'logo.svg', 'a.webp', 'b.bmp']);
  fs.writeFileSync(path.join(p2, 'grande_01.png'), Buffer.alloc(1100 * 1024, 2));
  cenarios.push({ pasta: p2, html: ['promo_1.png', 'promo_02.png', 'outra.png', 'x.png'], quebra: 'PROMO' });
  cenarios.push({ pasta: p2, html: [], quebra: '' });
  const p3 = mk(path.join(raiz, 'c3'), ['a_02.png', 'a_03.png', 'a_03.png'.replace('a_03', 'A_03')]);
  fs.mkdirSync(path.join(p3, 'sub')); fs.writeFileSync(path.join(p3, 'sub', 'a_09.png'), Buffer.alloc(10));
  cenarios.push({ pasta: p3, html: ['a_02.png', 'A_03.png', 'a_09.png'] });
  const p4 = mk(path.join(raiz, 'c4'), []);
  pngReal(path.join(p4, 'peca_alta.png'), 100, 400); pngReal(path.join(p4, 'banner_01.png'), 400, 100); pngReal(path.join(p4, 'banner_02.png'), 400, 100); pngReal(path.join(p4, 'solta.png'), 30, 30);
  cenarios.push({ pasta: p4, html: ['banner_01.png', 'banner_02.png'], quebra: 'banner' });
  cenarios.push({ pasta: path.join(raiz, 'nao_existe'), html: ['x.png'] });
  cenarios.push({ pasta: p1, html: ['LIVELO_01.png'], quebra: '  livelo ' });
  const esperadoImg = oraculo({ op: 'imagens', casos: cenarios });
  const obtidoImg = cenarios.map((c) => {
    const r = imagens.verificar(c.pasta, c.html, c.quebra === undefined ? null : c.quebra);
    const d = JSON.parse(JSON.stringify(r)); d.aprovado = r.aprovado;
    for (const a of d.arquivos) a.caminho = path.relative(c.pasta, a.caminho);
    return d;
  });
  igual(`imagens.verificar (${cenarios.length} cenários)`, obtidoImg, esperadoImg);
  const nomesInf = [['A_01.png', 'A_02.png', 'B_01.png'], ['x.png', 'y.png'], [], ['LIV-01.png', 'LIV-02.png', 'outra_01.png', 'outra_02.png']];
  igual('_inferir_quebra', nomesInf.map((n) => imagens._inferir_quebra(n)), oraculo({ op: 'inferir', casos: nomesInf }));
  fs.rmSync(raiz, { recursive: true, force: true });

  // ---- propriedades do cache / versão
  assert.strictEqual(ocr._versao_da_leitura([['a', 'x']]), ocr._versao_da_leitura([['a', 'x']]));
  assert.notStrictEqual(ocr._versao_da_leitura([['a', 'x']]), ocr._versao_da_leitura([['a', 'y']]));
  assert.strictEqual(ocr.VERSAO_DA_LEITURA.length, 12);
  console.log('ok  versão da leitura');

  console.log(`\n${total} grupos comparados com o Python${process.exitCode ? ' — HÁ DIFERENÇAS' : ' — tudo igual'}`);
})();
