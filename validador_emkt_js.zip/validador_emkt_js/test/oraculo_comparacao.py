"""Oráculo: roda no Python original as mesmas chamadas que o teste JS faz. Lê JSON do stdin, escreve JSON."""
import dataclasses
import datetime
import json
import os
import sys

REF = os.environ["VALIDADOR_REF"]
sys.path.insert(0, REF)
from validador import (comparador, correcao_ocr, excecoes, layout, normalizacao,  # noqa: E402
                       ordenacao, presenca, regras)
from validador.html_parser import BlocoFita  # noqa: E402

MODS = {"comparador": comparador, "correcao_ocr": correcao_ocr, "excecoes": excecoes,
        "layout": layout, "normalizacao": normalizacao, "ordenacao": ordenacao,
        "presenca": presenca, "regras": regras}


def decodificar(v):
    if isinstance(v, dict):
        if "$set" in v:
            return set(v["$set"])
        if "$fita" in v:
            return [BlocoFita(**b) for b in v["$fita"]]
        if "$data" in v:
            return datetime.date(*v["$data"])
        if "$assunto" in v:
            a = v["$assunto"]
            ns = type("L", (), {})()
            ns.pre_header = a["pre_header"]
            ns.texto_oculto = a.get("texto_oculto", [])
            ns.fita = [BlocoFita(**b) for b in a.get("fita", [])]
            return ns, ns
        return {k: decodificar(x) for k, x in v.items()}
    if isinstance(v, list):
        return [decodificar(x) for x in v]
    return v


def serializar(v):
    if dataclasses.is_dataclass(v) and not isinstance(v, type):
        d = {f.name: serializar(getattr(v, f.name)) for f in dataclasses.fields(v)}
        for extra in ("gravidade", "status", "aprovado", "texto"):
            if hasattr(type(v), extra):
                d[extra] = serializar(getattr(v, extra))
        return d
    if isinstance(v, (set, frozenset)):
        return sorted(serializar(x) for x in v)
    if isinstance(v, (list, tuple)):
        return [serializar(x) for x in v]
    if isinstance(v, dict):
        return {str(k): serializar(x) for k, x in v.items()}
    if hasattr(v, "texto") and hasattr(v, "caixas"):
        return {"caixas": serializar(v.caixas), "topo": v.topo, "esquerda": v.esquerda, "base": v.base,
                "texto": v.texto}
    return v


def rodar(caso):
    mod, nome = caso["fn"].split(".")
    fn = getattr(MODS[mod], nome)
    args = [decodificar(a) for a in caso.get("args", [])]
    kw = {k: decodificar(a) for k, a in caso.get("kw", {}).items()}
    # comparar_assunto recebe (assunto, html)
    if nome == "comparar_assunto":
        a, h = decodificar(caso["args"][0])
        args = [a, h]
    try:
        r = fn(*args, **kw)
        saida = {"ok": serializar(r)}
    except Exception as e:  # noqa: BLE001
        saida = {"erro": type(e).__name__}
    # a fita é alterada no lugar (conteúdo reordenado): devolve o estado depois
    for a in args:
        if isinstance(a, list) and a and isinstance(a[0], BlocoFita):
            saida["fita_depois"] = [dataclasses.asdict(b) for b in a]
    return saida


if __name__ == "__main__":
    casos = json.load(sys.stdin)
    print(json.dumps([rodar(c) for c in casos], ensure_ascii=False))
