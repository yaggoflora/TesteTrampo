# Gera imagens e a saída do Pillow para cada operação; o teste JS compara byte a byte.
import sys, os, json
import numpy as np
from PIL import Image, ImageOps, ImageFilter, ImageEnhance, ImageDraw, ImageFont
pasta = sys.argv[1]
rng = np.random.default_rng(7)
imgs = {}
imgs['ruido'] = Image.fromarray(rng.integers(0, 256, (23, 37, 3), dtype=np.uint8), 'RGB')
g = np.zeros((40, 90, 3), np.uint8)
for x in range(90):
    g[:, x] = (x * 2, 255 - x * 2, (x * 5) % 256)
imgs['gradiente'] = Image.fromarray(g, 'RGB')
t = Image.new('RGB', (300, 80), (30, 40, 90))
d = ImageDraw.Draw(t)
d.text((10, 20), "Simule agora 50% OFF", fill=(240, 240, 240))
imgs['texto'] = t
imgs['baixo_contraste'] = Image.fromarray((100 + rng.integers(0, 40, (30, 50, 3))).astype(np.uint8), 'RGB')
saida = {}
for nome, im in imgs.items():
    im.save(os.path.join(pasta, nome + '.png'))
    ops = {}
    w, h = im.size
    ops['lanczos_up'] = im.resize((int(w * 1.7), int(h * 2.3)), Image.LANCZOS)
    ops['lanczos_down'] = im.resize((max(1, w // 3), max(1, h // 2)), Image.LANCZOS)
    ops['bilinear64'] = im.convert('L').resize((64, 64), Image.BILINEAR)
    ops['cinza'] = ImageOps.grayscale(im)
    ops['inverter'] = ImageOps.invert(im)
    ops['autocontraste0'] = ImageOps.autocontrast(ImageOps.grayscale(im))
    ops['autocontraste1'] = ImageOps.autocontrast(im, cutoff=1)
    ops['contraste16'] = ImageEnhance.Contrast(im).enhance(1.6)
    ops['nitidez'] = im.filter(ImageFilter.UnsharpMask(radius=2, percent=140, threshold=3))
    ops['recorte'] = im.crop((3, 2, w - 4, h - 1))
    for k, v in ops.items():
        v.save(os.path.join(pasta, f'{nome}__{k}.png'))
    saida[nome] = {'lum': float(np.array(ImageOps.grayscale(im)).mean())}
json.dump(saida, open(os.path.join(pasta, 'meta.json'), 'w'))
# GIF animado e dimensões
fr = [Image.new('RGB', (80, 70), c) for c in [(255, 255, 255), (0, 0, 0), (255, 0, 0)]]
fr[0].save(os.path.join(pasta, 'anim.gif'), save_all=True, append_images=fr[1:], duration=100, loop=0)
Image.new('RGB', (123, 45), 'white').save(os.path.join(pasta, 'dim.jpg'), quality=80)
Image.new('RGB', (123, 45), 'white').save(os.path.join(pasta, 'dim.webp'))
Image.new('RGB', (123, 45), 'white').save(os.path.join(pasta, 'dim.bmp'))
Image.new('RGB', (123, 45), 'white').save(os.path.join(pasta, 'dim.gif'))
