'use strict';
const assert = require('assert');
const { execFileSync } = require('child_process');
const { SequenceMatcher } = require('../src/lib/difflib');

// gerador pseudoaleatório determinístico
let s = 12345;
const rnd = () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];

const palavras = 'o a de que e do da em um para com não uma os no se na por mais as dos como mas foi ao ele das tem à seu sua ou ser quando muito há nos já está eu também só pelo pela até isso ela entre era depois sem mesmo aos ter seus quem nas me esse eles estão você tinha foram essa num nem suas meu às minha têm numa pelos elas havia seja qual será nós tenho lhe deles essas esses pelas este fosse dele Livelo Bradesco cartão crédito pontos 50% R$ 1.200,00 20/12/2026 36x taxa prazo oferta'.split(' ');
const casos = [];
function seqAleatoria(alfabeto, n) { return Array.from({ length: n }, () => pick(alfabeto)); }
for (let i = 0; i < 1500; i++) {
  const alf = seqAleatoria([...'abcdefgh'], 1).concat(i % 3 ? [...'abcdefghij'] : [...'ab']);
  const na = Math.floor(rnd() * 40), nb = Math.floor(rnd() * 40);
  casos.push({ a: seqAleatoria(alf, na), b: seqAleatoria(alf, nb), auto: i % 2 === 0, junk: i % 5 === 0 ? 'ab' : '' });
}
// tokens reais: b parecido com a, com edições; e sequências longas (>=200) para disparar autojunk
for (let i = 0; i < 400; i++) {
  const n = i % 4 === 0 ? 260 + Math.floor(rnd() * 200) : 20 + Math.floor(rnd() * 80);
  const base = seqAleatoria(palavras, n);
  const b = base.slice();
  const edits = Math.floor(rnd() * 8);
  for (let e = 0; e < edits; e++) {
    const op = Math.floor(rnd() * 3), pos = Math.floor(rnd() * Math.max(1, b.length));
    if (op === 0) b.splice(pos, 1);
    else if (op === 1) b.splice(pos, 0, pick(palavras));
    else b[pos] = pick(palavras);
  }
  casos.push({ a: base, b, auto: i % 2 === 0, junk: '' });
}
// strings (por code point, inclusive astral)
for (const [a, b] of [['abcd', 'bcde'], ['qabxcd', 'abycdf'], [' abcd', 'abcd abcd'], ['😀a😀b', 'a😀b'], ['', ''], ['x', ''], ['', 'x'], ['Simular agora', 'Simular a agora']]) {
  casos.push({ a, b, auto: false, junk: '', str: true });
  casos.push({ a, b, auto: true, junk: ' ', str: true });
}
const ents = casos.map((c) => ({ a: c.a, b: c.b, auto: c.auto, junk: c.junk }));
const saida = execFileSync('python3', ['-c', `
import json,sys
from difflib import SequenceMatcher
casos=json.loads(sys.stdin.read())
res=[]
for c in casos:
    a,b=c['a'],c['b']
    j=c['junk']
    m=SequenceMatcher((lambda x: x in j) if j else None,a,b,autojunk=c['auto'])
    la,lb=len(a),len(b)
    flm=m.find_longest_match(0,la,0,lb)
    mid=m.find_longest_match(la//3,la-la//4,lb//4,lb-lb//3) if la>3 and lb>3 else None
    res.append(dict(ratio=m.ratio(),ops=[list(o) for o in m.get_opcodes()],
      blocks=[[x.a,x.b,x.size] for x in m.get_matching_blocks()],
      flm=[flm.a,flm.b,flm.size], mid=None if mid is None else [mid.a,mid.b,mid.size],
      q=m.quick_ratio(), rq=m.real_quick_ratio(),
      grouped=[[list(o) for o in g] for g in m.get_grouped_opcodes()]))
print(json.dumps(res))
`], { input: JSON.stringify(ents), maxBuffer: 1 << 28 }).toString();
const esperado = JSON.parse(saida);
casos.forEach((c, i) => {
  const j = c.junk;
  const m = new SequenceMatcher(j ? (x) => j.includes(x) : null, c.a, c.b, c.auto);
  const la = Array.from(c.a).length, lb = Array.from(c.b).length;
  const e = esperado[i];
  const rotulo = `caso ${i}`;
  assert.strictEqual(m.ratio(), e.ratio, rotulo + ' ratio');
  assert.deepStrictEqual(m.get_opcodes(), e.ops, rotulo + ' opcodes');
  assert.deepStrictEqual(m.get_matching_blocks().map((x) => [x.a, x.b, x.size]), e.blocks, rotulo + ' blocks');
  const flm = m.find_longest_match(0, la, 0, lb);
  assert.deepStrictEqual([flm.a, flm.b, flm.size], e.flm, rotulo + ' flm');
  if (e.mid) { const x = m.find_longest_match(Math.floor(la / 3), la - Math.floor(la / 4), Math.floor(lb / 4), lb - Math.floor(lb / 3)); assert.deepStrictEqual([x.a, x.b, x.size], e.mid, rotulo + ' mid'); }
  assert.strictEqual(m.quick_ratio(), e.q, rotulo + ' quick');
  assert.strictEqual(m.real_quick_ratio(), e.rq, rotulo + ' rq');
  assert.deepStrictEqual(m.get_grouped_opcodes(), e.grouped, rotulo + ' grouped');
});
console.log(`difflib OK (${casos.length} casos contra o Python)`);
