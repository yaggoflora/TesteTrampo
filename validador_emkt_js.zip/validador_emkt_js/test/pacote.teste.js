'use strict';
/**
 * Teste diferencial da frente E (docx_parser, html_parser, pacote, serializacao, relatorio).
 * O Python original (oráculo) monta pacotes de teste no disco e roda a conferência com um motor de OCR falso;
 * o JS roda sobre os MESMOS arquivos com o equivalente do motor falso e os resultados são comparados campo a campo,
 * inclusive o HTML do relatório (byte a byte, com a hora fixa).
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const REF = process.env.VALIDADOR_REF
  || '/tmp/claude-0/-home-claude/eb36be0e-6bcb-5b08-a75c-97a697a03e9e/scratchpad/src/validador_emkt';
const raiz = fs.mkdtempSync(path.join(os.tmpdir(), 'teste_pacote_'));
execFileSync('python3', [path.join(__dirname, '_oraculo_pacote.py'), raiz], { env: { ...process.env, VALIDADOR_REF: REF }, stdio: 'inherit' });
const py = JSON.parse(fs.readFileSync(path.join(raiz, '_python.json'), 'utf8'));
const CASOS = path.join(raiz, 'casos');

const ocr = require('../src/validador/ocr');
const pacote = require('../src/validador/pacote');
const docx_parser = require('../src/validador/docx_parser');
const html_parser = require('../src/validador/html_parser');
const serializacao = require('../src/validador/serializacao');
const relatorio = require('../src/validador/relatorio');

// ---- serialização equivalente à do oráculo
function ser(v) {
  if (v === null || v === undefined) return null;
  if (Array.isArray(v)) return v.map(ser);
  if (v instanceof Set) return [...v].map(ser).sort();
  if (v instanceof Map) return Object.fromEntries([...v.entries()].map(([k, x]) => [String(k), ser(x)]));
  if (typeof v === 'object') {
    const out = {};
    for (const [k, x] of Object.entries(v)) out[k] = ser(x);
    for (const g of ['status', 'aprovado', 'gravidade']) {
      const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(v) || {}, g);
      if (d && d.get) out['__' + g] = v[g];
    }
    return out;
  }
  return v;
}

// ---- comparação com relatório de diferenças
const diffs = [];
function comparar(a, b, caminho) {
  if (diffs.length >= 25) return;
  if (typeof a !== typeof b && !(a === null || b === null)) { diffs.push(`${caminho}: tipo ${typeof a} x ${typeof b} (${JSON.stringify(a)} x ${JSON.stringify(b)})`); return; }
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) diffs.push(`${caminho}: tamanho ${a.length} x ${b.length}`);
    for (let i = 0; i < Math.min(a.length, b.length); i++) comparar(a[i], b[i], `${caminho}[${i}]`);
    return;
  }
  if (a && b && typeof a === 'object') {
    const ks = new Set([...Object.keys(a), ...Object.keys(b)]);
    for (const k of ks) {
      if (!(k in a)) diffs.push(`${caminho}.${k}: falta no JS (py=${JSON.stringify(b[k]).slice(0, 80)})`);
      else if (!(k in b)) diffs.push(`${caminho}.${k}: sobra no JS (js=${JSON.stringify(a[k]).slice(0, 80)})`);
      else comparar(a[k], b[k], `${caminho}.${k}`);
    }
    return;
  }
  if (a !== b) diffs.push(`${caminho}: JS=${JSON.stringify(a)?.slice(0, 120)}  PY=${JSON.stringify(b)?.slice(0, 120)}`);
}

// ---- motor falso
function motor(leituras) {
  class MotorDeTeste extends ocr.MotorBase {
    get nome() { return 'motor-de-teste'; }
    get descricao() { return 'Motor de teste (texto combinado por arquivo)'; }
    disponivel() { return [true, 'ok']; }
    async ler(caminho) {
      const nome = path.basename(caminho);
      const linhas = [...(leituras[nome.toLowerCase()] || [])];
      return new ocr.ResultadoOCR({ arquivo: nome, texto: ocr.limpar ? ocr.limpar(linhas.join('\n')) : linhas.join('\n'), lido: true, linhas, motor: this.nome, confianca_media: 99.0 });
    }
  }
  return new MotorDeTeste();
}
// leituras idênticas às do oráculo (mantidas aqui por serem dados de teste)
const A = path.join(CASOS, 'A_ACAO_01_VAL_ATE_03.27');
const B = path.join(CASOS, 'B_PERFEITO');
const F = path.join(CASOS, 'F_WEBMAIL');
const G = path.join(CASOS, 'G_LOTE');
const H = path.join(CASOS, 'H_DIVERGENTE');
const LEIT = {
  [A]: { 'emkt_01.png': ['Banner principal', 'Simule agora', '36x²'], 'emkt_02.png': ['Aviso 10/01/2020', '50%'], 'emkt_03.png': [], 'emkt_05.png': ['Texto da imagem cinco'] },
  [B]: { 'emkt_01.png': ['Banner'] },
  [F]: { 'emkt_01.png': ['Texto da imagem'] },
  [H]: { 'emkt_01.png': ['Banner promocional', 'Oferta'] },
  [path.join(G, 'pac1')]: { 'emkt_01.png': ['Banner'] },
  [path.join(G, 'pac2')]: { 'emkt_01.png': ['Banner'] },
};

async function rodar(pasta, usar_ocr, quebra) {
  ocr._ESCOLHIDO = motor(usar_ocr ? (LEIT[pasta] || {}) : {});
  ocr.PASTA_CACHE = fs.mkdtempSync(path.join(os.tmpdir(), 'cache_js_'));
  let r;
  try { r = await pacote.validar(pasta, quebra, usar_ocr); } finally { fs.rmSync(ocr.PASTA_CACHE, { recursive: true, force: true }); }
  const arq = path.join(raiz, 'relatorios_js', path.basename(pasta) + '.html');
  relatorio.gerar(r, arq, new Date(2026, 10, 13, 10, 5));
  return { status: r.status, resultado: ser(r), json: serializacao.para_json(r, 'ID1'), html: fs.readFileSync(arq, 'utf8') };
}

(async () => {
  let total = 0;
  const conferir = (rotulo, a, b) => { total++; const antes = diffs.length; comparar(a, b, rotulo); return diffs.length === antes; };

  // casos de pacote
  for (const nome of Object.keys(py.casos)) {
    const [base, modo] = nome.split('|');
    const pasta = path.join(CASOS, base);
    const quebra = base.startsWith('A_') && !modo ? 'EMKT' : null;
    const js = await rodar(pasta, modo !== 'sem_ocr', quebra);
    const p = py.casos[nome];
    conferir(`${nome}.status`, js.status, p.status);
    conferir(`${nome}.resultado`, JSON.parse(JSON.stringify(js.resultado)), p.resultado);
    conferir(`${nome}.json`, JSON.parse(JSON.stringify(js.json)), p.json);
    if (js.html !== p.html) {
      total++;
      const a = js.html.split('\n'); const b = p.html.split('\n');
      let i = 0; while (i < a.length && a[i] === b[i]) i++;
      diffs.push(`${nome}.html: difere na linha ${i + 1}\n   JS: ${a[i]}\n   PY: ${b[i]}`);
    } else total++;
  }

  // localizar / lote
  const loc = {
    G_LOTE: pacote.localizar_pacotes(G),
    A: pacote.localizar_pacotes(A),
    inexistente: pacote.localizar_pacotes(path.join(CASOS, 'nada')),
    G_vazia: pacote.localizar_pacotes(path.join(G, 'vazia')),
  };
  conferir('localizar', loc, py.localizar);
  ocr._ESCOLHIDO = null;
  const lote = [];
  for (const p of pacote.localizar_pacotes(G)) lote.push((await rodar(p, true, null)).json);
  conferir('lote', JSON.parse(JSON.stringify(lote)), py.lote);

  // docx
  for (const nome of Object.keys(py.docx)) {
    const docs = docx_parser.localizar_docx(path.join(CASOS, nome));
    const [conteudo, assunto] = docx_parser.identificar_papeis(docs);
    conferir(`docx.${nome}`, {
      localizar: docs, leituras: docs.map((d) => ser(docx_parser.ler_docx(d))), papeis: [ser(conteudo), ser(assunto)],
    }, py.docx[nome]);
  }
  const linhas = ['Assunto: Olá', 'Pre header - Teste', 'Prehead Outro', 'Título', 'Só texto', 'Assunto', 'Seu assunto aqui',
    'Subject: Hello', 'Pré-header', 'x: y', 'Preview text: abc', 'Pre-chamada Algo'];
  conferir('rotulos', linhas.map((l) => docx_parser._identificar_rotulo(l)), py.rotulos);
  conferir('separar', [linhas, ['a', 'b', 'c'], ['Assunto', 'Linha A', 'Pré-header', 'Linha B'], []].map((x) => docx_parser._separar_assunto(x)), py.separar);
  const ruido = [];
  for (const t of ['Baixar', 'De: fulano', 'Assunto: x', '3 anexos', 'Fazer o download', 'Oferta', 'Enviado do meu Android']) for (const w of [false, true]) ruido.push(html_parser.e_ruido_de_cliente(t, w));
  conferir('ruido', ruido, py.ruido);
  conferir('nomes_url', ['a/b/c.png?x=1', 'http://x.com/p%20q/R%C3%A9.png#f', 'data:image/png;base64,AA', '', '  img/x.gif ', '//cdn/x.jpg;v=1', 'pasta/'].map(html_parser._nome_arquivo_da_url), py.nomes_url);
  const h = (n) => new Date(2026, 0, 1, n);
  conferir('emails', {
    validade: ['A_VAL_ATE_3.27', 'x val-ate-11/2027', 'sem', 'VAL ATÉ 03.2026', ''].map(serializacao.validade_da_pasta),
    saudacao: [0, 11, 12, 17, 18, 23].map((n) => serializacao.saudacao_do_horario(h(n))),
    render: serializacao.renderizar_email(serializacao.MODELO_AJUSTES, 'Ana', 'a@b.c', 'VAL_ATE_03.27', 'ACAO', h(9)),
  }, py.emails);

  fs.rmSync(raiz, { recursive: true, force: true });
  if (diffs.length) {
    console.log(`FALHOU: ${diffs.length} diferença(s) em ${total} comparações`);
    for (const d of diffs) console.log(' -', d);
    process.exit(1);
  }
  console.log(`pacote OK (${total} comparações contra o Python)`);
})().catch((e) => { console.error(e); process.exit(1); });
