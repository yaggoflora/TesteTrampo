# Oráculo Python para ocr.py e imagens.py. Entrada: JSON em stdin {"op": ..., ...}; saída: JSON.
import sys, json, os, unicodedata, tempfile
REF = "/tmp/claude-0/-home-claude/eb36be0e-6bcb-5b08-a75c-97a697a03e9e/scratchpad/src/validador_emkt"
sys.path.insert(0, REF)
from validador import ocr, imagens, layout
from PIL import Image

def caixas_fake(n_chamadas, sizes, respostas):
    pass

class MotorFake(ocr.MotorBase):
    nome = "fake"
    def __init__(self, respostas, inteira=False):
        self.respostas = respostas; self.i = 0; self.tamanhos = []
        self.prefere_imagem_inteira = inteira
    def caixas(self, imagem, idioma, confianca_minima):
        self.tamanhos.append(list(imagem.size))
        r = self.respostas[self.i % len(self.respostas)]; self.i += 1
        return [dict(c) for c in r]

def para_json(o):
    import dataclasses
    if dataclasses.is_dataclass(o): return {k: para_json(v) for k, v in dataclasses.asdict(o).items()}
    if isinstance(o, dict): return {str(k): para_json(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set)): return [para_json(v) for v in o]
    return o

dados = json.loads(sys.stdin.read())
op = dados["op"]
if op == "ruido":
    out = [ocr._e_ruido_de_icone(t, c) for t, c in dados["casos"]]
elif op == "numero":
    def f(v):
        try: return ocr._como_numero(v, -7.0)
        except Exception as e: return "ERRO"
    out = [f(v) for v in dados["valores"]]
    out = [("nan" if (isinstance(x, float) and x != x) else ("inf" if x == float("inf") else ("-inf" if x == float("-inf") else x))) for x in out]
elif op == "alfabeto":
    # exaustivo: todos os code points
    ruins = [cp for cp in range(0x110000) if not (0xD800 <= cp < 0xE000) and ocr._fora_do_alfabeto(chr(cp))]
    out = ruins
elif op == "cn":
    out = [cp for cp in range(0x110000) if unicodedata.category(chr(cp)) == "Cn"]
elif op == "montar_linha":
    out = [ocr._montar_linha([dict(c) for c in caixas]) for caixas in dados["casos"]]
elif op == "ordenar_linhas":
    out = [ocr._ordenar_linhas([dict(c) for c in caixas]) for caixas in dados["casos"]]
elif op == "linhas_bloco":
    out = [ocr._linhas_de_um_bloco([dict(c) for c in caixas]) for caixas in dados["casos"]]
elif op == "juntar":
    out = [ocr._juntar_textos(b) for b in dados["casos"]]
elif op == "fundir":
    out = [ocr._fundir_leituras([[dict(c) for c in l] for l in leituras]) for leituras in dados["casos"]]
elif op == "repetidas":
    out = [ocr._remover_repetidas([dict(c) for c in caixas]) for caixas in dados["casos"]]
elif op == "fatias":
    out = []
    for w, h in dados["tamanhos"]:
        im = Image.new("RGB", (w, h))
        out.append([[list(f.size), t] for f, t in ocr._fatias_da_imagem(im)])
elif op == "caixas_em_fatias":
    out = []
    for caso in dados["casos"]:
        w, h = caso["tamanho"]
        m = MotorFake(caso["respostas"], caso.get("inteira", False))
        caixas, n = ocr._caixas_em_fatias(m, Image.new("RGB", (w, h), (200, 200, 200)), "por", 40)
        out.append({"caixas": caixas, "n": n, "tamanhos": m.tamanhos})
elif op == "imagens":
    out = []
    for caso in dados["casos"]:
        r = imagens.verificar(caso["pasta"], caso["html"], caso.get("quebra"))
        d = para_json(r)
        d["aprovado"] = r.aprovado
        for a in d["arquivos"]: a["caminho"] = os.path.relpath(a["caminho"], caso["pasta"])
        out.append(d)
elif op == "inferir":
    out = [imagens._inferir_quebra(n) for n in dados["casos"]]
elif op == "tesseract":
    m = ocr.MotorTesseract()
    out = []
    for arq in dados["arquivos"]:
        r = m.ler(arq, "por", 40)
        out.append(para_json(r))
elif op == "ler_imagem":
    out = []
    for arq in dados["arquivos"]:
        out.append(para_json(ocr.ler_imagem(arq, "por", 40)))
elif op == "tsv":
    import pytesseract
    out = None
print(json.dumps(out, ensure_ascii=False))
