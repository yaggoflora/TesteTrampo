'use strict';
// Ponta a ponta: MotorTesseract (JS) x MotorTesseract (Python/pytesseract) sobre imagens geradas com PIL.
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { execFileSync } = require('child_process');
const ocr = require('../src/validador/ocr');

const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'ocrimg_'));
execFileSync('python3', ['-c', `
import sys, glob
from PIL import Image, ImageDraw, ImageFont
pasta = sys.argv[1]
fontes = glob.glob('/usr/share/fonts/**/DejaVuSans.ttf', recursive=True) + glob.glob('/usr/share/fonts/**/*.ttf', recursive=True)
def f(n): return ImageFont.truetype(fontes[0], n) if fontes else ImageFont.load_default()
a = Image.new('RGB', (900, 300), (255, 255, 255)); d = ImageDraw.Draw(a)
d.text((30, 30), 'Simule agora seu credito', fill=(20, 20, 20), font=f(40))
d.text((30, 110), '50% de desconto em 36x', fill=(200, 0, 0), font=f(34))
d.text((30, 190), 'Cartoes Digitais Bradesco', fill=(0, 0, 0), font=f(30))
a.save(pasta + '/plano.png')
b = Image.new('RGB', (900, 200), (20, 30, 80)); d = ImageDraw.Draw(b)
d.text((40, 40), 'Aproveite as ofertas', fill=(255, 255, 255), font=f(44))
d.text((40, 110), 'Livelo pontos em dobro', fill=(255, 220, 0), font=f(36))
b.save(pasta + '/escuro.png')
c = Image.new('RGB', (700, 2400), (245, 245, 245)); d = ImageDraw.Draw(c)
for i in range(8):
    d.text((40, 60 + i * 300), 'Linha numero %d da peca longa' % (i + 1), fill=(10, 10, 10), font=f(38))
c.save(pasta + '/alta.png')
Image.new('RGB', (30, 30), 'red').save(pasta + '/icone.png')
fr = []
for t, cor in [('Primeira cena', (255, 255, 255)), ('Segunda cena agora', (255, 240, 200)), ('Terceira cena final', (220, 240, 255))]:
    im = Image.new('RGB', (600, 120), cor); ImageDraw.Draw(im).text((20, 30), t, fill=(0, 0, 0), font=f(36)); fr.append(im)
fr[0].save(pasta + '/anim.gif', save_all=True, append_images=fr[1:], duration=200, loop=0)
`, pasta]);

const arquivos = ['plano.png', 'escuro.png', 'alta.png', 'icone.png', 'anim.gif'].map((n) => path.join(pasta, n));
const py = JSON.parse(execFileSync('python3', [path.join(__dirname, '_oraculo_ocr.py')], { input: JSON.stringify({ op: 'ler_imagem', arquivos }), maxBuffer: 1 << 28 }).toString());

(async () => {
  assert.strictEqual(ocr.motor_ativo().nome, 'tesseract');
  let falhas = 0;
  for (let i = 0; i < arquivos.length; i++) {
    const js = await ocr.ler_imagem(arquivos[i], 'por', 40);
    const p = py[i];
    const iguais = js.texto === p.texto && js.aviso === p.aviso && js.motor === p.motor && js.lido === p.lido && JSON.stringify(js.linhas) === JSON.stringify(p.linhas);
    console.log(iguais ? 'ok ' : 'DIF', path.basename(arquivos[i]), `conf JS=${js.confianca_media} PY=${p.confianca_media}`);
    if (!iguais) {
      falhas++;
      console.log('  JS:', JSON.stringify(js.texto), '|', js.aviso, '\n  PY:', JSON.stringify(p.texto), '|', p.aviso);
    }
  }
  // cache
  const cache = new ocr.CacheOCR('por', 40, true);
  const pc = fs.mkdtempSync(path.join(os.tmpdir(), 'cache_'));
  const guard = ocr.PASTA_CACHE; ocr.PASTA_CACHE = pc;
  let avancos = 0;
  await cache.pre_carregar(arquivos, 3, () => { avancos++; });
  assert.strictEqual(avancos, arquivos.length);
  const c2 = new ocr.CacheOCR('por', 40, true);
  await c2.pre_carregar(arquivos);
  assert.strictEqual(c2.reaproveitadas, arquivos.length - 0 > 0 ? c2.reaproveitadas : 0);
  assert.ok(c2.reaproveitadas >= 4, 'cache em disco deveria reaproveitar as leituras: ' + c2.reaproveitadas);
  console.log('ok  cache em disco, reaproveitadas =', c2.reaproveitadas, 'lidas =', cache.lidas);
  ocr.PASTA_CACHE = guard;
  fs.rmSync(pc, { recursive: true, force: true }); fs.rmSync(pasta, { recursive: true, force: true });
  if (falhas) { console.log(`${falhas} imagem(ns) com texto diferente do Python`); process.exitCode = 1; }
})();
