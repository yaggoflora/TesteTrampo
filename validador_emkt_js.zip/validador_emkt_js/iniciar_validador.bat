@echo off
rem Validador EMKT + SFMC Workbench: duplo clique para abrir (precisa do Node.js 20+).
rem Sem Node na maquina? Use o pacote portatil gerado por gerar_exe.bat.
chcp 65001 >nul
title Validador EMKT
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale em https://nodejs.org/ ^(versao 20 ou mais nova^).
  pause
  exit /b 1
)
if not exist node_modules (
  echo Preparando o ambiente pela primeira vez, aguarde...
  call npm install --omit=dev --no-audit --no-fund
)
echo Abrindo o Validador EMKT. Feche esta janela para encerrar.
node servidor.js
if errorlevel 1 pause
