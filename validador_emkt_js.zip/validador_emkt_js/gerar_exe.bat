@echo off
rem Gera o pacote portatil (pasta + .zip) em dist\ para o time que NAO tem Node.js.
rem Quem gera precisa de Node.js 20+ e internet. Duplo clique.
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale em https://nodejs.org/ ^(versao 20 ou mais nova^).
  pause
  exit /b 1
)
node scripts\gerar_pacote.js
if errorlevel 1 (
  echo.
  echo Algo deu errado. Leia a mensagem acima.
  pause
  exit /b 1
)
echo.
echo Mande o arquivo dist\ValidadorEMKT.zip para o time.
pause
