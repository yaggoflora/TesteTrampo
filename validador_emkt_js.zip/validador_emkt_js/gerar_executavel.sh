#!/usr/bin/env bash
# Gera o pacote portátil do Validador EMKT + SFMC Workbench em dist/ (pasta + .zip).
#
# Quem RECEBE o pacote não precisa de Node.js nem de internet: o Node vai dentro (runtime/).
# Quem GERA precisa de Node.js 20+ e npm, e de internet (baixa o Node do alvo e as bibliotecas).
#
# Ao contrário do executável antigo (PyInstaller), dá para gerar para outro sistema:
#   ALVO=win-x64 ./gerar_executavel.sh      (padrão: Windows 64 bits, o do time)
#   ALVO=linux-x64 ./gerar_executavel.sh    (win-arm64, linux-arm64, darwin-x64, darwin-arm64 também)
# Uso offline: NODE_ZIP=<arquivo do Node já baixado> ou NODE_DIST_DIR=<pasta do Node>; veja scripts/gerar_pacote.js.
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js nao encontrado. Instale em https://nodejs.org/ (versao 20 ou mais nova)."
  exit 1
fi
if ! command -v npm >/dev/null 2>&1 && [ "${SKIP_NPM:-0}" != "1" ]; then
  echo "npm nao encontrado (ele vem junto com o Node.js)."
  exit 1
fi
exec node scripts/gerar_pacote.js
