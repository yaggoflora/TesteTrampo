/* ==============================================================================
 * Validador de pacotes EMKT — Bradesco · CRM · Publicação e Orquestração
 * ==============================================================================
 * Organização:
 *   1. Utilitários            4. Envio da conferência
 *   2. Tema claro/escuro      5. Desenho de um pacote
 *   3. Abas de entrada        7. Motor de leitura de imagens
 *   4. Arrastar a pasta       8. Inicialização
 * ============================================================================== */

(function () {
  'use strict';

  /* ============================================================================
     1. Utilitários
     ========================================================================== */

  const $ = (sel) => document.querySelector(sel);

  /** Última resposta do servidor, guardada para reordenar o lote sem precisar
   *  conferir tudo de novo — reler dez pacotes por causa de um clique em
   *  "ordenar" seria absurdo. */
  let ultimaConferencia = null;
  let ordenacaoAtual = 'pior';

  /** Escapa antes de injetar no HTML: nome de arquivo e texto de peça vêm de
   *  fora e podem conter < e &. */
  function esc(valor) {
    return String(valor == null ? '' : valor)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  let timerToast = null;

  function toast(mensagem, tipo) {
    const caixa = $('#toast');
    if (!caixa) return;
    caixa.className = 'toast' + (tipo === 'ok' ? ' ok' : '');
    caixa.textContent = mensagem;
    requestAnimationFrame(() => caixa.classList.add('visivel'));
    clearTimeout(timerToast);
    timerToast = setTimeout(() => caixa.classList.remove('visivel'), 4200);
  }

  /* ============================================================================
     2. Tema claro/escuro
     ========================================================================== */

  const CHAVE_TEMA = 'bradesco_validador_emkt_theme';

  function aplicarTema(tema) {
    document.documentElement.setAttribute('data-theme', tema);
    const escuro = tema === 'dark';
    $('#theme-icon-moon').classList.toggle('hidden', escuro);
    $('#theme-icon-sun').classList.toggle('hidden', !escuro);
    $('#theme-label').textContent = escuro ? 'Claro' : 'Escuro';
    try { localStorage.setItem(CHAVE_TEMA, tema); } catch (e) { /* bloqueado: segue */ }
  }

  function ligarTema() {
    const atual = document.documentElement.getAttribute('data-theme') || 'light';
    aplicarTema(atual);
    $('#btn-theme-toggle').addEventListener('click', () => {
      const agora = document.documentElement.getAttribute('data-theme');
      aplicarTema(agora === 'dark' ? 'light' : 'dark');
    });
  }

  /* ============================================================================
     3. Arrastar a pasta
     ========================================================================== */

  let arquivosSelecionados = null;

  function registrarArquivos(lista) {
    arquivosSelecionados = Array.prototype.slice.call(lista);
    const caixa = $('#solta-lista');
    if (!arquivosSelecionados.length) {
      caixa.classList.remove('visivel');
      return;
    }
    const primeiro = arquivosSelecionados[0];
    const relativo = primeiro.caminhoRelativo || primeiro.webkitRelativePath || '';
    const nome = relativo.split('/')[0] || 'pacote';
    // conta as subpastas de primeiro nível: dá uma prévia de quantos pacotes
    // devem sair, antes mesmo de enviar
    const subpastas = new Set();
    arquivosSelecionados.forEach((a) => {
      const partes = (a.caminhoRelativo || a.webkitRelativePath || '').split('/');
      if (partes.length > 2) subpastas.add(partes[1]);
    });
    const previa = subpastas.size > 1
      ? ' · possivelmente ' + subpastas.size + ' pacotes'
      : '';
    caixa.innerHTML = '<b>' + esc(nome) + '</b> · ' + arquivosSelecionados.length +
      ' arquivo(s)' + previa;
    caixa.classList.add('visivel');
  }

  /** Percorre a árvore da pasta arrastada. O input comum só entrega arquivos
   *  soltos; a API de entradas preserva as subpastas, que é onde ficam as
   *  imagens. */
  function percorrer(entrada, caminho, coletados) {
    return new Promise((resolve) => {
      if (entrada.isFile) {
        entrada.file((arquivo) => {
          Object.defineProperty(arquivo, 'caminhoRelativo', { value: caminho });
          coletados.push(arquivo);
          resolve();
        }, resolve);
        return;
      }
      const leitor = entrada.createReader();
      const todos = [];
      const ler = () => leitor.readEntries(async (filhos) => {
        if (!filhos.length) {
          for (const filho of todos) {
            await percorrer(filho, caminho + '/' + filho.name, coletados);
          }
          resolve();
          return;
        }
        todos.push.apply(todos, filhos);
        ler();
      }, resolve);
      ler();
    });
  }

  function ligarArrastar() {
    const area = $('#area-solta');
    const seletor = $('#seletor');

    area.addEventListener('click', () => seletor.click());
    area.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); seletor.click(); }
    });
    seletor.addEventListener('change', (e) => registrarArquivos(e.target.files));

    ['dragenter', 'dragover'].forEach((evento) =>
      area.addEventListener(evento, (e) => { e.preventDefault(); area.classList.add('sobre'); }));
    ['dragleave', 'drop'].forEach((evento) =>
      area.addEventListener(evento, (e) => { e.preventDefault(); area.classList.remove('sobre'); }));

    area.addEventListener('drop', async (e) => {
      const itens = e.dataTransfer && e.dataTransfer.items;
      if (!itens || !itens.length) return;
      const entrada = itens[0].webkitGetAsEntry && itens[0].webkitGetAsEntry();
      if (!entrada || !entrada.isDirectory) {
        toast('Arraste a pasta inteira do pacote, não um arquivo solto.');
        return;
      }
      const coletados = [];
      await percorrer(entrada, entrada.name, coletados);
      registrarArquivos(coletados);
    });
  }

  /* ============================================================================
     4. Envio da conferência
     ========================================================================== */

  let inicioContagem = 0;
  let timerContagem = null;

  function mostrarCarregando(lendoImagens) {
    inicioContagem = Date.now();
    $('#status-area').innerHTML =
      '<div class="status-carregando">' +
        '<span class="pontos" aria-hidden="true"><i></i><i></i><i></i></span>' +
        '<span class="status-texto">' +
          '<span class="status-alvo">' +
            (lendoImagens ? 'Conferindo o pacote e lendo o texto das imagens…'
                          : 'Conferindo o pacote…') +
          '</span>' +
        '</span>' +
        '<span class="cronometro" id="cronometro">0,0s</span>' +
      '</div>';

    clearInterval(timerContagem);
    timerContagem = setInterval(() => {
      const alvo = $('#cronometro');
      if (!alvo) return;
      const s = (Date.now() - inicioContagem) / 1000;
      alvo.textContent = s.toFixed(1).replace('.', ',') + 's';
    }, 100);
  }

  /** Troca só o texto da barra, mantendo o cronômetro correndo. */
  function atualizarCarregando(texto) {
    const alvo = document.querySelector('.status-alvo');
    if (alvo) alvo.textContent = texto;
  }

  function pararCarregando() {
    clearInterval(timerContagem);
    $('#status-area').innerHTML = '';
  }

  function estadoErro(mensagem) {
    return '<div class="estado estado--erro">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" ' +
        'stroke-linecap="round" stroke-linejoin="round">' +
        '<circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><path d="M12 16.5h.01"/></svg>' +
      '<div><strong>Não deu para conferir</strong><p>' + esc(mensagem) + '</p></div></div>';
  }

  async function conferir() {
    const botao = $('#btn-conferir');
    const rotulo = $('#btn-conferir-rotulo');
    const alvo = $('#resultados');
    const usarOcr = $('#usar-ocr').checked;

    if (!arquivosSelecionados || !arquivosSelecionados.length) {
      toast('Escolha ou arraste a pasta primeiro.');
      return;
    }

    botao.disabled = true;
    rotulo.textContent = 'Conferindo…';
    $('#btn-spinner').hidden = false;
    alvo.innerHTML = '';
    mostrarCarregando(usarOcr);

    try {
      const envio = new FormData();
      for (const arquivo of arquivosSelecionados) {
        const relativo = arquivo.caminhoRelativo || arquivo.webkitRelativePath || arquivo.name;
        envio.append('arquivos', arquivo, relativo);
      }
      envio.append('usar_ocr', usarOcr ? 'true' : 'false');
      const seletor = $('#motor');
      if (seletor && seletor.value) envio.append('motor', seletor.value);

      // Lê a resposta conforme ela chega, em vez de esperar o fim: num lote,
      // o primeiro pacote aparece em segundos e já dá para começar a reportar
      // enquanto os outros rodam.
      const resposta = await fetch('/api/conferir-em-fluxo', { method: 'POST', body: envio });
      if (!resposta.ok || !resposta.body) {
        pararCarregando();
        alvo.innerHTML = estadoErro('Falha na conferência.');
        return;
      }

      const leitor = resposta.body.getReader();
      const decodificador = new TextDecoder();
      let sobra = '';
      let recebidos = [];
      let cabecalho = null;

      for (;;) {
        const { done, value } = await leitor.read();
        if (done) break;
        sobra += decodificador.decode(value, { stream: true });
        const linhas = sobra.split('\n');
        sobra = linhas.pop();          // a última pode estar pela metade

        for (const linha of linhas) {
          if (!linha.trim()) continue;
          let evento;
          try { evento = JSON.parse(linha); } catch (e) { continue; }

          if (evento.tipo === 'erro') {
            pararCarregando();
            alvo.innerHTML = estadoErro(evento.erro);
            return;
          }
          if (evento.tipo === 'inicio') {
            cabecalho = evento;
            atualizarCarregando(evento.total > 1
              ? 'Conferindo ' + evento.total + ' pacotes…'
              : 'Conferindo o pacote…');
          }
          if (evento.tipo === 'andamento') {
            atualizarCarregando(
              (cabecalho && cabecalho.total > 1
                ? 'Pacote ' + evento.posicao + ' de ' + cabecalho.total + ': '
                : '') + evento.nome);
          }
          if (evento.tipo === 'pacote') {
            recebidos.push(evento.resultado);
            ultimaConferencia = {
              modo: cabecalho ? cabecalho.modo : 'unico',
              origem: cabecalho ? cabecalho.origem : '',
              total: cabecalho ? cabecalho.total : recebidos.length,
              resultados: recebidos,
              parcial: recebidos.length < (cabecalho ? cabecalho.total : 1),
            };
            renderizar();
          }
          if (evento.tipo === 'falha') {
            recebidos.push({
              id: 'falha-' + recebidos.length, nome_pasta: evento.nome,
              status: 'erro', erros: [evento.erro], observacoes: [],
              imagens: { apontamentos: [], total_pasta: 0, total_chamadas_html: 0 },
              texto: { divergencias: [], similaridade: 0, sem_leitura: [] },
            });
          }
        }
      }

      pararCarregando();
      if (ultimaConferencia) {
        ultimaConferencia.parcial = false;
        renderizar();
      }

      const reprovados = recebidos.filter((r) => r.status === 'reprovado').length;
      if (cabecalho && cabecalho.modo === 'lote') {
        toast(recebidos.length + ' pacotes conferidos · ' + reprovados + ' com divergência.',
              reprovados ? '' : 'ok');
      } else if (reprovados) {
        toast('Divergências encontradas. Veja os apontamentos abaixo.');
      } else {
        toast('Conferência concluída.', 'ok');
      }
    } catch (erro) {
      pararCarregando();
      alvo.innerHTML = estadoErro('Não consegui concluir: ' + erro.message);
    } finally {
      botao.disabled = false;
      rotulo.textContent = 'Conferir';
      $('#btn-spinner').hidden = true;
    }
  }

  /* ============================================================================
     5. Desenho de um pacote
     ========================================================================== */

  // Frases descritivas: a ferramenta relata o que encontrou de diferente entre
  // os arquivos. O que fazer com isso é decisão de quem produziu a campanha.
  const FRASES = {
    aprovado: 'Válida: pode ser anexada no sistema.',
    atencao: 'Pontos para o analista avaliar.',
    parcial: 'O texto do código confere. O que está dentro das imagens não foi conferido.',
    reprovado: 'Divergências encontradas entre o HTML e o CONTEUDO.docx.',
    erro: 'Não foi possível concluir a conferência.',
  };

  const ICONE_OK =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

  /** Mostra o texto com a contagem de caracteres. O limite não é proibitivo,
   *  então o excedente aparece em cinza-alerta, sem alarme. */
  function campoEmail(rotulo, texto, limite) {
    if (!texto) return '';
    const tamanho = texto.trim().length;
    const passou = limite && tamanho > limite;
    return '<div class="campo-email' + (passou ? ' passou' : '') + '">' +
      '<span class="campo-rotulo">' + esc(rotulo) + '</span>' +
      '<span class="campo-valor">' + esc(texto) + '</span>' +
      '<span class="campo-contagem" title="limite de referência: ' + limite +
        ' caracteres">' + tamanho + '/' + limite + '</span>' +
    '</div>';
  }

  function tudoCerto(texto) {
    return '<div class="tudo-certo">' + ICONE_OK + '<span>' + esc(texto) + '</span></div>';
  }

  /* ---- e-mail de devolução: caixa de console ---- */

  const CHAVE_NOME = 'validador.emkt.nome';
  const CHAVE_EMAIL = 'validador.emkt.email';

  function guardado(chave) {
    try { return localStorage.getItem(chave) || ''; } catch (e) { return ''; }
  }
  function guardar(chave, valor) {
    try { localStorage.setItem(chave, valor); } catch (e) { /* sem armazenamento: segue */ }
  }

  /** Mesma regra de serializacao.saudacao_do_horario: antes das 12h bom dia,
   *  até as 18h boa tarde, depois boa noite. */
  function saudacaoDoHorario() {
    const hora = new Date().getHours();
    return hora < 12 ? 'bom dia' : (hora < 18 ? 'boa tarde' : 'boa noite');
  }

  function preencherEmail(modelo, nome, email, validade) {
    return modelo
      .split('{{saudacao}}').join(saudacaoDoHorario())
      .split('{{nome}}').join(nome || '[Nome Funcionário]')
      .split('{{email}}').join(email || '[Email corporativo]')
      .split('{{validade}}').join(validade || 'VAL_ATE_[MM.AA]');
  }

  function desenharConsole(r) {
    const e = r.email_retorno;
    if (!e) return '';
    const sugerido = e.sugerido;   // 'aprovado' | 'ajustes' | ''
    let veredito, classe;
    if (sugerido === 'aprovado') {
      veredito = '✔ VÁLIDA — pode ser anexada no sistema'; classe = 'ok';
    } else if (sugerido === 'ajustes') {
      veredito = '✖ PRECISA DE AJUSTES'; classe = 'ajuste';
    } else {
      veredito = '● CONFERIR ANTES DE RESPONDER'; classe = 'decidir';
    }
    const aviso = sugerido ? '' :
      '<div class="console-aviso">O sistema não fechou o veredito sozinho (veja os ' +
      'pontos em atenção abaixo). Depois de conferir, escolha o e-mail certo:</div>';
    return '<section class="console-retorno" id="' + esc(r.id) + '-console" data-modelo="' +
        esc(sugerido || 'aprovado') + '">' +
      '<div class="console-barra">' +
        '<span class="console-veredito ' + classe + '">' + veredito + '</span>' +
        '<span class="console-espaco"></span>' +
        '<button type="button" data-modelo-btn="aprovado">E-mail: arquivada</button>' +
        '<button type="button" data-modelo-btn="ajustes">E-mail: ajustes</button>' +
        '<button type="button" data-copiar-email>Copiar e-mail</button>' +
      '</div>' + aviso +
      '<div class="console-campos">' +
        '<label>Seu nome<input type="text" data-campo="nome" value="' + esc(guardado(CHAVE_NOME)) + '"></label>' +
        '<label>Seu e-mail corporativo<input type="text" data-campo="email" value="' + esc(guardado(CHAVE_EMAIL)) + '"></label>' +
        '<label>Validade<input type="text" data-campo="validade" placeholder="VAL_ATE_MM.AA" value="' + esc(e.validade || '') + '"></label>' +
      '</div>' +
      '<pre class="console-texto"></pre>' +
    '</section>';
  }

  function atualizarConsole(caixa, r) {
    const e = r.email_retorno;
    const modelo = caixa.dataset.modelo === 'ajustes' ? e.modelo_ajustes : e.modelo_aprovado;
    const valor = (campo) => caixa.querySelector('[data-campo="' + campo + '"]').value.trim();
    caixa.querySelector('.console-texto').textContent =
      preencherEmail(modelo, valor('nome'), valor('email'), valor('validade'));
    caixa.querySelectorAll('[data-modelo-btn]').forEach((b) =>
      b.classList.toggle('ativo', b.dataset.modeloBtn === caixa.dataset.modelo));
  }

  function ligarConsoles(resultados) {
    resultados.forEach((r) => {
      const caixa = document.getElementById(r.id + '-console');
      if (!caixa) return;
      atualizarConsole(caixa, r);
      caixa.querySelectorAll('[data-campo]').forEach((campo) =>
        campo.addEventListener('input', () => {
          if (campo.dataset.campo === 'nome') guardar(CHAVE_NOME, campo.value.trim());
          if (campo.dataset.campo === 'email') guardar(CHAVE_EMAIL, campo.value.trim());
          atualizarConsole(caixa, r);
        }));
      caixa.querySelectorAll('[data-modelo-btn]').forEach((b) =>
        b.addEventListener('click', () => {
          caixa.dataset.modelo = b.dataset.modeloBtn;
          atualizarConsole(caixa, r);
        }));
      caixa.querySelector('[data-copiar-email]').addEventListener('click', async () => {
        const texto = caixa.querySelector('.console-texto').textContent;
        try { await navigator.clipboard.writeText(texto); toast('E-mail copiado.', 'ok'); }
        catch (e) {
          const area = document.createElement('textarea');
          area.value = texto; document.body.appendChild(area); area.select();
          document.execCommand('copy'); area.remove(); toast('E-mail copiado.', 'ok');
        }
      });
    });
  }

  function desenharApontamentosImagem(img) {
    if (!img.apontamentos.length) {
      return tudoCerto('Nomes seguem a quebra, sequência sem furo e todas as imagens aparecem no HTML.');
    }
    return '<ul class="lista-apontamentos">' + img.apontamentos.map((a) =>
      '<li class="apontamento ' + esc(a.gravidade) + '">' +
        '<span class="apontamento-rotulo">' + esc(a.rotulo) + '</span>' +
        esc(a.texto) +
      '</li>').join('') + '</ul>';
  }

  function desenharDivergencias(txt, r) {
    if (!txt.divergencias.length) {
      return tudoCerto('O CONTEUDO.docx e a leitura do HTML têm as mesmas palavras, na mesma ordem.');
    }

    return '<ul class="lista-apontamentos">' + txt.divergencias.map((d, indice) => {
      const ehImagem = /\.(png|jpe?g|gif|webp)$/i.test(d.origem || '');
      const chave = r.id + '|' + indice;

      // O nome da coluna diz de onde veio o texto. "Como está no HTML" dava a
      // entender que era o código; quando a origem é imagem, aquilo é o que a
      // MÁQUINA leu — e é justamente o que pode estar errado.
      const rotuloLeitura = ehImagem
        ? 'O que o sistema leu da imagem'
        : 'O que o sistema leu do código';

      // Sublinha, dentro da citação inteira, exatamente o trecho que diverge.
      // Sem isso a pessoa lia o parágrafo todo procurando onde estava a
      // diferença que o quadro de baixo já tinha apontado.
      const ladoLeitura = destacar(d.citacao_html || d.trecho_html || '',
                                   d.trecho_html, 'marca-divergencia');
      const ladoDocx = destacar(d.citacao_docx || d.trecho_docx || '',
                                d.trecho_docx, 'marca-divergencia');

      const comparacao =
        '<div class="confronto">' +
          '<div class="confronto-lado">' +
            '<span class="confronto-titulo maquina">' + rotuloLeitura + '</span>' +
            '<blockquote>' + (ladoLeitura.html || '—') + '</blockquote>' +
          '</div>' +
          '<div class="confronto-lado">' +
            '<span class="confronto-titulo">Como está no CONTEUDO.docx</span>' +
            '<blockquote>' + (ladoDocx.html || '—') + '</blockquote>' +
          '</div>' +
        '</div>';

      const trechoDiff =
        '<div class="diff">' +
          '<div class="diff-linha html"><span class="diff-tag">Leitura</span>' +
            '<span class="diff-valor">' + (esc(d.trecho_html) || '—') + '</span></div>' +
          '<div class="diff-linha docx"><span class="diff-tag">CONTEUDO</span>' +
            '<span class="diff-valor">' + (esc(d.trecho_docx) || '—') + '</span></div>' +
        '</div>';

      let nota = '';
      if (d.palavras_ausentes) {
        nota = '<p class="nota"><b>Palavras que faltam no docx:</b> <code>' +
          esc(d.palavras_ausentes) + '</code></p>';
      } else if (d.contexto_antes || d.contexto_depois) {
        nota = '<p class="nota">Contexto: <code>' + esc(d.contexto_antes) +
          '</code> … <code>' + esc(d.contexto_depois) + '</code></p>';
      }

      // A imagem ao lado da comparação é a conferência humana: é olhando o
      // banner que se decide se o texto divergente está na peça ou se foi a
      // leitura que errou.
      const painelImagem = ehImagem
        ? '<div class="prova">' +
            '<span class="confronto-titulo">O que está na imagem</span>' +
            '<img src="/preview/' + esc(r.id) + '/imagem/' + encodeURIComponent(d.origem) +
              '" alt="' + esc(d.origem) + '" loading="lazy" class="prova-imagem" ' +
              'data-ampliar="' + esc(d.origem) + '" data-id="' + esc(r.id) + '">' +
            '<span class="prova-dica">clique para ampliar</span>' +
          '</div>'
        : '';

      const acoes =
        '<div class="apontamento-acoes">' +
          '<button type="button" class="prova-link" data-ir-peca="' + esc(r.id) + '" ' +
            'data-alvo="' + esc(d.origem) + '" data-texto="' +
            esc(d.trecho_html || '') + '">ver este ponto na peça</button>' +
          '<label class="conferido">' +
            '<input type="checkbox" class="conferido-marca" data-chave="' + esc(chave) +
              '" data-grave="' + (d.gravidade === 'alta' ? '1' : '0') + '">' +
            '<span>Conferi manualmente — a peça está correta</span>' +
          '</label>' +
        '</div>';

      return '<li class="apontamento ' + esc(d.gravidade) + '" data-tipo="' +
        esc(d.tipo) + '" data-chave="' + esc(chave) + '">' +
        '<div class="apontamento-cabeca">' +
          '<span class="apontamento-rotulo">' + esc(d.rotulo) + '</span>' +
          'em <span class="arquivo">' + esc(d.origem) + '</span>' +
          (d.bloco ? '<span class="marca-bloco">' + esc(d.bloco) + '</span>' : '') +
          (d.tolerado ? '<span class="marca-tolerado">diferença esperada · não reprova</span>' : '') +
          (d.gravidade === 'baixa' && !d.tolerado ? '<span class="marca-tolerado">aviso de diferença · não reprova</span>' : '') +
          (d.motivo_grotesca ? '<span class="marca-bloco">' + esc(d.motivo_grotesca) + '</span>' : '') +
        '</div>' +
        '<div class="apontamento-corpo' + (ehImagem ? ' com-imagem' : '') + '">' +
          painelImagem +
          '<div class="apontamento-texto">' + comparacao + trechoDiff + nota + '</div>' +
        '</div>' +
        acoes +
      '</li>';
    }).join('') + '</ul>';
  }

  function desenhar(r, posicao) {
    if (r.erros && r.erros.length) {
      return '<article class="resultado" data-status="erro">' +
        '<div class="resultado-topo">' +
          '<span class="selo erro">Erro</span>' +
          '<span class="resultado-identidade">' +
            '<span class="resultado-pasta">' + esc(r.nome_pasta) + '</span>' +
          '</span>' +
        '</div>' +
        '<div class="bloco">' + r.erros.map((e) =>
          '<div class="aviso">' + esc(e) + '</div>').join('') + '</div>' +
      '</article>';
    }

    const img = r.imagens;
    const txt = r.texto;
    const parcial = r.modo_texto === 'presenca';

    // Bloqueio abre o resultado: são as regras de publicação do banco, e sem
    // elas a peça não sobe. Vem antes de qualquer divergência de texto.
    const bloqueios = (r.bloqueios && r.bloqueios.length)
      ? '<div class="bloco bloco-bloqueio"><h3>Impede a publicação ' +
        '<span class="qtd">· ' + r.bloqueios.length + '</span></h3>' +
        '<ul class="lista-apontamentos">' + r.bloqueios.map((b) =>
          '<li class="apontamento alta bloqueio">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
              'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/>' +
              '<path d="M12 8v5"/><path d="M12 16.5h.01"/></svg>' +
            '<span>' + esc(b) + '</span></li>').join('') + '</ul></div>'
      : '';

    // Alerta é discreto de propósito: passar do limite de caracteres não
    // proíbe nada, só corta na caixa de entrada de alguns clientes.
    const alertas = (r.alertas && r.alertas.length)
      ? '<p class="alertas-sutis">' + r.alertas.map(esc).join(' · ') + '</p>'
      : '';

    const cabecalhoEmail = (r.assunto || r.pre_header)
      ? '<div class="bloco"><h3>Assunto e pré-header</h3>' +
        '<div class="campos-email">' +
          campoEmail('Assunto', r.assunto, r.limite_assunto) +
          campoEmail('Pré-header', r.pre_header, r.limite_pre_header) +
        '</div>' + alertas + '</div>'
      : '';

    const avisoModo = parcial
      ? '<div class="bloco"><div class="aviso"><b>Conferência parcial.</b> ' +
        'Sem a leitura de imagens, comparei apenas o texto escrito no código do HTML ' +
        'contra o CONTEUDO.docx — ' + txt.blocos_conferidos + ' bloco(s). O texto que ' +
        'está dentro dos banners não entrou na conta, e por isso nada que sobra no docx ' +
        'foi cobrado.</div></div>'
      : '';

    // Arte de conferência que a agência manda junto: não é peça publicada.
    // Aparece como nota para deixar claro que o sistema viu e desconsiderou.
    const apoio = (img.material_de_apoio && img.material_de_apoio.length)
      ? '<p class="nota"><b>Fora da conferência</b> (arte de apoio, não é chamada ' +
        'no código): ' + img.material_de_apoio.map((m) =>
          '<span class="arquivo">' + esc(m[0]) + '</span> — ' + esc(m[1])).join('; ') + '</p>'
      : '';

    const repetidas = Object.keys(img.reaproveitadas || {}).length
      ? '<p class="nota">Reaproveitadas no HTML (permitido): ' +
        Object.keys(img.reaproveitadas).map((n) =>
          esc(n) + ' (' + img.reaproveitadas[n] + 'x)').join(', ') + '</p>'
      : '';

    const correcoes = (txt.correcoes_ocr && txt.correcoes_ocr.length)
      ? '<p class="nota"><b>Corrigido na leitura das imagens</b> (palavra colada ou ' +
        'caractere confundido): ' + txt.correcoes_ocr.map(esc).join('; ') + '</p>'
      : '';

    // A reordenação precisa ficar visível: o sistema mudou a ordem da leitura
    // por conta própria, e quem confere tem direito de saber disso.
    const reordenadas = (txt.imagens_reordenadas && txt.imagens_reordenadas.length)
      ? '<p class="nota"><b>Ordem ajustada pelo CONTEUDO.docx</b> em ' +
        txt.imagens_reordenadas.map((n) =>
          '<span class="arquivo">' + esc(n) + '</span>').join(', ') +
        '. Dentro de uma imagem com blocos não existe ordem de leitura única, ' +
        'então vale a sequência que o docx escreveu. Só acontece quando todo o ' +
        'texto da imagem foi encontrado lá.</p>'
      : '';

    const dispensados = (txt.dispensados && txt.dispensados.length)
      ? '<p class="nota">Ignorado por ser texto de template: ' +
        txt.dispensados.map(esc).join('; ') + '</p>'
      : '';

    const semLeitura = txt.sem_leitura.length
      ? '<div class="bloco"><h3>Imagens não lidas ' +
        '<span class="qtd">· ' + txt.sem_leitura.length + ' de ' + img.total_pasta + '</span></h3>' +
        '<div class="aviso">O texto dentro destas imagens não foi conferido. ' +
        'Confira no olho: ' + txt.sem_leitura.map((s) =>
          '<span class="arquivo">' + esc(s) + '</span>').join(' ') + '</div></div>'
      : '';

    const observacoes = r.observacoes.length
      ? '<div class="bloco"><h3>Observações</h3>' +
        r.observacoes.map((o) => '<div class="aviso">' + esc(o) + '</div>').join('') + '</div>'
      : '';

    // --- mapa lateral: o que existe neste pacote, em números clicáveis ---
    const secoes = [];
    if (r.bloqueios && r.bloqueios.length) {
      secoes.push(['bloqueios', 'Impede a publicação', r.bloqueios.length, 'grave']);
    }
    if (r.assunto || r.pre_header) secoes.push(['email', 'Assunto e pré-header', '', '']);
    secoes.push(['imagens', 'Imagens', img.apontamentos.length,
                 img.apontamentos.length ? 'grave' : 'ok']);
    const graves = txt.divergencias.filter((d) => d.gravidade === 'alta').length;
    secoes.push(['texto', 'Texto', txt.divergencias.length,
                 graves ? 'grave' : (txt.divergencias.length ? 'aviso' : 'ok')]);
    if (r.tem_preview) secoes.push(['comparar', 'Comparar lado a lado', '', '']);
    const quantosAvisos = (txt.sem_leitura.length ? 1 : 0) + r.observacoes.length +
      (r.alertas ? r.alertas.length : 0);
    if (quantosAvisos) secoes.push(['avisos', 'Avisos', quantosAvisos, 'aviso']);

    const mapa =
      '<aside class="resultado-mapa">' +
        '<div class="mapa-topo">' +
          '<span class="selo ' + esc(r.status) + '">' + esc(r.status) + '</span>' +
          '<span class="resultado-pasta">' + esc(r.nome_pasta) + '</span>' +
          (r.quebra ? '<span class="resultado-quebra">quebra: ' + esc(r.quebra) +
            '</span>' : '') +
        '</div>' +
        '<p class="mapa-frase">' + (FRASES[r.status] || '') +
          ((r.status === 'aprovado' && txt.avisos_de_diferenca)
            ? ' ' + txt.avisos_de_diferenca + ' pequena(s) diferença(s) de acento/pontuação, que não reprovam.' : '') +
        '</p>' +
        '<dl class="mapa-numeros">' +
          '<div><dt>imagens</dt><dd>' + img.total_pasta + '</dd></div>' +
          '<div><dt>chamadas</dt><dd>' + img.total_chamadas_html + '</dd></div>' +
          '<div><dt>aderência</dt><dd>' + txt.similaridade + '%</dd></div>' +
          '<div><dt>redirects</dt><dd>' + r.redirects + '</dd></div>' +
        '</dl>' +
        '<nav class="mapa-secoes">' +
          secoes.map(([chave, rotulo, valor, estado]) =>
            '<button type="button" class="mapa-item ' + estado + '" ' +
              'data-secao="' + esc(r.id + '-' + chave) + '">' +
              '<span>' + rotulo + '</span>' +
              (valor === '' ? '' : '<b>' + valor + '</b>') +
            '</button>').join('') +
        '</nav>' +
        '<div class="mapa-rodape">' +
          (r.tem_preview
            ? '<button type="button" class="btn-ghost btn-preview" data-preview="' +
              esc(r.id) + '"><span class="preview-rotulo">Comparar lado a lado</span></button>'
            : '') +
          (r.tem_preview
            ? '<button type="button" class="btn-ghost btn-workbench" data-workbench="' +
              esc(r.id) + '" title="Leva o HTML deste pacote para o editor da aba SFMC ' +
              'Workbench, sem copiar e colar.">Abrir o HTML deste pacote no Workbench</button>'
            : '') +
          '<a class="link-relatorio" href="/relatorio/' + esc(r.id) + '" target="_blank" ' +
            'rel="noopener">Relatório para o chamado</a>' +
          (r.motor_ocr ? '<span class="mapa-motor">leitura por ' + esc(r.motor_ocr) +
            '</span>' : '') +
        '</div>' +
      '</aside>';

    const blocoEmail = (r.assunto || r.pre_header)
      ? '<section class="bloco" id="' + esc(r.id) + '-email"><h3>Assunto e pré-header</h3>' +
        '<div class="campos-email">' +
          campoEmail('Assunto', r.assunto, r.limite_assunto) +
          campoEmail('Pré-header', r.pre_header, r.limite_pre_header) +
        '</div>' + alertas + '</section>'
      : '';

    // Avisos ficam DEPOIS da comparação: eles não impedem nada, e no topo só
    // empurravam para baixo o que a pessoa precisa decidir.
    const blocoAvisos = quantosAvisos
      ? '<section class="bloco bloco-avisos" id="' + esc(r.id) + '-avisos">' +
        '<h3>Avisos <span class="qtd">· não impedem a publicação</span></h3>' +
        semLeitura + observacoes + '</section>'
      : '';

    return '<article class="resultado" id="pacote-' + esc(r.id) + '" data-status="' +
      esc(r.status) + '">' +
      mapa +
      '<div class="resultado-conteudo">' +
        (posicao ? '<span class="resultado-ordem">' + posicao + '</span>' : '') +
        desenharConsole(r) + bloqueios + avisoModo + blocoEmail +
        '<section class="bloco" id="' + esc(r.id) + '-imagens"><h3>Imagens</h3>' +
          desenharApontamentosImagem(img) + repetidas + apoio + '</section>' +
        '<section class="bloco" id="' + esc(r.id) + '-texto"><h3>Texto ' +
          '<span class="qtd">· ' +
          (parcial ? 'só o texto do HTML × CONTEUDO.docx'
                   : 'HTML + imagens × CONTEUDO.docx') + '</span></h3>' +
          desenharDivergencias(txt, r) + reordenadas + correcoes + dispensados +
        '</section>' +
        '<div id="' + esc(r.id) + '-comparar">' + blocoPreview(r) + '</div>' +
        blocoAvisos +
      '</div>' +
    '</article>';
  }



  /* ============================================================================
     6d. Conferência manual e navegação até o ponto
     ========================================================================== */

  /** Divergências que a pessoa já olhou e considerou certas na peça. */
  const conferidos = {};

  function aplicarConferido(marca) {
    const item = marca.closest('.apontamento');
    if (item) item.classList.toggle('ja-conferido', marca.checked);
  }

  /**
   * Mostra quantos apontamentos já passaram pelo olho humano.
   *
   * Num pacote onde a leitura das imagens saiu ruim, a lista de divergências
   * vira fila de trabalho: o contador diz o que falta olhar, e o que já foi
   * olhado não some — fica registrado como verificado.
   */
  function atualizarPlacarConferencia() {
    document.querySelectorAll('.resultado').forEach((cartao) => {
      const marcas = cartao.querySelectorAll('.conferido-marca');
      const feitas = cartao.querySelectorAll('.conferido-marca:checked').length;
      let placar = cartao.querySelector('.placar-conferencia');
      if (!marcas.length) { if (placar) placar.remove(); return; }
      if (!placar) {
        placar = document.createElement('div');
        placar.className = 'placar-conferencia';
        const destino = cartao.querySelector('.mapa-rodape');
        if (destino) destino.insertBefore(placar, destino.firstChild);
      }

      // Só o que reprova precisa de conferência para liberar o pacote; o que
      // já era aviso continua aviso.
      const graves = cartao.querySelectorAll('.conferido-marca[data-grave="1"]');
      const gravesFeitas = cartao.querySelectorAll(
        '.conferido-marca[data-grave="1"]:checked').length;
      const podeLiberar = graves.length > 0 && gravesFeitas === graves.length;
      const jaLiberado = cartao.dataset.liberado === '1';

      let texto = feitas + ' de ' + marcas.length + ' conferidos manualmente';
      if (feitas === marcas.length) {
        texto = '<b>Todos os ' + marcas.length + ' apontamentos conferidos.</b>';
      }
      placar.innerHTML = '<span>' + texto + '</span>' +
        ((podeLiberar && !jaLiberado)
          ? '<button type="button" class="btn-liberar">Confirmar e liberar</button>'
          : '');
      placar.classList.toggle('completo', feitas === marcas.length);

      const acao = placar.querySelector('.btn-liberar');
      if (acao) acao.addEventListener('click', () => liberarPacote(cartao));
    });
  }

  /**
   * Muda o veredito depois que a pessoa conferiu tudo que reprovava.
   *
   * O selo não vira um APROVADO comum: vira "aprovado após conferência". Quem
   * ler o relatório depois precisa saber que a liberação passou por decisão de
   * alguém, e não pela máquina ter achado tudo certo.
   */
  function liberarPacote(cartao) {
    const graves = cartao.querySelectorAll('.conferido-marca[data-grave="1"]');
    const feitas = cartao.querySelectorAll('.conferido-marca[data-grave="1"]:checked');
    if (!graves.length || graves.length !== feitas.length) return;

    cartao.dataset.liberado = '1';
    cartao.dataset.status = 'aprovado';
    const selo = cartao.querySelector('.mapa-topo .selo');
    if (selo) {
      selo.className = 'selo aprovado';
      selo.textContent = 'aprovado após conferência';
    }
    const frase = cartao.querySelector('.mapa-frase');
    if (frase) {
      frase.innerHTML = '<b>Liberado por conferência manual.</b> ' + graves.length +
        ' divergência(s) verificadas por pessoa e consideradas corretas na peça.';
    }
    const caixa = cartao.querySelector('.console-retorno');
    if (caixa) {
      caixa.dataset.modelo = 'aprovado';
      const v = caixa.querySelector('.console-veredito');
      if (v) { v.className = 'console-veredito ok'; v.textContent = '✔ VÁLIDA após conferência — pode ser anexada no sistema'; }
      const botao = caixa.querySelector('[data-modelo-btn="aprovado"]');
      if (botao) botao.click();
    }
    atualizarPlacarConferencia();
    toast('Pacote liberado por conferência manual.', 'ok');
  }

  /**
   * Mostra a imagem em tamanho grande sem sair da página.
   *
   * Abrir em outra aba tirava a pessoa de onde ela está conferindo, e voltar
   * custava perder a rolagem da lista.
   */
  function ampliarImagem(id, nome) {
    let caixa = document.getElementById('lupa');
    if (!caixa) {
      caixa = document.createElement('div');
      caixa.id = 'lupa';
      caixa.className = 'lupa';
      caixa.innerHTML = '<button type="button" class="lupa-fechar" ' +
        'aria-label="Fechar">&times;</button><img alt=""><span class="lupa-nome"></span>';
      document.body.appendChild(caixa);
      const fechar = () => caixa.classList.remove('aberta');
      caixa.addEventListener('click', (e) => { if (e.target === caixa) fechar(); });
      caixa.querySelector('.lupa-fechar').addEventListener('click', fechar);
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fechar(); });
    }
    caixa.querySelector('img').src = '/preview/' + id + '/imagem/' + encodeURIComponent(nome);
    caixa.querySelector('.lupa-nome').textContent = nome;
    caixa.classList.add('aberta');
  }

  /**
   * Leva à posição exata do apontamento dentro da peça.
   *
   * Abrir a peça no topo e mandar procurar não ajudava: em peça de dez
   * banners, achar o trecho é o trabalho todo.
   */
  function irAoPontoNaPeca(id, arquivo, texto) {
    const painel = document.getElementById('preview-' + id);
    if (!painel) return;
    const botao = document.querySelector('[data-preview="' + id + '"]');
    const precisaAbrir = painel.hidden;
    if (precisaAbrir && botao) abrirPreview(id, botao);

    setTimeout(() => {
      const aba = painel.querySelector('[data-vista="peca"]');
      if (aba && !aba.classList.contains('ativa')) aba.click();
      painel.scrollIntoView({ block: 'center', behavior: 'smooth' });
      setTimeout(() => destacarNaPeca(painel, arquivo, texto), 420);
    }, precisaAbrir ? 1100 : 80);
  }

  function destacarNaPeca(painel, arquivo, texto) {
    const quadro = painel.querySelector('iframe');
    if (!quadro) return;
    try {
      const doc = quadro.contentDocument;
      if (!doc) return;
      doc.querySelectorAll('.alvo-validador').forEach((no) =>
        no.classList.remove('alvo-validador'));

      let encontrado = null;
      if (arquivo && /\.(png|jpe?g|gif|webp)$/i.test(arquivo)) {
        const procurado = arquivo.toLowerCase();
        doc.querySelectorAll('img').forEach((img) => {
          const origem = (img.getAttribute('src') || '').toLowerCase();
          if (!encontrado && origem.indexOf(procurado) !== -1) encontrado = img;
        });
      }
      if (!encontrado && texto) {
        const chaveAlvo = chaveDeBusca(texto).slice(0, 40);
        if (chaveAlvo) {
          const percorre = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
          let no;
          while ((no = percorre.nextNode())) {
            if (chaveDeBusca(no.nodeValue).indexOf(chaveAlvo) !== -1) {
              encontrado = no.parentElement;
              break;
            }
          }
        }
      }
      if (!encontrado) return;

      if (!doc.getElementById('estilo-validador')) {
        const estilo = doc.createElement('style');
        estilo.id = 'estilo-validador';
        estilo.textContent =
          '.alvo-validador{outline:3px solid #cc092f !important;' +
          'outline-offset:2px;background:rgba(204,9,47,.08) !important;' +
          'animation:piscaAlvo 1.1s ease-in-out 3}' +
          '@keyframes piscaAlvo{0%,100%{outline-color:#cc092f}50%{outline-color:transparent}}';
        doc.head.appendChild(estilo);
      }
      encontrado.classList.add('alvo-validador');
      encontrado.scrollIntoView({ block: 'center' });
    } catch (e) { /* origem bloqueada: segue sem destacar */ }
  }

  /* ============================================================================
     6c. Painel do lote e ordenação
     ========================================================================== */

  const ORDENACOES = {
    pior:        { rotulo: 'Pior primeiro',        chave: (r) => [-r.apontamentos_graves, -r.total_apontamentos, r.texto.similaridade] },
    aderencia:   { rotulo: 'Menor aderência',      chave: (r) => [r.texto.similaridade, -r.total_apontamentos] },
    apontamento: { rotulo: 'Mais apontamentos',    chave: (r) => [-r.total_apontamentos, r.texto.similaridade] },
    imagens:     { rotulo: 'Imagens com problema', chave: (r) => [-r.imagens.apontamentos.length, r.texto.similaridade] },
    nome:        { rotulo: 'Nome da pasta',        chave: (r) => [String(r.nome_pasta || '').toLowerCase()] },
  };

  function comparar(a, b) {
    const ca = ORDENACOES[ordenacaoAtual].chave(a);
    const cb = ORDENACOES[ordenacaoAtual].chave(b);
    for (let i = 0; i < ca.length; i++) {
      if (ca[i] < cb[i]) return -1;
      if (ca[i] > cb[i]) return 1;
    }
    return 0;
  }

  function painelLote(dados) {
    const lista = dados.resultados;
    const conta = (status) => lista.filter((r) => r.status === status).length;
    const aprovados = conta('aprovado');
    const reprovados = conta('reprovado') + conta('erro');
    const atencao = lista.length - aprovados - reprovados;

    const botoes = Object.keys(ORDENACOES).map((chave) =>
      '<button type="button" class="ordenar' + (chave === ordenacaoAtual ? ' ativa' : '') +
      '" data-ordem="' + chave + '">' + ORDENACOES[chave].rotulo + '</button>').join('');

    return '<section class="panel lote-resumo">' +
      '<div class="lote-cabeca">' +
        '<div>' +
          '<span class="lote-etiqueta">Conferência múltipla</span>' +
          '<h2 class="lote-titulo">' + lista.length +
            (dados.parcial ? ' de ' + dados.total : '') + ' pacotes em ' +
            '<span class="arquivo">' + esc(dados.origem) + '</span>' +
            (dados.parcial ? '<span class="lote-rodando">conferindo…</span>' : '') +
          '</h2>' +
        '</div>' +
        '<div class="lote-placar">' +
          '<span class="placar aprovado"><b>' + aprovados + '</b> aprovado' + (aprovados === 1 ? '' : 's') + '</span>' +
          '<span class="placar atencao"><b>' + atencao + '</b> atenção</span>' +
          '<span class="placar reprovado"><b>' + reprovados + '</b> reprovado' + (reprovados === 1 ? '' : 's') + '</span>' +
        '</div>' +
      '</div>' +
      '<div class="lote-ordenacao"><span class="lote-ordenacao-rotulo">Ordenar por</span>' +
        botoes + '</div>' +
      '<ol class="lote-indice">' +
        lista.slice().sort(comparar).map((r, i) =>
          '<li><a href="#pacote-' + esc(r.id) + '" class="indice-linha" data-status="' + esc(r.status) + '">' +
            '<span class="indice-ordem">' + (i + 1) + '</span>' +
            '<span class="indice-nome">' + esc(r.nome_pasta) + '</span>' +
            '<span class="indice-numero" title="aderência do texto">' + r.texto.similaridade + '%</span>' +
            '<span class="indice-numero" title="apontamentos">' + r.total_apontamentos + ' apont.</span>' +
            '<span class="indice-numero" title="imagens na pasta / chamadas no HTML">' +
              r.imagens.total_pasta + '/' + r.imagens.total_chamadas_html + '</span>' +
            '<span class="selo ' + esc(r.status) + '">' + esc(r.status) + '</span>' +
          '</a></li>').join('') +
      '</ol></section>';
  }

  function cabecaUnica(dados) {
    const r = dados.resultados[0];
    return '<section class="panel unico-resumo">' +
      '<span class="lote-etiqueta unico">Conferência unitária</span>' +
      '<h2 class="lote-titulo">' + esc(r.nome_pasta) + '</h2>' +
      '<p class="nota">Um pacote conferido. Para conferir vários de uma vez, ' +
        'arraste a pasta que guarda os pacotes.</p>' +
    '</section>';
  }

  function renderizar() {
    const dados = ultimaConferencia;
    if (!dados) return;
    const alvo = $('#resultados');

    if (dados.modo === 'lote') {
      const ordenados = dados.resultados.slice().sort(comparar);
      alvo.innerHTML = painelLote(dados) +
        ordenados.map((r, i) => desenhar(r, (i + 1) + ' de ' + dados.total)).join('');
      alvo.querySelectorAll('.ordenar').forEach((botao) =>
        botao.addEventListener('click', () => {
          ordenacaoAtual = botao.dataset.ordem;
          renderizar();
          document.querySelector('.lote-resumo').scrollIntoView({ block: 'start' });
        }));
    } else {
      alvo.innerHTML = cabecaUnica(dados) + desenhar(dados.resultados[0], '');
    }

    ligarConsoles(dados.resultados.filter((r) => !(r.erros && r.erros.length)));

    alvo.querySelectorAll('.btn-preview').forEach((botao) =>
      botao.addEventListener('click', () => abrirPreview(botao.dataset.preview, botao)));
    alvo.querySelectorAll('.btn-workbench').forEach((botao) =>
      botao.addEventListener('click', () => abrirNoWorkbench(botao.dataset.workbench, botao)));

    // o mapa lateral leva direto à seção, e abre a comparação quando é o caso
    alvo.querySelectorAll('.mapa-item').forEach((item) =>
      item.addEventListener('click', () => {
        const destino = document.getElementById(item.dataset.secao);
        if (!destino) return;
        if (item.dataset.secao.endsWith('-comparar')) {
          const painel = destino.querySelector('.preview');
          const botao = alvo.querySelector('[data-preview="' +
            item.dataset.secao.replace('-comparar', '') + '"]');
          if (painel && painel.hidden && botao) botao.click();
        }
        destino.scrollIntoView({ block: 'start', behavior: 'smooth' });
        destino.classList.add('secao-alvo');
        setTimeout(() => destino.classList.remove('secao-alvo'), 1400);
      }));

    alvo.querySelectorAll('[data-ir-peca]').forEach((botao) =>
      botao.addEventListener('click', () =>
        irAoPontoNaPeca(botao.dataset.irPeca, botao.dataset.alvo, botao.dataset.texto)));
    alvo.querySelectorAll('[data-ampliar]').forEach((imagem) =>
      imagem.addEventListener('click', () =>
        ampliarImagem(imagem.dataset.id, imagem.dataset.ampliar)));

    alvo.querySelectorAll('.conferido-marca').forEach((marca) => {
      marca.checked = !!conferidos[marca.dataset.chave];
      aplicarConferido(marca);
      marca.addEventListener('change', () => {
        conferidos[marca.dataset.chave] = marca.checked;
        aplicarConferido(marca);
        atualizarPlacarConferencia();
      });
    });
    atualizarPlacarConferencia();
  }

  /* ============================================================================
     6b. Preview lado a lado
     ========================================================================== */

  /**
   * Abre a peça renderizada e o texto do docx lado a lado, com rolagem.
   *
   * É a conferência do jeito que a pessoa já faz hoje — duas janelas abertas,
   * olho indo de uma para outra. A diferença é que aqui as duas chegam juntas,
   * na mesma tela, sem procurar arquivo.
   */
  async function abrirPreview(id, botao) {
    const painel = document.getElementById('preview-' + id);
    if (!painel) return;

    const aberto = !painel.hidden;
    painel.hidden = aberto;
    botao.classList.toggle('ativo', !aberto);
    botao.querySelector('.preview-rotulo').textContent =
      aberto ? 'Ver peça e CONTEUDO lado a lado' : 'Fechar comparação';
    if (aberto || painel.dataset.carregado === '1') return;

    painel.dataset.carregado = '1';
    const coluna = painel.querySelector('.preview-texto-corpo');
    try {
      const resposta = await fetch('/api/preview/' + id + '/conteudo');
      const dados = await resposta.json();
      coluna.innerHTML = dados.paragrafos.length
        ? dados.paragrafos.map((linha, i) =>
            '<p class="preview-paragrafo" data-indice="' + i + '">' +
            '<span class="preview-numero">' + (i + 1) + '</span>' +
            '<span class="preview-conteudo-texto">' + esc(linha) + '</span></p>').join('')
        : '<p class="nota">O docx não tem parágrafos de texto.</p>';
      painel._dadosDeBusca = painel._dadosDeBusca || { leitura: [], docx: [] };
      painel._dadosDeBusca.docx = dados.paragrafos.slice();

      // clicar no parágrafo joga ele na busca: é o "procurar este trecho na
      // peça" sem precisar selecionar, copiar e colar
      coluna.querySelectorAll('.preview-paragrafo').forEach((no) =>
        no.addEventListener('click', () => {
          const campo = painel.querySelector('.busca-campo');
          campo.value = dados.paragrafos[Number(no.dataset.indice)] || '';
          buscarNoPainel(painel, campo.value);
          trocarParaLeitura(painel);
        }));
    } catch (e) {
      coluna.innerHTML = '<p class="nota">Não consegui carregar o texto do docx.</p>';
    }

    const campoBusca = painel.querySelector('.busca-campo');
    let adiar;
    campoBusca.addEventListener('input', () => {
      clearTimeout(adiar);
      // espera a digitação parar: em texto longo colado, buscar a cada tecla
      // deixaria o campo travado
      adiar = setTimeout(() => buscarNoPainel(painel, campoBusca.value), 160);
    });
    painel.querySelector('.busca-limpar').addEventListener('click', () => {
      campoBusca.value = '';
      buscarNoPainel(painel, '');
      campoBusca.focus();
    });

    painel.querySelectorAll('.preview-aba').forEach((botao) =>
      botao.addEventListener('click', () => {
        trocarVistaPreview(painel, botao.dataset.vista, botao);
        if (botao.dataset.vista === 'leitura') carregarLeitura(id, painel);
      }));

    const quadro = painel.querySelector('iframe');
    // A largura real só é conhecida depois que a peça carrega; até lá vale o
    // palpite padrão, que já evita o salto visual.
    quadro.addEventListener('load', () => agendarAjuste(painel), { once: true });
    quadro.src = '/preview/' + id + '/peca';
    agendarAjuste(painel);
    observarTamanho(painel);
  }

  /**
   * Mede só depois que o navegador terminou o layout.
   *
   * O painel acabou de deixar de ser `hidden`: medir na mesma linha devolve a
   * largura antiga (ou zero) e a peça sai esticada. Dois quadros de espera
   * resolvem — no primeiro o navegador aplica o display, no segundo as medidas
   * já são as definitivas. Era isso que "consertava" ao abrir o inspetor: o
   * DevTools forçava um novo cálculo.
   */
  function agendarAjuste(painel) {
    requestAnimationFrame(() => requestAnimationFrame(() => ajustarEscala(painel)));
  }

  /** Recalcula sempre que a coluna muda de tamanho: janela, zoom, inspetor. */
  function observarTamanho(painel) {
    if (painel.dataset.observado === '1' || typeof ResizeObserver === 'undefined') return;
    painel.dataset.observado = '1';
    const palco = painel.querySelector('.preview-palco');
    if (!palco) return;
    new ResizeObserver(() => {
      if (!painel.hidden) ajustarEscala(painel);
    }).observe(palco);
  }

  /** Palpite inicial, usado só até a peça carregar e informar a largura real. */
  const LARGURA_PADRAO = 700;

  /**
   * Descobre a largura para a qual a peça foi desenhada.
   *
   * Não dá para medir o conteúdo renderizado: HTML de e-mail usa tabela em
   * 100%, que se adapta ao espaço disponível. Medir assim devolvia a largura
   * do próprio iframe — a conta ficava circular e a peça encolhia a cada
   * abertura. A largura de verdade está declarada nos atributos: <table
   * width="700"> ou um max-width no style.
   */
  function larguraDaPeca(quadro) {
    try {
      const doc = quadro.contentDocument;
      if (!doc || !doc.body) return LARGURA_PADRAO;

      const medidas = [];
      doc.querySelectorAll('table, td, div').forEach((el) => {
        const atributo = parseInt(el.getAttribute('width') || '', 10);
        if (atributo > 300) medidas.push(atributo);
        const limite = parseInt((el.style && el.style.maxWidth) || '', 10);
        if (limite > 300) medidas.push(limite);
      });

      if (medidas.length) {
        // a maior largura declarada é o container da peça
        return Math.min(Math.max.apply(null, medidas), 1200);
      }

      // sem largura declarada, mede o conteúdo — com o iframe largo, para a
      // tabela em 100% não devolver a largura do próprio quadro
      const anterior = quadro.style.width;
      quadro.style.width = '1200px';
      const medido = Math.max(doc.body.scrollWidth, doc.documentElement.scrollWidth);
      quadro.style.width = anterior;
      return medido > 300 ? Math.min(medido, 1200) : LARGURA_PADRAO;
    } catch (e) {
      return LARGURA_PADRAO;   // origem bloqueada: usa o padrão
    }
  }

  /**
   * Encolhe a peça para caber na coluna.
   *
   * HTML de e-mail é desenhado numa largura fixa (600 a 900 px). Dentro de meia
   * tela ele apareceria cortado ao meio — justamente a parte da direita, onde
   * costuma estar o valor da oferta. Reduzir a escala mostra a peça inteira,
   * que é o ponto de olhar para ela.
   */
  function ajustarEscala(painel) {
    const palco = painel.querySelector('.preview-palco');
    const quadro = painel.querySelector('iframe');
    if (!palco || !quadro) return;
    const disponivel = palco.clientWidth;
    if (!disponivel) return;   // ainda sem layout: o observador chama de novo
    const largura = larguraDaPeca(quadro);
    const escala = Math.min(1, disponivel / largura);
    quadro.style.width = largura + 'px';
    quadro.style.height = (palco.clientHeight / escala) + 'px';
    quadro.style.transform = 'scale(' + escala.toFixed(3) + ')';
  }

  // rede extra para navegador sem ResizeObserver
  window.addEventListener('resize', () => {
    document.querySelectorAll('.preview:not([hidden])').forEach(agendarAjuste);
  });


  /**
   * Desenha a fita de leitura: o que o sistema entendeu, bloco a bloco.
   *
   * Quando um apontamento não faz sentido, é aqui que se descobre o motivo —
   * se a imagem foi lida errado ou se o docx é que está diferente. Sem isso a
   * leitura da máquina fica invisível, e só resta confiar ou desconfiar.
   */
  async function carregarLeitura(id, painel) {
    const alvo = painel.querySelector('.preview-leitura-corpo');
    if (alvo.dataset.carregado === '1') return;
    alvo.dataset.carregado = '1';
    alvo.innerHTML = '<p class="nota">Carregando…</p>';
    try {
      const resposta = await fetch('/api/preview/' + id + '/leitura');
      const dados = await resposta.json();
      alvo.innerHTML = dados.blocos.map((b) => {
        const imagem = b.tipo === 'imagem';
        const confianca = (imagem && b.confianca)
          ? '<span class="leitura-confianca' + (b.confianca < 80 ? ' baixa' : '') + '">' +
            b.confianca + '%</span>'
          : '';
        const marcaOrdem = b.reordenado
          ? '<span class="leitura-reordenado">ordem do docx</span>' : '';
        const aviso = b.aviso
          ? '<p class="nota leitura-aviso">' + esc(b.aviso) + '</p>' : '';
        const corpo = b.texto
          ? '<div class="leitura-texto">' + esc(b.texto) + '</div>'
          : '<div class="leitura-vazia">— sem texto lido —</div>';
        return '<div class="leitura-bloco' + (imagem ? ' imagem' : '') + '">' +
          '<div class="leitura-cabeca">' +
            '<span class="leitura-origem">' + esc(b.origem) + marcaOrdem + '</span>' +
            confianca +
          '</div>' + corpo + aviso +
        '</div>';
      }).join('') || '<p class="nota">Nada lido.</p>';
      painel._dadosDeBusca = painel._dadosDeBusca || { leitura: [], docx: [] };
      painel._dadosDeBusca.leitura = dados.blocos
        .filter((b) => b.texto).map((b) => b.texto);
      const consultaAtual = painel.querySelector('.busca-campo').value;
      if (consultaAtual) buscarNoPainel(painel, consultaAtual);
    } catch (e) {
      alvo.innerHTML = '<p class="nota">Não consegui carregar a leitura.</p>';
    }
  }

  /**
   * Forma usada para comparar na busca.
   *
   * É aqui que a busca ganha do CTRL+F do Word. Colar um trecho do HTML na
   * caixa do Word leva junto quebra de linha e espaço duplo, e a busca volta
   * 0/0 mesmo com o texto lá. Reduzindo os dois lados a letras e números sem
   * acento, o que sobra é o conteúdo — e aí ele é encontrado.
   */
  function chaveDeBusca(texto) {
    return String(texto || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')   // tira acento
      .replace(/[^a-z0-9%$&]+/g, '');                      // tira pontuação e espaço
  }

  /** Destaca as ocorrências mantendo o texto original visível. */
  function destacar(texto, consulta, classe) {
    const original = String(texto || '');
    const chaveAlvo = chaveDeBusca(consulta);
    if (!chaveAlvo) return { html: esc(original), ocorrencias: 0 };

    // mapeia cada caractere significativo de volta à posição no texto original
    const posicoes = [];
    let reduzido = '';
    for (let i = 0; i < original.length; i++) {
      const pedaco = chaveDeBusca(original[i]);
      if (pedaco) { reduzido += pedaco; posicoes.push(i); }
    }

    let saida = '';
    let cursor = 0;
    let ocorrencias = 0;
    let de = reduzido.indexOf(chaveAlvo);
    while (de !== -1) {
      const inicio = posicoes[de];
      const fim = posicoes[de + chaveAlvo.length - 1];
      saida += esc(original.slice(cursor, inicio));
      saida += '<mark' + (classe ? ' class="' + classe + '"' : '') + '>' +
        esc(original.slice(inicio, fim + 1)) + '</mark>';
      cursor = fim + 1;
      ocorrencias += 1;
      de = reduzido.indexOf(chaveAlvo, de + chaveAlvo.length);
    }
    saida += esc(original.slice(cursor));
    return { html: saida, ocorrencias: ocorrencias };
  }

  /**
   * Procura o trecho nos dois lados ao mesmo tempo.
   *
   * O ponto não é achar: é comparar. Se aparece no CONTEUDO e não aparece na
   * leitura da peça, o texto foi escrito e não publicado. Se aparece só na
   * peça, ficou de fora do docx e o cliente com deficiência visual não recebe.
   */
  function buscarNoPainel(painel, consulta) {
    const dados = painel._dadosDeBusca;
    if (!dados) return;

    const campoVazio = !chaveDeBusca(consulta);
    let achadosLeitura = 0;
    let achadosDocx = 0;

    painel.querySelectorAll('.leitura-texto').forEach((no, i) => {
      const bruto = dados.leitura[i] != null ? dados.leitura[i] : no.textContent;
      const r = destacar(bruto, consulta);
      no.innerHTML = r.html;
      achadosLeitura += r.ocorrencias;
      const bloco = no.closest('.leitura-bloco');
      if (bloco) bloco.classList.toggle('sem-resultado',
        !campoVazio && r.ocorrencias === 0);
    });

    painel.querySelectorAll('.preview-paragrafo').forEach((no, i) => {
      const alvo = no.querySelector('.preview-conteudo-texto');
      if (!alvo) return;
      const bruto = dados.docx[i] != null ? dados.docx[i] : alvo.textContent;
      const r = destacar(bruto, consulta);
      alvo.innerHTML = r.html;
      achadosDocx += r.ocorrencias;
      no.classList.toggle('sem-resultado', !campoVazio && r.ocorrencias === 0);
    });

    const placar = painel.querySelector('.busca-placar');
    painel.querySelector('.busca-limpar').hidden = campoVazio;
    if (campoVazio) { placar.innerHTML = ''; return; }

    const marca = (quantidade, rotulo) =>
      '<span class="busca-marca ' + (quantidade ? 'tem' : 'nao-tem') + '">' +
      rotulo + ': ' + quantidade + '</span>';
    placar.innerHTML = marca(achadosLeitura, 'peça') + marca(achadosDocx, 'CONTEUDO') +
      (achadosLeitura && !achadosDocx
        ? '<span class="busca-alerta">está na peça e não no CONTEUDO</span>' : '') +
      (!achadosLeitura && achadosDocx
        ? '<span class="busca-alerta">está no CONTEUDO e não na peça</span>' : '');
  }

  /** Leva para a aba de leitura, carregando-a se ainda não foi aberta. */
  function trocarParaLeitura(painel) {
    const botao = painel.querySelector('[data-vista="leitura"]');
    if (!botao || botao.classList.contains('ativa')) return;
    botao.click();
  }

  function trocarVistaPreview(painel, vista, botao) {
    painel.querySelectorAll('.preview-aba').forEach((b) =>
      b.classList.toggle('ativa', b === botao));
    const palco = painel.querySelector('.preview-palco');
    const leitura = painel.querySelector('.preview-leitura-corpo');
    const cabeca = painel.querySelector('[data-papel="cabeca-esquerda"]');
    const quadro = painel.querySelector('iframe');
    const ehPeca = vista === 'peca';

    // Guarda onde a peça estava antes de escondê-la. Sem isso ela voltava ao
    // topo a cada troca de aba, e comparar um trecho do meio da peça com a
    // leitura virava um exercício de rolar tudo de novo.
    if (!ehPeca && quadro) {
      try {
        const doc = quadro.contentDocument;
        painel.dataset.rolagemPeca = String(
          (doc.documentElement && doc.documentElement.scrollTop) ||
          (doc.body && doc.body.scrollTop) || 0);
      } catch (e) { /* origem bloqueada: segue sem guardar */ }
    }

    palco.hidden = !ehPeca;
    leitura.hidden = ehPeca;
    cabeca.textContent = ehPeca
      ? 'Peça · ' + (painel.dataset.arquivoHtml || '')
      : 'Leitura do sistema · na ordem do leitor de tela';
    // a escala do iframe é medida com o painel visível; voltando para a peça
    // ela precisa ser refeita
    if (ehPeca) {
      agendarAjuste(painel);
      const guardada = Number(painel.dataset.rolagemPeca || 0);
      if (guardada) {
        // depois do ajuste de escala, que mexe no tamanho do quadro
        requestAnimationFrame(() => requestAnimationFrame(() => {
          try {
            const doc = quadro.contentDocument;
            if (doc.documentElement) doc.documentElement.scrollTop = guardada;
            if (doc.body) doc.body.scrollTop = guardada;
          } catch (e) { /* segue */ }
        }));
      }
    }
  }

  /* Leva o HTML do pacote para o editor da aba SFMC Workbench.
     O servidor devolve o arquivo já decodificado; a aba do Workbench carrega no
     editor de entrada (WB.abrirPeca, em app.js) e fica com o botão Desfazer. */
  function abrirNoWorkbench(id, botao) {
    if (!window.WB || typeof window.WB.abrirPeca !== 'function') {
      toast('O Workbench não carregou. Recarregue a página e tente de novo.');
      return;
    }
    botao.disabled = true;
    fetch('/api/preview/' + encodeURIComponent(id) + '/html')
      .then((resposta) => {
        if (!resposta.ok) throw new Error('HTTP ' + resposta.status);
        return resposta.json();
      })
      .then((dados) => {
        // primeiro mostra a aba: o editor mede o tamanho dele ao aparecer
        const abaWorkbench = document.getElementById('aba-btn-workbench');
        if (abaWorkbench) abaWorkbench.click();
        window.WB.abrirPeca(dados.html, dados.arquivo || 'peca.html');
      })
      .catch(() => toast('Não consegui buscar o HTML deste pacote. Refaça a conferência.'))
      .finally(() => { botao.disabled = false; });
  }

  function blocoPreview(r) {
    if (!r.tem_preview) return '';
    return '<div class="preview" id="preview-' + esc(r.id) + '" hidden ' +
      'data-arquivo-html="' + esc(r.arquivo_html) + '">' +
      '<div class="preview-abas" role="tablist">' +
        '<button type="button" class="preview-aba ativa" data-vista="peca">' +
          'Peça renderizada</button>' +
        '<button type="button" class="preview-aba" data-vista="leitura">' +
          'O que o sistema leu</button>' +
        '<a class="preview-baixar" href="/preview/' + esc(r.id) + '/conteudo-gerado.docx" ' +
          'title="Gera um docx com esta leitura. Serve para montar pacote de teste, ' +
          'não para conferir a peça.">Baixar esta leitura em .docx</a>' +
      '</div>' +
      '<div class="busca-cruzada">' +
        '<svg class="busca-icone" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
          'stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/>' +
          '<path d="m20 20-3.5-3.5"/></svg>' +
        '<input type="search" class="busca-campo" placeholder="Cole ou digite um trecho para procurar nos dois lados" ' +
          'autocomplete="off" spellcheck="false">' +
        '<span class="busca-placar"></span>' +
        '<button type="button" class="busca-limpar" hidden>limpar</button>' +
      '</div>' +
      '<div class="preview-colunas">' +
        '<div class="preview-coluna">' +
          '<div class="preview-cabeca" data-papel="cabeca-esquerda">Peça · ' +
            esc(r.arquivo_html) + '</div>' +
          '<div class="preview-palco">' +
            // sandbox sem allow-scripts: a peça é só para olhar, e HTML de
            // e-mail não deve executar nada dentro da ferramenta
            '<iframe title="Peça renderizada" sandbox="allow-same-origin" loading="lazy"></iframe>' +
          '</div>' +
          '<div class="preview-leitura-corpo" hidden></div>' +
        '</div>' +
        '<div class="preview-coluna">' +
          '<div class="preview-cabeca">Texto · ' + esc(r.arquivo_conteudo) + '</div>' +
          '<div class="preview-texto-corpo"></div>' +
        '</div>' +
      '</div>' +
      '<p class="nota preview-dica">As duas colunas rolam separadamente. ' +
        'A peça abre com as imagens do próprio pacote.</p>' +
    '</div>';
  }

  /* ============================================================================
     7. Motor de leitura de imagens
     ========================================================================== */

  const ICONE_INFO =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" ' +
    'stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/>' +
    '<path d="M12 11v5"/><path d="M12 7.5h.01"/></svg>';

  function consultarMotor() {
    fetch('/api/status-ocr').then((r) => r.json()).then((s) => {
      const barra = $('#barra-motor');

      // Com mais de um motor instalado, a escolha fica na mão de quem confere:
      // cada um erra em imagens diferentes, e só testando nas peças de verdade
      // dá para saber qual serve melhor.
      const disponiveis = s.disponiveis || [];
      if (disponiveis.length > 1) {
        const seletor = $('#motor');
        seletor.innerHTML = disponiveis.map((m) =>
          '<option value="' + esc(m.nome) + '"' + (m.nome === s.motor ? ' selected' : '') +
          '>' + esc(m.descricao) + '</option>').join('');
        $('#opcao-motor').hidden = false;
      }
      // motor velho demais: a leitura falha em silêncio e o apontamento
      // aparece como se fosse erro da peça
      if (s.disponivel && s.aviso_versao) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO + '<span>' + esc(s.aviso_versao) + '</span>';
        return;
      }
      // pediram um motor que não está instalado: dizer isso é mais útil do
      // que mostrar a lista genérica de instalação
      if (s.disponivel && s.aviso_escolha) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO + '<span>' + esc(s.aviso_escolha) +
          ' A leitura está rodando por <b>' + esc(s.descricao) + '</b>.</span>';
        return;
      }
      if (s.disponivel && s.portugues) {
        barra.className = 'barra-motor ativo';
        barra.innerHTML = ICONE_INFO +
          '<span>Leitura do texto das imagens <b>ativa</b> · ' + esc(s.descricao) + '</span>';
        return;
      }
      if (s.disponivel) {
        barra.className = 'barra-motor inativo';
        barra.innerHTML = ICONE_INFO +
          '<span>Leitura ativa por <b>' + esc(s.descricao) + '</b>, mas sem o idioma ' +
          'português — acentos saem imprecisos.' +
          (s.dica_idioma ? '<br>' + esc(s.dica_idioma) : '') + '</span>';
        return;
      }
      const opcoes = (s.motores || []).map((m) =>
        '<li>' + esc(m.descricao) + ' — ' + esc(m.motivo) + '</li>').join('');
      barra.className = 'barra-motor inativo';
      barra.innerHTML = ICONE_INFO +
        '<span>Leitura do texto dentro das imagens <b>indisponível</b>. A conferência ' +
        'roda em modo parcial. Para ativar, basta um destes:<ul>' + opcoes + '</ul></span>';
    }).catch(() => { /* rodapé é informativo: falhar aqui não atrapalha a conferência */ });
  }

  /* ============================================================================
     8. Inicialização
     ========================================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    ligarTema();
    ligarArrastar();
    $('#btn-conferir').addEventListener('click', conferir);
    consultarMotor();
  });
})();
