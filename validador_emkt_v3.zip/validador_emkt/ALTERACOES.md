# Alterações nesta versão (ajuste de rigor + e-mail de devolução)

1. **Só reprova se a peça for realmente diferente.** Acento, vírgula, dois pontos ou
   espaço diferentes entre HTML e CONTEUDO.docx (ex.: `Cartões Digitais:` x `Cartões Digitais`)
   viram **aviso de diferença**: aparecem na tela, não reprovam, não pedem "atenção" e o
   pacote continua **válido para anexar**. Reprova: palavra faltando, trocada ou sobrando,
   imagem errada, letra errada no texto do código, e acento/pontuação **grotescos**.
   Limites em `validador/regras.py` (`LIMITE_ACENTOS_NA_PECA`, `LIMITE_ACENTOS_NO_TRECHO`,
   `LIMITE_PONTUACAO_NA_PECA`). Código: `validador/comparador.py`.
2. **Caixa de console com o e-mail de devolução** em cada pacote (`static/validador.js`,
   `validador/serializacao.py`): válido → e-mail "arquivadas em nosso controle";
   reprovado → e-mail "necessitam de ajustes" com o nome da ação. Saudação pelo horário
   (antes das 12h bom dia, até 18h boa tarde, depois boa noite). Nome e e-mail corporativo
   ficam salvos no navegador; a validade (VAL_ATE_MM.AA) vem do nome da pasta e pode ser editada.
3. 6 testes novos (`--testar`): 48 passam.

---

# Alterações nesta versão

1. **Ponte Validador → Workbench**: botão "Abrir o HTML deste pacote no Workbench" no resultado.
   Rota nova `/api/preview/<id>/html`; no Workbench, `WB.abrirPeca()` (com Desfazer).
   Arquivos: static/validador.js, static/wb/app.js, static/validador.css.
2. **Acentos no OCR**: aviso na tela e no relatório quando o Tesseract está sem `por`.
   Instalador: `python validador_emkt_unificado.py --instalar-idioma-por`
   (usa a pasta do Tesseract; sem permissão, cria `tessdata/` ao lado do script).
   `TESSDATA_URL` aponta para um espelho interno. Com RapidOCR não é preciso. (validador/ocr.py, validador/pacote.py)
3. **Limpeza de relatórios**: ao abrir, apaga os com mais de 30 dias (`DIAS_RELATORIOS=15` muda; `0` desliga).
4. **Cache do OCR**: a versão da leitura é o hash só de `ocr`, `layout` e `normalizacao`. (validador/ocr.py)
5. **Testes do Validador**: 42 casos em `/validador/tests/` e `python validador_emkt_unificado.py --testar`.
   Pacotes reais opcionais em `pacotes_de_teste/PACOTE_APROVADO` e `PACOTE_ERROS`.
