# Verificador de Validade de Pastas

Sistema web simples (HTML + CSS + Python/Flask) que verifica, em uma pasta de
rede, quais subpastas cujo nome começa com **"Val"** têm uma data de validade
**vencida há 3 meses ou mais**.

Este sistema é **somente leitura**: em nenhum momento cria, altera, move ou
exclui arquivos ou pastas. Ele apenas lê a estrutura de diretórios.

## Como a busca funciona (importante)

O sistema entra na pasta de rede informada e **percorre automaticamente
todos os níveis de subpastas** dentro dela — não é preciso que as pastas
"Val..." estejam logo no primeiro nível. Por exemplo, essa estrutura funciona
normalmente:

```
\\servidor\rede\
├── Filial_SP\
│   ├── Val_03.24        ← encontrada
│   └── Val_09.26
├── Filial_RJ\
│   ├── Val_ATE_01.25     ← encontrada
│   └── DocumentosGerais\
└── Filial_MG\
    └── Sub_Nivel_2\
        └── Val_05.20    ← encontrada mesmo em um 3º nível
```

Assim que uma pasta "Val..." é identificada, o sistema não entra no conteúdo
dela (não é necessário e evita varredura desnecessária em pastas de rede
grandes).

A leitura das pastas é feita **em paralelo** (várias pastas lidas ao mesmo
tempo, não uma de cada vez), já que em uma pasta de rede o tempo gasto é
principalmente de latência de rede, não de processamento. Isso reduz bastante
o tempo total em compartilhamentos com muitas pastas. O número de leituras
simultâneas pode ser ajustado em `scanner.py`, na constante
`MAX_LEITURAS_PARALELAS` (padrão: 16).

## Canais (PUSH, EMKT, SMS, IB, NET, ATM, MODAL, CARD, DOCs)

A estrutura da pasta de rede segue o padrão:

```
disponiveis\
└── 12345678 - Nome da Campanha\      ← briefing + nome
    ├── DOCs\      documentos do briefing
    ├── ATM\       atendimento caixa eletrônico
    ├── IB\        internet banking
    ├── NET\       Bradesco Net Empresa
    ├── EMKT\      e-mail marketing
    ├── SMS\
    ├── MODAL\     modais do app
    ├── CARD\      cards do app
    └── PUSH\      mobile push
        └── Val_03.24   ← encontrada, canal = PUSH
```

O reconhecimento não depende da grafia exata: a comparação ignora acentos,
maiúsculas e separadores, então cada canal aceita algumas escritas:

| Canal | Também aceita |
|-------|---------------|
| PUSH  | `Mobile Push`, `App Push` |
| EMKT  | `Email`, `E-mail`, `Email Marketing`, `E-mail Marketing` |
| SMS   | `Torpedo` |
| IB    | `Internet Banking` |
| NET   | `Net Empresa`, `Bradesco Net` |
| ATM   | `Caixa Eletronico`, `Autoatendimento` |
| MODAL | `Modais` |
| CARD  | `Cards` |
| DOCs  | `Doc`, `Documento`, `Documentos` |

Se aparecer uma grafia nova na rede, basta acrescentá-la na constante
`CANAIS`, em `scanner.py` — o restante do sistema (chips, cores, filtros,
exportação) passa a reconhecê-la sozinho.

### Escolher o que será varrido

Na tela de busca há a linha **canais a verificar**. Por padrão todos vêm
marcados; ao desmarcar um canal, ele **nem chega a ser aberto** pelo
servidor. Como o custo de uma pasta de rede é a latência de cada leitura,
buscar só em PUSH é bem mais rápido do que varrer tudo.

A seleção e o último caminho consultado ficam lembrados no navegador, então
a próxima consulta já abre pronta. Se a política do navegador bloquear o
armazenamento local, o programa continua funcionando — só não lembra.

Pastas `Val...` que não estejam dentro de nenhum canal conhecido são
agrupadas em **"Outras pastas"**, que também é selecionável — assim nada
desaparece silenciosamente.

Pela API, o filtro é o parâmetro `canais`, separado por vírgula:

```
/api/scan?path=\\servidor\disponiveis&canais=PUSH,SMS
```

Sem o parâmetro (ou com todos os canais), varre tudo, como antes.

### Filtrar o que já está na tela

Depois da busca, a **barra de distribuição** mostra a proporção de pastas
vencidas em cada canal. Clicar num segmento — ou na legenda abaixo dele —
filtra por aquele canal sem varrer a rede de novo; clicar de novo desfaz.

Ao lado ficam o filtro por texto (atalho `/`, `Esc` limpa), o controle de
gravidade com a contagem de cada faixa e a ordenação (mais vencidas, menos
vencidas, canal, campanha ou nome).

**Exportar Excel**, **Salvar log** e **Copiar caminhos** sempre usam o
recorte que está na tela, e o canal entra no nome do arquivo gerado
(ex.: `pastas-vencidas_push_2026-09-01.xlsx`). Cada resultado traz também a
**campanha** de origem — a pasta de briefing que contém o canal.

### Pastas sem permissão

Quando alguma subpasta não pode ser lida com o seu usuário de rede, a
varredura segue nas demais e os caminhos afetados vão para um bloco
recolhido no **fim da página**, com o total ao lado do título. Ele fica
fechado por padrão: é informação de apoio, não o resultado da busca.

## Regras usadas para identificar as pastas

1. O nome da pasta precisa começar com `Val` (não diferencia maiúsculas de
   minúsculas: `val`, `VAL`, `Val` etc. são aceitos).
2. A validade é a **última ocorrência** de uma data no formato `MM.AA` ou
   `MM.AAAA` encontrada no nome da pasta. Exemplos:
   - `Val_08.26` → validade 08/2026
   - `Val_02.09.26_ATE_11.26` → validade 11/2026 (última ocorrência)
   - `Val_ATE_02.27` → validade 02/2027
3. A pasta só aparece no resultado se a validade estiver vencida há **3 meses
   ou mais**, contando corretamente a virada de ano (ex: validade 11/2025,
   hoje fevereiro/2026 → 3 meses vencida).

## Estrutura do projeto

```
verificador-validade/
├── app.py              # Rotas web e da API (Flask)
├── scanner.py          # Lógica de varredura das pastas (sem dependências web)
├── requirements.txt    # Dependências Python
├── README.md
├── template/           # (ou "templates/" — o app.py aceita os dois nomes)
│   └── index.html      # Página principal
└── static/
    ├── style.css        # Estilo visual
    └── script.js        # Chamada da API e exibição dos resultados
```

## Como executar localmente

### 1. Pré-requisitos
- Python 3.9 ou superior instalado.

### 2. Criar um ambiente virtual (recomendado)

```bash
python -m venv venv
```

Ativar o ambiente:
- **Windows:** `venv\Scripts\activate`
- **Linux/macOS:** `source venv/bin/activate`

### 3. Instalar as dependências

```bash
pip install -r requirements.txt
```

### 4. Executar o sistema

```bash
python app.py
```

### 5. Acessar no navegador

Abra: [http://127.0.0.1:5000](http://127.0.0.1:5000)

Digite o caminho da pasta de rede que deseja verificar, por exemplo:
- Windows: `\\servidor\compartilhamento\pasta`
- Linux/macOS (montagem de rede): `/mnt/rede/pasta`

Clique em **Buscar**. O sistema mostrará uma tabela com nome, validade, meses
vencida e caminho completo de cada pasta encontrada. Os resultados sempre
aparecem na tela; o botão **Salvar log** é opcional e gera, além disso, um
arquivo `.txt` com o mesmo conteúdo, e o botão **Exportar para Excel** gera
uma planilha `.xlsx`.

## Observações importantes

- **Segurança:** por padrão, o servidor roda apenas em `127.0.0.1` (acessível
  só na própria máquina). Só altere para `0.0.0.0` em `app.py` se realmente
  precisar acessar de outros computadores da rede, e com cautela — essa
  ferramenta permite listar caminhos de pastas informados por quem a usa.
- **Erros de acesso:** se alguma subpasta não puder ser lida (permissão
  negada, por exemplo), o sistema continua a varredura nas demais pastas e
  mostra um aviso na tela, em vez de interromper tudo.
- **Caminho inexistente:** se o caminho informado não existir ou não for uma
  pasta, uma mensagem de erro clara é exibida.
