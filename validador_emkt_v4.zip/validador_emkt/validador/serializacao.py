"""
Converte o resultado da conferência em JSON, para a interface web desenhar.
"""

import os
import re
from datetime import datetime

from . import regras


# Rótulos descritivos de propósito. A ferramenta reporta o que está diferente
# entre os dois arquivos; ela não diz qual dos dois está certo nem o que a peça
# deveria conter. Essa decisão é de quem produziu a campanha.
ROTULOS = {
    "faltando": "Está no HTML, não está no CONTEUDO",
    "trocado": "Escrito de forma diferente nos dois",
    "sobrando": "Está no CONTEUDO, não está no HTML",
    "fora_de_ordem": "Mesmas palavras, ordem diferente",
    "acento_pontuacao": "Acento ou pontuação diferente",
    "espacamento": "Mesmo texto, espaçamento diferente",
}

# Nome do bloco onde a divergência caiu — é localização, não julgamento de
# conteúdo: ajuda quem lê o report a achar o trecho na peça.
BLOCOS = {
    "disclaimer": "no bloco de disclaimer",
    "opt-out": "no bloco de descadastro",
    "atendimento": "no bloco de atendimento",
}


def _descricao_do_motor() -> str:
    """
    Qual motor leu as imagens nesta conferência.

    Vai junto no resultado porque cada motor escreve diferente: um devolve
    "você" com acento, outro "voce". Comparar um docx gerado num motor contra
    uma peça lida noutro acusa divergência em cada acento, e sem essa
    informação na tela não há como desconfiar disso.
    """
    from .ocr import motor_ativo

    motor = motor_ativo()
    return motor.descricao if motor else ""


def _rotulo_divergencia(d) -> str:
    if d.tipo != "acento_pontuacao":
        return ROTULOS.get(d.tipo, d.tipo)
    if d.grotesca:
        return "Acento/pontuação diferente em excesso"
    return {
        "acento": "Pequena diferença de acento",
        "pontuacao": "Pequena diferença de pontuação",
    }.get(d.natureza, "Pequena diferença de acento e pontuação")


def _divergencia(d) -> dict:
    rotulo = _rotulo_divergencia(d)
    return {
        "natureza": getattr(d, "natureza", ""),
        "motivo_grotesca": getattr(d, "motivo_grotesca", ""),
        "motivo_leve": getattr(d, "motivo_leve", ""),
        "tipo": d.tipo,
        "rotulo": rotulo,
        "gravidade": d.gravidade,
        "bloco": BLOCOS.get(d.obrigatorio, ""),
        "tolerado": getattr(d, "tolerado", False),
        "obrigatorio": d.obrigatorio,
        "citacao_html": getattr(d, "citacao_html", ""),
        "citacao_docx": getattr(d, "citacao_docx", ""),
        "origem": d.origem,
        "trecho_html": d.trecho_html,
        "trecho_docx": d.trecho_docx,
        "contexto_antes": d.contexto_antes,
        "palavras_ausentes": (d.contexto_antes.replace("palavras ausentes: ", "")
                              if d.contexto_antes.startswith("palavras ausentes:") else ""),
        "contexto_depois": d.contexto_depois,
    }


# ------------------------------------------------- e-mail de devolução ao marketing

RODAPE_EMAIL = (
    "Atenciosamente,\n\n"
    "{{nome}}\n"
    "4832 | CRM\n"
    "{{email}}\n\n"
    "BANCO BRADESCO S.A.\n"
    "Cidade de Deus, Osasco, SP - Prédio Cinza, 1º andar\n\n"
    "Classificação: INTERNA"
)

# {{saudacao}}, {{nome}}, {{email}} e {{validade}} são preenchidos na hora, por
# renderizar_email() aqui ou pelo mesmo trecho em static/validador.js.
MODELO_APROVADO = (
    "Prezados, {{saudacao}}!\n\n"
    "Tudo bem?\n\n"
    "As peças abaixo foram recebidas, verificadas e arquivadas em nosso controle.\n\n"
    "EMKT\n\n"
    "{{validade}}\n\n" + RODAPE_EMAIL
)

MODELO_AJUSTES = (
    "Prezados, {{saudacao}}!\n\n"
    "As peças abaixo necessitam de ajustes:\n\n"
    "EMKT\n"
    "{{acao}}\n\n"
    "{{validade}}\n\n" + RODAPE_EMAIL
)

RE_VALIDADE = re.compile(r"val[\s_\-]*at[eé][\s_\-]*(\d{1,2})[._\-/](\d{2,4})", re.IGNORECASE)


def saudacao_do_horario(agora: datetime | None = None) -> str:
    """Antes das 12h, bom dia; das 12h às 18h, boa tarde; depois, boa noite."""
    hora = (agora or datetime.now()).hour
    if hora < 12:
        return "bom dia"
    if hora < 18:
        return "boa tarde"
    return "boa noite"


def validade_da_pasta(nome_pasta: str) -> str:
    """VAL_ATE_MM.AA tirado do nome da pasta; vazio quando o nome não traz."""
    achado = RE_VALIDADE.search(nome_pasta or "")
    if not achado:
        return ""
    return f"VAL_ATE_{int(achado.group(1)):02d}.{achado.group(2)[-2:]}"


def renderizar_email(modelo: str, nome: str = "", email: str = "", validade: str = "",
                     acao: str = "", agora: datetime | None = None) -> str:
    texto = modelo
    trocas = {
        "{{saudacao}}": saudacao_do_horario(agora),
        "{{nome}}": nome or "[Nome Funcionário]",
        "{{email}}": email or "[Email corporativo]",
        "{{validade}}": validade or "VAL_ATE_[MM.AA]",
        "{{acao}}": acao,
    }
    for chave, valor in trocas.items():
        texto = texto.replace(chave, valor)
    return texto


def _email_retorno(r, status: str) -> dict:
    nome_acao = getattr(r, "nome_pasta", "") or os.path.basename(r.pasta.rstrip("/\\"))
    return {
        # qual e-mail faz sentido: aprovado → arquivadas; reprovado → ajustes;
        # atenção e erro ficam sem sugestão, quem decide é o analista
        "sugerido": {"aprovado": "aprovado", "reprovado": "ajustes"}.get(status, ""),
        "pode_anexar": status == "aprovado",
        "acao": nome_acao,
        "validade": validade_da_pasta(nome_acao),
        "modelo_aprovado": MODELO_APROVADO.replace("{{acao}}", nome_acao),
        "modelo_ajustes": MODELO_AJUSTES.replace("{{acao}}", nome_acao),
    }


def _imagens(ri) -> list[dict]:
    if not ri:
        return []
    itens = []
    add = lambda g, r, t: itens.append({"gravidade": g, "rotulo": r, "texto": t})

    for nome, motivo in ri.fora_da_taxonomia:
        add("alta", "Nome fora do padrão da quebra", f"{nome} — {motivo}")
    if ri.numeros_faltando:
        add("alta", "Numeração com furo",
            "faltam os números " + ", ".join(f"{n:02d}" for n in ri.numeros_faltando))
    if ri.nao_comeca_em_um:
        add("media", "Não começa em 01", "o primeiro número da pasta não é 01")
    if ri.numeros_duplicados:
        add("alta", "Número repetido",
            "o número " + ", ".join(f"{n:02d}" for n in ri.numeros_duplicados)
            + " aparece em mais de um arquivo")
    for nome in ri.extensao_invalida:
        add("media", "Extensão fora do padrão", nome)
    for nome in ri.no_html_fora_da_pasta:
        add("alta", "Chamada no HTML sem arquivo na pasta",
            f"o HTML chama {nome}, que não está na pasta de imagens")
    for nome in ri.na_pasta_fora_do_html:
        add("alta", "Arquivo na pasta sem chamada no HTML",
            f"{nome} está na pasta, mas não aparece no código")
    for na_pasta, no_html in ri.divergencia_de_caixa:
        add("alta", "Maiúscula/minúscula diferente", f"pasta: {na_pasta} · HTML: {no_html}")
    for nome, kb in ri.acima_do_peso:
        add("alta", "Acima de 1 MB",
            f"{nome} tem {kb / 1024:.1f} MB — o limite para publicação é 1 MB")
    for nome in ri.sem_numeracao_zero_a_esquerda:
        add("baixa", "Sem zero à esquerda", f"{nome} — o padrão é 01, 02, 03")
    return itens


def para_json(r, id_relatorio: str = "") -> dict:
    ri, rt = r.resultado_imagens, r.resultado_texto

    observacoes = list(r.avisos)
    for a in r.apontamentos_assunto:
        observacoes.append(f"Pré-header do docx não localizado no HTML: {a.trecho_docx}")
    # Leitura de imagem com confiança baixa: o texto entrou na comparação, mas
    # pode ter caractere errado. Melhor dizer onde a máquina teve dúvida do que
    # deixar passar como se fosse certeza.
    if r.leitura_html:
        incertas = []
        # falha técnica na leitura vem primeiro: é defeito a corrigir, não
        # dúvida sobre o conteúdo da peça
        falhas = []
        for bloco in r.leitura_html.fita:
            if bloco.tipo != "imagem":
                continue
            if getattr(bloco, "ocr_erro", ""):
                marca = f"{bloco.referencia}: {bloco.ocr_erro}"
                if marca not in falhas:
                    falhas.append(marca)
                continue
            if getattr(bloco, "ocr_aviso", ""):
                if "incerta" in bloco.ocr_aviso or "nenhum texto" in bloco.ocr_aviso:
                    marca = f"{bloco.referencia} ({bloco.ocr_aviso})"
                    if marca not in incertas:
                        incertas.append(marca)
        if falhas:
            observacoes.append(
                "Falha ao ler estas imagens (é defeito do sistema, não da peça): "
                + "; ".join(falhas[:4])
            )
        if incertas:
            observacoes.append(
                "Imagens com leitura duvidosa: " + "; ".join(incertas[:5])
            )

    if r.leitura_html and getattr(r.leitura_html, "espacos_irregulares", []):
        amostras = "; ".join(r.leitura_html.espacos_irregulares[:4])
        observacoes.append(
            "Espaço duplicado ou espaço antes de pontuação no texto do HTML "
            f"(não reprova, mas vale revisar): {amostras}"
        )
    if r.leitura_html and r.leitura_html.alts_vazios:
        nomes = ", ".join(r.leitura_html.alts_vazios[:8])
        observacoes.append(f"Imagens sem atributo alt no HTML: {nomes}")

    apontamentos_imagem = _imagens(ri)
    divergencias = [_divergencia(d) for d in rt.divergencias] if rt else []
    total_apontamentos = (len(apontamentos_imagem) + len(divergencias)
                          + len(getattr(r, "bloqueios", [])))
    graves = sum(1 for a in apontamentos_imagem if a["gravidade"] == "alta")
    graves += sum(1 for d in divergencias if d["gravidade"] == "alta")
    graves += len(getattr(r, "bloqueios", []))

    return {
        "id": id_relatorio,
        "total_apontamentos": total_apontamentos,
        "apontamentos_graves": graves,
        "status": r.status,
        "email_retorno": _email_retorno(r, r.status),
        "nome_pasta": getattr(r, "nome_pasta", "") or os.path.basename(r.pasta.rstrip("/\\")),
        "quebra": r.quebra or "",
        "pasta": r.pasta,
        "arquivo_html": os.path.basename(r.caminho_html) if r.caminho_html else "",
        "arquivo_conteudo": os.path.basename(r.caminho_conteudo) if r.caminho_conteudo else "",
        "arquivo_assunto": os.path.basename(r.caminho_assunto) if r.caminho_assunto else "",
        "erros": r.erros,
        "bloqueios": list(getattr(r, "bloqueios", [])),
        "alertas": list(getattr(r, "alertas", [])),
        "redirects": getattr(r.leitura_html, "redirects", 0) if r.leitura_html else 0,
        "assunto": getattr(r.leitura_assunto, "assunto", "") if r.leitura_assunto else "",
        "pre_header": getattr(r.leitura_assunto, "pre_header", "") if r.leitura_assunto else "",
        "limite_assunto": regras.LIMITE_ASSUNTO,
        "limite_pre_header": regras.LIMITE_PRE_HEADER,
        "observacoes": observacoes,
        "ocr_ativo": r.ocr_ativo,
        "motor_ocr": _descricao_do_motor() if r.ocr_ativo else "",
        "modo_texto": getattr(r, "modo_texto", "sequencia"),
        "motivo_ocr": r.motivo_ocr,
        "imagens": {
            "material_de_apoio": ri.material_de_apoio if ri else [],
            "total_pasta": len(ri.arquivos) if ri else 0,
            "total_chamadas_html": ri.total_referencias_html if ri else 0,
            "reaproveitadas": ri.repeticoes_no_html if ri else {},
            "apontamentos": apontamentos_imagem,
        },
        "texto": {
            "similaridade": rt.similaridade if rt else 0,
            "avisos_de_diferenca": sum(1 for d in divergencias if d["gravidade"] == "baixa"),
            "divergencias": divergencias,
            "dispensados": rt.trechos_dispensados if rt else [],
            "sem_leitura": rt.blocos_sem_ocr if rt else [],
            "blocos_conferidos": getattr(rt, "blocos_conferidos", 0) if rt else 0,
            "correcoes_ocr": getattr(rt, "correcoes_ocr", []) if rt else [],
            "imagens_reordenadas": getattr(rt, "imagens_reordenadas", []) if rt else [],
        },
    }
