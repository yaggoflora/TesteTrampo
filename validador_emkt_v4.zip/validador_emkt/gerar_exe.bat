@echo off
rem Gera o executavel .exe do Validador EMKT + SFMC Workbench.
rem Rode UMA vez neste computador (precisa de Python e internet). Demora alguns minutos.
rem Resultado: dist\ValidadorEMKT\ValidadorEMKT.exe  (copie a pasta ValidadorEMKT inteira).
setlocal
cd /d "%~dp0"

set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python nao encontrado. Instale em https://www.python.org/downloads/ e marque "Add python.exe to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv || goto erro
)
".venv\Scripts\python.exe" -m pip install --upgrade pip || goto erro
".venv\Scripts\python.exe" -m pip install flask beautifulsoup4 python-docx pillow rapidocr onnxruntime numpy pytesseract pyinstaller || goto erro

rem As bibliotecas sao importadas de dentro do script, entao o PyInstaller nao as
rem enxerga sozinho: por isso o --collect-all de cada uma.
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --name ValidadorEMKT ^
  --collect-all rapidocr --collect-all onnxruntime --collect-all docx ^
  --collect-all bs4 --collect-all flask --collect-all pytesseract ^
  --hidden-import PIL.Image --hidden-import PIL.ImageOps --hidden-import PIL.ImageFilter ^
  --hidden-import PIL.ImageEnhance --hidden-import PIL.ImageSequence --hidden-import numpy ^
  validador_emkt_unificado.py || goto erro

echo.
echo Pronto: dist\ValidadorEMKT\ValidadorEMKT.exe
echo Para usar, de duplo clique no ValidadorEMKT.exe (a janela preta fica aberta enquanto o programa roda).
pause
exit /b 0

:erro
echo.
echo Algo deu errado. Confira a conexao com a internet e rode de novo.
pause
exit /b 1
