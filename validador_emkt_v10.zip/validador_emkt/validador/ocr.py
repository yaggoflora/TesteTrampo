"""
Leitura do texto contido nas imagens.

Três motores, testados em cascata. O sistema usa o primeiro que estiver
disponível na máquina, sem você precisar configurar nada:

  1. windows   — OCR nativo do Windows 10/11. Não instala binário nenhum:
                 o motor já faz parte do sistema operacional e o idioma
                 português normalmente já vem junto. Só precisa do pacote
                 Python `winocr`. É o caminho de menor atrito em máquina
                 corporativa, porque não há software novo para homologar.

  2. rapidocr  — modelos ONNX que vêm dentro do próprio pacote pip (~16 MB).
                 Roda offline depois de instalado, não precisa de binário
                 externo nem de privilégio de administrador. É o plano B
                 quando o item 1 não estiver disponível.

  3. tesseract — o mais conhecido, mas exige instalar um programa separado.
                 Aceita também versão portátil: aponte a variável de ambiente
                 TESSERACT_CMD para o executável e não precisa de instalador.

Para forçar um motor específico, defina a variável OCR_MOTOR com "windows",
"rapidocr" ou "tesseract".
"""

import os
import re
import threading
import unicodedata
from dataclasses import dataclass, field

from .normalizacao import limpar


@dataclass
class ResultadoOCR:
    arquivo: str
    texto: str = ""
    lido: bool = False
    erro: str = ""
    aviso: str = ""
    motor: str = ""
    confianca_media: float = 0.0
    linhas: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- utilidades

def _preparar(caminho: str, largura_minima: int = 0):
    """
    Abre a imagem e corrige orientação.

    O aumento de escala NÃO acontece aqui: quem amplia é o fatiamento, já com
    a faixa recortada. Ampliar duas vezes só borra a letra.
    """
    from PIL import Image, ImageOps

    img = Image.open(caminho)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    if largura_minima and img.width < largura_minima:
        fator = largura_minima / img.width
        # LANCZOS de propósito: o padrão do resize borra a borda das letras e o
        # motor passa a inventar caractere — "Simular agora" virava "Simular a
        # agora" num upscale de apenas 1,1x.
        img = img.resize(
            (int(img.width * fator), int(img.height * fator)), Image.LANCZOS
        )
    return img


MAXIMO_FRAMES_LIDOS = 10
# Fração mínima de pixels que precisa mudar para o frame contar como cena nova.
# Média de diferença não serve aqui: em banner de fundo claro, trocar a frase
# inteira mexe em poucos por cento dos pixels e a média mal se move.
MUDANCA_MINIMA_ENTRE_FRAMES = 0.01   # 1% dos pixels
DIFERENCA_POR_PIXEL = 40             # 0-255: o quanto um pixel precisa mudar


def _assinatura(imagem):
    """Miniatura em cinza usada só para comparar frames entre si."""
    from PIL import Image
    return list(imagem.convert("L").resize((64, 64), Image.BILINEAR).getdata())


def _frames_relevantes(caminho: str) -> list:
    """
    Escolhe quais frames de um GIF vale a pena ler.

    Um GIF de peça costuma ter dezenas de frames para poucas cenas de texto:
    ler todos custaria mais de um minuto por imagem sem acrescentar nada. Aqui
    só entram os frames que mudaram de verdade em relação ao último lido, e no
    máximo dez — o suficiente para pegar todas as cenas de uma peça de e-mail.
    """
    from PIL import Image, ImageSequence

    imagem = Image.open(caminho)
    total = getattr(imagem, "n_frames", 1)
    if total <= 1:
        return [imagem.convert("RGB")]

    escolhidos, ultima = [], None
    for quadro in ImageSequence.Iterator(imagem):
        atual = quadro.convert("RGB")
        assinatura = _assinatura(atual)
        if ultima is not None:
            mudados = sum(
                1 for a, b in zip(assinatura, ultima)
                if abs(a - b) > DIFERENCA_POR_PIXEL
            )
            if mudados / len(assinatura) < MUDANCA_MINIMA_ENTRE_FRAMES:
                continue
        escolhidos.append(atual.copy())
        ultima = assinatura
        if len(escolhidos) >= MAXIMO_FRAMES_LIDOS:
            break
    return escolhidos or [imagem.convert("RGB")]


def _juntar_textos(blocos: list[str]) -> str:
    """
    Junta o texto das cenas do GIF sem repetir o que já apareceu.

    Dois tipos de repetição acontecem aqui. A primeira é a frase que se repete
    em frames vizinhos — basta descartar a igual. A segunda é a animação de
    digitação, em que a mesma frase entra aos pedaços: "COMPROMISSO", depois
    "e TRANSPA", depois "e TRANSPARENCIA com sua empresa". Guardar todos os
    pedaços encheria a fita de fragmentos que não existem no docx, então fica
    só a versão mais completa de cada frase.
    """
    from .normalizacao import tokenizar

    candidatos = []
    for bloco in blocos:
        for linha in bloco.splitlines():
            limpa = linha.strip()
            chave = "".join(tokenizar(limpa))   # sem espaços: o OCR varia neles
            if not chave:
                continue
            candidatos.append((chave, limpa))

    # descarta o que está contido em outra linha — o pedaço da animação
    finais = []
    for chave, texto in candidatos:
        contido_em_outro = any(
            chave != outra and chave in outra for outra, _ in candidatos
        )
        if contido_em_outro:
            continue
        if any(chave == vista for vista, _ in finais):
            continue
        finais.append((chave, texto))

    return "\n".join(texto for _, texto in finais)


# O detector do motor encolhe a imagem inteira para caber em cerca de 960 px no
# lado maior. Peça de e-mail é uma tira alta e estreita: uma fatia de 900x2600
# é reduzida a 900x960 e o texto de 20 px vira 7 px — ilegível. Ler em faixas
# preserva a resolução do texto.
ALTURA_MAXIMA_POR_FATIA = 900
SOBREPOSICAO_ENTRE_FATIAS = 120   # px repetidos, para não cortar linha no meio
ALTURA_MINIMA_DO_TEXTO = 26       # abaixo disso o reconhecimento erra caractere
CONFIANCA_PARA_ALERTAR = 80       # abaixo disso a imagem entra em Observações

# Letra miúda não entra na leitura. Escrita em cartão ("MasterCard" e os números
# dele), ícone pequeno, estampa de camisa, selo: é parte da foto ou do desenho,
# não é texto que o redator coloca no CONTEUDO.docx, e ler isso só gera
# diferença que não existe. A altura da caixa é medida como se a peça tivesse
# LARGURA_DE_REFERENCIA px (o padrão do GUIDE), para valer igual em imagem 1x e 2x.
# Para ler tudo de novo, ponha IGNORAR_LETRAS_MIUDAS = False.
IGNORAR_LETRAS_MIUDAS = True
ALTURA_MINIMA_LETRA_PX = 14       # altura da caixa de texto, na escala de 700 px
LARGURA_DE_REFERENCIA = 700


# Peça de e-mail é cheia de ícone e pictograma — calendário, cadeado, cifrão,
# selo. O detector não sabe distinguir desenho de letra: ele acha uma forma
# parecida com texto e o reconhecedor devolve o palpite mais próximo. O
# calendário desta campanha virava "口" numa escala e "D000 000" na outra.
# Formatos que aparecem de verdade em peça e que NÃO têm letra nenhuma. Eles
# costumam ser o dado mais importante da imagem — o percentual da oferta, a
# data da estreia, o telefone da central — e não podem ser descartados por
# falta de letra.
RE_CONTEUDO_SEM_LETRA = re.compile(r"""
      ^\d{1,3}\s?%$                                   # 50%   20 %
    | ^\d{1,2}[/.\-]\d{1,2}([/.\-]\d{2,4})?[:.]?$     # 10/09:  03/09/2026
    | ^R?\$?\s?\d{1,3}([.\s]\d{3})*([,]\d{2})?$      # R$ 50.000,00
    | ^\d{3,5}[\s-]?\d{3,4}$                          # 4002 0022 · 0800 570
    | ^\d{1,3}\s?[xX]$                                # 36x
    | ^\d{1,2}[hH]$                                    # 22h
    | ^[+\-]?\d{1,4}[.,]\d{1,2}$                      # 1,29
""", re.VERBOSE)

# Dígito ou símbolo repetido é assinatura de contorno de ícone lido como texto:
# "000", "0 0000 000", "...."
RE_REPETICAO_BOBA = re.compile(r"^([\W\d_])[\s]*(\1[\s]*)+$")

CONFIANCA_MINIMA_SEM_LETRA = 88


def _como_numero(valor, padrao: float = 0.0) -> float:
    """
    Converte para número o que o motor devolveu como confiança.

    Versões diferentes do RapidOCR entregam esse campo de jeitos diferentes:
    umas como float, outras como string ("0.98"). Comparar string com número
    quebra a leitura inteira da imagem, e o erro aparece como "sem texto lido"
    — parecendo falha do OCR quando é só um tipo diferente.
    """
    if isinstance(valor, (int, float)):
        return float(valor)
    try:
        return float(str(valor).strip().replace(",", "."))
    except (TypeError, ValueError):
        return padrao


def _tem_letra(texto: str) -> bool:
    return any(c.isalpha() for c in texto)


def _fora_do_alfabeto(texto: str) -> bool:
    """Caractere que não existe em peça escrita em português."""
    for caractere in texto:
        if caractere.isalpha() and not ("a" <= caractere.lower() <= "z"):
            # letra acentuada é latina; CJK, cirílico e afins não são
            if unicodedata.name(caractere, "").startswith("LATIN"):
                continue
            return True
        if unicodedata.category(caractere) == "So":   # símbolo/pictograma
            return True
    return False


def _e_ruido_de_icone(texto: str, confianca) -> bool:
    """
    Diz se a caixa é desenho lido como texto.

    Descartar é mais seguro do que manter: um ícone fantasma entra na
    comparação como palavra inventada e vira apontamento que ninguém consegue
    resolver, porque não existe nada para corrigir na peça.
    """
    limpo = str(texto or "").strip()
    confianca = _como_numero(confianca)
    if not limpo:
        return True
    if _fora_do_alfabeto(limpo):
        return True

    # Repetição do mesmo caractere vem antes de tudo: "000" casaria como valor
    # monetário e escaparia do filtro, mas é contorno de ícone.
    if not _tem_letra(limpo) and RE_REPETICAO_BOBA.match(limpo):
        return True

    # Percentual, data, valor e telefone ficam, custe o que custar: é o dado
    # mais importante da imagem. Descartá-los por confiança apagava justamente
    # o "50%" da oferta e o "10/09:" da estreia.
    if RE_CONTEUDO_SEM_LETRA.match(limpo.replace("  ", " ")):
        return False

    if _tem_letra(limpo):
        return len(limpo) <= 2 and confianca < CONFIANCA_MINIMA_SEM_LETRA

    # sem letra e sem formato reconhecível: só passa com confiança alta
    return confianca < CONFIANCA_MINIMA_SEM_LETRA


# ----------------------------------------------- leitura em várias variantes
#
# O pipeline clássico de OCR (aquisição, pré-processamento, detecção, extração,
# classificação, pós-processamento) trata o pré-processamento como etapa
# própria — e é justamente a que estava faltando aqui. Peça de e-mail varia
# demais: texto branco sobre foto, título fino sobre fundo claro, bloco
# pequeno em cima de gradiente. Nenhum preparo único serve para todos.
#
# Em vez de escolher um, lê-se a mesma fatia em algumas variantes e funde-se o
# resultado, ficando com a melhor leitura de cada região. É o mesmo princípio
# de combinar classificadores: cada variante erra em lugares diferentes.

LIMIAR_ESCURA = 110          # abaixo disso a imagem é escura e vale inverter
SOBREPOSICAO_MESMA_CAIXA = 0.55


def _luminancia_media(imagem) -> float:
    import numpy as np
    from PIL import ImageOps
    return float(np.array(ImageOps.grayscale(imagem)).mean())


def _variantes_de_leitura(imagem, completa: bool):
    """
    Versões da mesma fatia para ler em paralelo.

    Na leitura rápida vai só o original. Quando ele vem fraco — pouca coisa
    lida ou confiança baixa — entram as outras, que custam tempo mas resgatam
    texto que o preparo padrão perde.
    """
    from PIL import ImageFilter, ImageOps

    saida = [("original", imagem)]
    if not completa:
        return saida

    # Texto claro sobre fundo escuro: o detector foi treinado sobretudo em
    # texto escuro sobre claro, e inverter devolve a polaridade esperada.
    if _luminancia_media(imagem) < LIMIAR_ESCURA:
        invertida = ImageOps.invert(ImageOps.grayscale(imagem)).convert("RGB")
        saida.append(("invertida", invertida))

    saida.append(("contraste", ImageOps.autocontrast(imagem, cutoff=1)))
    saida.append(("nitidez", imagem.filter(
        ImageFilter.UnsharpMask(radius=2, percent=140, threshold=3))))
    return saida


def _leitura_fraca(caixas: list, fatia) -> bool:
    """
    Decide se a fatia merece uma segunda passada com pré-processamento.

    O limiar é baixo de propósito. Medindo contra o gabarito, as variantes de
    pré-processamento NÃO reduziram o erro das peças testadas e dobraram o
    tempo: o que restava de divergência era acento, que o reconhecedor não
    emite e a comparação já ignora dos dois lados. Então elas ficam como
    resgate — fatia que não devolveu nada, ou devolveu com confiança baixa
    demais para merecer crédito.
    """
    if not caixas:
        return True
    confianca = sum(c["confianca"] for c in caixas) / len(caixas)
    return confianca < 78


def _mesma_regiao(a: dict, b: dict) -> bool:
    """Diz se duas caixas cobrem o mesmo pedaço da imagem."""
    largura = min(a["direita"], b["direita"]) - max(a["esquerda"], b["esquerda"])
    altura = min(a["base"], b["base"]) - max(a["topo"], b["topo"])
    if largura <= 0 or altura <= 0:
        return False
    intersecao = largura * altura
    area_a = max(1.0, (a["direita"] - a["esquerda"]) * (a["base"] - a["topo"]))
    area_b = max(1.0, (b["direita"] - b["esquerda"]) * (b["base"] - b["topo"]))
    return intersecao / min(area_a, area_b) >= SOBREPOSICAO_MESMA_CAIXA


def _fundir_leituras(leituras: list) -> list:
    """
    Junta as caixas das variantes, ficando com a melhor leitura de cada região.

    Região que só uma variante enxergou entra assim mesmo — é texto que as
    outras perderam. Região vista por várias fica com a de maior confiança;
    empatando, com a que leu mais caracteres, porque o erro típico do motor é
    cortar o fim da frase, não inventar.
    """
    final: list = []
    for caixas in leituras:
        for caixa in caixas:
            for indice, escolhida in enumerate(final):
                if not _mesma_regiao(caixa, escolhida):
                    continue
                atual = (escolhida["confianca"], len(escolhida["texto"]))
                nova = (caixa["confianca"], len(caixa["texto"]))
                if nova > atual:
                    final[indice] = caixa
                break
            else:
                final.append(caixa)
    return final


def _realcar(imagem):
    """
    Realça a faixa para uma segunda tentativa.

    Texto branco sobre área clara da foto — céu, parede, fachada — tem contraste
    baixo e o detector simplesmente não acha a caixa. Esticar o histograma e
    reforçar a borda das letras costuma resolver, e só roda quando a primeira
    leitura não achou nada, então não pesa no caso comum.
    """
    from PIL import ImageEnhance, ImageFilter, ImageOps

    realcada = ImageOps.autocontrast(imagem.convert("RGB"), cutoff=1)
    realcada = ImageEnhance.Contrast(realcada).enhance(1.6)
    return realcada.filter(ImageFilter.UnsharpMask(radius=2, percent=140, threshold=2))


def _fatias_da_imagem(imagem) -> list[tuple]:
    """Divide a imagem em faixas horizontais com sobreposição."""
    largura, altura = imagem.size
    limite = max(ALTURA_MAXIMA_POR_FATIA, largura)
    if altura <= limite:
        return [(imagem, 0)]

    passo = limite - SOBREPOSICAO_ENTRE_FATIAS
    fatias, topo = [], 0
    while topo < altura:
        base = min(altura, topo + limite)
        fatias.append((imagem.crop((0, topo, largura, base)), topo))
        if base >= altura:
            break
        topo += passo
    return fatias


def _caixas_em_fatias(motor, imagem, idioma: str, confianca_minima: int):
    """
    Lê a imagem em faixas e devolve as caixas já com a posição real.

    A sobreposição faz a mesma linha aparecer em duas faixas; a deduplicação
    compara texto e posição para não repetir o trecho na leitura final.
    """
    from PIL import Image

    todas = []
    # Fatiar resolve o encolhimento do detector antigo. O detector novo lê a
    # peça alta inteira e, em fatia, junta colunas vizinhas numa caixa só —
    # aí a análise de layout fica sem corredor para separar.
    if getattr(motor, "prefere_imagem_inteira", False):
        fatias = [(imagem, 0)]
    else:
        fatias = _fatias_da_imagem(imagem)
    for fatia, deslocamento in fatias:
        # o reconhecimento erra caractere quando a letra fica pequena demais;
        # ampliar a faixa antes de ler recupera "50%" que virava "SOVO"
        escala = 1.0
        if fatia.width < 1400:
            escala = min(2.5, 1400 / fatia.width)
            fatia = fatia.resize(
                (int(fatia.width * escala), int(fatia.height * escala)), Image.LANCZOS
            )
        def ler(variantes):
            leituras = []
            for _, variante in variantes:
                try:
                    caixas = motor.caixas(variante, idioma, confianca_minima)
                except Exception:
                    continue
                for caixa in caixas:
                    for campo in ("topo", "base", "esquerda", "direita", "confianca"):
                        caixa[campo] = _como_numero(caixa.get(campo, 0))
                leituras.append([c for c in caixas
                                 if not _e_ruido_de_icone(c["texto"],
                                                          c.get("confianca", 0))])
            return _fundir_leituras(leituras)

        achadas = ler(_variantes_de_leitura(fatia, completa=False))

        # Só vale pagar o preço das variantes quando a leitura simples veio
        # fraca — em peça bem comportada elas não acrescentam nada e triplicam
        # o tempo.
        if _leitura_fraca(achadas, fatia):
            achadas = ler(_variantes_de_leitura(fatia, completa=True))
        if not achadas:
            try:
                tentativa = motor.caixas(_realcar(fatia), idioma, confianca_minima)
            except Exception:
                tentativa = []
            tentativa = [c for c in tentativa
                         if not _e_ruido_de_icone(c["texto"], c.get("confianca", 0))]
            # o realce força o detector a achar forma onde não há texto: só
            # vale a tentativa se ela trouxer palavra de verdade
            if any(len(re.findall(r"[^\W\d_]{3,}", c["texto"])) for c in tentativa):
                achadas = tentativa
        for caixa in achadas:
            caixa["topo"] = caixa["topo"] / escala + deslocamento
            caixa["base"] = caixa["base"] / escala + deslocamento
            caixa["esquerda"] = caixa["esquerda"] / escala
            caixa["direita"] = caixa["direita"] / escala
            todas.append(caixa)

    miudas = 0
    if IGNORAR_LETRAS_MIUDAS and todas:
        todas, miudas = _sem_letra_miuda(todas, imagem.width)
    return _remover_repetidas(todas), len(fatias), miudas


def _sem_letra_miuda(caixas: list[dict], largura_imagem: int):
    """
    Tira as caixas de texto pequenas demais para serem texto da peça.

    Devolve (caixas que ficam, quantas foram descartadas). A altura da caixa é
    convertida para a escala de LARGURA_DE_REFERENCIA, então uma imagem em 2x
    (1400 px) e uma em 1x (700 px) usam o mesmo critério.
    """
    fator = LARGURA_DE_REFERENCIA / largura_imagem if largura_imagem else 1.0
    ficam = []
    for caixa in caixas:
        altura = (caixa["base"] - caixa["topo"]) * fator
        if altura < ALTURA_MINIMA_LETRA_PX:
            continue
        ficam.append(caixa)
    return ficam, len(caixas) - len(ficam)


def _remover_repetidas(itens: list[dict]) -> list[dict]:
    """Descarta caixas duplicadas pela sobreposição entre faixas vizinhas."""
    limpos = []
    for item in sorted(itens, key=lambda i: (i["topo"], i["esquerda"])):
        texto = item["texto"].strip()
        if not texto:
            continue
        repetida = False
        for anterior in limpos:
            if anterior["texto"].strip() != texto:
                continue
            if abs(anterior["topo"] - item["topo"]) < 24 and \
                    abs(anterior["esquerda"] - item["esquerda"]) < 24:
                # fica a leitura de maior confiança
                if item.get("confianca", 0) > anterior.get("confianca", 0):
                    anterior.update(item)
                repetida = True
                break
        if not repetida:
            limpos.append(item)
    return limpos


def _ordenar_linhas(itens: list[dict]) -> list[str]:
    """
    Reconstrói a ordem visual de leitura: de cima para baixo, da esquerda para
    a direita.

    Os motores devolvem caixas soltas, e duas palavras da mesma linha vêm
    separadas. Agrupar por faixa de altura fixa não funciona — título grande e
    rodapé miúdo precisam de tolerâncias diferentes. Aqui duas caixas entram na
    mesma linha quando se sobrepõem verticalmente em mais da metade da altura
    da menor delas, que é o critério que uma pessoa usaria olhando a peça.
    """
    validos = [i for i in itens if i["texto"].strip()]
    if not validos:
        return []

    for item in validos:
        item.setdefault("base", item["topo"] + item.get("altura", 10))
        item.setdefault("direita", item["esquerda"])

    # Separa a peça em blocos pelo desenho dela e monta as linhas DENTRO de
    # cada bloco. Agrupar por faixa de altura na peça inteira junta dois
    # cartões lado a lado numa linha só — "03/09: 24/09:" — e cada data perde
    # o filme a que pertence.
    from .layout import descrever_blocos

    saida: list[str] = []
    for bloco in descrever_blocos(validos):
        if bloco.caixas:
            saida.extend(_linhas_de_um_bloco(bloco.caixas))
    return saida


def _linhas_de_um_bloco(validos: list[dict]) -> list[str]:
    """Monta as linhas de texto dentro de um bloco já isolado."""
    validos = sorted(validos, key=lambda r: (r["topo"], r["esquerda"]))

    linhas: list[list[dict]] = []
    for item in validos:
        encaixou = False
        # Chamada de nota é uma caixa minúscula e assentada acima da linha:
        # ela mal encosta no texto ao lado. Com o mesmo critério das palavras
        # normais ela virava uma linha só dela, e o "2" de "36x²" acabava
        # solto, longe da palavra a que pertence.
        curta = len(item["texto"].strip()) <= 2
        for linha in linhas:
            topo_linha = min(c["topo"] for c in linha)
            base_linha = max(c["base"] for c in linha)
            sobreposicao = min(base_linha, item["base"]) - max(topo_linha, item["topo"])
            menor_altura = min(base_linha - topo_linha, item["base"] - item["topo"])
            # A ordenação é por topo, e a chamada de nota fica ACIMA da linha:
            # ela chega primeiro e vira âncora. Por isso o limiar reduzido vale
            # também quando é a linha existente que é só a marca de nota.
            linha_curta = all(len(c["texto"].strip()) <= 2 for c in linha)
            limiar = 0.15 if (curta or linha_curta) else 0.5
            if menor_altura > 0 and sobreposicao > menor_altura * limiar:
                linha.append(item)
                encaixou = True
                break
        if not encaixou:
            linhas.append([item])

    linhas.sort(key=lambda l: min(c["topo"] for c in l))
    saida = []
    for linha in linhas:
        linha.sort(key=lambda c: c["esquerda"])
        saida.append(_montar_linha(linha))
    return saida


RE_CHAMADA_DE_NOTA = re.compile(r"^[0-9]{1,2}$|^\*{1,3}$")


def _montar_linha(caixas: list[dict]) -> str:
    """
    Junta as caixas de uma linha, colando a chamada de nota na palavra anterior.

    O motor devolve o "2" de "CDB²" como uma caixa separada, e juntar tudo com
    espaço produziria "CDB 2". O docx traz "CDB2", porque o Word cola o
    sobrescrito — a diferença viraria apontamento em toda peça com nota de
    rodapé, que em banco é praticamente toda peça.

    O que identifica a chamada: texto de um ou dois dígitos (ou asterisco),
    caixa visivelmente menor que a anterior e assentada mais alto que ela.
    """
    partes = []
    anterior = None
    vistos_na_linha = []
    for caixa in caixas:
        texto = caixa["texto"].strip()
        if not texto:
            continue
        colar = False
        if anterior is not None and RE_CHAMADA_DE_NOTA.match(texto):
            altura = caixa["base"] - caixa["topo"]
            altura_anterior = anterior["base"] - anterior["topo"]
            distancia = caixa["esquerda"] - anterior.get("direita", anterior["esquerda"])
            mais_alta = caixa["topo"] < anterior["topo"]
            menor = altura_anterior > 0 and altura < altura_anterior * 0.8
            perto = distancia < altura_anterior * 0.8
            colar = menor and mais_alta and perto
        # A sobreposição entre faixas faz a mesma frase ser lida duas vezes, e
        # o acento muda entre as leituras ("Seducäo" e "Seducao"), então o
        # descarte por texto idêntico não pega. Comparar sem acento pega.
        assinatura = unicodedata.normalize("NFD", texto.lower())
        assinatura = "".join(c for c in assinatura
                             if unicodedata.category(c) != "Mn" and c.isalnum())
        if assinatura and assinatura in vistos_na_linha:
            continue
        if assinatura:
            vistos_na_linha.append(assinatura)

        partes.append(("" if colar else " ") + texto if partes else texto)
        anterior = caixa
    return "".join(partes)


# ------------------------------------------------------------------- motores

class MotorBase:
    # Fatiar a peça em faixas resolve o encolhimento do detector antigo, mas o
    # detector novo lê a imagem alta inteira e, em fatia, mistura colunas
    # vizinhas numa caixa só. Cada motor diz o que funciona para ele.
    prefere_imagem_inteira = False

    nome = ""
    descricao = ""

    def disponivel(self) -> tuple[bool, str]:
        raise NotImplementedError

    def caixas(self, imagem, idioma: str, confianca_minima: int) -> list[dict]:
        """Devolve as caixas de texto detectadas, com posição e confiança."""
        raise NotImplementedError

    def ler(self, caminho: str, idioma: str, confianca_minima: int) -> ResultadoOCR:
        nome_arquivo = os.path.basename(caminho)
        try:
            imagem = _preparar(caminho)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        try:
            itens, fatias, miudas = _caixas_em_fatias(self, imagem, idioma, confianca_minima)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        linhas = _ordenar_linhas(itens)
        confiancas = [i["confianca"] for i in itens if i.get("confianca")]
        media = round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0

        avisos = []
        if fatias > 1:
            avisos.append(f"lida em {fatias} faixas")
        if not linhas and miudas:
            # só havia letra miúda (cartão, ícone, estampa): não é falha de leitura
            avisos.append("só letra miúda na imagem (ignorada)")
        elif not linhas:
            avisos.append("nenhum texto encontrado nesta imagem")
        elif media and media < CONFIANCA_PARA_ALERTAR:
            # transparência sobre o que a máquina não teve certeza de ler:
            # é melhor apontar a dúvida do que deixar passar como certo
            avisos.append(f"leitura incerta ({media:.0f}% de confiança), vale conferir no olho")
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome, aviso="; ".join(avisos),
            confianca_media=media,
        )


class MotorWindows(MotorBase):
    """OCR embutido no Windows. Nenhum programa novo para instalar."""

    nome = "windows"
    descricao = "OCR nativo do Windows"

    def disponivel(self):
        if os.name != "nt":
            return False, "só funciona no Windows"
        try:
            import winocr  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install winocr"
        return True, "ok"

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import winocr

        tag = {"por": "pt-BR", "eng": "en-US"}.get(idioma, idioma)
        try:
            resultado = winocr.recognize_pil_sync(imagem, tag)
        except Exception:
            # idioma não instalado no Windows: cai para o padrão do sistema
            resultado = winocr.recognize_pil_sync(imagem)

        linhas_brutas = (resultado.get("lines") if isinstance(resultado, dict)
                         else getattr(resultado, "lines", None))

        itens = []
        for linha in (linhas_brutas or []):
            if isinstance(linha, dict):
                texto = linha.get("text", "")
                palavras = linha.get("words", []) or []
                caixa = palavras[0].get("bounding_rect", {}) if palavras else {}
                topo, esquerda = caixa.get("y", 0), caixa.get("x", 0)
                altura, largura = caixa.get("height", 10), caixa.get("width", 10)
                if palavras:
                    ultima = palavras[-1].get("bounding_rect", {})
                    largura = max(largura, ultima.get("x", 0) + ultima.get("width", 0) - esquerda)
            else:
                texto = getattr(linha, "text", "") or ""
                palavras = getattr(linha, "words", []) or []
                topo = esquerda = 0
                altura = largura = 10
                if palavras:
                    caixa = getattr(palavras[0], "bounding_rect", None)
                    if caixa is not None:
                        topo = getattr(caixa, "y", 0)
                        esquerda = getattr(caixa, "x", 0)
                        altura = getattr(caixa, "height", 10)
                        largura = getattr(caixa, "width", 10)
            if not texto.strip():
                continue
            itens.append({
                "texto": texto, "topo": topo, "base": topo + altura,
                "esquerda": esquerda, "direita": esquerda + largura,
                "confianca": 0.0,   # o Windows não devolve confiança por linha
            })
        return itens


# Abaixo disso o motor usa modelos antigos: sigla curta e texto pequeno passam
# despercebidos, e a confiança vem como texto em vez de número.
VERSAO_MINIMA_RAPIDOCR = (1, 4, 0)


def _versao_instalada(pacote: str):
    try:
        from importlib.metadata import version
        partes = version(pacote).split(".")[:3]
        return tuple(int("".join(c for c in p if c.isdigit()) or 0) for p in partes)
    except Exception:
        return None


# O ThreadPoolExecutor de ler_imagem chama _obter() de várias threads ao mesmo
# tempo. Sem trava, duas delas viam o leitor vazio e iniciavam o RapidOCR duas
# vezes (carrega os modelos ONNX duas vezes e uma instância se perde).
_TRAVA_RAPIDOCR = threading.Lock()


class MotorRapidOCRNovo(MotorBase):
    """
    O RapidOCR atual, publicado sob o nome `rapidocr` (3.x).

    O projeto trocou de nome: `rapidocr-onnxruntime` parou na 1.4.4, que exige
    Python abaixo do 3.13. Quem está num Python mais novo não consegue instalar
    nada além da 1.2.3 — uma versão de 2023, com modelos três gerações atrás,
    que perde sigla curta e texto pequeno sem avisar.

    O pacote novo acompanha o Python atual e traz o PP-OCRv6. É o preferido
    quando existe; o antigo continua atendido para quem já o tem instalado.
    """

    nome = "rapidocr"
    descricao = "RapidOCR (modelos embutidos, sem instalar programa)"
    prefere_imagem_inteira = True

    def __init__(self):
        self._leitor = None

    def disponivel(self) -> tuple[bool, str]:
        try:
            import rapidocr  # noqa: F401
        except ImportError:
            return False, 'falta o pacote Python: pip install rapidocr'
        return True, "pronto"

    def _obter(self):
        if self._leitor is None:
            with _TRAVA_RAPIDOCR:
                # confere de novo já com a trava: outra thread pode ter
                # terminado a inicialização enquanto esta esperava
                if self._leitor is None:
                    import logging

                    from rapidocr import RapidOCR
                    # a biblioteca fala muito no terminal a cada leitura; aqui o
                    # que interessa é o resultado
                    for registro in ("RapidOCR", "rapidocr"):
                        logging.getLogger(registro).setLevel(logging.ERROR)

                    # A detecção, no ajuste padrão, estica a caixa até engolir a
                    # coluna vizinha: "50%" e "na poltrona D-BOX" saíam numa caixa
                    # só, e aí a análise de layout não tinha o que separar. Com a
                    # expansão fixada, cada trecho volta a ter caixa própria.
                    try:
                        self._leitor = RapidOCR(params={"Det.unclip_ratio": 1.6})
                    except Exception:
                        self._leitor = RapidOCR()
        return self._leitor

    def caixas(self, imagem, idioma: str = "por", confianca_minima: int = 40):
        import numpy as np

        resultado = self._obter()(np.array(imagem.convert("RGB")))
        textos = getattr(resultado, "txts", None) or []
        pontos = getattr(resultado, "boxes", None)
        notas = getattr(resultado, "scores", None) or []
        if pontos is None or not len(textos):
            return []

        limite = confianca_minima / 100
        itens = []
        for caixa, texto, nota in zip(pontos, textos, notas):
            confianca = _como_numero(nota)
            if confianca < limite:
                continue
            coordenadas = [(_como_numero(p[0]), _como_numero(p[1])) for p in caixa]
            itens.append({
                "texto": str(texto or ""),
                "topo": min(p[1] for p in coordenadas),
                "base": max(p[1] for p in coordenadas),
                "esquerda": min(p[0] for p in coordenadas),
                "direita": max(p[0] for p in coordenadas),
                "confianca": confianca * 100,
            })
        return itens


class MotorRapidOCR(MotorBase):
    """Modelos ONNX que vêm no próprio pacote pip. Offline, sem binário."""

    nome = "rapidocr-antigo"
    descricao = "RapidOCR 1.x (pacote antigo rapidocr-onnxruntime)"
    _motor = None

    def disponivel(self):
        try:
            import rapidocr_onnxruntime  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install rapidocr-onnxruntime"
        return True, "ok"

    def _obter(self):
        if MotorRapidOCR._motor is None:
            with _TRAVA_RAPIDOCR:
                if MotorRapidOCR._motor is None:
                    from rapidocr_onnxruntime import RapidOCR
                    MotorRapidOCR._motor = RapidOCR()
        return MotorRapidOCR._motor

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import numpy as np

        saida, _ = self._obter()(np.array(imagem.convert("RGB")))
        if not saida:
            return []

        limite = confianca_minima / 100
        itens = []
        for registro in saida:
            caixa, texto, confianca = registro[0], registro[1], registro[2]
            confianca = _como_numero(confianca)
            if confianca < limite:
                continue
            pontos = [(_como_numero(p[0]), _como_numero(p[1])) for p in caixa]
            itens.append({
                "texto": str(texto or ""),
                "topo": min(p[1] for p in pontos),
                "base": max(p[1] for p in pontos),
                "esquerda": min(p[0] for p in pontos),
                "direita": max(p[0] for p in pontos),
                "confianca": confianca * 100,
            })
        return itens


def pasta_de_idiomas_local() -> str:
    """Pasta tessdata ao lado do script, onde --instalar-idioma-por guarda o idioma."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "tessdata")


def _usar_pasta_de_idiomas_local() -> None:
    """
    Aponta o Tesseract para a pasta tessdata ao lado do script, se ela tiver o português.

    Gravar na pasta de instalação do Tesseract pede administrador no Windows; a
    pasta local não pede. TESSDATA_PREFIX definido pela própria pessoa sempre vence.
    """
    if os.environ.get("TESSDATA_PREFIX"):
        return
    pasta = pasta_de_idiomas_local()
    if os.path.isfile(os.path.join(pasta, "por.traineddata")):
        os.environ["TESSDATA_PREFIX"] = pasta


def _pasta_de_idiomas_do_tesseract() -> str:
    """Pasta onde o Tesseract procura os idiomas, lida da saída dele. Vazio se não achar."""
    import shutil
    import subprocess

    try:
        import pytesseract
        comando = pytesseract.pytesseract.tesseract_cmd or "tesseract"
    except ImportError:
        comando = "tesseract"

    try:
        saida = subprocess.run([comando, "--list-langs"], capture_output=True,
                               text=True, timeout=20)
        texto = (saida.stdout or "") + "\n" + (saida.stderr or "")
        achado = re.search(r'languages\s+in\s+"([^"]+)"', texto)
        if achado and os.path.isdir(achado.group(1)):
            return achado.group(1)
    except Exception:
        pass

    # o Tesseract 4 não diz a pasta: tenta a que fica ao lado do executável
    caminho = shutil.which(comando) or comando
    ao_lado = os.path.join(os.path.dirname(os.path.abspath(caminho)), "tessdata")
    return ao_lado if os.path.isdir(ao_lado) else ""


class MotorTesseract(MotorBase):
    """Tesseract. Aceita instalação normal ou versão portátil via TESSERACT_CMD."""

    nome = "tesseract"
    descricao = "Tesseract"

    def disponivel(self):
        try:
            import pytesseract
        except ImportError:
            return False, "falta o pacote Python: pip install pytesseract"
        _usar_pasta_de_idiomas_local()
        if os.environ.get("TESSERACT_CMD"):
            pytesseract.pytesseract.tesseract_cmd = os.environ["TESSERACT_CMD"]
        try:
            pytesseract.get_tesseract_version()
        except Exception:
            return False, "o programa Tesseract não foi encontrado na máquina"
        return True, "ok"

    def idiomas(self):
        try:
            import pytesseract
            return list(pytesseract.get_languages(config=""))
        except Exception:
            return []

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import pytesseract
        from PIL import ImageOps

        disponiveis = self.idiomas()
        if disponiveis and idioma not in disponiveis:
            idioma = "eng" if "eng" in disponiveis else disponiveis[0]

        preparada = ImageOps.autocontrast(ImageOps.grayscale(imagem))
        dados = pytesseract.image_to_data(
            preparada, lang=idioma, output_type=pytesseract.Output.DICT, config="--psm 6"
        )

        agrupadas: dict[tuple, dict] = {}
        for i, palavra in enumerate(dados["text"]):
            palavra = palavra.strip()
            if not palavra:
                continue
            try:
                confianca = float(dados["conf"][i])
            except (ValueError, TypeError):
                confianca = -1
            if confianca < confianca_minima:
                continue
            chave = (dados["block_num"][i], dados["par_num"][i], dados["line_num"][i])
            registro = agrupadas.setdefault(chave, {
                "texto": "", "topo": dados["top"][i], "esquerda": dados["left"][i],
                "base": dados["top"][i] + dados["height"][i],
                "direita": dados["left"][i] + dados["width"][i],
                "confianca": confianca, "soma": 0.0, "quantidade": 0,
            })
            registro["texto"] = (registro["texto"] + " " + palavra).strip()
            registro["esquerda"] = min(registro["esquerda"], dados["left"][i])
            registro["base"] = max(registro["base"], dados["top"][i] + dados["height"][i])
            registro["direita"] = max(registro["direita"],
                                      dados["left"][i] + dados["width"][i])
            registro["soma"] += confianca
            registro["quantidade"] += 1

        for registro in agrupadas.values():
            if registro["quantidade"]:
                registro["confianca"] = registro["soma"] / registro["quantidade"]
        return list(agrupadas.values())


# A ordem é a preferência quando nenhum motor foi escolhido à mão.
#
# RapidOCR vem primeiro por dois motivos. Ele reporta a confiança de cada
# leitura — sem isso o sistema não consegue avisar "leitura duvidosa" nem
# descartar ruído de ícone, que são duas defesas importantes. E, nas peças
# testadas, errou menos: onde o motor do Windows devolveu "Estreias
# deseeerpbro", ele leu "Estreias de setembro".
#
# O do Windows continua disponível e tem uma vantagem real: acentua certo,
# porque tem português nativo. Vale testar os dois nas suas peças e fixar o
# melhor com a variável OCR_MOTOR.
MOTORES = [MotorRapidOCRNovo(), MotorRapidOCR(), MotorWindows(), MotorTesseract()]
_ESCOLHIDO = None
_DIAGNOSTICO = None


def aviso_de_versao() -> str:
    """
    Alerta quando o motor instalado é velho demais para as peças daqui.

    Vale a pena gastar uma linha na tela com isso: com uma versão antiga a
    leitura falha em silêncio — o texto some e o apontamento aparece como se
    fosse erro da peça. Já aconteceu de levar um dia para descobrir.
    """
    motor = motor_ativo()
    if not motor or motor.nome != "rapidocr-antigo":
        return ""
    instalada = _versao_instalada("rapidocr-onnxruntime")
    if not instalada or instalada >= VERSAO_MINIMA_RAPIDOCR:
        return ""
    atual = ".".join(str(n) for n in instalada)
    return (f"A leitura está usando o RapidOCR {atual}, de 2023 — ela perde "
            "sigla curta e texto pequeno dentro das imagens, sem avisar. "
            "O projeto mudou de nome e o pacote atual acompanha o Python novo. "
            "Instale com: python -m pip install rapidocr")


def diagnosticar() -> list[dict]:
    """Estado de cada motor, para a tela mostrar o que falta instalar."""
    global _DIAGNOSTICO
    if _DIAGNOSTICO is None:
        _DIAGNOSTICO = []
        for motor in MOTORES:
            ok, motivo = motor.disponivel()
            _DIAGNOSTICO.append({
                "nome": motor.nome, "descricao": motor.descricao,
                "disponivel": ok, "motivo": motivo,
            })
    return _DIAGNOSTICO


# motor escolhido na tela, válido só para a conferência em curso
_FORCADO_NA_TELA = ""
_AVISO_DE_ESCOLHA = ""


def aviso_de_escolha() -> str:
    """Explica por que o motor em uso não é o que foi pedido."""
    return _AVISO_DE_ESCOLHA


def forcar_motor(nome: str) -> None:
    """Fixa o motor para as próximas leituras. Vazio volta à preferência padrão."""
    global _FORCADO_NA_TELA, _ESCOLHIDO
    nome = (nome or "").strip().lower()
    if nome != _FORCADO_NA_TELA:
        _FORCADO_NA_TELA = nome
        _ESCOLHIDO = None        # refaz a escolha na próxima leitura


def motores_disponiveis() -> list[dict]:
    return [d for d in diagnosticar() if d["disponivel"]]


def motor_ativo():
    """Escolhe o motor: o forçado à mão, ou o primeiro disponível da lista."""
    global _ESCOLHIDO
    if _ESCOLHIDO is not None:
        return _ESCOLHIDO or None

    global _AVISO_DE_ESCOLHA
    _AVISO_DE_ESCOLHA = ""

    forcado = (_FORCADO_NA_TELA
               or (os.environ.get("OCR_MOTOR") or "").strip().lower())

    if forcado:
        pedido = next((m for m in MOTORES if m.nome == forcado), None)
        if pedido is None:
            _AVISO_DE_ESCOLHA = (
                f"O motor \u201c{forcado}\u201d não existe. "
                f"Use um destes: {', '.join(m.nome for m in MOTORES)}."
            )
        else:
            ok, motivo = pedido.disponivel()
            if ok:
                _ESCOLHIDO = pedido
                return pedido
            # Pedir um motor que não está instalado não pode desligar a leitura
            # inteira: o certo é usar o que existe e dizer por que não foi o
            # escolhido. Desligar em silêncio faz parecer defeito do sistema.
            _AVISO_DE_ESCOLHA = (
                f"Você pediu o motor \u201c{forcado}\u201d, mas ele não está "
                f"disponível ({motivo})."
            )

    for motor in MOTORES:
        ok, _ = motor.disponivel()
        if ok:
            _ESCOLHIDO = motor
            return motor
    _ESCOLHIDO = False
    return None


def ocr_disponivel() -> tuple[bool, str]:
    motor = motor_ativo()
    if motor:
        aviso = aviso_de_escolha()
        if aviso:
            return True, f"{aviso} Usando {motor.descricao}."
        return True, f"{motor.descricao} ativo"
    faltas = "; ".join(f"{d['nome']}: {d['motivo']}" for d in diagnosticar())
    return False, f"nenhum motor de leitura disponível ({faltas})"


def idiomas_instalados() -> list[str]:
    motor = motor_ativo()
    if isinstance(motor, MotorTesseract):
        return motor.idiomas()
    if motor:
        return ["por"]  # Windows e RapidOCR cobrem o alfabeto latino
    return []


COMANDO_IDIOMA_POR = "python validador_emkt_unificado.py --instalar-idioma-por"


def aviso_de_idioma() -> str:
    """
    Aviso para quando o motor em uso é o Tesseract e falta o português.

    Sem o idioma, o Tesseract cai para o inglês e perde os acentos, e cada
    palavra acentuada vira divergência falsa contra o docx. Vazio quando não
    há o que avisar (outro motor, ou Tesseract com o idioma).
    """
    motor = motor_ativo()
    if not isinstance(motor, MotorTesseract):
        return ""
    if "por" in motor.idiomas():
        return ""
    return (
        "O Tesseract está sem o idioma português, então os acentos saem errados "
        "na leitura das imagens. Para instalar, feche o programa e rode: "
        f"{COMANDO_IDIOMA_POR}. Outra saída é o RapidOCR (python -m pip install "
        "rapidocr), que não precisa de pacote de idioma."
    )


# Idiomas "fast" do projeto oficial do Tesseract: pequenos (cerca de 1 MB o
# português) e suficientes para texto de peça. TESSDATA_URL aponta para um
# espelho interno quando a rede da empresa bloqueia o github.com.
URL_IDIOMAS_TESSERACT = "https://github.com/tesseract-ocr/tessdata_fast/raw/main"
TAMANHO_MINIMO_DE_IDIOMA = 200_000    # abaixo disso o download veio uma página de erro


def _baixar_idioma(url_base: str, idioma: str, pasta: str, minimo_bytes: int) -> None:
    import shutil
    import urllib.request

    destino = os.path.join(pasta, f"{idioma}.traineddata")
    parcial = destino + ".parte"
    pedido = urllib.request.Request(
        f"{url_base.rstrip('/')}/{idioma}.traineddata",
        headers={"User-Agent": "validador-emkt"},
    )
    try:
        with urllib.request.urlopen(pedido, timeout=90) as resposta, \
                open(parcial, "wb") as saida:
            shutil.copyfileobj(resposta, saida)
        if os.path.getsize(parcial) < minimo_bytes:
            raise OSError(f"o arquivo de {idioma} veio pequeno demais, "
                          "provavelmente não é o idioma")
        os.replace(parcial, destino)
    finally:
        if os.path.exists(parcial):
            os.remove(parcial)


def instalar_idioma_por(imprimir=print, destino=None, url_base=None,
                        minimo_bytes: int = TAMANHO_MINIMO_DE_IDIOMA) -> bool:
    """
    Instala o idioma português (por.traineddata) do Tesseract. True se deu certo.

    Primeiro tenta a pasta de idiomas do próprio Tesseract. Sem permissão de
    escrita (comum no Windows, em Arquivos de Programas), guarda numa pasta
    tessdata ao lado do script e passa a usá-la sozinho nas próximas aberturas.
    A pasta local vira a única que o Tesseract enxerga, por isso leva junto o
    inglês.

    `destino` e `url_base` existem para os testes.
    """
    url_base = url_base or os.environ.get("TESSDATA_URL") or URL_IDIOMAS_TESSERACT

    if destino is None:
        motor = MotorTesseract()
        disponivel, motivo = motor.disponivel()
        if not disponivel:
            imprimir(f"Não dá para instalar o idioma: {motivo}.")
            imprimir("O idioma só importa para o Tesseract. Com o RapidOCR "
                     "(python -m pip install rapidocr) não é preciso.")
            return False
        if "por" in motor.idiomas():
            imprimir("O Tesseract já tem o idioma português. Nada a fazer.")
            return True

        sistema = _pasta_de_idiomas_do_tesseract()
        if sistema and os.access(sistema, os.W_OK):
            destino, idiomas = sistema, ["por"]
        else:
            destino, idiomas = pasta_de_idiomas_local(), ["por", "eng"]
            if sistema:
                imprimir(f"Sem permissão para gravar em {sistema}.")
            imprimir(f"O idioma vai para {destino}, ao lado do programa.")
    else:
        idiomas = ["por", "eng"]

    os.makedirs(destino, exist_ok=True)
    for idioma in idiomas:
        if os.path.isfile(os.path.join(destino, f"{idioma}.traineddata")):
            continue
        imprimir(f"Baixando {idioma}.traineddata...")
        try:
            _baixar_idioma(url_base, idioma, destino, minimo_bytes)
        except Exception as erro:  # noqa: BLE001 - rede, proxy, permissão
            imprimir(f"Falhou: {erro}")
            imprimir("Se a rede bloqueia o github.com, baixe o arquivo "
                     f"{idioma}.traineddata (projeto tessdata_fast) em outra "
                     f"máquina e copie para {destino}, ou aponte a variável "
                     "TESSDATA_URL para um espelho interno.")
            return False

    imprimir(f"Pronto: o idioma português está em {destino}. Abra o programa de novo.")
    return True


# Ícone de rede social, marcador de lista, pixel espaçador. Não cabe texto
# legível num quadrado de 20 px, e cada um desses custa meio segundo de
# leitura à toa — num pacote com dez ícones, são cinco segundos de espera.
LADO_MINIMO_PARA_LER = 60
AREA_MINIMA_PARA_LER = 2500


def _pequena_demais(caminho: str) -> tuple[bool, str]:
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            largura, altura = imagem.size
    except Exception:
        return False, ""
    if largura * altura < AREA_MINIMA_PARA_LER:
        return True, f"{largura}x{altura}: pequena demais para conter texto"
    if largura < LADO_MINIMO_PARA_LER and altura < LADO_MINIMO_PARA_LER:
        return True, f"{largura}x{altura}: tamanho de ícone"
    return False, ""


def _e_gif_animado(caminho: str) -> bool:
    if not caminho.lower().endswith(".gif"):
        return False
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return getattr(imagem, "n_frames", 1) > 1
    except Exception:
        return False


def ler_imagem(caminho: str, idioma: str = "por",
               confianca_minima: int = 40) -> ResultadoOCR:
    motor = motor_ativo()
    nome = os.path.basename(caminho)
    if not motor:
        return ResultadoOCR(arquivo=nome, erro=ocr_disponivel()[1])

    pequena, motivo = _pequena_demais(caminho)
    if pequena:
        return ResultadoOCR(arquivo=nome, lido=True, motor=motor.nome, aviso=motivo)

    if not _e_gif_animado(caminho):
        return motor.ler(caminho, idioma, confianca_minima)

    # GIF animado: cada cena pode trazer texto próprio, e é comum a oferta
    # inteira estar espalhada entre os frames.
    import tempfile

    textos, confiancas, frames_lidos = [], [], 0
    try:
        quadros = _frames_relevantes(caminho)
    except Exception as e:
        return ResultadoOCR(arquivo=nome, erro=f"não consegui abrir o GIF: {e}",
                            motor=motor.nome)

    with tempfile.TemporaryDirectory(prefix="frames_") as pasta:
        for indice, quadro in enumerate(quadros):
            destino = os.path.join(pasta, f"frame_{indice:02d}.png")
            try:
                quadro.save(destino)
            except Exception:
                continue
            parcial = motor.ler(destino, idioma, confianca_minima)
            if parcial.texto:
                textos.append(parcial.texto)
                frames_lidos += 1
            if parcial.confianca_media:
                confiancas.append(parcial.confianca_media)

    texto = _juntar_textos(textos)
    return ResultadoOCR(
        arquivo=nome, texto=texto, lido=True, motor=motor.nome,
        linhas=texto.splitlines(),
        confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        aviso=(f"GIF animado: {frames_lidos} cena(s) lida(s) de "
               f"{len(quadros)} frame(s) distintos"),
    )


# ------------------------------------------------------- cache entre execuções

PASTA_CACHE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".cache-leitura"
)

# Módulos cujo código decide o texto que sai de uma imagem: o próprio ocr
# (motores, fatiamento, filtros), o layout (separa a peça em blocos antes de
# montar as linhas) e a normalização (limpar). Só o texto destes entra na chave
# do cache. A correção de OCR, o comparador, o parser de HTML, as regras e a
# tela rodam DEPOIS da leitura e não mudam o que o cache guarda: mexer neles
# não pode jogar fora leituras que levaram minutos.
MODULOS_DA_LEITURA = ("ocr", "layout", "normalizacao")


def _fontes_da_leitura() -> list:
    """Texto de cada módulo da leitura, na ordem fixa de MODULOS_DA_LEITURA."""
    # no script único, o carregador entrega os textos embutidos
    embutidas = globals().get("_FONTES_DO_SCRIPT") or {}
    pasta = os.path.dirname(os.path.abspath(__file__))
    fontes = []
    for nome in MODULOS_DA_LEITURA:
        texto = embutidas.get(nome)
        if texto is None:
            # pacote em pastas (validador/ocr.py...): lê o arquivo ao lado
            try:
                with open(os.path.join(pasta, nome + ".py"), encoding="utf-8") as f:
                    texto = f.read()
            except OSError:
                texto = ""      # sem acesso ao código: a chave cai no nome do módulo
        fontes.append((nome, texto))
    return fontes


def _versao_da_leitura(fontes: list | None = None) -> str:
    """
    Identidade do código que produz a leitura.

    Isto já foi um número escrito à mão, e o número ficou para trás três vezes
    seguidas enquanto o comportamento da leitura mudava. O efeito é pior do que
    parece: a correção entra no código, a pessoa atualiza, roda o mesmo pacote
    e continua vendo o erro antigo, porque o cache devolve a leitura de antes.
    Depurar isso custa caro, e o sintoma aponta para o lugar errado.

    A chave é o resumo do texto dos módulos de MODULOS_DA_LEITURA. Mudou o
    código que decide a leitura, o cache antigo deixa de valer sozinho. Mudou
    qualquer outra parte do script (a tela, por exemplo), o cache sobrevive.

    `fontes` existe para os testes: lista de (nome, texto) no lugar da real.
    """
    import hashlib

    digestor = hashlib.sha1()
    for nome, texto in (_fontes_da_leitura() if fontes is None else fontes):
        digestor.update(nome.encode("utf-8") + b"\0")
        digestor.update(texto.encode("utf-8") + b"\0")
    return digestor.hexdigest()[:12]


VERSAO_DA_LEITURA = _versao_da_leitura()


def _impressao_do_arquivo(caminho: str, motor: str) -> str | None:
    """
    Identidade da leitura: conteúdo do arquivo + motor + versão.

    Pelo conteúdo, e não pelo caminho: o mesmo banner reaparece em campanhas
    diferentes com nomes diferentes, e conferir de novo o que já foi lido é
    desperdício. Muda uma vírgula na imagem, muda a impressão.
    """
    import hashlib

    try:
        digestor = hashlib.sha1()
        with open(caminho, "rb") as arquivo:
            for pedaco in iter(lambda: arquivo.read(262144), b""):
                digestor.update(pedaco)
    except OSError:
        return None
    digestor.update(f"|{motor}|{VERSAO_DA_LEITURA}".encode())
    return digestor.hexdigest()


def _ler_do_cache(impressao: str) -> ResultadoOCR | None:
    if not impressao:
        return None
    import json

    caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
    try:
        with open(caminho, encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
        return ResultadoOCR(**dados)
    except Exception:
        return None


def _gravar_no_cache(impressao: str, resultado: ResultadoOCR) -> None:
    if not impressao or resultado.erro:
        return          # falha não entra no cache: a próxima tentativa pode dar certo
    import json
    from dataclasses import asdict

    try:
        os.makedirs(PASTA_CACHE, exist_ok=True)
        caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
        with open(caminho, "w", encoding="utf-8") as arquivo:
            json.dump(asdict(resultado), arquivo, ensure_ascii=False)
    except OSError:
        pass            # sem permissão de escrita: segue sem cache


class CacheOCR:
    """
    Guarda a leitura de cada imagem, dentro da execução e entre execuções.

    Ler imagem é praticamente todo o tempo da conferência. Na prática o mesmo
    pacote é conferido várias vezes — ajusta o docx, confere de novo — e as
    imagens não mudaram. Reler tudo a cada vez é o desperdício mais caro aqui.
    """

    def __init__(self, idioma: str = "por", confianca_minima: int = 40,
                 usar_disco: bool = True):
        self.idioma = idioma
        self.confianca_minima = confianca_minima
        self.usar_disco = usar_disco
        self.aviso_idioma = ""
        self.reaproveitadas = 0
        self._cache: dict[str, ResultadoOCR] = {}

    def _nome_do_motor(self) -> str:
        motor = motor_ativo()
        return motor.nome if motor else "nenhum"

    def ler(self, caminho: str) -> ResultadoOCR:
        chave = os.path.normcase(os.path.abspath(caminho))
        if chave in self._cache:
            return self._cache[chave]

        impressao = (_impressao_do_arquivo(caminho, self._nome_do_motor())
                     if self.usar_disco else None)
        guardado = _ler_do_cache(impressao) if impressao else None
        if guardado is not None:
            self.reaproveitadas += 1
            self._cache[chave] = guardado
            return guardado

        resultado = ler_imagem(caminho, self.idioma, self.confianca_minima)
        if resultado.aviso and not self.aviso_idioma:
            self.aviso_idioma = resultado.aviso
        if impressao:
            _gravar_no_cache(impressao, resultado)
        self._cache[chave] = resultado
        return resultado

    def pre_carregar(self, caminhos: list[str], trabalhadores: int = 3,
                     ao_avancar=None) -> None:
        """
        Lê várias imagens ao mesmo tempo.

        O reconhecimento roda fora do Python, então a espera de uma imagem não
        impede a leitura da outra — ler quatro em paralelo aproveita a máquina
        em vez de ficar na fila.
        """
        pendentes = []
        for caminho in caminhos:
            chave = os.path.normcase(os.path.abspath(caminho))
            if chave not in self._cache and os.path.exists(caminho):
                pendentes.append(caminho)
        total = len(pendentes)
        if total < 2:
            for caminho in pendentes:
                self.ler(caminho)
                if ao_avancar:
                    ao_avancar(1, total)
            return

        from concurrent.futures import ThreadPoolExecutor

        concluidas = 0
        with ThreadPoolExecutor(max_workers=min(trabalhadores, total)) as pool:
            for _ in pool.map(self.ler, pendentes):
                concluidas += 1
                if ao_avancar:
                    ao_avancar(concluidas, total)

    @property
    def lidas(self) -> int:
        return sum(1 for r in self._cache.values() if r.lido)
