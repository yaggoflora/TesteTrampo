@echo off
REM ============================================================================
REM Verificador de Validade de Pastas — iniciar.bat
REM
REM Duplo-clique neste arquivo para abrir o programa. Na primeira vez, ele
REM prepara tudo sozinho (cria o ambiente Python e instala o Flask); nas
REM próximas, só abre. Não precisa saber o que é "venv" ou "pip" para usar.
REM ============================================================================

setlocal enabledelayedexpansion
title Verificador de Validade de Pastas

REM Garante que estamos na pasta onde este .bat está, não importa de onde
REM foi clicado (área de trabalho, atalho, etc.).
set "PASTA_DO_PROGRAMA=%~dp0"
cd /d "%PASTA_DO_PROGRAMA%"

REM --- 0. Cria (só na primeira vez) um atalho com ícone vermelho de "play",
REM        pra ficar visualmente óbvio qual arquivo clicar pra abrir o
REM        programa. Das próximas vezes, o ideal é usar esse atalho — mas
REM        clicar direto neste .bat continua funcionando normalmente.
if not exist "%PASTA_DO_PROGRAMA%Iniciar Verificador.lnk" (
    powershell -NoProfile -WindowStyle Hidden -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut('%PASTA_DO_PROGRAMA%Iniciar Verificador.lnk'); $sc.TargetPath = '%PASTA_DO_PROGRAMA%iniciar.bat'; $sc.WorkingDirectory = '%PASTA_DO_PROGRAMA%'; $sc.IconLocation = '%PASTA_DO_PROGRAMA%icones\iniciar.ico'; $sc.Description = 'Abre o Verificador de Validade de Pastas'; $sc.Save()" >nul 2>nul
    if exist "%PASTA_DO_PROGRAMA%Iniciar Verificador.lnk" (
        echo(
        echo   Foi criado o atalho "Iniciar Verificador" ^(icone vermelho^)
        echo   nesta pasta. Da proxima vez, pode usar ele em vez deste
        echo   arquivo .bat — fica mais facil de identificar.
        echo(
    )
)

REM --- 1. Confere se existe Python instalado nesta máquina ------------------
REM Importante: NAO usamos "where python" aqui. Em máquinas sem Python
REM instalado, o Windows costuma ter um "atalho fantasma" chamado python.exe
REM (o alias que abre a Microsoft Store) — o "where" encontra esse arquivo e
REM acha que Python está instalado, quando na verdade não está. Por isso
REM rodamos "python --version" de verdade e conferimos o código de erro:
REM esse alias fantasma sempre devolve o código 9009 quando Python não está
REM instalado de verdade.
python --version >nul 2>nul
set "PYTHON_ENCONTRADO=%errorlevel%"
if "%PYTHON_ENCONTRADO%"=="9009" (
    echo(
    echo   Nao foi encontrado o Python nesta maquina.
    echo(
    echo   Instale o Python em https://www.python.org/downloads/
    echo   e marque a opcao "Add Python to PATH" durante a instalacao.
    echo   Depois, clique de novo neste arquivo.
    echo(
    echo   Atencao: se o Windows abrir sozinho a Microsoft Store ao tentar
    echo   rodar este programa, e sinal de que existe um "atalho" do Windows
    echo   para o Python que nao e o Python de verdade. Para desativa-lo, va
    echo   em Configuracoes ^> Aplicativos ^> Configuracoes avancadas do
    echo   aplicativo ^> Aliases de execucao do aplicativo, e desligue os
    echo   aliases "python.exe" e "python3.exe". Depois instale o Python
    echo   pelo link acima.
    echo(
    pause
    exit /b 1
)

REM --- 2. Primeira vez: cria o ambiente e instala as dependencias -----------
if not exist "venv\Scripts\python.exe" (
    echo(
    echo   Preparando o programa pela primeira vez, aguarde um instante...
    echo(

    python -m venv venv
    if errorlevel 1 (
        echo(
        echo   Nao foi possivel preparar o programa ^(erro ao criar o ambiente^).
        echo   Copie a mensagem acima e envie para quem criou o programa.
        echo(
        pause
        exit /b 1
    )

    call venv\Scripts\activate.bat
    python -m pip install --upgrade pip --quiet
    pip install -r requirements.txt
    if errorlevel 1 (
        echo(
        echo   Nao foi possivel instalar as dependencias.
        echo   Verifique se esta maquina tem acesso a internet e tente de novo.
        echo(
        pause
        exit /b 1
    )

    echo(
    echo   Tudo pronto! Abrindo o programa...
    echo(
) else (
    call venv\Scripts\activate.bat
)

REM --- 3. Abre o navegador sozinho, um instante depois do servidor subir ----
REM O "timeout" roda em uma janela separada, sem travar o "python app.py"
REM logo abaixo, que precisa continuar rodando enquanto o programa é usado.
start "" cmd /c "timeout /t 2 /nobreak >nul & start "" http://127.0.0.1:5000"

echo(
echo   ==========================================================
echo    O programa esta rodando. O navegador vai abrir sozinho.
echo(
echo    NAO FECHE esta janela enquanto estiver usando o programa
echo    — fechar esta janela desliga o programa.
echo(
echo    Para encerrar: feche esta janela, ou clique aqui dentro
echo    e pressione Ctrl+C.
echo   ==========================================================
echo(

python app.py

echo(
echo   O programa foi encerrado.
pause
