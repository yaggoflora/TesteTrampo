# CRM Bradesco — Orquestração e Controle de Peças

Plataforma para automatizar a entrada de dados do time de Publicação e
Orquestração CRM, eliminando a duplicidade entre as planilhas "Fila de
Peças" e "Controle de Peças", com geração de e-mails padronizados,
exportação para Excel e um assistente de IA para validação de peças.

## Stack

- **Backend:** FastAPI + MongoDB (Motor)
- **Frontend:** React + Tailwind CSS

## Como rodar

### Backend

```bash
cd backend
pip install -r requirements.txt
```

Crie um arquivo `.env` dentro de `backend/` com:

```
MONGO_URL=mongodb://localhost:27017
DB_NAME=crm_bradesco
CORS_ORIGINS=http://localhost:3000
WEBHOOK_CRON_SECRET=defina_um_segredo
OPENAI_API_KEY=sua_chave_openai
```

Depois:

```bash
uvicorn server:app --reload
```

### Frontend

```bash
cd frontend
yarn install
```

Crie um arquivo `.env` dentro de `frontend/` com:

```
REACT_APP_BACKEND_URL=http://localhost:8000
```

Depois:

```bash
yarn start
```

## Funcionalidades

- Wizard guiado em 5 etapas para registro de peças
- Parser automático de briefing e nomenclatura de campanha
- Matriz de regras de status (Fila de Peças ↔ Controle de Peças)
- Geração de e-mails padronizados com saudação automática
- Exportação para Excel (.xlsx) e backup quinzenal
- Assistente de IA para validação de peças de comunicação
