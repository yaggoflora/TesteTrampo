import { useState } from "react";
import "@/App.css";
import { Toaster } from "@/components/ui/sonner";
import Navbar from "@/components/Navbar";
import Dashboard from "@/components/Dashboard";
import StepperWizard from "@/components/StepperWizard";
import FilaTable from "@/components/FilaTable";
import ControleTable from "@/components/ControleTable";
import ChatWidget from "@/components/ChatWidget";

const emptyDraft = {
  criador: "",
  assunto_email: "",
  responsavel: "",
  briefing: "",
  nome_campanha: "",
  segmento: "",
  link_pasta: "",
  data_entrega: "",
  data_conferencia: "",
  fim_vigencia: "",
  marketing: "",
  agencia: "",
  qtd_respostas: 0,
  tipo_canal: "",
  canal_esperado: "",
  observacao: "",
  possui_link: "",
};

function App() {
  const [tab, setTab] = useState("dashboard");
  const [draft, setDraft] = useState(emptyDraft);
  const [savedId, setSavedId] = useState(null);
  const [step, setStep] = useState(1);
  const [templateTipo, setTemplateTipo] = useState("");

  const novaPeca = () => {
    const criador = draft.criador || localStorage.getItem("crm_criador") || "";
    setDraft({ ...emptyDraft, criador });
    setSavedId(null);
    setStep(1);
    setTemplateTipo("");
    setTab("nova");
  };

  const retomarPeca = (peca) => {
    setDraft({ ...emptyDraft, ...peca });
    setSavedId(peca.id);
    setTemplateTipo(peca.template_tipo || "");
    setStep(peca.fila_status ? (peca.email_corpo ? 4 : 3) : 2);
    setTab("nova");
  };

  return (
    <div className="App min-h-screen bg-[#F8FAFC]">
      <Navbar tab={tab} setTab={setTab} onNovaPeca={novaPeca} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {tab === "dashboard" && <Dashboard onNovaPeca={novaPeca} />}
        {tab === "nova" && (
          <StepperWizard
            draft={draft}
            setDraft={setDraft}
            savedId={savedId}
            setSavedId={setSavedId}
            step={step}
            setStep={setStep}
            templateTipo={templateTipo}
            setTemplateTipo={setTemplateTipo}
            onNovaPeca={novaPeca}
          />
        )}
        {tab === "fila" && <FilaTable onRetomar={retomarPeca} />}
        {tab === "controle" && <ControleTable />}
      </main>
      <ChatWidget />
      <Toaster position="top-center" richColors closeButton />
    </div>
  );
}

export default App;
