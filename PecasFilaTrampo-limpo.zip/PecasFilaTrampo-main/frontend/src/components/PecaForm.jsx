import { SEGMENTOS, AGENCIAS, TIPOS_CANAL, CANAL_MAP, QTD_RESPOSTAS_OPCOES, POSSUI_LINK_OPCOES, STATUS_PECA_OPCOES } from "@/constants/options";

const inputCls =
  "w-full h-12 text-lg px-4 bg-white border-2 border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20 transition-all font-medium";
const selectCls = inputCls + " appearance-none pr-10 bg-no-repeat bg-[right_0.75rem_center] bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 fill=%22%23475569%22 viewBox=%220 0 16 16%22%3E%3Cpath d=%22M8 11L2 5h12z%22/%3E%3C/svg%3E')]";

function Field({ label, children, hint, className = "" }) {
  return (
    <div className={className}>
      <label className="block text-base font-semibold text-slate-800 mb-2">{label}</label>
      {children}
      {hint && <p className="text-sm text-slate-500 mt-1">{hint}</p>}
    </div>
  );
}

export default function PecaForm({ draft, set }) {
  const canaisEsperados = CANAL_MAP[draft.tipo_canal] || [];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <Field label="Responsável (A)">
        <input className={inputCls} placeholder="Ex: Yaggo" value={draft.responsavel} onChange={(e) => set("responsavel", e.target.value)} />
      </Field>
      <Field label="Briefing (B)" hint="Padrão de 8 a 9 dígitos, ex: 000123477">
        <input className={`${inputCls} font-mono`} placeholder="000123477" value={draft.briefing} onChange={(e) => set("briefing", e.target.value)} />
      </Field>
      <Field label="Segmento (D)">
        <select className={selectCls} value={draft.segmento} onChange={(e) => set("segmento", e.target.value)}>
          <option value="">Selecione...</option>
          {SEGMENTOS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>

      <Field label="Nome de Campanha (C)" className="md:col-span-2 lg:col-span-3">
        <input className={`${inputCls} font-mono !text-base`} placeholder="000123477_SQ_LINHACARA_PUB__CC_CLASSIC_PUSH" value={draft.nome_campanha} onChange={(e) => set("nome_campanha", e.target.value)} />
      </Field>

      <Field label="Link da Pasta (E)" className="md:col-span-2 lg:col-span-3">
        <input className={`${inputCls} font-mono !text-base`} placeholder="\\...\DISPONIVEIS\000123477" value={draft.link_pasta} onChange={(e) => set("link_pasta", e.target.value)} />
      </Field>

      <Field label="Data de Entrega (F)" hint="Data do e-mail de solicitação do Marketing">
        <input className={inputCls} placeholder="DD/MM/AAAA" value={draft.data_entrega} onChange={(e) => set("data_entrega", e.target.value)} />
      </Field>
      <Field label="Data de Conferência (G)">
        <input className={inputCls} placeholder="DD/MM/AAAA" value={draft.data_conferencia} onChange={(e) => set("data_conferencia", e.target.value)} />
      </Field>
      <Field label="Fim de Vigência (H)">
        <input className={inputCls} placeholder="31/12/2026" value={draft.fim_vigencia} onChange={(e) => set("fim_vigencia", e.target.value)} />
      </Field>

      <Field label="Marketing (I)">
        <input className={inputCls} placeholder="Nome e último sobrenome" value={draft.marketing} onChange={(e) => set("marketing", e.target.value)} />
      </Field>
      <Field label="Agência (J)">
        <select className={selectCls} value={draft.agencia} onChange={(e) => set("agencia", e.target.value)}>
          <option value="">Selecione...</option>
          {AGENCIAS.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </Field>
      <Field label="Qtd Respostas (K)" hint="Quantas interações por e-mail (1ª versão, correções...)">
        <select className={selectCls} value={draft.qtd_respostas} onChange={(e) => set("qtd_respostas", parseInt(e.target.value, 10))}>
          <option value={0}>Selecione...</option>
          {QTD_RESPOSTAS_OPCOES.map((n) => <option key={n} value={n}>{n}</option>)}
        </select>
      </Field>

      <Field label="Tipo de Canal (L)">
        <select className={selectCls} value={draft.tipo_canal} onChange={(e) => { set("tipo_canal", e.target.value); set("canal_esperado", ""); }}>
          <option value="">Selecione...</option>
          {TIPOS_CANAL.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </Field>
      <Field label="Canal Esperado (M)" hint={draft.tipo_canal ? `Opções filtradas para ${draft.tipo_canal}` : "Selecione o Tipo de Canal primeiro"}>
        <select className={selectCls} value={draft.canal_esperado} onChange={(e) => set("canal_esperado", e.target.value)} disabled={!draft.tipo_canal}>
          <option value="">{draft.tipo_canal ? "Selecione..." : "Aguardando tipo de canal"}</option>
          {canaisEsperados.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </Field>
      <Field label="Status Peça (N)" hint="Preenchido automaticamente pela Fila de Peças; ajuste manual se necessário">
        <select className={selectCls} value={draft.status_peca || ""} onChange={(e) => set("status_peca", e.target.value)}>
          <option value="">Automático (definido pela Fila)</option>
          {STATUS_PECA_OPCOES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="Possui Link (P)" hint="Se a peça contém link interno ou externo">
        <select className={selectCls} value={draft.possui_link} onChange={(e) => set("possui_link", e.target.value)}>
          <option value="">Selecione...</option>
          {POSSUI_LINK_OPCOES.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      </Field>
    </div>
  );
}
