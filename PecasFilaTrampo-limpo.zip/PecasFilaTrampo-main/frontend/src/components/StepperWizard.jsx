import { useState } from "react";
import { toast } from "sonner";
import { Check, ChevronLeft, ChevronRight, Wand2, AlertTriangle, CheckCircle2 } from "lucide-react";
import { api } from "@/api";
import PecaForm from "@/components/PecaForm";
import EmailPreview from "@/components/EmailPreview";
import DocsModal from "@/components/DocsModal";
import { STATUS_FILA_OPCOES } from "@/constants/options";

const STEPS = [
  { n: 1, id: "entrada", title: "Entrada & Briefing" },
  { n: 2, id: "controle", title: "Controle de Peças" },
  { n: 3, id: "fila", title: "Fila de Peças" },
  { n: 4, id: "email", title: "E-mail" },
  { n: 5, id: "conclusao", title: "Conclusão" },
];

const inputCls =
  "w-full h-12 text-lg px-4 bg-white border-2 border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20 transition-all font-medium";

function Stepper({ step }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm py-6 px-4 sm:px-8 mb-8">
      <div className="overflow-x-auto">
      <ol className="flex items-center w-full min-w-[560px]">
        {STEPS.map((s, i) => (
          <li key={s.id} className={`flex items-center ${i < STEPS.length - 1 ? "flex-1" : ""}`}>
            <div className="flex flex-col items-center gap-2 min-w-[64px]">
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center text-lg font-bold border-2 transition-colors ${
                  step > s.n
                    ? "bg-emerald-500 border-emerald-500 text-white"
                    : step === s.n
                      ? "bg-[#CC092F] border-[#CC092F] text-white"
                      : "bg-white border-slate-300 text-slate-400"
                }`}
              >
                {step > s.n ? <Check size={22} /> : s.n}
              </div>
              <span className={`text-xs sm:text-sm font-semibold text-center ${step === s.n ? "text-[#CC092F]" : "text-slate-500"}`}>
                {s.title}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`h-1 flex-1 mx-2 rounded-full mb-7 ${step > s.n ? "bg-emerald-500" : "bg-slate-200"}`} />
            )}
          </li>
        ))}
      </ol>
      </div>
      <div className="mt-4 h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-[#CC092F] rounded-full transition-all duration-500"
          style={{ width: `${((step - 1) / (STEPS.length - 1)) * 100}%` }}
        />
      </div>
    </div>
  );
}

export default function StepperWizard({ draft, setDraft, savedId, setSavedId, step, setStep, templateTipo, setTemplateTipo, onNovaPeca }) {
  const [loading, setLoading] = useState(false);
  const [parsed, setParsed] = useState(null);
  const [filaStatus, setFilaStatus] = useState(draft.fila_status || "");
  const [bloqueio, setBloqueio] = useState("");
  const [docsOpen, setDocsOpen] = useState(false);
  const [pastaRenomeada, setPastaRenomeada] = useState(draft.pasta_renomeada || "");

  const set = (k, v) => setDraft((d) => ({ ...d, [k]: v }));

  const analisar = async () => {
    if (!draft.assunto_email && !draft.nome_campanha) {
      toast.error("Informe o assunto do e-mail ou o nome da campanha para análise.");
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.post("/parse", { assunto: draft.assunto_email, nome_campanha: draft.nome_campanha });
      setParsed(data);
      setDraft((d) => ({
        ...d,
        briefing: data.briefing || d.briefing,
        link_pasta: data.link_pasta || d.link_pasta,
        tipo_canal: data.tipo_canal || d.tipo_canal,
        canal_esperado: data.canal_esperado || d.canal_esperado,
        segmento: data.segmento || d.segmento,
        data_conferencia: data.data_conferencia,
      }));
      if (data.briefing) toast.success(`Briefing identificado: ${data.briefing}`);
      else toast.info("Não foi possível identificar o briefing. Preencha manualmente.");
    } catch (e) {
      toast.error("Erro ao analisar: " + (e.response?.data?.detail || e.message));
    } finally {
      setLoading(false);
    }
  };

  const salvarEAvancar = async () => {
    if (!draft.criador.trim()) {
      toast.error("O campo 'Nome do Criador' é obrigatório.");
      return;
    }
    setLoading(true);
    try {
      localStorage.setItem("crm_criador", draft.criador);
      if (savedId) {
        await api.put(`/pecas/${savedId}`, draft);
        toast.success("Peça atualizada na Fila de Peças.");
      } else {
        const { data } = await api.post("/pecas", draft);
        setSavedId(data.id);
        toast.success("Peça registrada na Fila de Peças.");
      }
      setStep(3);
    } catch (e) {
      toast.error(e.response?.data?.detail || "Erro ao salvar a peça.");
    } finally {
      setLoading(false);
    }
  };

  const processar = async () => {
    if (!filaStatus) {
      toast.error("Selecione o status da peça na Fila.");
      return;
    }
    setLoading(true);
    setBloqueio("");
    try {
      const { data } = await api.post(`/pecas/${savedId}/processar`, { fila_status: filaStatus, observacao: draft.observacao });
      setTemplateTipo(data.template_tipo);
      if (data.escreve_controle) {
        toast.success(`Controle de Peças atualizado: status "${data.status_peca}".`);
      } else {
        toast.info("Status registrado. Controle de Peças não é preenchido para este status.");
      }
      setStep(4);
    } catch (e) {
      if (e.response?.status === 409) {
        setBloqueio(e.response.data.detail);
      } else {
        toast.error(e.response?.data?.detail || "Erro ao processar status.");
      }
    } finally {
      setLoading(false);
    }
  };

  const concluir = async () => {
    setLoading(true);
    try {
      const { data } = await api.post(`/pecas/${savedId}/concluir`);
      setPastaRenomeada(data.pasta_renomeada);
      setDraft((d) => ({ ...d, concluida: true, pasta_renomeada: data.pasta_renomeada }));
      toast.success("Processamento concluído com sucesso!");
    } catch (e) {
      toast.error(e.response?.data?.detail || "Erro ao concluir.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-fade-in-up">
      <Stepper step={step} />

      {step === 1 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-1">Entrada & Briefing</h2>
          <p className="text-base text-slate-600 mb-4">Cole o assunto do e-mail do Marketing. O sistema extrai o briefing e localiza a pasta na rede automaticamente.</p>
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-5">
            <h3 className="text-base font-bold text-blue-900 mb-1">Antes de começar: verifique a peça no Outlook e no Workflow</h3>
            <p className="text-sm text-blue-800 mb-2">Dados de consulta obrigatória do analista:</p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1 text-sm text-blue-900 font-medium">
              <li>• Briefing</li>
              <li>• Nome da Campanha</li>
              <li>• Segmento</li>
              <li>• Data de Fim de Vigência (Outlook)</li>
              <li>• Agência Desenvolvedora</li>
              <li>• Marketing (responsável pelo envio)</li>
            </ul>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="criador">Nome do Criador *</label>
              <input
                id="criador"
                className={inputCls}
                placeholder="Ex: Yaggo Silva"
                value={draft.criador}
                onChange={(e) => set("criador", e.target.value)}
              />
            </div>
            <div>
              <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="assunto">Assunto do E-mail</label>
              <input
                id="assunto"
                className={inputCls}
                placeholder='Ex: "SUBSTITUIÇÃO DE PEÇAS 14023 - Crédito - Balcão Emergencial"'
                value={draft.assunto_email}
                onChange={(e) => set("assunto_email", e.target.value)}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="campanha">Nome de Campanha (opcional nesta etapa)</label>
              <input
                id="campanha"
                className={`${inputCls} font-mono !text-base`}
                placeholder="Ex: 00015107_00139713_MARGEM_LIVRE_INSS_CLA_ATM_INF"
                value={draft.nome_campanha}
                onChange={(e) => set("nome_campanha", e.target.value)}
              />
            </div>
          </div>

          {parsed && (
            <div className="mt-6 bg-[#FDF2F4] border border-[#CC092F]/20 rounded-xl p-5">
              <h3 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Wand2 size={20} className="text-[#CC092F]" /> Dados extraídos automaticamente
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-base">
                <div className="bg-white rounded-lg p-3 border border-slate-200"><span className="text-sm text-slate-500 block">Briefing</span><strong className="font-mono">{parsed.briefing || "—"}</strong></div>
                <div className="bg-white rounded-lg p-3 border border-slate-200"><span className="text-sm text-slate-500 block">Tipo de Canal</span><strong>{parsed.tipo_canal || "—"}</strong></div>
                <div className="bg-white rounded-lg p-3 border border-slate-200"><span className="text-sm text-slate-500 block">Canal Esperado</span><strong>{parsed.canal_esperado || "—"}</strong></div>
                <div className="bg-white rounded-lg p-3 border border-slate-200"><span className="text-sm text-slate-500 block">Segmento</span><strong>{parsed.segmento || "—"}</strong></div>
                <div className="bg-white rounded-lg p-3 border border-slate-200 sm:col-span-2"><span className="text-sm text-slate-500 block">Link da Pasta</span><strong className="font-mono text-sm break-all">{parsed.link_pasta || "—"}</strong></div>
              </div>
              <p className="text-sm text-slate-600 mt-3">Campos não identificados com 100% de certeza ficam em branco para preenchimento manual.</p>
            </div>
          )}

          <div className="flex flex-wrap gap-4 mt-8">
            <button
              onClick={analisar}
              disabled={loading}
              className="flex items-center gap-2 bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors disabled:opacity-50"
            >
              <Wand2 size={20} /> {loading ? "Analisando..." : "Analisar e Extrair Dados"}
            </button>
            <button
              onClick={() => {
                if (!draft.criador.trim()) { toast.error("Informe o Nome do Criador antes de avançar."); return; }
                setStep(2);
              }}
              className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors active:scale-[0.98]"
            >
              Avançar <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-1">Controle de Peças — Formulário (colunas A–P)</h2>
          <p className="text-base text-slate-600 mb-6">Este é o preenchimento principal, equivalente à planilha "Controle de Peças". Os campos semelhantes da "Fila de Peças" são preenchidos automaticamente a partir daqui.</p>
          <PecaForm draft={draft} set={set} />
          <div className="flex flex-wrap gap-4 mt-8">
            <button onClick={() => setStep(1)} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-6 rounded-lg text-lg transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <button
              onClick={salvarEAvancar}
              disabled={loading}
              className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors disabled:opacity-50 active:scale-[0.98]"
            >
              {loading ? "Salvando..." : "Salvar na Fila e Avançar"} <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-1">Fila de Peças — Status da Peça</h2>
          <p className="text-base text-slate-600 mb-6">Selecione o status da peça na Fila de Peças. Conforme a regra, o sistema atualiza (ou não) a coluna N — Status Peça — do Controle de Peças e prepara o e-mail correspondente.</p>

          {bloqueio && (
            <div className="mb-6 bg-red-50 border-2 border-red-300 rounded-xl p-6 flex items-start gap-4 animate-fade-in-up">
              <AlertTriangle size={32} className="text-red-600 shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-red-800 mb-1">Processamento bloqueado</h3>
                <p className="text-lg text-red-700">{bloqueio}</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {STATUS_FILA_OPCOES.map((op) => (
              <button
                key={op.value}
                onClick={() => { setFilaStatus(op.value); setBloqueio(""); }}
                className={`text-left p-5 rounded-xl border-2 transition-all min-h-[96px] ${
                  filaStatus === op.value
                    ? "border-[#CC092F] bg-[#FDF2F4] shadow-md"
                    : "border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg font-bold text-slate-900">{op.label}</span>
                  {filaStatus === op.value && <CheckCircle2 size={22} className="text-[#CC092F]" />}
                </div>
                <p className="text-sm text-slate-600">{op.desc}</p>
              </button>
            ))}
          </div>

          <div className="mt-6">
            <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="obs">Observação (coluna O)</label>
            <textarea
              id="obs"
              className="w-full text-lg p-4 bg-white border-2 border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20 transition-all min-h-[100px]"
              placeholder="Anotações do analista, detalhamento de ajustes..."
              value={draft.observacao}
              onChange={(e) => set("observacao", e.target.value)}
            />
          </div>

          <div className="flex flex-wrap gap-4 mt-8">
            <button onClick={() => setStep(2)} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-6 rounded-lg text-lg transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <button
              onClick={processar}
              disabled={loading}
              className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors disabled:opacity-50 active:scale-[0.98]"
            >
              {loading ? "Processando..." : "Processar Status e Avançar"} <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div>
          <EmailPreview pecaId={savedId} templateTipo={templateTipo} observacao={draft.observacao} />
          <div className="flex flex-wrap gap-4 mt-8">
            <button onClick={() => setStep(3)} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-6 rounded-lg text-lg transition-colors">
              <ChevronLeft size={20} /> Voltar
            </button>
            <button
              onClick={() => setStep(5)}
              className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors active:scale-[0.98]"
            >
              E-mail enviado no Outlook — Avançar <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}

      {step === 5 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-1">Conclusão & Arquivamento</h2>
          <p className="text-base text-slate-600 mb-6">Finalize o processamento. O sistema irá orientar o arquivamento em DOCS e a renomeação da pasta na rede.</p>

          {!draft.concluida && !pastaRenomeada ? (
            <button
              onClick={() => setDocsOpen(true)}
              className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-8 rounded-lg text-lg shadow-sm transition-colors active:scale-[0.98]"
            >
              <CheckCircle2 size={22} /> Concluído
            </button>
          ) : (
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-xl p-6 animate-fade-in-up">
              <div className="flex items-start gap-4">
                <CheckCircle2 size={32} className="text-emerald-600 shrink-0 mt-1" />
                <div className="w-full">
                  <h3 className="text-xl font-bold text-emerald-800 mb-2">Peça processada e concluída!</h3>
                  <p className="text-base text-emerald-700 mb-3">Renomeie/salve a pasta do Briefing no diretório DISPONIVEIS com o nome abaixo:</p>
                  <div className="bg-white border border-emerald-200 rounded-lg p-4 font-mono text-base break-all select-all">
                    {pastaRenomeada}
                  </div>
                  <button
                    onClick={() => { navigator.clipboard.writeText(pastaRenomeada); toast.success("Nome da pasta copiado!"); }}
                    className="mt-4 bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-12 px-6 rounded-lg text-base transition-colors"
                  >
                    Copiar nome da pasta
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-4 mt-8 pt-6 border-t border-slate-200">
            <button
              onClick={onNovaPeca}
              className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-6 rounded-lg text-lg transition-colors"
            >
              Iniciar Nova Peça
            </button>
          </div>

          <DocsModal open={docsOpen} onClose={() => setDocsOpen(false)} onConfirm={() => { setDocsOpen(false); concluir(); }} loading={loading} />
        </div>
      )}
    </div>
  );
}
