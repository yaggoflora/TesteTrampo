import { useEffect, useState } from "react";
import { Layers, CheckCircle2, Wrench, AlertOctagon, PlusCircle, ArrowRight } from "lucide-react";
import { api } from "@/api";

const KPIS = [
  { key: "total", label: "Total de Peças", icon: Layers, color: "text-[#3B82F6]", bg: "bg-blue-50", border: "border-blue-200" },
  { key: "ok", label: "OK / Aprovadas", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200" },
  { key: "ajustes", label: "Em Ajustes", icon: Wrench, color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200" },
  { key: "alerta", label: "Sem Retorno / Alerta", icon: AlertOctagon, color: "text-red-600", bg: "bg-red-50", border: "border-red-200" },
];

export default function Dashboard({ onNovaPeca }) {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get("/stats").then(({ data }) => setStats(data)).catch(() => {});
  }, []);

  const values = {
    total: stats?.total ?? 0,
    ok: stats?.por_status_peca?.OK ?? 0,
    ajustes: stats?.por_status_peca?.Ajustes ?? 0,
    alerta: (stats?.por_status_fila?.["Sem Retorno"] ?? 0) + (stats?.por_status_fila?.FILA ?? 0),
  };

  const canais = Object.entries(stats?.por_canal || {}).sort((a, b) => b[1] - a[1]);
  const maxCanal = Math.max(1, ...canais.map(([, v]) => v));

  return (
    <div className="space-y-8 animate-fade-in-up">
      <div className="bg-[#1E293B] rounded-2xl p-8 lg:p-10 text-white shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-56 h-56 rounded-full bg-[#CC092F]/20 blur-2xl" />
        <h2 className="text-3xl lg:text-4xl font-bold tracking-tight mb-2">Orquestração e Controle de Peças CRM</h2>
        <p className="text-lg text-slate-300 max-w-2xl mb-6">
          Automatize a entrada de dados, elimine duplicidade entre Fila e Controle, gere e-mails padronizados e valide peças com o assistente de IA.
        </p>
        <button
          onClick={onNovaPeca}
          className="inline-flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-7 rounded-lg text-lg shadow-md transition-all active:scale-[0.98]"
        >
          <PlusCircle size={22} /> Iniciar Nova Orquestração <ArrowRight size={20} />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {KPIS.map(({ key, label, icon: Icon, color, bg, border }) => (
          <div key={key} className={`bg-white rounded-xl border ${border} shadow-sm p-6 hover:shadow-md transition-shadow`}>
            <div className={`w-12 h-12 rounded-xl ${bg} flex items-center justify-center mb-4`}>
              <Icon size={26} className={color} />
            </div>
            <p className="text-4xl font-extrabold text-slate-900 mb-1">{values[key]}</p>
            <p className="text-base text-slate-600 font-medium">{label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
        <h3 className="text-xl font-bold text-slate-900 mb-5">Peças por Tipo de Canal</h3>
        {canais.length === 0 ? (
          <p className="text-base text-slate-500">Nenhuma peça registrada ainda. Os dados aparecerão aqui conforme a fila for preenchida.</p>
        ) : (
          <div className="space-y-4">
            {canais.map(([canal, qtd]) => (
              <div key={canal}>
                <div className="flex justify-between text-base font-semibold text-slate-800 mb-1.5">
                  <span>{canal}</span>
                  <span>{qtd}</span>
                </div>
                <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-[#CC092F] rounded-full transition-all duration-700" style={{ width: `${(qtd / maxCanal) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
