import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Copy, Mail, RefreshCw } from "lucide-react";
import { api } from "@/api";

const TEMPLATE_LABEL = {
  recebidas: "Peças Recebidas (Confirmação)",
  ajuste_peca: "Ajuste de Peça",
  alteracao_validade: "Ajuste / Alteração de Validade",
};

const editCls =
  "w-full text-lg px-4 py-3 bg-white border-2 border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20 transition-all";

export default function EmailPreview({ pecaId, templateTipo, observacao }) {
  const [loading, setLoading] = useState(true);
  const [saudacao, setSaudacao] = useState("");
  const [assunto, setAssunto] = useState("");
  const [corpo, setCorpo] = useState("");
  const [ajusteDetalhe, setAjusteDetalhe] = useState(observacao || "");
  const [validadeAnterior, setValidadeAnterior] = useState("");

  const gerar = async (detalhe, anterior) => {
    setLoading(true);
    try {
      const { data } = await api.post(`/pecas/${pecaId}/email`, {
        template_tipo: templateTipo || "ajuste_peca",
        ajustes_detalhe: detalhe ?? ajusteDetalhe,
        validade_anterior: anterior ?? validadeAnterior,
      });
      setAssunto(data.assunto);
      setCorpo(data.corpo);
      setSaudacao(data.saudacao);
    } catch (e) {
      toast.error("Erro ao gerar o e-mail.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (pecaId) gerar(); }, [pecaId]); // eslint-disable-line react-hooks/exhaustive-deps

  const copiar = async (texto, label) => {
    try {
      await navigator.clipboard.writeText(texto);
      toast.success(`${label} copiado para a área de transferência!`);
    } catch {
      toast.error("Não foi possível copiar automaticamente. Selecione e copie manualmente.");
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-10 text-center text-lg text-slate-500">
        Gerando e-mail padronizado...
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2"><Mail size={26} className="text-[#CC092F]" /> E-mail Padronizado</h2>
          <p className="text-base text-slate-600">
            Modelo: <strong>{TEMPLATE_LABEL[templateTipo] || "Ajuste de Peça"}</strong> • Saudação automática: <strong>"Prezado(a), {saudacao}!"</strong>
          </p>
        </div>
        <button onClick={() => gerar()} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-5 rounded-lg text-base transition-colors">
          <RefreshCw size={18} /> Regenerar
        </button>
      </div>

      {templateTipo === "ajuste_peca" && (
        <div className="mb-5 bg-amber-50 border border-amber-200 rounded-xl p-5">
          <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="ajuste-detalhe">Ajustes Necessários (descreva o que precisa mudar)</label>
          <textarea
            id="ajuste-detalhe"
            className={`${editCls} min-h-[90px]`}
            placeholder="Ex: Corrigir link do botão e ajustar disclaimer do SMS"
            value={ajusteDetalhe}
            onChange={(e) => setAjusteDetalhe(e.target.value)}
          />
          <button
            onClick={() => gerar(ajusteDetalhe)}
            className="mt-3 bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-12 px-6 rounded-lg text-base transition-colors"
          >
            Atualizar e-mail com o ajuste
          </button>
        </div>
      )}

      {templateTipo === "alteracao_validade" && (
        <div className="mb-5 bg-blue-50 border border-blue-200 rounded-xl p-5">
          <label className="block text-base font-semibold text-slate-800 mb-2" htmlFor="validade-anterior">Validade anterior (MM.AA)</label>
          <div className="flex flex-wrap gap-3 items-center">
            <input
              id="validade-anterior"
              className={`${editCls} max-w-[200px] font-mono`}
              placeholder="Ex: 09.26"
              value={validadeAnterior}
              onChange={(e) => setValidadeAnterior(e.target.value)}
            />
            <button
              onClick={() => gerar(undefined, validadeAnterior)}
              className="bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-12 px-6 rounded-lg text-base transition-colors"
            >
              Atualizar e-mail
            </button>
          </div>
        </div>
      )}

      <div className="border-2 border-slate-200 rounded-xl overflow-hidden">
        <div className="bg-[#F1F5F9] px-5 py-4 border-b border-slate-200">
          <p className="text-sm text-slate-500 font-semibold mb-1">ASSUNTO (editável)</p>
          <input
            className="w-full text-lg font-bold text-slate-900 bg-transparent border-b-2 border-transparent hover:border-slate-300 focus:border-[#CC092F] focus:outline-none py-1 transition-colors"
            value={assunto}
            onChange={(e) => setAssunto(e.target.value)}
          />
        </div>
        <div className="p-6">
          <p className="text-sm text-slate-500 font-semibold mb-1">CORPO DO E-MAIL (editável)</p>
          <textarea
            className="w-full text-lg text-slate-800 leading-relaxed font-sans min-h-[280px] bg-transparent border-2 border-transparent hover:border-slate-200 focus:border-[#CC092F] focus:outline-none rounded-lg p-2 transition-colors"
            value={corpo}
            onChange={(e) => setCorpo(e.target.value)}
          />
        </div>
      </div>
      <p className="text-sm text-slate-500 mt-2">O e-mail é gerado pronto, mas pode ser ajustado livremente antes de copiar.</p>

      <div className="flex flex-wrap gap-4 mt-6">
        <button
          onClick={() => copiar(`Assunto: ${assunto}\n\n${corpo}`, "E-mail completo")}
          className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-lg shadow-sm transition-colors active:scale-[0.98]"
        >
          <Copy size={20} /> Copiar E-mail Completo
        </button>
        <button
          onClick={() => copiar(assunto, "Assunto")}
          className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-6 rounded-lg text-lg transition-colors"
        >
          Copiar apenas o Assunto
        </button>
      </div>
      <p className="text-sm text-slate-500 mt-4">Cole o conteúdo no Outlook e envie ao Marketing. Depois avance para a conclusão.</p>
    </div>
  );
}
