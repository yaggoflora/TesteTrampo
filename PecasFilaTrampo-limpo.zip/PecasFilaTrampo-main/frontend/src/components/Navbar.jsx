import { LayoutDashboard, ListChecks, Table2, PlusCircle } from "lucide-react";

const TABS = [
  { id: "dashboard", label: "Painel", icon: LayoutDashboard, testid: "nav-tab-dashboard" },
  { id: "fila", label: "Fila de Peças", icon: ListChecks, testid: "nav-tab-fila" },
  { id: "controle", label: "Controle de Peças", icon: Table2, testid: "nav-tab-controle" },
];

export default function Navbar({ tab, setTab, onNovaPeca }) {
  return (
    <header className="bg-[#1E293B] text-white shadow-lg sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[72px]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#CC092F] flex items-center justify-center font-extrabold text-2xl shadow-md">
              B
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight tracking-tight">CRM Bradesco</h1>
              <p className="text-xs text-slate-300 font-medium">Orquestração e Publicação</p>
            </div>
          </div>
          <button
            onClick={onNovaPeca}
            className="flex items-center gap-2 bg-[#CC092F] hover:bg-[#A80726] text-white font-semibold h-12 px-6 rounded-lg text-base shadow-sm transition-colors focus:ring-4 focus:ring-[#CC092F]/40 active:scale-[0.98]"
          >
            <PlusCircle size={22} />
            <span className="hidden sm:inline">Nova Peça</span>
          </button>
        </div>
        <nav className="flex gap-1 -mb-px overflow-x-auto">
          {TABS.map(({ id, label, icon: Icon, testid }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-2 px-5 h-12 text-base font-semibold rounded-t-lg transition-colors whitespace-nowrap ${
                tab === id ? "bg-[#F8FAFC] text-[#CC092F]" : "text-slate-300 hover:text-white hover:bg-white/5"
              }`}
            >
              <Icon size={20} />
              {label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
}
