import { useEffect, useState, useCallback } from "react";
import { toast } from "sonner";
import { FileSpreadsheet, DatabaseBackup, Download, RefreshCw, Table2 } from "lucide-react";
import { api, API } from "@/api";
import { PECA_BADGE, FILA_BADGE } from "@/constants/options";

export default function ControleTable() {
  const [pecas, setPecas] = useState([]);
  const [backups, setBackups] = useState([]);
  const [loading, setLoading] = useState(true);

  const carregar = useCallback(async () => {
    setLoading(true);
    try {
      const [p, b] = await Promise.all([api.get("/pecas"), api.get("/backups")]);
      setPecas(p.data.filter((x) => x.status_peca));
      setBackups(b.data);
    } catch (e) {
      toast.error("Erro ao carregar o Controle de Peças.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { carregar(); }, [carregar]);

  const criarBackup = async () => {
    try {
      const { data } = await api.post("/backups");
      toast.success(`Backup criado: ${data.nome}`);
      carregar();
    } catch (e) {
      toast.error("Erro ao criar backup.");
    }
  };

  return (
    <div className="space-y-8 animate-fade-in-up">
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Controle de Peças</h2>
            <p className="text-base text-slate-600">{pecas.length} peça(s) gravada(s) no controle (OK, Ajustes, Alt. Validade)</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <a
              href={`${API}/export/excel`}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-12 px-6 rounded-lg text-base shadow-sm transition-colors"
            >
              <FileSpreadsheet size={20} /> Exportar Excel (.xlsx)
            </a>
            <button
              onClick={criarBackup}
              className="flex items-center gap-2 bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-12 px-6 rounded-lg text-base shadow-sm transition-colors"
            >
              <DatabaseBackup size={20} /> Criar Backup Agora
            </button>
            <button onClick={carregar} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-5 rounded-lg text-base transition-colors">
              <RefreshCw size={18} />
            </button>
          </div>
        </div>

        {loading ? (
          <p className="text-lg text-slate-500 py-10 text-center">Carregando...</p>
        ) : pecas.length === 0 ? (
          <div className="text-center py-14 text-slate-500">
            <Table2 size={48} className="mx-auto mb-3 text-slate-300" />
            <p className="text-lg font-medium">Nenhuma peça gravada no controle ainda.</p>
          </div>
        ) : (
          <div className="overflow-x-auto -mx-2 px-2">
            <table className="w-full text-base">
              <thead>
                <tr className="text-left text-sm text-slate-500 border-b-2 border-slate-200">
                  <th className="py-3 pr-4 font-semibold">Briefing</th>
                  <th className="py-3 pr-4 font-semibold">Campanha</th>
                  <th className="py-3 pr-4 font-semibold">Segmento</th>
                  <th className="py-3 pr-4 font-semibold">Canal Esperado</th>
                  <th className="py-3 pr-4 font-semibold">Fim Vigência</th>
                  <th className="py-3 pr-4 font-semibold">Status Peça</th>
                  <th className="py-3 pr-4 font-semibold">Status Fila</th>
                  <th className="py-3 font-semibold">Criador</th>
                </tr>
              </thead>
              <tbody>
                {pecas.map((p) => (
                  <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                    <td className="py-4 pr-4 font-mono font-semibold text-slate-900">{p.briefing || "—"}</td>
                    <td className="py-4 pr-4 max-w-[280px] truncate text-slate-700" title={p.nome_campanha}>{p.nome_campanha || "—"}</td>
                    <td className="py-4 pr-4 text-slate-700">{p.segmento || "—"}</td>
                    <td className="py-4 pr-4 text-slate-700">{p.canal_esperado || "—"}</td>
                    <td className="py-4 pr-4 text-slate-700">{p.fim_vigencia || "—"}</td>
                    <td className="py-4 pr-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold border ${PECA_BADGE[p.status_peca] || "bg-slate-100 text-slate-700 border-slate-300"}`}>
                        {p.status_peca}
                      </span>
                    </td>
                    <td className="py-4 pr-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold border ${FILA_BADGE[p.fila_status] || "bg-slate-100 text-slate-700 border-slate-300"}`}>
                        {p.fila_status || "—"}
                      </span>
                    </td>
                    <td className="py-4 text-slate-700">{p.criador || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8">
        <h3 className="text-xl font-bold text-slate-900 mb-1">Backups da Base</h3>
        <p className="text-base text-slate-600 mb-5">Snapshots congelados gerados automaticamente a cada 15 dias (dias 1 e 16) ou manualmente.</p>
        {backups.length === 0 ? (
          <p className="text-base text-slate-500">Nenhum backup criado ainda.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {backups.map((b) => (
              <li key={b.id} className="py-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-mono text-base font-semibold text-slate-900">{b.nome}</p>
                  <p className="text-sm text-slate-500">{b.total_pecas} peças • {b.tipo === "agendado" ? "Automático (quinzenal)" : "Manual"}</p>
                </div>
                <a
                  href={`${API}/backups/${b.id}/download`}
                  className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-11 px-5 rounded-lg text-base transition-colors"
                >
                  <Download size={18} /> Baixar
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
