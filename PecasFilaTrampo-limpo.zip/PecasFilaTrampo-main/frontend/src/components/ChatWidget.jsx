import { useEffect, useRef, useState } from "react";
import { Bot, X, Send, Loader2 } from "lucide-react";
import { API } from "@/api";

const SUGESTOES = [
  "Validar SMS sem acentuação",
  "Regras para Push PF",
  "Pode usar emoji em e-mail?",
  "Limite de caracteres no SMS",
];

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const sessionId = useRef(localStorage.getItem("crm_chat_session") || (() => {
    const id = crypto.randomUUID();
    localStorage.setItem("crm_chat_session", id);
    return id;
  })());
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  const enviar = async (texto) => {
    const msg = (texto ?? input).trim();
    if (!msg || sending) return;
    setInput("");
    setSending(true);
    setMessages((m) => [...m, { role: "user", content: msg }, { role: "assistant", content: "" }]);
    try {
      const res = await fetch(`${API}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId.current, message: msg }),
      });
      if (!res.ok) throw new Error("Falha na resposta da IA");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop();
        for (const part of parts) {
          const line = part.trim();
          if (!line.startsWith("data: ")) continue;
          const payload = line.slice(6);
          if (payload === "[DONE]") break;
          try {
            const obj = JSON.parse(payload);
            if (obj.delta) {
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: copy[copy.length - 1].content + obj.delta };
                return copy;
              });
            } else if (obj.error) {
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: "Ocorreu um erro ao consultar o assistente. Tente novamente." };
                return copy;
              });
            }
          } catch { /* ignora linhas parciais */ }
        }
      }
      setMessages((m) => [...m, { role: "assistant", content: "Posso ajudar com mais alguma dúvida? Envie a próxima peça ou pergunta abaixo.", closer: true }]);
    } catch (e) {
      setMessages((m) => {
        const copy = [...m];
        copy[copy.length - 1] = { role: "assistant", content: "Não consegui me comunicar com o servidor. Verifique sua conexão e tente novamente." };
        return copy;
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      {open && (
        <div
          className="fixed bottom-24 right-6 z-50 w-[380px] max-w-[calc(100vw-3rem)] h-[520px] max-h-[calc(100vh-8rem)] bg-white rounded-2xl border border-slate-200 shadow-2xl flex flex-col overflow-hidden animate-fade-in-up"
        >
          <div className="bg-[#1E293B] text-white px-5 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#CC092F] flex items-center justify-center">
                <Bot size={22} />
              </div>
              <div>
                <p className="font-bold text-base leading-tight">Assistente CRM</p>
                <p className="text-xs text-slate-300">Validação de peças • IA</p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="w-10 h-10 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors" aria-label="Fechar assistente">
              <X size={22} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F8FAFC]">
            {messages.length === 0 && (
              <div className="text-center pt-6">
                <Bot size={44} className="mx-auto mb-3 text-[#CC092F]" />
                <p className="text-base font-semibold text-slate-800 mb-1">Olá! Sou o Assistente de Validação do CRM Bradesco.</p>
                <p className="text-sm text-slate-600 mb-4">Envie o texto da peça e o canal para validação rigorosa antes do envio.</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {SUGESTOES.map((s) => (
                    <button
                      key={s}
                      onClick={() => enviar(s)}
                      className="text-sm font-semibold bg-white border border-[#CC092F]/30 text-[#CC092F] hover:bg-[#FDF2F4] rounded-full px-4 py-2 transition-colors min-h-[40px]"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 leading-relaxed whitespace-pre-wrap ${
                    m.role === "user"
                      ? "bg-[#CC092F] text-white rounded-br-sm text-base"
                      : m.closer
                        ? "bg-[#FDF2F4] border border-[#CC092F]/25 text-[#A80726] rounded-bl-sm text-sm font-semibold"
                        : "bg-white border border-slate-200 text-slate-800 rounded-bl-sm shadow-sm text-base"
                  }`}
                >
                  {m.content || (m.role === "assistant" && sending ? <Loader2 size={18} className="animate-spin" /> : "")}
                </div>
              </div>
            ))}
            {!sending && messages.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center pt-2">
                {SUGESTOES.map((s) => (
                  <button
                    key={s}
                    onClick={() => enviar(s)}
                    className="text-sm font-semibold bg-white border border-[#CC092F]/30 text-[#CC092F] hover:bg-[#FDF2F4] rounded-full px-4 py-2 transition-colors min-h-[40px]"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="p-3 border-t border-slate-200 bg-white flex gap-2">
            <input
              className="flex-1 h-12 text-base px-4 bg-[#F8FAFC] border-2 border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20"
              placeholder="Descreva a peça ou dúvida..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && enviar()}
            />
            <button
              onClick={() => enviar()}
              disabled={sending || !input.trim()}
              className="w-12 h-12 rounded-lg bg-[#CC092F] hover:bg-[#A80726] text-white flex items-center justify-center transition-colors disabled:opacity-40"
              aria-label="Enviar mensagem"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen((o) => !o)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-[#CC092F] hover:bg-[#A80726] text-white shadow-xl flex items-center justify-center transition-all active:scale-95 ${!open ? "animate-pulse-soft" : ""}`}
        aria-label="Abrir assistente virtual"
      >
        {open ? <X size={26} /> : <Bot size={26} />}
      </button>
    </>
  );
}
