import { AlertTriangle } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function DocsModal({ open, onClose, onConfirm, loading }) {
  return (
    <AlertDialog open={open} onOpenChange={(v) => !v && onClose()}>
      <AlertDialogContent className="max-w-xl">
        <AlertDialogHeader>
          <div className="w-16 h-16 rounded-2xl bg-amber-100 flex items-center justify-center mb-3">
            <AlertTriangle size={36} className="text-amber-600" />
          </div>
          <AlertDialogTitle className="text-2xl font-bold text-slate-900">Atenção Analista!</AlertDialogTitle>
          <AlertDialogDescription className="text-lg text-slate-700 leading-relaxed">
            Lembre-se de salvar o e-mail recebido do Marketing e o e-mail de resposta enviado na pasta <strong>"DOCS"</strong>.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-3 sm:gap-3">
          <AlertDialogCancel
            className="h-12 px-6 text-lg font-semibold border-2 border-slate-300 rounded-lg m-0"
            onClick={onClose}
          >
            Voltar
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={(e) => { e.preventDefault(); onConfirm(); }}
            disabled={loading}
            className="h-12 px-6 text-lg font-semibold bg-[#CC092F] hover:bg-[#A80726] text-white rounded-lg m-0"
          >
            {loading ? "Concluindo..." : "Entendi, já salvei em DOCS — Concluir"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
