import { useEffect, useState, useCallback } from "react";
import { toast } from "sonner";
import { RefreshCw, Trash2, Play, Inbox } from "lucide-react";
import { api } from "@/api";
import { FILA_BADGE, PECA_BADGE } from "@/constants/options";

function Badge({ value, map }) {
  if (!value) return <span className="text-slate-400 text-sm">—</span>;
  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold border ${map[value] || "bg-slate-100 text-slate-700 border-slate-300"}`}>
      {value}
    </span>
  );
}

export default function FilaTable({ onRetomar }) {
  const [pecas, setPecas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState("");

  const carregar = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/pecas");
      setPecas(data);
    } catch (e) {
      toast.error("Erro ao carregar a Fila de Peças.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { carregar(); }, [carregar]);

  const excluir = async (id) => {
    try {
      await api.delete(`/pecas/${id}`);
      toast.success("Peça removida da fila.");
      carregar();
    } catch (e) {
      toast.error("Erro ao remover peça.");
    }
  };

  const filtradas = pecas.filter((p) =>
    !busca || [p.nome_campanha, p.briefing, p.responsavel, p.assunto_email].join(" ").toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 lg:p-8 animate-fade-in-up">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Fila de Peças</h2>
          <p className="text-base text-slate-600">{pecas.length} peça(s) registrada(s)</p>
        </div>
        <div className="flex gap-3">
          <input
            className="h-12 text-base px-4 bg-white border-2 border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#CC092F] focus:ring-2 focus:ring-[#CC092F]/20 w-64"
            placeholder="Buscar por briefing, campanha..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
          <button onClick={carregar} className="flex items-center gap-2 bg-white border-2 border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold h-12 px-5 rounded-lg text-base transition-colors">
            <RefreshCw size={18} /> Atualizar
          </button>
        </div>
      </div>

      {loading ? (
        <p className="text-lg text-slate-500 py-10 text-center">Carregando...</p>
      ) : filtradas.length === 0 ? (
        <div className="text-center py-14 text-slate-500">
          <Inbox size={48} className="mx-auto mb-3 text-slate-300" />
          <p className="text-lg font-medium">Nenhuma peça na fila. Clique em "Nova Peça" para começar.</p>
        </div>
      ) : (
        <div className="overflow-x-auto -mx-2 px-2">
          <table className="w-full text-base">
            <thead>
              <tr className="text-left text-sm text-slate-500 border-b-2 border-slate-200">
                <th className="py-3 pr-4 font-semibold">Briefing</th>
                <th className="py-3 pr-4 font-semibold">Campanha</th>
                <th className="py-3 pr-4 font-semibold">Canal</th>
                <th className="py-3 pr-4 font-semibold">Status Fila</th>
                <th className="py-3 pr-4 font-semibold">Status Peça</th>
                <th className="py-3 pr-4 font-semibold">Responsável</th>
                <th className="py-3 font-semibold text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtradas.map((p) => (
                <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="py-4 pr-4 font-mono font-semibold text-slate-900">{p.briefing || "—"}</td>
                  <td className="py-4 pr-4 max-w-[320px] truncate text-slate-700" title={p.nome_campanha}>{p.nome_campanha || p.assunto_email || "—"}</td>
                  <td className="py-4 pr-4 text-slate-700">{p.tipo_canal || "—"}</td>
                  <td className="py-4 pr-4"><Badge value={p.fila_status} map={FILA_BADGE} /></td>
                  <td className="py-4 pr-4"><Badge value={p.status_peca} map={PECA_BADGE} /></td>
                  <td className="py-4 pr-4 text-slate-700">{p.responsavel || p.criador || "—"}</td>
                  <td className="py-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => onRetomar(p)}
                      className="inline-flex items-center gap-1.5 bg-[#1E293B] hover:bg-[#0F172A] text-white font-semibold h-11 px-4 rounded-lg text-sm transition-colors mr-2"
                    >
                      <Play size={16} /> Retomar
                    </button>
                    <button
                      onClick={() => excluir(p.id)}
                      className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-semibold h-11 px-4 rounded-lg text-sm transition-colors"
                    >
                      <Trash2 size={16} /> Excluir
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
