export const SEGMENTOS = ["Classic", "Exclusive", "Unif_PF", "Unif_NC", "Unif_PJ", "Unif_Prime", "Private", "Principal"];

export const AGENCIAS = ["ACCENTURE", "AG2", "Agência F&C", "Aldeiah", "BBDA", "Produtos + interno", "LBTM", "Leo Burnett", "P3K", "MMDemby", "Não informativo", "One.BRA", "Conexão Xpress", "ALMAP", "WIPRO", "CCP"];

export const TIPOS_CANAL = ["ATM", "EMKT", "IB", "NET_EMPRESA", "PUSH", "SMS", "MOBILE", "CLOUD PAGE", "WHATSAPP"];

export const CANAL_MAP = {
  ATM: ["ATM - GC Informativo", "ATM - GC Ofertas", "ATM - SAIBA MAIS", "TELA DE ENCERRAMENTO", "ATM - TELA RANDOMICA"],
  EMKT: ["CLOUD PAGE", "EMAIL MARKETING GENERICO", "EMAIL MARKETING PERSONALIZADO", "EMAIL MARKETING DISCLAIMER"],
  IB: ["IB - BANNER TRANSPROMO", "IB - ENTRETELA", "MENSAGENS E AVISOS", "IB - TELA DE ENCERRAMENTO"],
  MOBILE: ["MOBILE - CARDS", "MOBILE - MODAL"],
  NET_EMPRESA: ["NE - BANNER TELA DE VENDAS", "NE - TELA DE ENCERRAMENTO", "NE - TRANSPROMO"],
  PUSH: ["PUSH PF", "PUSH PJ"],
  SMS: ["SMS"],
  "CLOUD PAGE": ["CLOUD PAGE"],
  WHATSAPP: ["WHATSAPP"],
};

export const QTD_RESPOSTAS_OPCOES = [1, 2, 3, 4, 5];

export const POSSUI_LINK_OPCOES = ["Interno", "Externo", "Não possui"];

export const STATUS_PECA_OPCOES = ["OK", "Ajustes", "Alt Validade", "Desconsiderada", "Desconsiderada Alerta"];

export const STATUS_FILA_OPCOES = [
  { value: "RECEBIDA", label: "RECEBIDA", desc: "Peça recebida e verificada. Grava no Controle como OK.", cor: "green" },
  { value: "Em Recebimento", label: "Em Recebimento", desc: "Peça em conferência com ajustes. Grava no Controle como Ajustes.", cor: "amber" },
  { value: "FILA", label: "FILA", desc: "Nenhum analista assumiu. Bloqueia o processamento.", cor: "red" },
  { value: "Sem Retorno", label: "Sem Retorno", desc: "Sem resposta do Marketing. Gera e-mail de correção.", cor: "red" },
  { value: "Devolvida - Pendente", label: "Devolvida - Pendente", desc: "Devolvida e pendente. Gera e-mail de correção.", cor: "amber" },
  { value: "Devolvida - OK", label: "Devolvida - OK", desc: "Devolvida OK. Gera e-mail de correção.", cor: "blue" },
  { value: "Alt. Validade", label: "Alt. Validade", desc: "Alteração de validade. Grava no Controle e gera aviso.", cor: "blue" },
];

export const FILA_BADGE = {
  "RECEBIDA": "bg-emerald-50 text-emerald-800 border-emerald-200",
  "Em Recebimento": "bg-amber-50 text-amber-800 border-amber-200",
  "FILA": "bg-red-50 text-red-800 border-red-200",
  "Sem Retorno": "bg-red-50 text-red-800 border-red-200",
  "Devolvida - Pendente": "bg-amber-50 text-amber-800 border-amber-200",
  "Devolvida - OK": "bg-blue-50 text-blue-800 border-blue-200",
  "Alt. Validade": "bg-blue-50 text-blue-800 border-blue-200",
};

export const PECA_BADGE = {
  "OK": "bg-emerald-50 text-emerald-800 border-emerald-200",
  "Ajustes": "bg-amber-50 text-amber-800 border-amber-200",
  "Alt Validade": "bg-blue-50 text-blue-800 border-blue-200",
  "Desconsiderada": "bg-slate-100 text-slate-700 border-slate-300",
  "Desconsiderada Alerta": "bg-red-50 text-red-800 border-red-200",
};

export const hojeBR = () => {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
};
