from fastapi import FastAPI, APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import re
import json
import uuid
import hmac
import asyncio
import logging
import io
from pathlib import Path
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openai import AsyncOpenAI

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

TZ = ZoneInfo("America/Sao_Paulo")
NETWORK_BASE = r"\\corpbradesco\CRM\ORQUESTRACAO\DISPONIVEIS"

app = FastAPI()
api_router = APIRouter(prefix="/api")

# ---------------- Domínio ----------------

SEGMENTOS = ["Classic", "Exclusive", "Unif_PF", "Unif_NC", "Unif_PJ", "Unif_Prime", "Private", "Principal"]

CANAL_MAP = {
    "ATM": ["ATM - GC Informativo", "ATM - GC Ofertas", "ATM - SAIBA MAIS", "TELA DE ENCERRAMENTO", "ATM - TELA RANDOMICA"],
    "EMKT": ["CLOUD PAGE", "EMAIL MARKETING GENERICO", "EMAIL MARKETING PERSONALIZADO", "EMAIL MARKETING DISCLAIMER"],
    "IB": ["IB - BANNER TRANSPROMO", "IB - ENTRETELA", "MENSAGENS E AVISOS", "IB - TELA DE ENCERRAMENTO"],
    "MOBILE": ["MOBILE - CARDS", "MOBILE - MODAL"],
    "NET_EMPRESA": ["NE - BANNER TELA DE VENDAS", "NE - TELA DE ENCERRAMENTO", "NE - TRANSPROMO"],
    "PUSH": ["PUSH PF", "PUSH PJ"],
    "SMS": ["SMS"],
    "WHATSAPP": ["WHATSAPP"],
}

STATUS_MATRIX = {
    "RECEBIDA": {"escreve_controle": True, "status_peca": "OK", "template": "recebidas"},
    "Em Recebimento": {"escreve_controle": True, "status_peca": "Ajustes", "template": "ajuste_peca"},
    "FILA": {"escreve_controle": False, "bloqueado": True,
             "erro": "Nenhum analista assumiu a peça ainda. Não é possível prosseguir."},
    "Sem Retorno": {"escreve_controle": False, "template": "ajuste_peca"},
    "Devolvida - Pendente": {"escreve_controle": False, "template": "ajuste_peca"},
    "Devolvida - OK": {"escreve_controle": False, "template": "ajuste_peca"},
    "Alt. Validade": {"escreve_controle": True, "status_peca": "Alt Validade", "template": "alteracao_validade"},
}

EXCEL_HEADERS = ["Responsável", "Briefing", "Nome de Campanha", "Segmento", "Link da Pasta",
                 "Data de Entrega", "Data de Conferência", "Fim de Vigência", "Marketing", "Agência",
                 "Qtd Respostas", "Tipo de Canal (Mobile)", "Canal Esperado", "Status Peça",
                 "Observação", "Possui Link", "Status Fila", "Criador", "Pasta Renomeada", "Criado em"]

EXCEL_FIELDS = ["responsavel", "briefing", "nome_campanha", "segmento", "link_pasta",
                "data_entrega", "data_conferencia", "fim_vigencia", "marketing", "agencia",
                "qtd_respostas", "tipo_canal", "canal_esperado", "status_peca",
                "observacao", "possui_link", "fila_status", "criador", "pasta_renomeada", "created_at"]


class Peca(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    criador: str = ""
    assunto_email: str = ""
    responsavel: str = ""
    briefing: str = ""
    nome_campanha: str = ""
    segmento: str = ""
    link_pasta: str = ""
    data_entrega: str = ""
    data_conferencia: str = ""
    fim_vigencia: str = ""
    marketing: str = ""
    agencia: str = ""
    qtd_respostas: int = 0
    tipo_canal: str = ""
    canal_esperado: str = ""
    status_peca: str = ""
    observacao: str = ""
    possui_link: str = ""
    fila_status: str = ""
    template_tipo: str = ""
    email_assunto: str = ""
    email_corpo: str = ""
    pasta_renomeada: str = ""
    concluida: bool = False
    historico: List[dict] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class PecaCreate(BaseModel):
    criador: str
    assunto_email: str = ""
    responsavel: str = ""
    briefing: str = ""
    nome_campanha: str = ""
    segmento: str = ""
    link_pasta: str = ""
    data_entrega: str = ""
    data_conferencia: str = ""
    fim_vigencia: str = ""
    marketing: str = ""
    agencia: str = ""
    qtd_respostas: int = 0
    tipo_canal: str = ""
    canal_esperado: str = ""
    observacao: str = ""
    possui_link: str = ""
    status_peca: str = ""


class ParseRequest(BaseModel):
    assunto: str = ""
    nome_campanha: str = ""


class ProcessarRequest(BaseModel):
    fila_status: str
    observacao: Optional[str] = None


class EmailRequest(BaseModel):
    template_tipo: str
    ajustes_detalhe: str = ""
    validade_anterior: str = ""


class ChatRequest(BaseModel):
    session_id: str
    message: str


# ---------------- Parser inteligente ----------------

def parse_briefing(assunto: str) -> Optional[str]:
    nums = re.findall(r'\d{4,9}', assunto or "")
    if not nums:
        return None
    n = nums[0]
    return n if len(n) >= 8 else n.zfill(8)


def parse_campanha(nome: str):
    n = (nome or "").upper()
    tipo, esperado = "", ""
    if "WHATSAPP" in n or "WPP" in n:
        tipo, esperado = "WHATSAPP", "WHATSAPP"
    elif "NET_EMPRESA" in n or re.search(r'(^|_)NE(_|$)', n):
        tipo = "NET_EMPRESA"
        if "VENDAS" in n:
            esperado = "NE - BANNER TELA DE VENDAS"
        elif "ENCERRAMENTO" in n:
            esperado = "NE - TELA DE ENCERRAMENTO"
        elif "TRANSPROMO" in n:
            esperado = "NE - TRANSPROMO"
    elif "CLOUD" in n and "PAGE" in n:
        tipo, esperado = "EMKT", "CLOUD PAGE"
    elif "EMKT" in n or "EMAIL" in n or "E_MAIL" in n:
        tipo = "EMKT"
        if "DISCLAIMER" in n:
            esperado = "EMAIL MARKETING DISCLAIMER"
        elif "PERS" in n:
            esperado = "EMAIL MARKETING PERSONALIZADO"
        elif "CLOUD" in n:
            esperado = "CLOUD PAGE"
        else:
            esperado = "EMAIL MARKETING GENERICO"
    elif re.search(r'(^|_|[^A-Z])ATM([^A-Z]|_|$)', n) or "ATM" in n:
        tipo = "ATM"
        if "SAIBA" in n:
            esperado = "ATM - SAIBA MAIS"
        elif "RANDOMICA" in n:
            esperado = "ATM - TELA RANDOMICA"
        elif "ENCERRAMENTO" in n:
            esperado = "TELA DE ENCERRAMENTO"
        elif "OFERTA" in n or "_OFE" in n:
            esperado = "ATM - GC Ofertas"
        elif "INF" in n:
            esperado = "ATM - GC Informativo"
    elif "PUSH" in n:
        tipo = "PUSH"
        if re.search(r'_PJ(_|$)', n) or " PJ" in n:
            esperado = "PUSH PJ"
        elif re.search(r'_PF(_|$)', n) or " PF" in n or "_CLA" in n:
            esperado = "PUSH PF"
    elif "SMS" in n:
        tipo, esperado = "SMS", "SMS"
    elif "MOBILE" in n or "MODAL" in n or "CARDS" in n:
        tipo = "MOBILE"
        if "CARD" in n:
            esperado = "MOBILE - CARDS"
        elif "MODAL" in n:
            esperado = "MOBILE - MODAL"
    elif re.search(r'(^|_)IB(_|$)', n) or "INTERNET_BANKING" in n:
        tipo = "IB"
        if "TRANSPROMO" in n:
            esperado = "IB - BANNER TRANSPROMO"
        elif "ENTRETELA" in n:
            esperado = "IB - ENTRETELA"
        elif "AVISO" in n or "MENSAG" in n:
            esperado = "MENSAGENS E AVISOS"
        elif "ENCERRAMENTO" in n:
            esperado = "IB - TELA DE ENCERRAMENTO"
    return tipo, esperado


def parse_segmento(nome: str) -> str:
    n = (nome or "").upper()
    if "PRIVATE" in n or "_PVT" in n:
        return "Private"
    if "PRIME" in n:
        return "Unif_Prime"
    if "EXCLUSIVE" in n or "_EXC" in n:
        return "Exclusive"
    if "_PJ" in n:
        return "Unif_PJ"
    if "_NC" in n:
        return "Unif_NC"
    if "_CLA" in n or "CLASSIC" in n:
        return "Classic"
    if "_PF" in n:
        return "Unif_PF"
    return ""


@api_router.post("/parse")
async def parse_dados(req: ParseRequest):
    briefing = parse_briefing(req.assunto) or parse_briefing(req.nome_campanha) or ""
    tipo, esperado = parse_campanha(req.nome_campanha)
    link_pasta = f"{NETWORK_BASE}\\{briefing}" if briefing else ""
    return {
        "briefing": briefing,
        "link_pasta": link_pasta,
        "tipo_canal": tipo,
        "canal_esperado": esperado,
        "segmento": parse_segmento(req.nome_campanha),
        "data_conferencia": datetime.now(TZ).strftime("%d/%m/%Y"),
    }


# ---------------- CRUD Peças ----------------

@api_router.get("/pecas")
async def listar_pecas():
    return await db.pecas.find({}, {"_id": 0}).sort("created_at", -1).to_list(5000)


@api_router.post("/pecas", status_code=201)
async def criar_peca(req: PecaCreate):
    if not req.criador.strip():
        raise HTTPException(400, "O campo 'Nome do Criador' é obrigatório.")
    peca = Peca(**req.model_dump())
    peca.historico.append({"acao": "Peça registrada no Controle de Peças", "data": datetime.now(TZ).isoformat()})
    await db.pecas.insert_one(peca.model_dump())
    return peca


@api_router.get("/pecas/{peca_id}")
async def obter_peca(peca_id: str):
    doc = await db.pecas.find_one({"id": peca_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Peça não encontrada")
    return doc


@api_router.put("/pecas/{peca_id}")
async def atualizar_peca(peca_id: str, req: PecaCreate):
    update = req.model_dump()
    update["updated_at"] = datetime.now(timezone.utc).isoformat()
    res = await db.pecas.update_one({"id": peca_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(404, "Peça não encontrada")
    return await db.pecas.find_one({"id": peca_id}, {"_id": 0})


@api_router.delete("/pecas/{peca_id}")
async def excluir_peca(peca_id: str):
    res = await db.pecas.delete_one({"id": peca_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Peça não encontrada")
    return {"ok": True}


# ---------------- Matriz de Status ----------------

@api_router.post("/pecas/{peca_id}/processar")
async def processar_status(peca_id: str, req: ProcessarRequest):
    doc = await db.pecas.find_one({"id": peca_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Peça não encontrada")
    regra = STATUS_MATRIX.get(req.fila_status)
    if not regra:
        raise HTTPException(400, "Status de fila inválido")
    if regra.get("bloqueado"):
        raise HTTPException(409, regra["erro"])
    update = {
        "fila_status": req.fila_status,
        "template_tipo": regra["template"],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if req.observacao is not None:
        update["observacao"] = req.observacao
    if regra["escreve_controle"]:
        update["status_peca"] = regra["status_peca"]
    historico_entry = {
        "acao": f"Status '{req.fila_status}' processado" + (f" → Controle atualizado: {regra['status_peca']}" if regra["escreve_controle"] else " (sem gravação no Controle)"),
        "data": datetime.now(TZ).isoformat(),
    }
    await db.pecas.update_one({"id": peca_id}, {"$set": update, "$push": {"historico": historico_entry}})
    return {
        "ok": True,
        "escreve_controle": regra["escreve_controle"],
        "status_peca": regra.get("status_peca", ""),
        "template_tipo": regra["template"],
    }


# ---------------- E-mails padronizados ----------------

def saudacao_atual() -> str:
    h = datetime.now(TZ).hour
    if h < 12:
        return "bom dia"
    if h < 18:
        return "boa tarde"
    return "boa noite"


def mm_aa(fim_vigencia: str) -> str:
    m = re.search(r'(\d{2})/(\d{2})/(\d{4})', fim_vigencia or "")
    if m:
        return f"{m.group(2)}.{m.group(3)[2:]}"
    m2 = re.search(r'(\d{4})-(\d{2})-(\d{2})', fim_vigencia or "")
    if m2:
        return f"{m2.group(2)}.{m2.group(1)[2:]}"
    return "__.__"


@api_router.post("/pecas/{peca_id}/email")
async def gerar_email(peca_id: str, req: EmailRequest):
    doc = await db.pecas.find_one({"id": peca_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Peça não encontrada")
    saudacao = saudacao_atual()
    campanha = doc.get("nome_campanha") or "(nome da campanha)"
    canais = doc.get("tipo_canal") or "(canal)"
    analista = doc.get("responsavel") or doc.get("criador") or "(analista)"
    assinatura = f"Atenciosamente,\n{analista} | CRM Bradesco - Orquestração e Publicação"

    if req.template_tipo == "alteracao_validade":
        vig = mm_aa(doc.get("fim_vigencia", ""))
        ant = req.validade_anterior or vig
        assunto = f"Ajuste / Alteração de Validade - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As pastas abaixo tiveram a validade alterada, conforme solicitado.\n\n"
                 f"Canais: {canais}\n"
                 f"Campanha: {campanha}\n"
                 f"Alteração: De Val_{ant} para Val_ATE_{vig}\n\n"
                 f"{assinatura}")
    elif req.template_tipo == "recebidas":
        vig = mm_aa(doc.get("fim_vigencia", ""))
        assunto = f"Peças Recebidas - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As peças abaixo foram recebidas, verificadas e arquivadas em nosso controle.\n\n"
                 f"Canais: {canais}\n"
                 f"Validade: Val_ATE_{vig}\n\n"
                 f"{assinatura}")
    else:
        detalhe = req.ajustes_detalhe or doc.get("observacao") or "[Descrever aqui o detalhamento do ajuste]"
        assunto = f"Ajuste de Peça - Campanha: {campanha}"
        corpo = (f"Prezado(a), {saudacao}!\n\n"
                 f"As peças abaixo necessitam de ajustes:\n\n"
                 f"Canais: {canais}\n"
                 f"Ajustes Necessários: {detalhe}\n\n"
                 f"{assinatura}")

    await db.pecas.update_one(
        {"id": peca_id},
        {"$set": {"email_assunto": assunto, "email_corpo": corpo, "updated_at": datetime.now(timezone.utc).isoformat()},
         "$push": {"historico": {"acao": f"E-mail gerado ({req.template_tipo})", "data": datetime.now(TZ).isoformat()}}},
    )
    return {"assunto": assunto, "corpo": corpo, "saudacao": saudacao}


# ---------------- Conclusão ----------------

@api_router.post("/pecas/{peca_id}/concluir")
async def concluir_peca(peca_id: str):
    doc = await db.pecas.find_one({"id": peca_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Peça não encontrada")
    hoje = datetime.now(TZ).strftime("%Y%m%d")
    assunto_base = doc.get("assunto_email") or doc.get("nome_campanha") or f"Briefing {doc.get('briefing', '')}"
    pasta_renomeada = f"{hoje}_ {assunto_base}"
    await db.pecas.update_one(
        {"id": peca_id},
        {"$set": {"concluida": True, "pasta_renomeada": pasta_renomeada, "updated_at": datetime.now(timezone.utc).isoformat()},
         "$push": {"historico": {"acao": f"Processamento concluído. Pasta renomeada: {pasta_renomeada}", "data": datetime.now(TZ).isoformat()}}},
    )
    return {"ok": True, "pasta_renomeada": pasta_renomeada}


# ---------------- Dashboard ----------------

@api_router.get("/stats")
async def stats():
    pecas = await db.pecas.find({}, {"_id": 0}).to_list(5000)
    por_status_peca, por_status_fila, por_canal = {}, {}, {}
    for p in pecas:
        if p.get("status_peca"):
            por_status_peca[p["status_peca"]] = por_status_peca.get(p["status_peca"], 0) + 1
        if p.get("fila_status"):
            por_status_fila[p["fila_status"]] = por_status_fila.get(p["fila_status"], 0) + 1
        if p.get("tipo_canal"):
            por_canal[p["tipo_canal"]] = por_canal.get(p["tipo_canal"], 0) + 1
    return {
        "total": len(pecas),
        "concluidas": sum(1 for p in pecas if p.get("concluida")),
        "no_controle": sum(1 for p in pecas if p.get("status_peca")),
        "por_status_peca": por_status_peca,
        "por_status_fila": por_status_fila,
        "por_canal": por_canal,
    }


# ---------------- Excel & Backup ----------------

def build_xlsx(rows: List[dict]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Controle de Peças"
    header_fill = PatternFill("solid", fgColor="1E293B")
    for col, header in enumerate(EXCEL_HEADERS, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
    for r, row in enumerate(rows, 2):
        for c, field in enumerate(EXCEL_FIELDS, 1):
            ws.cell(row=r, column=c, value=row.get(field, ""))
    for i, header in enumerate(EXCEL_HEADERS, 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = max(14, min(45, len(header) + 8))
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


@api_router.get("/export/excel")
async def export_excel():
    pecas = await db.pecas.find({}, {"_id": 0}).sort("created_at", -1).to_list(10000)
    content = build_xlsx(pecas)
    nome = f"CONTROLE_CRM_{datetime.now(TZ).strftime('%Y_%m_%d')}.xlsx"
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{nome}"'})


async def create_backup(tipo: str):
    pecas = await db.pecas.find({}, {"_id": 0}).sort("created_at", -1).to_list(10000)
    nome = f"BACKUP_CONTROLE_CRM_{datetime.now(TZ).strftime('%Y_%m_%d')}.xlsx"
    doc = {
        "id": str(uuid.uuid4()),
        "nome": nome,
        "tipo": tipo,
        "total_pecas": len(pecas),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "data": pecas,
    }
    await db.backups.insert_one(dict(doc))
    return {k: v for k, v in doc.items() if k != "data"}


@api_router.post("/backups", status_code=201)
async def criar_backup_manual():
    return await create_backup("manual")


@api_router.get("/backups")
async def listar_backups():
    return await db.backups.find({}, {"_id": 0, "data": 0}).sort("created_at", -1).to_list(200)


@api_router.get("/backups/{backup_id}/download")
async def baixar_backup(backup_id: str):
    doc = await db.backups.find_one({"id": backup_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Backup não encontrado")
    content = build_xlsx(doc.get("data", []))
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{doc["nome"]}"'})


@api_router.post("/cron/backup-quinzenal")
async def cron_backup_quinzenal(request: Request):
    # Cron endpoints must ack 2xx immediately; enqueue/background the actual work.
    auth = request.headers.get("authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else ""
    secret = os.environ.get("WEBHOOK_CRON_SECRET", "")
    if not secret or not hmac.compare_digest(token, secret):
        raise HTTPException(401, "Não autorizado")
    asyncio.create_task(create_backup("agendado"))
    return {"ok": True}


# ---------------- Chatbot IA ----------------

SYSTEM_PROMPT = """# FINALIDADE
Você é o Assistente Virtual de Validação do time de CRM Bradesco (Publicação e Orquestração). Sua função é tirar dúvidas dos analistas e validar rigorosamente o texto, imagem e regras de peças de comunicação antes do envio.

# REGRAS E FLUXO DE VALIDAÇÃO
1. Identifique o canal de publicação (SMS, E-mail, Push, Card, Modal, CloudPage, ATM). Se não informado, pergunte ao usuário.
2. Identifique o público (PF ou PJ, com ou sem imagem).
3. Consulte as fontes por PRIORIDADE OBRIGATÓRIA:
   - PRIORIDADE 1 (Arquivos Internos): 'GUIDE CRM FÁBRICA PUBLICAÇÃO_V7.pdf' e 'GUIDE BE.pdf'.
   - PRIORIDADE 2 (Links Oficiais Salesforce):
     * SMS (Regras e Opt-out): https://trailhead.salesforce.com/trailblazer-community/feed/0D53A00004th1nGSAQ
     * E-mail (Entregabilidade e Spam): https://help.salesforce.com/s/articleView?id=mktg.mc_es_email_deliverability_best_practices.htm&language=en_US&type=5
     * Push (Engajamento e limites): https://help.salesforce.com/s/articleView?id=mktg.mc_mp_manage_push_notifications.htm&language=en_US&type=5
     * CloudPages (Formulários e AMPscript): https://help.salesforce.com/s/articleView?id=002743057&language=no&type=1
     * In-App (Cards/Modais): https://developer.android.com/develop/ui/compose/components/dialog

4. Avalie 4 pilares: Regras do Canal, Ortografia, Sentido/Clareza e Boas Práticas.

# EXCEÇÕES DE CANAL
- SMS: Falta de acentuação NÃO é erro se a mensagem iniciar com "Bradesco:" ou "Bradesco Prime:", ou terminar com "Sair: PARE".
- Variáveis (ex: %%NOME%%): Ignorar na análise de texto.
- Emojis: Validar apenas se houver espaçamento colado no texto ou espaço duplo.
- Ignorar termos normais de copywriting de marketing (ex: "pra", frases curtas e diretas).

# FORMATO DA RESPOSTA (SEJA EXTREMAMENTE OBJETIVO)
Se a peça estiver VÁLIDA:
- Regras: OK
- Ortografia: OK
- Sentido: OK
- Boas práticas: OK
- Verificação: "O usuário deve verificar manualmente se a peça está de acordo com todas as regras presentes nos Guides."

Se a peça estiver INVÁLIDA:
- Liste cada problema por pilar com a fonte, ex:
- Ortografia: Erro de concordância verbal. (Fonte: página 41 do GUIDE BE)
- Boas Práticas: Uso inadequado de emoji em SMS. (Fonte: página 47 do GUIDE BE)

Responda sempre em Português do Brasil, de forma objetiva."""

CHAT_MODEL = os.environ.get("OPENAI_CHAT_MODEL", "gpt-4o-mini")
chat_sessions: dict[str, list[dict]] = {}


@api_router.post("/chat")
async def chat(req: ChatRequest):
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        raise HTTPException(500, "Chave de IA não configurada")

    history = chat_sessions.setdefault(req.session_id, [{"role": "system", "content": SYSTEM_PROMPT}])
    history.append({"role": "user", "content": req.message})

    await db.chat_messages.insert_one({
        "session_id": req.session_id, "role": "user", "content": req.message,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })

    client = AsyncOpenAI(api_key=api_key)

    async def event_generator():
        full = ""
        try:
            stream = await client.chat.completions.create(
                model=CHAT_MODEL,
                messages=history,
                stream=True,
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    full += delta
                    yield f"data: {json.dumps({'delta': delta}, ensure_ascii=False)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)}, ensure_ascii=False)}\n\n"
        if full:
            history.append({"role": "assistant", "content": full})
            await db.chat_messages.insert_one({
                "session_id": req.session_id, "role": "assistant", "content": full,
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@api_router.get("/chat/history/{session_id}")
async def chat_history(session_id: str):
    return await db.chat_messages.find({"session_id": session_id}, {"_id": 0}).sort("created_at", 1).to_list(200)


@api_router.get("/")
async def root():
    return {"message": "CRM Bradesco - Orquestração e Publicação API"}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
