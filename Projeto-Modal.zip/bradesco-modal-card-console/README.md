# Bradesco · Modal/Card Console

Projeto com **duas versões** da mesma automação (busca de imagens por similaridade
em planilhas Excel, com verificação de descrição e vencimento):

```
bradesco-modal-card-console/
├── web/                      # App 100% navegador (HTML/CSS/JS puro, sem servidor)
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   └── README.md             # instruções detalhadas de uso do app web
│
└── python/                   # Script original em Python
    └── pesquisa_cards.py
```

## web/ — App no navegador

Não precisa instalar nada. Abra `web/index.html` no navegador (duplo clique
ou arraste pra janela) e siga as instruções em `web/README.md`.
Roda 100% localmente — nada é enviado para nenhum servidor.

## python/ — Script Python

Requer as dependências abaixo instaladas:

```bash
pip install openpyxl pillow numpy imagehash
```

Antes de rodar, edite as configurações no topo de `pesquisa_cards.py`
(`CAMINHO_EXCEL`, `NOME_DA_ABA`, `CAMINHO_IMAGEM_PESQUISA`, etc.) para
apontar para os caminhos reais na sua máquina. Depois:

```bash
python pesquisa_cards.py
```

## Como abrir no VS Code

1. Extraia o `.zip`
2. No VS Code: `File > Open Folder...` → selecione a pasta `bradesco-modal-card-console`
3. Para o app web: clique com o botão direito em `web/index.html` → "Open with Live Server"
   (extensão recomendada), ou apenas abra o arquivo direto no navegador
4. Para o script Python: abra um terminal integrado (`` Ctrl+` ``), instale as
   dependências acima e rode `python python/pesquisa_cards.py`
