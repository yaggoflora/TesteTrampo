'use strict';
// Auditoria GUIDE (public/static/wb/guide.js) no Chromium: precisa do pacote playwright (NODE_PATH).
const assert = require('assert'); const fs = require('fs'); const path = require('path');
const { chromium } = require('playwright');
const wb = path.resolve(__dirname, '../public/static/wb');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  await p.setContent('<html><body></body></html>');
  for (const f of ['parser.js', 'guide.js']) await p.addScriptTag({ content: fs.readFileSync(path.join(wb, f), 'utf8') });
  const rodar = (arq, o) => p.evaluate(([s, o]) => { const r = WB.guide.auditar(s, o); return { r, t: WB.guide.formatar(r) }; }, [fs.readFileSync(path.join(__dirname, 'guide', arq), 'utf8'), o]);

  const bom = await rodar('bom.html', { assunto: 'Seu limite foi atualizado' });
  assert.strictEqual(bom.r.status, 'APROVADO'); assert.strictEqual(bom.r.geral, 100);

  const ruim = await rodar('ruim.html', { assunto: 'ASSUNTO: Oferta imperdível só hoje para você cliente!!', gifs: [{ arquivo: 'a.gif', kb: 1500, largura: 800, segundos: 12 }] });
  assert.strictEqual(ruim.r.status, 'REPROVADO');
  const p0 = ruim.r.p0.map(a => a.msg).join('|');
  for (const trecho of ['HTTP em vez de HTTPS', 'href "#"', 'Optout oculto', 'RedirectTo', 'alias', 'Disclaimer obrigatório ausente', 'disclaimer de investimentos']) assert(p0.includes(trecho), 'P0 esperado: ' + trecho);
  const p2 = ruim.r.p2.map(a => a.msg).join('|');
  for (const trecho of ['35', 'rótulo "Assunto:"', 'GIF a.gif com 1500 KB', '800px', '12.0s', 'DOCTYPE']) assert(p2.includes(trecho), 'P2 esperado: ' + trecho);
  assert(ruim.r.p1.some(a => a.msg.includes('Nome 1')));
  // formato exato do GUIDE
  const ordem = ['**STATUS GERAL**', '**RESUMO EXECUTIVO**', '**ERROS P0**', '**ERROS P1**', '**ERROS P2**', '**MELHORIAS P3**', '**REGRAS ATENDIDAS**', '**SCORE FINAL**', '• Compliance:', '• UX:', '• Responsividade:', '• HTML:', '• Dark Mode:', '• **Score Geral:', '**VEREDITO FINAL**'];
  let pos = -1; for (const o of ordem) { const i = ruim.t.indexOf(o); assert(i > pos, 'ordem do relatório: ' + o); pos = i; }
  console.log('guide OK');
  await b.close();
})().catch(e => { console.error(e); process.exit(1); });
