# Validador de pacotes EMKT + SFMC Workbench

Agora o programa é **só HTML, CSS e JavaScript**: o servidor roda em Node.js (sem Python) e o
front-end é o mesmo de antes. A lógica que estava em Python foi portada módulo a módulo, com os
mesmos nomes de funções e campos, as mesmas regras e as mesmas mensagens.

## Para rodar
Precisa de Node.js 20 ou mais novo (https://nodejs.org/).

    npm install          # uma vez; só baixa o que é opcional (sharp e tesseract.js)
    node servidor.js     # abre em http://127.0.0.1:5000

Atalhos: `iniciar_validador.bat` (duplo clique no Windows) ou `./iniciar_validador.sh` (bash).
Se a porta 5000 estiver ocupada, sobe na seguinte. Para subir em servidor, veja `DEPLOY.md`.

## Para compartilhar com quem NÃO tem Node.js
Gere o pacote portátil **uma vez**, num computador com Node.js e internet:

- Windows: duplo clique em `gerar_exe.bat` (ou `./gerar_executavel.sh` no Git Bash).
- Resultado: `dist/ValidadorEMKT/` e `dist/ValidadorEMKT.zip`, com o Node dentro (`runtime/`).
- Mande o **.zip** para o time. Quem recebe extrai e dá duplo clique em `ValidadorEMKT.bat`
  (abre em http://127.0.0.1:5000). Não precisa de Node, Python nem internet.
  As instruções para eles estão em `LEIA-ME-USUARIO.txt` (vai dentro do zip como `LEIA-ME.txt`).
- Diferente do `.exe` antigo, dá para gerar para outro sistema: `ALVO=win-x64` (padrão),
  `linux-x64`, `darwin-arm64` etc. Sem internet liberada: `NODE_ZIP=<arquivo do Node>` ou
  `NODE_DIST_DIR=<pasta do Node>`. A lógica está em `scripts/gerar_pacote.js`.
- Quando o alvo é o próprio sistema, o script roda `--testar` no pacote pronto e só termina com
  sucesso se os 53 testes passarem.
- Relatórios, cache e `regras-time.js` ficam ao lado do programa (pasta `relatorios/` etc.).

## Estrutura
    servidor.js                    entrada (substitui validador_emkt_unificado.py)
    src/app.js                     rotas HTTP (eram as rotas do Flask)
    src/config.js                  caminhos, limpeza de relatórios, escolha de porta
    src/validador/                 16 módulos (ocr, pacote, comparador, regras, imagens...) — mesmos nomes do Python
    src/lib/                       peças que o Python trazia de bibliotecas: difflib, zip, xml, docx, HTML (BeautifulSoup), multipart...
    src/testes/validador_testes.js os 53 testes do --testar
    public/html, public/static     front-end (index, CSS, JS das duas abas, CodeMirror, Workbench)
    test/                          testes diferenciais (comparam com o Python original; só para desenvolvimento)
    scripts/gerar_pacote.js        gerador do pacote portátil

## Comandos
    node servidor.js --testar            53 testes no terminal (sai com 1 se algum falhar)
    node servidor.js --instalar-idioma-por   instala o português do Tesseract
    npm test                             o mesmo que --testar

## Leitura do texto das imagens (OCR)
O primeiro motor disponível é usado: `rapidocr` (modelos PP-OCR, pacote opcional
`@gutenye/ocr-node`), `windows`, `tesseract` (programa instalado) ou `tesseract-js` (WebAssembly,
`npm install tesseract.js`, funciona em servidor sem instalar programa). Force um com `OCR_MOTOR`.
`sharp` (opcional) é usado para abrir as imagens. Sem motor, a conferência roda sem ler os banners
e nunca aprova (fica em "atenção"), como antes.

## O que mudou em relação à versão em Python
- Sumiram `sincronizar.py` e a ideia de "script único": no Python, o programa tinha de ser embutido
  num arquivo só para o executável; em JS os arquivos ficam como estão e é só editar e reiniciar.
- `iniciar_validador.*` e `gerar_*` agora usam Node.js no lugar de Python.
- Novas variáveis para servidor: `HOST`, `PORT`, `DADOS_DIR`, `MAX_UPLOAD_MB`, `HORAS_TEMPORARIAS`.

## Editar
Edite o arquivo que quiser (por exemplo `public/static/validador.js` ou `src/validador/regras.js`) e
reinicie o servidor. `regras-time.js`: se existir um `regras-time.js` ao lado do programa (ou em
`DADOS_DIR`), ele vale no lugar do embutido.


## Auditoria GUIDE
Aba do Workbench com as regras do GUIDE (P0 a P3, scores e veredito, no formato do GUIDE). Detalhes e decisões em
`ALTERACOES.md` e no cabeçalho de `public/static/wb/guide.js`. Parâmetros por segmento: seção `guide` de
`public/static/wb/regras-time.js`.
