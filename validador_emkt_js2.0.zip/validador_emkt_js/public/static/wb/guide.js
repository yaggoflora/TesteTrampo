/* guide.js — Auditoria GUIDE de E-mail Marketing Bradesco.
 *
 * Aplica ao HTML da peça as regras do GUIDE (assunto, pré-header, texto, personalização, estrutura, grid,
 * tipografia, CTA, links, GIF, ícones, QR Code, footer, optout, disclaimer, dark mode, segmentação,
 * investimentos, compliance/LGPD) e devolve o relatório no formato do GUIDE:
 *   STATUS GERAL · RESUMO EXECUTIVO · ERROS P0 · ERROS P1 · ERROS P2 · MELHORIAS P3 ·
 *   REGRAS ATENDIDAS · SCORE FINAL · VEREDITO FINAL.
 *
 * Classificação (do GUIDE): P0 reprovação imediata · P1 crítico · P2 médio · P3 melhoria.
 *
 * Decisões que o GUIDE não fecha (estão aqui, em um lugar só, para o time ajustar):
 *   STATUS: qualquer P0 => REPROVADO; sem P0 mas com P1 ou P2 => APROVADO COM RESSALVAS; só P3 ou nada => APROVADO.
 *   SCORE por categoria = 100 − (30·P0 + 15·P1 + 7·P2 + 3·P3), mínimo 0.
 *   Score Geral = 30% Compliance + 20% UX + 20% Responsividade + 20% HTML + 10% Dark Mode.
 *
 * O que um HTML sozinho não mostra (link funciona, página existe, conteúdo dentro de imagem, QR Code, cor
 * oficial do segmento, gutter/8 colunas, cards) NÃO é dado como conforme: vai em "não verificável
 * automaticamente" no resumo. Parâmetros por segmento (domínios, telefones, logos, disclaimers, cores) vêm
 * de window.WB_REGRAS_TIME.guide (ver regras-time.js); sem eles a coerência do segmento fica para conferência manual.
 *
 * Funciona no navegador (DOMParser) e depende de WB.parser.
 */
(function (WB) {
  'use strict';

  const PESO = { P0: 30, P1: 15, P2: 7, P3: 3 };
  const PESO_CAT = { compliance: 0.30, ux: 0.20, resp: 0.20, html: 0.20, dark: 0.10 };
  const NOME_CAT = { compliance: 'Compliance', ux: 'UX', resp: 'Responsividade', html: 'HTML', dark: 'Dark Mode' };

  const PADRAO = {
    assuntoMax: 35, preHeaderMax: 40, textoMax: 600,
    largura: 700, margemLateral: 42, gutter: 24,
    fonteHtml: 'verdana', corpoMin: 18, corpoMax: 24, legendaMin: 14, entrelinhaMin: 24,
    headerTituloMin: 28, headerSubtituloMin: 26, headerCampoMin: 22,
    cta: { altura: 48, padLateral: 28, padVertical: 14, fonte: 20, max: 3 },
    gifMaxKB: 1024, gifMaxLargura: 700, gifMaxSegundos: 10,
    iconeMin: 40, qrMin: 130, logoFooterMinPct: 30,
    footerRodapePct: 0.70,                       // sem marcação de footer: o que vem depois de 70% do texto é rodapé
    // Por segmento (preencher no regras-time.js): { dominios:[], telefones:[], logos:[], disclaimers:[], coresCTA:[] }
    segmentos: {}
  };

  const CONFIG = () => {
    const t = (window.WB_REGRAS_TIME && window.WB_REGRAS_TIME.guide) || {};
    const c = Object.assign({}, PADRAO, t);
    c.cta = Object.assign({}, PADRAO.cta, t.cta || {});
    return c;
  };

  // ------------------------------------------------------------------ utilidades
  const SEM_ACENTO = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '');
  const norm = s => SEM_ACENTO(s).toLowerCase();
  const limpa = s => String(s || '').replace(/\s+/g, ' ').trim();
  const NOMES_COR = { white: '#ffffff', black: '#000000', red: '#ff0000', blue: '#0000ff', green: '#008000', gray: '#808080', grey: '#808080', yellow: '#ffff00', silver: '#c0c0c0', orange: '#ffa500', navy: '#000080', transparent: null };

  function parseCor(v) {
    if (!v) return null;
    v = String(v).trim().toLowerCase().replace(/\s*!important/, '');
    if (v in NOMES_COR) v = NOMES_COR[v];
    if (!v) return null;
    let m = /^#([0-9a-f]{3})$/.exec(v);
    if (m) return m[1].split('').map(h => parseInt(h + h, 16));
    m = /^#([0-9a-f]{6})/.exec(v);
    if (m) return [0, 2, 4].map(i => parseInt(m[1].substr(i, 2), 16));
    m = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/.exec(v);
    if (m) return [+m[1], +m[2], +m[3]];
    return null;
  }
  const lum = ([r, g, b]) => {
    const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const contraste = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };

  function parseEstilo(s) {
    const o = {};
    for (const par of String(s || '').split(';')) {
      const i = par.indexOf(':'); if (i < 0) continue;
      o[par.slice(0, i).trim().toLowerCase()] = par.slice(i + 1).trim();
    }
    return o;
  }
  const px = v => {
    if (v == null) return null;
    const m = /^(-?[\d.]+)\s*(px|pt)?$/i.exec(String(v).trim());
    if (!m) return null;
    return /pt/i.test(m[2] || '') ? +m[1] * 4 / 3 : +m[1];
  };
  /** padding: "14px 28px" / "14px 28px 14px" / "14px" -> {t,r,b,l} (px) ou null. */
  function parsePadding(est) {
    let t = null, r = null, b = null, l = null;
    if (est.padding) {
      const p = est.padding.split(/\s+/).map(px);
      if (p.every(x => x != null)) {
        if (p.length === 1) [t, r, b, l] = [p[0], p[0], p[0], p[0]];
        else if (p.length === 2) [t, r, b, l] = [p[0], p[1], p[0], p[1]];
        else if (p.length === 3) [t, r, b, l] = [p[0], p[1], p[2], p[1]];
        else if (p.length === 4) [t, r, b, l] = p;
      }
    }
    const ov = (k, atual) => (est[k] != null && px(est[k]) != null ? px(est[k]) : atual);
    t = ov('padding-top', t); r = ov('padding-right', r); b = ov('padding-bottom', b); l = ov('padding-left', l);
    return { t, r, b, l };
  }

  const SISTEMA = ['view_email_url', 'unsub_center_url', 'unsub_url', 'profile_center_url', 'subscription_center_url', 'emailname_', 'email_name_', 'jobid', 'listid', 'batchid', 'memberid', 'subscriberid', 'emailaddr', 'xtmonth', 'xtmonthnumeric', 'xtday', 'xtyear', 'replyname', 'replyemailaddress', 'fromname', 'fromaddress', 'member_busname', 'member_addr', 'member_city', 'member_state', 'member_postalcode', 'member_country'];
  const eSistema = n => n[0] === '_' || SISTEMA.includes(n.toLowerCase());

  // ---------------------------------------------------------------------- núcleo
  function auditar(src, opts) {
    opts = opts || {};
    const C = CONFIG();
    const P = WB.parser;
    const tk = P.tokenize(src);
    const L = P.lineIndex(src);
    const { doc, restore, strip } = P.dom(src, tk);
    const body = doc.body || doc.documentElement;

    const achados = [];            // {p, cat, regra, msg, linha}
    const atendidas = [];
    const manuais = [];
    const add = (p, cat, regra, msg, el) => {
      const o = el && el.getAttribute && el.getAttribute('data-wbo');
      achados.push({ p, cat, regra, msg, linha: o != null ? L.line(+o) : null });
    };
    const ok = (txt) => atendidas.push(txt);
    const manual = (txt) => manuais.push(txt);

    const texto = el => limpa(strip(el.textContent || ''));
    const attr = (el, n) => el.hasAttribute(n) ? restore(el.getAttribute(n)) : null;
    const estiloProprio = el => parseEstilo(restore(el.getAttribute('style') || ''));

    // CSS em <style>: regras simples "seletor { ... }" só para tag/classe/id (dark mode, media queries e herança básica)
    const cssTexto = [...doc.querySelectorAll('style')].map(s => s.textContent).join('\n');
    const temMedia = re => re.test(cssTexto);

    // ---------- navegação
    const ancestrais = el => { const a = []; for (let p = el; p && p.nodeType === 1; p = p.parentElement) a.push(p); return a; };
    const herdado = (el, prop) => {
      for (const a of ancestrais(el)) {
        const e = estiloProprio(a);
        if (e[prop] != null) return e[prop];
        if (prop === 'font-family' && a.tagName === 'FONT' && a.getAttribute('face')) return a.getAttribute('face');
        if (prop === 'color' && a.tagName === 'FONT' && a.getAttribute('color')) return a.getAttribute('color');
      }
      return null;
    };
    const fundoDe = el => {
      for (const a of ancestrais(el)) {
        const e = estiloProprio(a);
        if (/gradient|url\(/i.test((e.background || '') + (e['background-image'] || ''))) return null;
        const c = parseCor(e['background-color'] || (/^[^(]*(#[0-9a-f]{3,6}|rgb)/i.test(e.background || '') ? e.background.match(/#[0-9a-f]{3,6}|rgba?\([^)]*\)/i)[0] : null) || a.getAttribute('bgcolor'));
        if (c) return c;
      }
      return [255, 255, 255];
    };
    const oculto = el => ancestrais(el).some(a => {
      const e = estiloProprio(a);
      return /^none$/i.test(e.display || '') || /^hidden$/i.test(e.visibility || '') || px(e['font-size']) === 0 ||
        px(e['max-height']) === 0 || +(e.opacity || 1) === 0 || a.hasAttribute('hidden');
    });

    // ---------- blocos de texto (para tipografia e contagem)
    const NO_TEXTO = [];
    {
      const w = doc.createTreeWalker(body, 4);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        const p = n.parentElement;
        if (!p || p.closest('script,style,title,head,template,noscript')) continue;
        const t = limpa(strip(n.data));
        if (!t) continue;
        NO_TEXTO.push({ n, p, t });
      }
    }

    // ---------- header / footer
    const UNSUB_ANCESTRAL = /%%(unsub_center_url|unsub_url|subscription_center_url|profile_center_url)%%|unsub/i;
    const marca = (el, re) => re.test(norm([el.id, el.getAttribute('class'), el.getAttribute('role'), el.getAttribute('data-type'), el.getAttribute('name'), el.getAttribute('data-name')].filter(Boolean).join(' ')));
    const comentariosDe = re => tk.tokens.filter(t => t.t === 'comment' && re.test(norm(src.slice(t.s, t.e))));
    let footerEl = body.querySelector('footer') || [...body.querySelectorAll('[id],[class],[role],[name],[data-type],[data-name]')].reverse().find(e => marca(e, /(^|[^a-z])(footer|rodape)([^a-z]|$)/));
    let headerEl = body.querySelector('header') || [...body.querySelectorAll('[id],[class],[role],[name],[data-type],[data-name]')].find(e => marca(e, /(^|[^a-z])(header|cabecalho|topo)([^a-z]|$)/));
    // marcação por comentário (<!-- footer -->): o bloco é o primeiro tr/table/div seguinte
    const porComentario = (re, ultimo) => {
      const cs = comentariosDe(re); if (!cs.length) return null;
      const c = ultimo ? cs[cs.length - 1] : cs[0];
      const prox = tk.tokens.find(t => t.t === 'start' && t.s >= c.e && /^(tr|table|div|td|section)$/.test(t.name));
      if (!prox) return null;
      return doc.querySelector('[data-wbo="' + prox.s + '"]');
    };
    if (!footerEl) footerEl = porComentario(/(^|[^a-z])(footer|rodape)([^a-z]|$)/, true);
    if (!headerEl) headerEl = porComentario(/(^|[^a-z])(header|cabecalho)([^a-z]|$)/, false);

    // posição relativa de um elemento no texto do corpo (0..1), para o rodapé "por posição"
    // Sem marcação, o rodapé começa no primeiro trecho que é claramente de rodapé (descadastro, disclaimer,
    // dados legais) e vai até o fim da peça.
    const RE_RODAPE = /descadastr|unsubscribe|opt.?out|disclaimer|mensagem autom|e-?mail autom|n[aã]o responda|cnpj|direitos reservados|pol[ií]tica de privacidade/i;
    const inicioRodape = footerEl ? null : (NO_TEXTO.find(x => RE_RODAPE.test(x.t) || (x.p.closest('a') && UNSUB_ANCESTRAL.test(restore(x.p.closest('a').getAttribute('href') || '')))) || {}).n || null;
    const dentroDoFooter = el => footerEl ? footerEl.contains(el)
      : !!inicioRodape && (el === inicioRodape.parentElement || !!(inicioRodape.compareDocumentPosition(el) & 4));
    const footerPorPosicao = !footerEl;
    const textoFooter = footerEl ? texto(footerEl)
      : limpa(NO_TEXTO.filter(x => dentroDoFooter(x.p)).map(x => x.t).join(' '));
    const textoCorpo = limpa(NO_TEXTO.filter(x => !dentroDoFooter(x.p) && !oculto(x.p)).map(x => x.t).join(' '));
    const textoTudo = limpa(NO_TEXTO.map(x => x.t).join(' '));
    const alts = [...body.querySelectorAll('img')].map(i => restore(i.getAttribute('alt') || '')).join(' ');
    const hrefsTudo = [...body.querySelectorAll('a[href]')].map(a => restore(a.getAttribute('href'))).join(' ');
    const universo = norm(textoTudo + ' ' + alts + ' ' + hrefsTudo);

    // ============================================================ ASSUNTO
    const assunto = limpa(opts.assunto);
    if (!assunto) {
      manual('assunto não informado (preencha o campo Assunto para validar tamanho, rótulo e clareza)');
    } else {
      let bom = true;
      const n = Array.from(assunto).length;
      if (n > C.assuntoMax) { bom = false; add('P2', 'ux', 'Assunto', `Assunto com ${n} caracteres; o máximo recomendado é ${C.assuntoMax} (excede em ${n - C.assuntoMax}).`); }
      if (/^\s*assunto\s*[:\-–—]/i.test(assunto)) { bom = false; add('P2', 'ux', 'Assunto', 'O assunto traz o rótulo "Assunto:" no texto; ele não deve aparecer.'); }
      if (assunto === assunto.toUpperCase() && /[A-ZÀ-Ý]{4,}/.test(assunto)) { bom = false; add('P3', 'ux', 'Assunto', 'Assunto todo em maiúsculas; pouco atrativo e com risco de filtro de spam.'); }
      if ((assunto.match(/!/g) || []).length > 1) { bom = false; add('P3', 'ux', 'Assunto', 'Mais de um ponto de exclamação no assunto; reduza para manter clareza e objetividade.'); }
      if (bom) ok(`Assunto dentro do limite (${n}/${C.assuntoMax} caracteres) e sem rótulo.`);
    }

    // ============================================================ PRÉ-HEADER
    let pre = limpa(opts.preheader), preOrigem = 'informado';
    if (!pre) {
      const cand = NO_TEXTO.slice(0, 12).find(x => oculto(x.p) && x.t.length > 3);
      if (cand) { pre = limpa(NO_TEXTO.filter(x => oculto(x.p) && x.p.closest('[data-wbo]') === cand.p.closest('[data-wbo]')).map(x => x.t).join(' ')) || cand.t; preOrigem = 'lido do texto oculto no início do HTML'; }
    }
    if (!pre) {
      add('P2', 'ux', 'Pré-header', 'Pré-header não encontrado: não foi informado e não há texto de pré-visualização oculto no início do HTML.');
    } else {
      let bom = true;
      const n = Array.from(pre.replace(/[​-‏͏­﻿\s]+/g, ' ').trim()).length;
      if (n > C.preHeaderMax) { bom = false; add('P2', 'ux', 'Pré-header', `Pré-header com ${n} caracteres; o limite é ${C.preHeaderMax} (excede em ${n - C.preHeaderMax}).`); }
      if (!/[.]\s*$/.test(pre.replace(/[​-‏͏­﻿\s]+$/g, ''))) { bom = false; add('P2', 'ux', 'Pré-header', 'O pré-header não termina com ponto final.'); }
      if (/^\s*pr[eé][\s\-]?header\s*[:\-–—]/i.test(pre)) { bom = false; add('P2', 'ux', 'Pré-header', 'O pré-header traz o rótulo "Pré-header:" no texto; ele não deve aparecer.'); }
      if (assunto && norm(assunto).replace(/[^a-z0-9]/g, '') === norm(pre).replace(/[^a-z0-9]/g, '')) { bom = false; add('P3', 'ux', 'Pré-header', 'O pré-header repete o assunto; ele deve complementá-lo e estimular a abertura.'); }
      if (bom) ok(`Pré-header (${preOrigem}) dentro do limite (${n}/${C.preHeaderMax}), com ponto final e sem rótulo.`);
    }

    // ============================================================ TEXTO
    {
      const n = Array.from(textoCorpo).length;
      if (n > C.textoMax) add('P3', 'ux', 'Texto', `Texto do corpo com ${n} caracteres; o recomendado é até ${C.textoMax}. Prefira texto escaneável e objetivo.`);
      else ok(`Texto do corpo com ${n} caracteres (recomendado até ${C.textoMax}).`);
      const nImg = body.querySelectorAll('img').length;
      if (nImg > 0 && n < 40) add('P2', 'ux', 'Texto', 'Quase não há texto em HTML no corpo; o conteúdo parece estar dentro de imagens (deve ser texto HTML).');
      for (const im of (opts.imagensComTexto || [])) {
        if ((im.palavras || 0) >= 12) add('P2', 'ux', 'Texto em imagem', `A imagem ${im.arquivo} contém um bloco de texto (${im.palavras} palavras lidas por OCR); texto deve estar em HTML.`);
      }
      if (!(opts.imagensComTexto || []).length) manual('blocos de texto dentro de imagens (só o OCR do Validador enxerga isso)');
      manual('objetividade, clareza, atratividade e facilidade de leitura do texto (avaliação editorial)');
    }

    // ============================================================ PERSONALIZAÇÃO
    {
      const semAmp = src.replace(/%%\[[\s\S]*?\]%%/g, ' ').replace(/%%=[\s\S]*?=%%/g, ' ');
      const vars = new Set([...semAmp.matchAll(/%%([^%\n]{1,60}?)%%/g)].map(m => m[1].trim()));
      let bom = true;
      for (const v of vars) {
        if (eSistema(v)) continue;
        const k = norm(v).replace(/[\s_-]+/g, '');
        if (/^(nome|data)\d+$/.test(k) || /^data(fim|inicio)$/.test(k)) { bom = false; add('P1', 'html', 'Personalização', `Campo genérico incorreto %%${v}%%: use o nome real do campo (ex.: %%NOME%%, %%PRIMEIRONOME%% ou o campo da Data Extension).`); }
      }
      const restante = semAmp.replace(/%%([^%\n]{1,60}?)%%/g, ' ');
      if (/%%/.test(restante.replace(/%%\[|\]%%|%%=|=%%/g, ''))) { bom = false; add('P1', 'html', 'Personalização', 'Há "%%" solto no HTML: variável de personalização malformada.'); }
      if (bom) ok(vars.size ? 'Campos de personalização sem nomes genéricos proibidos.' : 'Sem campos de personalização incorretos.');
    }

    // ============================================================ ESTRUTURA
    {
      if (!headerEl) manual('estrutura de Header não identificada por marcação (use <header>, id/class "header" ou comentário <!-- header -->)');
      if (!footerEl) {
        const temRodape = /(disclaimer|descadastr|unsub|optout|opt-out)/.test(universo);
        if (!temRodape) add('P1', 'ux', 'Estrutura', 'Footer não identificado: sem marcação de rodapé e sem optout/disclaimer no fim da peça.');
        else manual('Footer sem marcação (considerado o trecho final da peça; use <footer>, id/class "footer" ou comentário <!-- footer -->)');
      }
      if (!NO_TEXTO.length && !body.querySelector('img')) add('P1', 'ux', 'Estrutura', 'Body vazio: não há texto nem imagem no corpo.');
      if (headerEl && footerEl && NO_TEXTO.length) ok('Estrutura Header, Body e Footer identificada.');
    }

    // ============================================================ GRID
    {
      const larguras = [];
      for (const el of body.querySelectorAll('table,td,div,center,section')) {
        const e = estiloProprio(el);
        for (const v of [el.getAttribute('width'), e.width, e['max-width']]) { const n = px(v); if (n && n >= 320) larguras.push(n); }
      }
      if (larguras.includes(C.largura)) {
        ok(`Largura total de ${C.largura}px encontrada.`);
        const maior = Math.max(...larguras);
        if (maior > C.largura) add('P2', 'ux', 'Grid', `Há elemento com largura de ${maior}px; a largura total oficial é ${C.largura}px.`);
      } else add('P1', 'ux', 'Grid', `Largura total de ${C.largura}px não encontrada (table/td/div com width ou max-width de ${C.largura}px).`);
      const margem = [...body.querySelectorAll('[style],td[width]')].some(el => {
        const p = parsePadding(estiloProprio(el));
        return p.l === C.margemLateral || p.r === C.margemLateral || (el.tagName === 'TD' && px(el.getAttribute('width')) === C.margemLateral && !el.textContent.trim());
      });
      if (margem) ok(`Margem lateral de ${C.margemLateral}px encontrada.`);
      else add('P2', 'ux', 'Grid', `Margem lateral de ${C.margemLateral}px não encontrada (padding lateral ou coluna espaçadora).`);
      manual(`grid de 8 colunas e gutter de ${C.gutter}px, alinhamento da estrutura e cards (hierarquia, responsividade e área clicável)`);
    }

    const ehCandidatoCTA = a => {
      if (a.querySelector('img') && !texto(a)) return false;
      const e = estiloProprio(a);
      const classe = norm(a.getAttribute('class') || '') + ' ' + norm(a.getAttribute('role') || '');
      if (/(^|[\s_-])(btn|button|botao|cta)([\s_-]|$)/.test(classe)) return true;
      if (e['background-color'] || e.background || a.getAttribute('bgcolor')) return true;
      const td = a.closest('td');
      if (td && texto(td) === texto(a) && (td.getAttribute('bgcolor') || estiloProprio(td)['background-color'] || estiloProprio(td).background)) return true;
      return false;
    };

    // ============================================================ TIPOGRAFIA
    {
      let foraFonte = 0, semFonte = 0, pequenos = [], corpoFora = [], entrelinhaCurta = [], semEntrelinha = 0, avaliados = 0;
      for (const x of NO_TEXTO) {
        if (oculto(x.p)) continue;
        const ehBotao = (() => { const a = x.p.closest('a'); return !!a && ehCandidatoCTA(a); })();
        avaliados++;
        const ff = herdado(x.p, 'font-family');
        if (!ff) semFonte++;
        else if (!norm(ff).includes(C.fonteHtml)) foraFonte++;
        const fs = px(herdado(x.p, 'font-size'));
        if (fs != null) {
          if (fs < C.legendaMin) pequenos.push({ x, fs });
          else if (x.t.length > 80 && !dentroDoFooter(x.p) && (fs < C.corpoMin || fs > C.corpoMax) && !(headerEl && headerEl.contains(x.p))) corpoFora.push({ x, fs });
          const lhRaw = herdado(x.p, 'line-height');
          if (ehBotao) { /* a altura do botão tem regra própria */ }
          else if (lhRaw == null) semEntrelinha++;
          else {
            const lh = /^[\d.]+$/.test(lhRaw.trim()) ? parseFloat(lhRaw) * fs : px(lhRaw);
            if (lh != null && lh < C.entrelinhaMin) entrelinhaCurta.push({ x, lh });
          }
        }
      }
      const exemplo = l => ` Ex.: "${l[0].x.t.slice(0, 40)}"`;
      if (foraFonte) add('P1', 'ux', 'Tipografia', `${foraFonte} trecho(s) com fonte diferente de ${C.fonteHtml[0].toUpperCase() + C.fonteHtml.slice(1)}.`);
      if (semFonte && avaliados) add('P1', 'ux', 'Tipografia', `${semFonte} trecho(s) sem font-family definida (cai na fonte padrão do cliente de e-mail; o padrão é Verdana).`);
      if (!foraFonte && !semFonte && avaliados) ok('Fonte Verdana em todo o texto.');
      if (pequenos.length) add('P2', 'ux', 'Tipografia', `${pequenos.length} trecho(s) com fonte abaixo de ${C.legendaMin}px (mínimo para legenda).` + exemplo(pequenos));
      else if (avaliados) ok(`Nenhum texto abaixo de ${C.legendaMin}px.`);
      if (corpoFora.length) add('P2', 'ux', 'Tipografia', `${corpoFora.length} bloco(s) de corpo fora de ${C.corpoMin}px a ${C.corpoMax}px (ex.: ${corpoFora[0].fs}px).` + exemplo(corpoFora));
      if (entrelinhaCurta.length) add('P2', 'ux', 'Tipografia', `${entrelinhaCurta.length} trecho(s) com entrelinha abaixo de ${C.entrelinhaMin}px (ex.: ${Math.round(entrelinhaCurta[0].lh)}px).` + exemplo(entrelinhaCurta));
      else if (semEntrelinha > avaliados / 2 && avaliados) add('P2', 'ux', 'Tipografia', `Entrelinha (line-height) não definida na maior parte do texto; o mínimo é ${C.entrelinhaMin}px.`);
      else if (avaliados) ok(`Entrelinha de ${C.entrelinhaMin}px ou mais onde definida.`);

      if (headerEl) {
        const dentro = NO_TEXTO.filter(x => headerEl.contains(x.p) && !oculto(x.p));
        const tam = x => px(herdado(x.p, 'font-size'));
        const titulo = dentro.find(x => /^H1$/.test(x.p.tagName)) || dentro.slice().sort((a, b) => (tam(b) || 0) - (tam(a) || 0))[0];
        if (titulo && tam(titulo) != null && tam(titulo) < C.headerTituloMin) add('P1', 'ux', 'Header', `Título do Header com ${tam(titulo)}px; o mínimo é ${C.headerTituloMin}px.`, titulo.p);
        for (const x of dentro) {
          if (/^H2$/.test(x.p.tagName) && tam(x) != null && tam(x) < C.headerSubtituloMin) add('P1', 'ux', 'Header', `Subtítulo do Header com ${tam(x)}px; o mínimo é ${C.headerSubtituloMin}px.`, x.p);
          if (/%%[^%]+%%/.test(x.n.data) && tam(x) != null && tam(x) < C.headerCampoMin) add('P1', 'ux', 'Header', `Campo dinâmico do Header com ${tam(x)}px; o mínimo é ${C.headerCampoMin}px.`, x.p);
        }
      }
    }

    // ============================================================ LINKS
    const links = [...body.querySelectorAll('a')];
    const hrefDe = a => a.hasAttribute('href') ? restore(a.getAttribute('href')).trim() : null;
    const ehAmpSo = h => /^%%[^%]+%%$/.test(h) || /^%%=.*=%%$/.test(h);
    {
      let invalidos = 0, http = 0, vazios = 0;
      for (const a of links) {
        const h = hrefDe(a);
        if (h && /^(mailto:|tel:|sms:)/i.test(h)) continue;
        if (a.hasAttribute('name') && !a.hasAttribute('href')) continue;
        if (h === null || h === '' || h === '#' || /^javascript:/i.test(h)) { vazios++; add('P0', 'compliance', 'Links', `Link sem destino (${h === null ? 'sem href' : 'href "' + (h || '') + '"'})${texto(a) ? ': "' + texto(a).slice(0, 40) + '"' : ''}.`, a); continue; }
        if (ehAmpSo(h)) continue;
        if (/^http:\/\//i.test(h)) { http++; add('P0', 'compliance', 'Links', `Link com HTTP em vez de HTTPS: ${h.slice(0, 80)}.`, a); continue; }
        if (/^https?:\/\//i.test(h)) {
          const resto = h.replace(/%%=[\s\S]*?=%%|%%[^%]+%%/g, 'x');
          let valido = true;
          try { const u = new URL(resto); valido = !!u.hostname && /\./.test(u.hostname) && !/\s/.test(resto); } catch (e) { valido = false; }
          if (!valido) { invalidos++; add('P0', 'compliance', 'Links', `URL inválida: ${h.slice(0, 80)}.`, a); }
        } else if (!/^(%%|#)/.test(h)) { invalidos++; add('P0', 'compliance', 'Links', `Link sem protocolo https:// (${h.slice(0, 60)}); o destino pode não abrir.`, a); }
      }
      for (const im of body.querySelectorAll('img[src]')) {
        const s = restore(im.getAttribute('src')).trim();
        if (/^http:\/\//i.test(s)) { http++; add('P0', 'compliance', 'Links', `Imagem carregada por HTTP em vez de HTTPS: ${s.slice(0, 80)}.`, im); }
      }
      if (!invalidos && !http && !vazios && links.length) ok('Todos os links com destino e em HTTPS (ou variável de rastreamento).');
      manual('se cada URL funciona, a página existe e o redirecionamento está correto (exige acesso à internet)');

      // URL visível no conteúdo (fora do rodapé, onde os canais oficiais podem aparecer)
      const URLVIS = /\b(?:https?:\/\/|www\.)[^\s<>"']+|\b[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.(?:com\.br|gov\.br|com|net|org|br)\b(?:\/[^\s<>"']*)?/i;
      const vis = NO_TEXTO.filter(x => !dentroDoFooter(x.p) && !oculto(x.p) && !/@/.test(x.t) && URLVIS.test(x.t));
      if (vis.length) add('P2', 'ux', 'Links', `${vis.length} URL(s) visível(is) no conteúdo, o que é proibido (ex.: "${(URLVIS.exec(vis[0].t) || [''])[0].slice(0, 50)}"). Use um botão ou link com texto.`, vis[0].p);
      else ok('Nenhuma URL visível no conteúdo.');
    }

    // ============================================================ CTA
    const ctas = links.filter(ehCandidatoCTA).filter(a => !dentroDoFooter(a) && !/^%%(unsub|profile|subscription|view_email)/i.test(hrefDe(a) || ''));
    {
      const K = C.cta;
      if (ctas.length > K.max) add('P2', 'ux', 'CTA', `${ctas.length} CTAs na peça; o máximo é ${K.max}.`);
      else if (ctas.length) ok(`${ctas.length} CTA(s) (máximo ${K.max}).`);
      let tudoOk = ctas.length > 0;
      for (const a of ctas) {
        const nome = `CTA "${texto(a).slice(0, 30)}"`;
        const td = a.closest('td');
        const ea = estiloProprio(a), et = td ? estiloProprio(td) : {};
        const h = hrefDe(a);
        if (!h || h === '#' || /^javascript:/i.test(h)) { tudoOk = false; add('P0', 'compliance', 'CTA', `${nome} sem link (href vazio, "#" ou ausente).`, a); }
        const grad = [ea.background, ea['background-image'], et.background, et['background-image']].some(v => /gradient/i.test(v || ''));
        if (grad) { tudoOk = false; add('P1', 'ux', 'CTA', `${nome} com gradiente; a cor deve ser sólida.`, a); }
        const sombra = [ea['box-shadow'], et['box-shadow'], ea['text-shadow'], et['text-shadow'], ea.filter, et.filter].some(v => v && !/^none$/i.test(v));
        if (sombra) { tudoOk = false; add('P1', 'ux', 'CTA', `${nome} com sombra (box-shadow/text-shadow); é proibido.`, a); }
        const fs = px(herdado(a, 'font-size'));
        if (fs != null && fs !== K.fonte) { tudoOk = false; add('P2', 'ux', 'CTA', `${nome} com fonte de ${fs}px; o padrão é ${K.fonte}px.`, a); }
        const ff = herdado(a, 'font-family');
        if (ff && !norm(ff).includes(C.fonteHtml)) { tudoOk = false; add('P1', 'ux', 'CTA', `${nome} com fonte fora do padrão Verdana.`, a); }
        const pa = parsePadding(ea), pt = parsePadding(et);
        const pad = { t: pa.t ?? pt.t, r: pa.r ?? pt.r, b: pa.b ?? pt.b, l: pa.l ?? pt.l };
        if (pad.l != null && pad.r != null && (pad.l !== K.padLateral || pad.r !== K.padLateral)) { tudoOk = false; add('P2', 'ux', 'CTA', `${nome} com padding lateral de ${pad.l}/${pad.r}px; o padrão é ${K.padLateral}px.`, a); }
        if (pad.t != null && pad.b != null && (pad.t !== K.padVertical || pad.b !== K.padVertical)) { tudoOk = false; add('P2', 'ux', 'CTA', `${nome} com padding vertical de ${pad.t}/${pad.b}px; o padrão é ${K.padVertical}px.`, a); }
        let alt = px(ea.height) ?? px(et.height) ?? (td && px(td.getAttribute('height'))) ?? null;
        if (alt == null && pad.t != null && pad.b != null) {
          const lhRaw = herdado(a, 'line-height'), f = fs;
          const lh = lhRaw == null ? null : /^[\d.]+$/.test(lhRaw.trim()) ? (f != null ? parseFloat(lhRaw) * f : null) : px(lhRaw);
          if (lh != null) alt = pad.t + pad.b + lh;
        }
        if (alt != null && Math.round(alt) !== K.altura) { tudoOk = false; add('P2', 'ux', 'CTA', `${nome} com altura de ${Math.round(alt)}px; o padrão é ${K.altura}px.`, a); }
        if (alt == null) manual(`altura de 48px do ${nome} (não calculável pelo estilo em linha)`);
        const cor = a.getAttribute('bgcolor') || ea['background-color'] || et['background-color'] || (td && td.getAttribute('bgcolor'));
        if (!cor && !/gradient/i.test(ea.background || '')) { tudoOk = false; add('P2', 'ux', 'CTA', `${nome} sem cor de fundo sólida definida.`, a); }
      }
      if (ctas.length && tudoOk) ok('CTAs com link, cor sólida, sem sombra/gradiente e dentro das medidas do GUIDE.');
      if (!ctas.length) add('P3', 'ux', 'CTA', 'Nenhum botão (CTA) identificado na peça; confirme se a peça deve ter chamada para ação.');
      manual('cor do CTA conforme as cores oficiais do segmento (cadastre "coresCTA" do segmento no regras-time.js)');
    }

    // ============================================================ GIF
    {
      const gifsHtml = [...body.querySelectorAll('img')].filter(i => /\.gif(\?|$)/i.test(restore(i.getAttribute('src') || '')));
      const dados = opts.gifs || [];
      for (const g of dados) {
        const rot = `GIF ${g.arquivo}`;
        if (g.kb > C.gifMaxKB) add('P2', 'ux', 'GIF', `${rot} com ${Math.round(g.kb)} KB; o máximo é 1 MB.`);
        if (g.largura > C.gifMaxLargura) add('P2', 'ux', 'GIF', `${rot} com ${g.largura}px de largura; o máximo é ${C.gifMaxLargura}px.`);
        if (g.segundos > C.gifMaxSegundos) add('P2', 'ux', 'GIF', `${rot} com ${g.segundos.toFixed(1)}s de duração; o máximo é ${C.gifMaxSegundos}s.`);
        if (g.kb <= C.gifMaxKB && g.largura <= C.gifMaxLargura && g.segundos <= C.gifMaxSegundos) ok(`${rot} dentro dos limites (${Math.round(g.kb)} KB, ${g.largura}px, ${g.segundos.toFixed(1)}s).`);
      }
      if (gifsHtml.length && !dados.length) manual(`GIF (${gifsHtml.length} no HTML): tamanho até 1 MB, largura até 700px e duração até 10s — abra o HTML a partir do Validador para medir`);
      if (gifsHtml.length && textoCorpo.length < 60) add('P2', 'ux', 'GIF', 'A peça tem GIF e quase nenhum texto HTML: o GIF não pode substituir o conteúdo HTML nem ocupar a peça inteira.');
      if (gifsHtml.length) manual('se o GIF complementa o conteúdo (avaliação editorial)');
    }

    // ============================================================ ÍCONES e QR CODE
    {
      for (const im of body.querySelectorAll('img')) {
        const s = restore(im.getAttribute('src') || ''), alt = restore(im.getAttribute('alt') || '');
        const ident = norm(s.split('/').pop() + ' ' + alt);
        const e = estiloProprio(im);
        const w = px(im.getAttribute('width')) ?? px(e.width), h = px(im.getAttribute('height')) ?? px(e.height);
        if (/(^|[^a-z])qr([^a-z]|$)|qrcode|qr code/.test(ident)) {
          if ((w != null && w < C.qrMin) || (h != null && h < C.qrMin)) add('P2', 'ux', 'QR Code', `QR Code com ${w ?? '?'}x${h ?? '?'}px; o mínimo é ${C.qrMin}x${C.qrMin}px.`, im);
          else ok('QR Code com tamanho mínimo.');
          manual('QR Code: fundo branco, borda de proteção de 12px e contraste (confira a imagem)');
        } else if (/(^|[^a-z])(icon|icone|ico)([^a-z]|$)/.test(ident)) {
          if ((w != null && w < C.iconeMin) || (h != null && h < C.iconeMin)) add('P2', 'ux', 'Ícones', `Ícone com ${w ?? '?'}x${h ?? '?'}px; a área mínima é ${C.iconeMin}x${C.iconeMin}px.`, im);
        }
      }
      if (body.querySelector('img')) manual('ícones: traço de 2px e legibilidade (confira as imagens)');
    }

    // ============================================================ OPTOUT
    const UNSUB_VAR = /%%(unsub_center_url|unsub_url|subscription_center_url|profile_center_url)%%/i;
    const optouts = links.filter(a => {
      const h = hrefDe(a) || '';
      return UNSUB_VAR.test(h) || /unsub/i.test(h) || /^unsubscribe$/i.test(a.getAttribute('alias') || '') ||
        /descadastr|cancel\w* (o )?(recebimento|inscri)|n[aã]o (quer|deseja|quero) receber|unsubscribe|opt.?out|sair da lista/i.test(norm(texto(a)) + ' ' + texto(a));
    });
    {
      if (!optouts.length) {
        add('P0', 'compliance', 'Optout', 'Sem Optout: não há link de descadastro na peça.');
      } else {
        let bom = true;
        const falha = (msg, a) => { bom = false; add('P0', 'compliance', 'Optout', msg, a); };
        const a = optouts[optouts.length - 1];
        const h = hrefDe(a) || '';
        if (!h || h === '#' || /^javascript:/i.test(h)) falha('Optout quebrado: o link de descadastro não tem destino.', a);
        if (oculto(a) || parseEstiloOculto(a)) falha('Optout oculto: o link de descadastro está escondido (display/visibility/tamanho/opacidade).', a);
        else {
          const cor = parseCor(herdado(a, 'color')), fundo = fundoDe(a);
          if (cor && fundo && contraste(cor, fundo) < 1.5) falha('Optout invisível: a cor do texto é praticamente igual à do fundo.', a);
        }
        if (!dentroDoFooter(a)) falha('Optout fora do Footer: o link de descadastro deve ficar no rodapé.', a);
        if (!/RedirectTo\s*\(/i.test(h)) falha('Optout não utiliza RedirectTo: o href deve usar %%=RedirectTo(...)=%%.', a);
        const alias = a.getAttribute('alias');
        if (!alias || alias.trim().toLowerCase() !== 'unsubscribe') falha(`Optout com alias incorreto (${alias ? '"' + alias + '"' : 'ausente'}): o alias deve ser "Unsubscribe".`, a);
        if (bom) ok('Optout existe, funciona, está visível no Footer, usa RedirectTo e alias Unsubscribe.');
      }
    }
    function parseEstiloOculto(a) {
      const f = px(herdado(a, 'font-size'));
      return f != null && f < 6;
    }

    // ============================================================ FOOTER / DISCLAIMER
    {
      const tf = norm(textoFooter + ' ' + (footerEl ? [...footerEl.querySelectorAll('img')].map(i => i.getAttribute('alt') || '').join(' ') : ''));
      const logoRe = /bradesco/;
      if (!logoRe.test(tf) && !(footerEl && [...footerEl.querySelectorAll('img')].some(i => /bradesco|logo/.test(norm((i.getAttribute('src') || '') + (i.getAttribute('alt') || '')))))) add('P1', 'ux', 'Footer', 'Assinatura da marca (Bradesco) não encontrada no Footer.');
      else ok('Assinatura da marca presente no Footer.');
      if (!/cnpj|banco bradesco|s\.?\s?a\.?|direitos reservados|privacidade|©|&copy;/.test(tf)) add('P2', 'ux', 'Footer', 'Informações legais não encontradas no Footer (razão social, CNPJ, direitos ou política de privacidade).');
      else ok('Informações legais presentes no Footer.');

      // logo: horizontal, ao menos 30% da largura do footer
      const logo = footerEl && [...footerEl.querySelectorAll('img')].find(i => /logo|bradesco/.test(norm((i.getAttribute('src') || '') + (i.getAttribute('alt') || ''))));
      const wl = logo && (px(logo.getAttribute('width')) ?? px(estiloProprio(logo).width));
      if (wl != null) {
        const pct = wl / C.largura * 100;
        if (pct < C.logoFooterMinPct) add('P2', 'ux', 'Footer', `Logo do Footer com ${Math.round(pct)}% da largura (${wl}px de ${C.largura}px); o mínimo é ${C.logoFooterMinPct}%.`, logo);
        else ok(`Logo do Footer com ${Math.round(pct)}% da largura.`);
      } else manual('logo horizontal com no mínimo 30% do Footer (largura da imagem não definida no HTML)');

      // Disclaimer
      const temDisc = /disclaimer|aviso legal|este e-?mail|esta mensagem|mensagem autom|comunica[cç][aã]o autom/.test(tf) || textoFooter.length > 120;
      const antifraude = /fraude|golpe|phishing|n[aã]o (solicita|pede|enviamos|envia)|nunca (solicit|pe[cç]a|envi)|desconfie|link suspeito|dados pessoais|senha/;
      const canais = /sac|0800|ouvidoria|fale conosco|bradesco\.com\.br|app bradesco|whatsapp|central de atendimento|atendimento/;
      const automatica = /mensagem autom[aá]tica|e-?mail autom[aá]tico|comunica[cç][aã]o autom[aá]tica|enviad[oa] automaticamente|n[aã]o responda|n[aã]o (deve|precisa) ser respondid/;
      if (!temDisc) add('P0', 'compliance', 'Disclaimer', 'Disclaimer obrigatório ausente no Footer.');
      else {
        let bom = true;
        if (!antifraude.test(tf)) { bom = false; add('P1', 'compliance', 'Disclaimer', 'Disclaimer sem aviso antifraude.'); }
        if (!canais.test(tf)) { bom = false; add('P1', 'compliance', 'Disclaimer', 'Disclaimer sem os canais oficiais de atendimento.'); }
        if (!automatica.test(tf)) { bom = false; add('P1', 'compliance', 'Disclaimer', 'Disclaimer sem a informação de comunicação automática.'); }
        if (bom) ok('Disclaimer no Footer com aviso antifraude, canais oficiais e comunicação automática.');
        const menor = NO_TEXTO.filter(x => dentroDoFooter(x.p) && px(herdado(x.p, 'font-size')) != null && px(herdado(x.p, 'font-size')) < C.legendaMin && x.t.length > 60);
        if (menor.length) add('P2', 'ux', 'Disclaimer', `Disclaimer pouco legível: fonte de ${px(herdado(menor[0].p, 'font-size'))}px (mínimo ${C.legendaMin}px).`, menor[0].p);
      }
    }

    // ============================================================ SEGMENTAÇÃO
    let segmento = 'Varejo', indicios = [];
    {
      const T = universo;
      const DEF = [
        ['Global Private Bank', /global private|private bank/],
        ['Exclusive', /\bexclusive\b/],
        ['Prime', /\bprime\b/],
        ['Corporate', /\bcorporate\b/],
        ['Empresas e Negócios', /empresas e negocios|bradesco empresas|\bpj\b|pessoa juridica/],
        ['Investimentos', /investiment|\bfundos?\b|renda fixa|\bcdb\b|\blci\b|\blca\b|tesouro|wealth|\bfgc\b|previdencia|corretora/],
        ['Não Correntista', /nao correntista|abra (sua )?conta|abrir (sua )?conta|seja cliente|quero ser cliente/]
      ];
      const achou = DEF.filter(([, re]) => re.test(T));
      if (achou.length) { segmento = achou[0][0]; indicios = achou.map(a => a[0]); }
      const fortes = achou.filter(([n]) => n !== 'Investimentos' && n !== 'Não Correntista');
      if (fortes.length > 1) add('P1', 'compliance', 'Segmentação', `Possível mistura de segmentos na mesma peça: ${fortes.map(f => f[0]).join(', ')}.`);
      const cfg = C.segmentos[segmento];
      if (!cfg) manual(`coerência da segmentação "${segmento}" (logo, footer, canais, domínio, disclaimer e telefones): cadastre "segmentos.${segmento}" no regras-time.js`);
      else {
        let bom = true;
        const hosts = links.map(a => { try { return new URL((hrefDe(a) || '').replace(/%%=[\s\S]*?=%%|%%[^%]+%%/g, 'x')).hostname; } catch (e) { return ''; } }).filter(Boolean);
        if ((cfg.dominios || []).length) {
          const fora = hosts.filter(h => !cfg.dominios.some(d => h === d || h.endsWith('.' + d)));
          if (fora.length) { bom = false; add('P1', 'compliance', 'Segmentação', `Domínio fora do segmento ${segmento}: ${[...new Set(fora)].slice(0, 3).join(', ')}.`); }
        }
        if ((cfg.telefones || []).length) {
          const achados = textoFooter.match(/(?:0800[\s-]?\d{3}[\s-]?\d{3,4}|\(?\d{2,4}\)?[\s-]?\d{4}[\s-]?\d{4})/g) || [];
          const dig = s => s.replace(/\D/g, '');
          const errados = achados.filter(t => !cfg.telefones.some(c => dig(c) === dig(t)));
          if (errados.length) { bom = false; add('P1', 'compliance', 'Segmentação', `Telefone fora do segmento ${segmento}: ${errados.slice(0, 3).join(', ')}.`); }
          const faltam = cfg.telefones.filter(c => !achados.some(t => dig(t) === dig(c)));
          if (faltam.length) { bom = false; add('P1', 'compliance', 'Segmentação', `Telefone do segmento ${segmento} ausente no Footer: ${faltam.join(', ')}.`); }
        }
        if ((cfg.logos || []).length) {
          const imgs = [...body.querySelectorAll('img')].map(i => norm((i.getAttribute('src') || '') + ' ' + (i.getAttribute('alt') || '')));
          if (!cfg.logos.some(l => imgs.some(s => s.includes(norm(l))))) { bom = false; add('P1', 'compliance', 'Segmentação', `Logo do segmento ${segmento} não encontrada (esperado: ${cfg.logos.join(' ou ')}).`); }
        }
        for (const frase of (cfg.disclaimers || [])) if (!norm(textoFooter).includes(norm(frase))) { bom = false; add('P1', 'compliance', 'Segmentação', `Disclaimer do segmento ${segmento} sem o trecho: "${frase.slice(0, 60)}".`); }
        if (bom) ok(`Coerência com o segmento ${segmento} conferida (domínio, telefones, logo e disclaimer).`);
        if (!(cfg.coresCTA || []).length) { /* já listado como manual acima */ } else {
          const cores = (cfg.coresCTA || []).map(parseCor).filter(Boolean);
          for (const a of ctas) {
            const td = a.closest('td');
            const c = parseCor(a.getAttribute('bgcolor') || estiloProprio(a)['background-color'] || (td && (td.getAttribute('bgcolor') || estiloProprio(td)['background-color'])));
            if (c && !cores.some(o => o.every((v, i) => v === c[i]))) add('P1', 'ux', 'CTA', `Cor do CTA "${texto(a).slice(0, 30)}" fora das cores oficiais do segmento ${segmento}.`, a);
          }
        }
      }
    }

    // ============================================================ INVESTIMENTOS
    {
      const INV = /investiment|\bfundos?\b|wealth|\bprivate\b|\bfgc\b|renda fixa|\bcdb\b|\blci\b|\blca\b|tesouro|previdencia|rentabilidade|acoes\b/;
      if (INV.test(universo)) {
        const tf = norm(textoFooter);
        const regras = [
          ['Suitability / perfil do investidor', /suitability|perfil (de )?(investidor|de risco)|adequacao/],
          ['Risco', /\brisco|riscos/],
          ['Responsabilidade do investidor', /responsabilidade|leia (o|a|os|as)|prospecto|regulamento|lamina/],
          ['Rentabilidade passada', /rentabilidade (passada|obtida)|rentabilidade n[aã]o|garantia de rentabilidade|nao ha garantia/]
        ];
        const faltam = regras.filter(([, re]) => !re.test(tf)).map(r => r[0]);
        if (faltam.length === regras.length) add('P0', 'compliance', 'Investimentos', 'Campanha de investimentos sem o disclaimer de investimentos (suitability, risco, responsabilidade do investidor e rentabilidade) no Footer.');
        else if (faltam.length) add('P1', 'compliance', 'Investimentos', `Disclaimer de investimentos incompleto; falta: ${faltam.join(', ')}.`);
        else ok('Disclaimer de investimentos completo (suitability, risco, responsabilidade e rentabilidade).');
        if (/\bcdb\b|\blci\b|\blca\b|renda fixa|poupanca|deposito/.test(universo) && !/fgc|fundo garantidor/.test(tf)) add('P1', 'compliance', 'Investimentos', 'Produto de renda fixa/depósito sem menção ao FGC no Footer (quando aplicável).');
        manual('compliance jurídico do texto de investimentos (aprovação do Jurídico)');
      }
    }

    // ============================================================ COMPLIANCE / LGPD
    {
      if (!/privacidade|lgpd|prote[cç][aã]o de dados|dados pessoais/i.test(textoFooter + ' ' + hrefsTudo)) add('P2', 'compliance', 'LGPD', 'Sem referência à Política de Privacidade/LGPD (base legal e transparência) no Footer.');
      else ok('Transparência de dados (privacidade/LGPD) referenciada.');
      if (body.querySelector('script') ) add('P1', 'html', 'Segurança', 'Tag <script> na peça: JavaScript não roda em e-mail e é risco de segurança.');
      manual('base legal e comunicação permitida para a base de destino (avaliação do Jurídico/CRM)');
    }

    // ============================================================ HTML
    {
      let bom = true;
      if (!tk.tokens.some(t => t.t === 'decl' && /^<!doctype/i.test(src.slice(t.s, t.s + 9)))) { bom = false; add('P2', 'html', 'HTML', 'DOCTYPE ausente.'); }
      if (!doc.documentElement.getAttribute('lang')) { bom = false; add('P3', 'html', 'HTML', 'Atributo lang ausente na tag html (acessibilidade).'); }
      const sa = [...body.querySelectorAll('img')].filter(i => !i.hasAttribute('alt'));
      if (sa.length) { bom = false; add('P2', 'html', 'HTML', `${sa.length} imagem(ns) sem atributo alt.`, sa[0]); }
      const amp = tk.errors.filter(e => e.tipo === 'ampAberto');
      if (amp.length) { bom = false; add('P1', 'html', 'AMPScript', `${amp.length} trecho(s) AMPScript sem fechamento (%%[ sem ]%% ou %%= sem =%%); o SFMC recusa o envio.`); }
      const kb = new TextEncoder().encode(src).length / 1024;
      if (kb > 102) { bom = false; add('P2', 'html', 'HTML', `HTML com ${Math.round(kb)} KB; acima de 102 KB o Gmail corta o e-mail.`); }
      if (!/%%view_email_url%%/i.test(src)) { bom = false; add('P2', 'html', 'HTML', 'Link "ver no navegador" (%%view_email_url%%) ausente.'); }
      if (bom) ok('HTML sem pendências técnicas (doctype, lang, alt, AMPScript, tamanho, ver no navegador).');
    }

    // ============================================================ RESPONSIVIDADE
    {
      let bom = true;
      if (![...doc.querySelectorAll('meta')].some(m => /viewport/i.test(m.getAttribute('name') || ''))) { bom = false; add('P2', 'resp', 'Responsividade', 'Meta viewport ausente; a versão mobile pode quebrar.'); }
      if (!temMedia(/@media[^{]*(max-width|max-device-width)/i)) { bom = false; add('P2', 'resp', 'Responsividade', 'Nenhuma media query de largura máxima (@media max-width): a peça não se adapta ao mobile.'); }
      const fixas = [...body.querySelectorAll('table,td,div')].filter(el => { const n = px(el.getAttribute('width')) ?? px(estiloProprio(el).width); return n && n > C.largura; });
      if (fixas.length) { bom = false; add('P2', 'resp', 'Responsividade', `${fixas.length} elemento(s) com largura fixa acima de ${C.largura}px.`, fixas[0]); }
      const rigidas = [...body.querySelectorAll('img')].filter(i => { const w = px(i.getAttribute('width')) ?? px(estiloProprio(i).width); return w && w > 320 && !/max-width\s*:\s*100%|width\s*:\s*100%/i.test(i.getAttribute('style') || '') && !/img[^{]*\{[^}]*max-width/i.test(cssTexto); });
      if (rigidas.length) { bom = false; add('P3', 'resp', 'Responsividade', `${rigidas.length} imagem(ns) larga(s) sem max-width:100% (podem estourar a tela no mobile).`, rigidas[0]); }
      if (bom) ok('Viewport, media query e larguras compatíveis com mobile.');
    }

    // ============================================================ DARK MODE
    {
      let bom = true;
      if (!temMedia(/prefers-color-scheme\s*:\s*dark/i)) { bom = false; add('P2', 'dark', 'Dark Mode', 'Sem regras para dark mode (@media (prefers-color-scheme: dark)): textos, CTA, rodapé e logo podem perder legibilidade.'); }
      if (![...doc.querySelectorAll('meta')].some(m => /^(color-scheme|supported-color-schemes)$/i.test(m.getAttribute('name') || ''))) { bom = false; add('P3', 'dark', 'Dark Mode', 'Meta color-scheme/supported-color-schemes ausente.'); }
      let baixo = 0, exemplo = null;
      for (const x of NO_TEXTO) {
        if (oculto(x.p)) continue;
        const c = parseCor(herdado(x.p, 'color')); if (!c) continue;
        const fd = fundoDe(x.p); if (!fd) continue;
        const r = contraste(c, fd);
        if (r < 4.5) { baixo++; exemplo = exemplo || { x, r }; }
      }
      if (baixo) { bom = false; add('P2', 'dark', 'Contraste', `${baixo} trecho(s) com contraste abaixo de 4,5:1 (ex.: ${exemplo.r.toFixed(1)}:1 em "${exemplo.x.t.slice(0, 40)}").`, exemplo.x.p); }
      const logos = [...body.querySelectorAll('img')].filter(i => /logo/.test(norm((i.getAttribute('src') || '') + (i.getAttribute('alt') || ''))) && /\.jpe?g(\?|$)/i.test(i.getAttribute('src') || ''));
      if (logos.length) { bom = false; add('P3', 'dark', 'Dark Mode', 'Logo em JPG: sem transparência, aparece com caixa branca no dark mode. Prefira PNG transparente.', logos[0]); }
      if (bom) ok('Dark mode previsto, com contraste adequado.');
      manual('aparência real no dark mode (hierarquia, logo e CTA visíveis nos clientes que invertem cores)');
    }

    return fechar(achados, atendidas, manuais, { segmento, indicios });
  }

  // -------------------------------------------------------------- resultado
  function fechar(achados, atendidas, manuais, extra) {
    const por = p => achados.filter(a => a.p === p);
    const p0 = por('P0'), p1 = por('P1'), p2 = por('P2'), p3 = por('P3');
    const scores = {};
    for (const cat of Object.keys(PESO_CAT)) {
      const pen = achados.filter(a => a.cat === cat).reduce((s, a) => s + PESO[a.p], 0);
      scores[cat] = Math.max(0, 100 - pen);
    }
    const geral = Math.round(Object.keys(PESO_CAT).reduce((s, c) => s + scores[c] * PESO_CAT[c], 0));
    const status = p0.length ? 'REPROVADO' : (p1.length || p2.length) ? 'APROVADO COM RESSALVAS' : 'APROVADO';
    const resumo = [
      `Segmentação identificada: ${extra.segmento}${extra.indicios.length > 1 ? ' (outros indícios: ' + extra.indicios.slice(1).join(', ') + ')' : ''}.`,
      `${p0.length} erro(s) P0, ${p1.length} P1, ${p2.length} P2 e ${p3.length} melhoria(s) P3; ${atendidas.length} regra(s) atendida(s).`,
      p0.length ? 'Há reprovação imediata: ' + [...new Set(p0.map(a => a.regra))].join(', ') + '.' : 'Nenhum erro de reprovação imediata.',
      manuais.length ? 'Não verificável automaticamente (conferir manualmente): ' + manuais.join('; ') + '.' : ''
    ].filter(Boolean).join(' ');
    const veredito = status === 'REPROVADO'
      ? 'A peça NÃO pode seguir para aprovação. Corrija todos os erros P0' + (p1.length ? ' e P1' : '') + ' e envie novamente para nova auditoria.'
      : status === 'APROVADO COM RESSALVAS'
        ? 'A peça não tem reprovação imediata e pode seguir para aprovação, desde que as ressalvas (P1 e P2) sejam tratadas ou aceitas formalmente por quem aprova.'
        : 'A peça está aderente às regras verificáveis do GUIDE e pode seguir para aprovação, após a conferência manual dos itens listados no resumo.';
    return { status, resumo, p0, p1, p2, p3, atendidas, manuais, scores, geral, veredito, segmento: extra.segmento };
  }

  /** Relatório no formato exato do GUIDE (Markdown simples, igual ao do GUIDE). */
  function formatar(r) {
    const lista = itens => itens.length
      ? itens.map(a => `- ${a.regra}: ${a.msg}${a.linha ? ' (linha ' + a.linha + ')' : ''}`).join('\n')
      : 'Nenhum';
    return [
      '**STATUS GERAL**', r.status, '',
      '**RESUMO EXECUTIVO**', r.resumo, '',
      '**ERROS P0**', lista(r.p0), '',
      '**ERROS P1**', lista(r.p1), '',
      '**ERROS P2**', lista(r.p2), '',
      '**MELHORIAS P3**', lista(r.p3), '',
      '**REGRAS ATENDIDAS**', r.atendidas.length ? r.atendidas.map(t => '- ' + t).join('\n') : 'Nenhuma', '',
      '**SCORE FINAL**',
      `• Compliance: ${r.scores.compliance}/100`,
      `• UX: ${r.scores.ux}/100`,
      `• Responsividade: ${r.scores.resp}/100`,
      `• HTML: ${r.scores.html}/100`,
      `• Dark Mode: ${r.scores.dark}/100`,
      `• **Score Geral: ${r.geral}/100**`, '',
      '**VEREDITO FINAL**', r.veredito, ''
    ].join('\n');
  }

  WB.guide = { auditar, formatar, PADRAO, NOME_CAT, PESO, PESO_CAT, parseCor, contraste };
})(window.WB = window.WB || {});
